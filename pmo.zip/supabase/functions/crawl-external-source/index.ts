import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

// Types for function parameters
interface CrawlSourceRequest {
  topic: string;
  sources: {
    name: string;
    url: string;
  }[];
  options: {
    freshness?: 'any' | 'recent' | 'very-recent';
  };
}

// Response structure
interface CrawlResult {
  sources: {
    name: string;
    url: string;
    content: string;
    relevance: number;
  }[];
  error?: string;
}

// CORS Headers for cross-origin requests
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    // Parse request
    const { topic, sources, options } = await req.json() as CrawlSourceRequest;

    if (!topic || !sources || sources.length === 0) {
      throw new Error("Missing required parameters: topic and sources");
    }

    // Limit number of sources to crawl to prevent abuse
    const sourcesToCrawl = sources.slice(0, 5);
    
    console.log(`Crawling ${sourcesToCrawl.length} sources for topic: ${topic}`);
    
    // Process sources in parallel with a 10-second timeout per source
    const results = await Promise.all(
      sourcesToCrawl.map(async (source) => {
        try {
          // Create a timeout promise
          const timeoutPromise = new Promise<null>((_, reject) => {
            setTimeout(() => reject(new Error(`Timeout crawling: ${source.url}`)), 10000);
          });
          
          // Create crawl promise
          const crawlPromise = crawlSource(source, topic, options);
          
          // Race timeout against crawl
          const result = await Promise.race([crawlPromise, timeoutPromise]);
          return result;
        } catch (err) {
          console.error(`Error crawling ${source.url}:`, err);
          return null;
        }
      })
    );
    
    // Filter out failed results
    const successfulResults = results.filter(Boolean) as {
      name: string;
      url: string;
      content: string;
      relevance: number;
    }[];
    
    // Sort by relevance
    successfulResults.sort((a, b) => b.relevance - a.relevance);
    
    // Return the results
    return new Response(
      JSON.stringify({ sources: successfulResults }),
      { 
        headers: { 
          ...corsHeaders,
          "Content-Type": "application/json" 
        }
      }
    );

  } catch (error) {
    console.error("Error in crawl-external-source function:", error);
    
    return new Response(
      JSON.stringify({ 
        sources: [],
        error: error instanceof Error ? error.message : "Unknown error occurred" 
      }),
      { 
        status: 400,
        headers: { 
          ...corsHeaders,
          "Content-Type": "application/json" 
        }
      }
    );
  }
});

/**
 * Crawl a specific source URL for relevant content
 */
async function crawlSource(
  source: { name: string; url: string },
  topic: string,
  options: { freshness?: 'any' | 'recent' | 'very-recent' }
): Promise<{ name: string; url: string; content: string; relevance: number } | null> {
  try {
    // Initialize results
    let content = '';
    let relevance = 0;
    
    // Add search parameters to the URL based on the topic
    // This is a simplification - in reality you might need more 
    // sophisticated crawling for each specific source
    const searchUrl = new URL(source.url);
    
    // Add search parameters if the URL doesn't have a search path already
    if (!source.url.includes('/search') && !source.url.includes('?q=') && !source.url.includes('&q=')) {
      if (source.url.includes('pmi.org')) {
        searchUrl.pathname = '/search';
        searchUrl.searchParams.append('q', topic);
      } else if (source.url.includes('hbr.org')) {
        searchUrl.searchParams.append('term', topic);
      } else if (source.url.includes('mckinsey.com')) {
        searchUrl.pathname += '/search';
        searchUrl.searchParams.append('query', topic);
      } else if (source.url.includes('gartner.com')) {
        searchUrl.searchParams.append('keywords', topic);
      } else if (source.url.includes('projectmanagement.com')) {
        searchUrl.searchParams.append('searchString', topic);
      } else {
        // Generic search param
        searchUrl.searchParams.append('q', topic);
      }
    }
    
    // Add freshness parameter if specified and supported
    if (options.freshness && options.freshness !== 'any') {
      const currentDate = new Date();
      if (options.freshness === 'recent') {
        // Last 1 year
        const lastYear = new Date();
        lastYear.setFullYear(currentDate.getFullYear() - 1);
        
        if (source.url.includes('hbr.org')) {
          searchUrl.searchParams.append('dateFrom', lastYear.toISOString().split('T')[0]);
        } else if (source.url.includes('mckinsey.com')) {
          searchUrl.searchParams.append('dateRange', 'past-year');
        }
      } else if (options.freshness === 'very-recent') {
        // Last 3 months
        const threeMonthsAgo = new Date();
        threeMonthsAgo.setMonth(currentDate.getMonth() - 3);
        
        if (source.url.includes('hbr.org')) {
          searchUrl.searchParams.append('dateFrom', threeMonthsAgo.toISOString().split('T')[0]);
        } else if (source.url.includes('mckinsey.com')) {
          searchUrl.searchParams.append('dateRange', 'past-3-months');
        }
      }
    }
    
    // In a real implementation, we would perform intelligent crawling of search results
    // For this demo, we'll generate realistic mock content based on the source
    
    // Simulating web crawling - in production replace with actual crawling code
    // But for security and performance, we recommend using specialized web crawling services
    content = await generateMockContent(source.name, topic);
    
    // Calculate relevance - in production this would be based on semantic similarity
    // For now, we'll use a simple keyword-based approach
    relevance = calculateMockRelevance(content, topic);
    
    return {
      name: source.name,
      url: source.url,
      content,
      relevance
    };
  } catch (error) {
    console.error(`Error crawling ${source.url}:`, error);
    return null;
  }
}

/**
 * Generate realistic mock content for testing
 */
function generateMockContent(sourceName: string, topic: string): string {
  // Normalize topic
  const normalizedTopic = topic.toLowerCase().replace(/[^\w\s]/g, '');
  
  // Generate different content based on the source
  if (sourceName.includes('PMI')) {
    return `According to PMI standards and best practices, establishing a PMO for ${normalizedTopic} requires careful consideration of organizational context and maturity level. The PMI PMBOK® Guide recommends starting with a clear charter and governance framework. Recent studies have shown that successful PMOs align closely with strategic objectives and demonstrate value through measurable KPIs.`;
  }
  
  if (sourceName.includes('Harvard')) {
    return `Recent academic research on ${normalizedTopic} suggests that PMOs should focus on creating value rather than enforcing processes. A Harvard Business Review study found that adaptive PMO structures outperform rigid ones by 27%. Additionally, PMOs that foster knowledge sharing across the organization show higher success rates in project outcomes.`;
  }
  
  if (sourceName.includes('McKinsey')) {
    return `Our analysis of industry trends related to ${normalizedTopic} indicates that leading organizations are transitioning to value-driven PMO models. The most successful implementations begin with stakeholder analysis and clear definition of success metrics. Furthermore, iterative implementation approaches yield better adoption rates compared to big-bang rollouts.`;
  }
  
  if (sourceName.includes('Gartner')) {
    return `Gartner research shows that by 2025, 80% of successful PMOs will shift from process enforcement to strategic enablement for ${normalizedTopic}. Organizations should consider a phased maturity roadmap and focus on building the right capabilities before scaling. Strategic alignment remains the number one success factor according to our latest survey.`;
  }
  
  // Default/generic content
  return `Best practices for ${normalizedTopic} suggest that focus on quick wins is critical for initial PMO acceptance. Templates should be adapted to organizational culture rather than forced standardization. Consider starting with a small set of services and expand gradually based on demonstrated value. Communication strategy is often overlooked but crucial for successful implementation.`;
}

/**
 * Calculate mock relevance score for testing
 */
function calculateMockRelevance(content: string, topic: string): number {
  // Normalize topic and content
  const normalizedTopic = topic.toLowerCase().replace(/[^\w\s]/g, '');
  const normalizedContent = content.toLowerCase();
  
  // Split topic into keywords
  const keywords = normalizedTopic.split(/\s+/);
  
  // Count keyword occurrences
  let matches = 0;
  keywords.forEach(keyword => {
    if (keyword.length > 3) { // Only count meaningful words
      const regex = new RegExp(`\\b${keyword}\\b`, 'g');
      const count = (normalizedContent.match(regex) || []).length;
      matches += count;
    }
  });
  
  // Calculate base relevance
  let relevance = 0.5 + (matches / (keywords.length * 3)) * 0.4;
  
  // Add some randomness for realism
  relevance += (Math.random() * 0.2) - 0.1;
  
  // Ensure relevance is between 0 and 1
  return Math.max(0, Math.min(1, relevance));
}