import { createClient } from "npm:@supabase/supabase-js@2.38.4";
import * as pdfParse from "npm:pdf-parse@1.1.1";

// Define our chunk interfaces
interface DocumentChunk {
  id: string;
  documentId: string;
  content: string;
  chunkIndex: number;
  charStart: number;
  charEnd: number;
  tokenCount?: number;
  pageNumber?: number;
  source?: string;
}

interface DocumentMetadata {
  originalSize: number;
  pageCount?: number;
  author?: string;
  title?: string;
  keywords?: string[];
}

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req) => {
  // Handle CORS preflight request
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 204,
      headers: corsHeaders,
    });
  }
  
  try {
    // Get Supabase client
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('Missing Authorization header');
    }
    
    const supabaseUrl = Deno.env.get('SUPABASE_URL') || '';
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '';
    
    if (!supabaseUrl || !supabaseKey) {
      throw new Error('Missing Supabase credentials');
    }
    
    const supabase = createClient(supabaseUrl, supabaseKey);
    
    if (req.method !== 'POST') {
      return new Response(JSON.stringify({ error: 'Method not allowed' }), {
        status: 405,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
    
    // Get form data with the file
    const formData = await req.formData();
    const file = formData.get('file') as File | null;
    const projectId = formData.get('projectId') as string | null;
    const domainId = formData.get('domainId') as string | null;
    const userId = formData.get('userId') as string | null;
    
    if (!file || !projectId || !userId) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields (file, projectId, or userId)' }),
        {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }
    
    // Process the document based on type
    const fileName = file.name;
    const fileType = fileName.split('.').pop()?.toLowerCase() || '';
    
    let text: string;
    let metadata: DocumentMetadata;
    
    // Generate a unique ID for this document
    const documentId = crypto.randomUUID();
    
    if (fileType === 'pdf') {
      // Process PDF
      const arrayBuffer = await file.arrayBuffer();
      const data = new Uint8Array(arrayBuffer);
      const pdfData = await pdfParse.default(data);
      
      text = pdfData.text;
      metadata = {
        originalSize: arrayBuffer.byteLength,
        pageCount: pdfData.numpages,
        title: pdfData.info?.Title || fileName,
        author: pdfData.info?.Author,
      };
    } else {
      // Process text-based document
      text = await file.text();
      metadata = {
        originalSize: file.size,
        title: fileName,
      };
    }
    
    // Chunk the document
    const chunkSize = 1500;
    const overlapSize = 200;
    const chunks = chunkText(text, documentId, fileName, chunkSize, overlapSize);
    
    // Store document metadata in Supabase
    const { error: documentError } = await supabase
      .from('processed_documents')
      .insert([{
        id: documentId,
        file_name: fileName,
        file_type: fileType,
        total_chunks: chunks.length,
        created_by: userId,
        project_id: projectId,
        domain_id: domainId ? parseInt(domainId) : null,
        metadata: metadata,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      }]);
      
    if (documentError) {
      throw new Error(`Error storing document metadata: ${documentError.message}`);
    }
    
    // Store document chunks in Supabase
    const { error: chunkError } = await supabase
      .from('document_chunks')
      .insert(chunks.map(chunk => ({
        id: chunk.id,
        document_id: chunk.documentId,
        content: chunk.content,
        chunk_index: chunk.chunkIndex,
        char_start: chunk.charStart,
        char_end: chunk.charEnd,
        token_count: estimateTokenCount(chunk.content),
        page_number: chunk.pageNumber,
        source: chunk.source
      })));
      
    if (chunkError) {
      throw new Error(`Error storing document chunks: ${chunkError.message}`);
    }
    
    // Create simple term index
    const index = createSimpleIndex(chunks);
    
    // Store index in Supabase
    const indexInserts = Object.entries(index).map(([term, chunkIds]) => ({
      document_id: documentId,
      term,
      chunk_ids: chunkIds
    }));
    
    // Split into batches to avoid too many items in a single insert
    const BATCH_SIZE = 100;
    for (let i = 0; i < indexInserts.length; i += BATCH_SIZE) {
      const batch = indexInserts.slice(i, i + BATCH_SIZE);
      
      const { error: indexError } = await supabase
        .from('document_index')
        .insert(batch);
        
      if (indexError) {
        console.error('Error storing batch of document index:', indexError);
        // Continue with next batch even if this one failed
      }
    }
    
    return new Response(
      JSON.stringify({ 
        success: true,
        documentId,
        fileName,
        fileType,
        totalChunks: chunks.length,
        metadata
      }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
    
  } catch (error) {
    console.error('Error processing document:', error);
    
    return new Response(
      JSON.stringify({ 
        error: 'Document processing failed', 
        details: error instanceof Error ? error.message : String(error)
      }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});

// Helper function to chunk text
function chunkText(
  text: string, 
  documentId: string, 
  source: string,
  chunkSize: number = 1500, 
  overlapSize: number = 200
): DocumentChunk[] {
  if (!text || text.length === 0) {
    return [];
  }
  
  const chunks: DocumentChunk[] = [];
  
  // Sanitize text - remove excessive whitespace
  const sanitizedText = text.replace(/\s+/g, ' ').trim();
  
  // Split text into paragraphs first
  const paragraphs = sanitizedText.split(/\n\s*\n/);
  
  let currentChunk = '';
  let chunkIndex = 0;
  let charStart = 0;
  
  for (let i = 0; i < paragraphs.length; i++) {
    const paragraph = paragraphs[i].trim();
    
    // Skip empty paragraphs
    if (!paragraph) continue;
    
    // If adding this paragraph would exceed chunk size, create a new chunk
    if (currentChunk && (currentChunk.length + paragraph.length > chunkSize)) {
      // Save the current chunk
      chunks.push({
        id: crypto.randomUUID(),
        documentId,
        content: currentChunk,
        chunkIndex,
        charStart,
        charEnd: charStart + currentChunk.length,
        source
      });
      
      // Start new chunk with overlap
      if (currentChunk.length > overlapSize) {
        // Include the overlap from the previous chunk
        const overlapText = currentChunk.substring(currentChunk.length - overlapSize);
        currentChunk = overlapText + ' ' + paragraph;
      } else {
        currentChunk = paragraph;
      }
      
      charStart = Math.max(0, charStart + currentChunk.length - overlapSize);
      chunkIndex++;
    } else {
      // Add to current chunk
      currentChunk = currentChunk 
        ? currentChunk + ' ' + paragraph 
        : paragraph;
    }
  }
  
  // Add the final chunk if not empty
  if (currentChunk) {
    chunks.push({
      id: crypto.randomUUID(),
      documentId,
      content: currentChunk,
      chunkIndex,
      charStart,
      charEnd: charStart + currentChunk.length,
      source
    });
  }
  
  return chunks;
}

// Estimate token count
function estimateTokenCount(text: string): number {
  if (!text) return 0;
  // Rough approximation: ~4 chars per token for English text
  return Math.ceil(text.length / 4);
}

// Create simple term index
function createSimpleIndex(chunks: DocumentChunk[]): Record<string, string[]> {
  const index: Record<string, string[]> = {};
  
  chunks.forEach(chunk => {
    // Extract terms from chunk content (simplified tokenization)
    const terms = chunk.content
      .toLowerCase()
      .replace(/[^\w\s]/g, '') // Remove punctuation
      .split(/\s+/)            // Split on whitespace
      .filter(term => term.length > 2); // Filter out very short words
    
    // Add each term to the index
    const uniqueTerms = [...new Set(terms)];
    uniqueTerms.forEach(term => {
      if (!index[term]) {
        index[term] = [];
      }
      
      if (!index[term].includes(chunk.id)) {
        index[term].push(chunk.id);
      }
    });
  });
  
  return index;
}