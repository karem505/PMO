import { GoogleGenerativeAI } from "npm:@google/generative-ai@^0.2.0";

interface TemplateParams {
  templateName: string;
  domain: string;
  domainDescription: string;
  inputContent: string;
}

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
};

Deno.serve(async (req: Request) => {
  // CORS preflight request
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders,
      status: 200,
    });
  }

  try {
    // Get API key from environment
    const apiKey = Deno.env.get("VITE_GEMINI_API_KEY");
    if (!apiKey) {
      throw new Error("Gemini API key not found in environment variables");
    }

    // Initialize Gemini AI
    const genAI = new GoogleGenerativeAI(apiKey);
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-pro" });

    if (req.method === "POST") {
      // Parse request body
      const { templateName, domain, domainDescription, inputContent } = await req.json() as TemplateParams;

      if (!templateName || !domain || !inputContent) {
        return new Response(
          JSON.stringify({ error: "Missing required fields" }),
          {
            status: 400,
            headers: {
              ...corsHeaders,
              "Content-Type": "application/json",
            },
          }
        );
      }

      // Construct prompt for template generation
      const prompt = `
You are an expert PMO consultant specializing in creating professional, detailed templates.

Create a detailed, professional-quality "${templateName}" for the PMO domain: "${domain}" (${domainDescription}).

Use the following context to make the template specific to the organization's needs:

USER INPUT:
${inputContent.substring(0, 1000)}

Your template should:
1. Have a clear structure with proper headings and sections
2. Include practical, actionable components that PMO professionals can implement
3. Be comprehensive enough for real-world use
4. Use professional PMO terminology and best practices
5. Be in markdown format with proper formatting (tables, lists, etc.)
6. Include relevant sections like purpose, scope, usage instructions, etc.

The template should be immediately usable by PMO professionals.
`;

      // Generate content using Gemini
      const result = await model.generateContent({
        contents: [{ role: "user", parts: [{ text: prompt }] }],
        generationConfig: {
          temperature: 0.7,
          topK: 40,
          topP: 0.95,
          maxOutputTokens: 4096,
        },
      });

      const templateContent = result.response.text();

      return new Response(
        JSON.stringify({ 
          name: templateName,
          content: templateContent 
        }),
        {
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    return new Response(
      JSON.stringify({ error: "Method not allowed" }),
      {
        status: 405,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    console.error("Error generating template:", error);
    
    return new Response(
      JSON.stringify({ 
        error: "Failed to generate template",
        details: error.message 
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});