import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import Stripe from 'npm:stripe@12.5.0'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS'
}

serve(async (req) => {
  // Handle CORS preflight request
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 204,
      headers: corsHeaders
    })
  }

  try {
    // Get request body
    const { userId, priceId, successUrl, cancelUrl } = await req.json()

    // Validate inputs
    if (!userId || !priceId || !successUrl || !cancelUrl) {
      throw new Error('Missing required parameters')
    }

    // Initialize Stripe with the secret key from environment variables
    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', {
      apiVersion: '2023-10-16',
    })

    // Get customer ID for the user from the database
    const { data: subscriptionData, error: subscriptionError } = await supabaseClient
      .from('subscriptions')
      .select('payment_id')
      .eq('user_id', userId)
      .maybeSingle()

    let customerId = subscriptionData?.payment_id

    // If customer doesn't exist, create a new one
    if (!customerId) {
      // Get user email from auth table
      const { data: userData, error: userError } = await supabaseClient
        .from('users')
        .select('email')
        .eq('id', userId)
        .single()

      if (userError) {
        throw new Error(`Error fetching user: ${userError.message}`)
      }

      // Create a new customer
      const customer = await stripe.customers.create({
        email: userData.email,
        metadata: {
          supabaseUserId: userId
        }
      })

      customerId = customer.id

      // Save customer ID to the database
      const { error: updateError } = await supabaseClient
        .from('subscriptions')
        .update({
          payment_id: customerId,
          payment_provider: 'stripe'
        })
        .eq('user_id', userId)

      if (updateError) {
        throw new Error(`Error updating subscription: ${updateError.message}`)
      }
    }

    // Create a checkout session
    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      mode: 'subscription',
      success_url: successUrl,
      cancel_url: cancelUrl,
      metadata: {
        userId
      },
      client_reference_id: userId,
    })

    // Return the session ID
    return new Response(
      JSON.stringify({ sessionId: session.id }),
      {
        status: 200,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      }
    )
  } catch (err) {
    console.error('Error creating checkout session:', err)

    return new Response(
      JSON.stringify({ error: err.message }),
      {
        status: 400,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      }
    )
  }
})

// Helper to get Supabase client with admin privileges
const supabaseClient = createClient(
  Deno.env.get('SUPABASE_URL') || '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '',
)

// Create a Supabase client
function createClient(supabaseUrl: string, supabaseKey: string) {
  return createSupabaseClient(supabaseUrl, supabaseKey, {
    db: { schema: 'public' },
    auth: { persistSession: false },
  })
}

// Import for Supabase client
import { createClient as createSupabaseClient } from 'npm:@supabase/supabase-js@2.38.4'