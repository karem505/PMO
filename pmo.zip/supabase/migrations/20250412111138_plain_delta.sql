/*
  # Document Processing Schema

  1. New Tables
    - `processed_documents` - Stores document metadata
    - `document_chunks` - Stores chunks of processed documents
    - `document_index` - Stores search terms and related chunk IDs
  
  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to access their own data
*/

-- Processed documents table
CREATE TABLE IF NOT EXISTS processed_documents (
  id UUID PRIMARY KEY,
  file_name TEXT NOT NULL,
  file_type TEXT NOT NULL,
  total_chunks INTEGER NOT NULL,
  created_by UUID REFERENCES auth.users(id),
  project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  metadata JSONB DEFAULT '{}'::JSONB
);

-- Document chunks table
CREATE TABLE IF NOT EXISTS document_chunks (
  id UUID PRIMARY KEY,
  document_id UUID REFERENCES processed_documents(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  chunk_index INTEGER NOT NULL,
  char_start INTEGER NOT NULL,
  char_end INTEGER NOT NULL,
  token_count INTEGER,
  page_number INTEGER,
  source TEXT
);

-- Document index table for search
CREATE TABLE IF NOT EXISTS document_index (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id UUID REFERENCES processed_documents(id) ON DELETE CASCADE,
  term TEXT NOT NULL,
  chunk_ids TEXT[] NOT NULL,
  UNIQUE(document_id, term)
);

-- Enable Row Level Security
ALTER TABLE processed_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE document_chunks ENABLE ROW LEVEL SECURITY;
ALTER TABLE document_index ENABLE ROW LEVEL SECURITY;

-- Create security policies using DO blocks to check if they exist first

-- For processed_documents table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_policies
    WHERE tablename = 'processed_documents' 
    AND policyname = 'Users can view their own documents'
  ) THEN
    CREATE POLICY "Users can view their own documents" 
      ON processed_documents FOR SELECT 
      USING (
        auth.uid() = created_by OR 
        EXISTS (
          SELECT 1 FROM projects 
          WHERE projects.id = processed_documents.project_id 
          AND projects.owner_id = auth.uid()
        )
      );
  END IF;
END
$$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_policies
    WHERE tablename = 'processed_documents' 
    AND policyname = 'Users can insert their own documents'
  ) THEN
    CREATE POLICY "Users can insert their own documents" 
      ON processed_documents FOR INSERT 
      WITH CHECK (auth.uid() = created_by);
  END IF;
END
$$;

-- For document_chunks table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_policies
    WHERE tablename = 'document_chunks' 
    AND policyname = 'Users can view chunks for their documents'
  ) THEN
    CREATE POLICY "Users can view chunks for their documents" 
      ON document_chunks FOR SELECT 
      USING (
        EXISTS (
          SELECT 1 FROM processed_documents 
          WHERE processed_documents.id = document_chunks.document_id 
          AND (
            processed_documents.created_by = auth.uid() OR 
            EXISTS (
              SELECT 1 FROM projects 
              WHERE projects.id = processed_documents.project_id 
              AND projects.owner_id = auth.uid()
            )
          )
        )
      );
  END IF;
END
$$;

-- For document_index table  
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_policies
    WHERE tablename = 'document_index' 
    AND policyname = 'Users can view index for their documents'
  ) THEN
    CREATE POLICY "Users can view index for their documents" 
      ON document_index FOR SELECT 
      USING (
        EXISTS (
          SELECT 1 FROM processed_documents 
          WHERE processed_documents.id = document_index.document_id 
          AND (
            processed_documents.created_by = auth.uid() OR 
            EXISTS (
              SELECT 1 FROM projects 
              WHERE projects.id = processed_documents.project_id 
              AND projects.owner_id = auth.uid()
            )
          )
        )
      );
  END IF;
END
$$;

-- Indexes for better query performance
CREATE INDEX IF NOT EXISTS document_chunks_document_id_idx ON document_chunks(document_id);
CREATE INDEX IF NOT EXISTS document_index_document_id_idx ON document_index(document_id);
CREATE INDEX IF NOT EXISTS document_index_term_idx ON document_index(term);
CREATE INDEX IF NOT EXISTS processed_documents_project_id_idx ON processed_documents(project_id);
CREATE INDEX IF NOT EXISTS processed_documents_created_by_idx ON processed_documents(created_by);