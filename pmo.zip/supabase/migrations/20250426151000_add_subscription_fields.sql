-- Add subscription-related fields to profiles table
ALTER TABLE profiles
ADD COLUMN IF NOT EXISTS subscription_plan TEXT DEFAULT 'free' CHECK (subscription_plan IN ('free', 'premium', 'enterprise')),
ADD COLUMN IF NOT EXISTS token_limit INTEGER DEFAULT 81250 CHECK (token_limit > 0),
ADD COLUMN IF NOT EXISTS remaining_tokens INTEGER DEFAULT 81250 CHECK (remaining_tokens >= 0),
ADD COLUMN IF NOT EXISTS storage_limit_mb INTEGER DEFAULT 100 CHECK (storage_limit_mb > 0),
ADD COLUMN IF NOT EXISTS used_storage_mb INTEGER DEFAULT 0 CHECK (used_storage_mb >= 0),
ADD COLUMN IF NOT EXISTS next_billing_date TIMESTAMPTZ,
ADD COLUMN IF NOT EXISTS is_trial BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS trial_end_date TIMESTAMPTZ,
ADD COLUMN IF NOT EXISTS subscription_status TEXT DEFAULT 'active' CHECK (subscription_status IN ('active', 'inactive', 'trial', 'expired', 'cancelled'));

-- Create indexes for subscription-related queries
CREATE INDEX IF NOT EXISTS profiles_subscription_plan_idx ON profiles(subscription_plan);
CREATE INDEX IF NOT EXISTS profiles_subscription_status_idx ON profiles(subscription_status);
CREATE INDEX IF NOT EXISTS profiles_trial_end_date_idx ON profiles(trial_end_date);

-- Update RLS policies to allow subscription status checks
DROP POLICY IF EXISTS "Anyone can check subscription status" ON profiles;
CREATE POLICY "Anyone can check subscription status"
ON profiles FOR SELECT
USING (true);

-- Add policy for updating subscription status
CREATE POLICY "Users can update own subscription"
ON profiles FOR UPDATE
USING (auth.uid() = id)
WITH CHECK (auth.uid() = id);

-- Add policy for inserting new profiles
CREATE POLICY "Anyone can insert new profiles"
ON profiles FOR INSERT
WITH CHECK (true); 