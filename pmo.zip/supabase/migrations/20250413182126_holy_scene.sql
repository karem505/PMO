/*
  # External Source Crawling and Validation Infrastructure

  1. New Tables
    - `external_sources` - Stores trusted external sources
    - `crawl_results` - Stores cached results from crawler
    - `content_validations` - Records content validation history
  
  2. Security
    - Enable RLS on all tables
    - Add policies for user access control
*/

-- External trusted sources table
CREATE TABLE IF NOT EXISTS external_sources (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  url TEXT NOT NULL,
  description TEXT,
  category TEXT, -- professional-organization, academic, consulting, etc.
  trust_score NUMERIC NOT NULL DEFAULT 0.7, -- 0-1 scale
  is_active BOOLEAN DEFAULT true,
  is_public BOOLEAN DEFAULT true,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ DEFAULT now(),
  last_updated TIMESTAMPTZ DEFAULT now(),
  UNIQUE(url)
);

-- Cached crawl results
CREATE TABLE IF NOT EXISTS crawl_results (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source_id UUID REFERENCES external_sources(id),
  topic TEXT NOT NULL,
  content TEXT NOT NULL,
  relevance NUMERIC DEFAULT 0.5,
  crawled_at TIMESTAMPTZ DEFAULT now(),
  expire_at TIMESTAMPTZ,
  created_by UUID REFERENCES auth.users(id),
  UNIQUE(source_id, topic)
);

-- Content validation records
CREATE TABLE IF NOT EXISTS content_validations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  content_hash TEXT NOT NULL,
  domain TEXT NOT NULL,
  strictness TEXT NOT NULL,
  is_valid BOOLEAN DEFAULT true,
  confidence NUMERIC DEFAULT 0.5,
  sources_used JSONB DEFAULT '[]'::jsonb,
  suggested_corrections JSONB DEFAULT '[]'::jsonb,
  validated_at TIMESTAMPTZ DEFAULT now(),
  validated_by UUID REFERENCES auth.users(id),
  UNIQUE(content_hash, domain, strictness)
);

-- Enable Row Level Security
ALTER TABLE external_sources ENABLE ROW LEVEL SECURITY;
ALTER TABLE crawl_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE content_validations ENABLE ROW LEVEL SECURITY;

-- Create security policies

-- External sources policies
CREATE POLICY "Anyone can view public external sources" 
  ON external_sources FOR SELECT 
  USING (is_public = true);

CREATE POLICY "Admins can manage all external sources" 
  ON external_sources 
  USING (
    EXISTS (
      SELECT 1 FROM user_roles ur
      JOIN roles r ON ur.role_id = r.id
      WHERE ur.user_id = auth.uid() AND r.name = 'admin'
    )
  );

CREATE POLICY "Users can view their own private sources" 
  ON external_sources FOR SELECT 
  USING (created_by = auth.uid());

-- Crawl results policies
CREATE POLICY "Anyone can view public crawl results" 
  ON crawl_results FOR SELECT 
  USING (
    EXISTS (
      SELECT 1 FROM external_sources
      WHERE external_sources.id = crawl_results.source_id AND external_sources.is_public = true
    )
  );

CREATE POLICY "Users can view their own crawl results" 
  ON crawl_results FOR SELECT 
  USING (created_by = auth.uid());

CREATE POLICY "Admins can manage all crawl results" 
  ON crawl_results 
  USING (
    EXISTS (
      SELECT 1 FROM user_roles ur
      JOIN roles r ON ur.role_id = r.id
      WHERE ur.user_id = auth.uid() AND r.name = 'admin'
    )
  );

-- Content validation policies
CREATE POLICY "Anyone can view content validations" 
  ON content_validations FOR SELECT 
  USING (true);

CREATE POLICY "Users can insert own content validations" 
  ON content_validations FOR INSERT 
  WITH CHECK (auth.uid() = validated_by);

CREATE POLICY "Admins can manage all content validations" 
  ON content_validations 
  USING (
    EXISTS (
      SELECT 1 FROM user_roles ur
      JOIN roles r ON ur.role_id = r.id
      WHERE ur.user_id = auth.uid() AND r.name = 'admin'
    )
  );

-- Insert default trusted sources
INSERT INTO external_sources (name, url, description, category, trust_score, is_public) VALUES
  ('Project Management Institute', 'https://www.pmi.org', 'Global authority on project management standards and practices', 'professional-organization', 0.9, true),
  ('Harvard Business Review', 'https://hbr.org/topic/project-management', 'Academic articles on project management and PMO practices', 'academic', 0.85, true),
  ('McKinsey & Company', 'https://www.mckinsey.com/capabilities/operations/our-insights', 'Industry insights on organizational effectiveness and PMOs', 'consulting', 0.8, true),
  ('Gartner', 'https://www.gartner.com/en/project-portfolio-management', 'Research and advisory on project and portfolio management', 'research', 0.87, true),
  ('ProjectManagement.com', 'https://www.projectmanagement.com/contentCategories/pmo--c-9', 'PMO resources, templates and articles from practitioners', 'practitioner', 0.75, true)
ON CONFLICT (url) DO UPDATE SET 
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  category = EXCLUDED.category,
  trust_score = EXCLUDED.trust_score,
  last_updated = now();

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS crawl_results_source_id_topic_idx ON crawl_results(source_id, topic);
CREATE INDEX IF NOT EXISTS crawl_results_expire_at_idx ON crawl_results(expire_at);
CREATE INDEX IF NOT EXISTS content_validations_content_hash_idx ON content_validations(content_hash);
CREATE INDEX IF NOT EXISTS content_validations_domain_idx ON content_validations(domain);
CREATE INDEX IF NOT EXISTS external_sources_category_idx ON external_sources(category);

-- Create function to clean up expired crawl results
CREATE OR REPLACE FUNCTION clean_expired_crawl_results()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  DELETE FROM crawl_results
  WHERE expire_at < now();
END;
$$;