/*
  # PMO Builder Database Schema

  1. New Tables
    - `profiles` - Stores user profile information
    - `projects` - Stores project information
    - `domain_inputs` - Stores domain input data
    - `domain_outputs` - Stores AI-generated domain analysis
    - `tasks` - Stores task completion status
    - `templates` - Stores generated templates
  
  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to access their own data
*/

-- Profiles table for storing user information
CREATE TABLE IF NOT EXISTS profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  display_name TEXT,
  photo_url TEXT,
  organization_name TEXT,
  industry TEXT,
  pmo_maturity_level TEXT DEFAULT 'Initial',
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Projects table for storing project information
CREATE TABLE IF NOT EXISTS projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  owner_id UUID REFERENCES auth.users(id) NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  start_date TIMESTAMPTZ,
  end_date TIMESTAMPTZ,
  budget NUMERIC,
  budget_spent NUMERIC DEFAULT 0,
  key_objectives JSONB DEFAULT '[]'::JSONB,
  stakeholders JSONB DEFAULT '[]'::JSONB,
  risks JSONB DEFAULT '[]'::JSONB,
  is_active BOOLEAN DEFAULT true
);

-- Domain inputs table for storing user input for domains
CREATE TABLE IF NOT EXISTS domain_inputs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID REFERENCES projects(id) ON DELETE CASCADE NOT NULL,
  domain_id INTEGER NOT NULL,
  content TEXT,
  last_updated TIMESTAMPTZ DEFAULT now(),
  created_by UUID REFERENCES auth.users(id)
);

-- Domain outputs table for storing AI-generated analysis
CREATE TABLE IF NOT EXISTS domain_outputs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID REFERENCES projects(id) ON DELETE CASCADE NOT NULL,
  domain_id INTEGER NOT NULL,
  content TEXT,
  generated_date TIMESTAMPTZ DEFAULT now(),
  created_by UUID REFERENCES auth.users(id)
);

-- Tasks table for storing task completion status
CREATE TABLE IF NOT EXISTS tasks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID REFERENCES projects(id) ON DELETE CASCADE NOT NULL,
  task_id TEXT NOT NULL,
  completed BOOLEAN DEFAULT false,
  notes TEXT,
  attachments JSONB DEFAULT '[]'::JSONB,
  custom_fields JSONB DEFAULT '{}'::JSONB,
  updated_at TIMESTAMPTZ DEFAULT now(),
  updated_by UUID REFERENCES auth.users(id)
);

-- Templates table for storing generated templates
CREATE TABLE IF NOT EXISTS templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_output_id UUID REFERENCES domain_outputs(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  content TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Team collaboration table
CREATE TABLE IF NOT EXISTS teams (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Team members junction table
CREATE TABLE IF NOT EXISTS team_members (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  team_id UUID REFERENCES teams(id) ON DELETE CASCADE,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  role TEXT DEFAULT 'member',
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(team_id, user_id)
);

-- Team project sharing junction table
CREATE TABLE IF NOT EXISTS team_projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  team_id UUID REFERENCES teams(id) ON DELETE CASCADE,
  project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT now(),
  created_by UUID REFERENCES auth.users(id),
  UNIQUE(team_id, project_id)
);

-- Enable Row Level Security on all tables
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE domain_inputs ENABLE ROW LEVEL SECURITY;
ALTER TABLE domain_outputs ENABLE ROW LEVEL SECURITY;
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE teams ENABLE ROW LEVEL SECURITY;
ALTER TABLE team_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE team_projects ENABLE ROW LEVEL SECURITY;

-- Create security policies

-- Profiles: Users can view and update only their own profile
CREATE POLICY "Users can view own profile" 
  ON profiles FOR SELECT 
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile" 
  ON profiles FOR UPDATE
  USING (auth.uid() = id);

-- Projects: Users can view and update their own projects
CREATE POLICY "Users can view own projects" 
  ON projects FOR SELECT 
  USING (auth.uid() = owner_id);

CREATE POLICY "Users can update own projects" 
  ON projects FOR UPDATE
  USING (auth.uid() = owner_id);

CREATE POLICY "Users can insert own projects" 
  ON projects FOR INSERT
  WITH CHECK (auth.uid() = owner_id);

CREATE POLICY "Users can delete own projects" 
  ON projects FOR DELETE
  USING (auth.uid() = owner_id);

-- Domain inputs: Users can view and update inputs for their projects
CREATE POLICY "Users can view domain inputs for own projects" 
  ON domain_inputs FOR SELECT 
  USING (EXISTS (SELECT 1 FROM projects WHERE projects.id = domain_inputs.project_id AND projects.owner_id = auth.uid()));

CREATE POLICY "Users can update domain inputs for own projects" 
  ON domain_inputs FOR UPDATE
  USING (EXISTS (SELECT 1 FROM projects WHERE projects.id = domain_inputs.project_id AND projects.owner_id = auth.uid()));

CREATE POLICY "Users can insert domain inputs for own projects" 
  ON domain_inputs FOR INSERT
  WITH CHECK (EXISTS (SELECT 1 FROM projects WHERE projects.id = domain_inputs.project_id AND projects.owner_id = auth.uid()));

-- Domain outputs: Users can view outputs for their projects
CREATE POLICY "Users can view domain outputs for own projects" 
  ON domain_outputs FOR SELECT 
  USING (EXISTS (SELECT 1 FROM projects WHERE projects.id = domain_outputs.project_id AND projects.owner_id = auth.uid()));

CREATE POLICY "Users can insert domain outputs for own projects" 
  ON domain_outputs FOR INSERT
  WITH CHECK (EXISTS (SELECT 1 FROM projects WHERE projects.id = domain_outputs.project_id AND projects.owner_id = auth.uid()));

-- Tasks: Users can view and update tasks for their projects
CREATE POLICY "Users can view tasks for own projects" 
  ON tasks FOR SELECT 
  USING (EXISTS (SELECT 1 FROM projects WHERE projects.id = tasks.project_id AND projects.owner_id = auth.uid()));

CREATE POLICY "Users can update tasks for own projects" 
  ON tasks FOR UPDATE
  USING (EXISTS (SELECT 1 FROM projects WHERE projects.id = tasks.project_id AND projects.owner_id = auth.uid()));

CREATE POLICY "Users can insert tasks for own projects" 
  ON tasks FOR INSERT
  WITH CHECK (EXISTS (SELECT 1 FROM projects WHERE projects.id = tasks.project_id AND projects.owner_id = auth.uid()));

-- Templates: Users can view templates for their domain outputs
CREATE POLICY "Users can view templates for own domain outputs" 
  ON templates FOR SELECT 
  USING (EXISTS (
    SELECT 1 FROM domain_outputs 
    JOIN projects ON domain_outputs.project_id = projects.id
    WHERE domain_outputs.id = templates.domain_output_id 
    AND projects.owner_id = auth.uid()
  ));

-- Teams: Users can view teams they are members of
CREATE POLICY "Users can view teams they are members of" 
  ON teams FOR SELECT 
  USING (EXISTS (
    SELECT 1 FROM team_members 
    WHERE team_members.team_id = teams.id 
    AND team_members.user_id = auth.uid()
  ));

CREATE POLICY "Users can insert teams" 
  ON teams FOR INSERT
  WITH CHECK (auth.uid() = created_by);

-- Team members: Users can view team members of teams they are in
CREATE POLICY "Users can view members of their teams" 
  ON team_members FOR SELECT 
  USING (EXISTS (
    SELECT 1 FROM team_members AS tm 
    WHERE tm.team_id = team_members.team_id 
    AND tm.user_id = auth.uid()
  ));

-- Team projects: Users can view shared projects for teams they are in
CREATE POLICY "Users can view shared projects for their teams" 
  ON team_projects FOR SELECT 
  USING (EXISTS (
    SELECT 1 FROM team_members 
    WHERE team_members.team_id = team_projects.team_id 
    AND team_members.user_id = auth.uid()
  ));

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS domain_inputs_project_id_idx ON domain_inputs(project_id);
CREATE INDEX IF NOT EXISTS domain_outputs_project_id_idx ON domain_outputs(project_id);
CREATE INDEX IF NOT EXISTS tasks_project_id_idx ON tasks(project_id);
CREATE INDEX IF NOT EXISTS team_members_user_id_idx ON team_members(user_id);
CREATE INDEX IF NOT EXISTS team_members_team_id_idx ON team_members(team_id);
CREATE INDEX IF NOT EXISTS team_projects_team_id_idx ON team_projects(team_id);