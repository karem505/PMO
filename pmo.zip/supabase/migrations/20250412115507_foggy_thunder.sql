-- Roles table for storing role definitions
CREATE TABLE IF NOT EXISTS roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Permissions table for storing permission definitions
CREATE TABLE IF NOT EXISTS permissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Junction table for assigning roles to users
CREATE TABLE IF NOT EXISTS user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role_id UUID NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT now(),
  created_by UUID REFERENCES auth.users(id),
  UNIQUE (user_id, role_id)
);

-- Junction table for assigning permissions to roles
CREATE TABLE IF NOT EXISTS role_permissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  role_id UUID NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  permission_id UUID NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
  resource_type TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE (role_id, permission_id, resource_type) -- Fixed: removed the COALESCE() function
);

-- Junction table for assigning permissions directly to users
CREATE TABLE IF NOT EXISTS user_permissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  permission_id UUID NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
  resource_type TEXT,
  resource_id TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  created_by UUID REFERENCES auth.users(id),
  UNIQUE (user_id, permission_id, resource_type, resource_id) -- Fixed: removed the COALESCE() function
);

-- Project-specific permissions table
CREATE TABLE IF NOT EXISTS project_permissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK (role IN ('viewer', 'editor', 'admin')),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  created_by UUID REFERENCES auth.users(id),
  UNIQUE (project_id, user_id)
);

-- Enable Row Level Security
ALTER TABLE roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE role_permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE project_permissions ENABLE ROW LEVEL SECURITY;

-- Create security policies

-- Roles: Admins can manage all roles
CREATE POLICY "Admins can manage all roles" 
  ON roles 
  USING (
    EXISTS (
      SELECT 1 FROM user_roles ur
      JOIN roles r ON ur.role_id = r.id
      WHERE ur.user_id = auth.uid() AND r.name = 'admin'
    )
  );

-- Permissions: Admins can manage all permissions
CREATE POLICY "Admins can manage all permissions" 
  ON permissions 
  USING (
    EXISTS (
      SELECT 1 FROM user_roles ur
      JOIN roles r ON ur.role_id = r.id
      WHERE ur.user_id = auth.uid() AND r.name = 'admin'
    )
  );

-- User Roles: Admins can manage user roles
CREATE POLICY "Admins can manage user roles" 
  ON user_roles 
  USING (
    EXISTS (
      SELECT 1 FROM user_roles ur
      JOIN roles r ON ur.role_id = r.id
      WHERE ur.user_id = auth.uid() AND r.name = 'admin'
    )
  );

-- Role Permissions: Admins can manage role permissions
CREATE POLICY "Admins can manage role permissions" 
  ON role_permissions 
  USING (
    EXISTS (
      SELECT 1 FROM user_roles ur
      JOIN roles r ON ur.role_id = r.id
      WHERE ur.user_id = auth.uid() AND r.name = 'admin'
    )
  );

-- User Permissions: Admins can manage user permissions
CREATE POLICY "Admins can manage user permissions" 
  ON user_permissions 
  USING (
    EXISTS (
      SELECT 1 FROM user_roles ur
      JOIN roles r ON ur.role_id = r.id
      WHERE ur.user_id = auth.uid() AND r.name = 'admin'
    )
  );

-- Project Permissions: Project admins and system admins can manage project permissions
CREATE POLICY "Project admins can manage project permissions" 
  ON project_permissions 
  USING (
    auth.uid() IN (
      SELECT owner_id FROM projects WHERE id = project_permissions.project_id
    ) OR 
    EXISTS (
      SELECT 1 FROM project_permissions pp
      WHERE pp.project_id = project_permissions.project_id
      AND pp.user_id = auth.uid()
      AND pp.role = 'admin'
    ) OR
    EXISTS (
      SELECT 1 FROM user_roles ur
      JOIN roles r ON ur.role_id = r.id
      WHERE ur.user_id = auth.uid() AND r.name = 'admin'
    )
  );

-- Users can see their own roles
CREATE POLICY "Users can view their own roles"
  ON user_roles
  FOR SELECT
  USING (user_id = auth.uid());

-- Users can see their own permissions
CREATE POLICY "Users can view their own permissions"
  ON user_permissions
  FOR SELECT
  USING (user_id = auth.uid());

-- Users can see project permissions for projects they have access to
CREATE POLICY "Users can view permissions for accessible projects"
  ON project_permissions
  FOR SELECT
  USING (
    project_id IN (
      SELECT id FROM projects WHERE owner_id = auth.uid()
      UNION
      SELECT project_id FROM project_permissions WHERE user_id = auth.uid()
    )
  );

-- Insert default roles and permissions
INSERT INTO roles (name, description) 
VALUES 
  ('admin', 'Full system access with all permissions'),
  ('manager', 'Can manage projects and teams'),
  ('user', 'Standard user access')
ON CONFLICT (name) DO NOTHING;

-- Insert default permissions
INSERT INTO permissions (name, description)
VALUES
  -- Project permissions
  ('project:create', 'Can create new projects'),
  ('project:read', 'Can view projects'),
  ('project:update', 'Can update project details'),
  ('project:delete', 'Can delete projects'),
  ('project:share', 'Can share projects with other users'),
  
  -- Team permissions
  ('team:create', 'Can create new teams'),
  ('team:read', 'Can view teams'),
  ('team:update', 'Can update team details'),
  ('team:delete', 'Can delete teams'),
  ('team:invite', 'Can invite users to teams'),
  
  -- Document permissions
  ('document:upload', 'Can upload documents'),
  ('document:read', 'Can view documents'),
  ('document:delete', 'Can delete documents'),
  
  -- Domain permissions
  ('domain:input', 'Can create domain inputs'),
  ('domain:analyze', 'Can run domain analysis'),
  ('domain:read', 'Can view domain analysis results'),
  
  -- Admin permissions
  ('admin:users', 'Can manage users'),
  ('admin:roles', 'Can manage roles and permissions'),
  ('admin:system', 'Can manage system settings')
ON CONFLICT (name) DO NOTHING;

-- Assign permissions to roles
-- First, get role IDs
DO $$
DECLARE
  admin_role_id UUID;
  manager_role_id UUID;
  user_role_id UUID;
BEGIN
  SELECT id INTO admin_role_id FROM roles WHERE name = 'admin';
  SELECT id INTO manager_role_id FROM roles WHERE name = 'manager';
  SELECT id INTO user_role_id FROM roles WHERE name = 'user';
  
  -- Admin role gets all permissions
  INSERT INTO role_permissions (role_id, permission_id)
  SELECT admin_role_id, id FROM permissions
  ON CONFLICT (role_id, permission_id, resource_type) DO NOTHING;
  
  -- Manager role permissions
  INSERT INTO role_permissions (role_id, permission_id)
  SELECT manager_role_id, id FROM permissions
  WHERE name IN ('project:create', 'project:read', 'project:update', 'project:share',
                 'team:create', 'team:read', 'team:update', 'team:invite',
                 'document:upload', 'document:read', 'document:delete',
                 'domain:input', 'domain:analyze', 'domain:read')
  ON CONFLICT (role_id, permission_id, resource_type) DO NOTHING;
  
  -- User role permissions
  INSERT INTO role_permissions (role_id, permission_id)
  SELECT user_role_id, id FROM permissions
  WHERE name IN ('project:read', 'project:update',
                 'team:read',
                 'document:upload', 'document:read',
                 'domain:input', 'domain:analyze', 'domain:read')
  ON CONFLICT (role_id, permission_id, resource_type) DO NOTHING;
END $$;

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS user_roles_user_id_idx ON user_roles(user_id);
CREATE INDEX IF NOT EXISTS user_permissions_user_id_idx ON user_permissions(user_id);
CREATE INDEX IF NOT EXISTS role_permissions_role_id_idx ON role_permissions(role_id);
CREATE INDEX IF NOT EXISTS project_permissions_project_id_idx ON project_permissions(project_id);
CREATE INDEX IF NOT EXISTS project_permissions_user_id_idx ON project_permissions(user_id);