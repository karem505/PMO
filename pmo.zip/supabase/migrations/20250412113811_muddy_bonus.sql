/*
  # Enhanced Task Management

  1. Updates to Task Table
    - Add support for file attachments
    - Add support for document references
    - Enhance custom fields capabilities
  
  2. Task Storage Setup
    - Bucket for task attachments
    - Security policies for attachments

  3. Task API Functions
    - Task cloning functionality
    - Task dependency tracking
*/

-- Add document references column to tasks if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'tasks' AND column_name = 'document_references'
  ) THEN
    ALTER TABLE tasks ADD COLUMN document_references JSONB DEFAULT '[]'::JSONB;
  END IF;
END
$$;

-- Add dependencies column to tasks if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'tasks' AND column_name = 'dependencies'
  ) THEN
    ALTER TABLE tasks ADD COLUMN dependencies TEXT[] DEFAULT ARRAY[]::TEXT[];
  END IF;
END
$$;

-- Create a function to clone tasks
CREATE OR REPLACE FUNCTION clone_task(
  original_task_id TEXT,
  project_id UUID,
  new_task_id TEXT DEFAULT NULL,
  include_attachments BOOLEAN DEFAULT true
) RETURNS UUID AS $$
DECLARE
  original_task_record RECORD;
  new_id UUID;
BEGIN
  -- If no new_task_id is provided, generate one
  IF new_task_id IS NULL THEN
    new_task_id := original_task_id || '_clone_' || now()::TEXT;
  END IF;
  
  -- Get the original task record
  SELECT * INTO original_task_record FROM tasks
  WHERE task_id = original_task_id AND project_id = clone_task.project_id;
  
  -- If original task not found, raise exception
  IF original_task_record IS NULL THEN
    RAISE EXCEPTION 'Original task with ID % not found in project %', original_task_id, project_id;
  END IF;
  
  -- Create a new task record with a new UUID
  INSERT INTO tasks (
    id,
    project_id,
    task_id,
    completed,
    notes,
    attachments,
    custom_fields,
    updated_at,
    updated_by,
    document_references,
    dependencies
  ) VALUES (
    gen_random_uuid(),
    project_id,
    new_task_id,
    false, -- Set completed to false for the clone
    original_task_record.notes,
    CASE WHEN include_attachments THEN original_task_record.attachments ELSE '[]'::JSONB END,
    original_task_record.custom_fields,
    now(),
    original_task_record.updated_by,
    original_task_record.document_references,
    original_task_record.dependencies
  )
  RETURNING id INTO new_id;
  
  RETURN new_id;
END;
$$ LANGUAGE plpgsql;

-- Create a function to get related documents for a task
CREATE OR REPLACE FUNCTION get_task_related_documents(
  task_id TEXT,
  project_id UUID,
  limit_count INTEGER DEFAULT 10
) RETURNS TABLE (
  document_id UUID,
  file_name TEXT,
  file_type TEXT,
  domain_id INTEGER,
  relevance FLOAT
) AS $$
BEGIN
  -- Get the task information
  DECLARE
    task_record RECORD;
  BEGIN
    SELECT * INTO task_record FROM tasks
    WHERE tasks.task_id = get_task_related_documents.task_id
    AND tasks.project_id = get_task_related_documents.project_id;
    
    -- If task has document references, return those specific documents
    IF task_record IS NOT NULL AND 
       task_record.document_references IS NOT NULL AND 
       jsonb_array_length(task_record.document_references) > 0 THEN
      
      RETURN QUERY
      WITH doc_refs AS (
        SELECT jsonb_array_elements_text(task_record.document_references)::uuid AS doc_id
      )
      SELECT 
        pd.id AS document_id,
        pd.file_name,
        pd.file_type,
        pd.domain_id,
        1.0 AS relevance
      FROM 
        processed_documents pd
        JOIN doc_refs ON pd.id = doc_refs.doc_id
      WHERE pd.project_id = get_task_related_documents.project_id
      LIMIT limit_count;
      
    ELSE
      -- Otherwise try to find related documents based on task content
      RETURN QUERY
      SELECT 
        pd.id AS document_id,
        pd.file_name,
        pd.file_type,
        pd.domain_id,
        0.5 AS relevance
      FROM 
        processed_documents pd
      WHERE pd.project_id = get_task_related_documents.project_id
      ORDER BY pd.created_at DESC
      LIMIT limit_count;
    END IF;
  END;
END;
$$ LANGUAGE plpgsql;

-- Create a storage bucket for task attachments if it doesn't exist
DO $$
BEGIN
  BEGIN 
    INSERT INTO storage.buckets (id, name, public)
    VALUES ('task-attachments', 'Task attachments', true);
  EXCEPTION
    WHEN unique_violation THEN
      -- Bucket already exists
      NULL;
  END;
END $$;

-- Enable public access to task attachments
DO $$
BEGIN
  BEGIN
    INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
    VALUES (
      'task-attachments', 
      'Task attachments',
      true,
      52428800, -- 50MB limit
      ARRAY[
        'image/jpeg',
        'image/png',
        'image/gif',
        'image/svg+xml',
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.ms-powerpoint',
        'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'text/plain',
        'text/markdown',
        'application/json',
        'application/zip'
      ]::text[]
    );
  EXCEPTION
    WHEN unique_violation THEN
      -- Update the bucket if it exists
      UPDATE storage.buckets
      SET 
        public = true,
        file_size_limit = 52428800,
        allowed_mime_types = ARRAY[
          'image/jpeg',
          'image/png',
          'image/gif',
          'image/svg+xml',
          'application/pdf',
          'application/msword',
          'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
          'application/vnd.ms-excel',
          'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
          'application/vnd.ms-powerpoint',
          'application/vnd.openxmlformats-officedocument.presentationml.presentation',
          'text/plain',
          'text/markdown',
          'application/json',
          'application/zip'
        ]::text[]
      WHERE id = 'task-attachments';
  END;
END $$;

-- Storage policy to allow users to upload task attachments
DO $$
BEGIN
  DROP POLICY IF EXISTS "Users can upload task attachments" ON storage.objects;
  
  CREATE POLICY "Users can upload task attachments"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'task-attachments' AND
    (storage.foldername(name))[1] = 'tasks' AND
    auth.uid() = (
      SELECT t.updated_by 
      FROM tasks t 
      WHERE t.task_id = (storage.foldername(name))[2]
    )
  );
END $$;

-- Storage policy to allow users to download task attachments
DO $$
BEGIN
  DROP POLICY IF EXISTS "Users can download task attachments" ON storage.objects;
  
  CREATE POLICY "Users can download task attachments"
  ON storage.objects FOR SELECT
  TO authenticated
  USING (
    bucket_id = 'task-attachments' AND
    (storage.foldername(name))[1] = 'tasks' AND
    EXISTS (
      SELECT 1 FROM tasks t
      JOIN projects p ON t.project_id = p.id
      WHERE 
        t.task_id = (storage.foldername(name))[2] AND
        p.owner_id = auth.uid()
    )
  );
END $$;

-- Storage policy to allow users to delete their own task attachments
DO $$
BEGIN
  DROP POLICY IF EXISTS "Users can delete their task attachments" ON storage.objects;
  
  CREATE POLICY "Users can delete their task attachments"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'task-attachments' AND
    (storage.foldername(name))[1] = 'tasks' AND
    auth.uid() = (
      SELECT t.updated_by 
      FROM tasks t 
      WHERE t.task_id = (storage.foldername(name))[2]
    )
  );
END $$;