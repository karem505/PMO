import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
// Define Task and DocumentChunk interfaces directly since they're not exported from types
interface Task {
  id: string;
  title: string;
  description: string;
  domainId: number;
  stage: string;
  templates?: string[];
  bestPractices?: string[];
}

interface DocumentChunk {
  content: string;
  metadata: {
    source?: string;
    [key: string]: any;
  };
}

import { useAppStore } from '../store';
import { Sparkles, Download, CheckCircle, Loader2, AlertTriangle, Link, BarChart as FlowChart, Info, X } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { exportToPdf } from '../utils/exportUtils';
import { documentProcessingService } from '../services/documentProcessingService';
import ProcessMapGenerator from './ProcessMapGenerator';
import VisualizeButton from './VisualizeButton';
import { taskPromptService } from '../services/taskPromptService';
import OpenAI from 'openai';
import SourceValidation from './SourceValidation';
import { aiValidationService } from '../services/aiValidationService';
import TaskOutputAcceptance from './TaskOutputAcceptance';
import { useTranslation } from 'react-i18next';
import axios from 'axios';
import apiClient from '../api/client';
import { useToast } from '../hooks/useToast';
import { useLanguage } from '../contexts/LanguageContext';

interface TaskOutputGeneratorProps {
  task: Task;
  onOutputSaved: (taskId: string, output: string, attachments: string[] ) => void;
  taskData: any;
  onClose?: () => void; // Add optional onClose prop
  onGenerating?: (isGenerating: boolean) => void; // Add prop to communicate generation state
}

// Replace the generationSteps array with translation keys
const generationSteps = [
  {
    step: 1,
    messageKey: 'generationSteps.step1'
  },
  {
    step: 2,
    messageKey: 'generationSteps.step2'
  },
  {
    step: 3,
    messageKey: 'generationSteps.step3'
  },
  {
    step: 4,
    messageKey: 'generationSteps.step4'
  },
  {
    step: 5,
    messageKey: 'generationSteps.step5'
  },
  {
    step: 6,
    messageKey: 'generationSteps.step6'
  },
  {
    step: 7,
    messageKey: 'generationSteps.step7'
  }
];

// Add TaskData interface to fix type issues
interface TaskData {
  notes?: string;
  completed?: boolean;
  attachments?: string[];
  customFields?: Record<string, any>;
  acceptanceStatus?: 'accepted' | 'needs-refinement' | 'rejected';
  acceptanceTimestamp?: string;
}

interface ProcessMapGeneratorProps {
  text: string;
  title?: string;
  onError?: (error: Error) => void;
}

const TaskOutputGenerator: React.FC<TaskOutputGeneratorProps> = ({ task, onOutputSaved, taskData, onClose, onGenerating }) => {
  // Change this to directly use the tasks namespace with i18next
  const { t, i18n } = useTranslation('tasks');
  const { language, isRTL } = useLanguage(); // Keep for RTL support
  
  // Update i18n language when the app language changes
  useEffect(() => {
    if (i18n.language !== language) {
      i18n.changeLanguage(language);
    }
  }, [language, i18n]);
  
  const [isInitializing, setIsInitializing] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [output, setOutput] = useState<string>('');
  const [savedOutput, setSavedOutput] = useState<string>('');
  const [exportingPdf, setExportingPdf] = useState(false);
  const [outputSaved, setOutputSaved] = useState(false);
  const [linkedDocuments, setLinkedDocuments] = useState<DocumentChunk[]>([]);
  const [crossDomainDocuments, setCrossDomainDocuments] = useState<DocumentChunk[]>([]);
  const [isLoadingDocs, setIsLoadingDocs] = useState(false);
  const [showVisualization, setShowVisualization] = useState(false);
  const [visualizationType, setVisualizationType] = useState<string>('flowchart');
  const [generatingPrompt, setGeneratingPrompt] = useState(false);
  const [prompt, setPrompt] = useState<string>(''); // Store the generated prompt
  const [generationStartTime, setGenerationStartTime] = useState<number | null>(null);
  const [elapsedTime, setElapsedTime] = useState<number>(0);
  const [showPrompt, setShowPrompt] = useState(false);
  const [isValidating, setIsValidating] = useState(false);
  const [validationResult, setValidationResult] = useState<any>(null);
  const [enhancedOutput, setEnhancedOutput] = useState<string | null>(null);
  const [showAcceptanceUI, setShowAcceptanceUI] = useState(false);
  const [acceptanceStatus, setAcceptanceStatus] = useState<'idle' | 'accepted' | 'needs-refinement' | 'rejected'>('idle');
  const [generatedFileUrl, setGeneratedFileUrl] = useState<string | null>(null);
  const [generatedFileName, setGeneratedFileName] = useState<string | null>(null);
  const [currentGenerationStep, setCurrentGenerationStep] = useState<number>(0);
  const [randomSitesNumber, setRandomSitesNumber] = useState<number>(0);
  // This selectedLanguage is only for API requests, not UI translation
  const [selectedLanguage, setSelectedLanguage] = useState<'english' | 'arabic'>('english');
  const [error, setError] = useState<string | null>(null);
  const toast = useToast();
  const [showCloseConfirmation, setShowCloseConfirmation] = useState(false);
  const [showCancelConfirmation, setShowCancelConfirmation] = useState(false);

  const { getActiveProject, getDomainOutput, getDomainInput, connectionError, showConnectionErrors, updateTaskData } = useAppStore();
  const activeProject = getActiveProject();

  // Add a state variable for estimated time remaining
  const [estimatedTimeRemaining, setEstimatedTimeRemaining] = useState<number | null>(null);
  const [canCancel, setCanCancel] = useState<boolean>(false);

  // Add state for sub-steps in the final generation phase
  const [currentSubStep, setCurrentSubStep] = useState<number>(0);
  const [totalSubSteps, setTotalSubSteps] = useState<number>(0);

  // Add a reference to the API call that can be aborted
  const abortControllerRef = useRef<AbortController | null>(null);

  // Add a ref for the saved timeout
  const savedTimeoutRef = useRef<number | null>(null);
  
  // Add state for download loading
  const [isDownloading, setIsDownloading] = useState(false);

  // Define the sub-step messages once to be reused
  const subStepMessages = [
    'generationSubSteps.structuring',
    'generationSubSteps.drafting',
    'generationSubSteps.enhancing',
    'generationSubSteps.reviewing',
    'generationSubSteps.finalizing'
  ];

  // Add a ref to track the current request ID
  const currentRequestIdRef = useRef<string | null>(null);

  // Add a ref to track if component is mounted
  const isMounted = useRef(true);

  // Add a ref to track animation frame ID for cleanup
  const animationFrameRef = useRef<number | null>(null);
  const transitionTimeoutRef = useRef<number | null>(null);

  // Safe state update function to prevent updates after unmount
  const safeSetState = (setter: any, value: any) => {
    if (isMounted.current) {
      setter(value);
    }
  };

  // Fix the updateIsGenerating function to prevent flickering
  const updateIsGenerating = useCallback((generating: boolean): void => {
    // Clear any existing timeouts to prevent race conditions
    if (transitionTimeoutRef.current) {
      clearTimeout(transitionTimeoutRef.current);
      transitionTimeoutRef.current = null;
    }
    
    if (generating) {
      // First set initializing, then generating with a slight delay
      setIsInitializing(true);
      
      // Use a timeout to ensure proper state sequence
      transitionTimeoutRef.current = window.setTimeout(() => {
        if (isMounted.current) {
          setIsGenerating(true);
        }
      }, 150);
    } else {
      // When stopping, first remove generating state
      setIsGenerating(false);
      
      // Then remove initializing state after a delay
      transitionTimeoutRef.current = window.setTimeout(() => {
        if (isMounted.current) {
          setIsInitializing(false);
        }
      }, 500);
    }
    
    // Notify parent
    if (onGenerating) {
      onGenerating(generating);
    }
  }, [onGenerating]);

  // Add cleanup for animation frame and timeouts
  useEffect(() => {
    // Set mounted flag
    isMounted.current = true;
    
    // Clear any error state on mount
    setError(null);
    
    return () => {
      // Mark component as unmounted to prevent state updates
      isMounted.current = false;
      
      // Cancel any animation frames
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
        animationFrameRef.current = null;
      }
      
      // Clear all timeouts
      if (transitionTimeoutRef.current) {
        clearTimeout(transitionTimeoutRef.current);
        transitionTimeoutRef.current = null;
      }
      
      if (savedTimeoutRef.current) {
        clearTimeout(savedTimeoutRef.current);
        savedTimeoutRef.current = null;
      }
      
      // Abort any ongoing API requests
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
        
        // Also make an API call to cancel any backend processes
        if (activeProject?.id && task?.id) {
          try {
            // Use a new abort controller for the cancellation request to avoid issues
            const cancelController = new AbortController();
            apiClient.post('/pmo/cancel-generation', {
              project_id: activeProject.id,
              task_id: task.id,
              request_id: currentRequestIdRef.current || undefined
            }, {
              signal: cancelController.signal,
              timeout: 5000 // Short timeout for cleanup
            }).catch(err => {
              console.error('Error cancelling backend process during unmount:', err);
              // Try force cancel as last resort
              try {
                apiClient.post('/pmo/force-cancel', {
                  project_id: activeProject.id,
                  task_id: task.id,
                  request_id: currentRequestIdRef.current || undefined
                }).catch(e => console.error('Force cancel also failed during unmount:', e));
              } catch (e) {
                console.error('Error making force cancel request during unmount:', e);
              }
            });
            
            // Set a timeout to abort the cancellation request if it takes too long
            setTimeout(() => {
              if (cancelController) {
                try {
                  cancelController.abort();
                } catch (e) {
                  // Ignore errors during final cleanup
                }
              }
            }, 5000);
          } catch (err) {
            console.error('Error making cancel request during unmount:', err);
          }
        }
        
        abortControllerRef.current = null;
      }
      
      // Reset all state to avoid memory leaks
      // No need to update state since component is unmounting
      currentRequestIdRef.current = null;
    };
  }, [activeProject, task]);

  // Update the loadRelatedDocuments function to handle loading state properly
  const loadRelatedDocuments = useCallback(async () => {
    // If already loading or initializing, don't start another load
    if (isLoadingDocs || isInitializing) return;
    
    setIsLoadingDocs(true);
    setError(null);
    try {
      if (!activeProject) return;

      // Get domain-specific documents
      const domainDocs = await documentProcessingService.getDomainDocuments(
        task?.domainId, 
        activeProject.id
      );
      
      if (!isMounted.current) return;
      safeSetState(setLinkedDocuments, domainDocs || []);

      // Get cross-domain documents that might be relevant to this task
      const crossDocs = await documentProcessingService.getRelevantCrossDomainChunks(
        (task?.title || "") + " " + (task?.description || ""),
        task?.domainId,
        activeProject.id,
        3 // Limit to 3 most relevant chunks
      );
      
      if (!isMounted.current) return;
      safeSetState(setCrossDomainDocuments, crossDocs || []);

    } catch (error: any) {
      console.error('Error loading related documents:', error);
      if (isMounted.current) {
        safeSetState(setError, error?.message || t('errorLoadingRelatedDocuments', 'Failed to load related documents'));
        toast.error(t('errorLoadingRelatedDocuments', 'Error loading related documents'));
      }
    } finally {
      // Only update loading state if component is still mounted
      if (isMounted.current) {
        safeSetState(setIsLoadingDocs, false);
      }
    }
  }, [activeProject, task?.domainId, task?.title, task?.description, toast, isLoadingDocs, isInitializing, t]);

  // Initialize totalSubSteps based on the array length
  useEffect(() => {
    setTotalSubSteps(subStepMessages.length);
  }, [subStepMessages.length]);

  // Fetch task data and related documents
  useEffect(() => {
    const loadTaskData = async () => {
      if (!activeProject) return;

      try {
      const taskData = activeProject.domainData?.tasks?.[task?.id];
      if (taskData?.notes) {
        setSavedOutput(taskData.notes);
        
        // If there's saved output, show the acceptance UI only for non-processing tasks
        if (taskData.notes.trim().length > 0 && task?.stage !== 'processing') {
          setShowAcceptanceUI(true);
        }
        
        // Load acceptance status if available
        if (taskData.acceptanceStatus) {
          setAcceptanceStatus(taskData.acceptanceStatus);
        }
      }

      // Load cross-domain documents and attachments
      await loadRelatedDocuments();
      } catch (error) {
        console.error("Error loading task data:", error);
      }
    };

    loadTaskData();
  }, [task?.id, activeProject, task?.stage, loadRelatedDocuments]);
  
  // For tracking elapsed time during generation and updating step
  useEffect(() => {
    let interval: number | undefined;
    
    if (generationStartTime && isGenerating) {
      interval = window.setInterval(() => {
        if (generationStartTime) {
          const newElapsedTime = Math.floor((Date.now() - generationStartTime) / 1000);
          setElapsedTime(newElapsedTime);
          
          // Update generation step based on elapsed time - adjusted for longer generation times
          // Spread steps across 4 minutes (240 seconds) for main steps, but estimate total time as 7 minutes
          const totalGenerationTime = 240; // 4 minutes in seconds for distributing steps
          const stepsCount = generationSteps.length;
          const timePerStep = totalGenerationTime / stepsCount;
          
          // Calculate step based on elapsed time
          const newStep = Math.min(Math.floor(newElapsedTime / timePerStep) + 1, stepsCount);
          
          // Only update step if it's changed
          if (newStep !== currentGenerationStep) {
            setCurrentGenerationStep(newStep);
            
            // For step 5, generate random number of sites
            if (newStep === 5) {
              setRandomSitesNumber(Math.floor(Math.random() * (100 - 20 + 1)) + 20);
            }
            
            // Reset sub-steps when changing main steps
            setCurrentSubStep(0);
          }
          
          // Update sub-steps for the final generation step (step 7)
          if (currentGenerationStep === 7) {
            // Calculate sub-step based on time in this step
            const timeInFinalStep = newElapsedTime - (6 * timePerStep);
            const subStepDuration = timePerStep / totalSubSteps;
            const newSubStep = Math.min(Math.floor(timeInFinalStep / subStepDuration) + 1, totalSubSteps);
            
            if (newSubStep !== currentSubStep) {
              setCurrentSubStep(newSubStep);
            }
          }
          
          // Calculate estimated time remaining after 30 seconds have passed
          if (newElapsedTime > 30) {
            // Assume total time is 7 minutes (420 seconds) for complex tasks
            const estimatedTotal = 420;
            const remaining = Math.max(0, estimatedTotal - newElapsedTime);
            setEstimatedTimeRemaining(remaining);
            
            // Allow cancellation after 7 minutes (420 seconds)
            if (newElapsedTime > 420 && !canCancel) {
              setCanCancel(true);
            }
          }
        }
      }, 1000);
    } else {
      setElapsedTime(0);
      setCurrentGenerationStep(0);
      setEstimatedTimeRemaining(null);
      setCanCancel(false);
      setCurrentSubStep(0);
    }
    
    return () => {
      if (interval) window.clearInterval(interval);
    };
  }, [generationStartTime, isGenerating, currentGenerationStep, currentSubStep, totalSubSteps, canCancel]);

  // Add an effect to clean up the abort controller on unmount
  useEffect(() => {
    return () => {
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
        abortControllerRef.current = null;
      }
    };
  }, []);

  // Generate a dynamic task-specific prompt using AI
  const generateDynamicPrompt = async () => {
    if (!activeProject) return '';
    
    setGeneratingPrompt(true);
    setError(null);
    try {
      // Get the custom prompt from the taskPromptService
      const dynamicPrompt = await taskPromptService.generateTaskPrompt(
        task,
        savedOutput || '', // Use existing output as context if available
        activeProject.id
      );
      
      setPrompt(dynamicPrompt || '');
      setShowPrompt(true); // Show the prompt to the user
      
      return dynamicPrompt || '';
    } catch (error: any) {
      console.error('Error generating prompt:', error);
      setError(error?.message || 'Failed to generate prompt');
      toast.error('Error generating task prompt');
      return '';
    } finally {
      setGeneratingPrompt(false);
    }
  };

  // Update the handleCancelGeneration function to show confirmation dialog
  const handleCancelGeneration = () => {
    // First ensure no other confirmation dialogs are showing
    setShowCloseConfirmation(false);
    setShowCancelConfirmation(true);
  };

  // Add actual cancel function that will be called after confirmation
  const confirmCancelGeneration = () => {
    // Hide the confirmation dialog
    setShowCancelConfirmation(false);
    
    // Abort the API request if it's in progress
    if (abortControllerRef.current) {
      try {
        abortControllerRef.current.abort();
        console.log('Aborting backend generation request');
      } catch (error) {
        console.error('Error aborting request:', error);
      }
    }
    
    // Update UI state - ensure we reset all generation-related state
    updateIsGenerating(false);
    setGenerationStartTime(null);
    setCurrentGenerationStep(0);
    setCurrentSubStep(0);
    setError('Generation was cancelled by user.');
    toast.info('Generation cancelled. You can try again with a simpler task.');
    
    // Make an explicit API call to cancel the backend process with the request ID
    if (activeProject?.id && task?.id) {
      try {
        const requestId = currentRequestIdRef.current;
        apiClient.post('/pmo/cancel-generation', {
          project_id: activeProject.id,
          task_id: task.id,
          request_id: requestId || undefined
        }, {
          // Use a new abort controller for the cancellation request
          signal: new AbortController().signal,
          timeout: 10000 // 10 second timeout for cancellation
        }).then(() => {
          console.log('Backend generation process cancelled successfully');
        }).catch(err => {
          console.error('Error cancelling backend process:', err);
          // Try a second time with a different endpoint if available
          try {
            apiClient.post('/pmo/force-cancel', {
              project_id: activeProject.id,
              task_id: task.id,
              request_id: requestId || undefined
            }).catch(e => console.error('Force cancel also failed:', e));
          } catch (e) {
            console.error('Error making force cancel request:', e);
          }
        });
      } catch (err) {
        console.error('Error making cancel request:', err);
      }
    }
  };

  // In the generateOutput function, use safeSetState
  const generateOutput = async () => {
    if (!activeProject) {
      toast.error('No active project selected');
      return;
    }
    
    if (!task?.id) {
      toast.error('Invalid task data');
      return;
    }

    // Immediately set initializing state to prevent flickering
    safeSetState(setIsInitializing, true);
    
    // Clear any previous error before starting
    safeSetState(setError, null);
    
    // Reset output state to ensure we're starting fresh
    safeSetState(setOutput, '');
    safeSetState(setEnhancedOutput, null);
    
    // Wait for next frame to ensure initializing UI is visible
    await new Promise(resolve => {
      requestAnimationFrame(() => {
        requestAnimationFrame(resolve);
      });
    });
    
    // Add a small delay to ensure the initializing UI is fully rendered
    await new Promise(resolve => setTimeout(resolve, 200));
    
    // Now safely update UI state
    updateIsGenerating(true);
    safeSetState(setGenerationStartTime, Date.now());
    
    // Create a new AbortController for this request
    const abortController = new AbortController();
    abortControllerRef.current = abortController;
    
    // Set a timeout to show a warning if the request takes too long
    const timeoutWarning = setTimeout(() => {
      if (isGenerating && isMounted.current) {
        toast.warning('The generation is taking longer than expected. You can continue waiting or cancel and try again.');
        // Make cancel button more visible after timeout
        safeSetState(setCanCancel, true);
      }
    }, 90000); // 90 seconds
    
    try {
      // First, generate a dynamic prompt for this task
      const dynamicPrompt = await generateDynamicPrompt();
      if (!dynamicPrompt) {
        throw new Error('Failed to generate a prompt for this task');
      }
      
      // Check if the request was aborted during prompt generation
      if (abortController.signal.aborted) {
        throw new Error('Generation was cancelled by user.');
      }
      
      // Get domain input and analysis from the state
      const domainInput = getDomainInput(task?.domainId);
      const domainOutput = getDomainOutput(task?.domainId);
      
      // Call the backend recommendations API instead of generating locally
      console.log('Calling backend recommendations API');
      
      // Generate a unique request ID for this generation
      const requestId = `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
      // Store the request ID in the ref for cancellation
      currentRequestIdRef.current = requestId;
      
      // Prepare the request payload
      const requestPayload = {
        title: task.title,
        description: task.description,
        domain: task.domainId.toString(),
        stage: task.stage,
        bestPractices: task.bestPractices || [],
        user_input: dynamicPrompt, // Use the generated prompt as user input
        project_id: activeProject.id,
        task_id: task.id,
        language: selectedLanguage, // Use the selected language (english or arabic)
        request_id: requestId // Add unique request ID for cancellation
      };
      
      console.log('Generation request ID:', requestId);
      
      // Make the API call with the abort signal
      const response = await apiClient.post('/pmo/recommendations', requestPayload, {
        signal: abortController.signal,
        timeout: 180000 // 3 minutes timeout
      });
      
      if (!response.data || !response.data.public_url) {
        throw new Error('Invalid response from recommendations API');
      }
      
      // Check if the request was aborted after API call
      if (abortController.signal.aborted) {
        throw new Error('Generation was cancelled by user.');
      }
      
      // Get the content from the public URL - make this abortable too
      const contentResponse = await axios.get(response.data.public_url, {
        signal: abortController.signal,
        timeout: 30000 // 30 seconds timeout for content fetch
      });
      const content = contentResponse.data;
      
      // Check if the request was aborted after content fetch
      if (abortController.signal.aborted) {
        throw new Error('Generation was cancelled by user.');
      }
      
      // Check if component is still mounted before updating state
      if (!isMounted.current) {
        console.log('Component unmounted during error handling, skipping state updates');
        return null;
      }
      
      safeSetState(setOutput, content);
      
      // Store the DOCX file URL directly from response if available
      if (response.data.public_url) {
        // This should be the DOCX document URL
        const docxUrl = response.data.public_url;
        safeSetState(setGeneratedFileUrl, docxUrl);
        
        // Extract filename from URL or create a meaningful one
        const urlParts = docxUrl.split('/');
        let fileName = urlParts[urlParts.length - 1];
        
        // Clean up the filename and ensure it has a .docx extension
        if (fileName.includes('?')) {
          fileName = fileName.split('?')[0];
        }
        
        if (!fileName.toLowerCase().endsWith('.docx')) {
          fileName = `${task.title.replace(/\s+/g, '-')}-${new Date().toISOString().slice(0, 10)}.docx`;
        }
        
        safeSetState(setGeneratedFileName, fileName);
        console.log(`Document URL set: ${docxUrl}, filename: ${fileName}`);
      }
      
      // Ensure the loading screen is shown for a minimum time to display steps
      // Calculate how long the generation has taken so far
      const generationTime = (Date.now() - (generationStartTime || 0)) / 1000;
      const minimumLoadingTime = 30; // Show loading for at least 30 seconds
      
      if (generationTime < minimumLoadingTime) {
        // If generation completed quickly, keep the loading screen visible longer
        console.log(`Generation completed in ${generationTime.toFixed(1)}s, showing loading for ${minimumLoadingTime - generationTime}s more`);
        await new Promise(resolve => setTimeout(resolve, (minimumLoadingTime - generationTime) * 1000));
      }
      
      // Clear the abort controller reference since we're done
      abortControllerRef.current = null;
      currentRequestIdRef.current = null;
      
      return content;
    } catch (error: any) {
      console.error('Error generating output:', error);
      
      // Check if component is still mounted before updating state
      if (!isMounted.current) {
        console.log('Component unmounted during error handling, skipping state updates');
        return null;
      }
      
      // Check if this was an abort error
      if (error.name === 'AbortError' || 
          (typeof error.message === 'string' && (error.message.includes('aborted') || error.message.includes('cancelled')))) {
        safeSetState(setError, 'Generation was cancelled by user.');
        toast.info('Generation cancelled successfully.');
      } else if (error.code === 'ECONNABORTED' || 
                (typeof error.message === 'string' && error.message.includes('timeout'))) {
        // Handle timeout errors specifically
        safeSetState(setError, 'The generation process timed out. Please try again with a simpler task or try later when the system is less busy.');
        toast.error('Generation timed out. Please try again later.');
      } else {
        // Ensure error is a string
        const errorMessage = error?.response?.data?.detail || 
                            (typeof error?.message === 'string' ? error.message : 
                            (error ? String(error) : 'Failed to generate output'));
        safeSetState(setError, errorMessage);
        toast.error(errorMessage || 'Error generating output');
      }
      
      return null;
    } finally {
      clearTimeout(timeoutWarning);
      updateIsGenerating(false);
      safeSetState(setGenerationStartTime, null);
      abortControllerRef.current = null;
    }
  };

  // Effect to handle document URL availability - don't auto-download
  useEffect(() => {
    if (generatedFileUrl) {
      console.log('Generated file URL available:', generatedFileUrl);
      // Don't automatically trigger download, just make the button available
    }
    
    // Empty cleanup function to maintain consistent return type
    return () => {};
  }, [generatedFileUrl]);

  const handleDownload = async () => {
    if (isDownloading) return; // Prevent multiple clicks
    
    setIsDownloading(true);
    try {
      if (!generatedFileUrl) {
        toast.error('No file available to download.');
        return;
      }
      
      // Use the direct URL from the server - this should be a DOCX file
      const fileName = generatedFileName || `${task.title.replace(/\s+/g, '-')}-output.docx`;
      
      // For direct supabase URLs, use fetch to get the file as a blob first
      // This approach works better across different browsers
      const response = await fetch(generatedFileUrl);
      const blob = await response.blob();
      
      // Create a blob URL for the file
      const blobUrl = window.URL.createObjectURL(blob);
      
      // Create a temporary anchor element for download
      const link = document.createElement('a');
      link.href = blobUrl;
      link.setAttribute('download', fileName);
      link.setAttribute('target', '_blank');
      document.body.appendChild(link);
      link.click();
      
      // Clean up with a proper reference to the timeout
      const cleanupTimeout = setTimeout(() => {
        window.URL.revokeObjectURL(blobUrl);
        if (link.parentNode) {
          link.parentNode.removeChild(link);
        }
      }, 100);
      
      toast.success('Download initiated. Check your downloads folder.');
    } catch (error) {
      console.error('Error downloading file:', error);
      toast.error('Failed to download file. Please try again.');
    } finally {
      setIsDownloading(false);
    }
  };
  
  // Validate output with external sources
  const validateOutput = async (content: string) => {
    if (!content) return null;
    
    setIsValidating(true);
    try {
      const {
        enhancedContent,
        validationResult,
        externalSourcesAdded
      } = await aiValidationService.enhanceAnalysisWithExternalSources(
        content,
        task.title,
        [...linkedDocuments, ...crossDomainDocuments]
      );
      
      setValidationResult(validationResult);
      
      if (externalSourcesAdded) {
        setEnhancedOutput(enhancedContent);
        toast.success('Output validation completed with additional references.');
      } else {
        toast.success('Output validation passed successfully.');
      }
      
      return validationResult;
    } catch (error) {
      console.error('Error validating output:', error);
      toast.error('Failed to validate output.');
      return null;
    } finally {
      setIsValidating(false);
    }
  };

  const generateTaskOutput = async (
    task: Task,
    dynamicPrompt: string,
    inputContent: string,
    analysisContent: string,
    documentChunks: DocumentChunk[] = []
  ): Promise<string> => {
    // Access OpenAI API key from env vars
    const apiKey = import.meta.env.VITE_OPENAI_API_KEY;
    
    if (!apiKey) {
      console.warn('OpenAI API key not found, using mock output');
      return generateMockOutput(task);
    }
    
    // Set a reasonable timeout
    const controller = new AbortController();
    const timeoutId = setTimeout(() => {
      controller.abort();
      console.warn('OpenAI API request timed out after 25 minutes');
    }, 1500000); // 25 minutes timeout
    
    try {
      // Create an OpenAI client
      const openai = new OpenAI({
        apiKey,
        dangerouslyAllowBrowser: true
      });
      
      // Process document chunks into a summary format
      const documentSummary = documentChunks.length > 0
        ? documentChunks.map(chunk => 
            `From ${chunk.metadata.source || 'Document'}: ${chunk.content.substring(0, 150)}...`
          ).join('\n\n').substring(0, 500)
        : '';
      
      try {
        // Call OpenAI API
        const response = await openai.chat.completions.create({
          model: "gpt-3.5-turbo",
          messages: [
            {
              role: "system",
              content: `You are an expert PMO (Project Management Office) consultant who creates practical deliverables for PMO implementation tasks. Focus on creating useful, actionable content based on the prompt provided.`
            },
            {
              role: "user",
              content: `${dynamicPrompt}

ADDITIONAL CONTEXT:
- Task ID: ${task.id}
- Domain Content: ${inputContent ? inputContent.substring(0, 200) + "..." : "None provided"}
- Analysis: ${analysisContent ? analysisContent.substring(0, 200) + "..." : "None available"}
${documentSummary ? `\nDocument Context:\n${documentSummary}` : ""}`
            }
          ],
          max_tokens: 1500,
          temperature: 0.5
        }, { signal: controller.signal });
        
        // Get the generated content
        const generatedText = response.choices[0]?.message?.content || '';
        
        if (!generatedText) {
          console.warn('Empty response from OpenAI API, using mock output');
          return generateMockOutput(task);
        }
        
        return generatedText;
      } catch (apiError: any) {
        console.error('Error calling OpenAI API:', apiError);
        
        // Check if this was a rate limit error
        if (apiError.status === 429) {
          return `# ${task.title}\n\n**Note: We're experiencing high demand right now.**\n\nPlease try again in a few minutes. Our AI system is currently processing many requests.`;
        }
        
        // Check if this was an authentication error
        if (apiError.status === 401) {
          console.error('Authentication error with OpenAI API');
          return generateMockOutput(task);
        }
        
        // For all other errors
        return generateMockOutput(task);
      }
    } catch (error) {
      console.error('Unexpected error in generateTaskOutput:', error);
      return generateMockOutput(task);
    } finally {
      clearTimeout(timeoutId);
    }
  };

  const generateMockOutput = (task: Task): string => {
    // Generate a mock output based on task info
    const taskStageCapitalized = task.stage.charAt(0).toUpperCase() + task.stage.slice(1);
    
    return `# ${task.title} Deliverable

## Overview
This deliverable provides a comprehensive approach to ${task.title.toLowerCase()} as part of the ${taskStageCapitalized} stage for your PMO implementation.

## Purpose
${task.description}

## Process Flow
1. **Initiate the Process**: Begin by gathering key stakeholders and defining the scope
2. **Conduct Current State Assessment**: Evaluate existing practices and identify gaps
3. **Develop Implementation Plan**: Create detailed implementation steps and timelines
4. **Decision Point**: Is executive approval required?
   - If YES: Submit for approval and wait for decision
   - If NO: Proceed with implementation
5. **Execute Implementation**: Deploy the solution according to the plan
6. **Monitor & Measure**: Track key metrics to evaluate effectiveness
7. **Review & Adjust**: Analyze results and make necessary adjustments
8. **Formalize Process**: Document the final process and incorporate into PMO standards

## Key Components

### 1. Assessment Framework
- Current state evaluation methodology
- Gap analysis approach
- Benchmarking criteria against industry standards
- Measurement metrics and KPIs

### 2. Implementation Guidelines
- Step-by-step implementation process
- Roles and responsibilities matrix
- Required resources and tools
- Timeline and milestones

### 3. Best Practices Integration
${task.bestPractices?.map((practice: string) => `- ${practice}`).join('\n') || '- Best practices not specified'}

### 4. Templates and Tools
- ${task.title.split(' ')[0]} template
- Assessment worksheet
- Implementation checklist
- Progress tracking dashboard

## Implementation Recommendations
1. Begin with a comprehensive assessment of current capabilities
2. Identify key stakeholders and secure their engagement
3. Develop a phased implementation approach
4. Create a communication plan for all affected parties
5. Establish clear metrics to measure success
6. Implement feedback mechanisms for continuous improvement
7. Document lessons learned throughout the process

## References
- PMI Standard for Project Management Offices
- Industry benchmarking data
- Organizational best practices

---

*Note: This deliverable should be tailored to your specific organizational context and requirements.*`;
  };

  // Clean up any pending timeouts when component unmounts
  useEffect(() => {
    return () => {
      if (savedTimeoutRef.current) {
        clearTimeout(savedTimeoutRef.current);
        savedTimeoutRef.current = null;
      }
    };
  }, []);

  const handleSave = () => {
    if (!activeProject) {
      toast.error('No active project selected. Please select a project first.');
      return;
    }
    
    if (!output && !enhancedOutput) {
      toast.error('No output to save. Please generate output first.');
      return;
    }
    
    const contentToSave = enhancedOutput || output;
    
    // Validate that we have actual content to save
    if (!contentToSave.trim()) {
      toast.error('Cannot save empty content. Please regenerate the output.');
      return;
    }
    
    onOutputSaved(task.id, contentToSave, []);
      setOutputSaved(true);
    setSavedOutput(contentToSave);
      
      // Show success toast
      toast.success('Task output saved successfully!');
      
    // Clear any existing timeout
    if (savedTimeoutRef.current) {
      clearTimeout(savedTimeoutRef.current);
    }
    
    // Reset saved indicator after a delay - using functional update
    savedTimeoutRef.current = window.setTimeout(() => {
      setOutputSaved(prevState => false);
      savedTimeoutRef.current = null;
    }, 3000);
  };

  const handleExportPdf = async () => {
    setExportingPdf(true);
    try {
      const fileName = `${task.title.replace(/\s+/g, '-')}-Output.pdf`;
      await exportToPdf(enhancedOutput || output, fileName);
      toast.success('PDF export completed successfully.');
    } catch (error) {
      console.error('Error exporting to PDF:', error);
      toast.error('Failed to export PDF. Please try again.');
    } finally {
      setExportingPdf(false);
    }
  };
  
  // Add error handling for visualization
  const handleVisualizeClick = (type: string) => {
    try {
    setVisualizationType(type);
    setShowVisualization(true);
    } catch (error) {
      console.error('Error showing visualization:', error);
      toast.error('Failed to show visualization. Please try again.');
    }
  };
  
  // Format elapsed time as mm:ss
  const formatElapsedTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  // Handle output acceptance
  const handleOutputAcceptance = (content: string, status: 'accepted' | 'needs-refinement' | 'rejected', taskCompleted?: boolean) => {
    // Update the output saved in the store
    onOutputSaved(task.id, content, []);
    
    // Update the acceptance status
    updateTaskData(task.id, {
      acceptanceStatus: status,
      completed: status === 'accepted' && taskCompleted === true
    } as TaskData);
    
    // Update local state - use functional updates to avoid race conditions
    setAcceptanceStatus(prevStatus => status);
    setSavedOutput(prevOutput => content);
    
    if (status === 'rejected') {
      // Clear output to allow regeneration
      setOutput('');
      setEnhancedOutput(null);
    }
  };

  const reset = () => {
    updateIsGenerating(false);
    setGenerationStartTime(null);
    setElapsedTime(0);
    setShowAcceptanceUI(false);
    setAcceptanceStatus('idle');
    setGeneratedFileUrl(null);
    setGeneratedFileName(null);
  };

  // Update the getCurrentStepMessage function to include sub-steps
  const getCurrentStepMessage = () => {
    if (currentGenerationStep === 0 || currentGenerationStep > generationSteps.length) {
      return '';
    }
    
    const stepData = generationSteps[currentGenerationStep - 1];
    
    // Replace placeholder with random number for step 5
    if (currentGenerationStep === 5) {
      // Ensure randomSitesNumber is a valid number before calling toString
      const numberToDisplay = typeof randomSitesNumber === 'number' ? randomSitesNumber.toString() : '3';
      return t(stepData.messageKey).replace('${RANDOM_NUMBER}', numberToDisplay);
    }
    
    // Add sub-step information for the final generation step
    if (currentGenerationStep === 7 && currentSubStep > 0) {
      const baseMessage = t(stepData.messageKey);
      
      // Only show sub-step message if we have one for this sub-step
      if (currentSubStep <= subStepMessages.length) {
        return `${baseMessage}\n\n${t(subStepMessages[currentSubStep - 1], 'Processing...')}`;
      }
    }
    
    return t(stepData.messageKey);
  };

  // Replace the LoadingIndicator component with a translated version
  const LoadingIndicator = () => (
    <div className="task-output-generator-loading w-full h-[200px] overflow-hidden">
      <div className="flex flex-col items-center justify-center h-full fade-transition">
        <div className="relative w-16 h-16 mb-4">
          <div className="absolute inset-0 rounded-full border-4 border-t-blue-600 border-blue-200 animate-spin"></div>
          <div className="absolute inset-0 flex items-center justify-center">
            <Sparkles className="h-6 w-6 text-blue-600" />
          </div>
        </div>
        <h3 className="text-lg font-medium text-gray-800 mb-1">{t('loadingContent', 'Loading Content')}</h3>
        <p className="text-gray-500 text-sm text-center">{t('preparingTaskData', 'Preparing task data and recommendations...')}</p>
      </div>
    </div>
  );

  // Handle close button click
  const handleCloseClick = () => {
    if (isGenerating) {
      // Show confirmation dialog if generation is in progress
      // First ensure no other confirmation dialogs are showing
      setShowCancelConfirmation(false);
      setShowCloseConfirmation(true);
    } else if (onClose) {
      // Close directly if no generation in progress
      onClose();
    }
  };

  // Handle confirmation dialog responses
  const handleConfirmClose = () => {
    // Stop the generation process
    updateIsGenerating(false);
    setGenerationStartTime(null);
    
    // Abort the API request if it's in progress
    if (abortControllerRef.current) {
      try {
        abortControllerRef.current.abort();
        console.log('Aborting backend generation request during close');
      } catch (error) {
        console.error('Error aborting request during close:', error);
      }
    }
    
    // Also make an explicit API call to cancel any backend processes
    if (activeProject?.id && task?.id) {
      try {
        apiClient.post('/pmo/cancel-generation', {
          project_id: activeProject.id,
          task_id: task.id,
          request_id: currentRequestIdRef.current || undefined
        }, {
          // Use a new abort controller for the cancellation request
          signal: new AbortController().signal,
          timeout: 10000 // 10 second timeout for cancellation
        }).then(() => {
          console.log('Backend generation process cancelled successfully during close');
        }).catch(err => {
          console.error('Error cancelling backend process during close:', err);
          // Try a second time with a different endpoint if available
          try {
            apiClient.post('/pmo/force-cancel', {
              project_id: activeProject.id,
              task_id: task.id,
              request_id: currentRequestIdRef.current || undefined
            }).catch(e => console.error('Force cancel also failed during close:', e));
          } catch (e) {
            console.error('Error making force cancel request during close:', e);
          }
        });
      } catch (err) {
        console.error('Error making cancel request during close:', err);
      }
    }
    
    // Reset state
    setError('Generation was cancelled by user.');
    currentRequestIdRef.current = null;
    
    // Close the dialog
    setShowCloseConfirmation(false);
    
    // Call the onClose handler if provided
    if (onClose) {
      // Add a small delay to ensure the UI has time to update
      setTimeout(() => {
      onClose();
      }, 100);
    }
  };

  const handleCancelClose = () => {
    // Just hide the confirmation dialog
    setShowCloseConfirmation(false);
  };

  // Update the renderCancelConfirmationDialog function with translations
  const renderCancelConfirmationDialog = () => {
    if (!showCancelConfirmation) return null;
    
    return (
      <div className="fixed inset-0 bg-black/60 z-[60] flex items-center justify-center p-4" role="dialog" aria-modal="true" aria-labelledby="cancel-dialog-title">
        <div className="bg-white rounded-lg shadow-xl p-6 max-w-md w-full border-2 border-red-200">
          <div className="flex items-center mb-4 text-red-600">
            <AlertTriangle className="h-6 w-6 mr-2" />
            <h3 id="cancel-dialog-title" className="text-lg font-semibold">{t('cancelGenerationQuestion', 'Cancel Generation?')}</h3>
          </div>
          
          <p className="text-gray-700 mb-5">
            {t('cancelGenerationConfirmation', 'Are you sure you want to cancel the generation process? This will stop the backend process completely.')}
          </p>
          
          <div className="flex justify-end gap-3">
          <button 
              onClick={() => setShowCancelConfirmation(false)}
              className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 font-medium"
          >
              {t('noContinue', 'No, Continue')}
          </button>
            <button
              onClick={confirmCancelGeneration}
              className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 font-medium"
            >
              {t('yesCancel', 'Yes, Cancel')}
            </button>
          </div>
        </div>
      </div>
    );
  };

  // Add close confirmation dialog render function to reuse in multiple places
  const renderCloseConfirmationDialog = () => {
    if (!showCloseConfirmation) return null;
    
    return (
      <div className="fixed inset-0 bg-black/60 z-[60] flex items-center justify-center p-4" role="dialog" aria-modal="true" aria-labelledby="close-dialog-title">
        <div className="bg-white rounded-lg shadow-xl p-6 max-w-md w-full border-2 border-blue-200">
          <div className="flex items-center mb-4 text-blue-600">
            <Info className="h-6 w-6 mr-2" />
            <h3 id="close-dialog-title" className="text-lg font-semibold">{t('closeGenerator', 'Close Generator?')}</h3>
          </div>
          
          <p className="text-gray-700 mb-5">
            {t('closeGeneratorConfirmation', 'Are you sure you want to close the generator? Any unsaved progress will be lost.')}
          </p>
          
          <div className="flex justify-end gap-3">
            <button
              onClick={handleCancelClose}
              className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 font-medium"
            >
              {t('stayHere', 'No, Stay Here')}
            </button>
            <button
              onClick={handleConfirmClose}
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 font-medium"
            >
              {t('yesClose', 'Yes, Close')}
            </button>
              </div>
            </div>
      </div>
    );
  };

  // Add error handling for markdown rendering
  const renderMarkdown = useCallback((content: string) => {
    try {
      return <ReactMarkdown>{content}</ReactMarkdown>;
    } catch (error) {
      console.error('Error rendering markdown:', error);
      return (
        <div className="text-red-500 p-4 border border-red-200 rounded">
          <p className="font-medium">{t('errorRenderingContent', 'Error rendering content')}</p>
          <p className="text-sm mt-2">{t('contentDisplayError', 'The content could not be displayed properly. Please try regenerating the output.')}</p>
          <pre className="mt-4 text-xs bg-gray-50 p-2 rounded overflow-auto max-h-40">{content.substring(0, 500)}...</pre>
                </div>
      );
    }
  }, [t]);

  // Memoize markdown rendering for better performance
  const memoizedMarkdown = useMemo(() => {
    if (output) {
      return renderMarkdown(enhancedOutput || output);
    } else if (savedOutput) {
      return renderMarkdown(savedOutput);
    }
    return null;
  }, [output, enhancedOutput, savedOutput, renderMarkdown]);

  // Fix the styling for the initializing state
  if (isInitializing && !isGenerating) {
    return (
      <div className="task-output-generator-modal fixed inset-0 flex items-center justify-center z-[99999] bg-indigo-900/90 backdrop-blur-sm">
        <div className="bg-indigo-800/30 rounded-lg p-8 shadow-xl max-w-md w-full relative border border-indigo-700/50">
          <div className="flex flex-col items-center">
            <div className="w-16 h-16 relative mb-4">
              <div className="absolute inset-0 rounded-full border-4 border-t-white border-white/30 animate-spin"></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <Sparkles className="h-6 w-6 text-white" />
              </div>
            </div>
            <h3 className="text-lg font-medium text-white mb-1">{t('loadingContent', 'Loading Content')}</h3>
            <p className="text-white/80 text-center text-sm">{t('preparingTaskData', 'Preparing task data and recommendations...')}</p>
          </div>
        </div>
      </div>
    );
  }

  // Fix the styling for the generating state
  if (isGenerating) {
    return (
      <>
        <div className="fixed inset-0 bg-indigo-900/90 flex items-center justify-center z-[99999] transition-opacity duration-500" 
             role="dialog" 
             aria-modal="true" 
             aria-labelledby="generation-title">
          <div className="max-w-md w-full text-center relative p-8 bg-indigo-800/30 rounded-lg backdrop-blur-sm shadow-xl">
            {/* Cancel button */}
              <button
              className="absolute top-3 right-3 p-2 rounded-md bg-indigo-800/60 hover:bg-indigo-700 transition-colors flex items-center"
                onClick={handleCancelGeneration}
              aria-label={t('cancelGeneration', 'Cancel generation')}
              >
              <X className="h-5 w-5 text-white" />
              {canCancel && <span className="ml-1 text-sm text-white">{t('cancel', 'Cancel')}</span>}
              </button>
            
            <div className="mb-6">
              <div className="relative mx-auto w-20 h-20">
                <div className="animate-spin rounded-full h-20 w-20 border-4 border-t-transparent border-white/80" role="status"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <Sparkles className="h-8 w-8 text-white" />
            </div>
              </div>
        </div>
        
            <h3 id="generation-title" className="text-xl font-semibold text-white mb-2">{t('generating', 'Generating...')}</h3>
            <p className="text-white/80 text-sm mb-6">{t('generatingMessage', "You'll also find the generated documents in the Project Assets page.")}</p>
            
            {currentGenerationStep > 0 ? (
              <div className="mb-4" aria-live="polite">
                <div className="flex justify-between text-white/80 text-sm mb-2">
                  <span>{`${t('step', 'Step')} ${currentGenerationStep}/${generationSteps.length}`}</span>
                  <span>{formatElapsedTime(elapsedTime)}</span>
                </div>
                
                {/* Progress bar */}
                <div className="w-full bg-indigo-800/50 rounded-full h-2.5 mb-3 overflow-hidden" role="progressbar" aria-valuenow={(currentGenerationStep / generationSteps.length) * 100} aria-valuemin={0} aria-valuemax={100}>
                  <div 
                    className="bg-white h-2.5 rounded-full transition-all duration-300" 
                    style={{ width: `${Math.min((currentGenerationStep / generationSteps.length) * 100, 95)}%` }}
                  />
                </div>
                
                <p className="text-white/90 text-sm mt-3 bg-indigo-800/30 p-3 rounded-md">
                  {getCurrentStepMessage()}
                </p>
                
                {estimatedTimeRemaining !== null && (
                  <p className="text-white/90 text-sm mt-3">{t('estimatedTimeRemaining', 'Est. remaining:')} ~{formatElapsedTime(estimatedTimeRemaining)}</p>
                )}
                
                {/* Add explicit cancel button at the bottom when processing takes too long */}
                {canCancel && (
                <button
                    onClick={handleCancelGeneration}
                    className="mt-5 px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors"
                >
                    {t('cancelGeneration', 'Cancel Generation')}
                </button>
                )}
              </div>
            ) : (
              <div className="rounded-md p-4 bg-indigo-800/40 mt-4" aria-live="polite">
                <p className="text-sm text-white">{t('thinkingAndAnalyzing', 'Thinking and analyzing your requirements...')}</p>
          </div>
        )}
      </div>
        </div>
        {renderCancelConfirmationDialog()}
      </>
    );
  }

  if (isLoadingDocs || generatingPrompt) {
    return (
      <>
        <div className="bg-white rounded-lg p-6 shadow-md my-4 relative min-h-[250px] transition-all duration-300 ease-in-out border border-gray-200 overflow-hidden">
          {/* Add close button */}
          {onClose && (
            <button 
              className="absolute top-3 right-3 p-1.5 rounded-full hover:bg-gray-100 transition-colors"
              onClick={onClose}
              aria-label="Close"
            >
              <X className="h-5 w-5 text-gray-500" />
            </button>
          )}
        <LoadingIndicator />
      </div>
        {renderCancelConfirmationDialog()}
      </>
    );
  }

  if (error) {
    return (
      <>
        <div className="bg-white rounded-lg p-6 shadow-md my-4 relative min-h-[250px] transition-all duration-300 ease-in-out border border-gray-200 overflow-hidden">
          {/* Add close button */}
          {onClose && (
            <button 
              className="absolute top-3 right-3 p-1.5 rounded-full hover:bg-gray-100 transition-colors"
              onClick={onClose}
              aria-label={t('close', 'Close')}
            >
              <X className="h-5 w-5 text-gray-500" />
            </button>
          )}
          <div className="flex flex-col items-center justify-center text-red-500 h-full py-4">
            <AlertTriangle className="h-8 w-8 mb-2" />
            <span className="text-center">
              {typeof error === 'string' ? error : 'An error occurred during generation'}
            </span>
        <button
          onClick={() => setError(null)}
              className="mt-4 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
        >
              {t('tryAgain', 'Try Again')}
        </button>
      </div>
        </div>
        {renderCancelConfirmationDialog()}
      </>
    );
  }

  // For all non-generating states, show the white UI
  return (
    <>
      <div className={`bg-white rounded-lg shadow-md border border-gray-200 overflow-hidden task-output-generator ${isRTL ? 'rtl' : ''}`}>
        <div className="flex items-center justify-between border-b border-gray-200 bg-blue-600 px-6 py-3">
          <h3 className="text-lg font-semibold text-white flex items-center">
            <Sparkles className={`h-5 w-5 ${isRTL ? 'ml-2' : 'mr-2'} text-white`} />
            {task?.title || t('taskOutputGenerator','Task Output Generator')}
          </h3>
      {onClose && (
        <button 
              className="p-1.5 rounded-full hover:bg-blue-700 transition-colors"
          onClick={onClose}
          aria-label={t('close', 'Close')}
        >
          <X className="h-5 w-5 text-white" />
        </button>
      )}
        </div>
        
        <div className="p-6">
      <p className="text-sm text-gray-600 mb-6">
        {t('generateComprehensiveOutputDeliverableForThisTaskBasedOnBestPracticesDomainContextAndYourOrganizationDocuments','Generate a comprehensive output deliverable for this task based on best practices, domain context, and your organization\'s documents.')}
      </p>
      
      {connectionError && showConnectionErrors && (
        <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-100 dark:border-yellow-800 rounded-md p-3 mb-4">
          <div className="flex">
            <AlertTriangle className="flex-shrink-0 mr-2 h-5 w-5 text-yellow-500" />
            <div>
              <h4 className="text-sm font-medium text-amber-800">{t('workingInOfflineMode','Working in offline mode')}</h4>
              <p className="text-xs text-amber-700 mt-1">{t('youCanContinueWorkingButSomeAIFeaturesLimited','You can continue working, but some AI features might be limited.')}</p>
            </div>
          </div>
        </div>
      )}
      
      {/* Related documents section */}
      {(linkedDocuments.length > 0 || crossDomainDocuments.length > 0) && (
        <div className="mb-4 p-3 bg-gray-50 rounded-lg border border-gray-200">
          <h4 className="text-sm font-medium text-gray-700 mb-2 flex items-center">
            <Link className="h-4 w-4 mr-2 text-blue-600" />
            {t('documentsReferencedInAnalysis','Documents Referenced in Analysis')}
          </h4>
          {isLoadingDocs ? (
            <div className="text-sm text-gray-500 flex items-center">
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              {t('loadingDocumentReferences','Loading document references...')}
            </div>
          ) : (
            <>
              {linkedDocuments.length > 0 && (
                <div className="mb-3">
                  <h5 className="text-sm font-medium text-gray-700 mb-1">{t('domainDocuments','Domain Documents')}</h5>
                  <ul className="space-y-1">
                    {linkedDocuments.map((doc, index) => (
                      <li key={index} className="text-sm text-gray-600 flex items-start">
                        <span className="bg-gray-200 text-gray-700 rounded-full w-5 h-5 inline-flex items-center justify-center text-xs mr-2 flex-shrink-0 mt-0.5">{index+1}</span>
                        <span className="flex-1">{doc.metadata.source || t('document','Document')}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              
              {crossDomainDocuments.length > 0 && (
                <div>
                  <h5 className="text-sm font-medium text-gray-700 mb-1">{t('crossDomainReferences','Cross-Domain References')}</h5>
                  <ul className="space-y-1">
                    {crossDomainDocuments.map((doc, index) => (
                      <li key={index} className="text-sm text-gray-600 flex items-start">
                        <span className="bg-purple-100 text-purple-700 rounded-full w-5 h-5 inline-flex items-center justify-center text-xs mr-2 flex-shrink-0 mt-0.5">{index+1}</span>
                        <span className="flex-1">{doc.metadata.source || t('crossDomainDocument','Cross-domain document')}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </>
          )}
        </div>
      )}
      
      {/* Display prompt when being generated or when user wants to view it */}
      {(generatingPrompt || showPrompt) && prompt && (
        <div className="mb-4 p-4 bg-blue-50 rounded-lg border border-blue-100">
          <div className="flex justify-between items-start mb-2">
            <h4 className="text-sm font-medium text-blue-800 flex items-center">
              <Sparkles className="h-4 w-4 mr-2 text-blue-600" />
              {generatingPrompt ? t('generatingTaskPrompt','Generating Task Prompt...') : t('taskSpecificAIPrompt','Task-Specific AI Prompt')}
            </h4>
            {!generatingPrompt && (
              <button 
                className="text-xs bg-blue-600 text-white px-2 py-1 rounded hover:bg-blue-700"
                onClick={() => setShowPrompt(false)}
              >
                {t('hidePrompt','Hide Prompt')}
              </button>
            )}
          </div>
          
          {generatingPrompt ? (
            <div className="flex items-center">
              <Loader2 className="h-4 w-4 mr-2 animate-spin text-blue-600" />
              <span className="text-sm text-blue-700">{t('creatingPersonalizedPromptForThisTask','Creating personalized prompt for this task...')}</span>
            </div>
          ) : (
            <div className="text-sm text-blue-700 bg-white p-3 rounded border border-blue-200 max-h-64 overflow-y-auto prose prose-sm">
                  <pre 
                    className="whitespace-pre-wrap font-sans text-xs"
                    tabIndex={0}
                    aria-label={t('generatedPrompt', 'Generated prompt for this task')}
                  >{prompt}</pre>
            </div>
          )}
        </div>
      )}
      
      {/* Main content area for output generation or display */}
      {(!output && !savedOutput) ? (
        <div className="bg-blue-50 p-6 rounded-lg border border-blue-100 text-center">
          <Sparkles className="h-10 w-10 text-blue-600 mx-auto mb-3" />
          <h3 className="text-lg font-medium text-gray-800 mb-2">{t('generateTaskOutput','Generate Task Output')}</h3>
          <p className="text-sm text-gray-600 mb-4 max-w-lg mx-auto">
            {t('ourAIWillAnalyzeYourTaskRequirementsAndContextToCreateAPersonalizedComprehensiveDeliverableForThisSpecificTask','Our AI will analyze your task requirements and context to create a personalized, comprehensive deliverable for this specific task. Please note this process may take anywhere from 1 to 20 minutes depending on the complexity of the task.')}
          </p>
          <div className="flex flex-col items-center gap-3">
            {/* Language selection toggle */}
            <div className="mb-4">
              <div className="text-gray-700 dark:text-gray-300 mb-1">
                {t('selectGenerationLanguage')}
              </div>
              <div className="flex items-center space-x-4 mt-1">
                <div className="flex items-center">
                  <input
                    type="radio"
                    id="language-english"
                    name="language"
                    value="english"
                    checked={selectedLanguage === 'english'}
                    onChange={(event) => {
                      const newLanguage = event.target.value as 'english' | 'arabic';
                      if (selectedLanguage !== newLanguage && !isGenerating) {
                        setSelectedLanguage(newLanguage);
                        toast.success(t(newLanguage === 'english' ? 'languageSetToEnglish' : 'languageSetToArabic'));
                      }
                    }}
                    disabled={isGenerating}
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 disabled:opacity-50"
                  />
                  <label htmlFor="language-english" className={`ml-2 text-sm font-medium ${isGenerating ? 'text-gray-400' : 'text-gray-700 dark:text-gray-300'}`}>
                    English
                  </label>
                </div>
                <div className="flex items-center">
                  <input
                    type="radio"
                    id="language-arabic"
                    name="language"
                    value="arabic"
                    checked={selectedLanguage === 'arabic'}
                    onChange={(event) => {
                      const newLanguage = event.target.value as 'english' | 'arabic';
                      if (selectedLanguage !== newLanguage && !isGenerating) {
                        setSelectedLanguage(newLanguage);
                        toast.success(t(newLanguage === 'english' ? 'languageSetToEnglish' : 'languageSetToArabic'));
                      }
                    }}
                    disabled={isGenerating}
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 disabled:opacity-50"
                  />
                  <label htmlFor="language-arabic" className={`ml-2 text-sm font-medium ${isGenerating ? 'text-gray-400' : 'text-gray-700 dark:text-gray-300'}`}>
                    العربية
                  </label>
                </div>
              </div>
              <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                {t('generatedContentWillBeIn')}: {selectedLanguage === 'english' ? 'English' : 'العربية'}
              </div>
            </div>
            
            <button
              onClick={generateOutput}
              disabled={isGenerating}
              className={`px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center justify-center min-w-[200px] ${
                isGenerating ? 'opacity-70 cursor-not-allowed' : ''
              }`}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  if (!isGenerating) generateOutput();
                }
              }}
            >
              {isGenerating ? (
                <>
                  <Loader2 className="h-4 w-4 mr-1.5 animate-spin" />
                  {t('generating', 'Generating...')}
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4 mr-2" />
                  {t('generateRecommendations', 'Generate Recommendations')}
                </>
              )}
            </button>
          </div>
        </div>
      ) : (
        <div>
          {/* Source validation if available */}
          {validationResult && (
            <div className="mb-4">
              <SourceValidation
                content={enhancedOutput || output}
                domainName={task.title}
              />
            </div>
          )}

          {/* Content Acceptance UI */}
          {showAcceptanceUI && (
            <TaskOutputAcceptance
              taskId={task.id}
              content={enhancedOutput || output || savedOutput}
              onSave={handleOutputAcceptance}
              onRegenerate={generateOutput}
            />
          )}

          {/* Saved output display - only show if no active output and not showing acceptance UI */}
          {savedOutput && !output && !showAcceptanceUI && (
            <div className="mb-6">
                  <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
                <h4 className="font-medium text-gray-800 flex items-center">
                  <CheckCircle className="mr-3 h-5 w-5 text-green-600" />
                  {t('savedTaskOutput','Saved Task Output')}
                </h4>
                
                    <div className="flex flex-wrap gap-2">
                  <VisualizeButton onVisualize={handleVisualizeClick} />
                  <button 
                    className="px-3 py-1.5 border border-gray-300 text-sm text-gray-700 rounded-md hover:bg-gray-50 flex items-center"
                    onClick={() => {
                      setOutput('');
                      setShowAcceptanceUI(false);
                      generateOutput();
                    }}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' || e.key === ' ') {
                            e.preventDefault();
                            setOutput('');
                            setShowAcceptanceUI(false);
                            generateOutput();
                          }
                    }}
                  >
                    <Sparkles className="h-3.5 w-3.5 mr-1.5" />
                    {t('regenerate','Regenerate')}
                  </button>
                  
                  <button 
                    className="px-3 py-1.5 border border-gray-300 text-sm text-gray-700 rounded-md hover:bg-gray-50 flex items-center"
                    onClick={() => handleExportPdf()}
                    disabled={exportingPdf}
                        onKeyDown={(e) => {
                          if ((e.key === 'Enter' || e.key === ' ') && !exportingPdf) {
                            e.preventDefault();
                            handleExportPdf();
                          }
                        }}
                  >
                    {exportingPdf ? (
                          <>
                      <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />
                            {t('exporting','Exporting...')}
                          </>
                    ) : (
                          <>
                      <Download className="h-3.5 w-3.5 mr-1.5" />
                    {t('exportPDF','Export PDF')}
                          </>
                    )}
                  </button>
                  
                  {generatedFileUrl && (
                    <button
                      onClick={handleDownload}
                          disabled={isDownloading}
                      className="px-3 py-1.5 bg-green-600 text-white rounded-md hover:bg-green-700 flex items-center"
                          onKeyDown={(e) => {
                            if (e.key === 'Enter' || e.key === ' ') {
                              e.preventDefault();
                              if (!isDownloading) handleDownload();
                            }
                          }}
                        >
                          {isDownloading ? (
                            <>
                              <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />
                              {t('downloading', 'Downloading...')}
                      </>
                    ) : (
                      <>
                            <Download className="h-3.5 w-3.5 mr-1.5" />
                            {t('download', 'Download')}
                      </>
                    )}
                  </button>
                  )}
                </div>
              </div>
              
                  {/* File indicator - show when a file has been generated */}
                  {generatedFileUrl && (
                    <div className="mb-4 bg-green-50 border border-green-100 rounded-md p-3 flex items-center justify-between">
                      <div className="flex items-center">
                        <Download className="h-4 w-4 text-green-600 mr-2" />
                        <span className="text-sm text-green-800">
                          {t('documentReady', 'Your document is ready')}: 
                          <span className="font-medium ml-1">{generatedFileName}</span>
                        </span>
              </div>
                  <button 
                        onClick={handleDownload}
                        disabled={isDownloading}
                        className="px-2 py-1 bg-green-600 text-white text-xs rounded hover:bg-green-700 flex items-center"
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' || e.key === ' ') {
                            e.preventDefault();
                            if (!isDownloading) handleDownload();
                          }
                        }}
                      >
                        {isDownloading ? (
                          <>
                            <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                            {t('downloading', 'Downloading...')}
                      </>
                    ) : (
                      <>
                            <Download className="h-3 w-3 mr-1" />
                            {t('downloadNow', 'Download Now')}
                      </>
                    )}
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      )}
      
      <div className="mt-6">
        <div className="bg-gray-50 border border-gray-200 rounded-md p-4">
          <div className="flex items-start">
            <Info className="h-4 w-4 text-gray-500 mt-0.5 mr-2" />
            <div>
              <h4 className="text-sm font-medium text-gray-800">{t('aboutTaskSpecificGeneration', 'About Task-Specific Generation')}</h4>
              <p className="text-xs text-gray-600 mt-1">
                {t('thisFeatureCreatesPersonalizedContentTailoredToThisSpecificTaskUsing', 'This feature creates personalized content tailored to this specific task, using:')}
              </p>
              <ul className="text-xs text-gray-600 mt-1 list-disc list-inside space-y-1">
                <li>{t('taskDetailsAndBestPractices', 'Task details and best practices')}</li>
                <li>{t('domainContextAndRelatedDocuments', 'Domain context and related documents')}</li>
                <li>{t('aiGeneratedTaskSpecificPrompts', 'AI-generated task-specific prompts')}</li>
                <li>{t('externalKnowledgeSourcesForValidationAndEnrichment', 'External knowledge sources for validation and enrichment')}</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
      </div>
      {renderCancelConfirmationDialog()}
      {renderCloseConfirmationDialog()}
    </>
  );
};

export default TaskOutputGenerator;