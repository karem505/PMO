import psycopg2
from dotenv import load_dotenv
import os
from typing import Optional
from contextlib import contextmanager

# Load environment variables
load_dotenv()

# Database configuration
class DatabaseConfig:
    def __init__(self):
        # Load environment variables
        self.user = os.getenv("SUPABASE_USER", "postgres")
        self.password = os.getenv("SUPABASE_PASSWORD")
        self.host = os.getenv("SUPABASE_HOST", "db.uswaicotgqltxfetccme.supabase.co")
        self.port = os.getenv("SUPABASE_PORT", "5432")
        self.dbname = os.getenv("SUPABASE_DBNAME", "postgres")
        self._connection = None
        
    @contextmanager
    def get_connection(self):
        """Get a database connection using context manager."""
        try:
            connection = psycopg2.connect(
                user=self.user,
                password=self.password,
                host=self.host,
                port=self.port,
                dbname=self.dbname
            )
            yield connection
        finally:
            if connection:
                connection.close()
    
    @contextmanager
    def get_cursor(self):
        """Get a database cursor using context manager."""
        with self.get_connection() as connection:
            cursor = connection.cursor()
            try:
                yield cursor
                connection.commit()
            finally:
                cursor.close()

# Create a singleton instance
db_config = DatabaseConfig()

def test_connection() -> tuple[bool, Optional[str]]:
    """Test the database connection."""
    try:
        with db_config.get_cursor() as cursor:
            cursor.execute("SELECT NOW();")
            result = cursor.fetchone()
            return True, f"Connection successful! Current time: {result[0]}"
    except Exception as e:
        return False, f"Connection failed: {str(e)}" 