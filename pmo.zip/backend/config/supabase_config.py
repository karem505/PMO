import os
from supabase import create_client, Client
from dotenv import load_dotenv
from rich.console import Console

# Load environment variables
load_dotenv()

# Initialize console for output
console = Console()

# Supabase configuration
SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_SERVICE_ROLE_KEY")

# Storage bucket names
BUCKET_TASK_ATTACHMENTS = "task-attachments"
BUCKET_OUTPUTS = "outputs"
BUCKET_TASKS_INPUT = "tasks-input"

def get_supabase_client() -> Client:
    """Initialize and return Supabase client."""
    try:
        if not SUPABASE_URL or not SUPABASE_KEY:
            console.print("[bold red]Error: SUPABASE_URL or SUPABASE_KEY environment variables not set[/bold red]")
            return None
        
        return create_client(SUPABASE_URL, SUPABASE_KEY)
    except Exception as e:
        console.print(f"[bold red]Error initializing Supabase client: {e}[/bold red]")
        return None

def ensure_storage_buckets():
    """Ensure required storage buckets exist."""
    try:
        client = get_supabase_client()
        if not client:
            return
            
        # List of required buckets
        required_buckets = [
            BUCKET_TASK_ATTACHMENTS,
            BUCKET_OUTPUTS,
            BUCKET_TASKS_INPUT
        ]
        
        # Get existing buckets
        existing_buckets = client.storage.list_buckets()
        existing_bucket_names = [bucket["name"] for bucket in existing_buckets]
        
        # Create missing buckets
        for bucket_name in required_buckets:
            if bucket_name not in existing_bucket_names:
                try:
                    client.storage.create_bucket(bucket_name, options={"public": True})
                    console.print(f"[bold green]Created storage bucket: {bucket_name}[/bold green]")
                except Exception as e:
                    console.print(f"[bold red]Error creating bucket {bucket_name}: {e}[/bold red]")
                    
    except Exception as e:
        console.print(f"[bold red]Error ensuring storage buckets: {e}[/bold red]")

def upload_file_to_storage(bucket: str, file_path: str, file_name: str, content_type: str = None) -> str:
    """Upload a file to Supabase storage and return its public URL."""
    try:
        client = get_supabase_client()
        if not client:
            return None
            
        # Upload file
        with open(file_path, 'rb') as f:
            file_options = {"content-type": content_type} if content_type else None
            response = client.storage.from_(bucket).upload(
                path=file_name,
                file=f,
                file_options=file_options
            )
            
            if response:
                # Get public URL
                public_url = client.storage.from_(bucket).get_public_url(file_name)
                return public_url
                
    except Exception as e:
        console.print(f"[bold red]Error uploading file to storage: {e}[/bold red]")
        return None

def delete_file_from_storage(bucket: str, file_name: str) -> bool:
    """Delete a file from Supabase storage."""
    try:
        client = get_supabase_client()
        if not client:
            return False
            
        client.storage.from_(bucket).remove([file_name])
        return True
        
    except Exception as e:
        console.print(f"[bold red]Error deleting file from storage: {e}[/bold red]")
        return False 