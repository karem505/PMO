import os
import multiprocessing

# Determine the number of workers based on CPU cores
cores = multiprocessing.cpu_count()
# A common formula is (2 * num_cores) + 1
workers = int(os.getenv("GUNICORN_WORKERS", (2 * cores) + 1))

# Bind to host:port
bind = f"{os.getenv('HOST', '0.0.0.0')}:{os.getenv('PORT', '8000')}"

# Worker settings
worker_class = "uvicorn.workers.UvicornWorker"  # Use Uvicorn's worker class
worker_connections = 1000  # Maximum number of simultaneous connections
timeout = 300  # Timeout for worker processes in seconds
keepalive = 65  # Keep connections alive for this many seconds

# Server settings
graceful_timeout = 120  # Grace period for workers to finish requests before forced restart
max_requests = 1000  # Restart workers after this many requests to prevent memory leaks
max_requests_jitter = 200  # Add random jitter to max_requests to prevent all workers restarting at once

# Log settings
loglevel = os.getenv("GUNICORN_LOG_LEVEL", "info")
errorlog = "-"  # Log to stderr
accesslog = "-"  # Log to stdout
access_log_format = '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s" %(D)s'  # Apache-style log format

# Performance settings
preload_app = True  # Load application code before the worker processes are forked
forwarded_allow_ips = "*"  # Trust X-Forwarded-* headers from all IPs

# Print configuration (helpful for debugging)
print(f"Starting Gunicorn with {workers} workers on {bind}") 