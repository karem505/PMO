import re

def normalize_formatting(text):
    """Normalize formatting for lists, bullet points, and other special characters"""
    if not text:
        return text
        
    # Fix double numbering (e.g., "1. 1. Risk:" -> "1. Risk:")
    text = re.sub(r'(\d+)\.\s+(\d+)\.', r'\1.', text)
    
    # Replace bullet character with dash
    text = text.replace('·', '-')
    text = text.replace('•', '-')
    text = text.replace('⦁', '-')
    
    # Handle bullet followed by dash (e.g., "· - Start")
    text = re.sub(r'-\s*-\s*', '- ', text)
    
    # Ensure consistent spacing after bullet points and numbers
    text = re.sub(r'(\d+\.)(\S)', r'\1 \2', text)  # Add space after numbers if missing
    text = re.sub(r'(-)(\S)', r'\1 \2', text)      # Add space after dashes if missing
    
    # Better handling of nested items with sub-numbering
    lines = text.split('\n')
    result = []
    for i, line in enumerate(lines):
        # Skip empty lines
        if not line.strip():
            result.append(line)
            continue
            
        # Check if this is a nested sub-item with decimal notation (e.g., "1.1 Sub-item")
        if re.search(r'\s+\d+\.\d+\s+', line):
            # Convert to properly formatted sub-item
            line = re.sub(r'(\s+)(\d+)\.(\d+)(\s+)(.+)', r'\1    - Sub-item \2.\3: \5', line)
        
        # Check if this has decimal notation at the beginning of line (e.g., "1.1 Sub-item")
        elif re.match(r'^\d+\.\d+\s+', line):
            # Convert to properly formatted item
            line = re.sub(r'^(\d+)\.(\d+)(\s+)(.+)', r'\1.\2 \4', line)
            
        # Check if this is a nested list item (indented bullet or number)
        elif re.match(r'\s+(-|\d+\.)', line):
            # Ensure consistent indentation - 4 spaces for nested items
            line = re.sub(r'^\s+', '    ', line)
            
        result.append(line)
    
    # Rejoin with newlines
    text = '\n'.join(result)
    
    # Remove any asterisks that might cause bold formatting
    text = re.sub(r'\*\*(.*?)\*\*', r'\1', text)
    
    return text

# Test cases
test_cases = [
    # Double numbering
    "1. 1. Risk: Misinterpretation of the recommendations leading to improper implementation.",
    
    # Bullet points with special characters
    "· - Start by identifying all stakeholders",
    
    # Mixed formatting
    "1. Risk: **Bold text** that should be normal",
    
    # Multiple bullets
    "· First bullet point\n· Second bullet point",
    
    # Nested numbering
    "1. Main item\n   1.1 Sub-item\n   1.2 Another sub-item",
    
    # Inconsistent spacing
    "1.No space after number\n-No space after dash",
    
    # Mixed bullet types
    "· First type\n• Second type\n- Third type",
    
    # Extra test for sub-items
    "1. Main item\n1.1 Sub-item without indent\n1.2 Another without indent",
    
    # Test with long-form sample from user
    """1. 1. Risk: Misinterpretation of the recommendations leading to improper implementation. 
- Likelihood: High - Impact: High - Mitigation: Clear and concise communication of the recommendations along with additional training sessions."""
]

# Run tests
print("=== FORMATTING TEST RESULTS ===\n")

for i, test in enumerate(test_cases):
    print(f"Test {i+1}:")
    print("BEFORE:")
    print(test)
    print("\nAFTER:")
    print(normalize_formatting(test))
    print("\n" + "-"*50 + "\n")

print("=== END OF TESTS ===")

if __name__ == "__main__":
    # This will run when the script is executed directly
    print("Test completed. Check results above.") 