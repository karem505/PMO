from typing import List, Dict, Optional, Any
from datetime import datetime
from rich.console import Console

from ..config.supabase_config import get_supabase_client
from ..models.supabase_models import (
    ProcessedDocument,
    DocumentChunk,
    DocumentIndex,
    BestPracticeCategory,
    BestPracticeDocument,
    BestPracticeTag,
    BestPracticeDocumentTag,
    DomainOutput
)

console = Console()

class SupabaseService:
    def __init__(self):
        self.client = get_supabase_client()
        
    def save_processed_document(self, document: ProcessedDocument) -> bool:
        """Save a processed document to Supabase."""
        try:
            response = self.client.table("processed_documents").insert(document.dict()).execute()
            return bool(response.data)
        except Exception as e:
            console.print(f"[bold red]Error saving processed document: {e}[/bold red]")
            return False
            
    def save_document_chunks(self, chunks: List[DocumentChunk]) -> bool:
        """Save document chunks to Supabase."""
        try:
            chunk_data = [chunk.dict() for chunk in chunks]
            response = self.client.table("document_chunks").insert(chunk_data).execute()
            return bool(response.data)
        except Exception as e:
            console.print(f"[bold red]Error saving document chunks: {e}[/bold red]")
            return False
            
    def save_document_index(self, index: DocumentIndex) -> bool:
        """Save document index to Supabase."""
        try:
            response = self.client.table("document_indices").insert(index.dict()).execute()
            return bool(response.data)
        except Exception as e:
            console.print(f"[bold red]Error saving document index: {e}[/bold red]")
            return False
            
    def get_document_by_id(self, document_id: str) -> Optional[ProcessedDocument]:
        """Retrieve a document by its ID."""
        try:
            response = self.client.table("processed_documents").select("*").eq("id", document_id).execute()
            if response.data:
                return ProcessedDocument(**response.data[0])
            return None
        except Exception as e:
            console.print(f"[bold red]Error retrieving document: {e}[/bold red]")
            return None
            
    def get_document_chunks(self, document_id: str) -> List[DocumentChunk]:
        """Retrieve all chunks for a document."""
        try:
            response = self.client.table("document_chunks").select("*").eq("document_id", document_id).execute()
            return [DocumentChunk(**chunk) for chunk in response.data]
        except Exception as e:
            console.print(f"[bold red]Error retrieving document chunks: {e}[/bold red]")
            return []
            
    def save_best_practice(self, document: BestPracticeDocument, tags: List[str]) -> bool:
        """Save a best practice document with its tags."""
        try:
            # Save the document first
            doc_response = self.client.table("best_practice_documents").insert(document.dict()).execute()
            if not doc_response.data:
                return False
                
            # Save tags and document-tag relationships
            document_id = doc_response.data[0]["id"]
            for tag_name in tags:
                # Create or get tag
                tag_response = self.client.table("best_practice_tags").select("*").eq("name", tag_name).execute()
                tag_id = None
                
                if tag_response.data:
                    tag_id = tag_response.data[0]["id"]
                else:
                    new_tag = BestPracticeTag(name=tag_name)
                    tag_response = self.client.table("best_practice_tags").insert(new_tag.dict()).execute()
                    tag_id = tag_response.data[0]["id"]
                    
                # Create document-tag relationship
                doc_tag = BestPracticeDocumentTag(document_id=document_id, tag_id=tag_id)
                self.client.table("best_practice_document_tags").insert(doc_tag.dict()).execute()
                
            return True
        except Exception as e:
            console.print(f"[bold red]Error saving best practice: {e}[/bold red]")
            return False
            
    def get_best_practices_by_tag(self, tag_name: str) -> List[BestPracticeDocument]:
        """Retrieve best practices by tag name."""
        try:
            query = """
                select d.* from best_practice_documents d
                join best_practice_document_tags dt on d.id = dt.document_id
                join best_practice_tags t on dt.tag_id = t.id
                where t.name = ?
            """
            response = self.client.rpc("get_best_practices_by_tag", {"tag_name": tag_name}).execute()
            return [BestPracticeDocument(**doc) for doc in response.data]
        except Exception as e:
            console.print(f"[bold red]Error retrieving best practices by tag: {e}[/bold red]")
            return []
            
    def save_domain_output(self, output: DomainOutput) -> bool:
        """Save domain-specific output to Supabase."""
        try:
            response = self.client.table("domain_outputs").insert(output.dict()).execute()
            return bool(response.data)
        except Exception as e:
            console.print(f"[bold red]Error saving domain output: {e}[/bold red]")
            return False
            
    def get_domain_outputs(self, domain: str) -> List[DomainOutput]:
        """Retrieve all outputs for a specific domain."""
        try:
            response = self.client.table("domain_outputs").select("*").eq("domain", domain).execute()
            return [DomainOutput(**output) for output in response.data]
        except Exception as e:
            console.print(f"[bold red]Error retrieving domain outputs: {e}[/bold red]")
            return [] 