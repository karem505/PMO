from models.document import DocumentResponse
import PyPDF2
from docx import Document
import pandas as pd
import tabula
import io
from typing import Dict, Any, List
import os
from datetime import datetime

class DocumentReaderService:
    def __init__(self):
        self.documents_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'documents')
        os.makedirs(self.documents_dir, exist_ok=True)

    async def read_document(self, content: bytes, filename: str) -> Dict[str, Any]:
        try:
            # Save the file first
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            saved_filename = f"{timestamp}_{filename}"
            file_path = os.path.join(self.documents_dir, saved_filename)
            
            with open(file_path, 'wb') as f:
                f.write(content)
            
            # Determine file type
            file_type = filename.split('.')[-1].lower()
            
            # Process based on file type
            if file_type == 'pdf':
                return await self._read_pdf(content)
            elif file_type in ['xlsx', 'xls', 'csv']:
                return await self._read_excel(content, file_type)
            elif file_type == 'docx':
                return await self._read_docx(content)
            else:
                raise ValueError(f"Unsupported file type: {file_type}")
                
        except Exception as e:
            raise Exception(f"Error processing document: {str(e)}")

    async def _read_pdf(self, content: bytes) -> Dict[str, Any]:
        try:
            # Create a PDF reader object
            pdf_reader = PyPDF2.PdfReader(io.BytesIO(content))
            
            # Extract text from all pages
            text_content = ""
            for page in pdf_reader.pages:
                text_content += page.extract_text() + "\n"
            
            # Extract metadata
            metadata = {
                "pages": len(pdf_reader.pages),
                "author": pdf_reader.metadata.get("/Author", ""),
                "title": pdf_reader.metadata.get("/Title", ""),
                "subject": pdf_reader.metadata.get("/Subject", ""),
                "keywords": pdf_reader.metadata.get("/Keywords", ""),
                "creator": pdf_reader.metadata.get("/Creator", ""),
                "producer": pdf_reader.metadata.get("/Producer", ""),
                "creation_date": pdf_reader.metadata.get("/CreationDate", ""),
                "modification_date": pdf_reader.metadata.get("/ModDate", "")
            }
            
            return {
                "content": text_content,
                "tables": [],  # PDF tables would require additional processing
                "metadata": metadata
            }
            
        except Exception as e:
            raise Exception(f"Error reading PDF: {str(e)}")

    async def _read_excel(self, content: bytes, file_type: str) -> Dict[str, Any]:
        try:
            # Read Excel file
            if file_type in ['xlsx', 'xls']:
                df = pd.read_excel(io.BytesIO(content))
            else:  # csv
                df = pd.read_csv(io.BytesIO(content))
            
            # Convert to text content
            text_content = df.to_string()
            
            # Extract tables
            tables = []
            for sheet_name, sheet_df in pd.read_excel(io.BytesIO(content), sheet_name=None).items():
                tables.append({
                    "sheet_name": sheet_name,
                    "data": sheet_df.to_dict('records'),
                    "columns": sheet_df.columns.tolist()
                })
            
            # Extract metadata
            metadata = {
                "rows": len(df),
                "columns": len(df.columns),
                "column_names": df.columns.tolist()
            }
            
            return {
                "content": text_content,
                "tables": tables,
                "metadata": metadata
            }
            
        except Exception as e:
            raise Exception(f"Error reading Excel/CSV: {str(e)}")

    async def _read_docx(self, file_content: bytes) -> Dict[str, Any]:
        """
        Read Word documents including text and tables
        """
        doc_file = io.BytesIO(file_content)
        doc = Document(doc_file)
        text_content = []
        tables = []

        # Extract text
        for paragraph in doc.paragraphs:
            text_content.append(paragraph.text)

        # Extract tables
        for table in doc.tables:
            table_data = []
            for row in table.rows:
                row_data = [cell.text for cell in row.cells]
                table_data.append(row_data)
            tables.append(table_data)

        return {
            "text": "\n".join(text_content),
            "tables": tables,
            "metadata": {"author": doc.core_properties.author or "Unknown"}
        }

    async def _read_txt(self, file_content: bytes) -> Dict[str, Any]:
        """
        Read text files
        """
        text = file_content.decode('utf-8', errors='ignore')
        return {
            "text": text,
            "tables": [],
            "metadata": {}
        } 