from typing import Dict, List, Any, Optional
from openai import OpenAI
from dotenv import load_dotenv
import os
import json

load_dotenv()

class MaturityAssessmentService:
    def __init__(self):
        self.client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        self.model = "gpt-4-turbo-preview"

    async def assess_maturity(self, assessment_data: Dict[str, Any], domain: str) -> Dict[str, Any]:
        prompt = f"""
        Assess the maturity level of the following {domain} based on the provided data:
        
        {json.dumps(assessment_data, indent=2)}
        
        Please provide:
        1. Overall maturity score (1-5)
        2. Strengths identified
        3. Areas for improvement
        4. Recommendations for each maturity level
        5. Action plan for improvement
        """

        response = await self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": "You are a maturity assessment expert."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.3
        )

        return {
            "domain": domain,
            "assessment_data": assessment_data,
            "assessment_result": response.choices[0].message.content
        }

    async def generate_maturity_questionnaire(self, domain: str) -> Dict[str, Any]:
        prompt = f"""
        Generate a comprehensive maturity assessment questionnaire for {domain}.
        Include:
        1. Key assessment areas
        2. Specific questions for each area
        3. Scoring criteria
        4. Maturity level definitions
        5. Assessment guidelines
        """

        response = await self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": "You are a maturity assessment questionnaire expert."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.3
        )

        return {
            "domain": domain,
            "questionnaire": response.choices[0].message.content
        }

    async def compare_maturity_levels(self, current_state: Dict[str, Any], target_state: Dict[str, Any]) -> Dict[str, Any]:
        prompt = f"""
        Compare the current and target maturity levels:
        
        Current State:
        {json.dumps(current_state, indent=2)}
        
        Target State:
        {json.dumps(target_state, indent=2)}
        
        Please provide:
        1. Gap analysis
        2. Priority areas for improvement
        3. Implementation roadmap
        4. Risk assessment
        5. Success metrics
        """

        response = await self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": "You are a maturity level comparison expert."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.3
        )

        return {
            "current_state": current_state,
            "target_state": target_state,
            "comparison": response.choices[0].message.content
        }

    async def track_maturity_progress(self, historical_data: List[Dict[str, Any]]) -> Dict[str, Any]:
        prompt = f"""
        Analyze the maturity progress over time:
        
        {json.dumps(historical_data, indent=2)}
        
        Please provide:
        1. Progress trends
        2. Key milestones achieved
        3. Areas of stagnation
        4. Acceleration opportunities
        5. Future projections
        """

        response = await self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": "You are a maturity progress tracking expert."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.3
        )

        return {
            "historical_data": historical_data,
            "progress_analysis": response.choices[0].message.content
        } 