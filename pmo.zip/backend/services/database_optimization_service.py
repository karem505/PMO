from typing import Dict, List, Any
import asyncpg
from dotenv import load_dotenv
import os

load_dotenv()

class DatabaseOptimizationService:
    def __init__(self):
        self.connection_pool = None

    async def init_pool(self):
        if not self.connection_pool:
            self.connection_pool = await asyncpg.create_pool(
                dsn=os.getenv("DATABASE_URL"),
                min_size=1,
                max_size=10
            )

    async def analyze_query_performance(self, query: str) -> Dict[str, Any]:
        await self.init_pool()
        async with self.connection_pool.acquire() as conn:
            # Execute EXPLAIN ANALYZE
            plan = await conn.fetch(f"EXPLAIN ANALYZE {query}")
            return {
                "query": query,
                "execution_plan": [dict(row) for row in plan]
            }

    async def optimize_indexes(self, table_name: str) -> Dict[str, Any]:
        await self.init_pool()
        async with self.connection_pool.acquire() as conn:
            # Get current indexes
            indexes = await conn.fetch(f"""
                SELECT
                    schemaname,
                    tablename,
                    indexname,
                    indexdef
                FROM
                    pg_indexes
                WHERE
                    tablename = $1
            """, table_name)

            # Get table statistics
            stats = await conn.fetch(f"""
                SELECT
                    relname,
                    n_live_tup,
                    n_dead_tup,
                    last_vacuum,
                    last_analyze
                FROM
                    pg_stat_user_tables
                WHERE
                    relname = $1
            """, table_name)

            return {
                "table_name": table_name,
                "current_indexes": [dict(row) for row in indexes],
                "statistics": [dict(row) for row in stats]
            }

    async def vacuum_analyze(self, table_name: str) -> Dict[str, Any]:
        await self.init_pool()
        async with self.connection_pool.acquire() as conn:
            await conn.execute(f"VACUUM ANALYZE {table_name}")
            return {
                "table_name": table_name,
                "status": "VACUUM ANALYZE completed successfully"
            }

    async def get_slow_queries(self, threshold_ms: int = 1000) -> List[Dict[str, Any]]:
        await self.init_pool()
        async with self.connection_pool.acquire() as conn:
            slow_queries = await conn.fetch(f"""
                SELECT
                    query,
                    calls,
                    total_time,
                    mean_time,
                    rows
                FROM
                    pg_stat_statements
                WHERE
                    mean_time > $1
                ORDER BY
                    mean_time DESC
            """, threshold_ms)

            return [dict(row) for row in slow_queries] 