from typing import Dict, Optional
from supabase import Client
import uuid
from datetime import datetime
import time

class SubscriptionService:
    def __init__(self, supabase: Client):
        self.supabase = supabase
        # Ensure database is properly set up
        self.ensure_database_structure()

    def debug_user_lookup(self, email: str):
        """Debug user lookup by printing information about a specific email."""
        print(f"\n===== DEBUG USER LOOKUP FOR: {email} =====")
        
        # Try exact match search
        try:
            print(f"\nAttempting exact email lookup: {email}")
            response = self.supabase.from_("profiles").select("*").eq("email", email).execute()
            matches = response.data if response.data else []
            
            print(f"Found {len(matches)} exact matches:")
            for profile in matches:
                print(f"  - ID: {profile.get('id')}, Email: {profile.get('email')}")
                
                # Try to find subscription for this user
                try:
                    sub_response = self.supabase.from_("subscription_usage").select("*").eq("user_id", profile.get('id')).execute()
                    user_subs = sub_response.data if sub_response.data else []
                    
                    print(f"    Found {len(user_subs)} subscriptions for this user:")
                    for sub in user_subs:
                        print(f"    - Sub ID: {sub.get('id')}, Count: {sub.get('count')}")
                except Exception as e:
                    print(f"    Error finding subscriptions: {str(e)}")
        except Exception as e:
            print(f"Error in exact match search: {str(e)}")
        
        print("\n========================================")

    def get_user_by_email(self, email: str) -> Optional[Dict]:
        """Get user profile by email from Supabase."""
        try:
            # Debug lookup process (but only for the specific email)
            self.debug_user_lookup(email)
            
            # First try to get from profiles table
            print(f"\nFormal lookup for: {email}")
            response = self.supabase.from_("profiles").select("*").eq("email", email).execute()
            
            # Look at all returned rows
            all_rows = response.data if response.data else []
            print(f"Query returned {len(all_rows)} rows")
            
            # If we have at least one match, use the first one
            if all_rows and len(all_rows) > 0:
                print(f"Using first match: {all_rows[0]}")
                return all_rows[0]
            
            return None
        except Exception as e:
            print(f"Error fetching user by email: {str(e)}")
            return None

    def get_subscription_usage(self, user_id: str) -> Optional[Dict]:
        """Get user's subscription usage by user_id from Supabase."""
        try:
            print(f"Fetching subscription for user ID: {user_id}")
            response = self.supabase.from_("subscription_usage").select("*").eq("user_id", user_id).execute()
            
            # Look at all returned rows
            all_rows = response.data if response.data else []
            print(f"Query returned {len(all_rows)} rows for subscription")
            
            # If we have at least one match, use the first one
            if all_rows and len(all_rows) > 0:
                print(f"Using first subscription match: {all_rows[0]}")
                return all_rows[0]
            
            return None
        except Exception as e:
            print(f"Error fetching subscription: {str(e)}")
            return None

    def check_token_limit(self, email: str) -> bool:
        """
        Check if user has sufficient tokens (more than 13,000) 
        Returns True if sufficient tokens, False otherwise
        """
        # Get user profile
        user = self.get_user_by_email(email)
        if not user:
            print(f"No user found for email: {email}")
            return False
        
        # Get subscription usage
        subscription = self.get_subscription_usage(user.get("id"))
        if not subscription:
            print(f"No subscription found for user ID: {user.get('id')}")
            return False
        
        # Check if count is greater than 13,000
        tokens = subscription.get("count", 0)
        print(f"User has {tokens} tokens")
        return tokens >= 13000

    def update_token_usage(self, email: str, tokens_used: int) -> bool:
        """
        Update user's token usage by subtracting tokens_used from count
        Returns True if update successful, False otherwise
        """
        try:
            # Get user profile
            user = self.get_user_by_email(email)
            if not user:
                print(f"No user found for email: {email}")
                return False
            
            # Get subscription usage
            subscription = self.get_subscription_usage(user.get("id"))
            if not subscription:
                print(f"No subscription found for user ID: {user.get('id')}")
                return False
            
            # Calculate new count
            new_count = subscription.get("count", 0) - tokens_used
            if new_count < 0:
                new_count = 0
            
            print(f"Updating token usage. Old count: {subscription.get('count', 0)}, New count: {new_count}")
            
            # Update count in subscription_usage
            response = self.supabase.from_("subscription_usage").update({
                "count": new_count
            }).eq("user_id", user.get("id")).execute()
            
            return bool(response.data)
        except Exception as e:
            print(f"Error updating token usage: {str(e)}")
            return False

    def create_user_profile(self, email: str) -> Optional[Dict]:
        """Create a user profile in the database with retry logic."""
        max_retries = 3
        retry_delay = 1  # seconds
        
        for attempt in range(max_retries):
            try:
                # Check if user exists in auth system
                print(f"Looking up user in auth system for email {email} (attempt {attempt+1}/{max_retries})")
                
                # Get the list of all users and filter manually
                auth_response = None
                auth_user = None
                user_id = None
                
                try:
                    auth_response = self.supabase.auth.admin.list_users()
                    
                    # Manually filter the users by email
                    if auth_response and hasattr(auth_response, 'users'):
                        for user in auth_response.users:
                            if user.email == email:
                                auth_user = user
                                user_id = user.id
                                print(f"Found user in auth system with ID {user_id}")
                                break
                except Exception as auth_error:
                    print(f"Error accessing auth system: {auth_error}")
                    # We'll continue and retry if this fails
                
                if not auth_user:
                    print(f"User {email} not found in auth system on attempt {attempt+1}. Cannot create profile.")
                    if attempt < max_retries - 1:
                        print(f"Waiting {retry_delay} seconds before retry...")
                        time.sleep(retry_delay)
                        continue
                    
                # Check if profile already exists
                try:
                    existing_profile = self.supabase.from_("profiles").select("*").eq("email", email).execute()
                    if existing_profile.data and len(existing_profile.data) > 0:
                        print(f"Profile already exists for {email}, returning existing profile")
                        return existing_profile.data[0]
                except Exception as check_error:
                    print(f"Error checking existing profile: {check_error}")
                    # Continue attempting to create
                
                # Create profile for existing auth user
                user_profile = {
                    "id": user_id,
                    "email": email,
                    "display_name": email.split('@')[0],
                    "created_at": datetime.now().isoformat()
                }
                
                try:
                    response = self.supabase.from_("profiles").insert(user_profile).execute()
                    if response.data and len(response.data) > 0:
                        print(f"Created new profile for {email} with ID {user_id}")
                        
                        # Also create subscription usage
                        try:
                            self.create_subscription_usage(user_id)
                        except Exception as sub_error:
                            print(f"Warning: Failed to create subscription: {sub_error}")
                        
                        return response.data[0]
                    else:
                        print(f"Failed to create profile: {response}")
                        if attempt < max_retries - 1:
                            print(f"Waiting {retry_delay} seconds before retry...")
                            time.sleep(retry_delay)
                            continue
                except Exception as insert_error:
                    print(f"Error inserting profile: {insert_error}")
                    if attempt < max_retries - 1:
                        print(f"Waiting {retry_delay} seconds before retry...")
                        time.sleep(retry_delay)
                        continue
            except Exception as e:
                print(f"Error creating user profile on attempt {attempt+1}: {e}")
                if attempt < max_retries - 1:
                    print(f"Waiting {retry_delay} seconds before retry...")
                    time.sleep(retry_delay)
                    
        print("All profile creation attempts failed")
        return None

    def create_subscription_usage(self, user_id: str, initial_tokens: int = 81250) -> Optional[Dict]:
        """Create a subscription usage record for a user."""
        try:
            response = self.supabase.from_("subscription_usage").insert({
                "user_id": user_id,
                "count": initial_tokens,  # Start with default tokens
                "feature": "tokens"
            }).execute()
            
            if response.data and len(response.data) > 0:
                print(f"Created new subscription for user {user_id} with {initial_tokens} tokens")
                return response.data[0]
            return None
        except Exception as e:
            print(f"Error creating subscription: {str(e)}")
            return None

    def ensure_user_and_subscription(self, email: str) -> tuple[Optional[Dict], Optional[Dict]]:
        """Ensure a user and subscription exist, creating them if necessary."""
        # Try to get user
        user = self.get_user_by_email(email)
        if not user:
            print(f"No user profile found for {email}, attempting to create one")
            # Try to create a profile for an existing auth user
            user = self.create_user_profile(email)
            
            # If profile creation was successful, try to get it again to ensure everything is consistent
            if user:
                print(f"Successfully created profile for {email}, checking subscription")
                # Continue to subscription check below
            else:
                # If that fails (user not in auth system), create a temporary record
                print(f"User {email} not in auth system, creating temporary profile")
                try:
                    # Generate a valid UUID instead of a temp-prefix string
                    temp_id = str(uuid.uuid4())
                    
                    # Insert directly into subscription_usage with the temp ID
                    # This bypasses the profile->auth foreign key constraint
                    sub_response = self.supabase.from_("subscription_usage").insert({
                        "user_id": temp_id,
                        "email_reference": email,  # Store email reference
                        "count": 81250,
                        "feature": "tokens",
                        "is_temporary": True
                    }).execute()
                    
                    if sub_response.data and len(sub_response.data) > 0:
                        print(f"Created temporary subscription for {email}")
                        subscription = sub_response.data[0]
                        
                        # Create a synthetic user object
                        user = {
                            "id": temp_id,
                            "email": email,
                            "is_temporary": True
                        }
                        
                        return user, subscription
                except Exception as temp_error:
                    print(f"Error creating temporary subscription: {temp_error}")
                    return None, None
        
        # Try to get subscription for the user we found or created
        if user:
            user_id = user.get("id")
            subscription = self.get_subscription_usage(user_id)
            if not subscription:
                # Create subscription if not exists
                print(f"No subscription found for user {user_id}, creating one")
                subscription = self.create_subscription_usage(user_id)
            
            return user, subscription
        
        return None, None

    def ensure_database_structure(self):
        """Ensure the database has the necessary structure for subscriptions."""
        try:
            # Check if subscription_usage table exists and is accessible
            self.supabase.from_("subscription_usage").select("user_id").limit(1).execute()
            
            # Instead of using the query method (which doesn't exist), we'll use a workaround
            # by attempting to select data with the columns we need. If they don't exist,
            # we'll catch the exception and handle it specially
            try:
                # Try to select the columns - if this succeeds, they exist
                self.supabase.from_("subscription_usage").select("email_reference, is_temporary").limit(1).execute()
                print("Extra columns already exist in subscription_usage table")
            except Exception as column_error:
                print(f"Need to add columns: {column_error}")
                # Instead of using ALTER TABLE directly, create temporary records with the needed columns
                # This will create the columns if they don't exist
                try:
                    print("Adding email_reference and is_temporary columns to subscription_usage table")
                    # Use the rpc method to call a Postgres function that alters the table
                    # Note: This requires a Postgres function to be set up
                    # If that's not available, we can use a different approach
                    
                    # First, try inserting a temporary record with the new columns
                    # This will create the columns if they don't exist in some providers
                    temp_record = {
                        "user_id": str(uuid.uuid4()),  # Use a valid UUID instead of a temp- prefix
                        "count": 0,
                        "feature": "tokens",
                        "email_reference": "structure-check@example.com",
                        "is_temporary": True
                    }
                    
                    # Insert with 'upsert' functionality
                    self.supabase.from_("subscription_usage").upsert(temp_record).execute()
                    
                    # Then delete the temporary record
                    self.supabase.from_("subscription_usage").delete().eq("email_reference", "structure-check@example.com").execute()
                    
                    print("Added columns successfully via record insertion")
                except Exception as add_error:
                    print(f"Error adding columns via record: {add_error}")
                    # If that fails, suggest manual schema update
                    print("MANUAL ACTION REQUIRED: Please run the following SQL in your Supabase SQL editor:")
                    print("""
                        ALTER TABLE subscription_usage 
                        ADD COLUMN IF NOT EXISTS email_reference TEXT,
                        ADD COLUMN IF NOT EXISTS is_temporary BOOLEAN DEFAULT FALSE
                    """)
                    return False
            
            return True
        except Exception as e:
            print(f"Error ensuring database structure: {e}")
            return False

    def get_token_count(self, user_id: str) -> int:
        """Get the current token count for a user."""
        try:
            query = self.supabase.from_("subscription_usage").select("count").eq("user_id", user_id).eq("feature", "tokens")
            response = query.execute()
            
            if response.data and len(response.data) > 0:
                count = response.data[0].get("count", 0)
                return count
            return 0
        except Exception as e:
            print(f"Error getting token count: {e}")
            return 0

    def decrement_token(self, user_id: str, amount: int = 1) -> bool:
        """Decrement the user's token count by the specified amount."""
        try:
            # Get current count
            current_count = self.get_token_count(user_id)
            
            # If user has no tokens, don't try to decrement
            if current_count <= 0:
                return False
                
            # Calculate new count
            new_count = max(0, current_count - amount)
            
            # Update the counter
            query = self.supabase.from_("subscription_usage").update({"count": new_count}).eq("user_id", user_id).eq("feature", "tokens")
            response = query.execute()
            
            return response.data is not None and len(response.data) > 0
        except Exception as e:
            print(f"Error decrementing token: {e}")
            return False

    def update_token_count(self, user_id: str, token_delta: int) -> bool:
        """
        Update the user's token count by adding or subtracting the specified amount.
        Positive values add tokens, negative values remove tokens.
        """
        try:
            # Get current count
            current_count = self.get_token_count(user_id)
            
            # Calculate new count - don't go below zero
            new_count = max(0, current_count + token_delta)
            
            # Update the counter
            query = self.supabase.from_("subscription_usage").update({"count": new_count}).eq("user_id", user_id).eq("feature", "tokens")
            response = query.execute()
            
            return response.data is not None and len(response.data) > 0
        except Exception as e:
            print(f"Error updating token count: {e}")
            return False 