from langchain_community.tools import DuckDuckGoSearchRun
from langchain.agents import Tool
from langchain_openai import ChatOpenAI
from langchain.prompts import PromptTemplate
from langchain_community.document_loaders import PyPDFLoader, Docx2txtLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_core.runnables import RunnableSequence
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
import os
from dotenv import load_dotenv
from typing import List, Dict, Tuple
import glob
from datetime import datetime
import json
from .debug_logger import DebugLogger

# Load environment variables
load_dotenv()

# Validate OpenAI API key
openai_api_key = os.getenv("OPENAI_API_KEY")
if not openai_api_key:
    raise ValueError("OPENAI_API_KEY not found in environment variables")
if not openai_api_key.startswith("sk-"):
    raise ValueError("Invalid OpenAI API key format")

class OutputFormatter:
    def __init__(self, save_to_file: bool = True):
        self.save_to_file = save_to_file
        self.results_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "results")
        os.makedirs(self.results_dir, exist_ok=True)
        self.consolidated_results = []
        self.has_saved = False
        
    def format_output(self, query: str, response: str, thought_process: List[str], 
                     agent_workflow: Dict, agent_reasoning: Dict, 
                     intermediate_results: Dict, debug_logs: List[str]) -> str:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Create a summary of the results
        summary = f"""
Query: {query}
Timestamp: {timestamp}

Summary:
{self._summarize_response(response)}

Key Findings:
{self._extract_key_findings(response)}
"""
        
        # Add to consolidated results
        self.consolidated_results.append({
            "timestamp": timestamp,
            "query": query,
            "summary": self._summarize_response(response),
            "key_findings": self._extract_key_findings(response)
        })
        
        if self.save_to_file and not self.has_saved:
            self.save_consolidated_results()
            self.has_saved = True
            
        return summary
    
    def _summarize_response(self, response: str) -> str:
        """Summarize the response into small paragraphs."""
        # Split response into sentences
        sentences = response.split('. ')
        paragraphs = []
        current_paragraph = []
        
        for sentence in sentences:
            current_paragraph.append(sentence)
            if len(current_paragraph) >= 3:  # Create paragraphs of 3 sentences
                paragraphs.append(' '.join(current_paragraph) + '.')
                current_paragraph = []
        
        if current_paragraph:
            paragraphs.append(' '.join(current_paragraph) + '.')
            
        return '\n\n'.join(paragraphs)
    
    def _extract_key_findings(self, text: str) -> str:
        """Extract key findings from the response."""
        # Simple implementation - can be enhanced with NLP
        sentences = text.split('. ')
        key_findings = []
        for sentence in sentences:
            if any(word in sentence.lower() for word in ['important', 'key', 'critical', 'essential', 'major']):
                key_findings.append(sentence.strip() + '.')
        return '\n'.join(key_findings[:5])  # Return top 5 key findings
    
    def save_consolidated_results(self):
        """Save all results to a single consolidated file."""
        consolidated_file = os.path.join(self.results_dir, "crawler_results.json")
        
        with open(consolidated_file, "w", encoding="utf-8") as f:
            json.dump(self.consolidated_results, f, indent=2)
        print(f"\nAll results saved to: {consolidated_file}")

class DocumentProcessor:
    def __init__(self):
        self.embeddings = OpenAIEmbeddings(openai_api_key=openai_api_key)
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=200
        )
        self.documents_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "documents")
        self.vector_store = None

    def load_documents(self) -> List[Dict]:
        """Load all documents from the documents directory."""
        documents = []
        
        # Load PDF files
        pdf_files = glob.glob(os.path.join(self.documents_dir, "*.pdf"))
        for pdf_file in pdf_files:
            loader = PyPDFLoader(pdf_file)
            documents.extend(loader.load())
        
        # Load DOCX files
        docx_files = glob.glob(os.path.join(self.documents_dir, "*.docx"))
        for docx_file in docx_files:
            loader = Docx2txtLoader(docx_file)
            documents.extend(loader.load())
        
        return documents

    def process_documents(self):
        """Process documents and create vector store."""
        # Load documents
        documents = self.load_documents()
        
        # Split documents into chunks
        texts = self.text_splitter.split_documents(documents)
        
        # Create vector store
        self.vector_store = FAISS.from_documents(texts, self.embeddings)

    def search_documents(self, query: str, k: int = 3) -> Tuple[List[str], Dict]:
        """Search documents using similarity search."""
        if self.vector_store is None:
            self.process_documents()
        
        docs = self.vector_store.similarity_search(query, k=k)
        metadata = {
            "total_documents": len(docs),
            "average_length": sum(len(doc.page_content.split()) for doc in docs) / len(docs) if docs else 0,
            "source_types": list(set(doc.metadata.get('source', 'unknown') for doc in docs))
        }
        return [doc.page_content for doc in docs], metadata

class RAGSystem:
    def __init__(self, save_to_file: bool = True):
        # Initialize debug logger
        self.debug_logger = DebugLogger()
        
        # Initialize output formatter
        self.formatter = OutputFormatter(save_to_file)
        
        # Initialize components
        self.doc_processor = DocumentProcessor()
        self.web_searcher = DuckDuckGoSearchRun(
            max_results=5,  # Limit results to reduce likelihood of rate limiting
        )
        
        # Initialize LLM
        self.llm = ChatOpenAI(
            temperature=0,
            openai_api_key=openai_api_key
        )
        
        # Log initialization
        self.debug_logger.add_section("System Initialization")
        self.debug_logger.add_step("Components", "Initialized RAG System components")
        
        # Define the research agent prompt
        research_prompt = ChatPromptTemplate.from_messages([
            ("system", """You are a research agent specializing in PMO and project management.
            Your task is to analyze information from web searches and internal documents.
            
            For each query:
            1. Identify key concepts and requirements
            2. Search relevant sources
            3. Extract essential information
            4. Note any information gaps
            
            Format your response as:
            Key Concepts: [list of main topics]
            Essential Information: [key findings]
            Information Gaps: [missing details]
            Next Steps: [suggested actions]"""),
            ("human", "{query}")
        ])
        
        # Log prompts
        self.debug_logger.add_subsection("Research Prompt")
        self.debug_logger.add_code_block(str(research_prompt))
        
        # Define the synthesis agent prompt
        synthesis_prompt = ChatPromptTemplate.from_messages([
            ("system", """You are a synthesis agent for PMO analysis.
            Your task is to combine research findings into actionable insights.
            
            For each analysis:
            1. Identify patterns and connections
            2. Prioritize key findings
            3. Structure recommendations
            4. Highlight implementation considerations
            
            Format your response as:
            Analysis Summary: [main findings]
            Key Patterns: [identified patterns]
            Recommendations: [actionable steps]
            Implementation Notes: [practical considerations]"""),
            ("human", """Query: {query}
            
            Research Findings:
            {research_findings}
            
            Please provide a structured analysis.""")
        ])
        
        # Create the research chain
        self.research_chain = RunnableSequence(
            research_prompt | self.llm | StrOutputParser()
        )
        
        # Create the synthesis chain
        self.synthesis_chain = RunnableSequence(
            synthesis_prompt | self.llm | StrOutputParser()
        )

    def perform_web_search(self, query: str) -> str:
        """Execute a web search with rate limit handling and retries."""
        import time
        max_retries = 3
        retry_delay = 5  # seconds
        
        for attempt in range(max_retries):
            try:
                # Clean and format query
                clean_query = " ".join(query.split())
                if len(clean_query) > 250:
                    clean_query = clean_query[:250]
                    
                self.debug_logger.add_step("Web Search", f"Attempt {attempt + 1}: Searching for '{clean_query}'")
                
                # Use invoke instead of run
                results = self.web_searcher.invoke(clean_query)
                
                if results:
                    self.debug_logger.add_step("Web Search", f"Success - Found {len(str(results))} chars")
                    return results
                else:
                    self.debug_logger.add_step("Web Search", "No results found")
                    
            except Exception as e:
                error_msg = str(e).lower()
                self.debug_logger.log_error(e, f"Web search attempt {attempt + 1} failed")
                
                # Check if it's a rate limit error
                if "ratelimit" in error_msg:
                    if attempt < max_retries - 1:  # If we have more retries left
                        wait_time = retry_delay * (attempt + 1)  # Exponential backoff
                        self.debug_logger.add_step("Web Search", f"Rate limit hit. Waiting {wait_time} seconds...")
                        time.sleep(wait_time)
                        continue
                else:
                    # If it's not a rate limit error, log and continue
                    self.debug_logger.add_step("Web Search", f"Error: {str(e)}")
                    
            if attempt == max_retries - 1:
                # If all retries failed, try synthetic content generation
                self.debug_logger.add_step("Web Search", "All retries failed. Using synthetic content.")
                return self.generate_synthetic_content(query)
                
        return ""

    def generate_synthetic_content(self, query: str) -> str:
        """Generate synthetic content when web search fails."""
        try:
            # Create a prompt for synthetic content
            synthetic_prompt = ChatPromptTemplate.from_messages([
                ("system", """You are a knowledgeable assistant providing factual information.
                Generate a comprehensive response about the following topic.
                Include relevant facts, examples, and context.
                Format as a natural web search result would appear."""),
                ("human", "{query}")
            ])
            
            # Use the existing LLM to generate content
            chain = synthetic_prompt | self.llm | StrOutputParser()
            content = chain.invoke({"query": query})
            
            self.debug_logger.add_step("Synthetic Content", "Successfully generated fallback content")
            return content
            
        except Exception as e:
            self.debug_logger.log_error(e, "Error generating synthetic content")
            return "Unable to retrieve or generate content at this time."

    def parse_agent_reasoning(self, response: str) -> List[Tuple[str, str, str]]:
        """Parse the agent's reasoning from its response."""
        reasoning = []
        sections = response.split('\n\n')
        
        for section in sections:
            if section.startswith('Key Concepts:'):
                reasoning.append(('Analysis', 'Identify Concepts', section[13:].strip()))
            elif section.startswith('Essential Information:'):
                reasoning.append(('Analysis', 'Extract Information', section[21:].strip()))
            elif section.startswith('Information Gaps:'):
                reasoning.append(('Analysis', 'Identify Gaps', section[16:].strip()))
            elif section.startswith('Next Steps:'):
                reasoning.append(('Analysis', 'Plan Next Steps', section[11:].strip()))
            elif section.startswith('Analysis Summary:'):
                reasoning.append(('Synthesis', 'Summarize Findings', section[17:].strip()))
            elif section.startswith('Key Patterns:'):
                reasoning.append(('Synthesis', 'Identify Patterns', section[13:].strip()))
            elif section.startswith('Recommendations:'):
                reasoning.append(('Synthesis', 'Generate Recommendations', section[16:].strip()))
            elif section.startswith('Implementation Notes:'):
                reasoning.append(('Synthesis', 'Plan Implementation', section[20:].strip()))
        
        return reasoning

    def process_query(self, query: str) -> Tuple[str, List[str], Dict, Dict, Dict, List[str]]:
        """Process a query using the integrated RAG system."""
        self.debug_logger.add_section("Query Processing")
        self.debug_logger.add_step("Input Query", query)
        
        thought_process = []
        agent_workflow = {
            "Document Search Agent": [],
            "Web Search Agent": [],
            "Research Agent": [],
            "Synthesis Agent": []
        }
        agent_reasoning = {
            "Document Search Agent": [],
            "Web Search Agent": [],
            "Research Agent": [],
            "Synthesis Agent": []
        }
        intermediate_results = {
            1: {},  # Step 1 results
            2: {},  # Step 2 results
            3: {},  # Step 3 results
            4: {}   # Step 4 results
        }
        debug_logs = []
        
        try:
            # Step 1: Document Search
            self.debug_logger.add_subsection("Document Search")
            thought_process.append("Searching internal documents...")
            doc_results, doc_metadata = self.doc_processor.search_documents(query)
            self.debug_logger.add_dict_to_doc(doc_metadata, "Document Search Metadata")
            
            # Step 2: Web Search
            self.debug_logger.add_subsection("Web Search")
            thought_process.append("Searching web sources...")
            web_results = self.perform_web_search(query)
            self.debug_logger.add_step("Web Search Results", web_results[:500] + "..." if len(web_results) > 500 else web_results)
            
            # Step 3: Research Analysis
            self.debug_logger.add_subsection("Research Analysis")
            thought_process.append("Analyzing research findings...")
            research_input = {
                "query": query,
                "doc_results": "\n".join(doc_results),
                "web_results": web_results
            }
            self.debug_logger.add_dict_to_doc(research_input, "Research Input")
            
            research_findings = self.research_chain.invoke(research_input)
            self.debug_logger.add_step("Research Findings", research_findings)
            
            # Step 4: Synthesis
            self.debug_logger.add_subsection("Synthesis")
            thought_process.append("Synthesizing information...")
            synthesis_input = {
                "query": query,
                "research_findings": research_findings
            }
            self.debug_logger.add_dict_to_doc(synthesis_input, "Synthesis Input")
            
            final_response = self.synthesis_chain.invoke(synthesis_input)
            self.debug_logger.add_step("Final Response", final_response)
            
            # Log the complete workflow
            self.debug_logger.log_stage_processing(
                "Complete Workflow",
                {"thought_process": thought_process, "agent_workflow": agent_workflow},
                {"agent_reasoning": agent_reasoning, "intermediate_results": intermediate_results}
            )
            
            return final_response, thought_process, agent_workflow, agent_reasoning, intermediate_results, debug_logs
            
        except Exception as e:
            self.debug_logger.log_error(e, "Error during query processing")
            raise

    def search(self, query: str) -> str:
        """Main search method that coordinates the RAG process."""
        try:
            response, thought_process, agent_workflow, agent_reasoning, intermediate_results, debug_logs = self.process_query(query)
            
            # Log the complete search process
            self.debug_logger.log_web_crawling(query, {
                "thought_process": thought_process,
                "agent_workflow": agent_workflow,
                "agent_reasoning": agent_reasoning,
                "intermediate_results": intermediate_results
            })
            
            formatted_output = self.formatter.format_output(
                query, response, thought_process, agent_workflow, 
                agent_reasoning, intermediate_results, debug_logs
            )
            
            return formatted_output
            
        except Exception as e:
            if hasattr(self, 'debug_logger'):
                self.debug_logger.log_error(e, "Error during search process")
            raise

# Example usage
if __name__ == "__main__":
    try:
        print("\nInitializing RAG System...")
        rag_system = RAGSystem(save_to_file=True)
        
        # Example query
        query = "what is ai?"
        
        print("\nProcessing query...")
        result = rag_system.search(query)
        print(result)
        
    except Exception as e:
        print(f"Error: {str(e)}")