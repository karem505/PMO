from typing import Dict, List, Any
import PyPDF2
import docx
import json
import os
from pathlib import Path
import asyncio
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

class DocumentProcessingService:
    def __init__(self):
        self.openai_client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

    async def extract_text_from_pdf(self, file_path: str) -> str:
        text = ""
        with open(file_path, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            for page in pdf_reader.pages:
                text += page.extract_text()
        return text

    async def extract_text_from_docx(self, file_path: str) -> str:
        doc = docx.Document(file_path)
        return "\n".join([paragraph.text for paragraph in doc.paragraphs])

    async def process_document(self, file_path: str) -> Dict[str, Any]:
        file_extension = Path(file_path).suffix.lower()
        
        if file_extension == '.pdf':
            text = await self.extract_text_from_pdf(file_path)
        elif file_extension == '.docx':
            text = await self.extract_text_from_docx(file_path)
        else:
            raise ValueError(f"Unsupported file type: {file_extension}")

        # Use OpenAI to analyze the document
        analysis = await self.analyze_document(text)
        
        return {
            "file_path": file_path,
            "text": text,
            "analysis": analysis
        }

    async def analyze_document(self, text: str) -> Dict[str, Any]:
        prompt = f"""
        Analyze the following document text and provide:
        1. Key points and main topics
        2. Important dates and deadlines
        3. Action items or tasks
        4. Potential risks or concerns
        
        Document text:
        {text}
        """

        response = await self.openai_client.chat.completions.create(
            model="gpt-4-turbo-preview",
            messages=[
                {"role": "system", "content": "You are a document analysis assistant."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7
        )

        return {
            "analysis": response.choices[0].message.content
        }

    async def extract_metadata(self, file_path: str) -> Dict[str, Any]:
        file_info = Path(file_path)
        return {
            "file_name": file_info.name,
            "file_size": file_info.stat().st_size,
            "created_at": file_info.stat().st_ctime,
            "modified_at": file_info.stat().st_mtime,
            "file_type": file_info.suffix
        } 