from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from datetime import datetime
import os
import json
from typing import Dict, List, Any, Optional
from rich.console import Console
from rich.panel import Panel

console = Console()

class DebugLogger:
    _instance = None
    _initialized = False
    _saved = False

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(DebugLogger, cls).__new__(cls)
        return cls._instance

    def __init__(self):
        if not self._initialized:
            self.doc = Document()
            self.current_time = datetime.now().strftime("%Y%m%d_%H%M%S")
            self.debug_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "debug_logs")
            os.makedirs(self.debug_dir, exist_ok=True)
            self.filepath = os.path.join(self.debug_dir, f"unified_debug_log_{self.current_time}.docx")
            self._setup_document()
            self._initialized = True
            self._saved = False
            self.logs = []
            self.current_section = None
            self.current_subsection = None
        
    def _setup_document(self):
        """Initialize document with title and sections"""
        # Add title
        title = self.doc.add_heading('Unified Debug Log - PMO System', 0)
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        # Add timestamp
        timestamp_para = self.doc.add_paragraph()
        timestamp_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        timestamp_para.add_run(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        self.doc.add_paragraph()  # Add spacing
        
    def add_section(self, section_name: str):
        """Add a new section to the logs."""
        self.current_section = section_name
        self.current_subsection = None
        self.logs.append({
            "type": "section",
            "name": section_name,
            "timestamp": datetime.now().isoformat()
        })
        
    def add_subsection(self, subsection_name: str):
        """Add a new subsection to the current section."""
        self.current_subsection = subsection_name
        self.logs.append({
            "type": "subsection",
            "name": subsection_name,
            "section": self.current_section,
            "timestamp": datetime.now().isoformat()
        })
        
    def add_step(self, step_name: str, content: str):
        """Add a step to the current section/subsection."""
        self.logs.append({
            "type": "step",
            "name": step_name,
            "content": content,
            "section": self.current_section,
            "subsection": self.current_subsection,
            "timestamp": datetime.now().isoformat()
        })
        
    def add_code_block(self, code: str):
        """Add a code block to the current section/subsection."""
        self.logs.append({
            "type": "code",
            "content": code,
            "section": self.current_section,
            "subsection": self.current_subsection,
            "timestamp": datetime.now().isoformat()
        })
        
    def add_dict_to_doc(self, data: Dict[str, Any], title: str):
        """Add a dictionary to the documentation."""
        self.logs.append({
            "type": "dict",
            "title": title,
            "content": data,
            "section": self.current_section,
            "subsection": self.current_subsection,
            "timestamp": datetime.now().isoformat()
        })
        
    def log_error(self, error: Exception, context: str):
        """Log an error with context."""
        self.logs.append({
            "type": "error",
            "error": str(error),
            "context": context,
            "section": self.current_section,
            "subsection": self.current_subsection,
            "timestamp": datetime.now().isoformat()
        })
        
    def log_stage_processing(self, stage: str, workflow: Dict[str, Any], results: Dict[str, Any]):
        """Log stage processing information."""
        self.logs.append({
            "type": "stage_processing",
            "stage": stage,
            "workflow": workflow,
            "results": results,
            "timestamp": datetime.now().isoformat()
        })
        
    def log_web_crawling(self, query: str, results: Dict[str, Any]):
        """Log web crawling results."""
        self.logs.append({
            "type": "web_crawling",
            "query": query,
            "results": results,
            "timestamp": datetime.now().isoformat()
        })
        
    def save_logs(self, output_dir: str):
        """Save logs to a file."""
        try:
            os.makedirs(output_dir, exist_ok=True)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            log_file = os.path.join(output_dir, f"debug_logs_{timestamp}.json")
            
            with open(log_file, 'w') as f:
                json.dump(self.logs, f, indent=2)
                
            console.print(f"[bold green]Debug logs saved to:[/bold green] {log_file}")
        except Exception as e:
            console.print(f"[bold red]Error saving debug logs:[/bold red] {str(e)}")

    def save(self):
        """Save the debug document if not already saved"""
        if not self._saved:
            self.doc.save(self.filepath)
            self._saved = True
        return self.filepath

    def get_current_filepath(self):
        """Get the current debug log filepath"""
        return self.filepath

# Example usage
if __name__ == "__main__":
    logger = DebugLogger()
    
    # Example logging
    logger.add_section("Test Section")
    logger.add_step("Step 1", "This is a test step")
    logger.add_code_block("print('Hello World')")
    
    test_dict = {
        "key1": "value1",
        "key2": ["item1", "item2"],
        "key3": {"subkey1": "subvalue1"}
    }
    logger.add_dict_to_doc(test_dict, "Test Dictionary")
    
    filepath = logger.save()
    print(f"Debug log saved to: {filepath}") 