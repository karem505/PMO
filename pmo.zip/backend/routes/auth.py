from fastapi import APIRouter, HTTPException, Header
from typing import Optional
from pydantic import BaseModel
from supabase import create_client, Client
import os
from datetime import datetime, timedelta
from ..auth import verify_supabase_token

router = APIRouter()

# Initialize Supabase client
supabase: Client = create_client(
    os.getenv("SUPABASE_URL", ""),
    os.getenv("SUPABASE_SERVICE_KEY", "")
)

class UserSetupRequest(BaseModel):
    user_id: str
    email: str
    display_name: Optional[str] = None
    photo_url: Optional[str] = None
    team_code: Optional[str] = None

@router.post("/setup-user")
async def setup_user(
    request: UserSetupRequest,
    authorization: Optional[str] = Header(None)
):
    """
    Handle complete user setup including:
    - Profile creation
    - Default project creation
    - Free subscription setup
    - Team assignment (if team code provided)
    """
    try:
        # Verify the token matches the user_id
        if not authorization:
            raise HTTPException(status_code=401, detail="No authorization token provided")
            
        try:
            token = authorization.split(' ')[1]  # Remove 'Bearer ' prefix
            user_data = verify_supabase_token(token)
            
            if user_data['id'] != request.user_id:
                raise HTTPException(status_code=403, detail="User ID mismatch")
                
        except ValueError as e:
            raise HTTPException(status_code=401, detail=str(e))
        except Exception as e:
            raise HTTPException(status_code=401, detail="Invalid authorization token")

        print(f"Token verified for user {request.user_id}")

        # First check if profile already exists
        existing_profile = await supabase.table("profiles").select("*").eq("id", request.user_id).single().execute()
        
        if existing_profile.data:
            print(f"Profile already exists for user {request.user_id}")
            return {"status": "success", "message": "Profile already exists"}

        print(f"Creating new profile for user {request.user_id}")
        
        # Create profile
        profile_data = {
            "id": request.user_id,
            "email": request.email,
            "display_name": request.display_name or request.email.split('@')[0],
            "photo_url": request.photo_url,
            "created_at": datetime.utcnow().isoformat(),
            "organization_name": "",
            "industry": "",
            "pmo_maturity_level": "Initial"
        }
        
        profile_result = await supabase.table("profiles").insert(profile_data).execute()
        
        if not profile_result.data:
            print(f"Failed to create profile: {profile_result.error}")
            raise HTTPException(status_code=400, detail=f"Failed to create profile: {profile_result.error}")

        print(f"Profile created successfully")

        # Create default project
        project_data = {
            "name": "PMO Implementation & Digital Transformation",
            "description": """Launch a comprehensive PMO transformation initiative to enhance project delivery capabilities and drive digital innovation.

Key Focus Areas:
• Establish PMO governance framework and best practices
• Implement project portfolio management system
• Develop resource capacity planning model
• Create standardized project templates and tools
• Build team capabilities through training and mentoring
• Enable digital project delivery and reporting

Expected Outcomes:
✓ Improved project success rates
✓ Enhanced resource utilization
✓ Better stakeholder alignment
✓ Data-driven decision making
✓ Streamlined project processes""",
            "budget": 75000,
            "owner_id": request.user_id,
            "start_date": datetime.utcnow().isoformat(),
            "end_date": (datetime.utcnow() + timedelta(days=365)).isoformat(),  # 1 year project
            "key_objectives": [
                "Establish robust PMO governance framework and methodologies",
                "Implement digital project portfolio management system",
                "Develop resource capacity planning and optimization model",
                "Create standardized project templates and delivery tools",
                "Build team capabilities through training programs",
                "Enable data-driven decision making and reporting"
            ],
            "stakeholders": [
                {"name": "Executive Leadership", "role": "Project Sponsor"},
                {"name": "Project Managers", "role": "Key Users"},
                {"name": "Department Heads", "role": "Process Owners"},
                {"name": "Team Members", "role": "Contributors"},
                {"name": "IT Department", "role": "Technical Support"}
            ],
            "risks": [
                {
                    "description": "Organizational resistance to change",
                    "severity": "High",
                    "mitigation": "Comprehensive change management and stakeholder engagement plan"
                },
                {
                    "description": "Resource availability constraints",
                    "severity": "Medium",
                    "mitigation": "Phased implementation approach and resource optimization"
                },
                {
                    "description": "Technology adoption challenges",
                    "severity": "Medium",
                    "mitigation": "User-friendly tools selection and targeted training programs"
                }
            ],
            "milestones": [
                {
                    "name": "PMO Framework Design",
                    "due_date": (datetime.utcnow() + timedelta(days=60)).isoformat()
                },
                {
                    "name": "Tools Implementation",
                    "due_date": (datetime.utcnow() + timedelta(days=150)).isoformat()
                },
                {
                    "name": "Team Training Complete",
                    "due_date": (datetime.utcnow() + timedelta(days=240)).isoformat()
                },
                {
                    "name": "Digital Transformation",
                    "due_date": (datetime.utcnow() + timedelta(days=330)).isoformat()
                }
            ]
        }
        
        project_result = await supabase.table("projects").insert(project_data).execute()
        
        if not project_result.data:
            print(f"Failed to create project: {project_result.error}")
            raise HTTPException(status_code=400, detail="Failed to create default project")

        print(f"Project created successfully")

        # Set up free subscription
        subscription_data = {
            "user_id": request.user_id,
            "tier": "free",
            "status": "active",
            "start_date": datetime.utcnow().isoformat()
        }
        
        subscription_result = await supabase.table("subscriptions").insert(subscription_data).execute()
        
        if not subscription_result.data:
            print(f"Failed to create subscription: {subscription_result.error}")

        # Handle team assignment if team code provided
        if request.team_code:
            team_data = {
                "user_id": request.user_id,
                "team_code": request.team_code,
                "status": "pending"
            }
            await supabase.table("team_invitations").insert(team_data).execute()

        return {"status": "success", "message": "User setup completed successfully"}

    except HTTPException:
        raise
    except Exception as e:
        print(f"Error in setup_user: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/validate-setup/{user_id}")
async def validate_setup(
    user_id: str,
    authorization: Optional[str] = Header(None)
):
    """
    Validate that a user has been properly set up
    """
    try:
        # Verify the token
        if authorization:
            try:
                token = authorization.split(' ')[1]
                user_data = verify_supabase_token(token)
                if user_data['id'] != user_id:
                    raise HTTPException(status_code=403, detail="User ID mismatch")
            except ValueError as e:
                raise HTTPException(status_code=401, detail=str(e))
            except Exception:
                raise HTTPException(status_code=401, detail="Invalid authorization token")

        # Check if user profile exists
        profile = await supabase.table("profiles").select("*").eq("id", user_id).single().execute()
        
        if not profile.data:
            return {"status": "incomplete", "missing": ["profile"]}
        
        # Check if user has a project
        project = await supabase.table("projects").select("id").eq("owner_id", user_id).limit(1).execute()
        
        # Check if user has an active subscription
        subscription = await supabase.table("subscriptions").select("id").eq("user_id", user_id).eq("status", "active").limit(1).execute()
        
        missing = []
        if not project.data:
            missing.append("project")
        if not subscription.data:
            missing.append("subscription")
            
        return {
            "status": "complete" if not missing else "incomplete",
            "missing": missing
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"Error in validate_setup: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e)) 