import sys
import os
import time
from rich.console import Console
from services.web_rag.web_search import SimpleWebSearcher
import unittest
from services.web_crawling_agentic_workflow import RAGSystem

console = Console()

def test_web_search():
    """
    Test simple web search with query generation
    """
    console.print("[bold blue]Testing simple web search...[/bold blue]")
    
    # Initialize searcher
    web_searcher = SimpleWebSearcher()
    
    # Test input
    user_input = """
    We need to implement a new project management methodology for our software development team.
    The team is currently using a mix of Agile and Waterfall approaches, but we want to standardize
    on a single methodology. We have 50 developers across 5 teams.
    """
    
    # First search
    console.print("\n[bold]First search:[/bold]")
    start_time = time.time()
    
    try:
        console.print("[yellow]Starting search...[/yellow]")
        results = web_searcher.search(user_input)
        duration = time.time() - start_time
        
        console.print(f"[green]Found {len(results)} results in {duration:.2f} seconds[/green]")
        
        if results:
            console.print("\n[bold]First result:[/bold]")
            console.print(results[0])
            
            console.print("\n[bold]Second result:[/bold]")
            console.print(results[1])
    except Exception as e:
        console.print(f"[red]Error during test: {str(e)}[/red]")

class TestWebSearch(unittest.TestCase):
    def setUp(self):
        self.rag_system = RAGSystem(save_to_file=False)
        
    def test_web_search_with_retry(self):
        """Test web search with rate limit handling"""
        # Test multiple queries with delay between them
        queries = [
            "what is project management",
            "agile methodology",
            "scrum framework"
        ]
        
        for query in queries:
            print(f"\nTesting query: {query}")
            result = self.rag_system.web_search(query)
            
            # Verify result
            self.assertIsInstance(result, str)
            self.assertTrue(len(result) > 0)
            print(f"Result length: {len(result)}")
            print(f"First 100 chars: {result[:100]}...")
            
            # Add delay between queries
            time.sleep(5)  # 5 second delay between queries
            
    def test_synthetic_content_generation(self):
        """Test synthetic content generation fallback"""
        result = self.rag_system.generate_synthetic_content("what is PMO")
        
        # Verify result
        self.assertIsInstance(result, str)
        self.assertTrue(len(result) > 0)
        print(f"\nSynthetic content length: {len(result)}")
        print(f"First 100 chars: {result[:100]}...")

if __name__ == "__main__":
    test_web_search()
    unittest.main() 