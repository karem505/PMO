from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer
from typing import Dict, Any
import jwt
from config.supabase import supabase

# JWT settings (should match main.py)
SECRET_KEY = "test-secret-key-for-development-only"  # Should be from environment in production
ALGORITHM = "HS256"

# Bearer token security
security = HTTPBearer(auto_error=False)  # Make token optional

async def get_current_user(token: str = Depends(security)) -> Dict[str, Any]:
    """Get the current authenticated user using JWT.
    
    Modified to bypass authentication and always return a default test user.
    """
    # Return a default test user without verifying the token
    return {"email": "test@example.com", "sub": "test-user-id"}

    # Original token verification (commented out)
    """
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    try:
        # Verify JWT token
        payload = jwt.decode(token.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        email: str = payload.get("email")
        if email is None:
            raise credentials_exception
            
        # You can look up the user in Supabase if needed
        # For now, just return the decoded payload
        return {"email": email, "sub": payload.get("sub")}
    except jwt.PyJWTError as e:
        print(f"JWT verification error: {str(e)}")
        raise credentials_exception 
    """

# If you're using supabase.auth.get_user and it's failing with async/await issues, 
# uncomment and update this code

# Example of using Supabase auth without await:
# def get_user_from_token(token: str):
#     """Get user from token without using await."""
#     try:
#         return supabase.auth.get_user(token)
#     except Exception as e:
#         print(f"Error getting user from token: {str(e)}")
#         return None 