import sys
import os
import traceback
from services.pmo_rag_system import synthesize_final_response, Task, CacheManager, DebugLogger
from rich.console import Console

console = Console()

def test_synthesis():
    """Test the fixed final synthesis function"""
    console.print("[bold green]Testing improved synthesize_final_response function...[/bold green]")
    
    # Create a simple task
    task = Task(
        title="Test Project Implementation",
        description="Implementing a new project management system",
        domain="Information Technology",
        stage="Planning",
        bestPractices=["Define clear objectives", "Establish communication plan"]
    )
    
    # Create a mock previous results dictionary
    previous_results = {
        "situation_analysis": "The organization needs to implement a new project management system to improve efficiency.",
        "best_practices": "Best practices include defining clear objectives and establishing a communication plan.",
        "recommendations": "We recommend implementing the XYZ system with proper training for all staff.",
        "implementation_plan": "Phase 1: Setup and configuration. Phase 2: Training. Phase 3: Deployment."
    }
    
    try:
        # Run the synthesis function
        console.print("[bold blue]Running synthesis...[/bold blue]")
        result = synthesize_final_response(previous_results, task)
        
        # Check if result was produced
        if result and len(result) > 100:
            console.print(f"[bold green]Success! Generated document with {len(result)} characters[/bold green]")
            console.print(f"[blue]First 200 characters:[/blue] {result[:200]}...")
            return True
        else:
            console.print("[bold red]Error: Generated document is too short or empty[/bold red]")
            return False
            
    except Exception as e:
        console.print(f"[bold red]Error in test: {str(e)}[/bold red]")
        traceback.print_exc()
        return False

if __name__ == "__main__":
    test_synthesis() 