from typing import Optional, List, Dict, Any
from datetime import datetime
from pydantic import BaseModel, Field
from uuid import UUID, uuid4

class ProcessedDocument(BaseModel):
    """Model for processed documents."""
    id: UUID = Field(default_factory=uuid4)
    title: str
    content: str
    metadata: Dict[str, Any]
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    status: str = "processed"

class DocumentChunk(BaseModel):
    """Model for document chunks."""
    id: UUID = Field(default_factory=uuid4)
    document_id: UUID
    content: str
    metadata: Dict[str, Any]
    embedding: List[float]
    chunk_index: int
    created_at: datetime = Field(default_factory=datetime.utcnow)

class DocumentIndex(BaseModel):
    """Model for document indices."""
    id: UUID = Field(default_factory=uuid4)
    document_id: UUID
    index_type: str
    index_data: Dict[str, Any]
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

class BestPracticeCategory(BaseModel):
    """Model for best practice categories."""
    id: UUID = Field(default_factory=uuid4)
    name: str
    description: Optional[str]
    created_at: datetime = Field(default_factory=datetime.utcnow)

class BestPracticeDocument(BaseModel):
    """Model for best practice documents."""
    id: UUID = Field(default_factory=uuid4)
    title: str
    content: str
    category_id: UUID
    metadata: Dict[str, Any]
    status: str = "active"
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

class BestPracticeTag(BaseModel):
    """Model for best practice tags."""
    id: UUID = Field(default_factory=uuid4)
    name: str
    created_at: datetime = Field(default_factory=datetime.utcnow)

class BestPracticeDocumentTag(BaseModel):
    """Model for document-tag relationships."""
    id: UUID = Field(default_factory=uuid4)
    document_id: UUID
    tag_id: UUID
    created_at: datetime = Field(default_factory=datetime.utcnow)

class DomainOutput(BaseModel):
    """Model for domain-specific outputs."""
    id: UUID = Field(default_factory=uuid4)
    domain: str
    output_type: str
    content: Dict[str, Any]
    metadata: Dict[str, Any]
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow) 