from pydantic import BaseModel
from typing import List, Optional

class CodeAnalysisRequest(BaseModel):
    code: str
    language: str

class MaturityAssessmentRequest(BaseModel):
    assessment_data: dict
    domain: str 