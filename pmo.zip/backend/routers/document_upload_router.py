from fastapi import APIRouter, HTTPException, Header, Depends, UploadFile, File, Form
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from services.document_utils import get_supabase_client
from config.supabase import supabase
import os
import uuid
import json
import hashlib
from datetime import datetime
from .auth import get_current_user

router = APIRouter(
    prefix="/documents",
    tags=["documents"],
    responses={404: {"description": "Not found"}},
)

class TaskResponse(BaseModel):
    task_id: str
    public_url: str
    message: str

# Helper function to extract user email
async def get_user_email(
    x_user_email: Optional[str] = Header(None),
    test_email: Optional[str] = None,
    current_user: Optional[Dict[str, Any]] = Depends(get_current_user)
) -> str:
    """
    Get user email from either:
    1. The X-User-Email header
    2. The test_email query parameter
    3. JWT token
    Priority is given in that order.
    """
    # For testing, if specific test email is provided, use it
    if test_email:
        return test_email
        
    if x_user_email:
        return x_user_email
    elif current_user and "email" in current_user:
        return current_user["email"]
    else:
        raise HTTPException(
            status_code=401,
            detail="User email not found. Please provide X-User-Email header or valid JWT token."
        )

@router.post("/upload", response_model=TaskResponse)
async def upload_document(
    file: UploadFile = File(None),
    project_id: str = Form(...),
    task_name: str = Form(...),
    notes: Optional[str] = Form(None),
    test_email: Optional[str] = None,
    user_email: str = Depends(get_user_email)
):
    """
    Upload a document and store data in the tasks table.
    
    Parameters:
    - file: The document file to upload
    - project_id: UUID of the project
    - task_name: Name of the task
    - notes: Optional notes about the task (can be null)
    
    The endpoint will:
    1. Upload the file to Supabase storage in the 'tasks-input' bucket
    2. Store task data in the 'tasks' table
    3. Return the task ID and public URL for the uploaded file
    """
    try:
        # Get the Supabase client
        supabase_client = get_supabase_client()
        if not supabase_client:
            raise HTTPException(
                status_code=500,
                detail="Failed to initialize Supabase client"
            )
            
        # Get user ID from profiles table
        user_id = None
        try:
            profile_response = supabase_client.from_("profiles").select("id").eq("email", user_email).execute()
            
            if profile_response.data and len(profile_response.data) > 0:
                user_id = profile_response.data[0]["id"]
                print(f"Found user ID {user_id} from profiles table for email {user_email}")
            else:
                raise HTTPException(
                    status_code=404,
                    detail=f"No profile found for email {user_email}"
                )
        except Exception as lookup_error:
            raise HTTPException(
                status_code=500,
                detail=f"Error looking up user profile: {str(lookup_error)}"
            )
            
        # Use task_name as task_id
        task_id = task_name
        
        # Prepare filename with user email and task ID for uniqueness
        email_username = user_email.split('@')[0]
        file_extension = os.path.splitext(file.filename)[1]
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        # Include task_id in the filename for organization without creating directories
        storage_filename = f"{task_id}_{email_username}_{timestamp}{file_extension}"
        
        # Upload file to Supabase storage - directly to bucket root
        file_content = await file.read()
        
        upload_response = supabase_client.storage.from_("tasks-input").upload(
            path=storage_filename,  # No directory structure, just the filename
            file=file_content,
            file_options={"content-type": file.content_type}
        )
        
        if not upload_response:
            raise HTTPException(
                status_code=500,
                detail="Failed to upload file to storage"
            )
            
        # Get public URL for the uploaded file
        public_url = supabase_client.storage.from_("tasks-input").get_public_url(storage_filename)
        
        # Insert record into tasks table
        task_data = {
            "project_id": project_id,
            "task_id": task_id,
            "task_name": task_name,
            "notes": notes if notes else None,  # Allow null values
            "attachments": [public_url],  # Store URL as array since it expects an array
            "updated_by": user_id,
            "best_practice": None,  # Always set to null for document upload
            "completed": True  # Set completed to true for document uploads
        }
        
        insert_response = supabase_client.table("tasks").insert(task_data).execute()
        
        if not insert_response:
            # If we fail to insert, try to delete the uploaded file
            try:
                supabase_client.storage.from_("tasks-input").remove([storage_filename])
            except:
                pass
                
            raise HTTPException(
                status_code=500,
                detail="Failed to insert task data"
            )
            
        return TaskResponse(
            task_id=task_id,
            public_url=public_url,
            message="Document uploaded successfully"
        )
        
    except HTTPException as he:
        raise he
    except Exception as e:
        print(f"Error in document upload: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Unexpected error: {str(e)}"
        )

@router.get("/check-completion/{project_id}/{task_id}", response_model=bool)
async def check_task_completion(
    project_id: str,
    task_id: str
):
    """
    Check if a task is completed based on project ID and task ID.
    Returns a boolean indicating if the task is completed.
    """
    try:
        supabase_client = get_supabase_client()
        if not supabase_client:
            raise HTTPException(status_code=500, detail="Failed to initialize Supabase client")
            
        # Query the tasks table for the specific task using task_id
        response = supabase_client.table("tasks").select("completed").eq("project_id", project_id).eq("task_id", task_id).execute()
        
        if not response.data:
            raise HTTPException(status_code=404, detail="Task not found")
            
        return response.data[0].get("completed", False)
        
    except Exception as e:
        print(f"Error checking task completion: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Unexpected error: {str(e)}")

@router.get("/completed-tasks/{project_id}/{task_id}", response_model=dict)
async def get_completed_tasks(
    project_id: str,
    task_id: str
):
    """
    Get completion status for a specific task in a project.
    Returns a dictionary containing:
    - completed: boolean indicating if the task is completed
    - exists: boolean indicating if the task exists in the database
    - message: optional status message
    """
    try:
        supabase_client = get_supabase_client()
        if not supabase_client:
            return {
                "completed": False,
                "exists": False,
                "message": "Database connection not available"
            }
            
        # Query the tasks table for the specific task
        response = supabase_client.table("tasks").select("completed").eq("project_id", project_id).eq("task_id", task_id).execute()
        
        if not response.data:
            return {
                "completed": False,
                "exists": False,
                "message": "Task not yet initialized"
            }
            
        # Return the completion status of the task
        return {
            "completed": response.data[0].get("completed", False),
            "exists": True,
            "message": "Task status retrieved successfully"
        }
        
    except Exception as e:
        print(f"Error getting task completion status: {str(e)}")
        return {
            "completed": False,
            "exists": False,
            "message": f"Error checking task status: {str(e)}"
        }