from fastapi import APIRouter, HTTPException, Header, Depends, BackgroundTasks
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import os
import json
import hashlib
from datetime import datetime, timedelta
import uuid
from .auth import get_current_user
import time
from fastapi import status, Request
import asyncio
from services.document_utils import save_project_to_supabase

# Initialize router
router = APIRouter(
    tags=["pmo"],
    responses={404: {"description": "Not found"}},
)

# Try importing optional dependencies
try:
    from services.pmo_rag_system import Task, get_pm_recommendations_multi_call, TokenManager, get_pm_recommendations_single_call
    from services.subscription import SubscriptionService
    from services.document_utils import save_to_supabase, get_supabase_client, get_project_document, format_project_document
    from config.supabase import supabase
    PMO_SERVICES_AVAILABLE = True
    print("Successfully imported PMO services")
except ImportError as e:
    print(f"Warning: Some PMO services are not available: {str(e)}")
    print("PMO functionality will be limited")
    PMO_SERVICES_AVAILABLE = False

# Initialize subscription service if available
subscription_service = None
if PMO_SERVICES_AVAILABLE:
    try:
        subscription_service = SubscriptionService(supabase)
        print("Subscription service initialized")
    except Exception as e:
        print(f"Error initializing subscription service: {str(e)}")

class TaskRequest(BaseModel):
    title: str
    description: str
    domain: str
    stage: str
    bestPractices: Optional[List[str]] = None
    user_input: str 
    project_id: Optional[str] = None
    task_id: Optional[str] = None
    user_id: Optional[str] = None

class TaskResponse(BaseModel):
    public_url: str
    task_hash: str
    usage: dict

class UserData(BaseModel):
    email: str

def generate_task_hash(task_request: TaskRequest) -> str:
    """Generate a unique hash for the task based on its content and timestamp."""
    # Combine all task data into a single string
    task_data = f"{task_request.title}{task_request.description}{task_request.domain}{task_request.stage}"
    task_data += f"{','.join(task_request.bestPractices or [])}{task_request.user_input}{datetime.now().isoformat()}"
    
    # Generate SHA-256 hash
    return hashlib.sha256(task_data.encode()).hexdigest()[:12]

# Helper function to extract user email
async def get_user_email(
    x_user_email: Optional[str] = Header(None),
    test_email: Optional[str] = None,
    current_user: Optional[Dict[str, Any]] = Depends(get_current_user)
) -> str:
    """
    Get user email from either:
    1. The X-User-Email header
    2. The test_email query parameter
    3. JWT token
    Priority is given in that order.
    """
    # Print all sources for debugging
    print(f"get_user_email called with x_user_email={x_user_email}, test_email={test_email}, current_user={current_user}")
    
    # Try X-User-Email header first
    if x_user_email:
        print(f"Using X-User-Email header: {x_user_email}")
        return x_user_email
        
    # Then try email from authenticated user
    if current_user and "email" in current_user:
        print(f"Using email from authenticated user: {current_user['email']}")
        return current_user["email"]
        
    # Try regular test_email param as fallback
    if test_email:
        print(f"Using test_email parameter: {test_email}")
        return test_email
        
    # If all else fails, raise an error
    print("No email found in headers, JWT, or parameters")
    raise HTTPException(
        status_code=401,
        detail="User email not found. Please provide X-User-Email header or valid JWT token."
    )

@router.post("/recommendations", response_model=TaskResponse)
async def get_task_recommendations(
    task_request: TaskRequest,
    test_email: Optional[str] = None,
    user_email: str = Depends(get_user_email),
    background_tasks: BackgroundTasks = None
):
    """
    Generate PMO recommendations based on task details and user input.
    
    For storing in the domain_outputs table:
    - project_id: The project identifier
    - domain_id: The domain from the task
    - content: The user input text
    - file_url: The public URL to the generated document
    - generated_date: Timestamp when the document was generated
    - updated_by: User ID from the profiles table (looked up using the authenticated email)
    
    Note: Data will only be stored in the domain_outputs table if the user ID can be found in the profiles table.
    The updated_by field cannot be NULL.
    
    Returns:
    - public_url: URL to access the generated document
    - task_hash: Unique identifier for the task
    - usage: Token usage statistics
    """
    try:
        print(f"Processing recommendation request for user: {user_email}")
        
        # Initialize token usage tracking for fallback cases
        default_token_usage = {
            "input_tokens": 1000,
            "output_tokens": 4000,
            "total_tokens": 5000
        }
        
        # Get a fresh Supabase client
        supabase_client = get_supabase_client()
        if not supabase_client:
            print("Failed to connect to database, proceeding with limited functionality")
            # We'll continue without database functionality
        
        # CRITICAL: Check token limit for the user first
        # This is prioritized as the most important check
        if PMO_SERVICES_AVAILABLE and subscription_service:
            try:
                # Ensure user exists in the system
                user, subscription = subscription_service.ensure_user_and_subscription(user_email)
                print(f"User lookup result for {user_email}: {user is not None}")
                print(f"Subscription lookup result: {subscription is not None}")
                
                if not subscription or subscription.get("count", 0) < 13000:
                    print(f"User {user_email} has insufficient tokens")
                    raise HTTPException(
                        status_code=403, 
                        detail="Insufficient tokens. Please upgrade your plan."
                    )
                print(f"Token check passed for user: {user_email}")
            except Exception as token_error:
                print(f"Error checking token limit: {token_error}")
                # Without confirmed token availability, we can't proceed
                # Return a clear error message to the user
                raise HTTPException(
                    status_code=500,
                    detail=f"Unable to verify token availability: {str(token_error)}"
                )
        else:
            print("Subscription service not available, proceeding without token check")

        # Get user ID from profiles table
        user_id = None
        if supabase_client:
            try:
                # Try to find the user profile
                profile_response = supabase_client.from_("profiles").select("id").eq("email", user_email).execute()
                
                # If user doesn't exist in profiles table, look them up in auth.users first
                if not profile_response.data or len(profile_response.data) == 0:
                    print(f"No profile found for email {user_email}, checking auth.users table")
                    
                    # First check if user_id was provided in the request
                    if task_request.user_id:
                        user_id = task_request.user_id
                        print(f"Using user_id from request: {user_id}")
                    else:
                        # Look up the user in auth.users table by email
                        auth_user = None
                        try:
                            # Try to query auth.users table directly (might not be allowed due to RLS)
                            auth_response = supabase_client.rpc(
                                "get_user_by_email", 
                                {"email_param": user_email}
                            ).execute()
                            if auth_response.data:
                                auth_user = auth_response.data
                                user_id = auth_user.get("id")
                                print(f"Found user {user_id} in auth.users table")
                        except Exception as auth_error:
                            print(f"Error querying auth.users: {auth_error}")
                            
                        if not user_id:
                            print(f"User {user_email} not found in auth.users, unable to look up user ID")
                            # Continue with processing without user ID
                            # The output document will still be generated but won't be saved to domain_outputs
                else:
                    user_id = profile_response.data[0]["id"]
                    print(f"Found user profile for {user_email}, user ID: {user_id}")
            except Exception as profile_error:
                print(f"Error looking up user profile: {profile_error}")
                # Continue without user ID
        
        # Generate unique hash for the task
        task_hash = generate_task_hash(task_request)
        
        # Set up basic task structure
        task = Task(
            title=task_request.title,
            description=task_request.description,
            domain=task_request.domain,
            stage=task_request.stage,
            bestPractices=task_request.bestPractices if task_request.bestPractices else []
        )

        # Extract user input
        user_input = task_request.user_input
        
        # Check for existing related documents or context
        related_urls = []
        context_data = []
        
        # If this is an existing task/project, get related data
        if task_request.project_id and supabase_client:
            try:
                print(f"Fetching related data for project: {task_request.project_id}")
                
                # Check for tasks related to this project
                tasks_response = supabase_client.from_("tasks").select("*").eq("project_id", task_request.project_id).execute()
                
                if tasks_response.data:
                    print(f"Found {len(tasks_response.data)} tasks")
                    for task_record in tasks_response.data:
                        # Process attachments
                        attachments = task_record.get("attachments")
                        if attachments:
                            if isinstance(attachments, list):
                                for attachment in attachments:
                                    if attachment:  # Skip null/empty values
                                        related_urls.append(attachment)
                                        print(f"Added attachment URL: {attachment}")
                            elif isinstance(attachments, str):  # Handle case where attachments is a string
                                related_urls.append(attachments)
                                print(f"Added attachment URL: {attachments}")
                        
                        # Process notes if available
                        notes = task_record.get("notes")
                        if notes and isinstance(notes, str):
                            print(f"Processing notes for task {task_record.get('task_id')}")
                            # Add notes to the context for processing
                            context_data.append({
                                "content": notes,
                                "type": "task_notes",
                                "task_id": task_record.get("task_id"),
                                "timestamp": task_record.get("updated_at")
                            })
                        
                        # Process custom fields if available
                        custom_fields = task_record.get("custom_fields")
                        if custom_fields:
                            if isinstance(custom_fields, str):
                                try:
                                    # Try to parse JSON string
                                    parsed_fields = json.loads(custom_fields)
                                    for field_name, field_value in parsed_fields.items():
                                        # Only process text fields
                                        if isinstance(field_value, str) and field_value.strip():
                                            context_data.append({
                                                "content": field_value,
                                                "type": "custom_field",
                                                "field_name": field_name,
                                                "task_id": task_record.get("task_id"),
                                                "timestamp": task_record.get("updated_at")
                                            })
                                except json.JSONDecodeError:
                                    print(f"Failed to parse custom fields JSON: {custom_fields}")
                            elif isinstance(custom_fields, dict):
                                for field_name, field_value in custom_fields.items():
                                    # Only process text fields
                                    if isinstance(field_value, str) and field_value.strip():
                                        context_data.append({
                                            "content": field_value,
                                            "type": "custom_field",
                                            "field_name": field_name,
                                            "task_id": task_record.get("task_id"),
                                            "timestamp": task_record.get("updated_at")
                                        })
                
                # Check for existing outputs from this domain
                domain_outputs = supabase_client.from_("domain_outputs").select("*").eq("project_id", task_request.project_id).eq("domain_id", task_request.domain).execute()
                
                if domain_outputs.data:
                    print(f"Found {len(domain_outputs.data)} domain outputs")
                    for output in domain_outputs.data:
                        if output.get("file_url"):
                            related_urls.append(output.get("file_url"))
                            print(f"Added domain output URL: {output.get('file_url')}")
                        
                        # Process content if available
                        content = output.get("content")
                        if content and isinstance(content, str) and content.strip():
                            context_data.append({
                                "content": content,
                                "type": "domain_output",
                                "domain_id": output.get("domain_id"),
                                "timestamp": output.get("generated_date")
                            })
                
            except Exception as related_data_error:
                print(f"Error fetching related data: {related_data_error}")
                # Continue without related data

        # Determine if we should use fast path (simplified processing)
        use_simplified_mode = False
        # Check if there are no task notes in the context data
        has_task_notes = any(item.get("type") == "task_notes" for item in context_data if item.get("content") and len(item.get("content", "").strip()) > 50)
        
        # Determine if we should use simplified mode when both attachments and task notes are missing
        if not related_urls and not has_task_notes:
            use_simplified_mode = True
            print("Using simplified recommendation path (no attachments and no substantial task notes)")
        else:
            if not related_urls:
                print("Using comprehensive path with detailed user input but no attachments")
            else:
                print(f"Using comprehensive path with {len(related_urls)} attachments")

        # Process the task
        if PMO_SERVICES_AVAILABLE:
            try:
                # Record start time for performance tracking
                start_time = time.time()
                
                # Process input based on determined mode
                if use_simplified_mode:
                    # SIMPLIFIED PATH: Generate condensed document (2-4 pages)
                    content, token_usage = get_pm_recommendations_single_call(
                        task_request.domain, 
                        user_input, 
                        task,
                        simplified=True
                    )
                else:
                    # COMPREHENSIVE PATH: Full multi-call processing with context integration
                    content, token_usage = get_pm_recommendations_multi_call(task_request.domain, user_input, task, related_urls)
                
                # Track processing time
                processing_time = time.time() - start_time
                print(f"Processing completed in {processing_time:.2f} seconds")
                
                # Prepare best practices summary for storage
                best_practices_text = ", ".join(task_request.bestPractices) if task_request.bestPractices else ""
                
                # Create directory structure for output if it doesn't exist
                output_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "outputs")
                os.makedirs(output_dir, exist_ok=True)
                
                # Save outputs with unique ID
                output_filename = f"pmo_recommendation_{task_hash}.md"
                output_path = os.path.join(output_dir, output_filename)
                
                with open(output_path, "w", encoding="utf-8") as f:
                    f.write(content)
                    
                print(f"Output saved to: {output_path}")
                
                # Save to Supabase storage if all requirements are met
                public_url = None
                user_context = {
                    "user_id": user_id,
                    "user_email": user_email
                }
                
                try:
                    # Enhanced error handling for storage operations
                    if supabase_client and user_id:
                        storage_start = time.time()
                        
                        # Get appropriate bucket based on environment
                        bucket_name = "output"  # Default bucket
                        
                        storage_result = save_to_supabase(
                            supabase_client, 
                            content, 
                            output_filename, 
                            bucket_name, 
                            task_request, 
                            user_context
                        )
                        
                        if storage_result and "public_url" in storage_result:
                            public_url = storage_result["public_url"]
                            print(f"Document stored in Supabase storage: {public_url}")
                            print(f"Storage operation completed in {time.time() - storage_start:.2f} seconds")
                        else:
                            print("Warning: Storage operation didn't return a public URL")
                            
                    elif not supabase_client:
                        print("Supabase client not available, skipping storage")
                    elif not user_id:
                        print("User ID not found, skipping storage in domain_outputs table")
                    
                    # If no Supabase storage, create a mock URL
                    if not public_url:
                        public_url = f"file://{output_path.replace(os.sep, '/')}"
                        print(f"Using local file path as URL: {public_url}")
                        
                except Exception as storage_error:
                    print(f"Error saving to storage: {storage_error}")
                    # Continue with local file URL
                    public_url = f"file://{output_path.replace(os.sep, '/')}"
                    
                # Update task record if task_id and project_id are provided
                if task_request.task_id and task_request.project_id and supabase_client and user_id:
                    try:
                        # Check if the task exists
                        task_check = supabase_client.from_("tasks").select("*").eq("task_id", task_request.task_id).eq("project_id", task_request.project_id).execute()
                        
                        # Prepare attachments list with the new public URL
                        if task_check.data and len(task_check.data) > 0:
                            # Task exists, update it
                            print(f"Updating existing task: {task_request.task_id}")
                            
                            # Get existing attachments
                            existing_attachments = task_check.data[0].get("attachments", [])
                            if not isinstance(existing_attachments, list):
                                existing_attachments = [existing_attachments] if existing_attachments else []
                            
                            # Append new URL to existing attachments
                            existing_attachments.append(public_url)
                            
                            update_data = {
                                "notes": task_request.user_input,  # Update notes with user input
                                "best_practice": best_practices_text,  # Update best practice
                                "task_name": task_request.title,  # Update task name
                                "updated_by": user_context["user_id"],  # Update the user who made the change
                                "updated_at": datetime.now().isoformat(),  # Add update timestamp
                                "completed": True,  # Mark as completed
                                "attachments": existing_attachments
                            }
                            
                            update_response = supabase_client.from_("tasks").update(update_data).eq("task_id", task_request.task_id).eq("project_id", task_request.project_id).execute()
                            print(f"Updated task record in tasks table: {task_request.task_id}")
                        
                        else:
                            # Task doesn't exist, create it
                            print(f"Task {task_request.task_id} not found, creating new record")
                            
                            task_data = {
                                "task_id": task_request.task_id,
                                "project_id": task_request.project_id,
                                "task_name": task_request.title,
                                "notes": task_request.user_input,
                                "best_practice": best_practices_text,
                                "attachments": [public_url],
                                "completed": True,
                                "updated_at": datetime.now().isoformat(),
                                "updated_by": user_context["user_id"]
                            }
                            
                            insert_response = supabase_client.from_("tasks").insert(task_data).execute()
                            print(f"Created new task record in tasks table: {task_request.task_id}")
                            
                    except Exception as task_error:
                        print(f"Error updating/creating task record: {task_error}")
                        # Continue without updating task record
                
                # If user_id is available, also save to domain_outputs table
                if user_id and supabase_client and public_url:
                    try:
                        domain_data = {
                            "project_id": task_request.project_id,
                            "domain_id": task_request.domain,
                            "content": task_request.user_input,
                            "file_url": public_url,
                            "generated_date": datetime.now().isoformat(),
                            "updated_by": user_id,
                            "created_by": user_id
                        }
                        
                        domain_response = supabase_client.from_("domain_outputs").insert(domain_data).execute()
                        print(f"Saved document to domain_outputs table for project {task_request.project_id}")
                        
                    except Exception as domain_error:
                        print(f"Error saving to domain_outputs: {domain_error}")
                        # Continue without saving to domain_outputs
                elif not user_id:
                    print("User ID not available, skipping domain_outputs entry")
                
                # Update the subscription token count
                if PMO_SERVICES_AVAILABLE and subscription_service and user_id:
                    try:
                        tokens_used = token_usage["total_tokens"]
                        subscription_service.update_token_count(user_id, -tokens_used)
                        print(f"Updated token count for user {user_id}: used {tokens_used} tokens")
                    except Exception as token_update_error:
                        print(f"Error updating token count: {token_update_error}")
                
                # Return successful response
                return {
                    "public_url": public_url,
                    "task_hash": task_hash,
                    "usage": token_usage
                }
                
            except Exception as processing_error:
                print(f"Error processing task: {processing_error}")
                import traceback
                traceback.print_exc()
                
                # Return error response
                raise HTTPException(
                    status_code=500,
                    detail=f"Error processing task: {str(processing_error)}"
                )
        else:
            # PMO services not available, return basic response
            # Generate mock outputs for development/testing
            print("PMO services not available, returning mock response")
            
            # Mock output content
            content = f"""
            # Project Management Consultation
            
            ## Task
            {task_request.title}
            
            ## Domain
            {task_request.domain}
            
            ## Stage
            {task_request.stage}
            
            ## Best Practices
            {', '.join(task_request.bestPractices) if task_request.bestPractices else 'None specified'}
            
            ## User Input
            {task_request.user_input}
            
            ## Recommendations
            This is a mock response as the PMO services are not currently available.
            In a real scenario, detailed recommendations would be provided here.
            
            ## Implementation Plan
            This is a mock implementation plan as the PMO services are not currently available.
            """
            
            # Mock public URL (just a placeholder)
            mock_url = f"https://example.com/mock/pmo_recommendation_{task_hash}.md"
            
            # Return mock response
            return {
                "public_url": mock_url,
                "task_hash": task_hash,
                "usage": default_token_usage
            }
            
    except HTTPException as http_error:
        # Re-raise HTTP exceptions
        raise http_error
    except Exception as e:
        # Handle all other exceptions
        print(f"Unexpected error in get_task_recommendations: {str(e)}")
        import traceback
        traceback.print_exc()
        
        raise HTTPException(
            status_code=500,
            detail=f"Unexpected error: {str(e)}"
        )

@router.get("/tokens", 
    response_model=Dict[str, Any],
    summary="Get user's available tokens",
    description="Retrieves the number of tokens available for the user, including whether they have sufficient tokens for processing requests.",
    responses={
        200: {
            "description": "Successful response",
            "content": {
                "application/json": {
                    "example": {
                        "user_id": "f8f65065-8c0d-4b42-b88d-b19071d718f2",
                        "email": "user@example.com",
                        "remaining_tokens": 50000,
                        "has_sufficient_tokens": True,
                        "min_required_tokens": 13000
                    }
                }
            }
        },
        404: {"description": "User or subscription not found"},
        500: {"description": "Internal server error"}
    }
)
async def get_user_tokens(
    test_email: Optional[str] = None,
    user_email: str = Depends(get_user_email)
):
    """
    Get the number of tokens available for the user.
    
    Returns:
    - user_id: The user's ID
    - email: The user's email
    - remaining_tokens: Number of tokens remaining in the user's account
    - has_sufficient_tokens: Boolean indicating if the user has sufficient tokens (13,000+)
    """
    try:
        # Get user and subscription, will auto-create if not found
        user, subscription = subscription_service.ensure_user_and_subscription(user_email)
        
        if not user:
            raise HTTPException(status_code=500, detail=f"Failed to create or find user with email {user_email}")
        
        if not subscription:
            raise HTTPException(status_code=500, detail=f"Failed to create or find subscription for user {user_email}")
        
        # Get token count
        remaining_tokens = subscription.get("count", 0)
        min_required_tokens = 13000  # Minimum tokens required for service
        
        return {
            "user_id": user.get("id"),
            "email": user_email,
            "remaining_tokens": remaining_tokens,
            "has_sufficient_tokens": remaining_tokens >= min_required_tokens,
            "min_required_tokens": min_required_tokens
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching token information: {str(e)}")

def check_sufficient_tokens(user_email: str, required_tokens: int = 13000) -> bool:
    """
    Check if a user has sufficient tokens for a task.
    Raises an HTTPException if tokens are insufficient.
    
    Args:
        user_email: The user's email
        required_tokens: The minimum number of tokens required (default: 13000)
        
    Returns:
        True if sufficient tokens, raises exception otherwise
    """
    # Get user and subscription
    user, subscription = subscription_service.ensure_user_and_subscription(user_email)
    
    if not user or not subscription:
        raise HTTPException(
            status_code=404, 
            detail=f"User or subscription not found for {user_email}"
        )
    
    # Get token count
    remaining_tokens = subscription.get("count", 0)
    
    # Check if sufficient tokens
    if remaining_tokens < required_tokens:
        raise HTTPException(
            status_code=403, 
            detail=f"Insufficient tokens. You have {remaining_tokens} tokens, but {required_tokens} are required. Please upgrade your plan."
        )
    
    return True

@router.get("/user-documents")
async def get_user_documents(
    project_id: Optional[str] = None,
    test_email: Optional[str] = None,
    user_email: str = Depends(get_user_email)
):
    """
    Get all documents related to a user from both domain_outputs and tasks tables.
    
    Parameters:
    - project_id: Optional filter to get documents for a specific project
    - test_email: For testing purposes
    - user_email: Extracted from authorization
    
    Returns:
    - A list of documents with file URL, name, source, and creation date
    """
    try:
        documents = []
        user_id = None
        
        # Get a fresh Supabase client
        supabase_client = get_supabase_client()
        if not supabase_client:
            return {"documents": [], "count": 0, "message": "Failed to connect to database"}
        
        # First try to find user in profile table
        try:
            profile_response = supabase_client.from_("profiles").select("id").eq("email", user_email).execute()
            if profile_response.data and len(profile_response.data) > 0:
                user_id = profile_response.data[0]["id"]
                print(f"Found user ID {user_id} from profiles table for email {user_email}")
        except Exception as e:
            print(f"Error querying profiles table: {e}")
        
        # If not found in profiles, check auth system
        if not user_id:
            try:
                auth_user_response = supabase_client.auth.admin.list_users()
                if auth_user_response and hasattr(auth_user_response, 'users'):
                    for user in auth_user_response.users:
                        if hasattr(user, 'email') and user.email == user_email:
                            user_id = user.id
                            print(f"Found user in auth system with ID {user_id}")
                            
                            # Create a profile for this user
                            try:
                                new_profile = {
                                    "id": user_id,
                                    "email": user_email,
                                    "display_name": user_email.split('@')[0],
                                    "created_at": datetime.now().isoformat()
                                }
                                
                                profile_create = supabase_client.from_("profiles").insert(new_profile).execute()
                                if profile_create.data:
                                    print(f"Created new profile for auth user {user_email}")
                                    
                                    # Create a subscription
                                    try:
                                        subscription_data = {
                                            "user_id": user_id,
                                            "count": 81250,
                                            "feature": "tokens"
                                        }
                                        supabase_client.from_("subscription_usage").insert(subscription_data).execute()
                                        print(f"Created subscription for user {user_id}")
                                    except Exception as sub_error:
                                        print(f"Error creating subscription: {sub_error}")
                            except Exception as profile_error:
                                print(f"Error creating profile: {profile_error}")
                            
                            break
            except Exception as auth_error:
                print(f"Error looking up auth users: {auth_error}")
        
        # If still no user_id, try subscription service as fallback
        if not user_id and subscription_service:
            try:
                print(f"Using subscription service fallback for {user_email}")
                user, subscription = subscription_service.ensure_user_and_subscription(user_email)
                if user:
                    user_id = user.get("id")
                    print(f"Created temporary user with ID: {user_id}")
            except Exception as sub_error:
                print(f"Error creating temporary user: {sub_error}")
        
        # If we still don't have a user_id, return empty result
        if not user_id:
            return {"documents": [], "count": 0, "message": "User not found or could not be created"}
        
        # Get documents from domain_outputs table
        try:
            domain_query = supabase_client.from_("domain_outputs").select("file_url,domain_id,generated_date,project_id").eq("created_by", user_id)
            if project_id:
                domain_query = domain_query.eq("project_id", project_id)
                
            domain_outputs = domain_query.execute()
            
            if domain_outputs.data:
                for doc in domain_outputs.data:
                    if doc.get("file_url"):
                        filename = doc.get("file_url").split("/")[-1] if doc.get("file_url") else "Unknown"
                        documents.append({
                            "file_url": doc.get("file_url"),
                            "name": filename,
                            "domain": doc.get("domain_id"),
                            "created_date": doc.get("generated_date"),
                            "project_id": doc.get("project_id"),
                            "source": "domain_outputs"
                        })
        except Exception as e:
            print(f"Error retrieving domain_outputs: {e}")
        
        # Get documents from tasks table
        try:
            tasks_query = supabase_client.from_("tasks").select("task_id,project_id,task_name,attachments,updated_at").eq("updated_by", user_id)
            if project_id:
                tasks_query = tasks_query.eq("project_id", project_id)
                
            tasks_result = tasks_query.execute()
            
            if tasks_result.data:
                for task in tasks_result.data:
                    attachments = task.get("attachments")
                    if attachments is None:
                        continue
                        
                    if isinstance(attachments, list):
                        for attachment in attachments:
                            if attachment:
                                filename = attachment.split("/")[-1] if attachment else "Unknown"
                                documents.append({
                                    "file_url": attachment,
                                    "name": filename,
                                    "task_id": task.get("task_id"),
                                    "task_name": task.get("task_name"),
                                    "created_date": task.get("updated_at"),
                                    "project_id": task.get("project_id"),
                                    "source": "tasks"
                                })
                    elif attachments:
                        filename = attachments.split("/")[-1] if attachments else "Unknown"
                        documents.append({
                            "file_url": attachments,
                            "name": filename,
                            "task_id": task.get("task_id"),
                            "task_name": task.get("task_name"),
                            "created_date": task.get("updated_at"),
                            "project_id": task.get("project_id"),
                            "source": "tasks"
                        })
        except Exception as e:
            print(f"Error retrieving tasks: {e}")
        
        # Sort documents by creation date (newest first)
        documents.sort(key=lambda x: x.get("created_date", ""), reverse=True)
        
        return {"documents": documents, "count": len(documents)}
        
    except Exception as e:
        print(f"Unexpected error in get_user_documents: {str(e)}")
        import traceback
        traceback.print_exc()
        return {"documents": [], "count": 0, "error": str(e)}

@router.get("/export-project/{project_id}", response_model=Dict[str, str],
    summary="Export project details",
    description="Generates a document with project details and returns the download URL.",
    responses={
        200: {
            "description": "Successfully generated project document",
            "content": {
                "application/json": {
                    "example": {
                        "public_url": "https://example.com/files/project_document.docx",
                        "filename": "project_document.docx"
                    }
                }
            }
        },
        500: {"description": "Internal server error"}
    }
)
async def export_project_details(
    project_id: str,
    user_email: str = Depends(get_user_email)
):
    """
    Export project details as a document.
    Returns the public URL to download the generated document.
    If the requested project is not found, returns the default project document instead.
    """
    try:
        print(f"Exporting project {project_id} for user {user_email}")
        user_metadata = {"email": user_email}
        supabase = get_supabase_client()
        
        if not supabase:
            raise HTTPException(
                status_code=500,
                detail="Failed to connect to database"
            )
            
        # Check if project exists
        project_data = supabase.from_("projects").select("*").eq("id", project_id).execute()
        
        if not project_data.data or len(project_data.data) == 0:
            print(f"Project {project_id} not found, looking for default project")
            
            # Try to find user ID from email
            user_id = None
            profile_response = supabase.from_("profiles").select("id").eq("email", user_email).execute()
            if profile_response.data and len(profile_response.data) > 0:
                user_id = profile_response.data[0]["id"]
                print(f"Found user ID {user_id} from profiles table")
            
            if user_id:
                # Look for default project by is_default flag
                default_project = supabase.from_("projects").select("*").eq("owner_id", user_id).eq("is_default", True).execute()
                
                # If not found by flag, try by name
                if not default_project.data or len(default_project.data) == 0:
                    default_project = supabase.from_("projects").select("*").eq("owner_id", user_id).eq("name", "PMO Implementation Starter").execute()
                
                # If still not found, look for any project for this user
                if not default_project.data or len(default_project.data) == 0:
                    default_project = supabase.from_("projects").select("*").eq("owner_id", user_id).limit(1).execute()
                
                if default_project.data and len(default_project.data) > 0:
                    print(f"Using default project for user {user_id}")
                    project_id = default_project.data[0]["id"]
                else:
                    print(f"No projects found for user {user_id}, using hardcoded default project data")
                    # Generate a hardcoded project document and return it
                    result = create_hardcoded_project_document(user_metadata)
                    if not result:
                        raise HTTPException(
                            status_code=500,
                            detail="Error generating hardcoded project document"
                        )
                    return {
                        "public_url": result["public_url"],
                        "filename": result["filename"]
                    }
            else:
                print(f"Could not find user ID for email {user_email}, using hardcoded default project data")
                # Generate a hardcoded project document and return it
                result = create_hardcoded_project_document(user_metadata)
                if not result:
                    raise HTTPException(
                        status_code=500,
                        detail="Error generating hardcoded project document"
                    )
                return {
                    "public_url": result["public_url"],
                    "filename": result["filename"]
                }
        
        # Generate the project document
        result = get_project_document(project_id, user_metadata)
        
        if not result:
            raise HTTPException(
                status_code=500,
                detail="Error generating project document"
            )
            
        return {
            "public_url": result["public_url"],
            "filename": result["filename"]
        }
        
    except HTTPException as he:
        raise he
    except Exception as e:
        print(f"Error exporting project details: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Error generating project document: {str(e)}"
        )

def create_hardcoded_project_document(user_metadata=None):
    """
    Creates a document with hardcoded default project data.
    This is used when no projects are found for a user.
    """
    from datetime import datetime
    
    # Create hardcoded default project data
    hardcoded_project = {
        "name": "PMO Implementation Starter",
        "description": """Welcome to your PMO Implementation Project! This starter project includes essential PMO setup activities:

Key Objectives:
• Establish PMO governance framework
• Define project management methodology
• Set up project portfolio tracking
• Create templates and tools
• Plan team training and development

Expected Outcomes:
✓ Clear PMO structure and processes
✓ Standardized project management approach
✓ Improved project success rates
✓ Better resource management
✓ Enhanced stakeholder communication""",
        "start_date": datetime.now().isoformat(),
        "end_date": (datetime.now().replace(month=datetime.now().month + 6)).isoformat(),
        "budget": 50000,
        "owner_id": "default",
        "key_objectives": [
            "Establish PMO governance framework",
            "Define project management methodology",
            "Set up project portfolio tracking",
            "Create templates and tools",
            "Plan team training and development"
        ],
        "stakeholders": [
            {"role": "Project Sponsor", "name": "Executive Sponsor", "responsibilities": "Executive oversight and support"},
            {"role": "PMO Lead", "name": "PMO Manager", "responsibilities": "Implementation leadership and coordination"},
            {"role": "Team Members", "name": "Project Team", "responsibilities": "Process development and documentation"}
        ],
        "risks": [
            {"description": "Insufficient executive support", "severity": "High", "mitigation": "Regular executive briefings and demonstrating early value"},
            {"description": "Resistance to change", "severity": "Medium", "mitigation": "Stakeholder engagement and communication plan"},
            {"description": "Resource constraints", "severity": "Medium", "mitigation": "Phased implementation approach with clear prioritization"}
        ]
    }
    
    # Create document content
    document_content = format_project_document(hardcoded_project)
    
    # Save to Supabase and return the result
    return save_project_to_supabase(document_content, hardcoded_project["name"], user_metadata)

@router.post("/auth/setup-user", response_model=None)
def setup_user(request: Request, user_data: UserData):
    try:
        # Get the email from request
        user_email = user_data.email
        print(f"Setting up user for email: {user_email}")
        
        # Initialize Supabase client
        supabase_client = get_supabase_client()
        
        if supabase_client:
            # Initialize the subscription service
            subscription_service = SubscriptionService(supabase_client)
            
            # Ensure user profile and subscription exist
            user, subscription = subscription_service.ensure_user_and_subscription(user_email)
            
            if user:
                print(f"User setup complete with ID: {user.get('id')}")
                # Return success with user information
                return {
                    "status": "success",
                    "user_id": user.get("id"),
                    "subscription": subscription
                }
            else:
                # Could not find or create user
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Could not setup user for {user_email}"
                )
        else:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to initialize Supabase client"
            )
    except Exception as e:
        print(f"Error in setup-user endpoint: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error occurred: {str(e)}"
        )

@router.get("/results/{task_hash}", response_model=TaskResponse)
async def get_task_results_by_hash(
    task_hash: str,
    user_email: str = Depends(get_user_email),
):
    """
    Retrieve PMO recommendations results by task hash.
    
    This endpoint enables recovery of previously generated recommendations 
    in cases where the original request was successful but the response 
    was lost due to network issues or timeouts.
    
    Parameters:
    - task_hash: The unique identifier for the task
    
    Returns:
    - public_url: URL to access the generated document
    - task_hash: The same task_hash that was provided
    - usage: Token usage statistics (if available)
    """
    try:
        print(f"Attempting to retrieve results for task hash: {task_hash}")
        
        # Validate the hash format
        if not task_hash or len(task_hash) < 8:
            raise HTTPException(
                status_code=400,
                detail="Invalid task hash format"
            )
        
        # Get Supabase client
        supabase_client = get_supabase_client()
        
        # Search for the document in domain_outputs
        try:
            response = supabase_client.table('domain_outputs').select('*').eq('task_hash', task_hash).execute()
            data = response.data
            
            if data and len(data) > 0:
                # Found the document
                document = data[0]
                print(f"Found document for task hash {task_hash}")
                
                # Return the document details
                return {
                    "public_url": document.get('file_url'),
                    "task_hash": task_hash,
                    "usage": {
                        "input_tokens": document.get('input_tokens', 0),
                        "output_tokens": document.get('output_tokens', 0),
                        "total_tokens": document.get('total_tokens', 0)
                    }
                }
            else:
                # If not found in domain_outputs, try searching in output_files
                response = supabase_client.table('output_files').select('*').eq('hash', task_hash).execute()
                data = response.data
                
                if data and len(data) > 0:
                    # Found the document in output_files
                    document = data[0]
                    print(f"Found document in output_files for task hash {task_hash}")
                    
                    # Return the document details
                    return {
                        "public_url": document.get('url'),
                        "task_hash": task_hash,
                        "usage": {
                            "input_tokens": document.get('input_tokens', 0),
                            "output_tokens": document.get('output_tokens', 0),
                            "total_tokens": document.get('input_tokens', 0) + document.get('output_tokens', 0)
                        }
                    }
                
                # Document not found in either table
                raise HTTPException(
                    status_code=404,
                    detail=f"No document found for task hash: {task_hash}"
                )
                
        except Exception as db_error:
            print(f"Database error while searching for task hash {task_hash}: {db_error}")
            raise HTTPException(
                status_code=500,
                detail="Error retrieving document from database"
            )
            
    except HTTPException as http_error:
        # Re-raise HTTP exceptions
        raise http_error
    except Exception as error:
        print(f"Error retrieving results: {error}")
        raise HTTPException(
            status_code=500,
            detail=f"Unexpected error: {str(error)}"
        ) 