from fastapi import APIRouter, UploadFile, File, HTTPException
from typing import Dict, Any
from services.document_reader_service import DocumentReaderService

router = APIRouter()
document_reader = DocumentReaderService()

@router.post("/read", response_model=Dict[str, Any])
async def read_document(file: UploadFile = File(...)):
    try:
        # Read file content
        content = await file.read()
        
        # Process document
        result = await document_reader.read_document(content, file.filename)
        
        return {
            "status": "success",
            "filename": file.filename,
            "data": result
        }
        
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e)) 