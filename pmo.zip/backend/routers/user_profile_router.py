from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel, validator
from typing import Optional, Dict, Any
from config.supabase import supabase, get_supabase_client
import uuid
import re

router = APIRouter(
    prefix="/users",
    tags=["users"],
    responses={404: {"description": "Not found"}},
)

class UserProfileCreate(BaseModel):
    email: str
    display_name: str
    
    @validator('email')
    def validate_email(cls, v):
        # Basic email validation regex
        pattern = r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"
        if not re.match(pattern, v):
            raise ValueError('Invalid email format')
        return v

class UserProfileResponse(BaseModel):
    id: str
    email: str
    display_name: str

@router.post("/profile", response_model=UserProfileResponse, status_code=201)
async def create_user_profile(user_data: UserProfileCreate):
    """
    Create a new user profile in the 'profiles' table.
    """
    try:
        # Get a fresh Supabase client
        supabase_client = get_supabase_client()
        if not supabase_client:
            raise HTTPException(status_code=500, detail="Unable to connect to database")
        
        # Check if user already exists with this email
        existing_user = supabase_client.from_("profiles").select("*").eq("email", user_data.email).execute()
        
        if existing_user.data and len(existing_user.data) > 0:
            raise HTTPException(status_code=400, detail="User with this email already exists")
        
        # Create a new user profile
        user_id = str(uuid.uuid4())
        new_profile = {
            "id": user_id,
            "email": user_data.email,
            "display_name": user_data.display_name
        }
        
        # Insert into profiles table
        result = supabase_client.from_("profiles").insert(new_profile).execute()
        
        if not result.data or len(result.data) == 0:
            raise HTTPException(status_code=500, detail="Failed to create user profile")
        
        return {
            "id": user_id,
            "email": user_data.email,
            "display_name": user_data.display_name
        }
    
    except Exception as e:
        # Log the error (you can add more detailed logging)
        print(f"Error creating user profile: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

@router.get("/profile/{email}", response_model=UserProfileResponse)
async def get_user_profile(email: str):
    """
    Get a user profile by email.
    """
    try:
        # Get a fresh Supabase client
        supabase_client = get_supabase_client()
        if not supabase_client:
            raise HTTPException(status_code=500, detail="Unable to connect to database")
        
        # Query the profiles table
        result = supabase_client.from_("profiles").select("*").eq("email", email).execute()
        
        if not result.data or len(result.data) == 0:
            raise HTTPException(status_code=404, detail="User profile not found")
        
        user_data = result.data[0]
        return {
            "id": user_data["id"],
            "email": user_data["email"],
            "display_name": user_data["display_name"]
        }
    
    except Exception as e:
        # Log the error
        print(f"Error fetching user profile: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}") 