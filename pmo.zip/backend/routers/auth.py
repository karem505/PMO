from fastapi import APIRouter, HTTPException, Header, Depends, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from typing import Optional, Dict, Any
from pydantic import BaseModel
from supabase import create_client, Client
import os
from datetime import datetime, timedelta
import jwt
import asyncio
import json

router = APIRouter()

# Initialize Supabase client with better error handling
try:
    supabase_url = os.getenv("SUPABASE_URL")
    supabase_key = os.getenv("SUPABASE_SERVICE_ROLE_KEY")  # Changed from SUPABASE_SERVICE_ROLE_KEY
    jwt_secret = os.getenv("JWT_SECRET_KEY", "pmo-mvp-secure-jwt-key-for-development-only")  # More secure default key
    
    if not supabase_url or not supabase_key:
        print("Warning: Missing Supabase environment variables!")
        print(f"SUPABASE_URL: {'Set' if supabase_url else 'Missing'}")
        print(f"SUPABASE_SERVICE_KEY: {'Set' if supabase_key else 'Missing'}")
        if os.getenv("ENVIRONMENT") != "development":
            raise ValueError("Supabase configuration is incomplete. Please check your environment variables.")
        
    supabase: Client = create_client(supabase_url, supabase_key)
    print("Supabase client initialized successfully")
except Exception as e:
    print(f"Error initializing Supabase client: {str(e)}")
    if os.getenv("ENVIRONMENT") != "development":
        raise
    print("Running in development mode without Supabase")
    supabase = None

# Bearer token security
security = HTTPBearer(auto_error=False)  # Make it optional

async def get_current_user(
    token: Optional[HTTPAuthorizationCredentials] = Depends(security),
    x_user_email: Optional[str] = Header(None),
) -> Dict[str, Any]:
    """
    Get the current authenticated user using Supabase JWT or X-User-Email header.
    Prioritizes X-User-Email header if provided (for development/testing).
    
    Returns:
    - Dict containing user information (email, id, metadata)
    
    Raises:
    - HTTPException(401) if authentication fails
    """
    # Development mode with X-User-Email header
    if x_user_email:
        if os.getenv("ENVIRONMENT") == "development" or os.getenv("ALLOW_TEST_HEADERS"):
            print(f"Development mode: Using X-User-Email header: {x_user_email}")
            return {
                "email": x_user_email,
                "id": "dev-" + x_user_email.split("@")[0],
                "user_metadata": {"development_mode": True}
            }
        else:
            print("Warning: X-User-Email header ignored in production")
    
    # Production mode requires valid token
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    if not token:
        raise credentials_exception
    
    try:
        # First try Supabase token verification
        if supabase:
            try:
                user = supabase.auth.get_user(token.credentials)
                if user and user.user:
                    return {
                        "email": user.user.email,
                        "id": user.user.id,
                        "user_metadata": user.user.user_metadata
                    }
            except Exception as e:
                print(f"Supabase token verification failed: {str(e)}")
                # Fall through to JWT verification
        
        # Fallback to JWT verification in development
        if os.getenv("ENVIRONMENT") == "development":
            try:
                payload = jwt.decode(token.credentials, jwt_secret, algorithms=["HS256"])
                if email := payload.get("email"):
                    return {
                        "email": email,
                        "id": f"dev-{email.split('@')[0]}",
                        "user_metadata": {"development_mode": True}
                    }
            except jwt.PyJWTError as e:
                print(f"JWT verification failed: {str(e)}")
        
        raise credentials_exception
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Authentication error: {str(e)}")
        raise credentials_exception

def verify_supabase_token(token: str) -> Dict[str, Any]:
    """
    Verify a Supabase token and return the user data.
    Falls back to JWT verification in development mode.
    """
    try:
        # Try Supabase verification first
        if supabase:
            try:
                user = supabase.auth.get_user(token)
                if user and user.user:
                    return {
                        "id": user.user.id,
                        "email": user.user.email,
                        "user_metadata": user.user.user_metadata,
                        "sub": user.user.id  # Add the 'sub' field for ID matching
                    }
            except Exception as e:
                print(f"Supabase token verification failed: {str(e)}")
                if os.getenv("ENVIRONMENT") != "development":
                    raise
        
        # Fallback to JWT verification in development
        if os.getenv("ENVIRONMENT") == "development":
            payload = jwt.decode(token, jwt_secret, algorithms=["HS256"])
            if email := payload.get("email"):
                user_id = f"dev-{email.split('@')[0]}"
                return {
                    "id": user_id,
                    "email": email,
                    "user_metadata": {"development_mode": True},
                    "sub": user_id  # Add the 'sub' field for ID matching
                }
        
        raise ValueError("Invalid token")
    except Exception as e:
        print(f"Token verification error: {str(e)}")
        raise ValueError(str(e))

class UserSetupRequest(BaseModel):
    user_id: str
    email: str
    display_name: Optional[str] = None
    photo_url: Optional[str] = None
    team_code: Optional[str] = None

async def create_default_project(user_id: str):
    """Create a default project for a new user"""
    try:
        # First check if the user already has any projects
        has_projects = False
        try:
            projects_response = supabase.from_("projects").select("id").eq("owner_id", user_id).execute()
            has_projects = projects_response.data and len(projects_response.data) > 0
            
            if has_projects:
                print(f"User {user_id} already has projects, skipping default project creation")
                return
        except Exception as check_error:
            print(f"Error checking existing projects: {check_error}")
        
        # Proceed with creating a default project only if user has no projects
        if not has_projects:
            # Default project data
            project_data = {
                "name": "Default PMO Implementation",
                "description": "Initial PMO implementation project",
                "owner_id": user_id,
                "budget": 450000,
                "start_date": datetime.utcnow().isoformat(),
                "end_date": (datetime.utcnow() + timedelta(days=180)).isoformat()
            }
            
            response = supabase.from_("projects").insert(project_data).execute()
            
            if response.data and len(response.data) > 0:
                print(f"Created default project for user {user_id}")
                return response.data[0].get("id")
            else:
                print(f"No data returned from project creation")
                return None
        
    except Exception as error:
        print(f"Error creating default project: {error}")
        return None

@router.post("/setup-user")
async def setup_user(
    request: UserSetupRequest,
    authorization: Optional[str] = Header(None)
):
    """
    Set up a new user account with profile and initial data
    """
    try:
        # Verify the token if provided
        if authorization:
            try:
                token = authorization.split(' ')[1]
                user_data = verify_supabase_token(token)
                
                # Verify the user ID matches
                if user_data.get('sub') != request.user_id:
                    raise HTTPException(
                        status_code=403,
                        detail="User ID mismatch"
                    )
            except Exception as e:
                print(f"Token verification failed: {str(e)}")
                raise HTTPException(
                    status_code=401,
                    detail="Invalid authorization token"
                )

        # First check if profile already exists
        profile_result = supabase.from_("profiles").select("*").eq("id", request.user_id).execute()
        
        if profile_result.data:
            print(f"Profile already exists for user {request.user_id}")
            # Still check for default project even if profile exists
            await create_default_project(request.user_id)
            return {"status": "success", "message": "Profile already exists"}

        # Retry profile creation up to 3 times
        max_retries = 3
        retry_delay = 1
        
        for attempt in range(max_retries):
            try:
                # Create user profile
                profile_data = {
                    "id": request.user_id,
                    "email": request.email,
                    "display_name": request.display_name or request.email.split('@')[0],
                    "photo_url": request.photo_url,
                    "created_at": datetime.utcnow().isoformat(),
                    "organization_name": "",
                    "industry": "",
                    "pmo_maturity_level": "Initial"
                }
                
                profile_result = supabase.from_("profiles").insert(profile_data).execute()
                
                if profile_result.data:
                    print(f"Profile created successfully for user {request.user_id}")
                    
                    # Create subscription_usage entry 
                    try:
                        subscription_data = {
                            "user_id": request.user_id,
                            "count": 81250,  # Default token count
                            "feature": "free"  # Using 'free' as the feature instead of 'tokens'
                        }
                        
                        subscription_result = supabase.from_("subscription_usage").insert(subscription_data).execute()
                        if subscription_result.data:
                            print(f"Created subscription for user {request.user_id} with 81250 tokens")
                    except Exception as sub_error:
                        print(f"Error creating subscription: {sub_error}")
                    
                    # Create subscription record
                    try:
                        # Check if user already has a subscription
                        existing_sub = supabase.from_("subscriptions").select("*").eq("user_id", request.user_id).execute()
                        
                        if existing_sub.data and len(existing_sub.data) > 0:
                            print(f"User {request.user_id} already has a subscription, skipping creation")
                        else:
                            subscription_data = {
                                "user_id": request.user_id,
                                "plan": "free",
                                "status": "active",
                                "start_date": datetime.utcnow().isoformat()
                            }
                            
                            supabase.from_("subscriptions").insert(subscription_data).execute()
                            print(f"Created subscription plan for user {request.user_id}")
                    except Exception as sub_error:
                        print(f"Error creating subscription plan: {sub_error}")
                    
                    # Create a default project for the user
                    await create_default_project(request.user_id)
                    
                    break
                else:
                    print(f"Profile creation failed on attempt {attempt + 1}")
                    if attempt < max_retries - 1:
                        await asyncio.sleep(retry_delay)
                    else:
                        raise HTTPException(
                            status_code=500,
                            detail="Failed to create user profile after multiple attempts"
                        )
            except Exception as e:
                print(f"Error creating profile on attempt {attempt + 1}: {str(e)}")
                if attempt < max_retries - 1:
                    await asyncio.sleep(retry_delay)
                else:
                    raise HTTPException(
                        status_code=500,
                        detail=f"Database error creating profile: {str(e)}"
                    )
                    
        return {"status": "success", "message": "User setup completed successfully"}
    
    except Exception as e:
        print(f"Unexpected error in setup_user: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"User setup error: {str(e)}"
        )

@router.get("/validate-setup/{user_id}")
async def validate_setup(
    user_id: str,
    authorization: Optional[str] = Header(None)
):
    """
    Validate that a user has been properly set up
    """
    try:
        # Verify the token
        if authorization:
            try:
                token = authorization.split(' ')[1]
                user_data = verify_supabase_token(token)
                if user_data['id'] != user_id:
                    raise HTTPException(status_code=403, detail="User ID mismatch")
            except ValueError as e:
                raise HTTPException(status_code=401, detail=str(e))
            except Exception:
                raise HTTPException(status_code=401, detail="Invalid authorization token")

        # Check if user profile exists
        profile = supabase.from_("profiles").select("*").eq("id", user_id).single().execute()
        
        if not profile.data:
            return {"status": "incomplete", "missing": ["profile"]}
        
        # Check if user has a project (first check for default projects, then any project)
        default_project = supabase.from_("projects").select("id").eq("owner_id", user_id).eq("is_default", True).limit(1).execute()
        if not default_project.data or len(default_project.data) == 0:
            # Check by name as fallback
            name_project = supabase.from_("projects").select("id").eq("owner_id", user_id).eq("name", "PMO Implementation Starter").limit(1).execute()
            if not name_project.data or len(name_project.data) == 0:
                # Check for any project
                project = supabase.from_("projects").select("id").eq("owner_id", user_id).limit(1).execute()
                if not project.data or len(project.data) == 0:
                    project = None
                else:
                    project = project.data
            else:
                project = name_project.data
                # Update the is_default flag for this project
                supabase.from_("projects").update({"is_default": True}).eq("id", name_project.data[0]["id"]).execute()
        else:
            project = default_project.data
        
        # Check if user has an active subscription
        subscription = supabase.from_("subscriptions").select("id").eq("user_id", user_id).eq("status", "active").limit(1).execute()
        
        missing = []
        if not project:
            missing.append("project")
            # Attempt to create a default project if missing
            if not "profile" in missing:
                try:
                    await create_default_project(user_id)
                except Exception as e:
                    print(f"Error creating default project during validation: {str(e)}")
                    # Continue with validation
        
        if not subscription.data or len(subscription.data) == 0:
            missing.append("subscription")
            
        return {
            "status": "complete" if not missing else "incomplete",
            "missing": missing
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"Error in validate_setup: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

class GoogleUserSetupRequest(BaseModel):
    user_id: str
    email: str
    display_name: Optional[str] = None
    photo_url: Optional[str] = None

@router.post("/setup-google-user")
async def setup_google_user(
    request: GoogleUserSetupRequest,
    x_user_email: Optional[str] = Header(None)
):
    """
    Set up a user account who signed up via Google OAuth
    without requiring token verification
    """
    try:
        print(f"Setting up Google user: {request.email} ({request.user_id})")
        
        # Safety check - if x_user_email header provided, verify it matches
        if x_user_email and x_user_email != request.email:
            print(f"Email mismatch: {x_user_email} vs {request.email}")
            raise HTTPException(
                status_code=403,
                detail="Email mismatch between header and request body"
            )

        # First check if profile already exists
        try:
            profile_result = supabase.from_("profiles").select("*").eq("id", request.user_id).execute()
            
            if profile_result.data and len(profile_result.data) > 0:
                print(f"Profile already exists for user {request.user_id}")
                # Still check for default project even if profile exists
                project_id = await create_default_project(request.user_id)
                return {"status": "success", "message": "Profile already exists", "project_id": project_id}
        except Exception as profile_error:
            print(f"Error checking existing profile: {profile_error}")
            # Continue with profile creation
        
        # Retry profile creation up to 3 times
        max_retries = 3
        retry_delay = 1  # seconds
        profile_created = False
        
        for attempt in range(max_retries):
            try:
                # Create user profile
                profile_data = {
                    "id": request.user_id,
                    "email": request.email,
                    "display_name": request.display_name or request.email.split('@')[0],
                    "photo_url": request.photo_url,
                    "created_at": datetime.utcnow().isoformat(),
                    "organization_name": "",
                    "industry": "",
                    "pmo_maturity_level": "Initial"
                }
                
                try:
                    profile_result = supabase.from_("profiles").insert(profile_data).execute()
                    
                    if profile_result.data and len(profile_result.data) > 0:
                        print(f"Profile created successfully for user {request.user_id}")
                        profile_created = True
                        
                        # Create subscription_usage entry 
                        try:
                            subscription_data = {
                                "user_id": request.user_id,
                                "count": 81250,  # Default token count
                                "feature": "free"  # Using 'free' as the feature
                            }
                            
                            try:
                                subscription_result = supabase.from_("subscription_usage").insert(subscription_data).execute()
                                if subscription_result.data and len(subscription_result.data) > 0:
                                    print(f"Created subscription for user {request.user_id} with 81250 tokens")
                            except Exception as sub_error:
                                print(f"Error creating subscription: {sub_error}")
                        except Exception as sub_error:
                            print(f"Error creating subscription usage: {sub_error}")
                        
                        # Create subscription record
                        try:
                            # Check if user already has a subscription
                            try:
                                existing_sub = supabase.from_("subscriptions").select("*").eq("user_id", request.user_id).execute()
                                
                                if existing_sub.data and len(existing_sub.data) > 0:
                                    print(f"User {request.user_id} already has a subscription, skipping creation")
                                else:
                                    subscription_data = {
                                        "user_id": request.user_id,
                                        "plan": "free",
                                        "status": "active",
                                        "start_date": datetime.utcnow().isoformat()
                                    }
                                    
                                    try:
                                        sub_result = supabase.from_("subscriptions").insert(subscription_data).execute()
                                        if sub_result.data and len(sub_result.data) > 0:
                                            print(f"Created subscription plan for user {request.user_id}")
                                    except Exception as sub_insert_error:
                                        print(f"Error inserting subscription: {sub_insert_error}")
                            except Exception as sub_check_error:
                                print(f"Error checking existing subscription: {sub_check_error}")
                        except Exception as sub_error:
                            print(f"Error creating subscription plan: {sub_error}")
                        
                        # Create a default project for the user
                        project_id = await create_default_project(request.user_id)
                        
                        break
                    else:
                        print(f"Profile creation failed on attempt {attempt + 1}")
                        if attempt < max_retries - 1:
                            await asyncio.sleep(retry_delay)
                        else:
                            raise HTTPException(
                                status_code=500,
                                detail="Failed to create user profile after multiple attempts"
                            )
                except Exception as insert_error:
                    print(f"Error inserting profile: {insert_error}")
                    if attempt < max_retries - 1:
                        await asyncio.sleep(retry_delay)
                    else:
                        raise HTTPException(
                            status_code=500,
                            detail=f"Database error inserting profile: {str(insert_error)}"
                        )
            except Exception as e:
                print(f"Error creating profile on attempt {attempt + 1}: {str(e)}")
                if attempt < max_retries - 1:
                    await asyncio.sleep(retry_delay)
                else:
                    raise HTTPException(
                        status_code=500,
                        detail=f"Database error creating profile: {str(e)}"
                    )
        
        if not profile_created:
            raise HTTPException(
                status_code=500,
                detail="Failed to create profile after all attempts"
            )
        
        return {"status": "success", "message": "User setup completed successfully", "project_id": project_id if 'project_id' in locals() else None}
    
    except HTTPException as http_ex:
        raise http_ex
    except Exception as e:
        print(f"Unexpected error in setup_google_user: {str(e)}")
        import traceback
        traceback.print_exc()
        raise HTTPException(
            status_code=500,
            detail=f"User setup error: {str(e)}"
        ) 