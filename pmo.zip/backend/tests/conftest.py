import os
import sys
from pathlib import Path
from unittest.mock import Mock, patch
import pytest
from main import app
from supabase import Client
from fastapi.testclient import TestClient

# Add the backend directory to the Python path
backend_dir = str(Path(__file__).parent.parent)
sys.path.insert(0, backend_dir)

# Mock all dependencies before imports
@pytest.fixture(autouse=True, scope="session")
def mock_dependencies():
    """Mock all dependencies before imports."""
    # Mock Supabase client
    with patch('supabase.create_client') as mock_create_client:
        # Create mock client
        mock_client = Mock()
        mock_create_client.return_value = mock_client
        
        # Mock the auth methods
        mock_auth = Mock()
        mock_client.auth = mock_auth
        
        # Mock the sign_in method
        mock_auth.sign_in_with_password.return_value = {
            "user": {"email": "test@example.com"},
            "session": {"access_token": "test_token"}
        }
        
        # Mock the get_user method
        mock_auth.get_user.return_value = {
            "user": {"email": "test@example.com"}
        }
        
        # Mock the table methods
        mock_table = Mock()
        mock_client.table.return_value = mock_table
        
        # Mock the upsert method
        mock_upsert = Mock()
        mock_table.upsert.return_value = mock_upsert
        mock_upsert.execute.return_value = {"data": [{"email": "test@example.com"}]}
        
        # Mock the select method
        mock_select = Mock()
        mock_table.select.return_value = mock_select
        mock_select.eq.return_value = mock_select
        mock_select.execute.return_value = {"data": [{"email": "test@example.com"}]}
        
        # Mock the update method
        mock_update = Mock()
        mock_table.update.return_value = mock_update
        mock_update.eq.return_value = mock_update
        mock_update.execute.return_value = {"data": [{"email": "test@example.com"}]}
        
        # Mock the delete method
        mock_delete = Mock()
        mock_table.delete.return_value = mock_delete
        mock_delete.eq.return_value = mock_delete
        mock_delete.execute.return_value = {"data": []}

    # Mock OpenAI
    with patch('openai.OpenAI') as mock_openai:
        mock_client = Mock()
        mock_openai.return_value = mock_client
        
        # Mock the chat.completions.create method
        mock_chat = Mock()
        mock_client.chat = mock_chat
        mock_completions = Mock()
        mock_chat.completions = mock_completions
        mock_create = Mock()
        mock_completions.create = mock_create
        mock_create.return_value = Mock(
            choices=[
                Mock(
                    message=Mock(
                        content="Test response",
                        role="assistant"
                    )
                )
            ],
            usage=Mock(
                total_tokens=100,
                prompt_tokens=50,
                completion_tokens=50
            )
        )

    yield

# Set test environment variables
os.environ["TESTING"] = "true"
os.environ["SUPABASE_URL"] = "https://test.supabase.co"
os.environ["SUPABASE_ANON_KEY"] = "test-key"
os.environ["OPENAI_API_KEY"] = "sk-test-key-1234567890abcdef"

@pytest.fixture(autouse=True)
def mock_supabase():
    """Mock Supabase client for all tests."""
    mock_client = Mock(spec=Client)
    mock_client.table.return_value = Mock()
    mock_client.table().select.return_value = Mock()
    mock_client.table().select().eq.return_value = Mock()
    mock_client.table().select().eq().execute.return_value = {"data": []}
    
    # Set up the mock client in the app state
    app.state.supabase = mock_client
    
    yield mock_client

@pytest.fixture
def test_client():
    """Create a test client for the FastAPI app."""
    return TestClient(app) 