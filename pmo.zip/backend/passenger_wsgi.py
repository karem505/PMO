import sys
import os

# Add current directory (where passenger_wsgi.py lives) to sys.path
APP_DIR = os.path.dirname(__file__)
if APP_DIR not in sys.path:
    sys.path.insert(0, APP_DIR)

# Import your FastAPI app
from my_main import app

# Use Mangum to wrap your FastAPI app for WSGI compatibility
from mangum import Mangum
application = Mangum(app)