import os

# The line we need to fix is around line 524
file_path = os.path.join('backend', 'routers', 'pmo_router.py')
fixed_path = os.path.join('backend', 'routers', 'pmo_router_fixed.py')

with open(file_path, 'r') as f:
    lines = f.readlines()

# Find the problematic line that contains ")        else:"
problem_line_idx = None
for i, line in enumerate(lines):
    if ")        else:" in line:
        problem_line_idx = i
        break

if problem_line_idx is not None:
    # Split the line and fix it
    parts = lines[problem_line_idx].split(")")
    lines[problem_line_idx] = parts[0] + ")\n"
    
    # Insert proper else on the next line with correct indentation
    lines.insert(problem_line_idx + 1, "        else:\n")
    
    print(f"Fixed line {problem_line_idx+1}: Split problematic 'else' statement")
else:
    print("Could not find the problem line with ')        else:'")

# Fix the else indentation for line 217-218 as well
else_line_idx = None
for i, line in enumerate(lines):
    if i >= 200 and i <= 230 and line.strip() == "else:":
        else_line_idx = i
        break

if else_line_idx is not None:
    # Fix the indentation
    lines[else_line_idx] = "                else:\n"
    print(f"Fixed line {else_line_idx+1}: Corrected 'else' indentation")
else:
    print("Could not find the problem 'else' line around line 217")

# Fix public_url = None indentation
public_url_line_idx = None
for i, line in enumerate(lines):
    if "public_url = None" in line:
        public_url_line_idx = i
        user_context_line_idx = i + 1
        break

if public_url_line_idx is not None:
    # Fix the indentation
    lines[public_url_line_idx] = "                public_url = None\n"
    lines[user_context_line_idx] = "                user_context = {\n"
    print(f"Fixed lines {public_url_line_idx+1}-{user_context_line_idx+1}: Corrected variable indentation")
else:
    print("Could not find the 'public_url = None' line")

# Write the fixed content to a new file
with open(fixed_path, 'w') as f:
    f.writelines(lines)

print(f"Fixed content written to {fixed_path}")
print("Please check the file and if it looks correct, rename it to pmo_router.py") 