// config.ts - Updated Firebase Authentication Configuration

import { initializeApp } from "firebase/app";
import { 
  getAuth, 
  GoogleAuthProvider, 
  signInWithPopup, 
  signOut,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword as firebaseSignInWithEmailAndPassword,
  onAuthStateChanged as firebaseAuthStateChanged,
  User,
  NextOrObserver
} from "firebase/auth";
import { getAnalytics } from "firebase/analytics";
import { supabase } from '../services/supabaseClient';
import axios from "axios";
import apiClient from "../api/client";



// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBpad2_AOcLHh6dA3M5jpXd6jSNqyg3f-w",
  authDomain: "pmop-a687a.firebaseapp.com",
  projectId: "pmop-a687a",
  storageBucket: "pmop-a687a.appspot.com", // Fixed storage bucket URL
  messagingSenderId: "462374925697",
  appId: "1:462374925697:web:71da2171dc4ba36cdde480",
  measurementId: "G-HM2QCYGQWC"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// Google sign-in function with added scopes and prompt
export const signInWithGoogle = async () => {
  const auth = getAuth();
  const googleProvider = new GoogleAuthProvider();
  
  try {
    // Sign in with Firebase only
    const firebaseResult = await signInWithPopup(auth, googleProvider);
    // Extract user info
    const user = firebaseResult.user;
    return user;
  } catch (error) {
    console.error('Error during Google sign-in:', error);
    throw error;
  }
};
const provider = new GoogleAuthProvider();
provider.addScope('profile');
provider.addScope('email');
provider.setCustomParameters({
  prompt: 'select_account'
});


// Email/password sign-in function (for testing if Google auth is the specific issue)
export const signInWithEmailPassword = async (email: string, password: string): Promise<User> => {
  try {
    const userCredential = await firebaseSignInWithEmailAndPassword(auth, email, password);
    return userCredential.user;
  } catch (error) {
    console.error("Error during email/password sign in:", error);
    throw error;
  }
};

// Create a new user with email/password (for testing)
export const createUserWithEmail = async (email: string, password: string): Promise<User> => {
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    return userCredential.user;
  } catch (error) {
    console.error("Error creating user:", error);
    throw error;
  }
};

// Sign out function
export const logoutUser = async (): Promise<void> => {
  try {
    await signOut(auth);
    console.log("User signed out successfully");
  } catch (error) {
    console.error("Error signing out:", error);
    throw error;
  }
};

// Listen for auth state changes with proper typing
export const onAuthStateChanged = (callback: NextOrObserver<User>) => {
  return firebaseAuthStateChanged(auth, callback);
};

// Get current user
export const getCurrentUser = (): User | null => {
  return auth.currentUser;
};

// Check if a user is currently signed in
export const isUserSignedIn = (): boolean => {
  return auth.currentUser !== null;
};