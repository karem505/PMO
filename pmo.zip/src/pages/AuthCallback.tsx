import React, { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { supabase } from '../services/supabaseClient';
import apiClient from '../api/client';
import { useAppStore } from '../store';
import LoadingSpinner from '../components/common/LoadingSpinner';
import { createProject } from '../services/supabaseService';

const AuthCallback: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string>("Completing authentication...");
  const { createProject } = useAppStore();

  useEffect(() => {
    const handleAuthCallback = async () => {
      try {
        // If we're at the root with an error, we've been redirected incorrectly
        // Move the error parameters to a proper error handler URL
        if (location.pathname === '/' && location.search.includes('error=')) {
          console.log('Detected OAuth error at root path, redirecting to proper error handler');
          navigate({
            pathname: '/oauth-error',
            search: location.search
          });
          return;
        }

        // First step - always clean up the session storage items for troubleshooting
        const authTimestamp = sessionStorage.getItem('auth_timestamp');
        const timeSinceAuth = authTimestamp ? Math.floor((Date.now() - parseInt(authTimestamp)) / 1000) : null;
        console.log(`Auth callback received. Time since auth request: ${timeSinceAuth ? timeSinceAuth + 's' : 'unknown'}`);

        // Check for errors in the URL
        const params = new URLSearchParams(location.search);
        const hashParams = new URLSearchParams(window.location.hash.substring(1));
        
        const errorParam = params.get('error') || hashParams.get('error');
        const errorCode = params.get('error_code') || hashParams.get('error_code');
        const errorDesc = params.get('error_description') || hashParams.get('error_description');
        
        if (errorParam) {
          console.error('OAuth error detected:', {
            error: errorParam,
            code: errorCode,
            description: errorDesc,
            timeSinceAuth
          });
          
          // Clean up any OAuth-related localStorage and sessionStorage items
          sessionStorage.removeItem('newUserSignup');
          sessionStorage.removeItem('auth_timestamp');
          localStorage.removeItem('supabase_oauth_state');
          
          if (errorCode === 'bad_oauth_state') {
            throw new Error(
              "OAuth state validation failed. This typically happens if you've opened multiple sign-in tabs or " +
              "your browser is blocking third-party cookies. Please try:\n\n" +
              "1. Close all other tabs/windows of this site\n" +
              "2. Use a private/incognito window\n" +
              "3. Ensure third-party cookies are not blocked in your browser"
            );
          } else {
            throw new Error(decodeURIComponent(errorDesc || errorParam));
          }
        }

        // Verify the state parameter for security
        const stateParam = params.get('state') || hashParams.get('state');
        const savedState = localStorage.getItem('supabase_oauth_state');
        
        if (stateParam && savedState && stateParam !== savedState) {
          console.error('OAuth state mismatch:', { 
            urlState: stateParam, 
            savedState,
            timeSinceAuth
          });
          throw new Error(
            "OAuth state verification failed. This typically happens if you've opened multiple sign-in tabs or " +
            "your browser is blocking third-party cookies. Please try:\n\n" +
            "1. Close all other tabs/windows of this site\n" +
            "2. Use a private/incognito window\n" +
            "3. Ensure third-party cookies are not blocked in your browser"
          );
        }
        
        // Clean up state parameter after verification
        localStorage.removeItem('supabase_oauth_state');
        sessionStorage.removeItem('auth_timestamp');

        // Get the session to see if authentication was successful
        const { data, error: sessionError } = await supabase.auth.getSession();
        if (sessionError) throw sessionError;

        // Check if we have a valid session
        if (!data.session) {
          throw new Error('No session found after authentication');
        }

        // Set the auth token for API calls
        apiClient.defaults.headers.common['Authorization'] = `Bearer ${data.session.access_token}`;

        // Check if this is a new user by checking the newUserSignup flag
        const isNewUser = sessionStorage.getItem('newUserSignup') === 'true';
        
        if (isNewUser) {
          setMessage("Setting up your account...");
          
          try {
            console.log('Starting user setup for:', data.session.user.id);
            
            // Try multiple approaches for maximum reliability
            
            // 1. First try with the specialized Google user setup endpoint
            try {
              console.log('Attempting Google user setup with specialized endpoint');
              const googleSetupResponse = await apiClient.post('/auth/setup-google-user', {
                user_id: data.session.user.id,
                email: data.session.user.email,
                display_name: data.session.user.user_metadata?.full_name || data.session.user.email?.split('@')[0],
                photo_url: data.session.user.user_metadata?.avatar_url
              }, {
                headers: {
                  'X-User-Email': data.session.user.email
                },
                timeout: 30000 // 30 seconds timeout
              });
              
              console.log('Google user setup response:', googleSetupResponse.data);
              
              if (googleSetupResponse.data.status === 'success') {
                console.log('Google user setup successful!');
                // Successfully set up with specialized endpoint, skip other approaches
                return;
              }
            } catch (googleSetupError) {
              console.error('Google user setup failed, trying standard endpoint:', googleSetupError);
            }
            
            // 2. Next try with the standard setup endpoint
            try {
              console.log('Attempting user setup with standard endpoint');
              const setupResponse = await apiClient.post('/auth/setup-user', {
                user_id: data.session.user.id,
                email: data.session.user.email,
                display_name: data.session.user.user_metadata?.full_name || data.session.user.email?.split('@')[0],
                photo_url: data.session.user.user_metadata?.avatar_url
              });
              
              console.log('User setup response:', setupResponse.data);
              
              if (setupResponse.data.status === 'success') {
                console.log('Standard user setup successful!');
              }
            } catch (setupError) {
              console.error('Standard user setup failed, trying direct subscription setup:', setupError);
            }
            
            // 3. Try setting up subscription directly
            try {
              console.log('Attempting direct subscription setup');
              const subResponse = await apiClient.post('/subscription/setup-free', {
                user_email: data.session.user.email
              });
              
              console.log('Subscription setup response:', subResponse.data);
            } catch (subError) {
              console.error('Direct subscription setup failed:', subError);
            }
            
            // 4. Fallback to direct profile creation only (not subscription)
            try {
              // Check if profile exists
              const { data: profileExists } = await supabase
                .from('profiles')
                .select('id')
                .eq('id', data.session.user.id)
                .single();
                
              if (!profileExists) {
                console.log('Creating profile directly');
                await supabase.from('profiles').insert({
                  id: data.session.user.id,
                  email: data.session.user.email,
                  display_name: data.session.user.user_metadata?.full_name || data.session.user.email?.split('@')[0],
                  photo_url: data.session.user.user_metadata?.avatar_url,
                  created_at: new Date().toISOString(),
                  organization_name: "",
                  industry: "",
                  pmo_maturity_level: "Initial"
                });
              }
              
              // We no longer create subscriptions directly via Supabase
              // Instead, store email in localStorage for API calls
              if (data.session.user.email) {
                localStorage.setItem('userEmail', data.session.user.email);
              }
            } catch (directError) {
              console.error('Direct profile creation fallback failed:', directError);
            }
            
            // Check for existing project or create default project
            try {
              // Check if a project already exists
              const { data: projectsData } = await supabase
                .from('projects')
                .select('id')
                .eq('owner_id', data.session.user.id)
                .limit(1);
                
              if (!projectsData || projectsData.length === 0) {
                console.log('No projects found, creating default project');
                const startDate = new Date();
                const endDate = new Date();
                endDate.setMonth(endDate.getMonth() + 6); // Default: 6 month project
                
                await createProject({
                  name: 'PMO Implementation Starter',
                  description: 'Your first PMO implementation project with best practices and templates.',
                  budget: 50000,
                  startDate: startDate.toISOString(),
                  endDate: endDate.toISOString(),
                  owner_id: data.session.user.id,
                  is_default: true,
                });
                
                console.log('Default project created successfully');
              } else {
                console.log('User already has projects, skipping default project creation');
              }
            } catch (projectError) {
              console.error('Error checking/creating default project:', projectError);
              // Continue anyway - don't block the auth flow
            }
          } catch (setupError: any) {
            console.error('Error in account setup process:', setupError);
            // Continue anyway - attempt to create profile directly
            
            try {
              // Direct profile creation attempt
              const { error: profileError } = await supabase
                .from('profiles')
                .insert([{
                  id: data.session.user.id,
                  email: data.session.user.email,
                  display_name: data.session.user.user_metadata?.full_name || data.session.user.email?.split('@')[0],
                  photo_url: data.session.user.user_metadata?.avatar_url,
                  created_at: new Date().toISOString(),
                  organization_name: "",
                  industry: "",
                  pmo_maturity_level: "Initial"
                }]);
                
              if (profileError) {
                console.error('Direct profile creation failed:', profileError);
              } else {
                console.log('Direct profile creation succeeded');
                // Try to set up subscription via API
                if (data.session.user.email) {
                  localStorage.setItem('userEmail', data.session.user.email);
                  try {
                    await apiClient.post('/subscription/setup-free', {
                      user_email: data.session.user.email
                    });
                    console.log('API subscription setup succeeded');
                  } catch (apiError) {
                    console.error('API subscription setup failed:', apiError);
                  }
                }
              }
            } catch (directError) {
              console.error('Direct profile creation failed:', directError);
            }
          }
        }
        
        // Clean up session storage
        sessionStorage.removeItem('newUserSignup');
        
        // Redirect to dashboard
        setMessage("Authentication successful! Redirecting...");
        navigate('/dashboard');
        
      } catch (error) {
        console.error('Auth callback error:', error);
        setError(error instanceof Error ? error.message : 'Authentication error');
        
        // Cleanup any remaining storage items
        sessionStorage.removeItem('newUserSignup');
        sessionStorage.removeItem('auth_timestamp');
        localStorage.removeItem('supabase_oauth_state');
        
        // Redirect to login after a delay
        setTimeout(() => {
          navigate('/login');
        }, 3000);
      }
    };

    handleAuthCallback();
  }, [navigate, location, createProject]);

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="max-w-md w-full bg-white rounded-lg shadow-md p-8">
          <h2 className="text-xl font-semibold text-red-600 mb-2">Authentication Error</h2>
          <p className="text-gray-700">{error}</p>
          <p className="mt-4 text-sm text-gray-500">Redirecting to login page...</p>
        </div>
      </div>
    );
  }

  return <LoadingSpinner fullScreen text={message} />;
};

export default AuthCallback;