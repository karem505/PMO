import React, { useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../components/auth/AuthContext';
import { CheckCircle, ChevronRight, ArrowRight, Building2, Layers, Settings, Users, Target, Sparkles, Menu, X } from 'lucide-react';
import Logo from '../components/Logo';
import '../css/landing-animations.css';

const LandingPage: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { currentUser, isLoading } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);
  const menuRef = React.useRef<HTMLDivElement>(null);
  
  // Handle OAuth errors that might get redirected to root
  useEffect(() => {
    // If there's an error in the URL, redirect to the OAuth error handler
    if (location.search && location.search.includes('error=')) {
      console.log('Detected OAuth error parameters at root, redirecting to proper handler');
      
      // Clean up any lingering OAuth state
      localStorage.removeItem('supabase_oauth_state');
      localStorage.removeItem('newUserSignup');
      
      // Redirect to the OAuth error handler
      navigate({
        pathname: '/oauth-error',
        search: location.search
      });
    }
  }, [location, navigate]);
  
  // Close menu when clicking outside
  React.useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setMobileMenuOpen(false);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
  
  // Redirect authenticated users to dashboard
  React.useEffect(() => {
    if (currentUser && !isLoading) {
      navigate('/dashboard');
    }
  }, [currentUser, isLoading, navigate]);

  // If still loading auth state, don't render anything yet
  // if (isLoading) {
  //   return null;
  // }
  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gray-50">
        <div className="w-full max-w-md">
          <div className="bg-white px-8 py-10 shadow-md rounded-lg text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
            <p className="mt-4 text-gray-600">Loading...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div dir='ltr' className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
      {/* Header */}
      <header ref={menuRef} className='sticky top-0 z-50 bg-white md:bg-white shadow-md md:shadow-none '>
        <div className="px-4 bg-white md:bg-transparent shadow-md md:shadow-none py-4 md:py-6 mx-auto max-w-7xl">
          <div className="flex items-center justify-between">
            <Logo />
            
            <div className="flex items-center gap-x-6">
              <nav className="hidden gap-6 md:flex">
                <Link to="/pricing" className="text-gray-600 hover:text-primary-600 transition-colors">Pricing</Link>
                <a href="#features" className="text-gray-600 hover:text-primary-600 transition-colors">Features</a>
                <a href="#domains" className="text-gray-600 hover:text-primary-600 transition-colors">PMO Domains</a>
              </nav>
              
              <div className="hidden md:flex items-center gap-x-3">
                <button 
                  className="px-4 py-2 text-gray-700 transition-colors bg-white rounded-lg shadow-sm hover:bg-gray-50"
                  onClick={() => navigate('/login')}
                >
                  Sign in
                </button>
                <button 
                  className="px-4 py-2 text-white transition-colors rounded-lg shadow-sm bg-primary-600 hover:bg-primary-700"
                  onClick={() => navigate('/register')}
                >
                  Get Started
                </button>
              </div>
              
              {/* Mobile menu button */}
              <button 
                className="md:hidden p-2 text-gray-600 hover:text-primary-600 focus:outline-none"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
          
          {/* Mobile menu */}
          {mobileMenuOpen && (
            <div className="md:hidden mt-t py-4 absolute top-16 inset-x-0 bg-white rounded-lg shadow-lg">
              <nav className="flex flex-col space-y-4 px-6">
                <a 
                  href="#features" 
                  className="text-gray-600 hover:text-primary-600 transition-colors py-2"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Features
                </a>
                <a 
                  href="#domains" 
                  className="text-gray-600 hover:text-primary-600 transition-colors py-2"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  PMO Domains
                </a>
                <div className="pt-4 mt-4 border-t border-gray-100 flex flex-col gap-y-3">
                  <button 
                    className="w-full px-4 py-2 text-gray-700 transition-colors bg-gray-50 rounded-lg hover:bg-gray-100"
                    onClick={() => {
                      navigate('/login');
                      setMobileMenuOpen(false);
                    }}
                  >
                    Sign in
                  </button>
                  <button 
                    className="w-full px-4 py-2 text-white transition-colors rounded-lg bg-primary-600 hover:bg-primary-700"
                    onClick={() => {
                      navigate('/register');
                      setMobileMenuOpen(false);
                    }}
                  >
                    Get Started
                  </button>
                </div>
              </nav>
            </div>
          )}
        </div>
      </header>

      {/* Hero Section */}
      <section className="px-4 py-16 mx-auto max-w-7xl md:py-24">
        <div className="grid items-center gap-12 md:grid-cols-2">
          <div className="space-y-8 md:pr-12">
            <h1 className="text-4xl font-bold text-start tracking-tight text-gray-900 md:text-5xl">
              Build Your <span className="bg-gradient-to-r from-primary-600 to-secondary-600 bg-clip-text text-transparent">Project Management Office</span> With AI
            </h1>
            <p className="text-xl text-start text-gray-600">
              Create a world-class PMO with our comprehensive platform that guides you through all key domains using AI-powered recommendations and templates.
            </p>
            <div className="flex flex-col gap-y-3 sm:gap-y-0 sm:gap-x-4 sm:flex-row">
              <button 
                className="px-6 py-3 text-white transition-colors rounded-lg shadow-md bg-primary-600 hover:bg-primary-700 flex items-center justify-center"
                onClick={() => navigate('/register')}
              >
                Start Building Your PMO
                <ChevronRight className="w-5 h-5 ms-1 " />
              </button>
              <a 
                href="#domains"
                className="flex items-center justify-center px-6 py-3 space-x-2 text-gray-700 transition-colors bg-white rounded-lg shadow-md hover:bg-gray-50"
              >
                Explore PMO Domains
              </a>
            </div>
            <div className="flex items-center gap-x-4">
              <div className="flex -gap-x-2">
                <img 
                  src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" 
                  className="w-8 h-8 border-2 border-white rounded-full" 
                  alt="User"
                />
                <img 
                  src="https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" 
                  className="w-8 h-8 border-2 border-white rounded-full" 
                  alt="User"
                />
                <img 
                  src="https://images.unsplash.com/photo-1520813792240-56fc4a3765a7?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" 
                  className="w-8 h-8 border-2 border-white rounded-full" 
                  alt="User"
                />
              </div>
              <p className="text-sm text-gray-600">Join 2,000+ PMO professionals</p>
            </div>
          </div>
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-primary-500/30 to-secondary-500/30 rounded-xl filter blur-3xl opacity-70 animate-pulse-slow"></div>
            <div className="relative p-6 overflow-hidden bg-white border border-gray-200 rounded-xl shadow-xl">
              <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-primary-600/20 to-secondary-600/20 rounded-bl-3xl"></div>
              <div className="p-4 mb-4 bg-gradient-to-br from-primary-50 to-secondary-50 rounded-lg">
                <h3 className="text-lg font-medium text-start text-gray-800">PMO Maturity Assessment</h3>
                <div className="flex items-center mt-2 gap-x-2">
                  <div className="w-full h-2 rounded-full bg-gray-200">
                    <div className="h-2 rounded-full bg-primary-500 animate-widthGrow" style={{ width: "75%" }}></div>
                  </div>
                  <span className="text-sm font-medium text-gray-600">75%</span>
                </div>
              </div>
              <div className="space-y-3">
                {[
                  { name: "Organizational Alignment", progress: 90 },
                  { name: "Strategic Framework", progress: 65 },
                  { name: "PMO Structure", progress: 80 },
                  { name: "Operational Excellence", progress: 50 }
                ].map((domain, i) => (
                  <div key={i} className="flex items-center">
                    <div className="w-8 h-8 me-3 rounded-lg bg-gradient-to-br from-primary-100 to-secondary-100 flex items-center justify-center">
                      <CheckCircle className={domain.progress > 70 ? "w-5 h-5 text-green-500" : "w-5 h-5 text-gray-400"} />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h4 className="text-sm font-medium text-gray-700">{domain.name}</h4>
                        <span className="text-xs font-medium text-gray-500">{domain.progress}%</span>
                      </div>
                      <div className="w-full h-1.5 mt-1 rounded-full bg-gray-100">
                        <div
                          className="h-1.5 rounded-full bg-gradient-to-r from-primary-500 to-secondary-500"
                          style={{ width: `${domain.progress}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex justify-between mt-6">
                <button onClick={() => navigate('/login')} className="text-sm font-medium text-primary-600 hover:text-primary-700 flex items-center">
                  View All Domains
                  <ArrowRight className="w-4 h-4 ms-1 " />
                </button>
                <button onClick={() => navigate('/login?redirect=/dashboard/maturity-assessment')} className="px-3 py-1.5 text-white text-sm rounded bg-primary-600 hover:bg-primary-700">
                  Start Assessment
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Video Introduction Section */}
      <section className="px-4 py-16 bg-white">
        <div className="mx-auto max-w-5xl">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">Watch How It Works</h2>
            <p className="max-w-2xl mx-auto mt-4 text-xl text-gray-600">
              Learn how PMO Builder can transform your Project Management Office
            </p>
          </div>
          
          <div className="relative bg-white rounded-xl shadow-lg overflow-hidden">
            <div style={{padding:'75% 0 0 0', position:'relative'}}>
              <iframe 
                src="https://player.vimeo.com/video/1082209469?h=9228a60555&amp;badge=0&amp;autopause=0&amp;player_id=0&amp;app_id=58479" 
                frameBorder="0" 
                allow="autoplay; fullscreen; picture-in-picture; clipboard-write; encrypted-media" 
                style={{position:'absolute', top:0, left:0, width:'100%', height:'100%'}} 
                title="PMO Builder Introductory Video"
              ></iframe>
            </div>
            <script src="https://player.vimeo.com/api/player.js"></script>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="px-4 py-16 bg-white">
        <div className="mx-auto max-w-7xl">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">Comprehensive PMO Building Features</h2>
            <p className="max-w-2xl mx-auto mt-4 text-xl text-gray-600">
              Everything you need to establish, grow, and optimize your Project Management Office
            </p>
          </div>
          
          <div className="grid gap-8 mt-12 sm:grid-cols-2 lg:grid-cols-3">
            {[
              {
                title: "AI-Powered Templates",
                description: "Generate custom templates tailored to your organization's specific needs and context.",
                icon: Sparkles,
                color: "bg-purple-100 text-purple-600"
              },
              {
                title: "Maturity Assessment",
                description: "Evaluate your PMO's maturity across all domains with detailed improvement recommendations.",
                icon: Target,
                color: "bg-blue-100 text-blue-600"
              },
              {
                title: "Domain Guidance",
                description: "Step-by-step guidance for each PMO domain with best practices and implementation tips.",
                icon: Layers,
                color: "bg-green-100 text-green-600"
              },
              {
                title: "Strategic Alignment",
                description: "Ensure your PMO is perfectly aligned with your organization's strategic objectives.",
                icon: Building2,
                color: "bg-amber-100 text-amber-600"
              },
              {
                title: "Process Optimization",
                description: "Optimize your PMO processes with proven frameworks and methodologies.",
                icon: Settings,
                color: "bg-red-100 text-red-600"
              },
              {
                title: "Team Collaboration",
                description: "Collaborate with your team on PMO implementation with shared workspaces.",
                icon: Users,
                color: "bg-indigo-100 text-indigo-600"
              }
            ].map((feature, i) => (
              <div key={i} className="p-6 transition-all duration-300 border border-gray-200 rounded-xl hover:shadow-md hover:border-primary-200 hover-lift">
                <div className={`p-3 w-14 h-14 mb-4 rounded-lg flex items-center justify-center ${feature.color}`}>
                  <feature.icon className="w-7 h-7" />
                </div>
                <h3 className="mb-2 text-xl font-semibold text-start text-gray-800">{feature.title}</h3>
                <p className="text-gray-600 text-start">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Domains Section */}
      <section id="domains" className="px-4 py-16 bg-gray-50">
        <div className="mx-auto max-w-7xl">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">PMO Domains Framework</h2>
            <p className="max-w-2xl mx-auto mt-4 text-xl text-gray-600">
              Our comprehensive framework covers all aspects of successful PMO implementation
            </p>
          </div>
          
          <div className="grid gap-6 mt-12 md:grid-cols-2 lg:grid-cols-3">
            {[
              {
                title: "Organizational Development & Alignment",
                description: "Align the PMO with organizational strategy and culture to maximize value delivery.",
                icon: Building2
              },
              {
                title: "Strategic Framework & Governance",
                description: "Develop robust governance structures and strategic frameworks for effective oversight.",
                icon: Layers
              },
              {
                title: "PMO Structure & Design",
                description: "Create the optimal PMO structure with clear roles, responsibilities, and services.",
                icon: Building2
              },
              {
                title: "Operational Excellence",
                description: "Establish efficient operational processes, metrics, and performance standards.",
                icon: Settings 
              },
              {
                title: "Performance & Improvement",
                description: "Continuously improve PMO services, capabilities, and value delivery.",
                icon: Target
              },
              {
                title: "Capability Development",
                description: "Develop the human aspects of PMO including competency, training, and leadership.",
                icon: Users
              }
            ].map((domain, i) => (
              <div key={i} className="overflow-hidden transition-all duration-300 bg-white border border-gray-200 rounded-xl hover:shadow-md hover:border-primary-200 hover-lift">
                <div className="p-6">
                  <div className="p-3 w-12 h-12 mb-4 rounded-lg bg-primary-100 flex items-center justify-center">
                    <domain.icon className="w-6 h-6 text-primary-600" />
                  </div>
                  <h3 className="mb-2 text-lg font-semibold text-start text-gray-800">{domain.title}</h3>
                  <p className="text-sm text-start text-gray-600">{domain.description}</p>
                </div>
                <div className="px-6 py-4 bg-gray-50 border-t border-gray-100">
                  <div className="flex justify-between items-center">
                    <div>
                      <span className="text-xs text-gray-500">Input → Processing → Output</span>
                      <div className="w-full mt-1 bg-gray-200 rounded-full h-1.5">
                        <div className="bg-primary-600 h-1.5 rounded-full" style={{ width: '30%' }}></div>
                      </div>
                    </div>
                    <button className="text-sm font-medium text-primary-600 hover:text-primary-700 flex items-center">
                      Explore
                      <ChevronRight className="w-4 h-4 ms-1 " />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="px-4 py-16 text-white bg-gradient-to-r from-primary-600 to-secondary-600">
        <div className="mx-auto text-center max-w-7xl">
          <h2 className="text-3xl font-bold sm:text-4xl">Ready to build your PMO?</h2>
          <p className="max-w-2xl mx-auto mt-4 text-xl text-primary-100">
            Start your journey today and transform your project management capabilities
          </p>
          <div className="flex flex-col items-center justify-center mt-8 gap-y-4 sm:gap-y-0 sm:gap-x-4 sm:flex-row">
            <button 
              className="px-8 py-3 text-primary-700 bg-white rounded-lg shadow-lg hover:bg-gray-100"
              onClick={() => navigate('/register')}
            >
              Get Started for Free
            </button>
            <a href="#features" className="flex items-center text-primary-100 hover:text-white">
              Learn more
              <ChevronRight className="w-5 h-5 ms-1 " />
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="px-4 py-12 bg-gray-900 text-gray-300">
        <div className="mx-auto max-w-7xl">
          <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
            <div>
              <h3 className="mb-4 text-lg font-semibold text-white">PMO Builder</h3>
              <ul className="space-y-2">
                <li><a href="#" className="hover:text-white">About Us</a></li>
                <li><a href="#" className="hover:text-white">Features</a></li>
                <li><a href="#" className="hover:text-white">Pricing</a></li>
                <li><a href="#" className="hover:text-white">Careers</a></li>
              </ul>
            </div>
            <div>
              <h3 className="mb-4 text-lg font-semibold text-white">Resources</h3>
              <ul className="space-y-2">
                <li><a href="#" className="hover:text-white">Blog</a></li>
                <li><a href="#" className="hover:text-white">Documentation</a></li>
                <li><a href="#" className="hover:text-white">Guides</a></li>
                <li><a href="#" className="hover:text-white">Support</a></li>
              </ul>
            </div>
            <div>
              <h3 className="mb-4 text-lg font-semibold text-white">Legal</h3>
              <ul className="space-y-2">
                <li><a href="#" className="hover:text-white">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-white">Terms of Service</a></li>
                <li><a href="#" className="hover:text-white">Data Processing</a></li>
                <li><a href="#" className="hover:text-white">Cookie Policy</a></li>
              </ul>
            </div>
            <div>
              <h3 className="mb-4 text-lg font-semibold text-white">Contact</h3>
              <ul className="space-y-2">
                <li><a href="#" className="hover:text-white">Contact Us</a></li>
                <li><a href="#" className="hover:text-white">Support</a></li>
                <li><a href="#" className="hover:text-white">Sales</a></li>
              </ul>
            </div>
          </div>
          <div className="pt-8 mt-8 text-sm text-center border-t border-gray-800">
            <p>© 2025 PMO Builder. All rights reserved.</p>
            <p className="mt-2">Created by Dr. Ahmed Alsenosy</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;