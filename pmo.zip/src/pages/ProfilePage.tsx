import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppStore } from '../store';
import { Building, Save, User } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
const ProfilePage: React.FC = () => {
  const navigate = useNavigate();
  const { userData, updateUserProfile } = useAppStore();
  const { t } = useLanguage();
  const [formData, setFormData] = useState({
    organizationName: userData.organizationName || '',
    industry: userData.industry || '',
    pmoMaturityLevel: userData.pmoMaturityLevel || 'Initial'
  });
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateUserProfile(formData);
    navigate('/');
  };
  
  return (
    <div className="max-w-3xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold  text-neutral-800 dark:text-neutral-200">
            {t('profile.title')}
          </h1>
          <p className="text-gray-600 dark:text-gray-300 mt-1">
            {t('profile.description')}
          </p>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow-sm p-6">
        <form onSubmit={handleSubmit}>
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {t('profile.organizationName')}
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 start-0 ps-3 flex items-center pointer-events-none">
                  <Building className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  name="organizationName"
                  value={formData.organizationName}
                  onChange={handleChange}
                  className="ps-10  block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-neutral-800 px-3 py-2 sm:text-sm"
                  placeholder={t('profile.organizationNamePlaceholder')}
                />
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {t('profile.industry')}
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 start-0 ps-3 flex items-center pointer-events-none">
                  <User className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  name="industry"
                  value={formData.industry}
                  onChange={handleChange}
                  className="ps-10 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-neutral-800 px-3 py-2 sm:text-sm"
                  placeholder={t('profile.industryPlaceholder')}
                />
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {t('profile.pmoMaturityLevel')}
              </label>
              <select
                name="pmoMaturityLevel"
                value={formData.pmoMaturityLevel}
                onChange={handleChange}
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-neutral-800 px-3 py-2 sm:text-sm"
              >
                <option value="Initial">{t('profile.initial')}</option>
                <option value="Defined">{t('profile.defined')}</option>
                <option value="Managed">{t('profile.managed')}</option>
                <option value="Optimized">{t('profile.optimized')}</option>
                <option value="Not Established">{t('profile.notEstablished')}</option>
              </select>
              <p className="mt-1 text-sm text-gray-500">
                {t('profile.selectTheMaturityLevelThatBestDescribesYourCurrentPMO')}
              </p>
            </div>
            
            <div className="pt-4 border-t border-gray-200 flex justify-end">
              <button
                type="button"
                className="me-3 px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
                onClick={() => navigate('/')}
              >
                {t('profile.cancel')}
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center"
              >
                <Save className="h-4 w-4 me-1" />
                {t('profile.saveProfile')}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ProfilePage;