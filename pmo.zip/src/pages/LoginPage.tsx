import React, { useEffect, useState, Suspense } from 'react';
import { useNavigate, Link, useLocation } from 'react-router-dom';
import { LogIn, AlertCircle, Info, CheckCircle2, ChevronRight, User, Mail, Lock, Eye, EyeOff, AlertTriangle } from 'lucide-react';
import { useAuth } from '../components/auth/AuthContext';
import { supabase } from '../services/supabaseClient';
import Logo from '../components/Logo';
import { signInWithEmail, sendPasswordReset } from '../services/supabaseService';
import apiClient from '../api/client';
import { useOnboarding } from '../contexts/OnboardingContext';
import { useLanguage } from '../contexts/LanguageContext';
import ErrorBoundary from '../components/common/ErrorBoundary';
import LoadingSpinner from '../components/common/LoadingSpinner';

const LoginPage: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser, isLoading } = useAuth();
  const { setIsFirstLogin } = useOnboarding();
  const [error, setError] = useState<string | null>(null);
  const [isSigningIn, setIsSigningIn] = useState(false);
  const [signInSuccess, setSignInSuccess] = useState(false);
  const [loginMethod, setLoginMethod] = useState<'google' | 'email'>('email');
  const [infoMessage, setInfoMessage] = useState<string | null>(null);
  
  // Email login form state
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [resetSent, setResetSent] = useState(false);
  const [isSendingReset, setIsSendingReset] = useState(false);
  
  // Form validation
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const location = useLocation();
  const redirect = location.search?.split('=')[1] || '/';
  console.log({location , redirect});

  const { t } = useLanguage();

  // Check for OAuth redirect and verify user exists
  useEffect(() => {
    const checkAuthRedirect = async () => {
      const { data: authData } = await supabase.auth.getSession();
      
      if (authData?.session) {
        // User is authenticated, check if they exist in your profiles table
        const { data: userProfile, error: profileError } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', authData.session.user.id)
          .single();
        
        // If no profile exists, this might be a new sign in
        if (profileError || !userProfile) {
          // Sign the user out since they shouldn't be logged in yet
          await supabase.auth.signOut();
          setError('Please sign up first before attempting to log in.');
          setIsSigningIn(false);
        } else {
          // User exists, continue with sign in process
          console.log('Sign in successful');
          // Navigation will be handled by the other useEffect
        }
      }
    };
    
    checkAuthRedirect();
  }, []);
  
  useEffect(() => {
    // If already logged in, redirect to dashboard
    if (currentUser && !isLoading) {
      navigate(redirect);
    }
    
    // Check for verification success message in URL
    const urlParams = new URLSearchParams(window.location.search);
    const verificationStatus = urlParams.get('emailVerified');
    if (verificationStatus === 'true') {
      setInfoMessage("Your email has been verified! Please sign in to continue.");
    }
    
    // Check for password reset message
    const resetStatus = urlParams.get('passwordReset');
    if (resetStatus === 'true') {
      setInfoMessage("Your password has been reset! Please sign in with your new password.");
    }
    
    // Check for session expired message
    const sessionExpired = urlParams.get('sessionExpired');
    if (sessionExpired === 'true') {
      setInfoMessage("Your session has expired. Please sign in again.");
    }

    // Store redirect path if it exists in query params
    if (redirect && redirect !== '/') {
      localStorage.setItem('redirectAfterLogin', redirect);
    }

    // Check for new user flag for Google sign-in
    const isNewUser = localStorage.getItem('newUserSignup') === 'true';
    if (isNewUser && currentUser) {
      // Clear the flag since user is now logged in
      localStorage.removeItem('newUserSignup');
      
      // Set up free subscription if needed
      try {
        if (currentUser.email) {
          localStorage.setItem('userEmail', currentUser.email);
          apiClient.post('/subscription/setup-free', {
            user_email: currentUser.email
          }).catch(error => {
            console.error('Error setting up free subscription for Google user:', error);
          });
        }
      } catch (error) {
        console.error('Error setting up free subscription for Google user:', error);
      }
    }
  }, [currentUser, isLoading, navigate, redirect]);
  
  const validateEmail = (email: string): boolean => {
    if (!email) {
      setEmailError('Email is required');
      return false;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      setEmailError('Please enter a valid email address');
      return false;
    }
    setEmailError('');
    return true;
  };
  
  const validatePassword = (password: string): boolean => {
    if (!password) {
      setPasswordError('Password is required');
      return false;
    }
    if (password.length < 6) {
      setPasswordError('Password must be at least 6 characters');
      return false;
    }
    setPasswordError('');
    return true;
  };
  
  const handleGoogleSignIn = async () => {
    setIsSigningIn(true);
    setError(null);
    
    try {
      // Set newUserSignup flag before initiating sign in
      sessionStorage.setItem('newUserSignup', 'true');
      
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: `${import.meta.env.VITE_API_BASE_URL || window.location.origin}/auth/callback`
        }
      });

      if (error) {
        sessionStorage.removeItem('newUserSignup');
        throw error;
      }
    } catch (error: any) {
      console.error('Error signing in with Google:', error);
      setError(error.message || 'Failed to sign in with Google');
      setIsSigningIn(false);
      sessionStorage.removeItem('newUserSignup');
    }
  };
  
  const handleEmailSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate form
    const isEmailValid = validateEmail(email);
    const isPasswordValid = validatePassword(password);
    
    if (!isEmailValid || !isPasswordValid) {
      return;
    }
    
    try {
      setError(null);
      setIsSigningIn(true);
      
      const data= await supabase.auth.signInWithPassword({
        email,
        password
      });
      if (data.error) throw data.error;
      
      setSignInSuccess(true);
      
      // Check if this is the user's first login to trigger onboarding
      const tourCompleted = localStorage.getItem(`onboardingTourCompleted_${email}`);
      if (!tourCompleted) {
        setIsFirstLogin(true);
      }
      
      // Small delay to show success state
      setTimeout(() => {
        navigate('/');
      }, 1000);
    } catch (error: any) {
      console.error('Error signing in with email:', error);
      
      if (error.message === 'Invalid login credentials') {
        setError('Incorrect email or password. Please try again.');
      } else {
        setError(error.message || 'Failed to sign in. Please try again.');
      }
      
      setIsSigningIn(false);
    }
  };
  
  const handlePasswordReset = async () => {
    if (!validateEmail(email)) {
      return;
    }
    
    setIsSendingReset(true);
    
    try {
      await sendPasswordReset(email);
      setResetSent(true);
      setError(null);
    } catch (error: any) {
      console.error('Error sending password reset:', error);
      setError(error.message || 'Failed to send password reset email. Please try again.');
    } finally {
      setIsSendingReset(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gray-50">
        <div className="w-full max-w-md">
          <div className="bg-white px-8 py-10 shadow-md rounded-lg text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
            <p className="mt-4 text-gray-600">Loading...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <ErrorBoundary
      fallbackRender={({ error, resetErrorBoundary }) => (
        <div className="min-h-[calc(100vh-64px)] flex items-center justify-center bg-neutral-50">
          <div className="text-center px-4 max-w-md">
            <AlertTriangle className="h-12 w-12 text-amber-500 mx-auto mb-4" />
            <h1 className="text-3xl font-bold text-neutral-800 mb-2">Something went wrong</h1>
            <p className="text-neutral-600 mb-8">
              {error.message || 'An unexpected error occurred. Please try again.'}
            </p>
            <button
              onClick={resetErrorBoundary}
              className="px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 transition-colors"
            >
              Try Again
            </button>
          </div>
        </div>
      )}
    >
      <Suspense fallback={<LoadingSpinner fullScreen text="Loading login page..." />}>
        <div dir='ltr' className="flex min-h-screen flex-col bg-gray-50 py-12 sm:px-6 lg:px-8">
          <div className="sm:mx-auto sm:w-full sm:max-w-md">
            <div className="flex justify-center">
              <Logo variant="auth" />
            </div>
            <h2 className="mt-6 text-center text-3xl font-bold tracking-tight text-gray-900">
              Welcome to PMO Builder using AI
            </h2>
            <p className="mt-2 text-center text-sm text-gray-600">
              Sign in to access your PMO builder dashboard and team collaboration tools
            </p>
          </div>

          <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
            <div className="bg-white px-6 py-8 shadow-md sm:rounded-lg sm:px-10">
              {error && (
                <div className="mb-4 rounded-md bg-red-50 p-4">
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <AlertCircle className="h-5 w-5 text-red-400" aria-hidden="true" />
                    </div>
                    <div className="ms-3">
                      <h3 className="text-sm font-medium text-red-800">
                        Sign-in error
                      </h3>
                      <div className="mt-2 text-sm text-red-700">
                        <p>{error}</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              
              {infoMessage && (
                <div className="mb-4 rounded-md bg-blue-50 p-4">
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <Info className="h-5 w-5 text-blue-400" aria-hidden="true" />
                    </div>
                    <div className="ms-3">
                      <div className="text-sm text-blue-700">
                        <p>{infoMessage}</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              
              {resetSent && (
                <div className="mb-4 rounded-md bg-green-50 p-4">
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <CheckCircle2 className="h-5 w-5 text-green-400" aria-hidden="true" />
                    </div>
                    <div className="ms-3 flex flex-col">
                      <h3 className="text-sm me-auto font-medium text-green-800">
                        Password reset email sent
                      </h3>
                      <div className="mt-2 text-sm text-green-700">
                        <p>Please check your email to reset your password.</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              <div className="space-y-6">
                {/* Login Method Tabs */}
                <div className="flex border-b border-gray-200">
                  <button
                    className={`py-2 px-4 font-medium text-sm flex-1 text-center ${
                      loginMethod === 'email'
                        ? 'border-b-2 border-blue-500 text-blue-600'
                        : 'text-gray-500 hover:text-gray-700'
                    }`}
                    onClick={() => setLoginMethod('email')}
                  >
                    <Mail className="h-4 w-4 inline me-2" />
                    Email
                  </button>
                  <button
                    className={`py-2 px-4 font-medium text-sm flex-1 text-center ${
                      loginMethod === 'google'
                        ? 'border-b-2 border-blue-500 text-blue-600'
                        : 'text-gray-500 hover:text-gray-700'
                    }`}
                    onClick={() => setLoginMethod('google')}
                  >
                    <svg className="h-4 w-4 inline me-2" aria-hidden="true" viewBox="0 0 24 24">
                      <path
                        d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                        fill="#4285F4"
                      />
                      <path
                        d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                        fill="#34A853"
                      />
                      <path
                        d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                        fill="#FBBC05"
                      />
                      <path
                        d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                        fill="#EA4335"
                      />
                    </svg>
                    Google
                  </button>
                </div>
                
                {loginMethod === 'email' ? (
                  <form id="login-form" className="space-y-6" onSubmit={handleEmailSignIn}>
                    <div className='flex flex-col'>
                      <label htmlFor="email" className="block me-auto text-sm font-medium text-gray-700">
                        Email address
                      </label>
                      <div className="relative mt-1">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <Mail className="h-5 w-5 text-gray-400" />
                        </div>
                        <input
                          id="email"
                          name="email"
                          type="email"
                          autoComplete="email"
                          required
                          className={`block w-full pl-10 pr-3 py-2 border rounded-md shadow-sm focus:ring-blue-500 text-accent-800 focus:border-blue-500 sm:text-sm ${
                            emailError ? 'border-red-300' : 'border-gray-300'
                          }`}
                          placeholder="you@example.com"
                          value={email}
                          onChange={(e) => {
                            setEmail(e.target.value);
                            if (e.target.value) validateEmail(e.target.value);
                          }}
                          onBlur={() => validateEmail(email)}
                        />
                      </div>
                      {emailError && (
                        <p className="mt-1 text-xs text-red-600">{emailError}</p>
                      )}
                    </div>

                    <div className='flex flex-col'>
                      <label htmlFor="password" className="block me-auto text-sm font-medium text-gray-700">
                        Password
                      </label>
                      <div className="relative mt-1">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <Lock className="h-5 w-5 text-gray-400" />
                        </div>
                        <input
                          id="password"
                          name="password"
                          type={showPassword ? "text" : "password"}
                          autoComplete="current-password"
                          required
                          className={`block w-full pl-10 pr-10 py-2 border rounded-md shadow-sm focus:ring-blue-500 text-gray-800 focus:border-blue-500 sm:text-sm ${
                            passwordError ? 'border-red-300' : 'border-gray-300'
                          }`}
                          placeholder="••••••••"
                          value={password}
                          onChange={(e) => {
                            setPassword(e.target.value);
                            if (e.target.value) validatePassword(e.target.value);
                          }}
                          onBlur={() => validatePassword(password)}
                        />
                        <button
                          type="button"
                          className="absolute inset-y-0 right-0 pr-3 flex items-center"
                          onClick={() => setShowPassword(!showPassword)}
                        >
                          {showPassword ? (
                            <EyeOff className="h-5 w-5 text-gray-400" />
                          ) : (
                            <Eye className="h-5 w-5 text-gray-400" />
                          )}
                        </button>
                      </div>
                      {passwordError && (
                        <p className="mt-1 text-xs text-red-600">{passwordError}</p>
                      )}
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <input
                          id="remember-me"
                          name="remember-me"
                          type="checkbox"
                          className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                        />
                        <label htmlFor="remember-me" className="ms-2 block text-sm text-gray-700">
                          Remember me
                        </label>
                      </div>

                      <button
                        type="button"
                        className="text-sm font-medium text-blue-600 hover:text-blue-500"
                        onClick={handlePasswordReset}
                        disabled={isSendingReset}
                      >
                        {isSendingReset ? 'Sending...' : 'Forgot password?'}
                      </button>
                    </div>

                    <div>
                      <button
                        type="submit"
                        className={`w-full flex justify-center items-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 ${
                          isSigningIn ? 'opacity-75 cursor-not-allowed' : ''
                        }`}
                        disabled={isSigningIn}
                      >
                        {isSigningIn ? (
                          <>
                            <div className="me-3 h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent"></div>
                            Signing in...
                          </>
                        ) : signInSuccess ? (
                          <>
                            <CheckCircle2 className="me-3 h-5 w-5 text-white" />
                            Sign in successful!
                          </>
                        ) : (
                          <>Sign in</>
                        )}
                      </button>
                    </div>
                  </form>
                ) : (
                  <button
                    onClick={handleGoogleSignIn}
                    disabled={isSigningIn}
                    className={`flex w-full justify-center items-center rounded-md border px-4 py-3 text-sm font-medium shadow-sm transition-colors ${
                      isSigningIn 
                        ? 'bg-gray-100 text-gray-400 cursor-not-allowed' 
                        : signInSuccess
                        ? 'bg-green-50 text-green-700 border-green-300'
                        : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    {isSigningIn ? (
                      <>
                        <div className="me-3 h-4 w-4 animate-spin rounded-full border-2 border-gray-500 border-t-transparent"></div>
                        Signing in...
                      </>
                    ) : signInSuccess ? (
                      <>
                        <CheckCircle2 className="me-3 h-5 w-5 text-green-600" />
                        Sign in successful!
                      </>
                    ) : (
                      <>
                        <svg className="me-3 h-5 w-5" aria-hidden="true" viewBox="0 0 24 24">
                          <path
                            d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                            fill="#4285F4"
                          />
                          <path
                            d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                            fill="#34A853"
                          />
                          <path
                            d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                            fill="#FBBC05"
                          />
                          <path
                            d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                            fill="#EA4335"
                          />
                        </svg>
                        Sign in with Google
                      </>
                    )}
                  </button>
                )}

                <div className="relative mt-6">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-gray-300" />
                  </div>
                  <div className="relative flex justify-center text-sm">
                    <span className="bg-white px-2 text-gray-500">New to PMO Builder using AI?</span>
                  </div>
                </div>
                
                <div className="mt-6">
                  <Link 
                    to="/register" 
                    className="flex w-full justify-center items-center rounded-md border border-transparent bg-blue-600 px-4 py-3 text-sm font-medium text-white shadow-sm hover:bg-blue-700"
                  >
                    Create an account
                    <ChevronRight className="ms-2 h-4 w-4" />
                  </Link>
                </div>
              </div>
            </div>

            <div className="mt-8 text-center">
              <p className="text-xs text-gray-500">
                By signing in, you agree to our Terms of Service and Privacy Policy.
              </p>
              <p className="mt-4 text-sm">
                <a href="#" className="font-medium text-blue-600 hover:text-blue-500">
                  Need help? Contact Support
                </a>
              </p>
              <p className="mt-2 text-xs text-gray-500">
                © 2025 PMO Builder using AI by Dr. Ahmed Alsenosy
              </p>
            </div>
          </div>
        </div>
      </Suspense>
    </ErrorBoundary>
  );
};

export default LoginPage;