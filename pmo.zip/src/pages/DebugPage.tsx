import React, { useState, useEffect } from 'react';
import { useAppStore } from '../store';
import { Clipboard, RefreshCw } from 'lucide-react';
import { useToast } from '../hooks/useToast';

const DebugPage: React.FC = () => {
  const [appState, setAppState] = useState<string>('');
  const [loadingState, setLoadingState] = useState(false);
  const toast = useToast();
  const appStore = useAppStore();
  
  useEffect(() => {
    refreshState();
  }, []);
  
  const refreshState = () => {
    setLoadingState(true);
    
    try {
      // Get a sanitized copy of the app state (remove sensitive data)
      const state = {
        userData: {
          projects: appStore.userData.projects,
          activeProjectId: appStore.userData.activeProjectId
        },
        activeProject: appStore.getActiveProject(),
        connectionError: appStore.connectionError,
        currentDomain: appStore.currentDomain,
        isAnalyzing: appStore.isAnalyzing,
        processedDocuments: appStore.processedDocuments.length,
        domainProgress: appStore.currentDomain ? appStore.getDomainProgress(appStore.currentDomain) : null,
        overallProgress: appStore.getOverallProgress()
      };
      
      setAppState(JSON.stringify(state, null, 2));
    } catch (error) {
      console.error('Error getting app state:', error);
      setAppState('Error getting app state');
    } finally {
      setLoadingState(false);
    }
  };
  
  const copyToClipboard = () => {
    navigator.clipboard.writeText(appState)
      .then(() => toast.success('State copied to clipboard'))
      .catch(() => toast.error('Failed to copy state to clipboard'));
  };
  
  return (
    <div className="container mx-auto p-6">
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-bold text-slate-800 dark:text-white">Application Debug</h1>
        <div className="flex space-x-2">
          <button
            onClick={refreshState}
            disabled={loadingState}
            className="flex items-center px-3 py-2 text-sm bg-blue-600 text-white rounded-md hover:bg-blue-700"
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh State
          </button>
          <button
            onClick={copyToClipboard}
            className="flex items-center px-3 py-2 text-sm bg-slate-600 text-white rounded-md hover:bg-slate-700"
          >
            <Clipboard className="h-4 w-4 mr-2" />
            Copy
          </button>
        </div>
      </div>
      
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow p-4">
        <div className="mb-4">
          <h2 className="text-lg font-semibold text-slate-700 dark:text-slate-200 mb-2">Application State</h2>
          {loadingState ? (
            <div className="flex justify-center items-center h-60">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
            </div>
          ) : (
            <pre className="bg-slate-100 dark:bg-slate-900 p-4 rounded overflow-auto text-sm text-slate-800 dark:text-slate-200 h-[500px]">
              {appState}
            </pre>
          )}
        </div>
      </div>
    </div>
  );
};

export default DebugPage; 