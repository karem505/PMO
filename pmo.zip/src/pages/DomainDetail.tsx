import React, { useState, useEffect, useCallback, useRef, Suspense, useMemo } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { useAppStore } from '../store';
import { domains, tasks, getIconComponent } from '../data';
import MemoizedTaskCard from '../components/MemoizedTaskCard';
import MemoizedDomainInputForm from '../components/MemoizedDomainInputForm';
import MemoizedDomainOutputDisplay from '../components/MemoizedDomainOutputDisplay';
import MemoizedDocumentProcessor from '../components/MemoizedDocumentProcessor';
import MemoizedAIConfigurationPanel from '../components/MemoizedAIConfigurationPanel';
import { ArrowLeft, ArrowRight, Loader2, Upload, ChevronUp, ChevronDown, FileText, AlertTriangle, RefreshCw, Info, Lock, X } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { ProcessedDocument } from '../utils/documentUtils';
import LoadingScreen from '../components/common/LoadingScreen';
import { ErrorBoundary } from 'react-error-boundary';
import { useMediaQuery } from '../hooks/useMediaQuery';
import { useToast } from '../hooks/useToast';
import axios from 'axios';
import apiClient from '../api/client';
import debounce from 'lodash/debounce';
import { useSubscription } from '../contexts/SubscriptionContext';
import { SubscriptionTier } from '../services/subscriptionService';
import LoadingSpinner from '../components/common/LoadingSpinner';
import { captureException } from '../services/sentryService';
import DomainCardSkeleton from '../components/common/DomainCardSkeleton';
import LoadingWrapper from '../components/common/LoadingWrapper';
import { useNavigationGuard } from '../hooks/useNavigationGuard';
import TaskOutputGenerator from '../components/TaskOutputGenerator';

// Note: TaskCard uses a global taskBatchQueue for batch checking completion status.
// We handle this by clearing it when switching domains to ensure fresh checks.

// Enhanced DomainDetail component with comprehensive DOM safety
const DomainDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { navigate: safeNavigate } = useNavigationGuard();
  const location = useLocation();
  
  // Use a standard ref without the custom hook
  const domainRef = useRef<HTMLDivElement>(null);
  
  const isMobile = useMediaQuery('(max-width: 768px)');
  const toast = useToast();
  const { tier } = useSubscription();
  
  const domainId = parseInt(id || '1', 10);
  const isLocked = tier === SubscriptionTier.FREE && domainId > 2;
  
  // Single ref to track component mount status for safety
  const isMountedRef = useRef(true);
  
  const { 
    setCurrentDomain, 
    getDomainProgress, 
    analyzeDomainInput, 
    getDomainInput,
    getDomainOutput,
    isAnalyzing,
    addProcessedDocument,
    connectionError,
    showConnectionErrors,
    getActiveProject,
    setTaskCompleted,
    updateTaskData
  } = useAppStore();
  
  const { t, isRTL } = useLanguage();
  
  // Define type for activeView to resolve comparison issues
  const [activeView, setActiveView] = useState<'tasks' | 'input'>('tasks');
  const [isLoading, setIsLoading] = useState(true);
  const [showDocumentProcessor, setShowDocumentProcessor] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [analysisStarted, setAnalysisStarted] = useState(false);
  const [analysisProgress, setAnalysisProgress] = useState(0);
  const [analysisCurrentStage, setAnalysisCurrentStage] = useState<string>('Processing inputs...');
  const [analysisStartTime, setAnalysisStartTime] = useState<number | null>(null);
  const [analysisElapsedTime, setAnalysisElapsedTime] = useState<number>(0);
  const [showTimedOutMessage, setShowTimedOutMessage] = useState<boolean>(false);
  const [completedTask, setCompletedTask] = useState<string[]>([]);
  const loadingTimerRef = useRef<NodeJS.Timeout | null>(null);
  const [showTaskGenerator, setShowTaskGenerator] = useState(false);
  const [selectedTaskForGenerator, setSelectedTaskForGenerator] = useState<string | null>(null);

  // Add a ref to track closing state to prevent race conditions
  const closingGeneratorRef = useRef(false);

  // Find the domain object by ID
  const domain = domains.find(d => d.id === domainId);
  
  // Use a useEffect to ensure we're mounted before attempting to render complex content
  useEffect(() => {
    // Mark component as mounted
    isMountedRef.current = true;
    
    // Add a shorter delay to ensure the component is initialized
    // but don't make users wait too long
    loadingTimerRef.current = setTimeout(() => {
      if (isMountedRef.current) {
        setIsLoading(false);
      }
    }, 100); // Reduced from 300ms to 100ms
    
    return () => {
      // Clear the timer and mark component as unmounted
      if (loadingTimerRef.current) {
        clearTimeout(loadingTimerRef.current);
      }
      isMountedRef.current = false;
    };
  }, []);

  useEffect(() => {
    if(completedTask && isMountedRef.current){
      completedTask.forEach((task:string) => {
        setTaskCompleted(task, true);
      });
    }
  }, [completedTask, setTaskCompleted]);
  
  // Get domain-specific tasks - memoized to avoid recalculation on every render
  const domainTasks = useMemo(() => 
    tasks.filter(task => task.domainId === domainId),
    [domainId]
  );
  
  // Get domain progress with null safety
  const progress = useMemo(() => 
    getDomainProgress(domainId) || { 
    inputProgress: 0, 
    processingProgress: 0, 
    outputProgress: 0,
    overallProgress: 0
    },
    [getDomainProgress, domainId]
  );
  
  const activeProject = getActiveProject();
  
  const checkTasksCompletion = useCallback(
    debounce(async (projectId: string, taskIds: string[]) => {
      // Don't proceed if component is unmounted
      if (!isMountedRef.current || !projectId || !taskIds.length) return;
      
      // Add API request tracking
      let requestCompleted = false;
      const apiTimeout = setTimeout(() => {
        if (!requestCompleted && isMountedRef.current) {
          console.warn('Task completion check timed out after 15 seconds');
        }
      }, 15000);
      
      try {
        const controller = new AbortController();
        const abortTimeout = setTimeout(() => controller.abort(), 20000); // Abort after 20 seconds
        
        const res = await apiClient.post('/documents/completed-tasks/batch', {
          project_id: projectId,
          task_ids: taskIds
        }, {
          signal: controller.signal,
          timeout: 15000 // Explicit timeout
        });
        
        // Request completed successfully
        requestCompleted = true;
        clearTimeout(abortTimeout);
        
        // Check again if component is still mounted before updating state
        if (!isMountedRef.current) return;
        
        const tasks = res.data?.tasks || {};
        Object.entries(tasks).forEach(([taskId, status]: [string, any]) => {
          if (status?.exists && status?.completed) {
            setTaskCompleted(taskId, true);
            // Update task data with completion information
            const taskData = {
              completed: true,
              acceptanceStatus: 'accepted' as const,
              acceptanceTimestamp: status.data?.timestamp || new Date().toISOString()
            };
            updateTaskData(taskId, taskData);
          }
        });
      } catch (error: any) {
        // Request failed or was aborted
        requestCompleted = true;
        
        // Only log error if component is still mounted
        if (isMountedRef.current) {
        console.error('Error checking tasks completion:', error);
          
          // Don't surface errors to user - batch checks are background operations
          // but log them for debugging purposes
          if (error.name !== 'AbortError' && error.name !== 'TimeoutError') {
            // Capture non-timeout errors for monitoring
            captureException(error, {
              tags: {
                component: 'DomainDetail',
                operation: 'batchTaskCheck'
              },
              extra: {
                projectId,
                taskIds: JSON.stringify(taskIds)
              }
            });
          }
        }
      } finally {
        clearTimeout(apiTimeout);
      }
    }, 10000),
    [setTaskCompleted, updateTaskData]
  );

  // Get domain task IDs - memoized
  const domainTaskIds = useMemo(() => 
    domainTasks.map(task => task.id),
    [domainTasks]
  );
  
  // Replace the existing useEffect with one that only runs once on initial load
  useEffect(() => {
    // Check if we should use the component's batch check or let TaskCard handle it
    const shouldUseLocalBatchCheck = !window.taskBatchQueue;
    
    // Check task completion only on initial component mount and if global batch queue is not set up
    if (shouldUseLocalBatchCheck && activeProject?.id && domainTaskIds.length > 0 && isMountedRef.current) {
      console.log('Initial task completion check through component mechanism');
      checkTasksCompletion(activeProject.id, domainTaskIds);
    } else {
      console.log('Task completion will be handled by TaskCard batch queue system');
    }
  }, [activeProject?.id, domainTaskIds.length, checkTasksCompletion]); 

  // Group tasks by stage - memoized to avoid filtering on every render
  const inputTasks = useMemo(() => 
    domainTasks.filter(task => task.stage === 'input'),
    [domainTasks]
  );
  
  const processingTasks = useMemo(() => 
    domainTasks.filter(task => task.stage === 'processing'),
    [domainTasks]
  );
  
  const outputTasks = useMemo(() => 
    domainTasks.filter(task => task.stage === 'output'),
    [domainTasks]
  );
  
  // Get domain icon component - memoized
  const IconComponent = useMemo(() => 
    domain ? getIconComponent(domain.icon) : null,
    [domain]
  );
  
  // Get domain input and output data - memoized
  const domainInput = useMemo(() => 
    getDomainInput(domainId),
    [getDomainInput, domainId]
  );
  
  const domainOutput = useMemo(() => 
    getDomainOutput(domainId),
    [getDomainOutput, domainId]
  );
  
  // Handle document upload from navigation state
  useEffect(() => {
    if (location.state?.showDocumentUpload && isMountedRef.current) {
      setShowDocumentProcessor(true);
      setActiveView('input');
    }
  }, [location.state]);
  
  // Set current domain and load data with enhanced safety
  useEffect(() => {
    if (!isMountedRef.current) return;
    
    if (domain) {
      setCurrentDomain(domain.id);
      setIsLoading(true);
      
      try {
        // Clear any existing batch task queue to ensure fresh checks
        if (typeof window !== 'undefined' && window.taskBatchQueue) {
          if (window.taskBatchQueue.timeoutId) {
            clearTimeout(window.taskBatchQueue.timeoutId);
          }
          window.taskBatchQueue.tasks = [];
          window.taskBatchQueue.timeoutId = null;
        }
        
        // Short timeout to ensure all UI elements are properly loaded
        const timer = setTimeout(() => {
          if (isMountedRef.current) {
            setIsLoading(false);
          }
        }, 300);
        
        return () => {
          clearTimeout(timer);
        };
      } catch (err) {
        console.error('Error in domain detail effect:', err);
        if (isMountedRef.current) {
          setError(err instanceof Error ? err.message : 'Failed to load domain data');
          setIsLoading(false);
        }
      }
    } else {
      if (isMountedRef.current) {
        setError('Domain not found');
        setIsLoading(false);
      }
    }
    
    // Cleanup function to reset current domain when unmounting
    return () => {
      setCurrentDomain(null);
    };
  }, [domain, setCurrentDomain]);
  
  // Simulate progress during analysis for better UX and track actual elapsed time
  useEffect(() => {
    if (!isMountedRef.current) return;
    
    let progressInterval: ReturnType<typeof setInterval> | undefined;
    let elapsedInterval: ReturnType<typeof setInterval> | undefined;
    
    if (isAnalyzing && !domainOutput) {
      setAnalysisStarted(true);
      
      // Only set start time if it's not already set
      if (!analysisStartTime) {
        setAnalysisStartTime(Date.now());
      }
      
      // Update progress for better UX
      progressInterval = setInterval(() => {
        if (!isMountedRef.current) {
          // Clear intervals if component unmounted
          if (progressInterval) clearInterval(progressInterval);
          if (elapsedInterval) clearInterval(elapsedInterval);
          return;
        }
        
        setAnalysisProgress(prev => {
          const newProgress = prev < 95 ? prev + 1 : prev;
        
          // Update stage based on new progress value to avoid stale closure
          if (newProgress < 20) {
          setAnalysisCurrentStage('Processing inputs...');
          } else if (newProgress < 40) {
          setAnalysisCurrentStage('Analyzing content...');
          } else if (newProgress < 60) {
          setAnalysisCurrentStage('Generating insights...');
          } else if (newProgress < 80) {
          setAnalysisCurrentStage('Finalizing analysis...');
        } else {
          setAnalysisCurrentStage('Almost done...');
        }
          
          return newProgress;
        });
      }, 500);
      
      // Track elapsed time
      elapsedInterval = setInterval(() => {
        if (!isMountedRef.current) {
          // Clear intervals if component unmounted
          if (progressInterval) clearInterval(progressInterval);
          if (elapsedInterval) clearInterval(elapsedInterval);
          return;
        }
        
        if (analysisStartTime) {
          const elapsed = Math.floor((Date.now() - analysisStartTime) / 1000);
          setAnalysisElapsedTime(elapsed);
          
          // Show timeout warning after 3 minutes
          if (elapsed > 180) {
            setShowTimedOutMessage(true);
          }
        }
      }, 1000);
    } else if (analysisStarted && !isAnalyzing) {
      // Analysis finished
      setAnalysisProgress(100);
      setAnalysisCurrentStage('Complete');
      setTimeout(() => {
        if (isMountedRef.current) {
          setAnalysisStarted(false);
          setAnalysisProgress(0); // Reset progress for next time
          setAnalysisElapsedTime(0);
          setShowTimedOutMessage(false);
          setAnalysisStartTime(null); // Reset start time
        }
      }, 500);
    }
    
    return () => {
      if (progressInterval) clearInterval(progressInterval);
      if (elapsedInterval) clearInterval(elapsedInterval);
    };
  }, [isAnalyzing, domainOutput, analysisStarted, analysisStartTime]);
  
  // Safety timeout to prevent infinite loading state - consolidated implementation
  useEffect(() => {
    if (!isMountedRef.current) return;
    
    // Maximum loading time - starts with short timeout for better UX,
    // but has a backup to ensure we never get stuck loading
    const initialLoadingTimeout = setTimeout(() => {
      if (isLoading && isMountedRef.current) {
        console.log('Initial loading timeout reached, check if we need to complete');
        setIsLoading(false);
      }
    }, 800); 
    
    // Final safety timeout that will force complete no matter what
    const finalLoadingTimeout = setTimeout(() => {
      if (isMountedRef.current && isLoading) {
        console.log('Force completing domain loading after final timeout');
        setIsLoading(false);
      }
    }, 2000); // Force complete after 2 seconds max
    
    return () => {
      clearTimeout(initialLoadingTimeout);
      clearTimeout(finalLoadingTimeout);
    };
  }, [isLoading]);
  
  // Navigation functions for domain traversal with safety checks - consistently using safeNavigate
  const handlePrevDomain = () => {
    if (!isMountedRef.current) {
      console.warn('Navigation attempted when component is unmounted');
      return;
    }
    
    // More robust domain navigation logic with null checks
    const totalDomains = domains?.length || 0;
    if (totalDomains === 0) {
      console.warn('No domains available for navigation');
      return;
    }
    
    // Ensure valid bounds for domain navigation
    const prevDomainId = domainId > 1 ? domainId - 1 : totalDomains;
    
    try {
    safeNavigate(`/domains/${prevDomainId}`);
    } catch (err) {
      console.error('Navigation error:', err);
      // Fallback navigation as a last resort
      navigate(`/domains/${prevDomainId}`);
    }
  };

  const handleNextDomain = () => {
    if (!isMountedRef.current) {
      console.warn('Navigation attempted when component is unmounted');
      return;
    }
    
    // More robust domain navigation logic with null checks
    const totalDomains = domains?.length || 0;
    if (totalDomains === 0) {
      console.warn('No domains available for navigation');
      return;
    }
    
    // Ensure valid bounds for domain navigation
    const nextDomainId = domainId < totalDomains ? domainId + 1 : 1;
    
    try {
    safeNavigate(`/domains/${nextDomainId}`);
    } catch (err) {
      console.error('Navigation error:', err);
      // Fallback navigation as a last resort
      navigate(`/domains/${nextDomainId}`);
    }
  };
  
  const handleUpgradeClick = () => {
    if (!isMountedRef.current) {
      console.warn('Navigation attempted when component is unmounted');
      return;
    }
    
    try {
    safeNavigate('/pricing');
    } catch (err) {
      console.error('Navigation error:', err);
      // Fallback navigation as a last resort
      navigate('/pricing');
    }
  };
  
  // Create a safe navigation function for dashboard returns
  const navigateToDashboard = () => {
    try {
      safeNavigate('/dashboard');
    } catch (err) {
      console.error('Navigation error:', err);
      navigate('/dashboard');
    }
  };
  
  // Handle domain analysis with enhanced error handling
  const handleAnalyze = async () => {
    if (!domainInput || !domainInput.content) {
      toast.error(t('domain.provideInputFirst', "Please provide domain input data before analyzing"));
      return;
    }
    
    if (!isMountedRef.current) return;
    
    setError(null);
    setAnalysisStarted(true);
    setAnalysisStartTime(Date.now());
    
    try {
      // Set a timeout for the analysis
      const analysisTimeout = setTimeout(() => {
        if (isAnalyzing && isMountedRef.current) {
          console.warn('Analysis taking too long, showing timeout message');
          setShowTimedOutMessage(true);
        }
      }, 45000); // Show message after 45 seconds
      
      // Send a preflight request to wake up the backend if it's idle
      if (activeProject?.id) {
        try {
          console.log('Sending preflight request to ensure backend is ready');
          await apiClient.post('/documents/preflight', {
            project_id: activeProject.id,
            domain_id: domainId,
            operation: 'analyze'
          }).catch(err => {
            // Ignore preflight error, we'll try the main request anyway
            console.warn('Preflight request failed, attempting analysis anyway:', err);
          });
        } catch (preflightError) {
          console.warn('Error in preflight request:', preflightError);
          // Continue with analysis even if preflight fails
        }
      }
      
      // Small delay to ensure preflight completes
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Check if component is still mounted before proceeding
      if (!isMountedRef.current) {
        clearTimeout(analysisTimeout);
        return;
      }
      
      // Execute the main analysis request
      toast.info(t('domain.startingAnalysis', 'Starting domain analysis...'));
      console.log('Executing domain analysis for domain ID:', domainId);
      await analyzeDomainInput(domainId);
      
      // Clear the timeout since analysis completed
      clearTimeout(analysisTimeout);
      
      // Only update state if component is still mounted
      if (isMountedRef.current) {
        toast.success(t('domain.analysisCompleted', 'Domain analysis completed successfully'));
      }
    } catch (error: any) {
      console.error('Error analyzing domain:', error);
      
      // Only update state if component is still mounted
      if (isMountedRef.current) {
        // Provide more specific error messages based on error type
        if (error.code === 'ECONNABORTED' || error.message?.includes('timeout')) {
          setError('Analysis request timed out. Please try again with a shorter input or when the network is more stable.');
          toast.error(t('domain.analysisTimeoutError', 'Analysis timed out. Please try again.'));
        } else if (error.response?.status === 429) {
          setError('Too many analysis requests. The server is currently busy. Please wait a moment and try again.');
          toast.error(t('domain.analysisTooManyRequests', 'Server is busy. Please try again shortly.'));
        } else if (error.response?.status === 413) {
          setError('Input data is too large for analysis. Please reduce the size of your input and try again.');
          toast.error(t('domain.analysisInputTooLarge', 'Input is too large. Please reduce and try again.'));
        } else if (error.response?.status === 403) {
          setError('You do not have permission to perform this analysis. Please check your subscription status.');
          toast.error(t('domain.analysisPermissionError', 'Permission denied for this operation.'));
        } else if (error.message?.includes('network') || error.response?.status === 0) {
          setError('Network connection error. Please check your internet connection and try again.');
          toast.error(t('domain.analysisNetworkError', 'Network connection error. Please try again.'));
        } else {
          setError('Failed to analyze domain data. Please try again later.');
        toast.error(t('domain.analysisError', 'Analysis failed. Please try again.'));
        }
      }
    } finally {
      // Only update state if component is still mounted
      if (isMountedRef.current) {
        setAnalysisStarted(false);
      }
    }
  };
  
  // Format elapsed time as mm:ss - memoized to avoid recreation on every render
  const formatElapsedTime = useCallback((seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  }, []);
  
  // Handle document processing completion with safety check
  const handleProcessedDocument = (document: ProcessedDocument) => {
    // Only update state if component is still mounted
    if (isMountedRef.current) {
      // Add the processed document to the store
      addProcessedDocument(document);
    }
  };
  
  // Add a mounted state check for safe navigation attempts
  const isSafeToNavigate = useCallback(() => {
    return isMountedRef.current === true;
  }, []);

  // Update the task click handler to add additional safety checks
  const handleTaskClick = useCallback((taskId: string, showGenerator: boolean = false) => {
    // First check if it's safe to proceed
    if (!isMountedRef.current) {
      console.warn('Navigation attempted when component is unmounted');
      return;
    }
    
    // Additional lock check to prevent race conditions with closing logic
    if (showGenerator && closingGeneratorRef.current) {
      console.log('DomainDetail: Generator is closing, ignoring click');
      return;
    }

    if (showGenerator) {
      // Show the generator instead of navigating
      setSelectedTaskForGenerator(taskId);
      setShowTaskGenerator(true);
      return;
    }
    
    // Add a small delay to prevent potential DOM errors
    setTimeout(() => {
      if (!isMountedRef.current) {
        console.warn('Not navigating - component unmounted during delay');
        return;
      }
      
      try {
        console.log(`Navigating to task detail for task ${taskId}`);
        safeNavigate(`/tasks/${taskId}`);
      } catch (err) {
        console.error('Task navigation error:', err);
        // Fallback navigation as a last resort
        navigate(`/tasks/${taskId}`);
      }
    }, 50);
  }, [safeNavigate, navigate, isMountedRef, closingGeneratorRef]);
  
  // Function to handle task completion toggle - memoized to maintain reference stability
  const handleToggleTaskCompletion = useCallback((taskId: string, currentCompleted: boolean) => {
    if (!isMountedRef.current) {
      console.warn('Component not ready for task update');
      return;
    }
    
    try {
      console.log(`Toggling task ${taskId} completion from ${currentCompleted} to ${!currentCompleted}`);
      
      // TaskCard expects us to toggle the current state
      const newCompletedState = !currentCompleted;
      
      // Update task completion in store
      setTaskCompleted(taskId, newCompletedState);
      
      // Update task data with completion info
      updateTaskData(taskId, {
        completed: newCompletedState,
        acceptanceStatus: newCompletedState ? 'accepted' : 'needs-refinement'
      });
      
      toast.success(
        newCompletedState
          ? t('domain.detail.taskMarkedAsCompleted', 'Task marked as completed')
          : t('domain.detail.taskMarkedAsNotCompleted', 'Task marked as incomplete')
      );
    } catch (err) {
      console.error('Error updating task completion:', err);
      toast.error(t('domain.taskUpdateError', 'Failed to update task status'));
    }
  }, [setTaskCompleted, updateTaskData, toast, t, isMountedRef]);
  
  // Function to safely handle retry
  const handleRetry = useCallback(() => {
    if (!isMountedRef.current) return;
    
    setError(null);
    setIsLoading(true);
    
    // Force a reload attempt
    setTimeout(() => {
      if (isMountedRef.current) {
        setIsLoading(false);
      }
    }, 800);
  }, []);
  
  // Handle errors gracefully with safety check
  const handleError = (error: Error) => {
    console.error('Error rendering DomainDetail:', error);
    
    // Only update state if component is still mounted
    if (isMountedRef.current) {
      // Ensure error is a string before using includes
      const errorMessage = typeof error?.message === 'string' ? error.message : '';
      
      // Provide more specific error messages based on error type
      if (errorMessage.includes('network') || errorMessage.includes('connection')) {
        setError('Network connection issue. Please check your internet connection and try again.');
      } else if (errorMessage.includes('permission') || errorMessage.includes('403')) {
        setError('You don\'t have permission to access this domain or its resources.');
      } else if (errorMessage.includes('not found') || errorMessage.includes('404')) {
        setError('The requested domain or resource could not be found.');
      } else if (errorMessage.includes('timeout') || errorMessage.includes('timed out')) {
        setError('Operation timed out. The server took too long to respond. Please try again.');
      } else {
        setError(error.message || 'An unexpected error occurred while rendering this domain');
      }
      setIsLoading(false);
    }
    
    // Report to Sentry with additional context
    captureException(error, {
      tags: {
        component: 'DomainDetail',
        domainId: domainId.toString()
      },
      extra: {
        domainId,
        location: window.location.href,
        domainMounted: isMountedRef.current
      }
    });
  };
  
  // Memoized error troubleshooting panels for better performance
  const NetworkErrorPanel = useMemo(() => (
    <div className="bg-blue-50 p-4 rounded-md mb-6 text-left">
      <h3 className="font-medium text-blue-800 mb-1">Troubleshooting steps:</h3>
      <ul className="text-sm text-blue-700 list-disc pl-5 space-y-1">
        <li>Check your internet connection</li>
        <li>Try refreshing the page</li>
        <li>If using VPN, try disabling it</li>
        <li>Clear your browser cache and cookies</li>
      </ul>
    </div>
  ), []);
  
  const PermissionErrorPanel = useMemo(() => (
    <div className="bg-blue-50 p-4 rounded-md mb-6 text-left">
      <h3 className="font-medium text-blue-800 mb-1">Possible solutions:</h3>
      <ul className="text-sm text-blue-700 list-disc pl-5 space-y-1">
        <li>Verify your account has access to this domain</li>
        <li>Check your subscription status</li>
        <li>Try logging out and back in</li>
        <li>Contact support if the issue persists</li>
      </ul>
    </div>
  ), []);
  
  const TimeoutErrorPanel = useMemo(() => (
    <div className="bg-blue-50 p-4 rounded-md mb-6 text-left">
      <h3 className="font-medium text-blue-800 mb-1">Try these steps:</h3>
      <ul className="text-sm text-blue-700 list-disc pl-5 space-y-1">
        <li>Wait a few minutes and try again</li>
        <li>Try with smaller inputs</li>
        <li>Check if the server status is online</li>
        <li>Try a different network connection</li>
      </ul>
    </div>
  ), []);
  
  const SizeErrorPanel = useMemo(() => (
    <div className="bg-blue-50 p-4 rounded-md mb-6 text-left">
      <h3 className="font-medium text-blue-800 mb-1">Recommendations:</h3>
      <ul className="text-sm text-blue-700 list-disc pl-5 space-y-1">
        <li>Reduce the size of your input text</li>
        <li>Split your content into smaller chunks</li>
        <li>Remove unnecessary formatting or images</li>
        <li>Try using file compression before uploading</li>
      </ul>
    </div>
  ), []);
  
  // Create a factory function that produces memoized onClick handlers for each task
  const createTaskClickHandler = useCallback(
    (taskId: string) => () => handleTaskClick(taskId),
    [handleTaskClick]
  );
  
  // Create a factory function for generator click handlers
  const createGeneratorClickHandler = useCallback(
    (taskId: string) => () => handleTaskClick(taskId, true),
    [handleTaskClick]
  );
  
  // Memoize the task lists with their handlers for optimal rendering
  const renderedInputTasks = useMemo(() => 
    inputTasks && inputTasks.length > 0 
      ? inputTasks.map(task => (
          <MemoizedTaskCard 
            key={task.id} 
            task={task} 
            onToggleComplete={handleToggleTaskCompletion}
            onClick={createTaskClickHandler(task.id)}
            onGeneratorClick={createGeneratorClickHandler(task.id)}
          />
        ))
      : (
        <div className="p-4 bg-gray-50 border border-gray-100 rounded-lg text-center dark:bg-gray-800 dark:border-gray-700">
          <p className="text-gray-500 text-sm dark:text-gray-400">{t('domain.noTasksAvailable', 'No input tasks available')}</p>
        </div>
      ),
    [inputTasks, handleToggleTaskCompletion, createTaskClickHandler, createGeneratorClickHandler, t]
  );
  
  const renderedProcessingTasks = useMemo(() => 
    processingTasks && processingTasks.length > 0 
      ? processingTasks.map(task => (
          <MemoizedTaskCard 
            key={task.id} 
            task={task} 
            onToggleComplete={handleToggleTaskCompletion}
            onClick={createTaskClickHandler(task.id)}
            onGeneratorClick={createGeneratorClickHandler(task.id)}
          />
        ))
      : (
        <div className="p-4 bg-gray-50 border border-gray-100 rounded-lg text-center dark:bg-gray-800 dark:border-gray-700">
          <p className="text-gray-500 text-sm dark:text-gray-400">{t('domain.noTasksAvailable', 'No processing tasks available')}</p>
        </div>
      ),
    [processingTasks, handleToggleTaskCompletion, createTaskClickHandler, createGeneratorClickHandler, t]
  );
  
  const renderedOutputTasks = useMemo(() => 
    outputTasks && outputTasks.length > 0 
      ? outputTasks.map(task => (
          <MemoizedTaskCard 
            key={task.id} 
            task={task} 
            onToggleComplete={handleToggleTaskCompletion}
            onClick={createTaskClickHandler(task.id)}
            onGeneratorClick={createGeneratorClickHandler(task.id)}
          />
        ))
      : (
        <div className="p-4 bg-gray-50 border border-gray-100 rounded-lg text-center dark:bg-gray-800 dark:border-gray-700">
          <p className="text-gray-500 text-sm dark:text-gray-400">{t('domain.noTasksAvailable', 'No output tasks available')}</p>
        </div>
      ),
    [outputTasks, handleToggleTaskCompletion, createTaskClickHandler, createGeneratorClickHandler, t]
  );
  
  // Type guard for objects with a message property
  type ErrorWithMessage = {
    message: string;
    [key: string]: any;
  };
  
  // Type guard function to check if object has message property
  function isErrorWithMessage(error: any): error is ErrorWithMessage {
    return (
      error !== null &&
      typeof error === 'object' &&
      'message' in error &&
      typeof error.message === 'string'
    );
  }
  
  // Domain not found state (allowing the wrapper to handle this)
  if (!domain && !isLoading) {
    return (
      <div className="min-h-[calc(100vh-64px)] flex items-center justify-center bg-neutral-50">
        <div className="text-center px-4 max-w-md">
          <h1 className="text-3xl font-bold text-neutral-800 mb-2">Domain Not Found</h1>
          <p className="text-neutral-600 mb-8">
            The domain you're looking for doesn't exist or has been removed.
          </p>
          <button 
            onClick={navigateToDashboard}
            className="px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 transition-colors"
          >
            Return to Dashboard
          </button>
        </div>
      </div>
    );
  }
  
  // Main render with enhanced error boundary for robust error handling
  return (
    <ErrorBoundary
      fallbackRender={({ error }) => {
        // Safely convert error to string for display
        let errorDisplay = 'Unknown error';
        let errorNetwork = false;
        let errorPermission = false;
        let errorTimeout = false;
        let errorSize = false;
        
        if (error) {
          // Handle string errors
          if (typeof error === 'string') {
            errorDisplay = error;
            errorNetwork = error.includes('network');
            errorPermission = error.includes('permission');
            errorTimeout = error.includes('timeout');
            errorSize = error.includes('too large');
          } 
          // Handle object errors with message property
          else if (typeof error === 'object' && error !== null) {
            // Use toString() if available
            if (typeof error.toString === 'function') {
              errorDisplay = error.toString();
            }
            
            // Check for message property using type guard
            if (isErrorWithMessage(error)) {
              errorDisplay = error.message;
              errorNetwork = error.message.includes('network');
              errorPermission = error.message.includes('permission');
              errorTimeout = error.message.includes('timeout');
              errorSize = error.message.includes('too large');
            }
          }
        }
        
        return (
          <div className="min-h-[calc(100vh-64px)] flex items-center justify-center bg-neutral-50">
            <div className="text-center px-4 max-w-md">
              <AlertTriangle className="h-12 w-12 text-amber-500 mx-auto mb-4" />
              <h1 className="text-3xl font-bold text-neutral-800 mb-2">Something went wrong</h1>
              <p className="text-neutral-600 mb-4">{isErrorWithMessage(error) ? error.message : (error as string) || 'Unknown error'}</p>
              
              {/* Additional helpful information based on error type */}
              {typeof error === 'string' && error.includes('network') && NetworkErrorPanel}
              {typeof error === 'string' && error.includes('permission') && PermissionErrorPanel}
              {typeof error === 'string' && error.includes('timeout') && TimeoutErrorPanel}
              {typeof error === 'string' && error.includes('too large') && SizeErrorPanel}
              {isErrorWithMessage(error) && error.message.includes('network') && NetworkErrorPanel}
              {isErrorWithMessage(error) && error.message.includes('permission') && PermissionErrorPanel}
              {isErrorWithMessage(error) && error.message.includes('timeout') && TimeoutErrorPanel}
              {isErrorWithMessage(error) && error.message.includes('too large') && SizeErrorPanel}
              
              <button
                onClick={handleRetry}
                className="px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 transition-colors flex items-center mx-auto"
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Try Again
              </button>
              
              <button 
                onClick={navigateToDashboard}
                className="mt-4 px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors mx-auto"
              >
                Return to Dashboard
              </button>
            </div>
          </div>
        );
      }}
      onError={(error) => {
        // Report to Sentry with additional context
        captureException(error, {
          tags: {
            component: 'DomainDetail',
            errorBoundary: 'true',
            domainId: domainId.toString()
          },
          extra: {
            domainId,
            location: window.location.href,
            domainMounted: isMountedRef.current
          }
        });
      }}
    >
      <Suspense fallback={<LoadingSpinner fullScreen text="Loading domain details..." />}>
        {/* Simplified loading logic using ternary operators instead of LoadingWrapper */}
        {isLoading ? (
          <LoadingScreen />
        ) : error ? (
          <div className="min-h-[calc(100vh-64px)] flex items-center justify-center bg-neutral-50">
            <div className="text-center px-4 max-w-md">
              <AlertTriangle className="h-12 w-12 text-amber-500 mx-auto mb-4" />
              <h1 className="text-3xl font-bold text-neutral-800 mb-2">Something went wrong</h1>
              <p className="text-neutral-600 mb-4">{isErrorWithMessage(error) ? error.message : (error as string) || 'Unknown error'}</p>
              
              {/* Additional helpful information based on error type */}
              {typeof error === 'string' && error.includes('network') && NetworkErrorPanel}
              {typeof error === 'string' && error.includes('permission') && PermissionErrorPanel}
              {typeof error === 'string' && error.includes('timeout') && TimeoutErrorPanel}
              {typeof error === 'string' && error.includes('too large') && SizeErrorPanel}
              {isErrorWithMessage(error) && error.message.includes('network') && NetworkErrorPanel}
              {isErrorWithMessage(error) && error.message.includes('permission') && PermissionErrorPanel}
              {isErrorWithMessage(error) && error.message.includes('timeout') && TimeoutErrorPanel}
              {isErrorWithMessage(error) && error.message.includes('too large') && SizeErrorPanel}
              
              <button
                onClick={handleRetry}
                className="px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 transition-colors flex items-center mx-auto"
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Try Again
              </button>
              
              <button 
                onClick={navigateToDashboard}
                className="mt-4 px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors mx-auto"
              >
                Return to Dashboard
              </button>
            </div>
          </div>
        ) : !domain ? (
          <div className="min-h-[calc(100vh-64px)] flex items-center justify-center bg-neutral-50">
            <div className="text-center px-4 max-w-md">
              <h1 className="text-3xl font-bold text-neutral-800 mb-2">No Data Available</h1>
              <p className="text-neutral-600 mb-8">
                We couldn't find the domain data you're looking for.
              </p>
              <button 
                onClick={navigateToDashboard}
                className="px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 transition-colors"
              >
                Return to Dashboard
              </button>
            </div>
          </div>
        ) : (
          <div ref={domainRef} className="relative">
            {/* Domain Lock Overlay */}
            {isLocked && (
              <div className="fixed inset-0 bg-gray-900/60 backdrop-blur-sm flex flex-col items-center justify-center z-50">
                <div className="p-8 rounded-xl bg-white/10 mb-6 max-w-md text-center">
                  <div className="p-4 rounded-full bg-white/10 mx-auto mb-4 w-fit">
                    <Lock className="h-10 w-10 text-white" />
                  </div>
                  {domain && (
                    <>
                  <h3 className="text-white text-2xl font-semibold mb-2">
                        {t(`domains.${domain.id}.name`, domain.name)}
                  </h3>
                  <p className="text-white/80 mb-6">
                    {t('subscription.premiumOnlyFeature', 'This domain is only available on Premium plans. You can view the content but cannot interact with it.')}
                  </p>
                    </>
                  )}
                  <div className="flex flex-col space-y-3">
                    <button 
                      onClick={handleUpgradeClick}
                      className="w-full px-6 py-3 bg-primary-600 text-white rounded-lg font-medium hover:bg-primary-700 transition-colors"
                    >
                      {t('subscription.upgradeToUnlock', 'Upgrade to Unlock')}
                    </button>
                    <button 
                      onClick={navigateToDashboard}
                      className="w-full px-6 py-3 bg-white/20 text-white rounded-lg font-medium hover:bg-white/30 transition-colors"
                    >
                      {t('common.backToDashboard', 'Back to Dashboard')}
                    </button>
                  </div>
                </div>
              </div>
            )}
            
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <button 
                  className="flex items-center text-gray-600 hover:text-gray-800 dark:text-gray-300 dark:hover:text-gray-100"
                  onClick={navigateToDashboard}
                >
                  <ArrowLeft className={`h-4 w-4 ${isRTL ? 'me-1.5 rtl:rotate-180' : 'me-1.5'}`} />
                  {t('domain.backToDashboard')}
                </button>
                
                <div className={`flex gap-2 ${isRTL ? 'rtl:space-x-reverse' : ''}`}>
                  <button 
                    className="px-3 py-2 border border-gray-300 rounded-md hover:bg-gray-50 flex items-center dark:border-gray-600 dark:text-gray-200 dark:hover:bg-gray-700"
                    onClick={handlePrevDomain}
                  >
                    {isRTL ? (
                      <>
                        <ArrowRight className="h-4 w-4 me-1.5 " />
                        {t('domain.prevDomain')}
                      </>
                    ) : (
                      <>
                        <ArrowLeft className="h-4 w-4 me-1.5" />
                        {t('domain.prevDomain')}
                      </>
                    )}
                  </button>
                  <button 
                    className="px-3 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center dark:bg-blue-700 dark:hover:bg-blue-800"
                    onClick={handleNextDomain}
                  >
                    {isRTL ? (
                      <>
                        {t('domain.nextDomain')}
                        <ArrowLeft className="h-4 w-4 ms-1.5 " />
                      </>
                    ) : (
                      <>
                        {t('domain.nextDomain')}
                        <ArrowRight className="h-4 w-4 ml-1.5 rtl:ml-0 rtl:me-1.5" />
                      </>
                    )}
                  </button>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-sm p-6 dark:bg-neutral-800 dark:border dark:border-neutral-700">
                {domain && (
                <div className="flex items-start">
                  {IconComponent && (
                    <div className={`p-3 bg-blue-100 rounded-lg me-4 dark:bg-blue-900/50`}>
                      <IconComponent className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                    </div>
                  )}
                  <div>
                    <h1 className="text-2xl font-bold  text-gray-800 dark:text-white">
                        {t(`domains.${domain.id}.name`, domain.name)}
                    </h1>
                    <p className="text-gray-600 mt-1 dark:text-gray-300">
                        {t(`domains.${domain.id}.description`, domain.description)}
                    </p>
                  </div>
                </div>
                )}
                
                <div className="mt-6">
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm font-medium text-neutral-600 dark:text-neutral-300">{t('common.overallProgress', 'Overall Progress')}</span>
                    <span className="text-sm font-semibold text-neutral-700 dark:text-neutral-200">{Math.round(progress?.overallProgress || 0)}%</span>
                  </div>
                  <div className="w-full h-2 bg-neutral-100 rounded-full overflow-hidden dark:bg-neutral-700">
                    <div 
                      className="h-full bg-gradient-to-r from-primary-500 to-secondary-500 rounded-full transition-all duration-300"
                      style={{ width: `${progress?.overallProgress || 0}%` }}
                    ></div>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4 mt-3">
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-xs font-medium text-neutral-500 dark:text-neutral-400">{t('domain.inputStage', 'Input')}</span>
                        <span className="text-xs font-semibold text-neutral-600 dark:text-neutral-300">{Math.round(progress?.inputProgress || 0)}%</span>
                      </div>
                      <div className="w-full h-1.5 bg-neutral-100 rounded-full overflow-hidden dark:bg-neutral-700">
                        <div 
                          className="h-full bg-green-500 rounded-full transition-all duration-300"
                          style={{ width: `${progress?.inputProgress || 0}%` }}
                        ></div>
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-xs font-medium text-neutral-500 dark:text-neutral-400">{t('domain.processingStage', 'Processing')}</span>
                        <span className="text-xs font-semibold text-neutral-600 dark:text-neutral-300">{Math.round(progress?.processingProgress || 0)}%</span>
                      </div>
                      <div className="w-full h-1.5 bg-neutral-100 rounded-full overflow-hidden dark:bg-neutral-700">
                        <div 
                          className="h-full bg-amber-500 rounded-full transition-all duration-300"
                          style={{ width: `${progress?.processingProgress || 0}%` }}
                        ></div>
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-xs font-medium text-neutral-500 dark:text-neutral-400">{t('domain.outputStage', 'Output')}</span>
                        <span className="text-xs font-semibold text-neutral-600 dark:text-neutral-300">{Math.round(progress?.outputProgress || 0)}%</span>
                      </div>
                      <div className="w-full h-1.5 bg-neutral-100 rounded-full overflow-hidden dark:bg-neutral-700">
                        <div 
                          className="h-full bg-secondary-500 rounded-full transition-all duration-300"
                          style={{ width: `${progress?.outputProgress || 0}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="mt-6 flex border-b border-gray-200 dark:border-neutral-700 overflow-x-auto scrollbar-thin">
                  <button
                    className={`py-3 px-4 font-medium text-sm whitespace-nowrap ${
                      activeView === 'tasks'
                        ? 'border-b-2 border-blue-500 text-blue-600 dark:text-blue-400'
                        : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
                    }`}
                    onClick={() => setActiveView('tasks')}
                    aria-selected={activeView === 'tasks'}
                    role="tab"
                  >
                    {t('domain.tasks', 'Tasks')}
                  </button>
                  <div className="relative">
                    <button
                      className="py-3 px-4 font-medium text-sm whitespace-nowrap text-gray-400 cursor-not-allowed"
                      aria-selected={false}
                      role="tab"
                      disabled={true}
                    >
                      {t('domain.input', 'Input & Analysis')}
                      <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-amber-100 text-amber-800">
                        {t('common.comingSoon', 'Coming Soon')}
                      </span>
                    </button>
                  </div>
                </div>
              </div>
              
              {connectionError && showConnectionErrors && (
                <div className="bg-amber-50 dark:bg-amber-900/30 border border-amber-200 dark:border-amber-800 rounded-md p-4 mb-4 flex items-start">
                  <AlertTriangle className="h-5 w-5 text-amber-600 dark:text-amber-500 mt-0.5 me-2 flex-shrink-0" />
                  <div>
                    <p className="text-sm font-medium text-amber-800 dark:text-amber-400">
                      Working in offline mode
                    </p>
                    <p className="text-xs text-amber-700 dark:text-amber-300 mt-1">
                      You appear to be working offline or have connection issues with the database. You can continue working, and changes will be saved locally.
                    </p>
                  </div>
                </div>
              )}
              
              {isAnalyzing && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                  <div className="bg-white dark:bg-neutral-800 p-8 rounded-lg shadow-lg max-w-md w-full">
                    <Loader2 className="h-10 w-10 text-blue-500 animate-spin mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-gray-800 text-center mb-2 dark:text-white">{t('domain.analyzing')}</h3>
                    <p className="text-gray-600 dark:text-gray-300 text-center mb-4">{t('domain.processingData')}</p>
                    
                    {/* Progress bar */}
                    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5 mb-2">
                      <div 
                        className="bg-blue-600 dark:bg-blue-500 h-2.5 rounded-full transition-all duration-300" 
                        style={{ width: `${analysisProgress}%` }}
                      />
                    </div>
                    <div className="flex items-center justify-between mb-4">
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {analysisCurrentStage}
                      </p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {formatElapsedTime(analysisElapsedTime)}
                      </p>
                    </div>
                    
                    {showTimedOutMessage ? (
                      <div className="mt-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-md p-3">
                        <div className="flex items-start">
                          <AlertTriangle className="h-5 w-5 text-amber-600 dark:text-amber-400 mt-0.5 me-2 flex-shrink-0" />
                          <div>
                            <p className="text-sm font-medium text-amber-800 dark:text-amber-400">
                              This is taking longer than usual
                            </p>
                            <p className="text-xs text-amber-700 dark:text-amber-300 mt-1">
                              The analysis is still running. For faster results in the future, try using shorter inputs or simplifying your text.
                            </p>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="mt-4 bg-blue-50 dark:bg-blue-900/20 rounded-md p-3">
                        <div className="flex items-start">
                          <Info className="h-4 w-4 text-blue-500 mt-0.5 me-2 flex-shrink-0" />
                          <p className="text-xs text-blue-700 dark:text-blue-300">
                            Analysis typically takes 20-40 seconds. The AI is analyzing your input to generate recommendations and templates.
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}
              
              {activeView === 'tasks' ? (
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-6">
                  <div className="space-y-4">
                    <h2 className={`text-lg font-semibold text-gray-800 flex items-center gap-2 dark:text-white`}>
                      <div className={`w-4 h-4 rounded-full bg-green-500 `}></div>
                      {t('domain.inputStage', 'Input')}
                    </h2>
                    <p className="text-sm text-gray-600 dark:text-gray-300">
                      {t('domain.inputDesc', 'Collect and organize information needed for this domain.')}
                    </p>
                    {renderedInputTasks}
                  </div>
                  
                  <div className="space-y-4">
                    <h2 className={`text-lg font-semibold text-gray-800 flex items-center gap-2 dark:text-white`}>
                      <div className={`w-4 h-4 rounded-full bg-yellow-500 `}></div>
                      {t('domain.processingStage', 'Processing')}
                    </h2>
                    <p className="text-sm text-gray-600 dark:text-gray-300">
                      {t('domain.processingDesc', 'Process the collected information to extract valuable insights.')}
                    </p>
                    {renderedProcessingTasks}
                  </div>
                  
                  <div className="space-y-4">
                    <h2 className={`text-lg font-semibold text-gray-800 flex items-center gap-2 dark:text-white`}>
                      <div className={`w-4 h-4 rounded-full bg-purple-500 `}></div>
                      {t('domain.outputStage', 'Output')}
                    </h2>
                    <p className="text-sm text-gray-600 dark:text-gray-300">
                      {t('domain.outputDesc', 'Generate final deliverables and documents based on the processed information.')}
                    </p>
                    {renderedOutputTasks}
                  </div>
                </div>
              ) : (
                <div className="bg-white rounded-lg shadow-sm p-6 dark:bg-neutral-800 dark:border dark:border-neutral-700">
                  <div className="bg-white rounded-lg shadow-sm p-4 mb-4 flex flex-col sm:flex-row justify-between items-center gap-4 dark:bg-neutral-800 dark:border dark:border-neutral-700">
                    <button
                      className="flex items-center text-primary-600 hover:text-primary-800 dark:text-primary-400 dark:hover:text-primary-300 w-full sm:w-auto"
                      onClick={() => setShowDocumentProcessor(!showDocumentProcessor)}
                    >
                      <Upload className="h-4 w-4 me-2" />
                      <span className="font-medium">{t('domain.uploadSupportingDocuments' ,'Upload Supporting Documents')}</span>
                      {showDocumentProcessor ? (
                        <ChevronUp className="h-4 w-4 ms-1" />
                      ) : (
                        <ChevronDown className="h-4 w-4 ms-1" />
                      )}
                    </button>
                    
                    <div className="flex items-center text-sm text-gray-600 dark:text-gray-300 w-full sm:w-auto justify-center sm:justify-start">
                      <FileText className="h-4 w-4 me-1" />
                      <span>{t('domain.documentsEnhanceAIAnalysisAccuracy' ,'Documents enhance AI analysis accuracy')}</span>
                    </div>
                  </div>
                  
                  {showDocumentProcessor && (
                    <MemoizedDocumentProcessor 
                      onProcessingComplete={handleProcessedDocument} 
                      domainId={domainId}
                    />
                  )}
                  
                  <div>
                    {domain && <MemoizedDomainInputForm domain={domain} onAnalyze={handleAnalyze} />}
                  
                    {domain && domainInput && domainInput.content && !domainOutput && (
                      <MemoizedAIConfigurationPanel domain={domain} onStartAnalysis={handleAnalyze} />
                  )}
                  
                    {domain && domainOutput && <MemoizedDomainOutputDisplay domain={domain} />}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </Suspense>
      
      {showTaskGenerator && selectedTaskForGenerator && !closingGeneratorRef.current && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 overflow-y-auto">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-y-auto">
            {tasks.find(t => t.id === selectedTaskForGenerator) && (
              <TaskOutputGenerator 
                task={tasks.find(t => t.id === selectedTaskForGenerator)!}
                taskData={activeProject?.domainData?.tasks?.[selectedTaskForGenerator] || {}}
                onOutputSaved={(taskId: string, output: string, attachments: string[]) => {
                  updateTaskData(taskId, { 
                    notes: output,
                    attachments: [
                      ...(activeProject?.domainData?.tasks?.[taskId]?.attachments || []),
                      ...attachments
                    ]
                  });
                  console.log('DomainDetail: Saving output and closing generator');
                  if (isMountedRef.current) {
                    // Set closing flag to prevent race conditions
                    closingGeneratorRef.current = true;
                    // Reset state to prevent reopening issues
                    setShowTaskGenerator(false);
                    setSelectedTaskForGenerator(null);
                    
                    // Release the closing lock after a delay
                    setTimeout(() => {
                      if (isMountedRef.current) {
                        closingGeneratorRef.current = false;
                      }
                    }, 500);
                  }
                }}
                onClose={() => {
                  // Check if we're already in the process of closing
                  if (closingGeneratorRef.current) {
                    console.log('DomainDetail: Already closing, ignoring duplicate close call');
                    return;
                  }
                  
                  // Verify component is still mounted
                  if (!isMountedRef.current) {
                    console.warn('DomainDetail: Attempted to close unmounted generator');
                    return;
                  }
                  
                  // Set closing lock
                  closingGeneratorRef.current = true;
                  console.log('DomainDetail: Force closing TaskOutputGenerator, resetting state');
                  
                  // Force reset all related state SYNCHRONOUSLY
                  setShowTaskGenerator(false);
                  setSelectedTaskForGenerator(null);
                  
                  // Release the lock after a delay to prevent immediate reopening
                  setTimeout(() => {
                    if (isMountedRef.current) {
                      closingGeneratorRef.current = false;
                      console.log('DomainDetail: Generator closing complete, lock released');
                    }
                  }, 500);
                }}
              />
            )}
          </div>
        </div>
      )}
    </ErrorBoundary>
  );
};

export default DomainDetail;