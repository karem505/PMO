import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAppStore } from '../store';
import { tasks, domains } from '../data';
import { ArrowLeft, Check, Clock, FileText, Download, Paperclip, Edit, Save, Loader2, AlertTriangle, ArrowRight } from 'lucide-react';
import TaskManager from '../components/TaskManager';
import TaskOutputGenerator from '../components/TaskOutputGenerator';
import TaskFileAttachment from '../components/TaskFileAttachment';
import { useLanguage } from '../contexts/LanguageContext';
import { documentProcessingService } from '../services/documentProcessingService';
import { useToast } from '../hooks/useToast';

// Add or update the TaskData interface to include customFields property
interface TaskData {
  notes?: string;
  completed?: boolean;
  attachments?: string[];
  customFields?: Record<string, any>;
  acceptanceStatus?: 'accepted' | 'needs-refinement' | 'rejected';
  acceptanceTimestamp?: string;
}

const TaskDetailPage: React.FC = () => {
  const { taskId } = useParams<{ taskId: string }>();
  const navigate = useNavigate();
  const { t, isRTL } = useLanguage();
  const toast = useToast();
  
  const { getActiveProject,  updateTaskData } = useAppStore();
  const activeProject = getActiveProject();
  
  const [task, setTask] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [taskData, setTaskData] = useState<any>(null);
  const [editMode, setEditMode] = useState(false);
  const [saving, setSaving] = useState(false);
  const [relatedDocuments, setRelatedDocuments] = useState<any[]>([]);
  
  // Form state
  const [notes, setNotes] = useState('');
  const [completed, setCompleted] = useState(false);
  const [customFields, setCustomFields] = useState<any>({});
  
  useEffect(() => {
    if (!taskId) {
      setError('Task ID is missing');
      setLoading(false);
      return;
    }
    // Find task in predefined tasks
    const foundTask = tasks.find(t => t.id === taskId);
    if (!foundTask) {
      setError('Task not found');
      setLoading(false);
      return;
    }
    
    setTask(foundTask);
    
    // Get task data from store
    if (activeProject) {
      const data = activeProject.domainData?.tasks?.[taskId] || { 
        completed: false, 
        notes: '', 
        attachments: [],
        customFields: {}
      };
      
      setTaskData(data);
      setNotes(data.notes || '');
      setCompleted(data.completed || false);
      setCustomFields(data.customFields || {});
      
      // Fetch related documents
      loadRelatedDocuments(foundTask.domainId);
    }
    
    setLoading(false);
  }, [taskId, activeProject]);
  
  const loadRelatedDocuments = async (domainId: number) => {
    if (!activeProject) return;
    
    try {
      const docs = await documentProcessingService.getDomainDocuments(domainId, activeProject.id);
      setRelatedDocuments(docs);
    } catch (error) {
      console.error('Error loading related documents:', error);
    }
  };
  
  const handleSave = async () => {
    if (!task || !activeProject) return;
    
    setSaving(true);
    
    try {
      // Update task data in store
      await updateTaskData(task.id, {
        notes,
        completed,
        customFields
      } as TaskData);
      
      // Update local state without reloading
      setTaskData({
        ...taskData,
        notes,
        completed,
        customFields
      });
      
      setEditMode(false);
      toast.success('Task updated successfully');
    } catch (error) {
      console.error('Error saving task:', error);
      toast.error('Failed to save task data');
    } finally {
      setSaving(false);
    }
  };
  
  const handleOutputSaved = (taskId: string, output: string, attachments: string[]) => {
    setNotes(output);
    updateTaskData(taskId, { 
      notes: output,
      // Handle attachments if needed
    });
  };
  
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 text-blue-600 animate-spin" />
      </div>
    );
  }
  
  if (error || !task) {
    return (
      <div className="max-w-4xl mx-auto p-6 bg-white rounded-lg shadow-sm">
        <div className="flex items-center text-red-600 mb-4">
          <AlertTriangle className="h-5 w-5 me-2" />
          <h2 className="text-xl font-semibold">{error || 'Task not found'}</h2>
        </div>
        <button
          onClick={() => navigate('/tasks')}
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
        >
          Back to Tasks
        </button>
      </div>
    );
  }
  
  // Find domain
  const domain = domains.find(d => d.id === task.domainId);
  
  return (
    <div className="max-w-4xl mx-auto">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center">
          <button
            onClick={() => navigate('/tasks')}
            className="me-3 text-gray-600 hover:text-gray-800 dark:text-gray-300 dark:hover:text-gray-100"
          >
            {isRTL ? <ArrowRight className="h-5 w-5" /> : <ArrowLeft className="h-5 w-5" />}
          </button>
          <h1 className="text-2xl font-bold  text-neutral-800 dark:text-neutral-200">{t(`domains.${task.domainId}.tasks.${task.id}.title`)}</h1>
        </div>
        <p className="text-neutral-600 dark:text-neutral-400 mt-1 ms-8">
          {t(`domains.${task.domainId}.name`)} • {t(`domains.${task.domainId}.tasks.${task.id}.stage`)} 
        </p>
      </div>
      
      {/* Task management card */}
      <div className="bg-white rounded-lg shadow-sm mb-6 overflow-hidden">
        <div className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <h2 className="text-lg font-semibold text-neutral-700">{t(`domains.${task.domainId}.tasks.${task.id}.title`)}</h2>
              <p className="text-gray-600 mt-1">{t(`domains.${task.domainId}.tasks.${task.id}.description`)}</p>
              
              <div className="mt-2 flex items-center flex-wrap gap-2">
                <span className={`text-xs px-2 py-1 capitalize rounded-full ${
                  task.stage === 'input' ? 'bg-green-100 text-green-800' : 
                  task.stage === 'processing' ? 'bg-yellow-100 text-yellow-800' : 
                  'bg-purple-100 text-purple-800'
                }`}>
                  {t(`domains.${task.domainId}.tasks.${task.id}.stage`)}
                </span>
                
                {completed && (
                  <span className="text-xs px-2 py-1 rounded-full bg-green-100 text-green-800 flex items-center">
                    <Check className="h-3 w-3 me-1" />
                    Completed
                  </span>
                )}
                
                {taskData?.attachments?.length > 0 && (
                  <span className="text-xs px-2 py-1 rounded-full bg-blue-100 text-blue-800 flex items-center">
                    <Paperclip className="h-3 w-3 me-1" />
                    {taskData.attachments.length} Attachment{taskData.attachments.length !== 1 ? 's' : ''}
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-100">
          {editMode ? (
            <div className="p-6 space-y-4">
              {/* Completion toggle */}
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="task-completed"
                  checked={completed}
                  onChange={(e) => setCompleted(e.target.checked)}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                />
                <label htmlFor="task-completed" className="ms-2 text-sm text-gray-700">
                  {t('tasks.markAsCompleted', 'Mark as completed')}
                </label>
              </div>
              
              {/* Notes editor */}
              <div>
                <label htmlFor="task-notes" className="block text-sm font-medium text-gray-700 mb-1">
                  {t('tasks.notes', 'Notes')}
                </label>
                <textarea
                  id="task-notes"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 text-neutral-800 fo text-sm"
                  rows={6}
                  placeholder={t('tasks.addNotes', 'Add notes about this task...')}
                ></textarea>
              </div>
              
              {/* Custom fields */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    {t('tasks.priority', 'Priority')}
                  </label>
                  <select
                    value={customFields.priority || 'medium'}
                    onChange={(e) => setCustomFields({...customFields, priority: e.target.value})}
                    className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 text-neutral-800  text-sm"
                  >
                    <option value="low">{t('tasks.low', 'Low')}</option>
                    <option value="medium">{t('tasks.medium', 'Medium')}</option>
                    <option value="high">{t('tasks.high', 'High')}</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    {t('tasks.targetCompletionDate', 'Target Completion Date')}
                  </label>
                  <input
                    type="date"
                    value={customFields.dueDate || ''}
                    onChange={(e) => setCustomFields({...customFields, dueDate: e.target.value})}
                    className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 text-neutral-800 fo text-sm"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    {t('tasks.assignedTo', 'Assigned To')}
                  </label>
                  <input
                    type="text"
                    value={customFields.assignedTo || ''}
                    onChange={(e) => setCustomFields({...customFields, assignedTo: e.target.value})}
                    className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 text-neutral-800 fo text-sm"
                    placeholder={t('tasks.enterNameOrEmail', 'Enter name or email')}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    {t('tasks.estimatedHours', 'Estimated Hours')}
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="0.5"
                    value={customFields.estimatedHours || ''}
                    onChange={(e) => setCustomFields({...customFields, estimatedHours: e.target.value})}
                    className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 text-neutral-800 fo text-sm"
                  />
                </div>
              </div>
              
              {/* File attachments */}
              <TaskFileAttachment 
                taskId={task.id}
                projectId={activeProject?.id}
                existingAttachments={taskData?.attachments?.map((att: string) => {
                  try {
                    return typeof att === 'string' ? JSON.parse(att) : att;
                  } catch (e) {
                    return { name: 'Unknown attachment', url: '#', id: 'unknown' };
                  }
                }) || []}
              />
            </div>
          ) : (
            <>
              {taskData && (
                <div className="p-6">
                  <div className="flex items-center mb-4">
                    <div className={`p-1 rounded-md ${completed ? 'bg-green-100' : 'bg-yellow-100'}`}>
                      {completed ? (
                        <Check className="h-4 w-4 text-green-600" />
                      ) : (
                        <Clock className="h-4 w-4 text-yellow-600" />
                      )}
                    </div>
                    <span className={`ms-2 text-sm font-medium ${completed ? 'text-green-700' : 'text-yellow-700'}`}>
                      {completed ? t(`tasks.completed`, 'Completed') : t(`tasks.inProgress`, 'In Progress')}
                    </span>
                    
                    {customFields.priority && (
                      <span className={`ms-4 px-2 py-0.5 text-xs rounded-full ${
                        customFields.priority === 'high' ? 'bg-red-100 text-red-800' :
                        customFields.priority === 'medium' ? 'bg-blue-100 text-blue-800' :
                        'bg-green-100 text-green-800'
                      }`}>
                        {customFields.priority.charAt(0).toUpperCase() + customFields.priority.slice(1)} {t('tasks.priority', 'Priority')}
                      </span>
                    )}
                  </div>
                  
                  {notes && (
                    <div className="mt-4">
                      <h3 className="text-sm font-medium text-gray-700 mb-2">{t('tasks.notes', 'Notes')}:</h3>
                      <div className="bg-gray-50 p-4 rounded-md text-gray-700 text-sm">
                        {notes.split('\n').map((line, i) => (
                          <p key={i} className={i > 0 ? 'mt-2' : ''}>{line}</p>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                    {customFields.dueDate && (
                      <div className="bg-blue-50 p-3 rounded-md">
                        <h3 className="text-xs font-medium text-blue-800 mb-1">{t('tasks.targetCompletionDate', 'Target Completion Date')}</h3>
                        <p className="text-sm text-blue-700">{new Date(customFields.dueDate).toLocaleDateString()}</p>
                      </div>
                    )}
                    
                    {customFields.assignedTo && (
                      <div className="bg-purple-50 p-3 rounded-md">
                        <h3 className="text-xs font-medium text-purple-800 mb-1">{t('tasks.assignedTo', 'Assigned To')}</h3>
                        <p className="text-sm text-purple-700">{customFields.assignedTo}</p>
                      </div>
                    )}
                    
                    {customFields.estimatedHours && (
                      <div className="bg-green-50 p-3 rounded-md">
                        <h3 className="text-xs font-medium text-green-800 mb-1">{t('tasks.estimatedHours', 'Estimated Hours')}</h3>
                        <p className="text-sm text-green-700">{customFields.estimatedHours} hours</p>
                      </div>
                    )}
                  </div>
                  
                  {taskData.attachments && taskData.attachments.length > 0 && (
                    <div className="mt-6">
                      <h3 className="text-sm font-medium text-gray-700 mb-2">
                        {t('tasks.attachments', 'Attachments')} ({taskData.attachments.length}):
                      </h3>
                      <div className="space-y-2">
                        {taskData.attachments.map((attachment: string, index: number) => {
                          let parsedAttachment;
                          try {
                            parsedAttachment = typeof attachment === 'string' ? JSON.parse(attachment) : attachment;
                          } catch (e) {
                            console.error('Error parsing attachment:', e);
                            return null;
                          }
                          
                          if (!parsedAttachment) return null;
                          
                          return (
                            <div key={index} className="flex items-center p-2 bg-gray-50 rounded-md border border-gray-200">
                              <FileText className="h-4 w-4 text-blue-500 me-2" />
                              <span className="text-sm text-gray-700 flex-1 truncate">{parsedAttachment.name}</span>
                              <a 
                                href={parsedAttachment.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="p-1 hover:bg-gray-200 rounded-md"
                              >
                                <Download className="h-4 w-4 text-gray-600" />
                              </a>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </>
          )}
        </div>
      </div>
      
      {/* Best practices section */}
      {task.bestPractices && task.bestPractices.length > 0 && (
        <div className="bg-white rounded-lg shadow-sm mb-6 p-6">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">{t('tasks.bestPractices', 'Best Practices')}</h2>
          <div className="space-y-2">
            {task.bestPractices.map((practice: string, index: number) => (
              <div key={index} className="p-3 bg-green-50 rounded-md">
                <p className="text-green-800">{t(`domains.${task.domainId}.tasks.${task.id}.bestPractices.${index}`,practice)}</p>
              </div>
            ))}
          </div>
        </div>
      )}
      
      {/* Task templates section */}
      {task.templates && task.templates.length > 0 && (
        <div className="bg-white rounded-lg shadow-sm mb-6 p-6">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">{t('tasks.templates', 'Templates')}</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {task.templates.map((template: string, index: number) => (
              <div key={index} className="p-4 border border-gray-200 rounded-lg hover:border-blue-300 transition-colors">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-medium text-gray-800">{template}</h3>
                  <FileText className="h-5 w-5 text-blue-500" />
                </div>
                <p className="text-sm text-gray-600">{t('tasks.templateForStandardizedImplementation', 'Template for standardized implementation')}</p>
                <div className="mt-4 flex justify-end">
                  <button className="px-3 py-1.5 bg-blue-600 text-white rounded-md hover:bg-blue-700 text-sm">
                    {t('tasks.viewTemplate', 'View Template')}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      
      {/* Task output generator */}
      <div className="bg-white rounded-lg shadow-sm mb-6">
        <h2 className="text-lg font-semibold text-gray-800 mb-4 px-6 pt-6">{t('tasks.generateTaskOutput', 'Generate Task Output')}</h2>
        <TaskOutputGenerator 
          task={task}
          taskData={taskData}
          onOutputSaved={handleOutputSaved}
        />
      </div>
      
      {/* Related documents section */}
      {relatedDocuments.length > 0 && (
        <div className="bg-white rounded-lg shadow-sm mb-6 p-6">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">{t('tasks.relatedDocuments', 'Related Documents')}</h2>
          <div className="space-y-3">
            {relatedDocuments.map((doc, index) => (
              <div key={index} className="flex items-start p-3 bg-gray-50 rounded-lg border border-gray-200">
                <FileText className="h-5 w-5 text-blue-500 mt-0.5 me-3" />
                <div>
                  <h3 className="font-medium text-gray-800">{doc.metadata.source || `Document ${index + 1}`}</h3>
                  <p className="text-sm text-gray-600 mt-1 line-clamp-2">{doc.content.substring(0, 150)}...</p>
                  <div className="mt-2">
                    <button className="text-xs text-blue-600 hover:text-blue-800 font-medium">{t('tasks.viewFullContent', 'View Full Content')}</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default TaskDetailPage;