import React, { useEffect, useState } from 'react';
import { testSupabaseConnection, supabase } from '../services/supabaseClient';
import ConnectionStatus from '../components/ConnectionStatus';
import { ArrowLeft, WifiOff, Wifi, Database, Server, RefreshCw, Activity, Check, X, Globe, Shield } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAppStore } from '../store';

const ConnectionStatusPage: React.FC = () => {
  const navigate = useNavigate();
  const { connectionError, setConnectionError } = useAppStore();
  const [isChecking, setIsChecking] = useState(false);
  const [connectionResults, setConnectionResults] = useState<{
    database: boolean;
    api: boolean;
    auth: boolean;
    storage: boolean;
    lastChecked: Date | null;
  }>({
    database: false,
    api: false,
    auth: false,
    storage: false,
    lastChecked: null
  });

  const checkAllConnections = async () => {
    setIsChecking(true);

    try {
      // Check database connection
      const dbResult = await testSupabaseConnection();
      console.log('ConnectionStatusPage dbResult', dbResult);
      // Check auth status
      let authResult = false;
      try {
        console.log('ConnectionStatusPage supabase', supabase);
        const { data } = await supabase.auth.getSession();
        console.log('ConnectionStatusPage data', data);
        authResult = !!data.session;
      } catch (error) {
        console.error('Auth check failed:', error);
      }
      
      // Check storage access
      let storageResult = false;
      try {
        const { data } = await supabase.storage.listBuckets();
        storageResult = Array.isArray(data);
      } catch (error) {
        console.error('Storage check failed:', error);
      }
      
      // Check general API access
      let apiResult = false;
      try {
        console.log('ConnectionStatusPage supabase', supabase);
        const { data } = await supabase.from('profiles').select('count', { count: 'exact', head: true });
        console.log('ConnectionStatusPage data', data);
        apiResult = data !== null;
      } catch (error) {
        console.error('API check failed:', error);
      }
      
      // Update results
      setConnectionResults({
        database: dbResult.success,
        auth: authResult,
        storage: storageResult,
        api: apiResult,
        lastChecked: new Date()
      });
      
      // Update global connection state
      const overallStatus = dbResult.success && apiResult;
      setConnectionError(!overallStatus);
      
    } catch (error) {
      console.error('Connection checks failed:', error);
      setConnectionError(true);
    } finally {
      setIsChecking(false);
    }
  };

  // Run check on mount
  useEffect(() => {
    checkAllConnections();
  }, []);
  
  // Get network status from browser
  const isOnline = typeof navigator !== 'undefined' ? navigator.onLine : true;
  
  return (
    <div className="max-w-3xl mx-auto">
      <div className="flex items-center mb-6">
        <button
          onClick={() => navigate(-1)}
          className="mr-3 text-gray-600 hover:text-gray-800"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-2xl font-bold  text-gray-800">Connection Status</h1>
      </div>
      
      <div className="space-y-6">
        {/* Overall Status */}
        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-100">
          <ConnectionStatus showDetailed={true} />
        </div>
        
        {/* Network and Browser Status */}
        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-100">
          <div className="flex items-center mb-4">
            <Globe className="h-5 w-5 text-blue-600 mr-2" />
            <h2 className="text-lg font-semibold text-gray-800">Network Status</h2>
          </div>
          
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg border border-gray-200 mb-4">
            <div className="flex items-center">
              {isOnline ? (
                <Wifi className="h-5 w-5 text-green-500 mr-3" />
              ) : (
                <WifiOff className="h-5 w-5 text-red-500 mr-3" />
              )}
              <div>
                <h3 className="font-medium text-gray-800">Network Connection</h3>
                <p className="text-sm text-gray-600">Browser reported network status</p>
              </div>
            </div>
            <div className={`px-2 py-1 rounded-full text-sm ${isOnline ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
              {isOnline ? 'Online' : 'Offline'}
            </div>
          </div>
          
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
              <div className="flex items-center">
                <Activity className="h-4 w-4 text-blue-600 mr-2" />
                <span className="text-sm">Automatic reconnection</span>
              </div>
              <div className="px-2 py-0.5 rounded-full text-xs bg-blue-100 text-blue-800">Enabled</div>
            </div>
          </div>
        </div>
        
        {/* Detailed Connection Status */}
        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <Server className="h-5 w-5 text-indigo-600 mr-2" />
              <h2 className="text-lg font-semibold text-gray-800">Service Status</h2>
            </div>
            <button 
              className="px-3 py-1.5 bg-gray-100 text-gray-700 rounded-md flex items-center text-sm hover:bg-gray-200"
              onClick={checkAllConnections}
              disabled={isChecking}
            >
              <RefreshCw className={`h-4 w-4 mr-1.5 ${isChecking ? 'animate-spin' : ''}`} />
              {isChecking ? 'Checking...' : 'Check Now'}
            </button>
          </div>
          
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-white rounded-lg border border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center">
                    <Database className="h-5 w-5 text-blue-600 mr-2" />
                    <h3 className="font-medium text-gray-800">Database</h3>
                  </div>
                  {isChecking ? (
                    <RefreshCw className="h-4 w-4 text-gray-400 animate-spin" />
                  ) : connectionResults.database ? (
                    <Check className="h-5 w-5 p-0.5 rounded-full bg-green-100 text-green-600" />
                  ) : (
                    <X className="h-5 w-5 p-0.5 rounded-full bg-red-100 text-red-600" />
                  )}
                </div>
                <p className="text-sm text-gray-600">Database connection status</p>
              </div>
              
              <div className="p-4 bg-white rounded-lg border border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center">
                    <Server className="h-5 w-5 text-blue-600 mr-2" />
                    <h3 className="font-medium text-gray-800">API Service</h3>
                  </div>
                  {isChecking ? (
                    <RefreshCw className="h-4 w-4 text-gray-400 animate-spin" />
                  ) : connectionResults.api ? (
                    <Check className="h-5 w-5 p-0.5 rounded-full bg-green-100 text-green-600" />
                  ) : (
                    <X className="h-5 w-5 p-0.5 rounded-full bg-red-100 text-red-600" />
                  )}
                </div>
                <p className="text-sm text-gray-600">API access status</p>
              </div>
              
              <div className="p-4 bg-white rounded-lg border border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center">
                    <Shield className="h-5 w-5 text-blue-600 mr-2" />
                    <h3 className="font-medium text-gray-800">Authentication</h3>
                  </div>
                  {isChecking ? (
                    <RefreshCw className="h-4 w-4 text-gray-400 animate-spin" />
                  ) : connectionResults.auth ? (
                    <Check className="h-5 w-5 p-0.5 rounded-full bg-green-100 text-green-600" />
                  ) : (
                    <X className="h-5 w-5 p-0.5 rounded-full bg-red-100 text-red-600" />
                  )}
                </div>
                <p className="text-sm text-gray-600">Auth service status</p>
              </div>
              
              <div className="p-4 bg-white rounded-lg border border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center">
                    <Database className="h-5 w-5 text-blue-600 mr-2" />
                    <h3 className="font-medium text-gray-800">Storage</h3>
                  </div>
                  {isChecking ? (
                    <RefreshCw className="h-4 w-4 text-gray-400 animate-spin" />
                  ) : connectionResults.storage ? (
                    <Check className="h-5 w-5 p-0.5 rounded-full bg-green-100 text-green-600" />
                  ) : (
                    <X className="h-5 w-5 p-0.5 rounded-full bg-red-100 text-red-600" />
                  )}
                </div>
                <p className="text-sm text-gray-600">File storage status</p>
              </div>
            </div>
            
            <div className="p-4 bg-gray-50 rounded-md border border-gray-200 text-sm text-gray-600">
              Last checked: {connectionResults.lastChecked ? connectionResults.lastChecked.toLocaleString() : 'Never'}
            </div>
          </div>
        </div>
        
        {/* Offline Capabilities */}
        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-100">
          <div className="flex items-center mb-4">
            <WifiOff className="h-5 w-5 text-amber-600 mr-2" />
            <h2 className="text-lg font-semibold text-gray-800">Offline Capabilities</h2>
          </div>
          
          <p className="text-sm text-gray-600 mb-4">
            This application provides offline capabilities that allow you to continue working even when your internet connection is unavailable.
            Your changes will be saved locally and synchronized with the server when your connection is restored.
          </p>
          
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-green-50 rounded-md">
              <div className="flex items-center">
                <Check className="h-4 w-4 text-green-600 mr-2" />
                <span className="text-sm font-medium text-green-800">Document editing</span>
              </div>
              <div className="px-2 py-0.5 rounded-full text-xs bg-green-200 text-green-800">Available offline</div>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-green-50 rounded-md">
              <div className="flex items-center">
                <Check className="h-4 w-4 text-green-600 mr-2" />
                <span className="text-sm font-medium text-green-800">Task management</span>
              </div>
              <div className="px-2 py-0.5 rounded-full text-xs bg-green-200 text-green-800">Available offline</div>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-amber-50 rounded-md">
              <div className="flex items-center">
                <WifiOff className="h-4 w-4 text-amber-600 mr-2" />
                <span className="text-sm font-medium text-amber-800">AI analysis</span>
              </div>
              <div className="px-2 py-0.5 rounded-full text-xs bg-amber-200 text-amber-800">Limited offline support</div>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-amber-50 rounded-md">
              <div className="flex items-center">
                <WifiOff className="h-4 w-4 text-amber-600 mr-2" />
                <span className="text-sm font-medium text-amber-800">File uploads</span>
              </div>
              <div className="px-2 py-0.5 rounded-full text-xs bg-amber-200 text-amber-800">Requires connection</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConnectionStatusPage;