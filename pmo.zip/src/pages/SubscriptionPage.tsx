import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../components/auth/AuthContext';
import { subscriptionService, SubscriptionTier, TIER_LIMITS } from '../services/subscriptionService';
import { stripeService } from '../services/stripeService';
import { CreditCard, Calendar, Clock, Shield, AlertCircle, CheckCircle, Loader2, ZapOff, Zap, Download, BarChart, Upload, Check } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const SubscriptionPage: React.FC = () => {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [subscription, setSubscription] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [usage, setUsage] = useState<Record<string, number>>({});
  const [processingAction, setProcessingAction] = useState<string | null>(null);
  
  // Load subscription data
  useEffect(() => {
    const loadSubscriptionData = async () => {
      if (!currentUser) return;
      
      try {
        setLoading(true);  // Set loading to true at the start
        
        // Get subscription
        const subscriptionData = await subscriptionService.getUserSubscription(currentUser.id);
        setSubscription(subscriptionData);
        
        // Get usage for key features
        const projectsUsage = await subscriptionService.getFeatureUsage(currentUser.id, 'projects');
        const aiAnalysisUsage = await subscriptionService.getFeatureUsage(currentUser.id, 'aiAnalysis');
        const storageUsage = await subscriptionService.getFeatureUsage(currentUser.id, 'storage');
        
        setUsage({
          projects: projectsUsage,
          aiAnalysis: aiAnalysisUsage,
          storage: storageUsage
        });
      } catch (error) {
        console.error('Error loading subscription data:', error);
        setError(t('subscription.failedToLoadData', 'Failed to load subscription data'));
      } finally {
        setLoading(false);  // Set loading to false only once at the end
      }
    };
    
    loadSubscriptionData();
  }, [currentUser, t]);
  
  // Format next billing date
  const formatDate = (dateString?: string) => {
    if (!dateString) return t('subscription.notAvailable', 'N/A');
    
    return new Date(dateString).toLocaleDateString(t('common.locale', 'en-US'), {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };
  
  // Manage subscription
  const handleManageSubscription = async () => {
    if (!currentUser) return;
    
    setProcessingAction('manage');
    
    try {
      const { url, error } = await stripeService.createCustomerPortalSession(
        currentUser.id,
        `${window.location.origin}/dashboard/settings/subscription`
      );
      
      if (error || !url) {
        throw new Error(error || t('subscription.failedToCreateSession', 'Failed to create customer portal session'));
      }
      
      // Redirect to Stripe customer portal
      await stripeService.redirectToCustomerPortal(url);
    } catch (error: any) {
      console.error('Error creating customer portal session:', error);
      setError(error.message || t('subscription.failedToOpenPortal', 'Failed to open subscription management portal'));
    } finally {
      setProcessingAction(null);
    }
  };
  
  // Upgrade subscription
  const handleUpgrade = () => {
    navigate('/pricing');
  };
  
  // Calculate usage percentage
  const calculateUsagePercentage = (feature: string) => {
    if (!subscription) return 0;
    
    // Convert SubscriptionTier enum value to lowercase key for TIER_LIMITS
    const tierKey = subscription.tier ? subscription.tier.toLowerCase() : 'free';
    const limit = TIER_LIMITS[tierKey as keyof typeof TIER_LIMITS][feature as keyof typeof TIER_LIMITS[keyof typeof TIER_LIMITS]];
    const current = usage[feature] || 0;
    
    if (limit === 'unlimited' || limit === 0) return 0;
    return Math.min(100, (current / (limit as number)) * 100);
  };
  
  // Get tier name for display
  const getTierName = (tier?: SubscriptionTier) => {
    if (!tier) return t('subscription.unknown');
    
    switch (tier) {
      case SubscriptionTier.FREE:
        return t('subscription.free');
      case SubscriptionTier.PREMIUM:
        return t('subscription.premium');
      case SubscriptionTier.ENTERPRISE:
        return t('subscription.enterprise');
      default:
        return tier;
    }
  };
  
  // Get tier class for styling
  const getTierClass = (tier?: SubscriptionTier) => {
    if (!tier) return '';
    
    switch (tier) {
      case SubscriptionTier.FREE:
        return 'bg-gray-100 text-gray-800';
      case SubscriptionTier.PREMIUM:
        return 'bg-primary-100 text-primary-800';
      case SubscriptionTier.ENTERPRISE:
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 text-primary-500 animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold  text-neutral-800 dark:text-neutral-200 mb-8">{t('subscription.title')}</h1>
      
      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
          <div className="flex items-start">
            <AlertCircle className="h-5 w-5 text-red-500 mt-0.5 me-2 flex-shrink-0" />
            <p className="text-sm text-red-800">{error}</p>
          </div>
        </div>
      )}
      
      {/* Subscription Overview */}
      <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-100 mb-6">
        <div className="flex justify-between items-start">
          <div>
            <h2 className="text-lg font-medium text-gray-900 flex items-center">
              <CreditCard className="h-5 w-5 me-2 text-primary-500" />
              {t('subscription.currentPlan')}
            </h2>
            
            <div className="mt-4 flex items-center">
              <span className={`px-2.5 py-0.5 rounded-full text-gray-700 text-sm font-medium ${getTierClass(subscription?.tier)}`}>
                {getTierName(subscription?.tier)}
              </span>
              
              {subscription?.status === 'trial' && (
                <span className="ms-2 px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                  {t('subscription.trial')}
                </span>
              )}
              
              {subscription?.cancel_at_period_end && (
                <span className="ms-2 px-2.5 py-0.5 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                  {t('subscription.cancelsAtPeriodEnd')}
                </span>
              )}
            </div>
          </div>
          
          <div className="flex space-x-3">
            {subscription?.tier === SubscriptionTier.FREE ? (
              <button
                className="px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 flex items-center"
                onClick={handleUpgrade}
              >
                <Zap className="h-4 w-4 me-1.5" />
                {t('subscription.upgradePlan')}
              </button>
            ) : (
              <>
                <button
                  className="px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 flex items-center"
                  onClick={handleManageSubscription}
                  disabled={processingAction === 'manage'}
                >
                  {processingAction === 'manage' ? (
                    <Loader2 className="h-4 w-4 me-1.5 animate-spin" />
                  ) : (
                    <CreditCard className="h-4 w-4 me-1.5" />
                  )}
                  {t('subscription.manageSubscription')}
                </button>
              </>
            )}
          </div>
        </div>
        
        {subscription && subscription.tier !== SubscriptionTier.FREE && (
          <div className="mt-8 border-t border-gray-100 pt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <h3 className="text-sm font-medium text-gray-500 mb-1">
                  {t('subscription.nextBillingDate')}
                </h3>
                <p className="flex items-center text-gray-900">
                  <Calendar className="h-4 w-4 me-1.5 text-primary-500" />
                  {formatDate(subscription.current_period_end)}
                </p>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-gray-500 mb-1">
                  {t('subscription.billingCycle')}
                </h3>
                <p className="flex items-center text-gray-900">
                  <Clock className="h-4 w-4 me-1.5 text-primary-500" />
                  {subscription.interval === 'month' 
                    ? t('subscription.monthly') 
                    : t('subscription.annually')}
                </p>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-gray-500 mb-1">
                  {t('subscription.paymentMethod')}
                </h3>
                <p className="flex items-center text-gray-900">
                  <Shield className="h-4 w-4 me-1.5 text-primary-500" />
                  {subscription.payment_method 
                    ? `${subscription.payment_method.brand} •••• ${subscription.payment_method.last4}`
                    : t('subscription.notAvailable', 'N/A')}
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
      
      {/* Usage Overview */}
      <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-100 mb-6">
        <h2 className="text-lg font-medium text-gray-900 mb-6 flex items-center">
          <BarChart className="h-5 w-5 me-2 text-primary-500" />
          {t('subscription.usageOverview')}
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Projects */}
          <div className="p-4 border border-gray-200 rounded-lg">
            <div className="flex justify-between items-start mb-2">
              <h3 className="text-sm font-medium text-gray-700">{t('subscription.projects')}</h3>
              {subscription?.tier === SubscriptionTier.FREE ? (
                <span className="px-2 py-1 bg-yellow-50 text-yellow-800 text-xs font-medium rounded flex items-center">
                  <ZapOff className="h-3 w-3 me-1" />
                  {t('subscription.limited')}
                </span>
              ) : (
                <span className="px-2 py-1 bg-green-50 text-green-800 text-xs font-medium rounded flex items-center">
                  <CheckCircle className="h-3 w-3 me-1" />
                  {t('subscription.unlimited')}
                </span>
              )}
            </div>
            
            {subscription?.tier === SubscriptionTier.FREE && (
              <>
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden mb-2">
                  <div 
                    className="h-full bg-primary-500 rounded-full" 
                    style={{ width: `${calculateUsagePercentage('projects')}%` }}
                  ></div>
                </div>
                
                <p className="text-sm text-gray-500">
                  {usage.projects || 0} / {TIER_LIMITS[subscription.tier?.toLowerCase() as keyof typeof TIER_LIMITS].projects} {t('subscription.projectsUsed')}
                </p>
              </>
            )}
          </div>
          
          {/* AI Analysis */}
          <div className="p-4 border border-gray-200 rounded-lg">
            <div className="flex justify-between items-start mb-2">
              <h3 className="text-sm font-medium text-gray-700">{t('subscription.aiAnalysis')}</h3>
              {subscription?.tier === SubscriptionTier.FREE ? (
                <span className="px-2 py-1 bg-yellow-50 text-yellow-800 text-xs font-medium rounded flex items-center">
                  <ZapOff className="h-3 w-3 me-1" />
                  {t('subscription.limited')}
                </span>
              ) : (
                <span className="px-2 py-1 bg-green-50 text-green-800 text-xs font-medium rounded flex items-center">
                  <CheckCircle className="h-3 w-3 me-1" />
                  {t('subscription.included')}
                </span>
              )}
            </div>
            
            {subscription?.tier === SubscriptionTier.FREE && (
              <>
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden mb-2">
                  <div 
                    className="h-full bg-primary-500 rounded-full" 
                    style={{ width: `${calculateUsagePercentage('aiAnalysis')}%` }}
                  ></div>
                </div>
                
                <p className="text-sm text-gray-500">
                  {usage.aiAnalysis || 0} / {TIER_LIMITS[subscription.tier?.toLowerCase() as keyof typeof TIER_LIMITS].aiAnalysis} {t('subscription.analysesUsed')}
                </p>
              </>
            )}
          </div>
          
          {/* Storage */}
          <div className="p-4 border border-gray-200 rounded-lg">
            <div className="flex justify-between items-start mb-2">
              <h3 className="text-sm font-medium text-gray-700">{t('subscription.storage')}</h3>
              {subscription?.tier === SubscriptionTier.FREE ? (
                <span className="px-2 py-1 bg-yellow-50 text-yellow-800 text-xs font-medium rounded flex items-center">
                  <ZapOff className="h-3 w-3 me-1" />
                  {t('subscription.limited')}
                </span>
              ) : (
                <span className="px-2 py-1 bg-green-50 text-green-800 text-xs font-medium rounded flex items-center">
                  <CheckCircle className="h-3 w-3 me-1" />
                  {t('subscription.advanced')}
                </span>
              )}
            </div>
            
            {subscription?.tier === SubscriptionTier.FREE && (
              <>
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden mb-2">
                  <div 
                    className="h-full bg-primary-500 rounded-full" 
                    style={{ width: `${calculateUsagePercentage('storage')}%` }}
                  ></div>
                </div>
                
                <p className="text-sm text-gray-500">
                  {(usage.storage || 0).toFixed(1)} / {TIER_LIMITS[subscription.tier?.toLowerCase() as keyof typeof TIER_LIMITS].storage} {t('subscription.mbUsed')}
                </p>
              </>
            )}
          </div>
          
          {/* Export */}
          <div className="p-4 border border-gray-200 rounded-lg">
            <div className="flex justify-between items-start mb-2">
              <h3 className="text-sm font-medium text-gray-700">{t('subscription.export')}</h3>
              {subscription?.tier === SubscriptionTier.FREE ? (
                <span className="px-2 py-1 bg-yellow-50 text-yellow-800 text-xs font-medium rounded flex items-center">
                  <ZapOff className="h-3 w-3 me-1" />
                  {t('subscription.basic')}
                </span>
              ) : (
                <span className="px-2 py-1 bg-green-50 text-green-800 text-xs font-medium rounded flex items-center">
                  <CheckCircle className="h-3 w-3 me-1" />
                  {t('subscription.advanced')}
                </span>
              )}
            </div>
            
            <p className="text-sm text-gray-500">
              {subscription?.tier === SubscriptionTier.FREE 
                ? t('subscription.basicExportDescription')
                : t('subscription.advancedExportDescription')}
            </p>
          </div>
        </div>
        
        {subscription?.tier === SubscriptionTier.FREE && (
          <div className="mt-6 p-4 bg-primary-50 rounded-lg border border-primary-100">
            <div className="flex items-start">
              <Zap className="h-5 w-5 text-primary-500 mt-0.5 me-3 flex-shrink-0" />
              <div>
                <h3 className="text-sm font-medium text-primary-800 mb-1">
                  {t('subscription.unlockPremiumFeatures')}
                </h3>
                <p className="text-sm text-primary-700 mb-3">
                  {t('subscription.upgradeDescription')}
                </p>
                <button
                  className="px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 flex items-center text-sm"
                  onClick={handleUpgrade}
                >
                  <Upload className="h-4 w-4 me-1.5" />
                  {t('subscription.viewPricingOptions')}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
      
      {/* Feature Comparison */}
      <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-100">
        <h2 className="text-lg font-medium text-gray-900 mb-6 flex items-center">
          <Download className="h-5 w-5 me-2 text-primary-500" />
          {t('subscription.featureComparison')}
        </h2>
        
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="text-xs text-gray-700 uppercase bg-gray-50">
              <tr>
                <th className="px-4 py-3">{t('subscription.feature')}</th>
                <th className="px-4 py-3">{t('subscription.free')}</th>
                <th className="px-4 py-3">{t('subscription.premium')}</th>
                <th className="px-4 py-3">{t('subscription.enterprise')}</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b">
                <td className="px-4 py-3 font-medium text-gray-900">{t('subscription.projects')}</td>
                <td className="px-4 py-3">{TIER_LIMITS.free.projects}</td>
                <td className="px-4 py-3 text-green-700 font-medium">
                  <span className="flex items-center">
                    <Check className="h-4 w-4 me-1" />
                    {t('subscription.unlimited')}
                  </span>
                </td>
                <td className="px-4 py-3 text-green-700 font-medium">
                  <span className="flex items-center">
                    <Check className="h-4 w-4 me-1" />
                    {t('subscription.unlimited')}
                  </span>
                </td>
              </tr>
              <tr className="border-b">
                <td className="px-4 py-3 font-medium text-gray-900">{t('subscription.aiAnalysis')}</td>
                <td className="px-4 py-3">{TIER_LIMITS.free.aiAnalysis} {t('subscription.perMonth')}</td>
                <td className="px-4 py-3">{TIER_LIMITS.premium.aiAnalysis} {t('subscription.perMonth')}</td>
                <td className="px-4 py-3 text-green-700 font-medium">
                  <span className="flex items-center">
                    <Check className="h-4 w-4 me-1" />
                    {t('subscription.unlimited')}
                  </span>
                </td>
              </tr>
              <tr className="border-b">
                <td className="px-4 py-3 font-medium text-gray-900">{t('subscription.storage')}</td>
                <td className="px-4 py-3">{TIER_LIMITS.free.storage} MB</td>
                <td className="px-4 py-3">{TIER_LIMITS.premium.storage} MB</td>
                <td className="px-4 py-3">{TIER_LIMITS.enterprise.storage} GB</td>
              </tr>
              <tr className="border-b">
                <td className="px-4 py-3 font-medium text-gray-900">{t('subscription.export')}</td>
                <td className="px-4 py-3">{t('subscription.basic')}</td>
                <td className="px-4 py-3 text-green-700 font-medium">
                  <span className="flex items-center">
                    <Check className="h-4 w-4 me-1" />
                    {t('subscription.advanced')}
                  </span>
                </td>
                <td className="px-4 py-3 text-green-700 font-medium">
                  <span className="flex items-center">
                    <Check className="h-4 w-4 me-1" />
                    {t('subscription.advanced')}
                  </span>
                </td>
              </tr>
              <tr className="border-b">
                <td className="px-4 py-3 font-medium text-gray-900">{t('subscription.prioritySupport')}</td>
                <td className="px-4 py-3">-</td>
                <td className="px-4 py-3 text-green-700 font-medium">
                  <span className="flex items-center">
                    <Check className="h-4 w-4 me-1" />
                  </span>
                </td>
                <td className="px-4 py-3 text-green-700 font-medium">
                  <span className="flex items-center">
                    <Check className="h-4 w-4 me-1" />
                  </span>
                </td>
              </tr>
              <tr className="border-b">
                <td className="px-4 py-3 font-medium text-gray-900">{t('subscription.teamMembers')}</td>
                <td className="px-4 py-3">1</td>
                <td className="px-4 py-3">5</td>
                <td className="px-4 py-3">{t('subscription.unlimited')}</td>
              </tr>
              <tr className="border-b">
                <td className="px-4 py-3 font-medium text-gray-900">{t('subscription.features.basic_pmo_templates', 'Basic PMO Templates')}</td>
                <td className="px-4 py-3 text-green-700 font-medium">
                  <span className="flex items-center">
                    <Check className="h-4 w-4 me-1" />
                  </span>
                </td>
                <td className="px-4 py-3 text-green-700 font-medium">
                  <span className="flex items-center">
                    <Check className="h-4 w-4 me-1" />
                  </span>
                </td>
                <td className="px-4 py-3 text-green-700 font-medium">
                  <span className="flex items-center">
                    <Check className="h-4 w-4 me-1" />
                  </span>
                </td>
              </tr>
              <tr className="border-b">
                <td className="px-4 py-3 font-medium text-gray-900">{t('subscription.features.advanced_pmo_templates', 'Advanced PMO Templates')}</td>
                <td className="px-4 py-3">-</td>
                <td className="px-4 py-3 text-green-700 font-medium">
                  <span className="flex items-center">
                    <Check className="h-4 w-4 me-1" />
                  </span>
                </td>
                <td className="px-4 py-3 text-green-700 font-medium">
                  <span className="flex items-center">
                    <Check className="h-4 w-4 me-1" />
                  </span>
                </td>
              </tr>
              <tr className="border-b">
                <td className="px-4 py-3 font-medium text-gray-900">{t('subscription.features.team_collaboration', 'Team Collaboration')}</td>
                <td className="px-4 py-3">-</td>
                <td className="px-4 py-3 text-green-700 font-medium">
                  <span className="flex items-center">
                    <Check className="h-4 w-4 me-1" />
                  </span>
                </td>
                <td className="px-4 py-3 text-green-700 font-medium">
                  <span className="flex items-center">
                    <Check className="h-4 w-4 me-1" />
                  </span>
                </td>
              </tr>
              <tr className="border-b">
                <td className="px-4 py-3 font-medium text-gray-900">{t('subscription.features.document_processing', 'Document Processing')}</td>
                <td className="px-4 py-3">-</td>
                <td className="px-4 py-3 text-green-700 font-medium">
                  <span className="flex items-center">
                    <Check className="h-4 w-4 me-1" />
                  </span>
                </td>
                <td className="px-4 py-3 text-green-700 font-medium">
                  <span className="flex items-center">
                    <Check className="h-4 w-4 me-1" />
                  </span>
                </td>
              </tr>
              <tr className="border-b">
                <td className="px-4 py-3 font-medium text-gray-900">{t('subscription.features.api_access', 'API Access')}</td>
                <td className="px-4 py-3">-</td>
                <td className="px-4 py-3 text-green-700 font-medium">
                  <span className="flex items-center">
                    <Check className="h-4 w-4 me-1" />
                  </span>
                </td>
                <td className="px-4 py-3 text-green-700 font-medium">
                  <span className="flex items-center">
                    <Check className="h-4 w-4 me-1" />
                  </span>
                </td>
              </tr>
              <tr className="border-b">
                <td className="px-4 py-3 font-medium text-gray-900">{t('subscription.features.white-labeling', 'White Labeling')}</td>
                <td className="px-4 py-3">-</td>
                <td className="px-4 py-3">-</td>
                <td className="px-4 py-3 text-green-700 font-medium">
                  <span className="flex items-center">
                    <Check className="h-4 w-4 me-1" />
                  </span>
                </td>
              </tr>
              <tr className="border-b">
                <td className="px-4 py-3 font-medium text-gray-900">{t('subscription.features.dedicated_support', 'Dedicated Support')}</td>
                <td className="px-4 py-3">-</td>
                <td className="px-4 py-3">-</td>
                <td className="px-4 py-3 text-green-700 font-medium">
                  <span className="flex items-center">
                    <Check className="h-4 w-4 me-1" />
                  </span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        
        {subscription?.tier === SubscriptionTier.FREE && (
          <div className="mt-6">
            <button
              className="w-full py-2.5 bg-primary-600 text-white rounded-md hover:bg-primary-700 flex items-center justify-center"
              onClick={handleUpgrade}
            >
              <Zap className="h-4 w-4 me-1.5" />
              {t('subscription.upgradeToPremium')}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default SubscriptionPage;