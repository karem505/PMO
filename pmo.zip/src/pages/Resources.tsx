import React, { useEffect, useState } from 'react';
import { Document, documentsService } from '../services/documentsService';
import { FileIcon, Download } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { formatFileSize } from '../utils/formatters';

const Resources: React.FC = () => {
  const [documents, setDocuments] = useState<Document[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { t } = useLanguage();

  useEffect(() => {
    loadDocuments();
  }, []);

  const loadDocuments = async () => {
    try {
      setLoading(true);
      const docs = await documentsService.listDocuments();
      setDocuments(docs);
      setError(null);
    } catch (err) {
      setError(t('resources.errorLoading'));
      console.error('Error loading documents:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = async (document: Document) => {
    try {
      const blob = await documentsService.downloadDocument(document.name);
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = document.name;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (err) {
      console.error('Error downloading document:', err);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-screen text-red-500">
        {error}
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">{t('resources.title', 'Project Assets')}</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {documents.map((doc) => (
          <div
            key={doc.name}
            className="bg-neutral-800 rounded-lg p-4 hover:bg-neutral-700 transition-colors duration-200 cursor-pointer"
            onClick={() => handleDownload(doc)}
          >
            <div className="flex items-center justify-between mb-4">
              <FileIcon className="h-8 w-8 text-primary-400" />
              <Download className="h-5 w-5 text-neutral-400 hover:text-white transition-colors duration-200" />
            </div>
            
            <h3 className="font-medium text-lg mb-2 truncate" title={doc.name}>
              {doc.name}
            </h3>
            
            <div className="text-sm text-neutral-400">
              <p className="mb-1">{formatFileSize(doc.size)}</p>
              <p className="truncate" title={new Date(doc.modified).toLocaleString()}>
                {new Date(doc.modified).toLocaleString()}
              </p>
              {doc.metadata.task_name && (
                <p className="truncate text-primary-400" title={doc.metadata.task_name}>
                  {doc.metadata.task_name}
                </p>
              )}
            </div>
          </div>
        ))}
      </div>
      
      {documents.length === 0 && (
        <div className="text-center text-neutral-400 mt-8">
          {t('resources.noDocuments')}
        </div>
      )}
    </div>
  );
};

export default Resources; 