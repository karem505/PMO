import React, { useState } from 'react';
import { UserPlus, Mail, Clock, Check, X, AlertTriangle, Search, Users, Send } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const InvitationsPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'received' | 'sent'>('received');
  const [searchTerm, setSearchTerm] = useState('');
  const { t, isRTL } = useLanguage();
  
  const receivedInvitations = [
    {
      id: 1,
      teamName: 'Enterprise PMO Council',
      invitedBy: 'Sarah Johnson',
      invitedByEmail: 'sarah.johnson@example.com',
      role: 'Member',
      sentAt: '2 days ago',
      status: 'pending'
    },
    {
      id: 2,
      teamName: 'Program Management Excellence',
      invitedBy: 'Michael Chen',
      invitedByEmail: 'michael.chen@example.com',
      role: 'Editor',
      sentAt: '1 week ago',
      status: 'pending'
    }
  ];
  
  const sentInvitations = [
    {
      id: 3,
      teamName: 'PMO Governance Team',
      invitedUser: 'James Wilson',
      invitedEmail: 'james.wilson@example.com',
      role: 'Viewer',
      sentAt: '1 day ago',
      status: 'pending'
    },
    {
      id: 4,
      teamName: 'PMO Governance Team',
      invitedUser: 'Emily Rodriguez',
      invitedEmail: 'emily.rodriguez@example.com',
      role: 'Member',
      sentAt: '3 days ago',
      status: 'accepted'
    },
    {
      id: 5,
      teamName: 'Portfolio Management Office',
      invitedUser: 'Daniel Kim',
      invitedEmail: 'daniel.kim@example.com',
      role: 'Admin',
      sentAt: '1 week ago',
      status: 'declined'
    }
  ];
  
  const filteredReceivedInvitations = receivedInvitations.filter(invitation => 
    invitation.teamName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    invitation.invitedBy.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  const filteredSentInvitations = sentInvitations.filter(invitation => 
    invitation.teamName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    invitation.invitedUser.toLowerCase().includes(searchTerm.toLowerCase()) ||
    invitation.invitedEmail.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-800">
            <Clock className={`h-3 w-3 ${isRTL ? 'ml-1' : 'mr-1'}`} />
            {t('invitations.pending', 'Pending')}
          </span>
        );
      case 'accepted':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-accent-100 text-accent-800">
            <Check className={`h-3 w-3 ${isRTL ? 'ml-1' : 'mr-1'}`} />
            {t('invitations.accepted', 'Accepted')}
          </span>
        );
      case 'declined':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-secondary-100 text-secondary-800">
            <X className={`h-3 w-3 ${isRTL ? 'ml-1' : 'mr-1'}`} />
            {t('invitations.declined', 'Declined')}
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-neutral-800 flex items-center">
            <UserPlus className={`${isRTL ? 'ml-2' : 'mr-2'} text-primary-500 h-6 w-6`} />
            {t('invitations.title', 'Team Invitations')}
          </h1>
          <p className="text-neutral-600 mt-1">
            {t('invitations.description', 'Manage invitations to collaborate on PMO teams')}
          </p>
        </div>
        <div className="mt-4 md:mt-0">
          <button className="px-4 py-2 bg-gradient-to-r from-primary-600 to-primary-700 text-white rounded-lg shadow-sm hover:shadow-md transition-all duration-200 flex items-center">
            <Send className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
            {t('invitations.sendNewInvitation', 'Send New Invitation')}
          </button>
        </div>
      </div>
      
      <div className="bg-white rounded-xl shadow-sm p-6 mb-6 border border-neutral-100">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
          <div className="mb-4 md:mb-0">
            <div className="flex border-b border-neutral-200">
              <button
                className={`py-2 px-4 font-medium text-sm border-b-2 ${
                  activeTab === 'received'
                    ? 'border-primary-500 text-primary-600'
                    : 'border-transparent text-neutral-500 hover:text-neutral-700'
                }`}
                onClick={() => setActiveTab('received')}
              >
                {t('invitations.receivedInvitations', 'Received Invitations')}
              </button>
              <button
                className={`py-2 px-4 font-medium text-sm border-b-2 ${
                  activeTab === 'sent'
                    ? 'border-primary-500 text-primary-600'
                    : 'border-transparent text-neutral-500 hover:text-neutral-700'
                }`}
                onClick={() => setActiveTab('sent')}
              >
                {t('invitations.sentInvitations', 'Sent Invitations')}
              </button>
            </div>
          </div>
          <div className="w-full md:w-64 relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-4 w-4 text-neutral-400" />
            </div>
            <input
              type="text"
              placeholder={t('invitations.search', 'Search invitations...')}
              className="pl-10 block w-full rounded-md border-neutral-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        
        {activeTab === 'received' ? (
          <div className="space-y-4">
            {filteredReceivedInvitations.length > 0 ? (
              filteredReceivedInvitations.map(invitation => (
                <div key={invitation.id} className="bg-neutral-50 p-4 rounded-lg border border-neutral-100 hover:border-primary-200 transition-colors duration-200">
                  <div className="flex flex-col md:flex-row md:items-center justify-between">
                    <div className="flex items-start">
                      <div className="p-2 bg-primary-100 rounded-lg mr-4">
                        <Users className="h-6 w-6 text-primary-600" />
                      </div>
                      <div>
                        <div className="flex items-center flex-wrap gap-2">
                          <h3 className="font-semibold text-neutral-800">{invitation.teamName}</h3>
                          {getStatusBadge(invitation.status)}
                        </div>
                        <p className="text-sm text-neutral-600 mt-1">
                          {t('invitations.youveBeenInvited', "You've been invited to join as")} <span className="font-medium">{invitation.role}</span>
                        </p>
                        <div className="flex items-center mt-2 text-xs text-neutral-500">
                          <span className="flex items-center">
                            <Mail className={`h-3.5 w-3.5 ${isRTL ? 'ml-1' : 'mr-1'}`} />
                            {t('invitations.invitedBy', 'Invited by')} {invitation.invitedBy}
                          </span>
                          <span className="mx-2">•</span>
                          <span>{t('invitations.sent', 'Sent')} {invitation.sentAt}</span>
                        </div>
                      </div>
                    </div>
                    <div className="mt-4 md:mt-0 flex items-center space-x-2">
                      <button className="px-3 py-1.5 bg-accent-600 text-white text-sm rounded-md hover:bg-accent-700 transition-colors flex items-center">
                        <Check className={`h-4 w-4 ${isRTL ? 'ml-1.5' : 'mr-1.5'}`} />
                        {t('invitations.accept', 'Accept')}
                      </button>
                      <button className="px-3 py-1.5 border border-neutral-200 text-neutral-700 text-sm rounded-md hover:bg-neutral-50 transition-colors flex items-center">
                        <X className={`h-4 w-4 ${isRTL ? 'ml-1.5' : 'mr-1.5'}`} />
                        {t('invitations.decline', 'Decline')}
                      </button>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="bg-neutral-50 p-8 rounded-lg border border-neutral-100 text-center">
                <div className="inline-flex items-center justify-center p-3 bg-amber-100 rounded-full mb-4">
                  <AlertTriangle className="h-6 w-6 text-amber-600" />
                </div>
                <h3 className="text-lg font-medium text-neutral-800 mb-1">
                  {t('invitations.noInvitations', 'No Invitations Found')}
                </h3>
                <p className="text-neutral-600">
                  {t('invitations.noInvitationsDescription', "You don't have any pending invitations at this time.")}
                </p>
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            {filteredSentInvitations.length > 0 ? (
              filteredSentInvitations.map(invitation => (
                <div key={invitation.id} className="bg-neutral-50 p-4 rounded-lg border border-neutral-100 hover:border-primary-200 transition-colors duration-200">
                  <div className="flex flex-col md:flex-row md:items-center justify-between">
                    <div className="flex items-start">
                      <div className="p-2 bg-primary-100 rounded-lg mr-4">
                        <Users className="h-6 w-6 text-primary-600" />
                      </div>
                      <div>
                        <div className="flex items-center flex-wrap gap-2">
                          <h3 className="font-semibold text-neutral-800">{invitation.teamName}</h3>
                          {getStatusBadge(invitation.status)}
                        </div>
                        <p className="text-sm text-neutral-600 mt-1">
                          {t('invitations.invitedSent', 'Invitation sent to')} <span className="font-medium">{invitation.invitedUser}</span>
                        </p>
                        <div className="flex items-center mt-2 text-xs text-neutral-500">
                          <span className="flex items-center">
                            <Mail className={`h-3.5 w-3.5 ${isRTL ? 'ml-1' : 'mr-1'}`} />
                            {invitation.invitedEmail}
                          </span>
                          <span className="mx-2">•</span>
                          <span>{t('invitations.sent', 'Sent')} {invitation.sentAt}</span>
                        </div>
                      </div>
                    </div>
                    <div className="mt-4 md:mt-0">
                      <button className="px-3 py-1.5 border border-neutral-200 text-neutral-700 text-sm rounded-md hover:bg-neutral-50 transition-colors">
                        {t('invitations.resend', 'Resend')}
                      </button>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="bg-neutral-50 p-8 rounded-lg border border-neutral-100 text-center">
                <div className="inline-flex items-center justify-center p-3 bg-amber-100 rounded-full mb-4">
                  <AlertTriangle className="h-6 w-6 text-amber-600" />
                </div>
                <h3 className="text-lg font-medium text-neutral-800 mb-1">
                  {t('invitations.noSentInvitations', 'No Sent Invitations')}
                </h3>
                <p className="text-neutral-600">
                  {t('invitations.noSentInvitationsDescription', "You haven't sent any invitations yet.")}
                </p>
              </div>
            )}
          </div>
        )}
      </div>
      
      <div className="bg-white rounded-xl shadow-sm p-6 border border-neutral-100">
        <div className="flex flex-col md:flex-row items-start">
          <div className="p-3 bg-amber-100 rounded-lg mr-4 flex-shrink-0">
            <AlertTriangle className="h-6 w-6 text-amber-600" />
          </div>
          <div>
            <h3 className="font-semibold text-neutral-800">About Team Invitations</h3>
            <p className="text-sm text-neutral-600 mt-1">
              Team invitations allow you to collaborate with colleagues on PMO Builder. When you accept an invitation, you'll gain access to the team's shared domains, templates, and resources based on your assigned role permissions.
            </p>
            <p className="text-sm text-neutral-600 mt-2">
              <span className="font-medium">Member</span>: Can view and edit shared content<br />
              <span className="font-medium">Admin</span>: Can manage team members and all content<br />
              <span className="font-medium">Viewer</span>: Can only view shared content
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InvitationsPage;