import React, { useState } from 'react';
import { useNavigate, Routes, Route, Link, useLocation } from 'react-router-dom';
import { useAppStore } from '../store';
import { Building, Save, Trash2, Upload, Cloud, Database, Shield, UserCog, Bell, CreditCard } from 'lucide-react';
import SubscriptionPage from './SubscriptionPage';
import { useLanguage } from '../contexts/LanguageContext';
const SettingsPage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { userData, updateUserProfile } = useAppStore();
  const { t } = useLanguage();
  // Default content - Personal Settings
  const PersonalSettings = () => {
    const [formData, setFormData] = useState({
      organizationName: userData.organizationName || '',
      industry: userData.industry || '',
      pmoMaturityLevel: userData.pmoMaturityLevel || 'Initial'
    });
    
    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
      const { name, value } = e.target;
      setFormData(prev => ({ ...prev, [name]: value }));
    };
    
    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      updateUserProfile(formData);
      navigate('/dashboard');
    };
    
    return (
      <div>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-neutral-800 dark:text-neutral-200">{t('settings.personal')}</h2>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6">
          <form onSubmit={handleSubmit}>
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {t('settings.organizationName')}
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 start-0 ps-3 flex items-center pointer-events-none">
                    <Building className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    name="organizationName"
                    value={formData.organizationName}
                    onChange={handleChange}
                    className="ps-10 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-neutral-800 px-3 py-2 sm:text-sm"
                    placeholder={t('settings.organizationNamePlaceholder')}
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {t('settings.industry')}
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 start-0 ps-3 flex items-center pointer-events-none">
                    <Building className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    name="industry"
                    value={formData.industry}
                    onChange={handleChange}
                    className="ps-10 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-neutral-800 px-3 py-2 sm:text-sm"
                    placeholder={t('settings.industryPlaceholder')}
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {t('settings.pmoMaturityLevel')}
                </label>
                <select
                  name="pmoMaturityLevel"
                  value={formData.pmoMaturityLevel}
                  onChange={handleChange}
                  className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-neutral-800 px-3 py-2 sm:text-sm"
                >
                  <option value="Initial">{t('settings.initial')}</option>
                  <option value="Defined">{t('settings.defined')}</option>
                  <option value="Managed">{t('settings.managed')}</option>
                  <option value="Optimized">{t('settings.optimized')}</option>
                  <option value="Not Established">{t('settings.notEstablished')}</option>
                </select>
                <p className="mt-1 text-sm text-gray-500">
                  {t('settings.selectTheMaturityLevelThatBestDescribesYourCurrentPMO')}
                </p>
              </div>
              
              <div className="pt-4 border-t border-gray-200 flex justify-end">
                <button
                  type="button"
                  className="me-3 px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
                  onClick={() => navigate('/')}
                >
                  {t('settings.cancel')}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center"
                >
                  <Save className="h-4 w-4 me-1" />
                  {t('settings.saveProfile')}
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    );
  };

  // Navigation tabs
  const tabs = [
    { name: t('settings.personal'), href: '/dashboard/settings', icon: UserCog },
    { name: t('settings.subscription'), href: '/dashboard/settings/subscription', icon: CreditCard },
    { name: t('settings.notifications'), href: '/dashboard/notifications', icon: Bell },
    { name: t('settings.security'), href: '/dashboard/security', icon: Shield },
    { name: t('settings.data'), href: '/dashboard/data', icon: Database },
  ];
  
  // Check which tab is active
  const getIsActive = (path: string) => location.pathname === path;
  
  return (
    <div className="max-w-6xl mx-auto">
      <div className="mb-8">
        <h1 className="text-2xl font-bold  text-neutral-800 dark:text-neutral-200">{t('settings.title')}</h1>
        <p className="text-neutral-600 dark:text-neutral-300 mt-1">
          {t('settings.description')}
        </p>
      </div>
      
      <div className="flex flex-col md:flex-row gap-6">
        {/* Sidebar */}
        <div className="md:w-64 flex-shrink-0">
          <nav className="bg-white rounded-lg shadow-sm p-4 space-y-1">
            {tabs.map((tab) => {
              const isActive = getIsActive(tab.href);
              const Icon = tab.icon;
              
              return (
                <Link
                  key={tab.name}
                  to={tab.href}
                  className={`flex items-center px-3 py-2 text-sm font-medium rounded-md ${
                    isActive 
                      ? 'bg-blue-50 text-blue-700' 
                      : 'text-gray-700 hover:bg-gray-50 hover:text-gray-900'
                  }`}
                >
                  <Icon className={`me-3 h-5 w-5 ${isActive ? 'text-blue-500' : 'text-gray-400'}`} />
                  {tab.name}
                </Link>
              );
            })}
          </nav>
        </div>
        
        {/* Main content area */}
        <div className="flex-1">
          <Routes>
            <Route path="/" element={<PersonalSettings />} />
            <Route path="/dashboard/settings/subscription" element={<SubscriptionPage />} />
            <Route path="/dashboard/notifications" element={<ComingSoonSection title="Notification Settings" />} />
            <Route path="/dashboard/security" element={<ComingSoonSection title="Security Settings" />} />
            <Route path="/dashboard/data" element={<ComingSoonSection title="Data Management" />} />
          </Routes>
        </div>
      </div>
    </div>
  );
};

const ComingSoonSection: React.FC<{title: string}> = ({ title }) => (
  <div>
    <div className="flex items-center justify-between mb-6">
      <h2 className="text-xl font-bold text-gray-800">{title}</h2>
    </div>
    
    <div className="bg-white rounded-lg shadow-sm p-6 text-center">
      <Cloud className="h-12 w-12 text-blue-400 mx-auto mb-4" />
      <h3 className="text-lg font-medium text-gray-700 mb-2">Coming Soon</h3>
      <p className="text-gray-600 max-w-md mx-auto">
        We're working on this feature and it will be available in a future update. Check back soon!
      </p>
    </div>
  </div>
);

export default SettingsPage;