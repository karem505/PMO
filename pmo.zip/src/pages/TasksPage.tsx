import React, { useState, useEffect, useRef, useCallback, useMemo, useLayoutEffect } from 'react';
import { CheckSquare, Filter, Search, CheckCircle, Clock, Tag, Calendar, Plus, ChevronDown, X, MoreHorizontal, Paperclip } from 'lucide-react';
import { tasks, domains } from '../data';
import { useAppStore } from '../store';
import MemoizedTaskCard from '../components/MemoizedTaskCard';
import MemoizedTaskManager from '../components/MemoizedTaskManager';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { useToast } from '../hooks/useToast';
import { useNavigationGuard } from '../hooks/useNavigationGuard';
import { ErrorBoundary } from 'react-error-boundary';

// Analytics interface
interface Analytics {
  trackPerformance: (eventType: string, data: Record<string, any>) => void;
}

// Memory leak detection hook for development
const useMemoryLeakDetector = (componentName: string) => {
  useEffect(() => {
    // Only run in development mode
    if (process.env.NODE_ENV !== 'development') return;
    
    // Create a unique identifier for this component instance
    const instanceId = Math.random().toString(36).substring(2, 9);
    
    // Store reference to the component instance
    if (!window.__MEMORY_LEAK_DETECTOR__) {
      window.__MEMORY_LEAK_DETECTOR__ = {};
    }
    
    window.__MEMORY_LEAK_DETECTOR__[`${componentName}_${instanceId}`] = {
      mountTime: new Date().toISOString(),
      componentName
    };
    
    console.log(`[MemoryDetector] ${componentName} mounted (${instanceId})`);
    console.log(`[MemoryDetector] Active instances: ${Object.keys(window.__MEMORY_LEAK_DETECTOR__).length}`);
    
    return () => {
      // Clean up on unmount
      if (window.__MEMORY_LEAK_DETECTOR__ && window.__MEMORY_LEAK_DETECTOR__[`${componentName}_${instanceId}`]) {
        delete window.__MEMORY_LEAK_DETECTOR__[`${componentName}_${instanceId}`];
        console.log(`[MemoryDetector] ${componentName} unmounted (${instanceId})`);
        console.log(`[MemoryDetector] Active instances: ${Object.keys(window.__MEMORY_LEAK_DETECTOR__).length}`);
      }
    };
  }, []);
};

// Extend Window interface for memory leak detector
declare global {
  interface Window {
    __MEMORY_LEAK_DETECTOR__?: Record<string, {
      mountTime: string;
      componentName: string;
    }>;
    analytics?: Analytics;
  }
}

// Performance monitoring hook with enhanced metrics
const useRenderPerformance = (componentName: string) => {
  const renderStartTime = useRef<number>(0);
  const renderCount = useRef<number>(0);
  const totalRenderTime = useRef<number>(0);
  
  useLayoutEffect(() => {
    renderStartTime.current = performance.now();
    renderCount.current += 1;
    
    return () => {
      const renderTime = performance.now() - renderStartTime.current;
      totalRenderTime.current += renderTime;
      
      // Log slow renders (over 50ms)
      if (renderTime > 50) {
        console.warn(`[Performance] ${componentName} took ${renderTime.toFixed(2)}ms to render (render #${renderCount.current})`);
        
        // Send to analytics if available
        if (window.analytics?.trackPerformance) {
          window.analytics.trackPerformance('render', {
            component: componentName,
            duration: renderTime,
            renderCount: renderCount.current,
            averageRenderTime: totalRenderTime.current / renderCount.current,
            timestamp: new Date().toISOString()
          });
        }
      }
    };
  });
  
  // Return function to manually track performance events
  return {
    trackEvent: (eventName: string, data: Record<string, any> = {}) => {
      if (window.analytics?.trackPerformance) {
        window.analytics.trackPerformance('custom', {
          component: componentName,
          event: eventName,
          ...data,
          timestamp: new Date().toISOString()
        });
      }
    }
  };
};

// Check for contentVisibility support
const supportsContentVisibility = (() => {
  if (typeof document === 'undefined') return false;
  return CSS.supports?.('content-visibility', 'auto') || false;
})();

// Define types for task and domain data
interface Task {
  id: string;
  title: string;
  description: string;
  domainId: number;
  stage: string;
}

// Define type for task data in active project
interface TaskData {
  completed?: boolean;
  attachments?: any[];
}

// Custom hook for debounced value
function useDebounce<T>(value: T, delay: number): T {
  const [debouncedValue, setDebouncedValue] = useState<T>(value);

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);

    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);

  return debouncedValue;
}

const TasksPage: React.FC = () => {
  // Monitor rendering performance
  const { trackEvent: trackRenderEvent } = useRenderPerformance('TasksPage');
  
  // Monitor for memory leaks in development
  useMemoryLeakDetector('TasksPage');
  
  const navigate = useNavigate();
  const navigationGuard = useNavigationGuard();
  const { getDomainProgress, getActiveProject, updateTaskData, syncWithSupabase } = useAppStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDomain, setSelectedDomain] = useState<number | null>(null);
  const [selectedStage, setSelectedStage] = useState<string | null>(null);
  const [selectedStatus, setSelectedStatus] = useState<'all' | 'completed' | 'incomplete'>('all');
  const [showFilters, setShowFilters] = useState(false);
  const [selectedTask, setSelectedTask] = useState<string | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [sortConfig, setSortConfig] = useState({ field: 'title', direction: 'asc' as 'asc' | 'desc' });
  const { t, isRTL } = useLanguage();
  const toast = useToast();
  
  // Debounce search term to prevent excessive filtering
  const debouncedSearchTerm = useDebounce(searchTerm, 300);

  // Simplified mount tracking with a single ref
  const isMountedRef = useRef(true);
  const [isLoading, setIsLoading] = useState(true);
  const [isActionLoading, setIsActionLoading] = useState(false);
  const syncInProgressRef = useRef(false);
  const [loadError, setLoadError] = useState<string | null>(null);

  // Get active project data - memoized to prevent unnecessary recalculations
  const activeProject = useMemo(() => getActiveProject(), [getActiveProject, refreshKey]);

  // Filter tasks based on search term, domain, stage, and status - memoized
  const filteredTasks = useMemo(() => {
    return tasks.filter((task: Task) => {
      const matchesDomain = selectedDomain === null || task.domainId === selectedDomain;
      const matchesStage = selectedStage === null || task.stage === selectedStage;
      const matchesSearch = debouncedSearchTerm === '' || 
        task.title.toLowerCase().includes(debouncedSearchTerm.toLowerCase()) ||
        task.description.toLowerCase().includes(debouncedSearchTerm.toLowerCase());
      
      // Get completion status
      const isCompleted = activeProject?.domainData?.tasks?.[task.id]?.completed || false;
      const matchesStatus = selectedStatus === 'all' || 
        (selectedStatus === 'completed' && isCompleted) ||
        (selectedStatus === 'incomplete' && !isCompleted);
      
      return matchesDomain && matchesStage && matchesSearch && matchesStatus;
    });
  }, [tasks, selectedDomain, selectedStage, debouncedSearchTerm, selectedStatus, activeProject]);
  
  // Group tasks by domain - memoized
  const tasksByDomain = useMemo(() => {
    return filteredTasks.reduce<Record<number, Task[]>>((acc, task) => {
      if (!acc[task.domainId]) {
        acc[task.domainId] = [];
      }
      acc[task.domainId].push(task);
      return acc;
    }, {});
  }, [filteredTasks]);
  
  // Calculate task stats - memoized
  const { totalTasks, completedTasks, completionRate } = useMemo(() => {
    const total = tasks.length;
    const completed = Object.values(activeProject?.domainData?.tasks || {})
      .filter((task: unknown) => (task as TaskData).completed).length;
    const rate = Math.round((completed / total) * 100);
    
    return { totalTasks: total, completedTasks: completed, completionRate: rate };
  }, [tasks, activeProject]);
  
  // Retry loading function
  const handleRetryLoad = useCallback(() => {
    setLoadError(null);
    setRefreshKey(prev => prev + 1);
  }, []);

  // Set up component mount tracking
  useEffect(() => {
    isMountedRef.current = true;
    
    // Add a small delay to ensure the component is fully rendered
    const timer = setTimeout(() => {
      if (isMountedRef.current) {
        setIsLoading(false);
      }
    }, 300);
    
    return () => {
      isMountedRef.current = false;
      clearTimeout(timer);
    };
  }, []);

  // Sync with Supabase on initial load and if refreshKey changes
  useEffect(() => {
    if (!isMountedRef.current || syncInProgressRef.current) return;
    
    const syncData = async () => {
      try {
        syncInProgressRef.current = true;
        setIsLoading(true);
        setLoadError(null);
        
        // Track sync start
        trackRenderEvent('sync_start', { refreshKey });
        const syncStartTime = performance.now();
        
        await syncWithSupabase();
        
        // Track sync completion and duration
        const syncDuration = performance.now() - syncStartTime;
        trackRenderEvent('sync_complete', { 
          refreshKey,
          duration: syncDuration,
          success: true
        });
        
        console.log('Task data synchronized');
      } catch (error) {
        console.error('Error syncing with Supabase:', error);
        setLoadError(t('tasks.errors.syncFailed', 'Failed to load task data. Please try again.'));
        toast.error('Failed to synchronize task data');
        
        // Track sync error
        trackRenderEvent('sync_error', { 
          refreshKey,
          error: String(error)
        });
      } finally {
        if (isMountedRef.current) {
          setIsLoading(false);
          // Add a small delay before allowing another sync
          setTimeout(() => {
            syncInProgressRef.current = false;
          }, 1000);
        }
      }
    };
    
    syncData();
  }, [refreshKey, syncWithSupabase, toast, t, trackRenderEvent]);
  
  // Track task filtering performance
  useEffect(() => {
    if (debouncedSearchTerm !== '' || selectedDomain !== null || selectedStage !== null || selectedStatus !== 'all') {
      const filterStartTime = performance.now();
      
      // This will run after the filteredTasks memoized value is recalculated
      setTimeout(() => {
        const filterDuration = performance.now() - filterStartTime;
        trackRenderEvent('filter_applied', {
          searchTerm: debouncedSearchTerm,
          domain: selectedDomain,
          stage: selectedStage,
          status: selectedStatus,
          resultCount: filteredTasks.length,
          duration: filterDuration
        });
      }, 0);
    }
  }, [debouncedSearchTerm, selectedDomain, selectedStage, selectedStatus, filteredTasks.length, trackRenderEvent]);
  
  // Track user interaction for analytics
  const trackUserInteraction = useCallback((action: string, details?: Record<string, any>) => {
    // Log to console in development
    if (process.env.NODE_ENV === 'development') {
      console.log(`[Analytics] ${action}`, details);
    }
    
    // Send to analytics if available
    if (window.analytics?.trackPerformance) {
      window.analytics.trackPerformance('user_interaction', {
        action,
        ...(details || {})
      });
    }
  }, []);

  // Safe filter clearing function - memoized
  const clearFilters = useCallback(() => {
    if (!isMountedRef.current) {
      console.warn('Filter clearing attempted when component is unmounted');
      return;
    }
    
    trackUserInteraction('clear_filters', {
      previousFilters: {
        domain: selectedDomain,
        stage: selectedStage,
        status: selectedStatus,
        search: searchTerm
      }
    });
    
    setSelectedDomain(null);
    setSelectedStage(null);
    setSelectedStatus('all');
    setSearchTerm('');
    toast.info('Filters cleared');
  }, [toast, selectedDomain, selectedStage, selectedStatus, searchTerm, trackUserInteraction]);
  
  // Safe task selection function - memoized
  const handleTaskClick = useCallback((taskId: string) => {
    if (!isMountedRef.current || isActionLoading) {
      console.warn('Task selection attempted when component is unmounted or action in progress');
      return;
    }
    
    try {
      // Find the task to ensure it exists before setting it as selected
      const taskExists = tasks.some((task: Task) => task.id === taskId);
      
      if (!taskExists) {
        console.error(`Task with ID ${taskId} not found`);
        toast.error(t('tasks.errors.taskNotFound', 'Task not found'));
        trackUserInteraction('task_not_found', { taskId });
        return;
      }
      
      // Track task selection
      trackUserInteraction('select_task', { taskId });
    
    // Instead of navigating away, show the task in the current page
    setSelectedTask(taskId);
    } catch (error) {
      console.error('Error selecting task:', error);
      toast.error(t('tasks.errors.failedToSelectTask', 'Failed to select task'));
      trackUserInteraction('task_selection_error', { taskId, error: String(error) });
    }
  }, [isActionLoading, tasks, toast, t, trackUserInteraction]);
  
  // Safe task update function - memoized
  const handleTaskUpdate = useCallback(async () => {
    if (!isMountedRef.current) {
      console.warn('Task update attempted when component is unmounted');
      return;
    }
    
    try {
      setIsActionLoading(true);
      // Track task update start
      trackUserInteraction('task_update_start', { taskId: selectedTask });
      
      // Simulate a network delay for updating task data
      await new Promise(resolve => setTimeout(resolve, 300));
    
    // Refresh the task list
    setRefreshKey(prev => prev + 1);
    // Close the task detail
    setSelectedTask(null);
    toast.success('Task updated successfully');
      
      // Track task update success
      trackUserInteraction('task_update_success', { taskId: selectedTask });
    } catch (error) {
      console.error('Error updating task:', error);
      toast.error('Failed to update task');
      
      // Track task update error
      trackUserInteraction('task_update_error', { 
        taskId: selectedTask,
        error: String(error)
      });
    } finally {
      if (isMountedRef.current) {
        setIsActionLoading(false);
      }
    }
  }, [toast, selectedTask, trackUserInteraction]);

  // Get file count for a task
  const getTaskAttachmentsCount = useCallback((taskId: string): number => {
    const taskData = activeProject?.domainData?.tasks?.[taskId] as TaskData | undefined;
    if (!taskData?.attachments) return 0;
    return taskData.attachments.length;
  }, [activeProject]);
  
  // Safe navigation function - memoized
  const handleNavigateToResources = useCallback(() => {
    if (!isMountedRef.current || isActionLoading) {
      console.warn('Navigation attempted when component is unmounted or action in progress');
      return;
    }
    
    try {
      setIsActionLoading(true);
      // Track navigation attempt
      trackUserInteraction('navigate_to_resources');
      
      navigationGuard.navigate('/resources');
    } catch (error) {
      console.error('Navigation error:', error);
      // Track navigation error
      trackUserInteraction('navigation_error', { 
        destination: '/resources',
        error: String(error)
      });
      
      // Fallback navigation
      navigate('/resources');
    } finally {
      // No need to reset action loading as we're navigating away
    }
  }, [navigationGuard, navigate, isActionLoading, trackUserInteraction]);
  
  // Task loading overlay with accessibility improvements
  const LoadingOverlay = useCallback(() => {
    // Use a ref to announce loading state to screen readers after a delay
    const loadingRef = useRef<HTMLDivElement>(null);
    
    useEffect(() => {
      // Ensure the loading message is announced to screen readers
      const timer = setTimeout(() => {
        if (loadingRef.current) {
          loadingRef.current.setAttribute('aria-live', 'assertive');
        }
      }, 100);
      
      return () => clearTimeout(timer);
    }, []);
    
    return (
      <div 
        className="fixed inset-0 bg-black bg-opacity-20 flex items-center justify-center z-50"
        role="alert"
        aria-busy="true"
        aria-label={t('common.loading', 'Loading...')}
      >
        <div className="bg-white p-4 rounded-lg shadow-lg flex items-center space-x-3">
          <div className="animate-spin rounded-full h-5 w-5 border-t-2 border-b-2 border-primary-500"></div>
          <p ref={loadingRef}>{t('common.loading', 'Loading...')}</p>
        </div>
      </div>
    );
  }, [t]);

  // Memoize task click handlers for all tasks to prevent recreating them on each render
  const taskClickHandlers = useMemo(() => {
    const handlers: Record<string, () => void> = {};
    
    // Only create handlers for filtered tasks that are actually displayed
    // This prevents memory bloat when there are many tasks but only a few are shown
    filteredTasks.forEach((task: Task) => {
      handlers[task.id] = () => handleTaskClick(task.id);
    });
    
    return handlers;
  }, [filteredTasks, handleTaskClick]);

  // Network status monitoring
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  
  // Dynamic chunk sizing based on device capabilities
  const [chunkSize, setChunkSize] = useState(10);
  const [devicePerformance, setDevicePerformance] = useState<'low'|'medium'|'high'>('medium');
  
  // Determine if we should use virtualization based on task count
  const shouldUseVirtualization = useCallback((taskCount: number) => {
    return taskCount > 50 && devicePerformance !== 'high';
  }, [devicePerformance]);
  
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Show offline warning if needed
  const OfflineBanner = useCallback(() => {
    if (isOnline) return null;
    
    return (
      <div className="bg-amber-50 border-l-4 border-amber-400 p-4 mb-6" role="alert">
        <div className="flex items-center">
          <div className="flex-shrink-0">
            <svg className="h-5 w-5 text-amber-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
            </svg>
          </div>
          <div className="ml-3">
            <p className="text-sm text-amber-700">
              {t('common.offlineWarning', "You're currently offline. Some features may be limited.")}
            </p>
          </div>
        </div>
      </div>
    );
  }, [isOnline, t]);

  // Focus management for task list
  const taskListRef = useRef<HTMLDivElement>(null);
  
  // When filtered tasks change, ensure focus is managed properly
  useEffect(() => {
    // If tasks were filtered and the list is now empty, move focus to the filter section
    if (filteredTasks.length === 0 && taskListRef.current) {
      const filterButton = document.querySelector('[aria-controls="task-filters"]');
      if (filterButton && document.activeElement !== filterButton) {
        (filterButton as HTMLElement).focus();
      }
    }
  }, [filteredTasks]);

  // Define task data prefetching function before it's used
  const prefetchTaskData = useCallback((taskId: string) => {
    // Skip prefetching if component is unmounted or an action is in progress
    if (!isMountedRef.current || isActionLoading) return;
    
    // Skip if already selected
    if (selectedTask === taskId) return;
    
    try {
      // Find the task to ensure it exists
      const task = tasks.find((t: Task) => t.id === taskId);
      if (!task) return;
      
      // Track prefetch attempt
      trackRenderEvent('task_prefetch', { taskId, taskTitle: task.title });
      
      // Simulate data prefetching (in a real app, this would fetch additional task details)
      // This could be an API call to get detailed task information
      setTimeout(() => {
        if (isMountedRef.current) {
          // Cache the task data in memory or context/store
          // For this example, we're just tracking the event
          trackRenderEvent('task_prefetch_complete', { 
            taskId,
            taskTitle: task.title,
            success: true
          });
        }
      }, 200);
    } catch (error) {
      console.error('Error prefetching task data:', error);
      trackRenderEvent('task_prefetch_error', { 
        taskId,
        error: String(error)
      });
    }
  }, [isActionLoading, selectedTask, tasks, trackRenderEvent]);

  // Safe task selection with validation - moved higher in the file
  const getSelectedTask = useCallback((taskId: string | null): Task | null => {
    if (!taskId) return null;
    return tasks.find(t => t.id === taskId) || null;
  }, [tasks]);

  // Get the currently selected task with validation
  const selectedTaskData = useMemo(() => {
    return getSelectedTask(selectedTask);
  }, [getSelectedTask, selectedTask]);

  // Filter change handler - memoized
  const handleFilterChange = useCallback((filterType: string, value: string | boolean | number | null) => {
    if (!isMountedRef.current) {
      console.warn('Filter change attempted when component is unmounted');
      return;
    }
    
    // Track filter change
    trackUserInteraction('filter_change', {
      filterType,
      newValue: value,
      previousValue: filterType === 'domain' ? selectedDomain :
                    filterType === 'stage' ? selectedStage :
                    filterType === 'status' ? selectedStatus : null
    });
    
    // Update the appropriate filter
    if (filterType === 'domain') {
      setSelectedDomain(value as number | null);
    } else if (filterType === 'stage') {
      setSelectedStage(value as string | null);
    } else if (filterType === 'status') {
      setSelectedStatus(value as 'all' | 'completed' | 'incomplete');
    }
    
    // Reset to first page when filters change
    setCurrentPage(1);
  }, [selectedDomain, selectedStage, selectedStatus, trackUserInteraction]);

  // Update filter select handlers to use the new handleFilterChange function
  const handleDomainFilterChange = useCallback((e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value ? parseInt(e.target.value) : null;
    handleFilterChange('domain', value);
  }, [handleFilterChange]);
  
  const handleStageFilterChange = useCallback((e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value || null;
    handleFilterChange('stage', value);
  }, [handleFilterChange]);
  
  const handleStatusFilterChange = useCallback((e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value as 'all' | 'completed' | 'incomplete';
    handleFilterChange('status', value);
  }, [handleFilterChange]);
  
  const handleSearchChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchTerm(value);
    
    // Only track search after debounce to avoid excessive events
    if (value.length === 0 || value.length > 2) {
      trackUserInteraction('search_change', {
        term: value,
        resultsCount: filteredTasks.length
      });
    }
  }, [trackUserInteraction, filteredTasks.length]);

  // Virtual list implementation for very large task collections
  const VirtualizedTaskList: React.FC<{
    tasks: Task[];
    taskClickHandlers: Record<string, () => void>;
    handleTaskClick: (taskId: string) => void;
  }> = ({ tasks, taskClickHandlers, handleTaskClick }) => {
    // Monitor rendering performance
    const { trackEvent: trackVirtualListEvent } = useRenderPerformance(`VirtualizedTaskList(${tasks.length})`);
    
    // Monitor for memory leaks in development
    useMemoryLeakDetector(`VirtualizedTaskList-${tasks.length}`);
    
    // Virtual list state
    const containerRef = useRef<HTMLDivElement>(null);
    const [visibleRange, setVisibleRange] = useState({ start: 0, end: 20 });
    const [itemHeight, setItemHeight] = useState(200); // Estimated height
    const bufferSize = 5; // Extra items to render above/below viewport
    
    // Measure actual item height after first render
    const measureRef = useRef<HTMLDivElement>(null);
    useEffect(() => {
      if (measureRef.current && tasks.length > 0) {
        const height = measureRef.current.getBoundingClientRect().height;
        if (height > 0 && height !== itemHeight) {
          setItemHeight(height);
        }
      }
    }, [tasks, itemHeight]);
    
    // Update visible items on scroll
    useEffect(() => {
      if (!containerRef.current) return;
      
      const container = containerRef.current;
      let scrollTicking = false;
      
      const handleScroll = () => {
        if (!scrollTicking) {
          window.requestAnimationFrame(() => {
            if (container) {
              const { scrollTop, clientHeight } = container;
              const startIndex = Math.max(0, Math.floor(scrollTop / itemHeight) - bufferSize);
              const endIndex = Math.min(
                tasks.length - 1,
                Math.ceil((scrollTop + clientHeight) / itemHeight) + bufferSize
              );
              
              setVisibleRange({ start: startIndex, end: endIndex });
              trackVirtualListEvent('scroll_update', { 
                visible: endIndex - startIndex + 1,
                total: tasks.length,
                scrollPosition: scrollTop
              });
              
              scrollTicking = false;
            }
          });
          scrollTicking = true;
        }
      };
      
      container.addEventListener('scroll', handleScroll);
      // Initial calculation
      handleScroll();
      
      return () => {
        container.removeEventListener('scroll', handleScroll);
      };
    }, [tasks.length, itemHeight, trackVirtualListEvent]);
    
    // Define a local TaskItem component to avoid circular dependencies
    const TaskItem = ({ task, measure = false }: { task: Task, measure?: boolean }) => {
      if (!task || !task.id) return null;
      
      // Use a ref to track if we've already prefetched this task's data
      const prefetchedRef = useRef(false);
      
      // Handle hover to prefetch data
      const handleMouseEnter = () => {
        if (!prefetchedRef.current) {
          prefetchTaskData(task.id);
          prefetchedRef.current = true;
        }
      };
      
      return (
        <div 
          ref={measure ? measureRef : undefined}
          key={task.id}
          onClick={taskClickHandlers[task.id]}
          onMouseEnter={handleMouseEnter}
          onFocus={handleMouseEnter}
          className="cursor-pointer hover:shadow-md transition-shadow"
          role="listitem"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              handleTaskClick(task.id);
            }
          }}
          aria-label={`Task: ${task.title}`}
        >
          <MemoizedTaskCard 
            key={task.id} 
            task={task} 
            onClick={taskClickHandlers[task.id]}
            onToggleComplete={() => {}} 
          />
        </div>
      );
    };
    
    // Memoized task item
    const MemoizedTaskItem = useMemo(() => React.memo(TaskItem), []);
    
    // Only render if we have tasks
    if (tasks.length === 0) return null;
    
    // Calculate total height to maintain proper scrollbar
    const totalHeight = tasks.length * itemHeight;
    // Calculate visible items
    const visibleItems = tasks.slice(visibleRange.start, visibleRange.end + 1);
    // Calculate offset for absolute positioning
    const offsetTop = visibleRange.start * itemHeight;
    
    return (
      <div 
        ref={containerRef}
        className="overflow-auto h-[600px] relative"
        style={{ willChange: 'transform' }}
      >
        {/* Spacer to maintain scroll area */}
        <div style={{ height: `${totalHeight}px` }} />
        
        {/* Measurement item (first render only) */}
        {tasks.length > 0 && visibleRange.start === 0 && (
          <div className="absolute top-0 left-0 opacity-0 pointer-events-none">
            <MemoizedTaskItem task={tasks[0]} measure={true} />
          </div>
        )}
        
        {/* Visible items */}
        <div 
          className="absolute left-0 right-0"
          style={{ top: `${offsetTop}px` }}
        >
          {visibleItems.map(task => (
            <MemoizedTaskItem key={task.id} task={task} />
          ))}
        </div>
      </div>
    );
  };
  
  // Memoized virtualized list
  const MemoizedVirtualizedTaskList = useMemo(() => React.memo(VirtualizedTaskList), []);
  
  // Detect device performance capabilities
  useEffect(() => {
    if (!isMountedRef.current) return;
    
    const detectDevicePerformance = () => {
      // Use hardware concurrency as a proxy for device capability
      const cores = navigator.hardwareConcurrency || 4;
      
      // Use memory if available (Chrome only)
      const memory = (navigator as any).deviceMemory || 4;
      
      // Check if device is mobile
      const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
      
      // Determine performance tier
      let performanceTier: 'low' | 'medium' | 'high';
      
      if (isMobile && (cores <= 4 || memory <= 4)) {
        performanceTier = 'low';
      } else if (cores >= 8 && memory >= 8) {
        performanceTier = 'high';
      } else {
        performanceTier = 'medium';
      }
      
      // Set chunk size based on performance tier
      const newChunkSize = performanceTier === 'low' ? 5 : 
                          performanceTier === 'medium' ? 10 : 20;
      
      setDevicePerformance(performanceTier);
      setChunkSize(newChunkSize);
      
      // Track device capabilities
      trackRenderEvent('device_capabilities', {
        cores,
        memory,
        isMobile,
        performanceTier,
        chunkSize: newChunkSize,
        userAgent: navigator.userAgent
      });
    };
    
    detectDevicePerformance();
  }, [trackRenderEvent]);
  
  // Adjust chunk size based on screen size and device performance
  const getOptimalChunkSize = useCallback((tasksCount: number) => {
    // Base size on device performance
    let optimal = chunkSize;
    
    // Adjust for very large lists
    if (tasksCount > 100) {
      optimal = Math.max(5, optimal / 2);
    } else if (tasksCount < 20) {
      // For small lists, just render all at once
      optimal = tasksCount;
    }
    
    return optimal;
  }, [chunkSize]);

  // Performance monitoring component for development mode
  const PerformanceMonitor = useCallback(() => {
    // Only show in development mode
    if (process.env.NODE_ENV !== 'development') return null;
    
    const [stats, setStats] = useState({
      fps: 0,
      memory: 0,
      tasks: filteredTasks.length,
      renderCount: 0
    });
    
    useEffect(() => {
      let frameCount = 0;
      let lastTime = performance.now();
      let animFrameId: number;
      
      const updateStats = () => {
        const now = performance.now();
        const elapsed = now - lastTime;
        
        if (elapsed >= 1000) {
          // Calculate FPS
          const fps = Math.round((frameCount * 1000) / elapsed);
          
          // Get memory usage if available
          let memory = 0;
          if (window.performance && (performance as any).memory) {
            memory = Math.round((performance as any).memory.usedJSHeapSize / (1024 * 1024));
          }
          
          setStats(prev => ({
            ...prev,
            fps,
            memory,
            tasks: filteredTasks.length,
            renderCount: prev.renderCount + 1
          }));
          
          frameCount = 0;
          lastTime = now;
        }
        
        frameCount++;
        animFrameId = requestAnimationFrame(updateStats);
      };
      
      animFrameId = requestAnimationFrame(updateStats);
      
      return () => {
        cancelAnimationFrame(animFrameId);
      };
    }, [filteredTasks.length]);
    
    return (
      <div className="fixed bottom-0 right-0 bg-black bg-opacity-75 text-white text-xs p-2 font-mono z-50">
        <div>FPS: {stats.fps}</div>
        {stats.memory > 0 && <div>Mem: {stats.memory} MB</div>}
        <div>Tasks: {stats.tasks}</div>
        <div>Perf: {devicePerformance}</div>
        <div>Chunk: {chunkSize}</div>
      </div>
    );
  }, [filteredTasks.length, devicePerformance, chunkSize]);
  
  // Only render performance monitor in development
  const shouldShowPerformanceMonitor = process.env.NODE_ENV === 'development';

  // Enhanced task item with hover prefetching
  const TaskItemWithPrefetch = useCallback(({ task }: { task: Task }) => {
    // Check if the task has valid data to prevent rendering errors
    if (!task || !task.id) {
      console.error('Invalid task data:', task);
      return null;
    }
    
    // Use a ref to track if we've already prefetched this task's data
    const prefetchedRef = useRef(false);
    
    // Handle hover to prefetch data
    const handleMouseEnter = () => {
      if (!prefetchedRef.current) {
        prefetchTaskData(task.id);
        prefetchedRef.current = true;
      }
    };
    
    return (
      <div 
        key={task.id}
        onClick={taskClickHandlers[task.id]}
        onMouseEnter={handleMouseEnter}
        onFocus={handleMouseEnter}
        className="cursor-pointer hover:shadow-md transition-shadow"
        role="listitem"
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            handleTaskClick(task.id);
          }
        }}
        aria-label={`Task: ${task.title}`}
      >
        <MemoizedTaskCard 
          key={task.id} 
          task={task} 
          onClick={taskClickHandlers[task.id]}
          onToggleComplete={() => {}} // Not used in this context
        />
      </div>
    );
  }, [taskClickHandlers, handleTaskClick, prefetchTaskData]);

  // Chunked task list component to handle large lists efficiently
  const ChunkedTaskList: React.FC<{ 
    tasks: Task[]; 
    chunkSize?: number;
    taskClickHandlers: Record<string, () => void>;
    handleTaskClick: (taskId: string) => void;
  }> = ({ tasks, chunkSize = 10, taskClickHandlers, handleTaskClick }) => {
    // Monitor rendering performance
    const { trackEvent: trackTaskListEvent } = useRenderPerformance(`ChunkedTaskList(${tasks.length})`);

    // Monitor for memory leaks in development
    useMemoryLeakDetector(`ChunkedTaskList-${tasks.length}`);

    // Memoized task item to prevent unnecessary re-renders
    const MemoizedTaskItemWithPrefetch = useMemo(() => React.memo(TaskItemWithPrefetch), [TaskItemWithPrefetch]);

    // For small lists, render directly
    if (tasks.length <= chunkSize) {
      return (
        <>
          {tasks.map((task: Task) => (
            <MemoizedTaskItemWithPrefetch key={task.id} task={task} />
          ))}
        </>
      );
    }
    
    // For large lists, use chunked rendering with useEffect
    const [renderedTasks, setRenderedTasks] = useState<Task[]>([]);
    
    useEffect(() => {
      // Reset rendered tasks when the task list changes
      setRenderedTasks(tasks.slice(0, chunkSize));
      
      // Render remaining tasks in chunks
      let currentIndex = chunkSize;
      let timerId: NodeJS.Timeout | null = null;
      
      const renderNextChunk = () => {
        if (currentIndex >= tasks.length) return;
        
        setRenderedTasks(prev => [
          ...prev,
          ...tasks.slice(currentIndex, currentIndex + chunkSize)
        ]);
        
        currentIndex += chunkSize;
        
        // Schedule next chunk with setTimeout
        // Use a short timeout to avoid blocking the main thread
        timerId = setTimeout(() => renderNextChunk(), 10);
      };
      
      // Start rendering chunks after a small delay
      timerId = setTimeout(renderNextChunk, 50);
      
      return () => {
        if (timerId) clearTimeout(timerId);
      };
    }, [tasks, chunkSize]);
    
    return (
      <>
        {renderedTasks.map((task: Task) => (
          <MemoizedTaskItemWithPrefetch key={task.id} task={task} />
        ))}
      </>
    );
  };

  // Memoized chunked task list to prevent unnecessary re-renders
  const MemoizedChunkedTaskList = React.memo(ChunkedTaskList);
  
  // Show error state if data loading failed
  if (loadError) {
    return (
      <div className="max-w-6xl mx-auto">
        <div className="bg-white rounded-xl shadow-sm p-8 text-center">
          <div className="inline-flex items-center justify-center p-3 bg-red-100 rounded-full mb-4">
            <X className="h-8 w-8 text-red-500" />
          </div>
          <h3 className="text-lg font-semibold text-neutral-800 mb-2">{t('tasks.errors.loadingFailed', 'Error Loading Tasks')}</h3>
          <p className="text-neutral-600 max-w-md mx-auto mb-6">{loadError}</p>
          <button 
            onClick={handleRetryLoad}
            className="px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 transition-colors"
          >
            {t('common.retry', 'Retry')}
          </button>
        </div>
      </div>
    );
  }

  // Show loading state if data is loading
  if (isLoading) {
    return (
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6 animate-pulse">
          <div className="h-8 w-64 bg-neutral-200 rounded mb-2"></div>
          <div className="h-4 w-96 bg-neutral-100 rounded"></div>
        </div>
        <div className="bg-white rounded-xl shadow-sm p-8 flex justify-center items-center">
          <div 
            className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-500"
            role="status"
            aria-label={t('common.loading', 'Loading...')}
          >
            <span className="sr-only">{t('common.loading', 'Loading...')}</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <ErrorBoundary
      fallbackRender={({ error }) => (
        <div className="max-w-6xl mx-auto p-6 bg-white rounded-xl shadow-sm">
          <h2 className="text-xl font-bold text-red-600 mb-4">Error Loading Tasks</h2>
          <p className="text-neutral-800 mb-4">{error.message}</p>
          <button 
            onClick={() => window.location.reload()}
            className="px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700"
          >
            Reload Page
          </button>
        </div>
      )}
    >
      <div className="max-w-6xl mx-auto" role="main" aria-label="Tasks Page">
        {/* Offline warning banner */}
        <OfflineBanner />
        
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
            <h1 className="text-2xl font-bold text-neutral-800 dark:text-neutral-200 flex items-center">
            <CheckSquare className="me-2 text-primary-500 h-6 w-6" />
            {t('tasks.tasks', 'Tasks')}
          </h1>
          <p className="text-neutral-600 mt-1">
            {t('tasks.manageAndTrackYourPmoImplementationTasks', 'Manage and track your PMO implementation tasks')}
          </p>
        </div>
        <div className="mt-4 md:mt-0 flex items-center justify-center md:justify-end w-full md:w-auto">
          <div className="w-full sm:w-auto mx-auto md:mx-0 max-w-sm md:max-w-none flex flex-wrap items-center p-2 bg-white rounded-lg border border-neutral-200 shadow-sm me-4">
            <div className="text-center px-3 py-1 border-b sm:border-b-0 sm:border-r border-neutral-200 w-full sm:w-auto">
              <p className="text-xs text-neutral-500">{t('tasks.completed', 'Completed')}</p>
              <p className="text-lg font-bold text-accent-600">{completedTasks}</p>
            </div>
            <div className="text-center px-3 py-1 border-b sm:border-b-0 sm:border-r border-neutral-200 w-full sm:w-auto">
              <p className="text-xs text-neutral-500">{t('tasks.total', 'Total')}</p>
              <p className="text-lg font-bold text-neutral-800">{totalTasks}</p>
            </div>
            <div className="text-center px-3 py-1 w-full sm:w-auto">
              <p className="text-xs text-neutral-500">{t('tasks.rate', 'Rate')}</p>
              <p className="text-lg font-bold text-primary-600">{completionRate}%</p>
            </div>
          </div>
        </div>
      </div>
      
      <div className="bg-white rounded-xl shadow-sm p-6 mb-6 border border-neutral-100">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-4">
          <div className="w-full md:w-1/2 relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-4 w-4 text-neutral-400" />
            </div>
            <input
              type="text"
              placeholder={t('tasks.searchTasks', 'Search tasks...')}
              className="pl-10 px-3 py-2 block w-full rounded-md border-neutral-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 text-neutral-800 dark:text-neutral-800 sm:text-sm"
              value={searchTerm}
                onChange={handleSearchChange}
                aria-label="Search tasks"
            />
          </div>
          <div className="mt-4 md:mt-0 flex items-center">
            <button 
              className="px-3 py-1.5 bg-neutral-100 text-neutral-700 rounded-md flex items-center text-sm hover:bg-neutral-200 transition-colors"
              onClick={() => setShowFilters(!showFilters)}
                aria-expanded={showFilters}
                aria-controls="task-filters"
            >
              <Filter className="h-4 w-4 me-1.5" />
              {t('tasks.filters', 'Filters')}
              <ChevronDown className={`h-4 w-4 ms-1.5 transform transition-transform ${showFilters ? 'rotate-180' : ''}`} />
            </button>
            {(selectedDomain !== null || selectedStage !== null || selectedStatus !== 'all' || searchTerm !== '') && (
              <button 
                className="ms-2 px-3 py-1.5 border border-neutral-200 text-neutral-700 rounded-md flex items-center text-sm hover:bg-neutral-50 transition-colors"
                onClick={clearFilters}
                  aria-label="Clear filters"
                  disabled={isActionLoading}
              >
                <X className="h-4 w-4 me-1.5" />
                {t('tasks.clear', 'Clear')}
              </button>
            )}
          </div>
        </div>
        
        {showFilters && (
            <div id="task-filters" className="mt-4 p-4 bg-neutral-50 rounded-lg border border-neutral-100 grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
                <label className="block text-sm font-medium text-neutral-700 mb-1" htmlFor="domain-filter">
                  {t('tasks.domain', 'Domain')}
                </label>
              <select
                  id="domain-filter"
                className="px-3 py-2 block w-full rounded-md border-neutral-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 text-neutral-800 sm:text-sm"
                value={selectedDomain || ''}
                  onChange={handleDomainFilterChange}
              >
                <option value="">{t('tasks.allDomains', 'All Domains')}</option>
                {domains.map(domain => (
                  <option key={domain.id} value={domain.id}>{t(`domains.${domain.id}.name`, domain.name)}</option>
                ))}
              </select>
            </div>
            <div>
                <label className="block text-sm font-medium text-neutral-700 mb-1" htmlFor="stage-filter">
                  {t('tasks.stage', 'Stage')}
                </label>
              <select
                  id="stage-filter"
                className="px-3 py-2 block w-full rounded-md border-neutral-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 text-neutral-800 sm:text-sm"
                value={selectedStage || ''}
                  onChange={handleStageFilterChange}
              >
                <option value="">{t('tasks.allStages', 'All Stages')}</option>
                <option value="input">{t('tasks.input', 'Input')}</option>
                <option value="processing">{t('tasks.processing', 'Processing')}</option>
                <option value="output">{t('tasks.output', 'Output')}</option>
              </select>
            </div>
            <div>
                <label className="block text-sm font-medium text-neutral-700 mb-1" htmlFor="status-filter">
                  {t('tasks.status', 'Status')}
                </label>
              <select
                  id="status-filter"
                className="px-3 py-2 block w-full rounded-md border-neutral-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 text-neutral-800 sm:text-sm"
                value={selectedStatus}
                  onChange={handleStatusFilterChange}
              >
                <option value="all">{t('tasks.allTasks', 'All Tasks')}</option>
                <option value="completed">{t('tasks.completed', 'Completed')}</option>
                <option value="incomplete">{t('tasks.incomplete', 'Incomplete')}</option>
              </select>
            </div>
          </div>
        )}
        
        {filteredTasks.length === 0 && (
          <div className="mt-6 bg-neutral-50 p-8 rounded-lg border border-neutral-100 text-center">
            <div className="inline-flex items-center justify-center p-3 bg-neutral-100 rounded-full mb-4">
              <CheckSquare className="h-8 w-8 text-neutral-500" />
            </div>
            <h3 className="text-lg font-semibold text-neutral-800 mb-2">{t('tasks.noTasksFound', 'No tasks found')}</h3>
            <p className="text-neutral-600 max-w-md mx-auto">
              {searchTerm || selectedDomain !== null || selectedStage !== null || selectedStatus !== 'all'
                ? t('tasks.noTasksMatchFilters', 'No tasks match your current filters. Try adjusting or clearing your filters.')
                : t('tasks.noTasksAvailable', 'No tasks available. Start by creating a new task.')}
            </p>
            {(searchTerm || selectedDomain !== null || selectedStage !== null || selectedStatus !== 'all') && (
              <button 
                className="mt-4 px-4 py-2 border border-neutral-200 bg-white text-neutral-700 rounded-md inline-flex items-center hover:bg-neutral-50"
                onClick={clearFilters}
                  disabled={isActionLoading}
              >
                <X className="h-4 w-4 me-1.5" />
                {t('tasks.clearFilters', 'Clear Filters')}
              </button>
            )}
          </div>
        )}
      </div>
      
      {/* Task Management Interface */}
        {isActionLoading && (
          <LoadingOverlay />
        )}
        
      {selectedTask ? (
          selectedTaskData ? (
            <MemoizedTaskManager 
              task={selectedTaskData}
          onUpdate={handleTaskUpdate}
          onDelete={handleTaskUpdate}
        />
      ) : (
            <div className="bg-white rounded-xl shadow-sm p-8 text-center">
              <div className="inline-flex items-center justify-center p-3 bg-amber-100 rounded-full mb-4">
                <X className="h-8 w-8 text-amber-500" />
              </div>
              <h3 className="text-lg font-semibold text-neutral-800 mb-2">{t('tasks.errors.taskNotFound', 'Task Not Found')}</h3>
              <p className="text-neutral-600 max-w-md mx-auto mb-6">
                {t('tasks.errors.taskMayHaveBeenDeleted', 'This task may have been deleted or is no longer available.')}
              </p>
              <button 
                onClick={() => setSelectedTask(null)}
                className="px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 transition-colors"
              >
                {t('common.backToTasks', 'Back to Tasks')}
              </button>
            </div>
          )
        ) : (
          <div className="task-domains" role="list" aria-label="Task domains" ref={taskListRef}>
            {Object.entries(tasksByDomain).map(([domainId, domainTasks]) => {
          const domain = domains.find(d => d.id === parseInt(domainId));
          if (!domain) return null;
          
          return (
                <div key={domainId} className="mb-8" role="listitem">
              <div className="flex flex-col sm:flex-row sm:items-center mb-4">
                <div className="mb-2 sm:mb-0">
                  <h2 className="text-lg font-semibold text-neutral-800 dark:text-neutral-200">{t(`domains.${domain.id}.name`, domain.name)}</h2>
                </div>
                <div className="mt-2 sm:mt-0 sm:ms-auto flex items-center justify-between w-full sm:w-auto">
                  <div className="flex items-center text-sm text-neutral-500">
                    <span>{t('tasks.progress', 'Progress')}:</span>
                    <div className="ms-2 w-24 h-1.5 bg-neutral-100 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-gradient-to-r from-primary-500 to-secondary-500 rounded-full"
                        style={{ width: `${getDomainProgress(parseInt(domainId)).overallProgress}%` }}
                            role="progressbar"
                            aria-valuenow={Math.round(getDomainProgress(parseInt(domainId)).overallProgress)}
                            aria-valuemin={0}
                            aria-valuemax={100}
                      ></div>
                    </div>
                    <span className="ms-2 font-medium">
                      {Math.round(getDomainProgress(parseInt(domainId)).overallProgress)}%
                    </span>
                  </div>
                  <div className="ms-6 px-2 py-0.5 bg-primary-100 text-primary-800 rounded-md text-xs font-medium flex-shrink-0">
                    {domainTasks.length} {t('tasks.tasks', 'tasks')}
                  </div>
                </div>
              </div>
              
                  <div 
                    className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4" 
                    role="list" 
                    aria-label={`${domain.name} tasks`}
                    style={{ 
                      ...(supportsContentVisibility && domainTasks.length > 20 ? {
                        contentVisibility: 'auto',
                        containIntrinsicSize: '200px'
                      } : {})
                    }}
                  >
                    {shouldUseVirtualization(domainTasks.length) ? (
                      <MemoizedVirtualizedTaskList tasks={domainTasks} taskClickHandlers={taskClickHandlers} handleTaskClick={handleTaskClick} />
                    ) : (
                      <MemoizedChunkedTaskList tasks={domainTasks} chunkSize={getOptimalChunkSize(domainTasks.length)} taskClickHandlers={taskClickHandlers} handleTaskClick={handleTaskClick} />
                    )}
                  </div>
                    </div>
                  );
                })}
              </div>
      )}
      
      <div className="bg-gradient-to-r from-primary-700 to-secondary-700 rounded-xl shadow-md p-6 text-white mb-8">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="mb-4 md:mb-0 md:me-6 rtl:md:me-0 rtl:md:ml-6">
            <h2 className="text-xl font-bold flex items-center">
              <Calendar className="h-5 w-5 me-2" />
              {t('tasks.taskManagementTips', 'Task Management Tips')}
            </h2>
            <p className="mt-2 text-white/80 max-w-xl">
              {t('tasks.taskManagementTipsDescription', 'Prioritize tasks based on your PMO maturity level and organizational goals. Complete the Input stage tasks first before moving to Processing and Output stages for the best results.')}
            </p>
          </div>
          <div className="flex-shrink-0">
            <button 
              onClick={handleNavigateToResources} 
              className="px-4 py-2 bg-white text-primary-700 rounded-lg shadow-sm hover:shadow-md transition-all duration-200 font-medium inline-flex items-center justify-center"
                disabled={isActionLoading}
                aria-label="View best practices"
            >
              {t('tasks.viewBestPractices', 'View Best Practices')}
            </button>
          </div>
        </div>
      </div>
    </div>
      {shouldShowPerformanceMonitor && <PerformanceMonitor />}
    </ErrorBoundary>
  );
};

export default TasksPage;