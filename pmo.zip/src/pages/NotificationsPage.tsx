import React from 'react';
import { Bell, Check, AlertCircle, Clock, Calendar, ChevronRight, Star, FileText, MailOpen } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
const NotificationsPage: React.FC = () => {
  const { t } = useLanguage();
  const notifications = [
    {
      id: 1,
      type: 'alert',
      title: 'PMO Maturity Assessment Due',
      description: 'Complete your quarterly PMO maturity assessment by Friday.',
      time: '2 days ago',
      read: false,
      icon: AlertCircle,
      iconColor: 'text-secondary-500',
      bgColor: 'bg-secondary-50'
    },
    {
      id: 2,
      type: 'update',
      title: 'Strategic Elements Domain Updated',
      description: 'New templates and resources have been added to the Strategic Elements domain.',
      time: '3 days ago',
      read: false,
      icon: FileText,
      iconColor: 'text-primary-500',
      bgColor: 'bg-primary-50'
    },
    {
      id: 3,
      type: 'reminder',
      title: 'Team Meeting: PMO Enhancement',
      description: 'Upcoming team meeting to discuss PMO Enhancement strategies.',
      time: 'Tomorrow, 10:00 AM',
      read: true,
      icon: Calendar,
      iconColor: 'text-accent-500',
      bgColor: 'bg-accent-50'
    },
    {
      id: 4,
      type: 'message',
      title: 'New Message from Admin',
      description: 'You have a new message regarding your Organization Development domain progress.',
      time: '1 week ago',
      read: true,
      icon: MailOpen,
      iconColor: 'text-neutral-500',
      bgColor: 'bg-neutral-50'
    },
    {
      id: 5,
      type: 'system',
      title: 'Data Backup Complete',
      description: 'Your PMO data has been successfully backed up to cloud storage.',
      time: '2 weeks ago',
      read: true,
      icon: Check,
      iconColor: 'text-accent-500',
      bgColor: 'bg-accent-50'
    }
  ];

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold  text-neutral-800 dark:text-neutral-200 flex items-center">
            <Bell className="me-2 text-primary-500 h-6 w-6" />
            {t('notifications.title')}
          </h1>
          <p className="text-gray-600 dark:text-gray-300 mt-1">
            {t('notifications.description')}
          </p>
        </div>
        <div className="flex gap-2">
          <button className="text-sm font-medium text-neutral-600 hover:text-neutral-800 flex items-center">
            <Check className="h-4 w-4 me-1" />
            {t('notifications.markAllAsRead')}
          </button>
          <button className="text-sm font-medium text-neutral-600 hover:text-neutral-800 flex items-center">
            <Clock className="h-4 w-4 me-1" />
            {t('notifications.clearAll')}
          </button>
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-lg font-semibold text-neutral-800 dark:text-neutral-400">
            {t('notifications.recentNotifications')}
          </h2>
          <div className="flex gap-x-2">
            <button className="px-3 py-1 bg-primary-100 text-primary-700 rounded-full text-sm font-medium">
              {t('notifications.all')}
            </button>
            <button className="px-3 py-1 bg-neutral-100 text-neutral-700 rounded-full text-sm font-medium hover:bg-neutral-200">
              {t('notifications.unread')}
            </button>
          </div>
        </div>

        {notifications.map((notification) => (
          <div 
            key={notification.id} 
            className={`bg-white p-4 rounded-lg border ${notification.read ? 'border-neutral-100' : 'border-primary-200'} shadow-sm hover:shadow-md transition-all duration-200`}
          >
            <div className="flex items-start">
              <div className={`p-2 ${notification.bgColor} rounded-lg me-4`}>
                <notification.icon className={`h-6 w-6 ${notification.iconColor}`} />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h3 className={`font-semibold ${notification.read ? 'text-neutral-700' : 'text-neutral-900'}`}>
                    {t(`notifications.${notification.id}.title`)}
                    {!notification.read && (
                      <span className="ms-2 inline-block h-2 w-2 rounded-full bg-primary-500"></span>
                    )}
                  </h3>
                  <span className="text-xs text-neutral-500">{t(`notifications.${notification.id}.time`)}</span>
                </div>
                <p className="text-sm text-neutral-600 mt-1">{t(`notifications.${notification.id}.description`)}</p>
                <div className="mt-2 flex items-center justify-between">
                  <button className="text-sm text-primary-600 hover:text-primary-700 font-medium flex items-center">
                    {t('notifications.viewDetails')} <ChevronRight className="h-4 w-4 ms-1 rtl:rotate-180" />
                  </button>
                  <button className="text-xs text-neutral-500 hover:text-neutral-700">
                    {notification.read ? t('notifications.markAsUnread') : t('notifications.markAsRead')}
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}

        <div className="mt-6 flex justify-center">
          <button className="px-4 py-2 border border-neutral-200 rounded-lg text-neutral-700 hover:bg-neutral-50 text-sm font-medium">
            {t('notifications.loadMore')}
          </button>
        </div>
      </div>

      <div className="mt-10 bg-gradient-to-r from-primary-50 to-secondary-50 p-6 rounded-lg shadow-sm border border-primary-100">
        <div className="flex items-center">
          <Star className="h-6 w-6 text-secondary-500 me-3" />
          <div>
            <h3 className="font-semibold text-neutral-800">
              {t('notifications.notificationPreferences')}
            </h3>
            <p className="text-sm text-neutral-600 mt-1">
              {t('notifications.customizeNotifications')}
            </p>
          </div>
        </div>
        <button className="mt-4 px-4 py-2 bg-white text-primary-700 border border-primary-200 rounded-lg shadow-sm hover:shadow text-sm font-medium">
          {t('notifications.managePreferences')}
        </button>
      </div>
    </div>
  );
};

export default NotificationsPage;