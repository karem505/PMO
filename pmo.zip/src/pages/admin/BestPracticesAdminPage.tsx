import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, BookOpen, Tag, BarChart, FolderPlus, Upload, Zap, Book, Download } from 'lucide-react';
import { useAuth } from '../../components/auth/AuthContext';
import BestPracticeUploader from '../../components/admin/BestPracticeUploader';

const BestPracticesAdminPage: React.FC = () => {
  const navigate = useNavigate();
  const { hasRole } = useAuth();
  
  // Check if current user has admin role
  React.useEffect(() => {
    if (!hasRole('admin')) {
      navigate('/dashboard');
    }
  }, [hasRole, navigate]);

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex items-center mb-6">
        <button
          onClick={() => navigate('/admin')}
          className="mr-3 text-gray-600 hover:text-gray-800"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <div>
          <h1 className="text-2xl font-bold  text-gray-800 flex items-center">
            <BookOpen className="mr-2 text-blue-600 h-6 w-6" />
            Best Practices Management
          </h1>
          <p className="text-gray-600 mt-1">
            Upload and manage best practice documents, templates and resources for users
          </p>
        </div>
      </div>

      <div className="space-y-8">
        {/* Key statistics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-100">
            <div className="flex justify-between items-center mb-2">
              <h3 className="text-sm font-medium text-gray-500">Total Documents</h3>
              <Book className="h-5 w-5 text-blue-500" />
            </div>
            <p className="text-3xl font-bold text-gray-900">42</p>
            <div className="mt-2">
              <span className="text-sm text-green-600 flex items-center">
                <Zap className="h-4 w-4 mr-1" />
                <span>12 new in last month</span>
              </span>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-100">
            <div className="flex justify-between items-center mb-2">
              <h3 className="text-sm font-medium text-gray-500">Categories</h3>
              <FolderPlus className="h-5 w-5 text-purple-500" />
            </div>
            <p className="text-3xl font-bold text-gray-900">7</p>
            <div className="mt-2">
              <span className="text-sm text-gray-600">Across all domains</span>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-100">
            <div className="flex justify-between items-center mb-2">
              <h3 className="text-sm font-medium text-gray-500">Downloads</h3>
              <Download className="h-5 w-5 text-green-500" />
            </div>
            <p className="text-3xl font-bold text-gray-900">256</p>
            <div className="mt-2">
              <span className="text-sm text-green-600">↑ 18% from last month</span>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-100">
            <div className="flex justify-between items-center mb-2">
              <h3 className="text-sm font-medium text-gray-500">Tags</h3>
              <Tag className="h-5 w-5 text-yellow-500" />
            </div>
            <p className="text-3xl font-bold text-gray-900">15</p>
            <div className="mt-2">
              <span className="text-sm text-gray-600">For document organization</span>
            </div>
          </div>
        </div>
        
        {/* Document Manager */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-100">
          <BestPracticeUploader />
        </div>
      </div>
    </div>
  );
};

export default BestPracticesAdminPage;