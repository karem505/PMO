import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../components/auth/AuthContext';
import { 
  ArrowLeft, 
  Users, 
  Search, 
  Filter, 
  UserPlus, 
  Edit, 
  Trash2, 
  Shield, 
  CheckCircle, 
  AlertTriangle, 
  X, 
  Save,
  Loader2
} from 'lucide-react';
import { supabase } from '../../services/supabaseClient';
import { UserRole } from '../../types';
import { getAllRoles, assignRoleToUser, removeRoleFromUser } from '../../services/supabaseService';

const UserManagementPage: React.FC = () => {
  const navigate = useNavigate();
  const { hasRole } = useAuth();
  
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedUser, setSelectedUser] = useState<any | null>(null);
  const [userRoles, setUserRoles] = useState<Record<string, UserRole[]>>({});
  const [availableRoles, setAvailableRoles] = useState<UserRole[]>([]);
  const [editingUser, setEditingUser] = useState<any | null>(null);
  const [savingChanges, setSavingChanges] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  
  // Check if current user has admin role
  useEffect(() => {
    if (!hasRole('admin')) {
      navigate('/');
    }
  }, [hasRole, navigate]);

  // Load users and roles
  useEffect(() => {
    const fetchUsers = async () => {
      setLoading(true);
      try {
        // Fetch users from auth.users table (requires admin privileges)
        const { data: userData, error: userError } = await supabase
          .from('profiles')
          .select('*');
          
        if (userError) throw userError;
        
        if (userData) {
          setUsers(userData);
          
          // Fetch roles for each user
          const userIdsMap = userData.reduce((acc: Record<string, boolean>, user: any) => {
            acc[user.id] = true;
            return acc;
          }, {});
          
          const { data: userRolesData, error: rolesError } = await supabase
            .from('user_roles')
            .select('*, role:roles(*)')
            .in('user_id', Object.keys(userIdsMap));
            
          if (rolesError) throw rolesError;
          
          // Format roles data by user
          if (userRolesData) {
            const rolesByUser: Record<string, UserRole[]> = {};
            
            userRolesData.forEach((userRole: any) => {
              if (!rolesByUser[userRole.user_id]) {
                rolesByUser[userRole.user_id] = [];
              }
              
              rolesByUser[userRole.user_id].push({
                id: userRole.role.id,
                name: userRole.role.name,
                description: userRole.role.description
              });
            });
            
            setUserRoles(rolesByUser);
          }
        }
        
        // Fetch available roles
        const roles = await getAllRoles();
        setAvailableRoles(roles);
      } catch (error) {
        console.error('Error fetching users:', error);
        setError('Failed to load users. Please try again later.');
      } finally {
        setLoading(false);
      }
    };
    
    fetchUsers();
  }, []);

  // Filter users based on search term
  const filteredUsers = users.filter(user => 
    (user.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.display_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.organization_name?.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const handleViewUser = (user: any) => {
    setSelectedUser(user);
  };

  const handleEditUser = (user: any) => {
    setEditingUser({
      ...user,
      roleIds: (userRoles[user.id] || []).map(role => role.id)
    });
  };

  const handleSaveUserChanges = async () => {
    if (!editingUser) return;
    
    setSavingChanges(true);
    setError(null);
    
    try {
      // Update user profile
      const { error: updateError } = await supabase
        .from('profiles')
        .update({
          display_name: editingUser.display_name,
          organization_name: editingUser.organization_name,
          industry: editingUser.industry,
          pmo_maturity_level: editingUser.pmo_maturity_level,
          updated_at: new Date().toISOString()
        })
        .eq('id', editingUser.id);
        
      if (updateError) throw updateError;
      
      // Update user's roles
      const currentRoleIds = (userRoles[editingUser.id] || []).map(role => role.id);
      const newRoleIds = editingUser.roleIds || [];
      
      // Roles to add
      for (const roleId of newRoleIds) {
        if (!currentRoleIds.includes(roleId)) {
          await assignRoleToUser(editingUser.id, roleId);
        }
      }
      
      // Roles to remove
      for (const roleId of currentRoleIds) {
        if (!newRoleIds.includes(roleId)) {
          await removeRoleFromUser(editingUser.id, roleId);
        }
      }
      
      // Update local state
      setUsers(users.map(user => 
        user.id === editingUser.id ? {
          ...user,
          display_name: editingUser.display_name,
          organization_name: editingUser.organization_name,
          industry: editingUser.industry,
          pmo_maturity_level: editingUser.pmo_maturity_level
        } : user
      ));
      
      // Update user roles in local state
      setUserRoles({
        ...userRoles,
        [editingUser.id]: availableRoles.filter(role => newRoleIds.includes(role.id))
      });
      
      setSuccess('User updated successfully');
      setEditingUser(null);
      
      // Clear success message after 3 seconds
      setTimeout(() => {
        setSuccess(null);
      }, 3000);
    } catch (error) {
      console.error('Error updating user:', error);
      setError('Failed to update user. Please try again.');
    } finally {
      setSavingChanges(false);
    }
  };

  const handleRoleChange = (roleId: string, checked: boolean) => {
    if (!editingUser) return;
    
    let newRoleIds = [...(editingUser.roleIds || [])];
    
    if (checked) {
      // Add role
      if (!newRoleIds.includes(roleId)) {
        newRoleIds.push(roleId);
      }
    } else {
      // Remove role
      newRoleIds = newRoleIds.filter(id => id !== roleId);
    }
    
    setEditingUser({ ...editingUser, roleIds: newRoleIds });
  };

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <button
            onClick={() => navigate('/admin')}
            className="mr-3 text-gray-600 hover:text-gray-800"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold  text-neutral-800 flex items-center">
              <Users className="mr-2 text-primary-600 h-6 w-6" />
              User Management
            </h1>
            <p className="text-neutral-600 mt-1">
              Manage users, roles, and permissions
            </p>
          </div>
        </div>
        <button
          className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 flex items-center"
        >
          <UserPlus className="h-4 w-4 mr-2" />
          Create User
        </button>
      </div>
      
      {error && (
        <div className="mb-4 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded relative">
          <span className="block sm:inline">{error}</span>
          <button
            className="absolute top-0 bottom-0 right-0 px-4 py-3"
            onClick={() => setError(null)}
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      )}
      
      {success && (
        <div className="mb-4 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded relative">
          <span className="block sm:inline">{success}</span>
          <button
            className="absolute top-0 bottom-0 right-0 px-4 py-3"
            onClick={() => setSuccess(null)}
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      )}
      
      <div className="bg-white rounded-lg shadow-sm mb-6">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-800">Users</h2>
            <div className="flex space-x-2">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-4 w-4 text-gray-400" />
                </div>
                <input
                  type="text"
                  placeholder="Search users..."
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-primary-500 focus:border-primary-500 w-64"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <button
                className="px-3 py-2 border border-gray-300 rounded-md flex items-center text-gray-700 hover:bg-gray-50"
              >
                <Filter className="h-4 w-4 mr-2" />
                Filters
              </button>
            </div>
          </div>
          
          {loading ? (
            <div className="flex justify-center items-center py-12">
              <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary-600"></div>
              <span className="ml-3 text-gray-600">Loading users...</span>
            </div>
          ) : filteredUsers.length === 0 ? (
            <div className="py-8 text-center text-gray-500">
              No users found matching your search criteria.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      User
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Organization
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Roles
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Last Login
                    </th>
                    <th scope="col" className="relative px-6 py-3">
                      <span className="sr-only">Actions</span>
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredUsers.map((user) => (
                    <tr key={user.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="flex-shrink-0 h-10 w-10">
                            {user.photo_url ? (
                              <img className="h-10 w-10 rounded-full" src={user.photo_url} alt="" />
                            ) : (
                              <div className="h-10 w-10 rounded-full bg-primary-100 flex items-center justify-center text-primary-800 font-semibold">
                                {(user.display_name || user.email || 'U')[0].toUpperCase()}
                              </div>
                            )}
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900">
                              {user.display_name || 'Unnamed User'}
                            </div>
                            <div className="text-sm text-gray-500">
                              {user.email}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{user.organization_name || '-'}</div>
                        <div className="text-sm text-gray-500">{user.industry || '-'}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex flex-wrap gap-1">
                          {userRoles[user.id]?.map((role) => (
                            <span 
                              key={role.id} 
                              className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                role.name === 'admin' ? 'bg-red-100 text-red-800' :
                                role.name === 'manager' ? 'bg-blue-100 text-blue-800' :
                                'bg-green-100 text-green-800'
                              }`}
                            >
                              {role.name}
                            </span>
                          ))}
                          {(!userRoles[user.id] || userRoles[user.id].length === 0) && (
                            <span className="text-sm text-gray-500">No roles</span>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {user.last_sign_in_at ? new Date(user.last_sign_in_at).toLocaleDateString() : 'Never'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <div className="flex space-x-2 justify-end">
                          <button
                            onClick={() => handleViewUser(user)}
                            className="text-primary-600 hover:text-primary-900"
                          >
                            View
                          </button>
                          <button
                            onClick={() => handleEditUser(user)}
                            className="text-blue-600 hover:text-blue-900"
                          >
                            Edit
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
      
      {/* User Details Modal */}
      {selectedUser && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full">
            <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-800">User Details</h3>
              <button
                onClick={() => setSelectedUser(null)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="p-6">
              <div className="flex items-center mb-6">
                {selectedUser.photo_url ? (
                  <img
                    src={selectedUser.photo_url}
                    alt="User"
                    className="w-24 h-24 rounded-full object-cover"
                  />
                ) : (
                  <div className="w-24 h-24 rounded-full bg-primary-100 flex items-center justify-center text-primary-800 text-3xl font-semibold">
                    {(selectedUser.display_name || selectedUser.email || 'U')[0].toUpperCase()}
                  </div>
                )}
                <div className="ml-6">
                  <h2 className="text-xl font-semibold">{selectedUser.display_name || 'Unnamed User'}</h2>
                  <p className="text-gray-600">{selectedUser.email}</p>
                  <div className="flex mt-2 space-x-2">
                    {userRoles[selectedUser.id]?.map((role) => (
                      <span 
                        key={role.id} 
                        className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          role.name === 'admin' ? 'bg-red-100 text-red-800' :
                          role.name === 'manager' ? 'bg-blue-100 text-blue-800' :
                          'bg-green-100 text-green-800'
                        }`}
                      >
                        {role.name}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <h4 className="text-sm font-medium text-gray-500 mb-1">Organization</h4>
                  <p className="text-gray-900">{selectedUser.organization_name || '-'}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-gray-500 mb-1">Industry</h4>
                  <p className="text-gray-900">{selectedUser.industry || '-'}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-gray-500 mb-1">PMO Maturity Level</h4>
                  <p className="text-gray-900">{selectedUser.pmo_maturity_level || '-'}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-gray-500 mb-1">Last Sign In</h4>
                  <p className="text-gray-900">
                    {selectedUser.last_sign_in_at ? new Date(selectedUser.last_sign_in_at).toLocaleString() : 'Never'}
                  </p>
                </div>
              </div>
              
              <div className="mt-6">
                <h4 className="text-sm font-medium text-gray-500 mb-3">User Roles & Permissions</h4>
                <div className="bg-gray-50 p-4 rounded-md">
                  {userRoles[selectedUser.id]?.length ? (
                    <div className="space-y-3">
                      {userRoles[selectedUser.id].map((role) => (
                        <div key={role.id} className="bg-white p-3 rounded border border-gray-200">
                          <div className="flex items-start">
                            <Shield className="h-5 w-5 text-primary-600 mt-0.5 mr-3" />
                            <div>
                              <h5 className="font-medium text-gray-900">{role.name}</h5>
                              <p className="text-sm text-gray-600">{role.description}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-gray-500 text-center py-4">
                      No roles assigned to this user
                    </div>
                  )}
                </div>
              </div>
            </div>
            <div className="px-6 py-4 border-t border-gray-200 flex justify-end">
              <button
                onClick={() => setSelectedUser(null)}
                className="px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Edit User Modal */}
      {editingUser && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full">
            <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-800">Edit User</h3>
              <button
                onClick={() => setEditingUser(null)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="p-6">
              <div className="grid grid-cols-2 gap-6 mb-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Display Name
                  </label>
                  <input
                    type="text"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-primary-500 focus:border-primary-500"
                    value={editingUser.display_name || ''}
                    onChange={(e) => setEditingUser({...editingUser, display_name: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email
                  </label>
                  <input
                    type="email"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100"
                    value={editingUser.email || ''}
                    disabled
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Organization
                  </label>
                  <input
                    type="text"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-primary-500 focus:border-primary-500"
                    value={editingUser.organization_name || ''}
                    onChange={(e) => setEditingUser({...editingUser, organization_name: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Industry
                  </label>
                  <input
                    type="text"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-primary-500 focus:border-primary-500"
                    value={editingUser.industry || ''}
                    onChange={(e) => setEditingUser({...editingUser, industry: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    PMO Maturity Level
                  </label>
                  <select
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-primary-500 focus:border-primary-500"
                    value={editingUser.pmo_maturity_level || 'Initial'}
                    onChange={(e) => setEditingUser({...editingUser, pmo_maturity_level: e.target.value})}
                  >
                    <option value="Initial">Initial</option>
                    <option value="Defined">Defined</option>
                    <option value="Managed">Managed</option>
                    <option value="Optimized">Optimized</option>
                    <option value="Innovative">Innovative</option>
                  </select>
                </div>
              </div>
              
              <div className="mb-6">
                <h4 className="text-sm font-medium text-gray-700 mb-3">User Roles</h4>
                <div className="bg-gray-50 p-4 rounded-md">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {availableRoles.map((role) => (
                      <div key={role.id} className="flex items-start">
                        <input
                          type="checkbox"
                          id={`role-${role.id}`}
                          checked={(editingUser.roleIds || []).includes(role.id)}
                          onChange={(e) => handleRoleChange(role.id, e.target.checked)}
                          className="mt-1 h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                        />
                        <label htmlFor={`role-${role.id}`} className="ml-3 block">
                          <span className={`text-sm font-medium ${
                            role.name === 'admin' ? 'text-red-700' : 'text-gray-900'
                          }`}>
                            {role.name}
                          </span>
                          <span className="text-sm text-gray-500 block mt-0.5">{role.description}</span>
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
                
                {role => role.name === 'admin' && (
                  <div className="mt-3 p-3 bg-yellow-50 border border-yellow-200 rounded-md flex items-start">
                    <AlertTriangle className="h-5 w-5 text-yellow-500 mr-2 mt-0.5" />
                    <p className="text-sm text-yellow-700">
                      The admin role grants full system access. Assign with caution.
                    </p>
                  </div>
                )}
              </div>
            </div>
            <div className="px-6 py-4 border-t border-gray-200 flex justify-end space-x-3">
              <button
                onClick={() => setEditingUser(null)}
                className="px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveUserChanges}
                disabled={savingChanges}
                className={`px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 flex items-center ${
                  savingChanges ? 'opacity-70 cursor-not-allowed' : ''
                }`}
              >
                {savingChanges ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="h-4 w-4 mr-2" />
                    Save Changes
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserManagementPage;