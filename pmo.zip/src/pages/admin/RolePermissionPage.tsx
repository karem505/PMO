import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, 
  Shield, 
  Key, 
  Plus, 
  Edit, 
  Trash2, 
  Save, 
  X, 
  CheckSquare, 
  Square, 
  AlertTriangle, 
  Loader2
} from 'lucide-react';
import { useAuth } from '../../components/auth/AuthContext';
import { Permission, UserRole } from '../../types';
import { supabase } from '../../services/supabaseClient';
import { getAllRoles, getAllPermissions } from '../../services/supabaseService';

const RolePermissionPage: React.FC = () => {
  const navigate = useNavigate();
  const { hasRole } = useAuth();
  
  const [roles, setRoles] = useState<UserRole[]>([]);
  const [permissions, setPermissions] = useState<Permission[]>([]);
  const [rolePermissions, setRolePermissions] = useState<Record<string, string[]>>({});
  
  const [selectedRole, setSelectedRole] = useState<UserRole | null>(null);
  const [editingRole, setEditingRole] = useState<UserRole | null>(null);
  const [selectedPermissions, setSelectedPermissions] = useState<string[]>([]);
  
  const [newRole, setNewRole] = useState({ name: '', description: '' });
  const [creatingRole, setCreatingRole] = useState(false);
  
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  
  // Check if current user has admin role
  useEffect(() => {
    if (!hasRole('admin')) {
      navigate('/');
    }
  }, [hasRole, navigate]);
  
  // Load roles and permissions
  useEffect(() => {
    const fetchRolesAndPermissions = async () => {
      setLoading(true);
      try {
        // Fetch roles
        const rolesData = await getAllRoles();
        setRoles(rolesData);
        
        // Fetch permissions
        const permissionsData = await getAllPermissions();
        setPermissions(permissionsData);
        
        // Fetch role-permission mappings
        const { data: rolePerm, error: rolePermError } = await supabase
          .from('role_permissions')
          .select('*');
          
        if (rolePermError) throw rolePermError;
        
        if (rolePerm) {
          // Format role permissions by role
          const permsByRole: Record<string, string[]> = {};
          
          rolePerm.forEach((rp: any) => {
            if (!permsByRole[rp.role_id]) {
              permsByRole[rp.role_id] = [];
            }
            
            permsByRole[rp.role_id].push(rp.permission_id);
          });
          
          setRolePermissions(permsByRole);
        }
      } catch (error) {
        console.error('Error fetching roles and permissions:', error);
        setError('Failed to load roles and permissions data.');
      } finally {
        setLoading(false);
      }
    };
    
    fetchRolesAndPermissions();
  }, []);
  
  // Group permissions by category
  const groupedPermissions = permissions.reduce((groups, permission) => {
    const category = permission.name.split(':')[0];
    if (!groups[category]) {
      groups[category] = [];
    }
    groups[category].push(permission);
    return groups;
  }, {} as Record<string, Permission[]>);
  
  const handleSelectRole = (role: UserRole) => {
    setSelectedRole(role);
    setSelectedPermissions(rolePermissions[role.id] || []);
  };
  
  const handleCreateRole = async () => {
    if (!newRole.name || !newRole.description) {
      setError('Role name and description are required');
      return;
    }
    
    setSaving(true);
    setError(null);
    
    try {
      // Create new role
      const { data, error: createError } = await supabase
        .from('roles')
        .insert([{
          name: newRole.name.toLowerCase(),
          description: newRole.description,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }])
        .select();
        
      if (createError) throw createError;
      
      if (data && data[0]) {
        // Add to local state
        const newRoleData = {
          id: data[0].id,
          name: data[0].name,
          description: data[0].description
        };
        
        setRoles([...roles, newRoleData]);
        setCreatingRole(false);
        setNewRole({ name: '', description: '' });
        setSuccess(`Role "${newRole.name}" created successfully`);
        
        // Clear success message after 3 seconds
        setTimeout(() => {
          setSuccess(null);
        }, 3000);
      }
    } catch (error) {
      console.error('Error creating role:', error);
      setError('Failed to create role. The role name might already exist.');
    } finally {
      setSaving(false);
    }
  };
  
  const handleEditRole = (role: UserRole) => {
    setEditingRole({ ...role });
  };
  
  const handleUpdateRole = async () => {
    if (!editingRole || !editingRole.name || !editingRole.description) {
      setError('Role name and description are required');
      return;
    }
    
    setSaving(true);
    setError(null);
    
    try {
      // Update role
      const { error: updateError } = await supabase
        .from('roles')
        .update({
          name: editingRole.name.toLowerCase(),
          description: editingRole.description,
          updated_at: new Date().toISOString()
        })
        .eq('id', editingRole.id);
        
      if (updateError) throw updateError;
      
      // Update local state
      setRoles(roles.map(r => r.id === editingRole.id ? editingRole : r));
      setEditingRole(null);
      setSuccess(`Role "${editingRole.name}" updated successfully`);
      
      // Update selected role if it was the one being edited
      if (selectedRole && selectedRole.id === editingRole.id) {
        setSelectedRole(editingRole);
      }
      
      // Clear success message after 3 seconds
      setTimeout(() => {
        setSuccess(null);
      }, 3000);
    } catch (error) {
      console.error('Error updating role:', error);
      setError('Failed to update role. The role name might already exist.');
    } finally {
      setSaving(false);
    }
  };
  
  const handleTogglePermission = async (permissionId: string, checked: boolean) => {
    if (!selectedRole) return;
    
    setSaving(true);
    setError(null);
    
    try {
      if (checked) {
        // Add permission to role
        const { error: addError } = await supabase
          .from('role_permissions')
          .insert([{
            role_id: selectedRole.id,
            permission_id: permissionId,
            created_at: new Date().toISOString()
          }]);
          
        if (addError) throw addError;
        
        // Update local state
        setSelectedPermissions([...selectedPermissions, permissionId]);
        setRolePermissions({
          ...rolePermissions,
          [selectedRole.id]: [...(rolePermissions[selectedRole.id] || []), permissionId]
        });
      } else {
        // Remove permission from role
        const { error: removeError } = await supabase
          .from('role_permissions')
          .delete()
          .match({
            role_id: selectedRole.id,
            permission_id: permissionId
          });
          
        if (removeError) throw removeError;
        
        // Update local state
        setSelectedPermissions(selectedPermissions.filter(id => id !== permissionId));
        setRolePermissions({
          ...rolePermissions,
          [selectedRole.id]: (rolePermissions[selectedRole.id] || []).filter(id => id !== permissionId)
        });
      }
    } catch (error) {
      console.error('Error updating role permissions:', error);
      setError('Failed to update permissions.');
    } finally {
      setSaving(false);
    }
  };
  
  const isPermissionSelected = (permissionId: string) => {
    return selectedPermissions.includes(permissionId);
  };

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <button
            onClick={() => navigate('/admin')}
            className="mr-3 text-gray-600 hover:text-gray-800"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold  text-neutral-800 flex items-center">
              <Shield className="mr-2 text-primary-600 h-6 w-6" />
              Roles & Permissions
            </h1>
            <p className="text-neutral-600 mt-1">
              Manage access control for your organization
            </p>
          </div>
        </div>
      </div>
      
      {error && (
        <div className="mb-4 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded relative">
          <span className="block sm:inline">{error}</span>
          <button
            className="absolute top-0 bottom-0 right-0 px-4 py-3"
            onClick={() => setError(null)}
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      )}
      
      {success && (
        <div className="mb-4 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded relative">
          <span className="block sm:inline">{success}</span>
          <button
            className="absolute top-0 bottom-0 right-0 px-4 py-3"
            onClick={() => setSuccess(null)}
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      )}
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Roles panel */}
        <div className="bg-white rounded-lg shadow-sm">
          <div className="p-4 border-b border-gray-200 flex items-center justify-between">
            <h2 className="font-semibold text-gray-800 flex items-center">
              <Shield className="h-5 w-5 mr-2 text-primary-500" />
              Roles
            </h2>
            <button
              onClick={() => setCreatingRole(true)}
              className="p-1.5 text-gray-400 hover:text-primary-600 hover:bg-gray-100 rounded"
            >
              <Plus className="h-4 w-4" />
            </button>
          </div>
          
          {loading ? (
            <div className="flex justify-center items-center py-12">
              <div className="animate-spin rounded-full h-6 w-6 border-t-2 border-b-2 border-primary-600"></div>
            </div>
          ) : (
            <div className="p-4 space-y-2 max-h-[600px] overflow-y-auto">
              {roles.map(role => (
                <div 
                  key={role.id}
                  className={`p-3 rounded-md border cursor-pointer ${
                    selectedRole?.id === role.id 
                      ? 'border-primary-300 bg-primary-50' 
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => handleSelectRole(role)}
                >
                  <div className="flex justify-between items-start">
                    <h3 className={`font-medium ${
                      role.name === 'admin' ? 'text-red-700' : 'text-gray-800'
                    }`}>
                      {role.name}
                    </h3>
                    {selectedRole?.id === role.id && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleEditRole(role);
                        }}
                        className="p-1 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded"
                      >
                        <Edit className="h-3.5 w-3.5" />
                      </button>
                    )}
                  </div>
                  <p className="text-sm text-gray-500 mt-1">{role.description}</p>
                  <div className="mt-2 flex items-center text-xs text-gray-500">
                    <Key className="h-3.5 w-3.5 mr-1" />
                    {rolePermissions[role.id]?.length || 0} permissions
                  </div>
                </div>
              ))}
              
              {roles.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  No roles defined yet
                </div>
              )}
              
              {/* Create role form */}
              {creatingRole && (
                <div className="p-4 border border-primary-300 bg-primary-50 rounded-md">
                  <h3 className="font-medium text-primary-800 mb-3">Create New Role</h3>
                  <div className="mb-3">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Role Name
                    </label>
                    <input
                      type="text"
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-primary-500 focus:border-primary-500"
                      value={newRole.name}
                      onChange={(e) => setNewRole({...newRole, name: e.target.value})}
                      placeholder="e.g., project_manager"
                    />
                  </div>
                  <div className="mb-3">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Description
                    </label>
                    <textarea
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-primary-500 focus:border-primary-500"
                      value={newRole.description}
                      onChange={(e) => setNewRole({...newRole, description: e.target.value})}
                      placeholder="Role description..."
                      rows={2}
                    />
                  </div>
                  <div className="flex justify-end space-x-2 mt-4">
                    <button
                      onClick={() => {
                        setCreatingRole(false);
                        setNewRole({ name: '', description: '' });
                      }}
                      className="px-3 py-1.5 text-sm text-gray-600 hover:text-gray-800"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleCreateRole}
                      disabled={saving}
                      className={`px-3 py-1.5 text-sm bg-primary-600 text-white rounded hover:bg-primary-700 ${
                        saving ? 'opacity-70 cursor-not-allowed' : ''
                      }`}
                    >
                      {saving ? 'Creating...' : 'Create Role'}
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
        
        {/* Permissions panel */}
        <div className="md:col-span-2 bg-white rounded-lg shadow-sm">
          {!selectedRole ? (
            <div className="flex flex-col items-center justify-center h-64 text-gray-500">
              <Shield className="h-12 w-12 mb-3 opacity-20" />
              <p>Select a role to manage its permissions</p>
            </div>
          ) : (
            <>
              <div className="p-4 border-b border-gray-200">
                <h2 className="font-semibold text-gray-800 flex items-center">
                  <Key className="h-5 w-5 mr-2 text-primary-500" />
                  {selectedRole.name} Permissions
                </h2>
                <p className="mt-1 text-sm text-gray-600">{selectedRole.description}</p>
              </div>
              
              {saving && (
                <div className="bg-blue-50 p-2 flex items-center justify-center text-blue-700">
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  <span className="text-sm">Updating permissions...</span>
                </div>
              )}
              
              {Object.keys(groupedPermissions).length > 0 ? (
                <div className="p-4 space-y-6">
                  {Object.entries(groupedPermissions).map(([category, categoryPermissions]) => (
                    <div key={category} className="space-y-3">
                      <h3 className="text-sm font-semibold text-gray-700 uppercase tracking-wider">
                        {category} Permissions
                      </h3>
                      <div className="bg-gray-50 p-3 rounded-md border border-gray-200">
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
                          {categoryPermissions.map(permission => (
                            <div key={permission.id} className="flex items-start">
                              <div className="flex items-center h-5 mt-0.5">
                                <input
                                  id={`permission-${permission.id}`}
                                  name={`permission-${permission.id}`}
                                  type="checkbox"
                                  checked={isPermissionSelected(permission.id)}
                                  onChange={(e) => handleTogglePermission(permission.id, e.target.checked)}
                                  className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                                />
                              </div>
                              <div className="ml-3">
                                <label htmlFor={`permission-${permission.id}`} className="text-sm font-medium text-gray-700">
                                  {permission.name}
                                </label>
                                <p className="text-xs text-gray-500">{permission.description}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex items-center justify-center h-64 text-gray-500">
                  <p>No permissions defined in the system</p>
                </div>
              )}
            </>
          )}
        </div>
      </div>
      
      {/* Edit Role Modal */}
      {editingRole && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full">
            <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-800">Edit Role</h3>
              <button
                onClick={() => setEditingRole(null)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="p-6">
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Role Name
                </label>
                <input
                  type="text"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-primary-500 focus:border-primary-500"
                  value={editingRole.name}
                  onChange={(e) => setEditingRole({...editingRole, name: e.target.value})}
                  placeholder="e.g., project_manager"
                />
              </div>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Description
                </label>
                <textarea
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-primary-500 focus:border-primary-500"
                  value={editingRole.description}
                  onChange={(e) => setEditingRole({...editingRole, description: e.target.value})}
                  placeholder="Role description..."
                  rows={3}
                />
              </div>
              
              {editingRole.name === 'admin' && (
                <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-md flex items-start mb-4">
                  <AlertTriangle className="h-5 w-5 text-yellow-500 mr-2 mt-0.5" />
                  <p className="text-sm text-yellow-700">
                    The admin role is a system role with full access. Changing its name might affect system functionality.
                  </p>
                </div>
              )}
            </div>
            <div className="px-6 py-4 border-t border-gray-200 flex justify-end space-x-3">
              <button
                onClick={() => setEditingRole(null)}
                className="px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200"
              >
                Cancel
              </button>
              <button
                onClick={handleUpdateRole}
                disabled={saving}
                className={`px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 flex items-center ${
                  saving ? 'opacity-70 cursor-not-allowed' : ''
                }`}
              >
                {saving ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="h-4 w-4 mr-2" />
                    Save Changes
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default RolePermissionPage;