import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './index.css';
import { LanguageProvider } from './contexts/LanguageContext';
import { SubscriptionProvider } from './contexts/SubscriptionContext';
import { initSentry, setupGlobalErrorHandlers } from './services/sentryService';
import ErrorBoundary from './components/ErrorBoundary';

// Import dev auth helper (no-op in production)
import './utils/devAuthHelper';

// Initialize Sentry for error tracking
initSentry({
  dsn: import.meta.env.VITE_SENTRY_DSN || '',
  environment: import.meta.env.MODE,
  release: import.meta.env.VITE_APP_VERSION,
  debug: import.meta.env.MODE !== 'production',
});

// Set up global error handlers to catch DOM reference errors
setupGlobalErrorHandlers();

// Add DOM safety patches to prevent nodeName errors
const applyDOMSafetyPatches = () => {
  // Patch React's internal DOM methods to be more resilient
  const originalCreateElement = document.createElement;
  document.createElement = function safeCreateElement(tagName: string, options?: ElementCreationOptions) {
    try {
      return originalCreateElement.call(document, tagName, options);
    } catch (error) {
      console.error(`Error creating element ${tagName}:`, error);
      // Return a safe div as fallback
      return originalCreateElement.call(document, 'div');
    }
  };

  // Add safety to querySelector methods
  const originalQuerySelector = Element.prototype.querySelector;
  Element.prototype.querySelector = function safeQuerySelector(this: Element, selectors: string): Element | null {
    try {
      return originalQuerySelector.call(this, selectors);
    } catch (error) {
      console.error(`Error in querySelector with selector ${selectors}:`, error);
      return null;
    }
  };

  // Add safety to appendChild method
  const originalAppendChild = Node.prototype.appendChild;
  Node.prototype.appendChild = function safeAppendChild<T extends Node>(this: Node, newChild: T): T {
    try {
      if (this && newChild) {
        return originalAppendChild.call(this, newChild);
      }
      console.warn('Prevented appendChild with null/undefined node');
      return newChild;
    } catch (error) {
      console.error('Error in appendChild:', error);
      return newChild;
    }
  };

  // Patch getBoundingClientRect to be safe
  const originalGetBoundingClientRect = Element.prototype.getBoundingClientRect;
  Element.prototype.getBoundingClientRect = function safeBoundingClientRect(this: Element): DOMRect {
    try {
      return originalGetBoundingClientRect.call(this);
    } catch (error) {
      console.error('Error in getBoundingClientRect:', error);
      // Return a dummy DOMRect
      return new DOMRect(0, 0, 0, 0);
    }
  };

  // Patch scrollIntoView to be safe
  const originalScrollIntoView = Element.prototype.scrollIntoView;
  Element.prototype.scrollIntoView = function safeScrollIntoView(this: Element, options?: boolean | ScrollIntoViewOptions): void {
    try {
      if (this.isConnected) {
        originalScrollIntoView.call(this, options);
      } else {
        console.warn('Prevented scrollIntoView on disconnected element');
      }
    } catch (error) {
      console.error('Error in scrollIntoView:', error);
      // Try a fallback scroll
      try {
        window.scrollTo(0, 0);
      } catch (fallbackError) {
        console.error('Even fallback scroll failed:', fallbackError);
      }
    }
  };

  // Add a direct fix for the "Cannot read properties of null (reading 'nodeName')" error
  // This is a common error in React when trying to access DOM nodes that don't exist
  window.addEventListener('error', (event) => {
    if (event.error && event.error.message && event.error.message.includes("Cannot read properties of null (reading 'nodeName')")) {
      // Prevent the error from propagating
      event.preventDefault();
      event.stopPropagation();
      
      console.warn('Intercepted nodeName error and prevented app crash');
      
      // Force a synchronous layout calculation to ensure DOM is up to date
      try {
        document.body.getBoundingClientRect();
      } catch (err) {
        console.error('Error forcing layout calculation:', err);
      }
      
      return false;
    }
  }, true); // Use capture phase to get the error before React

  console.log('DOM safety patches applied');
};

// Apply DOM safety patches before mounting React
applyDOMSafetyPatches();

// Create root with error handling
const createRoot = () => {
  try {
    const rootElement = document.getElementById('root');
    if (!rootElement) {
      console.error('Root element not found, creating it');
      const newRoot = document.createElement('div');
      newRoot.id = 'root';
      document.body.appendChild(newRoot);
      return ReactDOM.createRoot(newRoot);
    }
    return ReactDOM.createRoot(rootElement);
  } catch (error) {
    console.error('Error creating React root:', error);
    // Create a new root element as fallback
    const fallbackRoot = document.createElement('div');
    fallbackRoot.id = 'fallback-root';
    document.body.appendChild(fallbackRoot);
    return ReactDOM.createRoot(fallbackRoot);
  }
};

// Render app with comprehensive error boundary
const root = createRoot();
root.render(
  <React.StrictMode>
    <ErrorBoundary>
      <LanguageProvider>
        <SubscriptionProvider>
          <App />
        </SubscriptionProvider>
      </LanguageProvider>
    </ErrorBoundary>
  </React.StrictMode>
);