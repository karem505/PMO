export interface Domain {
  id: number;
  name: string;
  description: string;
  icon: string;
}

export interface Task {
  id: string;
  domainId: number;
  domainName: string;
  stage: 'input' | 'processing' | 'output';
  title: string;
  description: string;
  completed: boolean;
  bestPractices: string[];
  templates?: string[];
}

export interface UserData {
  id?: string;
  email?: string;
  displayName?: string;
  photoURL?: string;
  organizationName: string;
  industry: string;
  pmoMaturityLevel: string;
  tasks: Record<string, TaskData>;
  domainInputs: Record<number, DomainInput>;
  generatedOutputs: Record<number, DomainOutput>;
  teams?: string[];
  createdAt?: string;
  updatedAt?: string;
  projects: Project[];
  activeProjectId?: string;
  emailVerified?: boolean;
  role?: 'user' | 'admin' | 'manager';
  isAdmin?: boolean;
  teamCode?: string;
  lastLogin?: string;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  createdAt: string;
  updatedAt: string;
  startDate: string;
  endDate: string;
  budget: number;
  budgetSpent: number;
  keyObjectives: string[];
  owner_id: string;
  user_id: string;
  stakeholders: { name: string; role: string }[];
  risks: { description: string; severity: string; mitigation: string }[];
  email?: string;
  domainData?: {
    tasks?: Record<string, TaskData>;
    domainInputs?: Record<number, DomainInput>;
    generatedOutputs?: Record<number, DomainOutput>;
  };
  sharedWith?: string[];
  ownerId?: string;
  permissions?: ProjectPermission[];
  is_default?: boolean;
}

export interface ProjectPermission {
  userId: string;
  role: 'viewer' | 'editor' | 'admin';
  grantedBy: string;
  grantedAt: string;
}

export interface ProjectDetails {
  name: string;
  startDate: string;
  endDate: string;
  budget: number;
  budgetSpent: number;
  keyObjectives: string[];
  stakeholders: { name: string; role: string }[];
  risks: { description: string; severity: string; mitigation: string }[];
}

export interface DomainInput {
  content: string;
  lastUpdated: string;
}

export interface DomainOutput {
  content: string;
  generatedDate: string;
  templates: GeneratedTemplate[];
}

export interface GeneratedTemplate {
  name: string;
  content: string;
}

export interface TaskData {
  completed: boolean;
  notes: string;
  attachments: string[];
  customFields: Record<string, any>;
  acceptanceStatus?: 'accepted' | 'needs-refinement' | 'rejected';
  acceptanceTimestamp?: string;
  versionHistory?: TaskOutputVersion[];
}

export interface TaskOutputVersion {
  content: string;
  timestamp: string;
  status: 'draft' | 'accepted' | 'rejected';
  comments?: string;
}

export interface DomainProgress {
  inputProgress: number;
  processingProgress: number;
  outputProgress: number;
  overallProgress: number;
}

export interface TeamCollaboration {
  id: string;
  name: string;
  description: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  members: string[];
  admins: string[];
  sharedProjects?: string[];
  teamCode?: string;
}

export interface TeamInvitation {
  id: string;
  teamId: string;
  invitedBy: string;
  invitedEmail: string;
  status: 'pending' | 'accepted' | 'rejected';
  createdAt: string;
  acceptedBy?: string;
  acceptedAt?: string;
  rejectedBy?: string;
  rejectedAt?: string;
}

export interface CollaborationPermission {
  userId: string;
  projectId: string;
  teamId?: string;
  permissionLevel: 'view' | 'edit' | 'admin';
  createdAt: string;
  updatedAt: string;
}

export interface SharedProject {
  id: string;
  originalOwnerId: string;
  name: string;
  description: string;
  sharedWithTeams: string[];
  sharedWithUsers: string[];
  createdAt: string;
  updatedAt: string;
}

export interface DocumentChunk {
  id: string;
  documentId: string;
  content: string;
  metadata: {
    chunkIndex: number;
    charStart: number;
    charEnd: number;
    tokenCount?: number;
    pageNumber?: number;
    source?: string;
    title?: string;
    domainId?: number;
  };
}

export interface ProcessedDocument {
  id: string;
  fileName: string;
  fileType: string;
  chunks: DocumentChunk[];
  totalChunks: number;
  createdAt: string;
  updatedAt: string;
  domainId?: number;
  projectId?: string;
  userId?: string;
  metadata?: Record<string, any>;
}

export interface MaturityLevel {
  value: string;
  label: string;
  description: string;
}

export interface MaturityAssessment {
  id: string;
  userId: string;
  projectId: string;
  overallMaturity: string;
  domainMaturity: Record<number, string>;
  strengths: string[];
  weaknesses: string[];
  recommendations: string[];
  report: string;
  createdAt: string;
  assessmentType: 'manual' | 'ai';
}

// Role-based access control types
export interface UserRole {
  id: string;
  name: string;
  description: string;
}

export interface Permission {
  id: string;
  name: string;
  description: string;
  resourceType: string | null;
  resourceId: string | null;
}

export type PermissionAction = 'create' | 'read' | 'update' | 'delete' | 'admin';
export type ResourceType = 'project' | 'document' | 'team' | 'assessment' | 'template' | 'task';

export interface RolePermission {
  roleId: string;
  permissionId: string;
  resourceType?: string;
}

export interface AccessPolicy {
  id: string;
  name: string;
  description: string;
  conditions: {
    roles?: string[];
    permissions?: string[];
    resourceTypes?: string[];
  };
  rules: {
    allow: boolean;
    actions: string[];
    resources: string[];
    conditions?: Record<string, any>;
  }[];
}

export interface TaskAttachment {
  id: string;
  name: string;
  url: string;
  size?: number; 
  type?: string;
  uploadDate?: string;
}