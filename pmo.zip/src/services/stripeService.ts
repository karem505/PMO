import { loadStripe } from '@stripe/stripe-js';
import { supabase } from './supabaseClient';
import { SubscriptionTier } from './subscriptionService';

// Stripe public key
const stripePublicKey = import.meta.env.VITE_STRIPE_PUBLIC_KEY || 'pk_test_51O9wDbItw5UE1Ij2HyXfZlBsJI8GQsvZlCQhOAkACYeUcBgDVuJrNATrfMqGxr2dUADsY4JQ1qfxCkGsI7VwARwk00yFnTlv1X';

// Check if we're in production and not using HTTPS
const isProduction = import.meta.env.PROD;
const isSecure = window.location.protocol === 'https:';

if (isProduction && !isSecure) {
  console.warn('Stripe.js integration is running over HTTP in production. Please use HTTPS for live integrations.');
}

// Stripe product IDs (these would be configured in your Stripe dashboard)
export const STRIPE_PRODUCT_IDS = {
  [SubscriptionTier.PREMIUM]: {
    monthly: 'price_1O9wDbItw5UE1Ij2Z0RcCNqp',
    annual: 'price_1O9wDbItw5UE1Ij2ghYPrLk8'
  },
  [SubscriptionTier.ENTERPRISE]: {
    monthly: 'price_1O9wDbItw5UE1Ij2mXW3O46f',
    annual: 'price_1O9wDbItw5UE1Ij2A6GTBiK9'
  }
};

class StripeService {
  private stripePromise: Promise<any>;
  
  constructor() {
    // Only load Stripe in production if we're using HTTPS
    if (isProduction && !isSecure) {
      console.warn('Stripe.js will not be loaded in production without HTTPS');
      this.stripePromise = Promise.reject(new Error('Stripe.js requires HTTPS in production'));
    } else {
    this.stripePromise = loadStripe(stripePublicKey);
    }
  }
  
  /**
   * Create a checkout session for subscription
   */
  async createCheckoutSession(
    userId: string,
    tier: SubscriptionTier,
    billingPeriod: 'monthly' | 'annual',
    successUrl: string,
    cancelUrl: string
  ): Promise<{ sessionId: string | null; error: string | null }> {
    try {
      // Get price ID
      const priceId = STRIPE_PRODUCT_IDS[tier][billingPeriod];
      
      if (!priceId) {
        return { sessionId: null, error: 'Invalid subscription tier or billing period' };
      }
      
      // Call our Supabase Edge Function to create a checkout session
      const { data, error } = await supabase.functions.invoke('create-checkout-session', {
        body: {
          userId,
          priceId,
          successUrl,
          cancelUrl
        }
      });
      
      if (error) {
        console.error('Error creating checkout session:', error);
        return { sessionId: null, error: error.message || 'Error creating checkout session' };
      }
      
      return { sessionId: data.sessionId, error: null };
    } catch (error: any) {
      console.error('Error in createCheckoutSession:', error);
      return { sessionId: null, error: error.message || 'Unknown error creating checkout session' };
    }
  }
  
  /**
   * Redirect to Stripe checkout
   */
  async redirectToCheckout(sessionId: string): Promise<{ success: boolean; error: string | null }> {
    try {
      // Get Stripe instance
      const stripe = await this.stripePromise;
      
      // Redirect to checkout
      const { error } = await stripe.redirectToCheckout({ sessionId });
      
      if (error) {
        console.error('Error redirecting to checkout:', error);
        return { success: false, error: error.message || 'Error redirecting to checkout' };
      }
      
      return { success: true, error: null };
    } catch (error: any) {
      console.error('Error in redirectToCheckout:', error);
      return { success: false, error: error.message || 'Unknown error redirecting to checkout' };
    }
  }
  
  /**
   * Create a customer portal session for managing subscriptions
   */
  async createCustomerPortalSession(
    userId: string,
    returnUrl: string
  ): Promise<{ url: string | null; error: string | null }> {
    try {
      // Call our Supabase Edge Function to create a customer portal session
      const { data, error } = await supabase.functions.invoke('create-customer-portal', {
        body: {
          userId,
          returnUrl
        }
      });
      
      if (error) {
        console.error('Error creating customer portal session:', error);
        return { url: null, error: error.message || 'Error creating customer portal session' };
      }
      
      return { url: data.url, error: null };
    } catch (error: any) {
      console.error('Error in createCustomerPortalSession:', error);
      return { url: null, error: error.message || 'Unknown error creating customer portal session' };
    }
  }
  
  /**
   * Redirect to Stripe customer portal
   */
  async redirectToCustomerPortal(url: string): Promise<{ success: boolean; error: string | null }> {
    try {
      // Redirect to customer portal
      window.location.href = url;
      return { success: true, error: null };
    } catch (error: any) {
      console.error('Error redirecting to customer portal:', error);
      return { success: false, error: error.message || 'Error redirecting to customer portal' };
    }
  }
}

export const stripeService = new StripeService();