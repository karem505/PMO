import { Task, DocumentChunk } from '../types';
import { domains } from '../data';
import { hashString } from '../utils/documentUtils';
import { documentProcessingService } from './documentProcessingService';
import OpenAI from 'openai';
import pRetry from 'p-retry';

/**
 * Service for generating and managing AI prompts for tasks
 */
class TaskPromptService {
  private openai: OpenAI | null = null;
  private initialized: boolean = false;
  private memoryCache: Map<string, any> = new Map();
  private cacheTTL: number = 24 * 60 * 60 * 1000; // 24 hours
  private apiKey: string = '';

  constructor() {
    this.apiKey = import.meta.env.VITE_OPENAI_API_KEY;
    if (!this.apiKey) {
      console.warn('OpenAI API key is missing. Dynamic task prompts will use fallback templates.');
      return;
    }

    try {
      this.openai = new OpenAI({
        apiKey: this.apiKey,
        dangerouslyAllowBrowser: true
      });
      this.initialized = true;
      console.log('Task Prompt Service initialized successfully');
      
      // Load cache from localStorage
      this.loadCacheFromStorage();
    } catch (error) {
      console.error('Failed to initialize Task Prompt Service:', error);
    }
  }

  /**
   * Load previously cached items from localStorage
   */
  private loadCacheFromStorage(): void {
    try {
      const cacheKeys = Object.keys(localStorage).filter(key => key.startsWith('task-prompt-'));
      
      for (const key of cacheKeys) {
        try {
          const item = localStorage.getItem(key);
          if (item) {
            const parsed = JSON.parse(item);
            if (parsed.expiry && parsed.data) {
              if (parsed.expiry > Date.now()) {
                const cacheKey = key.replace('task-prompt-', '');
                this.memoryCache.set(cacheKey, parsed.data);
              } else {
                localStorage.removeItem(key);
              }
            }
          }
        } catch (e) {
          console.warn('Error parsing cached prompt:', e);
        }
      }
      console.log(`[Cache] Loaded ${this.memoryCache.size} task prompts from localStorage`);
    } catch (error) {
      console.warn('Error loading task prompt cache from localStorage:', error);
    }
  }

  /**
   * Generate a dynamic prompt for a specific task
   */
  async generateTaskPrompt(
    task: Task, 
    userInput: string = '',
    projectId?: string
  ): Promise<string> {
    console.log("[TaskPrompt] Generating prompt for task:", task.id);
    
    // Generate cache key 
    const cacheKey = this.generateCacheKey(task.id, userInput);
    
    // Check cache first
    const cachedPrompt = this.getCachedPrompt(cacheKey);
    if (cachedPrompt) {
      console.log("[TaskPrompt] Using cached prompt for task:", task.id);
      return cachedPrompt;
    }

    // If not initialized, return fallback prompt
    if (!this.initialized || !this.openai) {
      const fallbackPrompt = this.generateFallbackPrompt(task);
      this.setCachedPrompt(cacheKey, fallbackPrompt);
      return fallbackPrompt;
    }
    
    try {
      // Get domain info
      const domain = domains.find(d => d.id === task.domainId);
      if (!domain) {
        throw new Error(`Domain ${task.domainId} not found`);
      }

      // Get relevant documents if projectId is provided
      let relevantChunks: DocumentChunk[] = [];
      if (projectId) {
        try {
          // Get document chunks relevant to this task
          relevantChunks = await documentProcessingService.getRelevantChunks(
            `${task.title} ${task.description}`,
            projectId,
            3, // Limit to 3 most relevant chunks
            task.domainId
          );
        } catch (error) {
          console.warn('Error fetching document chunks for task prompt:', error);
          // Continue without document chunks
        }
      }
      
      // Create a more dynamic prompt based on task characteristics
      let prompt = await this.createDynamicPrompt(task, domain.name, userInput, relevantChunks);
      
      // Cache the generated prompt
      this.setCachedPrompt(cacheKey, prompt);
      
      return prompt;
    } catch (error) {
      console.error('Error generating dynamic task prompt:', error);
      
      // Use fallback in case of error
      const fallbackPrompt = this.generateFallbackPrompt(task);
      this.setCachedPrompt(cacheKey, fallbackPrompt);
      return fallbackPrompt;
    }
  }
  
  /**
   * Create a dynamic prompt for a task using AI
   */
  private async createDynamicPrompt(
    task: Task,
    domainName: string,
    userInput: string,
    relevantChunks: DocumentChunk[] = []
  ): Promise<string> {
    if (!this.openai) {
      throw new Error('OpenAI client not initialized');
    }
    
    // Create a system message that instructs the AI on how to create a prompt
    const systemMessage = `
You are an expert at creating prompts for an AI assistant. Your job is to create a detailed, targeted prompt
for generating content related to a PMO (Project Management Office) task.

The prompt should be specific to the task domain, stage, and description provided. It should guide the AI
to create actionable, practical content that is appropriate for the specific task.

Follow these guidelines:
1. Focus on the specific task at hand, not general information
2. Include specific elements that should be in the output
3. Specify the format (headings, sections, lists, etc.)
4. Be clear about the expertise level and tone required
5. Include relevant context from the provided information

Respond ONLY with the prompt itself, no meta-commentary or explanations.
`;

    // Create document context from relevant chunks
    const documentContext = relevantChunks.length > 0
      ? relevantChunks.map(chunk => 
          `From document: ${chunk.metadata.source || 'document'}: ${chunk.content.substring(0, 200)}...`
        ).join("\n\n")
      : "No specific document references available.";

    // Determine specific content based on task stage
    const stageSpecificGuidance = this.getStageSpecificGuidance(task.stage);

    // Retry with exponential backoff
    return pRetry(async () => {
      try {
        const completion = await this.openai!.chat.completions.create({
          model: "gpt-3.5-turbo", // Use the faster model
          messages: [
            { role: "system", content: systemMessage },
            { 
              role: "user", 
              content: `
Create a prompt for generating content about:

TASK: ${task.title}
DESCRIPTION: ${task.description}
DOMAIN: ${domainName}
STAGE: ${task.stage} (${stageSpecificGuidance})

BEST PRACTICES CONTEXT:
${task.bestPractices?.join("\n") || "No specific best practices provided."}

DOCUMENT CONTEXT:
${documentContext}

USER INPUT (if any):
${userInput || "No specific user input provided."}

Create an effective prompt for an AI to generate content for this specific task.
`
            }
          ],
          temperature: 0.1, // Low temperature for consistency
          max_tokens: 500 // Limit token usage
        });

        const promptContent = completion.choices[0]?.message?.content;
        if (!promptContent) {
          throw new Error('Empty response from OpenAI');
        }
        
        return promptContent;
      } catch (error) {
        console.error('Error in createDynamicPrompt:', error);
        throw error; // This will trigger a retry if it's a transient error
      }
    }, {
      retries: 2,
      onFailedAttempt: (error) => {
        console.warn(`Attempt failed: ${error.message}. Retries left: ${error.retriesLeft}`);
      }
    });
  }
  
  /**
   * Get stage-specific guidance based on the task stage
   */
  private getStageSpecificGuidance(stage: string): string {
    switch (stage) {
      case 'input':
        return "Input stage involves gathering data, assessment, and information collection. Content should focus on methods for effective data collection, assessment frameworks, and information gathering techniques.";
      case 'processing':
        return "Processing stage involves analysis, application of tools and techniques, and developing frameworks. Content should focus on analytical methods, tool application, and framework development.";
      case 'output':
        return "Output stage involves producing deliverables, implementing solutions, and establishing frameworks. Content should focus on creating actionable deliverables, implementation approaches, and operational frameworks.";
      default:
        return "Focus on creating practical, actionable guidance appropriate for PMO implementation.";
    }
  }

  /**
   * Generate a cache key for a task prompt
   */
  private generateCacheKey(taskId: string, userInput: string): string {
    const inputHash = userInput ? hashString(userInput.substring(0, 100)) : 'none';
    return `${taskId}-${inputHash}`;
  }

  /**
   * Get a cached prompt
   */
  private getCachedPrompt(key: string): string | null {
    // Check memory cache first
    if (this.memoryCache.has(key)) {
      return this.memoryCache.get(key);
    }
    
    // Then check localStorage
    try {
      const cachedData = localStorage.getItem(`task-prompt-${key}`);
      if (cachedData) {
        const parsed = JSON.parse(cachedData);
        if (parsed.expiry && parsed.expiry > Date.now()) {
          // Also store in memory for faster access next time
          this.memoryCache.set(key, parsed.data);
          return parsed.data;
        } else {
          // Remove expired item
          localStorage.removeItem(`task-prompt-${key}`);
        }
      }
    } catch (error) {
      console.warn('Error reading cached task prompt:', error);
    }
    
    return null;
  }

  /**
   * Store a prompt in the cache
   */
  private setCachedPrompt(key: string, value: string): void {
    try {
      // Store in memory
      this.memoryCache.set(key, value);
      
      // Store in localStorage
      const expiryTime = Date.now() + this.cacheTTL;
      localStorage.setItem(`task-prompt-${key}`, JSON.stringify({
        data: value,
        expiry: expiryTime
      }));
    } catch (error) {
      console.warn('Error caching task prompt:', error);
    }
  }

  /**
   * Generate a fallback prompt for a task
   */
  private generateFallbackPrompt(task: Task): string {
    const domain = domains.find(d => d.id === task.domainId);
    const domainName = domain ? domain.name : 'PMO';
    
    // Dynamic template based on task stage
    let stageTemplate = '';
    switch (task.stage) {
      case 'input':
        stageTemplate = `
This should include:
1. Assessment frameworks and methodologies
2. Data collection techniques and templates
3. Information gathering best practices
4. Stakeholder interview structures
5. Documentation formats for current state analysis
`;
        break;
      case 'processing':
        stageTemplate = `
This should include:
1. Analysis methodologies and frameworks
2. Tools and techniques for processing information
3. Development approaches for creating frameworks
4. Methods for synthesizing gathered information
5. Techniques for identifying patterns and insights
`;
        break;
      case 'output':
        stageTemplate = `
This should include:
1. Implementation roadmap and approach
2. Deliverable templates and examples
3. Framework documentation standards
4. Monitoring and control mechanisms
5. Success metrics and evaluation criteria
`;
        break;
      default:
        stageTemplate = `
This should include:
1. Practical implementation guidelines
2. Best practices and standards
3. Measurement and evaluation approaches
4. Continuous improvement mechanisms
5. Templates and examples where appropriate
`;
    }

    // Create a fallback prompt incorporating task specifics
    return `
You are an expert PMO consultant specializing in ${domainName}. Please create a comprehensive guide for:

TASK: ${task.title}
DESCRIPTION: ${task.description}

${stageTemplate}

INCORPORATE THESE BEST PRACTICES:
${task.bestPractices?.map(bp => `- ${bp}`).join('\n') || 'Follow industry-standard best practices'}

Format your response using markdown with clear headings, bullet points, and numbered lists where appropriate.
Focus on practical, actionable guidance that a PMO professional could implement immediately.
Include examples and templates where helpful.
`;
  }
}

// Export a singleton instance
export const taskPromptService = new TaskPromptService();