import { SourceValidationResult } from './externalSourceService';
import { externalSourceService } from './externalSourceService';
import { DocumentChunk } from '../types';

/**
 * Service for enhancing AI outputs with external source validation
 */
class AIValidationService {
  private validationResults = new Map<string, SourceValidationResult>();
  private validationCache = new Map<string, {result: SourceValidationResult, timestamp: number}>();
  private cacheTTL = 24 * 60 * 60 * 1000; // 24 hours
  
  constructor() {
    // Try to load cached validations from localStorage
    this.loadValidationCache();
  }
  
  /**
   * Load cached validations from localStorage
   */
  private loadValidationCache() {
    try {
      const cachedItems = Object.keys(localStorage)
        .filter(key => key.startsWith('validation:'));
      
      for (const key of cachedItems) {
        const data = localStorage.getItem(key);
        if (data) {
          const parsed = JSON.parse(data);
          if (parsed.result && parsed.timestamp) {
            // Only load if not expired
            if (Date.now() - parsed.timestamp < this.cacheTTL) {
              const cacheKey = key.replace('validation:', '');
              this.validationCache.set(cacheKey, parsed);
            } else {
              // Clean up expired items
              localStorage.removeItem(key);
            }
          }
        }
      }
      
      console.log(`Loaded ${this.validationCache.size} cached validations`);
    } catch (error) {
      console.warn('Error loading validation cache:', error);
    }
  }
  
  /**
   * Validate AI-generated content with external sources
   */
  async validateContent(
    content: string,
    domain: string,
    options: {
      strictness?: 'low' | 'medium' | 'high',
      includeCorrections?: boolean,
      cacheResults?: boolean,
      autoApplyCorrections?: boolean
    } = {}
  ): Promise<{
    validatedContent: string;
    validationResult: SourceValidationResult;
    corrected: boolean;
  }> {
    // Default options
    const {
      strictness = 'medium',
      includeCorrections = true,
      cacheResults = true,
      autoApplyCorrections = false
    } = options;
    
    // Generate cache key
    const contentHash = this.hashString(content.substring(0, 500));
    const cacheKey = `${contentHash}:${domain}:${strictness}`;
    
    // Check cache first
    let validationResult: SourceValidationResult;
    if (this.validationCache.has(cacheKey)) {
      console.log('Using cached validation result');
      validationResult = this.validationCache.get(cacheKey)!.result;
    } else {
      // Perform validation
      validationResult = await externalSourceService.validateContent(
        content, 
        domain, 
        { 
          strictness, 
          includeCorrections 
        }
      );
      
      // Cache result if requested
      if (cacheResults) {
        const cacheItem = {
          result: validationResult,
          timestamp: Date.now()
        };
        
        this.validationCache.set(cacheKey, cacheItem);
        
        // Also cache in localStorage for persistence
        try {
          localStorage.setItem(`validation:${cacheKey}`, JSON.stringify(cacheItem));
        } catch (error) {
          console.warn('Error caching validation result:', error);
        }
      }
    }
    
    // Store the result for later reference
    this.validationResults.set(content, validationResult);
    
    // Apply corrections if requested and available
    let correctedContent = content;
    let corrected = false;
    
    if (autoApplyCorrections && 
        validationResult.suggestedCorrections && 
        validationResult.suggestedCorrections.length > 0) {
      
      correctedContent = this.applySuggestedCorrections(
        content, 
        validationResult.suggestedCorrections
      );
      
      corrected = correctedContent !== content;
    }
    
    return {
      validatedContent: correctedContent,
      validationResult,
      corrected
    };
  }
  
  /**
   * Apply suggested corrections to content
   */
  private applySuggestedCorrections(
    content: string,
    corrections: { original: string; correction: string; explanation: string }[]
  ): string {
    let correctedContent = content;
    
    for (const correction of corrections) {
      // Use simple string replacement - in real implementation
      // would need more sophisticated text processing
      correctedContent = correctedContent.replace(
        correction.original,
        correction.correction
      );
    }
    
    return correctedContent;
  }
  
  /**
   * Enhanced AI analysis with external source validation and augmentation
   * 
   * @param analysisContent - The original AI-generated analysis content
   * @param domain - The domain name/topic
   * @param documentChunks - Supporting document chunks to enhance analysis
   * @returns Validated and enhanced analysis content
   */
  async enhanceAnalysisWithExternalSources(
    analysisContent: string,
    domain: string,
    documentChunks: DocumentChunk[] = []
  ): Promise<{
    enhancedContent: string;
    validationResult: SourceValidationResult;
    externalSourcesAdded: boolean;
  }> {
    // Validate the analysis first
    const { 
      validatedContent, 
      validationResult, 
      corrected 
    } = await this.validateContent(
      analysisContent, 
      domain, 
      { autoApplyCorrections: true }
    );
    
    // Crawl external sources for additional information
    const { sources, error } = await externalSourceService.crawlExternalSources(
      domain,
      { maxSources: 3, freshness: 'recent' }
    );
    
    // Enhance content with external sources if available
    let enhancedContent = validatedContent;
    let externalSourcesAdded = false;
    
    if (sources && sources.length > 0 && !error) {
      const sourcesSection = this.formatExternalSources(sources, domain);
      
      // Check if content already has a references section
      if ((/references|bibliography|sources/i).test(enhancedContent)) {
        // Try to append to existing section
        enhancedContent = enhancedContent.replace(
          /(?:references|bibliography|sources)(?:\s*)?(?:\:|\n)/i,
          (match) => `${match}\n\n${sourcesSection}`
        );
      } else {
        // Add new references section
        enhancedContent += `\n\n## External References & Further Reading\n\n${sourcesSection}`;
      }
      
      externalSourcesAdded = true;
    }
    
    return {
      enhancedContent,
      validationResult,
      externalSourcesAdded
    };
  }
  
  /**
   * Format external sources into a readable reference list
   */
  private formatExternalSources(
    sources: { name: string; url: string; content: string; relevance: number }[],
    topic: string
  ): string {
    // Format sources as readable references
    return sources.map((source, index) => {
      // Extract a relevant quote from the content (first 100 chars)
      const snippet = source.content.substring(0, 150) + '...';
      
      return `### ${index + 1}. ${source.name}\n\n` +
             `"${snippet}"\n\n` +
             `[Read more about ${topic} at ${source.name}](${source.url})\n`;
    }).join('\n\n');
  }
  
  /**
   * Get validation result for previously validated content
   */
  getValidationResult(content: string): SourceValidationResult | null {
    return this.validationResults.get(content) || null;
  }
  
  /**
   * Clear validation cache
   */
  clearCache(): void {
    this.validationResults.clear();
    this.validationCache.clear();
    
    // Also clear localStorage
    try {
      const keys = Object.keys(localStorage)
        .filter(key => key.startsWith('validation:'));
        
      for (const key of keys) {
        localStorage.removeItem(key);
      }
      
      console.log(`Cleared ${keys.length} cached validations`);
    } catch (error) {
      console.warn('Error clearing validation cache from localStorage:', error);
    }
  }
  
  /**
   * Simple string hashing function
   */
  private hashString(str: string): string {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32bit integer
    }
    return Math.abs(hash).toString(36);
  }
}

// Export singleton instance
export const aiValidationService = new AIValidationService();