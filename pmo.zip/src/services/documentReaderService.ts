import axios from 'axios';

interface DocumentContent {
  filename: string;
  file_type: string;
  content: string;
  tables: any[];
  metadata: Record<string, any>;
}

const API_URL = import.meta.env.VITE_API_BASE_URL || 'https://pmo-mvp-fe.onrender.com';

export const documentReaderService = {
  async readDocument(file: File): Promise<DocumentContent> {
    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await axios.post<DocumentContent>(
        `${API_URL}/api/v1/read-document`,
        formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        }
      );
      return response.data;
    } catch (error) {
      console.error('Error reading document:', error);
      throw error;
    }
  }
}; 