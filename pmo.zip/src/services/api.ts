import axios from 'axios';

// إنشاء نسخة من Axios مع التكوين المناسب
const api = axios.create({
  // استخدم قيمة متغير البيئة أو استخدم القيمة الافتراضية
  baseURL: import.meta.env.VITE_API_BASE_URL || 'https://pmo-mvp-fe.onrender.com',
  headers: {
    'Content-Type': 'application/json',
  }
});

// اعتراض الطلبات لإضافة رمز التفويض إذا كان المستخدم مسجل الدخول
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('auth_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

export default api; 