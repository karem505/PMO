import { supabase } from './supabaseClient';
import { validateData, taskSchema, domainInputSchema, domainOutputSchema, projectSchema } from './schemaValidationService';

// Performance monitoring constants
const QUERY_TIMEOUT = 10000; // 10 seconds
const SLOW_QUERY_THRESHOLD = 1000; // 1 second
const LOG_PERFORMANCE = true;

/**
 * Service for database query optimization and performance monitoring
 */
class DatabaseOptimizationService {
  // Track slow queries for analysis
  private slowQueries: Map<string, { count: number, totalTime: number, lastTime: number }> = new Map();
  
  // Retry configurations
  private maxRetries = 3;
  private retryDelay = 500; // ms
  
  // Query caching
  private queryCache: Map<string, { data: any, timestamp: number }> = new Map();
  private cacheTTL = 60 * 1000; // 1 minute
  
  // Cache statistics
  private cacheHits = 0;
  private cacheMisses = 0;
  
  constructor() {
    // Initialize and prepare indexes if needed
    this.initialize();
  }
  
  /**
   * Initialize the service
   */
  private async initialize() {
    console.log('Database optimization service initialized');
    
    // Clean the query cache periodically
    setInterval(() => this.cleanCache(), 5 * 60 * 1000); // Every 5 minutes
  }
  
  /**
   * Clean expired entries from query cache
   */
  private cleanCache() {
    const now = Date.now();
    let expiredCount = 0;
    
    for (const [key, value] of this.queryCache.entries()) {
      if (now - value.timestamp > this.cacheTTL) {
        this.queryCache.delete(key);
        expiredCount++;
      }
    }
    
    console.log(`[DB Optimization] Cleaned ${expiredCount} expired cache entries. Current cache size: ${this.queryCache.size}`);
    
    // Log cache statistics
    const hitRate = this.cacheHits + this.cacheMisses > 0 
      ? (this.cacheHits / (this.cacheHits + this.cacheMisses) * 100).toFixed(1)
      : '0';
      
    console.log(`[DB Performance] Cache hit rate: ${hitRate}% (${this.cacheHits} hits, ${this.cacheMisses} misses)`);
    
    // Reset statistics periodically
    if (this.cacheHits + this.cacheMisses > 1000) {
      this.cacheHits = 0;
      this.cacheMisses = 0;
    }
  }
  
  /**
   * Safely create a project with validation and optimized queries
   */
  async createProject(projectData: any, userId: string): Promise<any> {
    // Validate project data
    const validation = validateData(projectSchema, {
      ...projectData,
      owner_id: userId
    });
    
    if (!validation.success || !validation.data) {
      throw new Error(`Invalid project data: ${validation.error}`);
    }
    
    return this.executeWithRetry(async () => {
      // Log query start time
      const startTime = performance.now();
      
      // Create the project with validated data
      const { data, error } = await supabase
        .from('projects')
        .insert([validation.data])
        .select()
        .single();
        
      // Log query performance
      this.logQueryPerformance('createProject', performance.now() - startTime);
        
      if (error) throw error;
      return data;
    });
  }
  
  /**
   * Safely update a project with validation and optimized queries
   */
  async updateProject(projectId: string, projectData: any): Promise<any> {
    // Partial validation since we're updating
    const validation = validateData(projectSchema.partial(), {
      ...projectData,
      updated_at: new Date().toISOString()
    });
    
    if (!validation.success || !validation.data) {
      throw new Error(`Invalid project update: ${validation.error}`);
    }
    
    return this.executeWithRetry(async () => {
      const startTime = performance.now();
      
      const { data, error } = await supabase
        .from('projects')
        .update(validation.data)
        .eq('id', projectId)
        .select()
        .single();
        
      this.logQueryPerformance('updateProject', performance.now() - startTime);
        
      if (error) throw error;
      return data;
    });
  }
  
  /**
   * Optimize getting domain inputs with caching
   */
  async getDomainInputs(projectId: string): Promise<any[]> {
    // Create a cache key
    const cacheKey = `domainInputs:${projectId}`;
    
    // Check cache first
    const cached = this.getCachedQuery(cacheKey);
    if (cached) return cached;
    
    return this.executeWithRetry(async () => {
      const startTime = performance.now();
      
      const { data, error } = await supabase
        .from('domain_inputs')
        .select('*')
        .eq('project_id', projectId)
        .order('domain_id', { ascending: true });
        
      this.logQueryPerformance('getDomainInputs', performance.now() - startTime);
        
      if (error) throw error;
      
      // Cache the result
      this.setCachedQuery(cacheKey, data || []);
      
      return data || [];
    });
  }
  
  /**
   * Optimize saving domain input with validation
   */
  async saveDomainInput(inputData: any): Promise<any> {
    // Validate input data
    const validation = validateData(domainInputSchema, inputData);
    
    if (!validation.success || !validation.data) {
      throw new Error(`Invalid domain input: ${validation.error}`);
    }
    
    // Need to check if the input exists first
    return this.executeWithRetry(async () => {
      // Check if input already exists
      const startTime = performance.now();
      
      const { data: existingData, error: checkError } = await supabase
        .from('domain_inputs')
        .select('id')
        .eq('project_id', inputData.project_id)
        .eq('domain_id', inputData.domain_id)
        .maybeSingle();
        
      this.logQueryPerformance('checkDomainInput', performance.now() - startTime);
        
      if (checkError) throw checkError;
      
      if (existingData) {
        // Update existing record
        const updateTime = performance.now();
        
        const { data, error } = await supabase
          .from('domain_inputs')
          .update({
            content: validation.data.content,
            last_updated: validation.data.last_updated,
            updated_by: validation.data.updated_by
          })
          .eq('id', existingData.id)
          .select()
          .single();
          
        this.logQueryPerformance('updateDomainInput', performance.now() - updateTime);
          
        if (error) throw error;
        
        // Invalidate related cache entries
        this.invalidateCacheEntry(`domainInputs:${inputData.project_id}`);
        this.invalidateCacheEntry(`domainInput:${inputData.project_id}:${inputData.domain_id}`);
        
        return data;
      } else {
        // Create new record
        const insertTime = performance.now();
        
        const { data, error } = await supabase
          .from('domain_inputs')
          .insert([validation.data])
          .select()
          .single();
          
        this.logQueryPerformance('insertDomainInput', performance.now() - insertTime);
          
        if (error) throw error;
        
        // Invalidate related cache entries
        this.invalidateCacheEntry(`domainInputs:${inputData.project_id}`);
        
        return data;
      }
    });
  }
  
  /**
   * Save domain output with optimized queries and validation
   */
  async saveDomainOutput(outputData: any, templates: any[] = []): Promise<any> {
    // Validate output data
    const validation = validateData(domainOutputSchema, outputData);
    
    if (!validation.success || !validation.data) {
      throw new Error(`Invalid domain output: ${validation.error}`);
    }
    
    return this.executeWithRetry(async () => {
      // First, save the domain output
      const startTime = performance.now();
      
      const { data: outputResult, error: outputError } = await supabase
        .from('domain_outputs')
        .upsert([validation.data], {
          onConflict: 'project_id,domain_id',
          ignoreDuplicates: false
        })
        .select()
        .single();
        
      this.logQueryPerformance('saveDomainOutput', performance.now() - startTime);
        
      if (outputError) throw outputError;
      
      // If there are templates and we have a valid output, save them
      if (templates.length > 0 && outputResult) {
        // Batch process templates for better performance
        await this.saveTemplatesBatch(outputResult.id, templates);
      }
      
      return outputResult;
    });
  }
  
  /**
   * Optimize template saving with batching
   */
  private async saveTemplatesBatch(domainOutputId: string, templates: any[]): Promise<void> {
    // First, remove any existing templates
    const deleteTime = performance.now();
    
    const { error: deleteError } = await supabase
      .from('templates')
      .delete()
      .eq('domain_output_id', domainOutputId);
      
    this.logQueryPerformance('deleteTemplates', performance.now() - deleteTime);
    
    if (deleteError) throw deleteError;
    
    // Prepare template data with output ID
    const templatesWithOutputId = templates.map(template => ({
      domain_output_id: domainOutputId,
      name: template.name,
      content: template.content
    }));
    
    // Split into batches if there are many templates
    const BATCH_SIZE = 5;
    for (let i = 0; i < templatesWithOutputId.length; i += BATCH_SIZE) {
      const batch = templatesWithOutputId.slice(i, i + BATCH_SIZE);
      
      // Insert batch
      const insertTime = performance.now();
      
      const { error: templateError } = await supabase
        .from('templates')
        .insert(batch);
        
      this.logQueryPerformance('insertTemplateBatch', performance.now() - insertTime);
      
      if (templateError) throw templateError;
    }
  }
  
  /**
   * Save task data with optimized queries and validation
   */
  async saveTask(taskData: any): Promise<any> {
    // Validate task data
    const validation = validateData(taskSchema, taskData);
    
    if (!validation.success || !validation.data) {
      throw new Error(`Invalid task data: ${validation.error}`);
    }
    
    return this.executeWithRetry(async () => {
      // First check if task already exists
      const checkTime = performance.now();
      
      const { data: existingData, error: checkError } = await supabase
        .from('tasks')
        .select('id')
        .eq('project_id', taskData.project_id)
        .eq('task_id', taskData.task_id)
        .maybeSingle();
        
      this.logQueryPerformance('checkTaskExists', performance.now() - checkTime);
      
      if (checkError) throw checkError;
      
      if (existingData) {
        // Update existing task
        const updateTime = performance.now();
        
        const { data, error } = await supabase
          .from('tasks')
          .update({
            completed: validation.data.completed,
            notes: validation.data.notes,
            attachments: validation.data.attachments,
            custom_fields: validation.data.custom_fields,
            document_references: validation.data.document_references,
            dependencies: validation.data.dependencies,
            updated_at: validation.data.updated_at,
            updated_by: validation.data.updated_by
          })
          .eq('id', existingData.id)
          .select()
          .single();
          
        this.logQueryPerformance('updateTask', performance.now() - updateTime);
        
        if (error) throw error;
        return data;
      } else {
        // Insert new task
        const insertTime = performance.now();
        
        const { data, error } = await supabase
          .from('tasks')
          .insert([validation.data])
          .select()
          .single();
          
        this.logQueryPerformance('insertTask', performance.now() - insertTime);
        
        if (error) throw error;
        return data;
      }
    });
  }
  
  /**
   * Execute a database operation with retry logic
   */
  private async executeWithRetry<T>(operation: () => Promise<T>, retries = this.maxRetries): Promise<T> {
    try {
      // Set a timeout for the operation
      const timeoutPromise = new Promise<never>((_, reject) => {
        setTimeout(() => reject(new Error(`Operation timed out after ${QUERY_TIMEOUT}ms`)), QUERY_TIMEOUT);
      });
      
      // Execute the operation with timeout
      return await Promise.race([operation(), timeoutPromise]) as T;
    } catch (error) {
      // If we have retries left, wait and try again
      if (retries > 0) {
        console.warn(`Database operation failed, retrying... (${retries} attempts left)`, error);
        
        // Wait before retrying with exponential backoff
        await new Promise(resolve => setTimeout(resolve, this.retryDelay * (this.maxRetries - retries + 1)));
        
        return this.executeWithRetry(operation, retries - 1);
      }
      
      // No more retries, throw the error
      console.error('Database operation failed after all retry attempts', error);
      throw error;
    }
  }
  
  /**
   * Log query performance and track slow queries
   */
  private logQueryPerformance(queryName: string, elapsedTime: number): void {
    if (!LOG_PERFORMANCE) return;
    
    // Track as a slow query if it exceeds threshold
    if (elapsedTime > SLOW_QUERY_THRESHOLD) {
      if (this.slowQueries.has(queryName)) {
        const stats = this.slowQueries.get(queryName)!;
        stats.count++;
        stats.totalTime += elapsedTime;
        stats.lastTime = elapsedTime;
      } else {
        this.slowQueries.set(queryName, {
          count: 1,
          totalTime: elapsedTime,
          lastTime: elapsedTime
        });
      }
      
      console.warn(`[DB Performance] Slow query: ${queryName} took ${elapsedTime.toFixed(2)}ms`);
    } else {
      console.log(`[DB Performance] Query: ${queryName} took ${elapsedTime.toFixed(2)}ms`);
    }
  }
  
  /**
   * Get cached query result
   */
  private getCachedQuery(key: string): any | null {
    const cached = this.queryCache.get(key);
    
    if (cached) {
      const now = Date.now();
      
      // Check if cache is still valid
      if (now - cached.timestamp <= this.cacheTTL) {
        this.cacheHits++;
        return cached.data;
      } else {
        // Expired cache
        this.queryCache.delete(key);
      }
    }
    
    this.cacheMisses++;
    return null;
  }
  
  /**
   * Set cached query result
   */
  private setCachedQuery(key: string, data: any): void {
    this.queryCache.set(key, {
      data,
      timestamp: Date.now()
    });
  }
  
  /**
   * Invalidate a specific cache entry
   */
  private invalidateCacheEntry(key: string): void {
    if (this.queryCache.has(key)) {
      this.queryCache.delete(key);
      console.log(`[Cache] Invalidated: ${key}`);
    }
  }
  
  /**
   * Get database performance metrics
   */
  getPerformanceMetrics(): {
    slowQueries: { [key: string]: { count: number, avgTime: number, lastTime: number } };
    cacheStats: { hits: number, misses: number, hitRate: string, cacheSize: number };
  } {
    // Calculate stats for slow queries
    const slowQueryStats: { [key: string]: { count: number, avgTime: number, lastTime: number } } = {};
    
    for (const [queryName, stats] of this.slowQueries.entries()) {
      slowQueryStats[queryName] = {
        count: stats.count,
        avgTime: stats.totalTime / stats.count,
        lastTime: stats.lastTime
      };
    }
    
    // Calculate cache stats
    const totalRequests = this.cacheHits + this.cacheMisses;
    const hitRate = totalRequests > 0
      ? (this.cacheHits / totalRequests * 100).toFixed(1)
      : '0.0';
      
    return {
      slowQueries: slowQueryStats,
      cacheStats: {
        hits: this.cacheHits,
        misses: this.cacheMisses,
        hitRate: `${hitRate}%`,
        cacheSize: this.queryCache.size
      }
    };
  }
}

// Export singleton instance
export const dbOptimizationService = new DatabaseOptimizationService();