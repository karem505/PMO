import { v4 as uuidv4 } from 'uuid';

/**
 * Service for generating and processing diagrams
 */
export const generateDiagramCode = async (
  text: string,
  diagramType: string = 'flowchart'
): Promise<string> => {
  try {
    // Try to use the Gemini API if configured
    const apiKey = import.meta.env.VITE_GEMINI_API_KEY;
    
    if (apiKey) {
      return await generateDiagramWithGemini(text, diagramType, apiKey);
    } else {
      return generateDiagramFallback(text, diagramType);
    }
  } catch (error) {
    console.error('Error generating diagram code:', error);
    return generateDiagramFallback(text, diagramType);
  }
};

const generateDiagramWithGemini = async (
  text: string,
  diagramType: string,
  apiKey: string
): Promise<string> => {
  // Prepare the prompt for Gemini API
  const prompt = `
Generate Mermaid diagram code from the following text description.

TEXT DESCRIPTION:
${text}

DIAGRAM TYPE: ${diagramType}

For this text, create a clear and effective ${diagramType} diagram using Mermaid syntax.

IMPORTANT GUIDELINES:
1. Make sure the generated code is valid Mermaid syntax
2. Include only essentials - focus on key steps, elements, or relationships
3. Use proper formatting and spacing
4. Include meaningful labels and descriptions
5. DO NOT include markdown code blocks or any explanatory text, only the Mermaid code itself

Please analyze the text and respond ONLY with the Mermaid code that represents the process or structure described.
`;

  // Call Gemini API
  const response = await fetch(`https://generativelanguage.googleapis.com/v1/models/gemini-1.5-pro:generateContent?key=${apiKey}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      generationConfig: {
        temperature: 0.2,
        topK: 32,
        topP: 0.95,
        maxOutputTokens: 2048,
      },
    }),
  });

  if (!response.ok) {
    throw new Error(`Failed to generate diagram: ${response.statusText}`);
  }

  const data = await response.json();
  let diagramCode = data?.candidates?.[0]?.content?.parts?.[0]?.text || '';

  // Clean up the response - sometimes it returns with markdown code blocks
  diagramCode = diagramCode.replace(/```mermaid/g, '').replace(/```/g, '').trim();
  
  // If the code doesn't start with the diagram type declaration, add it
  if (!diagramCode.startsWith(diagramType) && !diagramCode.startsWith(`graph`)) {
    if (diagramType === 'flowchart') {
      diagramCode = `graph TD;\n${diagramCode}`;
    } else {
      diagramCode = `${diagramType}\n${diagramCode}`;
    }
  }

  return diagramCode;
};

const generateDiagramFallback = (text: string, diagramType: string): string => {
  // This function creates basic diagrams without AI
  // It uses simple text parsing to extract key elements
  
  switch (diagramType) {
    case 'flowchart':
      return generateFlowchartFallback(text);
    case 'sequence':
      return generateSequenceDiagramFallback(text);
    case 'classDiagram':
      return generateClassDiagramFallback(text);
    case 'stateDiagram':
      return generateStateDiagramFallback(text);
    case 'gantt':
      return generateGanttChartFallback(text);
    default:
      return generateFlowchartFallback(text);
  }
};

const generateFlowchartFallback = (text: string): string => {
  // Parse the text to identify steps, processes, and decision points
  const lines = text.split('\n');
  const steps: string[] = [];
  const connections: string[] = [];
  const nodes = new Map<string, string>();
  
  // Extract numbered lists, bullet points, and paragraphs that look like steps
  let currentNodeId = 1;
  
  // Process numbered or bulleted lists
  const stepRegex = /^[\d\s]*[\d\.)]|[-*]\s+(.+)$/;
  const headingRegex = /^#{1,3}\s+(.+)$/;
  
  lines.forEach(line => {
    const trimmedLine = line.trim();
    
    // Skip empty lines
    if (!trimmedLine) return;
    
    // Check if it's a step (numbered or bulleted list)
    const stepMatch = trimmedLine.match(stepRegex);
    const headingMatch = trimmedLine.match(headingRegex);
    
    if (stepMatch && stepMatch[1]) {
      const nodeId = `step${currentNodeId++}`;
      const content = stepMatch[1].trim();
      nodes.set(nodeId, content);
      steps.push(nodeId);
    } else if (headingMatch && headingMatch[1]) {
      const nodeId = `heading${currentNodeId++}`;
      // Add headings as special nodes
      const content = headingMatch[1].trim();
      nodes.set(nodeId, content);
      steps.push(nodeId);
    } else if (trimmedLine.toLowerCase().includes('if') || 
               trimmedLine.toLowerCase().includes('decision') || 
               trimmedLine.toLowerCase().includes('choose')) {
      // This looks like a decision point
      const nodeId = `decision${currentNodeId++}`;
      nodes.set(nodeId, trimmedLine);
      steps.push(nodeId);
    } else if (trimmedLine.length > 10 && 
               (trimmedLine.endsWith('.') || 
               trimmedLine.length > 40)) {
      // This looks like a substantive step
      const nodeId = `node${currentNodeId++}`;
      nodes.set(nodeId, trimmedLine);
      steps.push(nodeId);
    }
  });
  
  // If we have too few or too many nodes, create a simpler diagram
  if (steps.length < 3 || steps.length > 15) {
    // Extract key sentences for a simpler flowchart
    const sentences = text.match(/[^.!?]+[.!?]+/g) || [];
    const keyPhrases = sentences
      .filter(s => 
        s.toLowerCase().includes('process') || 
        s.toLowerCase().includes('workflow') || 
        s.toLowerCase().includes('step') ||
        s.toLowerCase().includes('procedure') ||
        s.toLowerCase().includes('phase')
      )
      .slice(0, 7);
    
    if (keyPhrases.length >= 3) {
      // Build a simple flowchart from key phrases
      let code = 'graph TD;\n';
      
      for (let i = 0; i < keyPhrases.length; i++) {
        const nodeId = `node${i + 1}`;
        // Simplify long phrases
        let phrase = keyPhrases[i].trim();
        phrase = phrase.replace(/[.!?]+$/, '');
        if (phrase.length > 40) {
          phrase = phrase.substring(0, 40) + '...';
        }
        
        code += `  ${nodeId}["${phrase}"];\n`;
        
        if (i < keyPhrases.length - 1) {
          code += `  ${nodeId} --> node${i + 2};\n`;
        }
      }
      
      return code;
    }
    
    // If we still can't create a good diagram, generate a sample one
    return generateSampleFlowchart();
  }
  
  // Create connections between steps
  for (let i = 0; i < steps.length - 1; i++) {
    // If the current node seems like a decision, create Yes/No branches
    const nodeName = nodes.get(steps[i]) || '';
    
    if (nodeName.toLowerCase().includes('if') || 
        nodeName.toLowerCase().includes('decision') || 
        nodeName.toLowerCase().includes('choose') || 
        nodeName.toLowerCase().includes('?')) {
      // It's a decision node, see if we can determine branches
      if (i + 2 < steps.length) {
        // Yes branch goes to next node
        connections.push(`  ${steps[i]} -->|Yes| ${steps[i+1]};`);
        // No branch goes to the node after next
        connections.push(`  ${steps[i]} -->|No| ${steps[i+2]};`);
        // Skip the next node since we've connected it
        i++;
      } else {
        // Simple connection for the last decision node
        connections.push(`  ${steps[i]} --> ${steps[i+1]};`);
      }
    } else {
      // Standard connection
      connections.push(`  ${steps[i]} --> ${steps[i+1]};`);
    }
  }
  
  // Generate the Mermaid flowchart code
  let flowchartCode = 'graph TD;\n';
  
  // Add all nodes
  nodes.forEach((content, nodeId) => {
    // Clean content for diagram
    content = content.replace(/"/g, "'").replace(/\n/g, " ");
    if (content.length > 40) {
      content = content.substring(0, 40) + '...';
    }
    
    // Style based on node type
    if (nodeId.startsWith('heading')) {
      // Headings get a special style
      flowchartCode += `  ${nodeId}[["${content}"]];\n`;
    } else if (nodeId.startsWith('decision')) {
      // Decision nodes get diamond shapes
      flowchartCode += `  ${nodeId}{"${content}"};\n`;
    } else if (nodeId.startsWith('step')) {
      // Step nodes get rounded rectangles
      flowchartCode += `  ${nodeId}["${content}"];\n`;
    } else {
      // Regular nodes get rectangles
      flowchartCode += `  ${nodeId}("${content}");\n`;
    }
  });
  
  // Add all connections
  connections.forEach(connection => {
    flowchartCode += `${connection}\n`;
  });
  
  return flowchartCode;
};

const generateSequenceDiagramFallback = (text: string): string => {
  // Extract potential actors/participants from the text
  const actorKeywords = ['user', 'system', 'admin', 'client', 'server', 'database', 'api'];
  const actors = new Set<string>();
  
  // Find actors mentioned in the text
  actorKeywords.forEach(keyword => {
    const regex = new RegExp(`\\b${keyword}\\b`, 'gi');
    const matches = text.match(regex);
    if (matches) {
      actors.add(keyword.charAt(0).toUpperCase() + keyword.slice(1));
    }
  });
  
  // Add some default actors if we didn't find enough
  if (actors.size < 3) {
    actors.add('User');
    actors.add('System');
    actors.add('Database');
  }
  
  // Generate sequence diagram
  let sequenceDiagram = 'sequenceDiagram\n';
  
  // Add participants
  actors.forEach(actor => {
    sequenceDiagram += `  participant ${actor}\n`;
  });
  
  // Extract interaction sentences
  const sentences = text.match(/[^.!?]+[.!?]+/g) || [];
  const interactions = sentences
    .filter(s => 
      actors.has(s.trim().split(' ')[0]) || // Sentence starts with an actor
      actorKeywords.some(keyword => s.toLowerCase().includes(keyword)) // Sentence contains an actor
    )
    .slice(0, 8); // Limit to 8 interactions
  
  // If we couldn't find good interactions, create some typical ones
  if (interactions.length < 3) {
    const actorsArray = Array.from(actors);
    
    // Generate some typical interactions
    sequenceDiagram += `  ${actorsArray[0]}->>+${actorsArray[1]}: Request information\n`;
    sequenceDiagram += `  ${actorsArray[1]}->>+${actorsArray[2]}: Validate request\n`;
    sequenceDiagram += `  ${actorsArray[2]}-->>-${actorsArray[1]}: Return validation result\n`;
    sequenceDiagram += `  ${actorsArray[1]}-->>-${actorsArray[0]}: Provide requested information\n`;
    
    return sequenceDiagram;
  }
  
  // Convert extracted sentences into interactions
  const actorsList = Array.from(actors);
  
  interactions.forEach((interaction, index) => {
    const source = actorsList[index % actorsList.length];
    const target = actorsList[(index + 1) % actorsList.length];
    
    // Clean up and shorten the message
    let message = interaction.trim();
    message = message.replace(/[.!?]+$/, '');
    if (message.length > 40) {
      message = message.substring(0, 40) + '...';
    }
    
    // Determine if it's a request or response
    const isEvenIndex = index % 2 === 0;
    
    if (isEvenIndex) {
      sequenceDiagram += `  ${source}->>+${target}: ${message}\n`;
    } else {
      sequenceDiagram += `  ${target}-->>-${source}: ${message}\n`;
    }
  });
  
  return sequenceDiagram;
};

const generateClassDiagramFallback = (text: string): string => {
  // This function will generate a class/structure diagram based on the text
  // For PMO context, this is often organizational structure
  
  // Look for organizational structure indicators
  const structureKeywords = [
    'organization', 'department', 'team', 'division', 'unit', 
    'role', 'position', 'responsibility', 'manager', 'director',
    'reports to', 'oversees', 'supervises', 'manages'
  ];
  
  const hasStructureContent = structureKeywords.some(keyword => 
    text.toLowerCase().includes(keyword)
  );
  
  if (!hasStructureContent) {
    return generateSampleClassDiagram();
  }
  
  // Try to identify entities/classes from the text
  const entities = new Set<string>();
  const relationships = new Map<string, string[]>();
  
  // Look for sections that might define structures
  const sectionRegex = /#+\s+(.*structure|.*organization|.*hierarchy|.*team|.*composition|.*breakdown|.*governance)/i;
  const sections = text.split(sectionRegex);
  
  // Analyze relevant section if found
  let relevantText = text;
  if (sections.length > 1) {
    relevantText = sections[1]; // Get the content after the matching heading
    
    // Limit to the next heading if there is one
    const nextHeadingMatch = relevantText.match(/#+\s+/);
    if (nextHeadingMatch) {
      const nextHeadingIndex = relevantText.indexOf(nextHeadingMatch[0]);
      if (nextHeadingIndex > 0) {
        relevantText = relevantText.substring(0, nextHeadingIndex);
      }
    }
  }
  
  // Extract potential entities from bullet points and key terms
  const lines = relevantText.split('\n');
  const bulletPointRegex = /[-*]\s+(.*)/;
  const relationshipRegex = /(.*)\s+(reports to|manages|supervises|oversees|is responsible for)\s+(.*)/i;
  
  lines.forEach(line => {
    const trimmedLine = line.trim();
    const bulletMatch = trimmedLine.match(bulletPointRegex);
    
    if (bulletMatch) {
      const entityName = bulletMatch[1].trim().split(/[,:]/, 1)[0].trim();
      if (entityName && entityName.length <= 30) {
        entities.add(entityName);
      }
    }
    
    // Look for relationships in the text
    const relationshipMatch = trimmedLine.match(relationshipRegex);
    if (relationshipMatch) {
      const entity1 = relationshipMatch[1].trim();
      const relationship = relationshipMatch[2].trim().toLowerCase();
      const entity2 = relationshipMatch[3].trim();
      
      if (entity1 && entity2) {
        entities.add(entity1);
        entities.add(entity2);
        
        if (!relationships.has(entity1)) {
          relationships.set(entity1, []);
        }
        
        // Add the relationship
        let relationshipArrow = '';
        if (relationship.includes('reports to')) {
          relationshipArrow = `"Reports to" -->`;
        } else if (relationship.includes('manages') || relationship.includes('supervises') || relationship.includes('oversees')) {
          relationshipArrow = `"Manages" -->`;
        } else {
          relationshipArrow = `-->`;
        }
        
        relationships.get(entity1)!.push(`${entity1} ${relationshipArrow} ${entity2}`);
      }
    }
  });
  
  // If we couldn't identify entities, create a sample diagram
  if (entities.size < 3 && relationships.size === 0) {
    return generateSampleClassDiagram();
  }
  
  // Generate the class diagram code
  let classDiagram = 'classDiagram\n';
  
  // Add classes
  entities.forEach(entity => {
    classDiagram += `  class ${sanitizeClassName(entity)} {\n`;
    classDiagram += `    +Responsibilities\n`; // Default field
    classDiagram += `  }\n`;
  });
  
  // Add relationships
  relationships.forEach((targetRelations, source) => {
    targetRelations.forEach(rel => {
      classDiagram += `  ${rel}\n`;
    });
  });
  
  // If no relationships were found, create some based on entities
  if (relationships.size === 0) {
    const entitiesArray = Array.from(entities);
    for (let i = 0; i < entitiesArray.length - 1; i++) {
      classDiagram += `  ${sanitizeClassName(entitiesArray[i])} --> ${sanitizeClassName(entitiesArray[i+1])}\n`;
    }
  }
  
  return classDiagram;
};

const generateStateDiagramFallback = (text: string): string => {
  // Look for state-related keywords in the text
  const stateKeywords = [
    'state', 'condition', 'status', 'phase', 'stage',
    'transition', 'change', 'move', 'shift', 'transform',
    'initial', 'final', 'start', 'end', 'complete'
  ];
  
  const hasStateContent = stateKeywords.some(keyword => 
    text.toLowerCase().includes(keyword)
  );
  
  if (!hasStateContent) {
    return generateSampleStateDiagram();
  }
  
  // Try to identify states and transitions
  const states = new Set<string>();
  const transitions: { from: string, to: string, label?: string }[] = [];
  
  // Extract potential states from the text
  const stateRegex = /\b(initial|start|begin|draft|review|approve|reject|complete|final|end)\b\s*(state|stage|status|phase)?/gi;
  const stateMatches = [...text.matchAll(stateRegex)];
  
  // Extract states
  stateMatches.forEach(match => {
    const state = match[1].trim();
    if (state) {
      states.add(state.charAt(0).toUpperCase() + state.slice(1).toLowerCase());
    }
  });
  
  // Extract transitions
  const lines = text.split('\n');
  const transitionRegex = /(from|moves|changes|transitions)\s+(.*?)\s+(to|into|toward)\s+(.*?)([,.]|$)/i;
  
  lines.forEach(line => {
    const matches = line.match(transitionRegex);
    if (matches) {
      const fromState = matches[2].trim();
      const toState = matches[4].trim();
      
      if (fromState && toState) {
        states.add(fromState.charAt(0).toUpperCase() + fromState.slice(1).toLowerCase());
        states.add(toState.charAt(0).toUpperCase() + toState.slice(1).toLowerCase());
        
        transitions.push({
          from: fromState.charAt(0).toUpperCase() + fromState.slice(1).toLowerCase(),
          to: toState.charAt(0).toUpperCase() + toState.slice(1).toLowerCase()
        });
      }
    }
  });
  
  // If we didn't find enough states, add some common ones
  if (states.size < 3) {
    states.add('Initial');
    states.add('InProgress');
    states.add('Review');
    states.add('Complete');
  }
  
  // If we didn't find transitions, create some based on the states
  if (transitions.length === 0) {
    const statesArray = Array.from(states);
    for (let i = 0; i < statesArray.length - 1; i++) {
      transitions.push({
        from: statesArray[i],
        to: statesArray[i + 1]
      });
    }
  }
  
  // Generate the state diagram code
  let stateDiagram = 'stateDiagram-v2\n';
  
  // Add states
  states.forEach(state => {
    stateDiagram += `  ${sanitizeStateName(state)}\n`;
  });
  
  // Add transitions
  transitions.forEach(transition => {
    const label = transition.label ? ` : ${transition.label}` : '';
    stateDiagram += `  ${sanitizeStateName(transition.from)} --> ${sanitizeStateName(transition.to)}${label}\n`;
  });
  
  // Add initial state if it exists
  if (states.has('Initial')) {
    stateDiagram += '  [*] --> Initial\n';
  } else if (states.has('Start')) {
    stateDiagram += '  [*] --> Start\n';
  } else {
    // Add to the first state in the set
    const firstState = Array.from(states)[0];
    stateDiagram += `  [*] --> ${sanitizeStateName(firstState)}\n`;
  }
  
  // Add final state if it exists
  if (states.has('Complete')) {
    stateDiagram += '  Complete --> [*]\n';
  } else if (states.has('Final')) {
    stateDiagram += '  Final --> [*]\n';
  } else if (states.has('End')) {
    stateDiagram += '  End --> [*]\n';
  } else {
    // Add from the last state in the set
    const lastState = Array.from(states)[states.size - 1];
    stateDiagram += `  ${sanitizeStateName(lastState)} --> [*]\n`;
  }
  
  return stateDiagram;
};

const generateGanttChartFallback = (text: string): string => {
  // Basic gantt chart generation from text
  let ganttChart = 'gantt\n';
  ganttChart += '    title PMO Implementation Timeline\n';
  ganttChart += '    dateFormat  YYYY-MM-DD\n';
  ganttChart += '    section Planning Phase\n';
  
  // Try to extract tasks and timeframes
  const tasks = new Map<string, { start: string, duration: number }>();
  
  // Look for time-related phrases
  const today = new Date();
  const startDate = new Date(today);
  const defaultStart = startDate.toISOString().split('T')[0]; // YYYY-MM-DD
  
  // Check for specific phases
  const phases = [
    'planning', 'preparation', 'implementation', 'execution', 'evaluation',
    'assessment', 'development', 'design', 'review', 'delivery', 'testing'
  ];
  
  let foundTasks = false;
  
  // Extract tasks from bullet points or lines with phase names
  const lines = text.split('\n');
  let currentSection = 'Planning Phase';
  
  lines.forEach(line => {
    const trimmedLine = line.trim();
    
    // Check if it's a heading that could be a section
    if (/^#+\s+(.+)/.test(trimmedLine)) {
      const headingText = trimmedLine.replace(/^#+\s+/, '');
      currentSection = headingText;
      ganttChart += `    section ${currentSection}\n`;
      foundTasks = true;
    }
    
    // Check if the line is a task
    const bulletMatch = trimmedLine.match(/[-*]\s+(.+)/) || trimmedLine.match(/^\d+\.\s+(.+)/);
    if (bulletMatch) {
      const taskText = bulletMatch[1].trim();
      
      // Check if the task mentions any phase
      const phaseMatch = phases.find(phase => taskText.toLowerCase().includes(phase));
      
      if (phaseMatch || taskText.length <= 50) {
        // This is likely a task
        const taskId = `task${uuidv4().substring(0, 8)}`;
        
        // Map a base duration based on position
        const idx = lines.indexOf(line);
        const position = idx / lines.length;
        const duration = 7 + Math.floor(position * 21); // 7-28 days
        
        // Calculate a start date
        const daysToAdd = Math.floor(position * 60); // Spread tasks over 60 days
        const taskStartDate = new Date(startDate);
        taskStartDate.setDate(taskStartDate.getDate() + daysToAdd);
        const formattedStart = taskStartDate.toISOString().split('T')[0];
        
        tasks.set(taskText, { start: formattedStart, duration });
        
        // Add to gantt chart
        ganttChart += `    ${taskText.replace(/:/g, ' -')} :${taskId}, ${formattedStart}, ${duration}d\n`;
        foundTasks = true;
      }
    }
  });
  
  // If we couldn't find tasks, create some based on typical PMO implementation
  if (!foundTasks) {
    ganttChart += '    Define PMO charter and scope :a1, 2025-01-01, 14d\n';
    ganttChart += '    Identify key stakeholders :a2, 2025-01-15, 7d\n';
    ganttChart += '    Develop governance structure :a3, after a2, 21d\n';
    
    ganttChart += '    section Implementation Phase\n';
    ganttChart += '    Create standard methodologies :b1, after a3, 30d\n';
    ganttChart += '    Develop templates and artifacts :b2, after a3, 14d\n';
    ganttChart += '    Establish performance metrics :b3, after b1, 14d\n';
    
    ganttChart += '    section Deployment Phase\n';
    ganttChart += '    Train project managers :c1, after b2, 14d\n';
    ganttChart += '    Pilot with selected projects :c2, after c1, 30d\n';
    ganttChart += '    Full implementation :c3, after c2, 14d\n';
  }
  
  return ganttChart;
};

// Helper functions
const sanitizeClassName = (name: string): string => {
  // Remove special characters and spaces
  return name.replace(/[^\w]/g, '_').replace(/_{2,}/g, '_');
};

const sanitizeStateName = (name: string): string => {
  // Remove special characters and spaces
  return name.replace(/\s+/g, '');
};

// Sample diagram generators
const generateSampleFlowchart = (): string => {
  return `graph TD;
  A[Start Process] --> B{Is documentation complete?};
  B -->|Yes| C[Review Documentation];
  B -->|No| D[Request Additional Information];
  D --> B;
  C --> E[Approve Process];
  E --> F[Implement Process];
  F --> G[Monitor & Evaluate];
  G --> H{Improvements needed?};
  H -->|Yes| I[Identify Improvements];
  I --> F;
  H -->|No| J[Maintain Process];
  J --> G;`;
};

const generateSampleClassDiagram = (): string => {
  return `classDiagram
  class PMO {
    +DirectorOfPMO
    +Responsibilities
    +OverseePortfolio()
  }
  
  class ProjectManagers {
    +NumberOfPMs
    +ManageProjects()
  }
  
  class ProjectTeams {
    +TeamMembers
    +Skills
    +DeliverProject()
  }
  
  class Stakeholders {
    +Requirements
    +Feedback
    +ApproveDeliverables()
  }
  
  PMO --> ProjectManagers : "Oversees"
  ProjectManagers --> ProjectTeams : "Leads"
  ProjectTeams --> Stakeholders : "Delivers to"
  Stakeholders --> PMO : "Provides requirements"`;
};

const generateSampleStateDiagram = (): string => {
  return `stateDiagram-v2
  [*] --> Draft
  Draft --> Review : Document completed
  Review --> Revision : Changes requested
  Revision --> Review : Submitted for review
  Review --> Approved : Meets requirements
  Approved --> Published : Release scheduled
  Published --> [*]`;
};

export const extractProcessSteps = (text: string): string[] => {
  // Extract process steps from text
  const steps: string[] = [];
  
  // Try to identify numbered or bulleted lists
  const lines = text.split('\n');
  
  const stepRegex = /^[\d\s]*[\d\.)]|[-*]\s+(.+)$/;
  
  lines.forEach(line => {
    const trimmedLine = line.trim();
    const stepMatch = trimmedLine.match(stepRegex);
    
    if (stepMatch && stepMatch[1]) {
      steps.push(stepMatch[1].trim());
    }
  });
  
  // If no steps found, try to extract sentences that seem like steps
  if (steps.length === 0) {
    const sentences = text.match(/[^.!?]+[.!?]+/g) || [];
    const stepSentences = sentences.filter(s => 
      s.toLowerCase().includes('step') || 
      s.toLowerCase().includes('first') ||
      s.toLowerCase().includes('next') ||
      s.toLowerCase().includes('then') ||
      s.toLowerCase().includes('finally') ||
      /^\s*\d+\./.test(s) // Starts with a number followed by a period
    );
    
    steps.push(...stepSentences.map(s => s.trim()));
  }
  
  return steps;
};