import { supabase } from './supabaseClient';

export interface BestPracticeCategory {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  display_order: number;
}

export interface BestPracticeTag {
  id: string;
  name: string;
  description?: string;
}

export interface BestPracticeDocument {
  id: string;
  title: string;
  summary?: string;
  content: string;
  category_id?: string;
  category?: {
    name: string;
    icon: string;
    color: string;
  };
  document_type: string;
  format: string;
  status: string;
  featured: boolean;
  is_public: boolean;
  view_count: number;
  version: string;
  created_at: string;
  updated_at: string;
  tags?: string[];
  tag_objects?: BestPracticeTag[];
}

class BestPracticeService {
  /**
   * Get all categories
   */
  async getCategories(): Promise<BestPracticeCategory[]> {
    try {
      const { data, error } = await supabase
        .from('best_practice_categories')
        .select('*')
        .eq('is_active', true)
        .order('display_order', { ascending: true });
        
      if (error) throw error;
      
      return data || [];
    } catch (error) {
      console.error('Error fetching categories:', error);
      return [];
    }
  }
  
  /**
   * Get all tags
   */
  async getTags(): Promise<BestPracticeTag[]> {
    try {
      const { data, error } = await supabase
        .from('best_practice_tags')
        .select('*')
        .order('name', { ascending: true });
        
      if (error) throw error;
      
      return data || [];
    } catch (error) {
      console.error('Error fetching tags:', error);
      return [];
    }
  }
  
  /**
   * Get all published and public documents
   */
  async getDocuments(options?: {
    categoryId?: string;
    tagIds?: string[];
    documentType?: string;
    featured?: boolean;
    searchTerm?: string;
    limit?: number;
    page?: number;
  }): Promise<{
    documents: BestPracticeDocument[];
    total: number;
  }> {
    const {
      categoryId,
      tagIds,
      documentType,
      featured,
      searchTerm,
      limit = 20,
      page = 1
    } = options || {};
    
    try {
      // For testing, create and return mock documents
      const mockDocuments = this.createMockDocuments();
      const filteredDocs = mockDocuments.filter(doc => {
        let matches = true;
        
        if (categoryId && doc.category_id !== categoryId) {
          matches = false;
        }
        
        if (documentType && doc.document_type !== documentType) {
          matches = false;
        }
        
        if (featured && !doc.featured) {
          matches = false;
        }
        
        if (tagIds && tagIds.length > 0) {
          const docTagIds = doc.tags || [];
          const hasMatchingTag = tagIds.some(id => docTagIds.includes(id));
          if (!hasMatchingTag) {
            matches = false;
          }
        }
        
        if (searchTerm) {
          const searchLower = searchTerm.toLowerCase();
          const titleMatch = doc.title.toLowerCase().includes(searchLower);
          const summaryMatch = doc.summary ? doc.summary.toLowerCase().includes(searchLower) : false;
          const contentMatch = doc.content.toLowerCase().includes(searchLower);
          
          if (!titleMatch && !summaryMatch && !contentMatch) {
            matches = false;
          }
        }
        
        return matches;
      });
      
      // Calculate pagination
      const startIndex = (page - 1) * limit;
      const endIndex = startIndex + limit;
      const paginatedDocs = filteredDocs.slice(startIndex, endIndex);
      
      return {
        documents: paginatedDocs,
        total: filteredDocs.length
      };
    } catch (error) {
      console.error('Error fetching documents:', error);
      return { documents: [], total: 0 };
    }
  }
  
  /**
   * Get a single document by ID
   */
  async getDocument(id: string): Promise<BestPracticeDocument | null> {
    try {
      // For testing, find the document in mock data
      const mockDocuments = this.createMockDocuments();
      const document = mockDocuments.find(doc => doc.id === id);
      
      if (!document) return null;
      
      // Simulate view count increment
      document.view_count += 1;
      
      return document;
    } catch (error) {
      console.error('Error fetching document:', error);
      return null;
    }
  }
  
  /**
   * Increment document view count
   */
  async incrementViewCount(id: string): Promise<void> {
    // Mock implementation
    console.log(`Incrementing view count for document ${id}`);
  }
  
  /**
   * Get featured documents
   */
  async getFeaturedDocuments(limit: number = 6): Promise<BestPracticeDocument[]> {
    try {
      // For testing, return featured documents from mock data
      const mockDocuments = this.createMockDocuments();
      const featured = mockDocuments.filter(doc => doc.featured).slice(0, limit);
      
      return featured;
    } catch (error) {
      console.error('Error fetching featured documents:', error);
      return [];
    }
  }
  
  /**
   * Create mock documents for testing
   */
  private createMockDocuments(): BestPracticeDocument[] {
    const categories = [
      { id: 'cat1', name: 'Methodologies & Frameworks', icon: 'layout', color: 'blue' },
      { id: 'cat2', name: 'Governance & Oversight', icon: 'shield', color: 'purple' },
      { id: 'cat3', name: 'Templates & Tools', icon: 'file-text', color: 'green' },
    ];
    
    const tags: BestPracticeTag[] = [
      { id: 'tag1', name: 'Beginner' },
      { id: 'tag2', name: 'Intermediate' },
      { id: 'tag3', name: 'Advanced' },
      { id: 'tag4', name: 'Template' },
      { id: 'tag5', name: 'Guide' },
    ];
    
    // Create 12 mock documents
    return Array.from({ length: 12 }, (_, index) => {
      const docId = `doc${index + 1}`;
      const categoryIndex = index % 3;
      const category = categories[categoryIndex];
      const docType = index % 5 === 0 ? 'template' : 
                      index % 5 === 1 ? 'guide' : 
                      index % 5 === 2 ? 'checklist' : 
                      index % 5 === 3 ? 'whitepaper' : 'case-study';
      
      // Assign 1-3 random tags
      const docTags: string[] = [];
      const docTagObjects: BestPracticeTag[] = [];
      
      for (let i = 0; i < 3; i++) {
        if (Math.random() > 0.3) {
          const tagIndex = Math.floor(Math.random() * tags.length);
          const tag = tags[tagIndex];
          if (!docTags.includes(tag.id)) {
            docTags.push(tag.id);
            docTagObjects.push(tag);
          }
        }
      }
      
      return {
        id: docId,
        title: `${docType.charAt(0).toUpperCase() + docType.slice(1)}: ${category.name} Example ${index + 1}`,
        summary: `A comprehensive ${docType} for ${category.name.toLowerCase()}.`,
        content: this.getExampleContent(docType, category.name),
        category_id: category.id,
        category: {
          name: category.name,
          icon: category.icon,
          color: category.color
        },
        document_type: docType,
        format: 'markdown',
        status: 'published',
        featured: index % 4 === 0, // Every 4th document is featured
        is_public: true,
        view_count: Math.floor(Math.random() * 100),
        version: '1.0',
        created_at: new Date(Date.now() - (index * 86400000)).toISOString(), // Each doc 1 day older
        updated_at: new Date(Date.now() - (index * 43200000)).toISOString(), // Each doc 12 hours older
        tags: docTags,
        tag_objects: docTagObjects
      };
    });
  }
  
  /**
   * Generate example content for mock documents
   */
  private getExampleContent(type: string, category: string): string {
    return `# ${type.charAt(0).toUpperCase() + type.slice(1)}: ${category}

## Overview

This is an example ${type} for ${category}. It demonstrates the structure and content typically found in PMO documents of this type. This mock content is for demonstration purposes.

## Key Components

### 1. Purpose and Scope

The purpose of this ${type} is to provide guidance on implementing effective ${category.toLowerCase()} within a Project Management Office (PMO).

### 2. Implementation Guidelines

- Start with a clear understanding of organizational objectives
- Develop a comprehensive framework aligned with business needs
- Establish clear roles and responsibilities
- Implement regular review cycles
- Monitor effectiveness through defined metrics

### 3. Best Practices

1. Engage stakeholders early and often
2. Document processes thoroughly
3. Provide adequate training and support
4. Establish feedback mechanisms
5. Continuously improve based on lessons learned

## Template Structure

| Section | Purpose | Key Elements |
|---------|---------|-------------|
| Introduction | Set context | Background, objectives |
| Framework | Define structure | Components, relationships |
| Processes | Define workflow | Inputs, activities, outputs |
| Roles | Clarify responsibilities | RACI matrix |
| Metrics | Measure success | KPIs, targets |

## Implementation Roadmap

1. **Assessment Phase** (Weeks 1-4)
   - Evaluate current state
   - Identify gaps and opportunities
   - Define requirements

2. **Design Phase** (Weeks 5-8)
   - Develop framework and processes
   - Create documentation
   - Design training materials

3. **Implementation Phase** (Weeks 9-16)
   - Pilot implementation
   - Gather feedback
   - Refine approach

4. **Evaluation Phase** (Ongoing)
   - Measure effectiveness
   - Identify areas for improvement
   - Update documentation

---

*This document is a sample template for demonstration purposes.*`;
  }
  
  /**
   * Get documents by category
   */
  async getDocumentsByCategory(categoryId: string, limit: number = 10): Promise<BestPracticeDocument[]> {
    try {
      // For testing, return filtered mock data
      const mockDocuments = this.createMockDocuments();
      const filtered = mockDocuments
        .filter(doc => doc.category_id === categoryId)
        .slice(0, limit);
      
      return filtered;
    } catch (error) {
      console.error('Error fetching documents by category:', error);
      return [];
    }
  }
  
  /**
   * Search documents
   */
  async searchDocuments(searchTerm: string, limit: number = 10): Promise<BestPracticeDocument[]> {
    if (!searchTerm || searchTerm.length < 2) return [];
    
    try {
      // For testing, search mock data
      const mockDocuments = this.createMockDocuments();
      const searchLower = searchTerm.toLowerCase();
      
      const results = mockDocuments.filter(doc => {
        return doc.title.toLowerCase().includes(searchLower) || 
               (doc.summary && doc.summary.toLowerCase().includes(searchLower)) ||
               doc.content.toLowerCase().includes(searchLower);
      }).slice(0, limit);
      
      return results;
    } catch (error) {
      console.error('Error searching documents:', error);
      return [];
    }
  }
  
  /**
   * Get related documents
   */
  async getRelatedDocuments(documentId: string, limit: number = 5): Promise<BestPracticeDocument[]> {
    try {
      // For testing, get documents from the same category
      const mockDocuments = this.createMockDocuments();
      const document = mockDocuments.find(doc => doc.id === documentId);
      
      if (!document) return [];
      
      const related = mockDocuments
        .filter(doc => doc.id !== documentId && doc.category_id === document.category_id)
        .slice(0, limit);
      
      return related;
    } catch (error) {
      console.error('Error fetching related documents:', error);
      return [];
    }
  }
}

export const bestPracticeService = new BestPracticeService();