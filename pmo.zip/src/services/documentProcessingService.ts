/**
 * Service for processing and analyzing documents
 */

import { v4 as uuidv4 } from 'uuid';
import { supabase } from './supabaseClient';
import { 
  chunkDocument, 
  ProcessedDocument, 
  DocumentChunk,
  createSimpleIndex,
  searchChunks
} from '../utils/documentUtils';
import pLimit from 'p-limit';

// Set up rate limiting for document operations
const documentLimiter = pLimit(2); // Only allow 2 concurrent document operations
const chunkLimiter = pLimit(3); // Allow 3 concurrent chunk operations

interface DocumentIndexEntry {
  term: string;
  chunkIds: string[];
}

export class DocumentProcessingService {
  // Document processing caches
  private chunkCache: Map<string, DocumentChunk[]> = new Map();
  private domainDocumentCache: Map<string, DocumentChunk[]> = new Map();
  private documentsBeingProcessed: Set<string> = new Set();
  
  /**
   * Process a text document by chunking and indexing it
   */
  async processTextDocument(
    fileName: string,
    content: string,
    fileType: string = 'text',
    userId?: string,
    projectId?: string,
    domainId?: number
  ): Promise<ProcessedDocument> {
    return documentLimiter(async () => {
      try {
        // Track processing start time
        const startTime = performance.now();
        console.log(`[Performance] Processing document: ${fileName}`);
        
        // Chunk the document
        const processedDocument = chunkDocument(content, fileName, fileType);
        
        // Add domain ID if provided
        if (domainId) {
          processedDocument.domainId = domainId;
        }
        
        // Add project ID if provided
        if (projectId) {
          processedDocument.projectId = projectId;
        }
        
        // Add user ID if provided
        if (userId) {
          processedDocument.userId = userId;
        }
        
        // Store in Supabase if user and project IDs are provided
        if (userId && projectId) {
          // Mark this document as being processed
          const docKey = `${projectId}-${fileName}`;
          this.documentsBeingProcessed.add(docKey);
          
          try {
            await this.storeProcessedDocument(processedDocument, userId, projectId, domainId);
          } catch (error) {
            console.error('Error storing document in Supabase:', error);
            // Continue even if Supabase storage fails
          } finally {
            // Remove from processing list
            this.documentsBeingProcessed.delete(docKey);
          }
        }
        
        // Log processing time
        const processingTime = performance.now() - startTime;
        console.log(`[Performance] Document processed in ${processingTime.toFixed(2)}ms`);
        
        return processedDocument;
      } catch (error) {
        console.error('Error processing document:', error);
        throw error;
      }
    });
  }
  
  /**
   * Store processed document in Supabase with improved batching
   */
  private async storeProcessedDocument(
    document: ProcessedDocument,
    userId: string,
    projectId: string,
    domainId?: number
  ): Promise<void> {
    return documentLimiter(async () => {
      try {
        // First, store document metadata
        const { error: docError } = await supabase
          .from('processed_documents')
          .insert([{
            id: document.id,
            file_name: document.fileName,
            file_type: document.fileType,
            total_chunks: document.totalChunks,
            updated_by: userId,
            project_id: projectId,
            domain_id: domainId,
            created_at: document.createdAt,
            updated_at: document.updatedAt,
            metadata: document.metadata
          }]);
          
        if (docError) throw docError;
        
        // Then, store chunks in batches
        const BATCH_SIZE = 20; // Reduced batch size for better reliability
        
        for (let i = 0; i < document.chunks.length; i += BATCH_SIZE) {
          const batchChunks = document.chunks.slice(i, i + BATCH_SIZE);
          
          const chunkRecords = batchChunks.map(chunk => ({
            id: chunk.id,
            document_id: chunk.documentId,
            content: chunk.content,
            chunk_index: chunk.metadata.chunkIndex,
            char_start: chunk.metadata.charStart,
            char_end: chunk.metadata.charEnd,
            token_count: chunk.metadata.tokenCount,
            page_number: chunk.metadata.pageNumber,
            source: chunk.metadata.source
          }));
          
          // Process chunk batches concurrently but with rate limiting
          await chunkLimiter(async () => {
            const { error: chunksError } = await supabase
              .from('document_chunks')
              .insert(chunkRecords);
              
            if (chunksError) {
              console.error(`Error inserting chunk batch (${i}-${i + batchChunks.length}):`, chunksError);
              // Continue processing other batches even if one fails
            }
          });
        }
        
        // Create and store simple index
        const index = createSimpleIndex(document.chunks);
        const indexBatches = [];
        const entries = Object.entries(index);
        
        // Split index entries into batches
        for (let i = 0; i < entries.length; i += BATCH_SIZE) {
          const batchEntries = entries.slice(i, i + BATCH_SIZE);
          
          const indexRecords = batchEntries.map(([term, chunkIds]) => ({
            id: uuidv4(), // Generate a UUID for each index entry
            document_id: document.id,
            term: term,
            chunk_ids: chunkIds
          }));
          
          indexBatches.push(indexRecords);
        }
        
        // Process index batches concurrently but with rate limiting
        await Promise.all(
          indexBatches.map(batch => 
            chunkLimiter(async () => {
              const { error: indexError } = await supabase
                .from('document_index')
                .insert(batch);
                
              if (indexError) {
                console.error(`Error inserting index batch:`, indexError);
                // Continue with other operations even if index insertion fails
              }
            })
          )
        );
        
      } catch (error) {
        console.error('Error storing processed document:', error);
        throw error;
      }
    });
  }
  
  /**
   * Retrieve documents for a specific domain with caching
   */
  async getDomainDocuments(
    domainId: number,
    projectId: string
  ): Promise<DocumentChunk[]> {
    // Generate a cache key
    const cacheKey = `domain-${projectId}-${domainId}`;
    
    // Check cache first
    if (this.domainDocumentCache.has(cacheKey)) {
      return this.domainDocumentCache.get(cacheKey) || [];
    }
    
    try {
      // Query for documents related to this domain
      const { data, error } = await supabase
        .from('processed_documents')
        .select('id, file_name, file_type')
        .eq('project_id', projectId)
        .eq('domain_id', domainId);
      
      if (error) throw error;
      
      if (!data || data.length === 0) {
        this.domainDocumentCache.set(cacheKey, []);
        return [];
      }
      
      // Get a representative chunk from each document (up to 2 chunks per document)
      const documentChunks: DocumentChunk[] = [];
      
      // Process documents concurrently but with rate limiting
      await Promise.all(
        data.slice(0, 3).map(doc => // Limit to 3 documents for better performance
          chunkLimiter(async () => {
            const { data: chunkData, error: chunkError } = await supabase
              .from('document_chunks')
              .select('id, document_id, content, chunk_index, char_start, char_end, source')
              .eq('document_id', doc.id)
              .order('chunk_index', { ascending: true })
              .limit(1);
            
            if (chunkError) {
              console.error(`Error fetching chunk for document ${doc.id}:`, chunkError);
              return;
            }
            
            if (chunkData && chunkData.length > 0) {
              documentChunks.push({
                id: chunkData[0].id,
                documentId: chunkData[0].document_id,
                content: chunkData[0].content,
                metadata: {
                  chunkIndex: chunkData[0].chunk_index,
                  charStart: chunkData[0].char_start,
                  charEnd: chunkData[0].char_end,
                  source: doc.file_name,
                  domainId
                }
              });
            }
          })
        )
      );
      
      // Cache the results
      this.domainDocumentCache.set(cacheKey, documentChunks);
      
      return documentChunks;
    } catch (error) {
      console.error('Error retrieving domain documents:', error);
      return [];
    }
  }
  
  /**
   * Retrieve relevant chunks for a query with improved performance
   */
  async getRelevantChunks(
    query: string,
    projectId: string,
    maxResults: number = 10,
    domainId?: number
  ): Promise<DocumentChunk[]> {
    return documentLimiter(async () => {
      try {
        // Generate cache key
        const cacheKey = `query-${projectId}-${query.slice(0, 50)}-${domainId || 'all'}`;
        
        // Check cache first
        if (this.chunkCache.has(cacheKey)) {
          return this.chunkCache.get(cacheKey) || [];
        }
        
        // Extract key terms from query (simple implementation)
        const terms = query
          .toLowerCase()
          .replace(/[^\w\s]/g, '')
          .split(/\s+/)
          .filter(term => term.length > 3)
          .slice(0, 5); // Take top 5 terms
        
        if (terms.length === 0) {
          return [];
        }
        
        // Build a query to find chunks containing these terms
        let baseQuery = supabase
          .from('document_chunks')
          .select(`
            id,
            document_id,
            content,
            chunk_index,
            char_start,
            char_end,
            source,
            processed_documents(domain_id)
          `)
          .eq('processed_documents.project_id', projectId)
          .limit(maxResults);
        
        if (domainId !== undefined) {
          baseQuery = baseQuery.eq('processed_documents.domain_id', domainId);
        }
        
        // Build OR conditions for content search
        const orConditions = terms.map(term => `content.ilike.%${term}%`);
        const { data, error } = await baseQuery.or(orConditions.join(','));
        
        if (error) throw error;
        
        if (!data || data.length === 0) {
          this.chunkCache.set(cacheKey, []);
          return [];
        }
        
        // Convert to DocumentChunk format
        const chunks: DocumentChunk[] = data.map(item => ({
          id: item.id,
          documentId: item.document_id,
          content: item.content,
          metadata: {
            chunkIndex: item.chunk_index,
            charStart: item.char_start,
            charEnd: item.char_end,
            source: item.source,
            domainId: item.processed_documents?.domain_id
          }
        }));
        
        // Cache the results
        this.chunkCache.set(cacheKey, chunks);
        
        return chunks;
      } catch (error) {
        console.error('Error retrieving relevant chunks:', error);
        return [];
      }
    });
  }

  /**
   * Retrieve relevant chunks from other domains (cross-domain)
   */
  async getRelevantCrossDomainChunks(
    query: string,
    currentDomainId: number,
    projectId: string,
    maxResults: number = 5
  ): Promise<DocumentChunk[]> {
    return documentLimiter(async () => {
      try {
        // Generate cache key
        const cacheKey = `cross-${projectId}-${currentDomainId}-${query.slice(0, 50)}`;
        
        // Check cache first
        if (this.chunkCache.has(cacheKey)) {
          return this.chunkCache.get(cacheKey) || [];
        }
        
        // Extract key terms from query (simple implementation)
        const terms = query
          .toLowerCase()
          .replace(/[^\w\s]/g, '')
          .split(/\s+/)
          .filter(term => term.length > 3)
          .slice(0, 5); // Take top 5 terms
        
        if (terms.length === 0) {
          return [];
        }
        
        // Build a query to find chunks containing these terms, but from other domains
        const baseQuery = supabase
          .from('document_chunks')
          .select(`
            id,
            document_id,
            content,
            chunk_index,
            char_start,
            char_end,
            source,
            processed_documents(domain_id, file_name)
          `)
          .eq('processed_documents.project_id', projectId)
          .neq('processed_documents.domain_id', currentDomainId)
          .limit(maxResults);
        
        // Build OR conditions for content search
        const orConditions = terms.map(term => `content.ilike.%${term}%`);
        const { data, error } = await baseQuery.or(orConditions.join(','));
        
        if (error) throw error;
        
        if (!data || data.length === 0) {
          this.chunkCache.set(cacheKey, []);
          return [];
        }
        
        // Convert to DocumentChunk format
        const chunks: DocumentChunk[] = data.map(item => ({
          id: item.id,
          documentId: item.document_id,
          content: item.content,
          metadata: {
            chunkIndex: item.chunk_index,
            charStart: item.char_start,
            charEnd: item.char_end,
            source: `${item.processed_documents?.file_name} (Domain ${item.processed_documents?.domain_id})`,
            domainId: item.processed_documents?.domain_id
          }
        }));
        
        // Cache the results
        this.chunkCache.set(cacheKey, chunks);
        
        return chunks;
      } catch (error) {
        console.error('Error retrieving cross-domain chunks:', error);
        return [];
      }
    });
  }
  
  /**
   * Process PDF document with optimized handling
   */
  async processPdfDocument(
    fileName: string,
    fileData: ArrayBuffer,
    userId?: string,
    projectId?: string,
    domainId?: number
  ): Promise<ProcessedDocument> {
    return documentLimiter(async () => {
      // Track processing start time
      const startTime = performance.now();
      console.log(`[Performance] Processing PDF document: ${fileName}`);
      
      try {
        // This uses pdf-parse to extract text
        const pdfParse = await import('pdf-parse');
        
        // Set a timeout to avoid hanging on corrupt PDF files
        const pdfParsePromise = pdfParse.default(Buffer.from(fileData));
        const timeoutPromise = new Promise((_, reject) => {
          setTimeout(() => reject(new Error('PDF processing timeout')), 10000);
        });
        
        // Race the PDF parsing against timeout
        const pdf = await Promise.race([pdfParsePromise, timeoutPromise]) as any;
        
        // If PDF has too much text, be more aggressive in truncating
        let text = pdf.text;
        if (text.length > 100000) { // 100K chars
          console.log(`[Performance] PDF is very large (${text.length} chars), truncating`);
          text = text.substring(0, 30000); // Only use first 30K chars
          text += `\n\n[Content truncated: PDF was ${text.length} characters]`;
        }
        
        // Process the extracted text
        const result = await this.processTextDocument(fileName, text, 'pdf', userId, projectId, domainId);
        
        // Log processing time
        const processingTime = performance.now() - startTime;
        console.log(`[Performance] PDF processed in ${processingTime.toFixed(2)}ms`);
        
        return result;
      } catch (error) {
        console.error('Error processing PDF document:', error);
        throw new Error('PDF processing failed: ' + (error instanceof Error ? error.message : String(error)));
      }
    });
  }
  
  /**
   * Clear the document cache to free memory
   */
  clearCache(): void {
    this.chunkCache.clear();
    this.domainDocumentCache.clear();
    console.log('[Performance] Document processing cache cleared');
  }
}

export const documentProcessingService = new DocumentProcessingService();