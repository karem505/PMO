import { supabase } from './supabaseClient';
import { Domain, GeneratedTemplate, DocumentChunk } from '../types';
import OpenAI from 'openai';

/**
 * Service for generating and managing PMO templates
 */
export class TemplateService {
  // Template cache
  private templateCache: Map<string, GeneratedTemplate> = new Map();
  private cacheTTL: number = 24 * 60 * 60 * 1000; // 24 hours cache TTL
  private openai: OpenAI | null = null;

  constructor() {
    const apiKey = import.meta.env.VITE_OPENAI_API_KEY;
    
    if (apiKey) {
      try {
        this.openai = new OpenAI({
          apiKey,
          dangerouslyAllowBrowser: true
        });
      } catch (error) {
        console.error('Failed to initialize OpenAI client for template service:', error);
      }
    }
    
    // Pre-warm the cache by loading any saved templates
    this.loadTemplateCache();
  }
  
  /**
   * Load templates from localStorage to memory for faster access
   */
  private loadTemplateCache(): void {
    // Find all template entries in localStorage
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key?.startsWith('template-')) {
          try {
            const data = localStorage.getItem(key);
            if (data) {
              const parsed = JSON.parse(data);
              if (parsed.template && parsed.timestamp) {
                if (Date.now() - parsed.timestamp < this.cacheTTL) {
                  // Only load if not expired
                  const cacheKey = key.replace('template-', '');
                  this.templateCache.set(cacheKey, parsed.template);
                } else {
                  // Clean up expired entries
                  localStorage.removeItem(key);
                }
              }
            }
          } catch (e) {
            console.warn('Error parsing template cache entry:', e);
          }
        }
      }
    } catch (e) {
      console.warn('Error loading template cache:', e);
    }
  }

  /**
   * Generate a template using OpenAI
   */
  async generateTemplate(
    templateName: string,
    domain: Domain,
    inputContent: string,
    relatedChunks: DocumentChunk[] = []
  ): Promise<GeneratedTemplate> {
    try {
      // Check memory cache first - fastest access
      const cacheKey = `${domain.id}-${templateName}`;
      if (this.templateCache.has(cacheKey)) {
        return this.templateCache.get(cacheKey)!;
      }
      
      // Then check local storage
      const storageKey = `template-${cacheKey}`;
      const cachedTemplate = localStorage.getItem(storageKey);
      if (cachedTemplate) {
        try {
          const parsed = JSON.parse(cachedTemplate);
          if (parsed.timestamp && Date.now() - parsed.timestamp < this.cacheTTL) {
            const template = parsed.template;
            // Also add to memory cache
            this.templateCache.set(cacheKey, template);
            return template;
          }
        } catch (e) {
          console.warn('Error parsing cached template:', e);
        }
      }
      
      // No cache hit, generate new template with minimal content for speed
      console.log('[Performance] Generating new template:', templateName);
      
      // Generate extremely simplified template to minimize generation time
      const template = await this.generateSimplifiedTemplate(templateName, domain, inputContent.substring(0, 300));
      
      // Cache the template
      this.templateCache.set(cacheKey, template);
      
      // Store in localStorage too
      try {
        localStorage.setItem(storageKey, JSON.stringify({
          template,
          timestamp: Date.now()
        }));
      } catch (e) {
        console.warn('Error caching template to localStorage:', e);
      }
      
      return template;
    } catch (error) {
      console.error('Error generating template:', error);
      
      // Return a fallback template
      return this.getFallbackTemplate(templateName, domain);
    }
  }
  
  /**
   * Generate a bare minimum template with OpenAI for maximum speed
   */
  private async generateSimplifiedTemplate(
    templateName: string,
    domain: Domain,
    inputSample: string
  ): Promise<GeneratedTemplate> {
    if (!this.openai) {
      return this.getFallbackTemplate(templateName, domain);
    }
    
    try {
      // Set a strict 5 second timeout
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 5000);
      
      try {
        // Extremely short prompt for faster processing
        const prompt = `Create a simple "${templateName}" template for ${domain.name} PMO domain. Use markdown format. Keep it brief.`;
        
        // Use the smallest, fastest model with minimal tokens
        const completion = await this.openai.chat.completions.create({
          model: "gpt-3.5-turbo",
          messages: [
            { role: "system", content: "You create brief markdown templates. Focus on structure, not content detail." },
            { role: "user", content: prompt }
          ],
          max_tokens: 500, // Strict token limit
          temperature: 0.1, // Very deterministic 
        }, { signal: controller.signal });
        
        const content = completion.choices[0]?.message?.content;
        if (!content) {
          throw new Error('Empty response');
        }
        
        return {
          name: templateName,
          content
        };
      } finally {
        clearTimeout(timeoutId);
      }
    } catch (error) {
      console.warn('Template generation failed:', error);
      return this.getFallbackTemplate(templateName, domain);
    }
  }

  /**
   * Get templates for a domain output from Supabase
   */
  async getTemplatesForDomainOutput(domainOutputId: string): Promise<GeneratedTemplate[]> {
    try {
      const { data, error } = await supabase
        .from('templates')
        .select('*')
        .eq('domain_output_id', domainOutputId);

      if (error) throw error;
      
      return data.map(template => ({
        name: template.name,
        content: template.content || ''
      }));
    } catch (error) {
      console.error('Error fetching templates:', error);
      return [];
    }
  }

  /**
   * Save a template to Supabase
   */
  async saveTemplate(domainOutputId: string, template: GeneratedTemplate): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('templates')
        .insert([{
          domain_output_id: domainOutputId,
          name: template.name,
          content: template.content
        }]);

      if (error) throw error;
      return true;
    } catch (error) {
      console.error('Error saving template:', error);
      return false;
    }
  }
  
  /**
   * Generate a fallback template if the AI service fails
   */
  private getFallbackTemplate(
    templateName: string,
    domain: Domain
  ): GeneratedTemplate {
    // Create a super minimal template
    return {
      name: templateName,
      content: `# ${templateName}

## Purpose
This template provides a framework for implementing ${domain.name.toLowerCase()}.

## Key Components

- Purpose and objectives
- Implementation approach
- Key considerations
- Success metrics

## Implementation Guidelines
1. Customize for your organization
2. Involve stakeholders
3. Define clear responsibilities
4. Review regularly

---

*This is a simplified template. For more details, regenerate when the system is less busy.*`
    };
  }
}

export const templateService = new TemplateService();