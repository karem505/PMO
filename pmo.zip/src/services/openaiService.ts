import { Domain, DocumentChunk } from '../types';
import { templateService } from './templateService';
import { documentProcessingService } from './documentProcessingService';
import OpenAI from 'openai';
import pLimit from 'p-limit';
import pRetry from 'p-retry';

// Create a wrapper service for OpenAI API
class OpenAIService {
  private openai: OpenAI | null = null;
  private initialized: boolean = false;
  private apiKey: string = '';
  private analysisStartTime: number | null = null;
  
  // Concurrency control and caching
  private apiLimiter = pLimit(1); // Only 1 API call at a time
  private memoryCache: Map<string, any> = new Map();
  private cacheExpiry: Map<string, number> = new Map();
  private cacheTTL: number = 24 * 60 * 60 * 1000; // 24 hours
  private operationTimeouts: Map<string, NodeJS.Timeout> = new Map();
  
  // Progressive loading config
  private useExpandingAnalysis: boolean = true;
  private initialResponseTimeout: number = 15000; // 15 seconds for initial response
  
  // Error handling
  private errorCount: number = 0;
  private lastErrorTime: number = 0;
  private cooldownMode: boolean = false;
  private cooldownEndTime: number = 0;

  constructor() {
    this.apiKey = import.meta.env.VITE_OPENAI_API_KEY;
    if (!this.apiKey) {
      console.warn('OpenAI API key is missing. AI analysis will fall back to mock data.');
      return;
    }

    try {
      this.openai = new OpenAI({
        apiKey: this.apiKey,
        dangerouslyAllowBrowser: true
      });
      this.initialized = true;
      console.log('OpenAI service initialized successfully');
      
      // Load cached items
      this.loadCacheFromStorage();
    } catch (error) {
      console.error('Failed to initialize OpenAI service:', error);
    }
  }

  /**
   * Load previously cached items from localStorage
   */
  private loadCacheFromStorage(): void {
    try {
      const cacheKeys = Object.keys(localStorage).filter(key => key.startsWith('openai-'));
      
      for (const key of cacheKeys) {
        try {
          const item = localStorage.getItem(key);
          if (item) {
            const parsed = JSON.parse(item);
            if (parsed.expiry && parsed.data) {
              if (parsed.expiry > Date.now()) {
                const cacheKey = key.replace('openai-', '');
                this.memoryCache.set(cacheKey, parsed.data);
                this.cacheExpiry.set(cacheKey, parsed.expiry);
              } else {
                localStorage.removeItem(key);
              }
            }
          }
        } catch (e) {
          console.warn('Error parsing cached item:', e);
        }
      }
      console.log(`[Cache] Loaded ${this.memoryCache.size} items from localStorage`);
    } catch (error) {
      console.warn('Error loading cache from localStorage:', error);
    }
  }

  /**
   * Check if the service is properly initialized
   */
  isInitialized(): boolean {
    return this.initialized;
  }

  /**
   * Analyze domain input to generate comprehensive analysis
   */
  async analyzeDomainInput(
    domainName: string, 
    domainDescription: string, 
    inputContent: string,
    previousDomainOutput?: string | null,
    userOrganization?: string,
    userIndustry?: string,
    userMaturityLevel?: string,
    projectId?: string
  ): Promise<{content: string, templates: {name: string, content: string}[]}> {
    // Mark analysis start time
    this.analysisStartTime = performance.now();
    console.log('[Performance] Starting domain analysis for:', domainName);

    // Check for initialization issues
    if (!this.initialized || !this.openai) {
      return this.getFallbackAnalysis(domainName, domainDescription);
    }
    
    // Generate cache key
    const cacheKey = this.generateCacheKey(domainName, inputContent, userMaturityLevel);
    
    // Handle in-progress analysis timeout
    this.setupAnalysisTimeout(cacheKey);

    // Check cache first
    const cachedItem = this.getCachedItem(cacheKey);
    if (cachedItem) {
      console.log('[Performance] Using cached analysis');
      return cachedItem;
    }

    try {
      // Prepare input content (reduce size, extract key points)
      const processedInput = this.prepareInputContent(inputContent);
      
      // SUPER STREAMLINED ANALYSIS - minimal processing for speed
      const minimal = domainName.length > 20 ? domainName.substring(0, 20) : domainName;
      const prompt = `Create a brief analysis of ${minimal} with 3 key recommendations. Be extremely concise.`;
      
      // First get a minimal response quickly using a fast model and small context
      const quickResult = await this.getQuickAnalysis(prompt, processedInput.substring(0, 500));
      
      // Create a minimal result that can be displayed immediately
      const initialResult = {
        content: quickResult,
        templates: [{
          name: this.getPrimaryTemplateForDomain(domainName),
          content: this.getFallbackTemplateContent(domainName, this.getPrimaryTemplateForDomain(domainName))
        }]
      };
      
      // Immediately cache initial result so something is available
      this.setCachedItem(cacheKey, initialResult);
      
      // Now proceed with the full analysis in the background, which will update the cache
      this.runBackgroundAnalysis(
        cacheKey,
        domainName, 
        domainDescription, 
        processedInput,
        userOrganization,
        userIndustry,
        userMaturityLevel,
        projectId
      );
      
      // Return the minimal result immediately
      return initialResult;
    } catch (error) {
      // Log error and return fallback
      console.error('Error in analyzeDomainInput:', error);
      const fallback = this.getFallbackAnalysis(domainName, domainDescription);
      this.setCachedItem(cacheKey, fallback);
      return fallback;
    }
  }

  /**
   * Generate a quick, minimal analysis for immediate display
   */
  private async getQuickAnalysis(prompt: string, minimalInput: string): Promise<string> {
    if (!this.openai) {
      return "# Analysis\n\n*Generating a more detailed analysis...*";
    }
    
    try {
      // Set a very short timeout
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 8000);
      
      try {
        // Use the fastest model with minimal tokens
        const completion = await this.openai.chat.completions.create({
          model: "gpt-3.5-turbo", // Fastest model
          messages: [
            {
              role: "system",
              content: "Create a very brief markdown analysis (150 words max) with the structure: 1) Overview, 2) Key Recommendations (3 bullet points)"
            },
            {
              role: "user",
              content: `${prompt}\n\nContent: ${minimalInput}`
            }
          ],
          temperature: 0.1, // Very deterministic
          max_tokens: 300, // Keep response tiny
          timeout: 10 // 10 seconds max
        }, { signal: controller.signal });
        
        // Use whatever content we got back, even if partial
        const content = completion.choices[0]?.message?.content || 
          "# Analysis\n\n*Generating detailed analysis...*\n\n## Initial Recommendations\n\n- Document current processes\n- Establish governance framework\n- Develop implementation roadmap";
        
        return content;
      } finally {
        clearTimeout(timeoutId);
      }
    } catch (error) {
      console.warn('Quick analysis failed, returning placeholder:', error);
      return "# Analysis\n\n*Generating detailed analysis...*\n\n## Initial Recommendations\n\n- Document current processes\n- Establish governance framework\n- Develop implementation roadmap";
    }
  }

  /**
   * Run a more detailed analysis in the background, updating the cache when complete
   */
  private async runBackgroundAnalysis(
    cacheKey: string,
    domainName: string,
    domainDescription: string,
    processedInput: string,
    userOrganization?: string,
    userIndustry?: string,
    userMaturityLevel?: string,
    projectId?: string
  ): Promise<void> {
    try {
      console.log('[Performance] Starting background full analysis');
      // Generate complete analysis
      const analysisContent = await this.generateAnalysis(
        domainName,
        domainDescription,
        processedInput,
        userOrganization,
        userIndustry,
        userMaturityLevel
      );
      
      // Generate a single template for the domain
      const templateName = this.getPrimaryTemplateForDomain(domainName);
      const templates = [{
        name: templateName,
        content: await this.generateTemplateContent(templateName, domainName, processedInput.substring(0, 300))
      }];
      
      // Create the full result
      const result = { content: analysisContent, templates };
      
      // Update the cache with the complete result
      this.setCachedItem(cacheKey, result);
      
      console.log('[Performance] Background analysis completed and cached');
    } catch (error) {
      console.error('Background analysis failed:', error);
      // The cache already has the initial result, so we'll just leave that in place
    } finally {
      // Clear any timeout for this analysis
      if (this.operationTimeouts.has(cacheKey)) {
        clearTimeout(this.operationTimeouts.get(cacheKey)!);
        this.operationTimeouts.delete(cacheKey);
      }
    }
  }

  /**
   * Set up a timeout for analysis operations
   */
  private setupAnalysisTimeout(cacheKey: string): void {
    // Clear any existing timeout
    if (this.operationTimeouts.has(cacheKey)) {
      clearTimeout(this.operationTimeouts.get(cacheKey)!);
    }
    
    // Set a new timeout
    const timeoutId = setTimeout(() => {
      console.warn(`Analysis timeout for ${cacheKey}`);
      // The operation is taking too long, make sure we have a fallback in cache
      if (!this.getCachedItem(cacheKey)) {
        this.setCachedItem(cacheKey, {
          content: "# Analysis timed out\n\nThe analysis operation took too long. Please try again with a shorter input text.",
          templates: [{
            name: "Fallback Template",
            content: "# Fallback Template\n\nThis template was provided because the analysis timed out."
          }]
        });
      }
    }, 60000); // 60-second timeout
    
    // Save the timeout ID
    this.operationTimeouts.set(cacheKey, timeoutId);
  }

  /**
   * Generate analysis content with OpenAI
   */
  private async generateAnalysis(
    domainName: string,
    domainDescription: string,
    inputContent: string,
    userOrganization?: string,
    userIndustry?: string,
    userMaturityLevel?: string
  ): Promise<string> {
    if (!this.openai) {
      throw new Error('OpenAI client not initialized');
    }

    console.log('[Performance] Calling OpenAI API for analysis');
    const startTime = performance.now();
    
    // Create an AbortController for timeout management
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 30000); // 30 second timeout (reduced from previous 45s)
    
    try {
      // Create a very simple prompt for faster processing
      const prompt = `
Analyze "${domainName}" data for a PMO implementation.
Organization: ${userOrganization || 'Unknown'} | Industry: ${userIndustry || 'Unknown'} | Maturity: ${userMaturityLevel || 'Initial'}
`;

      // Call the API with minimal parameters for speed
      const completion = await this.openai.chat.completions.create({
        model: "gpt-3.5-turbo", // Using the faster model
        messages: [
          {
            role: "system", 
            content: "Create a concise PMO domain analysis with: 1) Executive Summary, 2) Key Recommendations (bullet points), 3) Implementation Phases, 4) Key Focus Areas. Use markdown. Keep under 1000 words."
          },
          {
            role: "user",
            content: prompt + "\n\n" + inputContent.substring(0, Math.min(2000, inputContent.length))
          }
        ],
        temperature: 0.1, // Very low temperature for speed and consistency
        max_tokens: 1500, // Moderate token limit for balance of speed and detail
        timeout: 30 // 30 second timeout
      }, { signal: controller.signal });
      
      // Measure and log API performance
      const apiTime = performance.now() - startTime;
      console.log(`[Performance] OpenAI API response received in ${(apiTime / 1000).toFixed(2)}s`);
      
      // Extract and return content
      const analysisContent = completion.choices[0]?.message?.content || '';
      if (!analysisContent) {
        throw new Error('Empty response from OpenAI');
      }
      
      return analysisContent;
    } catch (error) {
      console.error('Error generating analysis:', error);
      
      if (error.name === 'AbortError') {
        throw new Error('OpenAI request timed out');
      }
      
      throw error;
    } finally {
      clearTimeout(timeoutId);
    }
  }
  
  /**
   * Generate template content
   */
  private async generateTemplateContent(
    templateName: string,
    domainName: string,
    inputSample: string
  ): Promise<string> {
    if (!this.openai) {
      return this.getFallbackTemplateContent(domainName, templateName);
    }
    
    try {
      // Create an AbortController for timeout management
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 10000); // 10 second timeout
      
      try {
        // Call the API with minimal parameters for speed
        const completion = await this.openai.chat.completions.create({
          model: "gpt-3.5-turbo", // Using the faster model
          messages: [
            {
              role: "system", 
              content: "Create a concise professional template in markdown format. Include clear sections with placeholders. Be practical and actionable."
            },
            {
              role: "user",
              content: `Create a "${templateName}" template for ${domainName}.\n\nContext: ${inputSample}`
            }
          ],
          temperature: 0.1, // Very low temperature for speed and consistency
          max_tokens: 1000, // Reduced tokens for speed
          timeout: 10 // 10 second timeout
        }, { signal: controller.signal });
        
        // Extract and return content
        const templateContent = completion.choices[0]?.message?.content || '';
        if (!templateContent) {
          throw new Error('Empty response from OpenAI');
        }
        
        return templateContent;
      } finally {
        clearTimeout(timeoutId);
      }
    } catch (error) {
      console.error('Error generating template content:', error);
      return this.getFallbackTemplateContent(domainName, templateName);
    }
  }

  /**
   * Prepare input content for faster processing
   */
  private prepareInputContent(inputContent: string): string {
    // For extremely long inputs, be more aggressive with truncation
    const maxInputLength = 1500; // Reduced from 2000
    
    if (inputContent.length <= maxInputLength) {
      return inputContent;
    }
    
    // For excessive inputs, take a more drastic approach
    if (inputContent.length > 5000) {
      console.log(`[Performance] Drastically reducing input size from ${inputContent.length} chars`);
      // Just take the first part
      return inputContent.substring(0, 1500) + `\n\n[Note: Input was truncated from ${inputContent.length} characters for performance]`;
    }
    
    // Normal reduction for moderately long inputs
    console.log(`[Performance] Reducing input size from ${inputContent.length} chars to ~${maxInputLength}`);
    return inputContent.substring(0, maxInputLength) + `\n\n[Note: Input was truncated from ${inputContent.length} characters for performance]`;
  }
  
  /**
   * Get the primary template type for a domain
   */
  private getPrimaryTemplateForDomain(domainName: string): string {
    // Just return the most valuable template for each domain
    switch (domainName) {
      case "Organizational Development and Alignment":
        return "Organizational Alignment Framework";
      case "Strategic Framework & Governance":
        return "PMO Charter Template";
      case "PMO Structure & Design":
        return "PMO Structure Template";
      case "Operational Excellence":
        return "PMO Process Framework";
      case "Performance & Improvement":
        return "Continuous Improvement Plan";
      case "Capability Development":
        return "PMO Competency Framework";
      default:
        return `${domainName} Implementation Guide`;
    }
  }

  /**
   * Generate a cache key from inputs
   */
  private generateCacheKey(domainName: string, inputContent: string, userMaturityLevel?: string): string {
    // Create a consistent cache key from the input parameters
    const inputHash = this.simpleHash(inputContent.substring(0, 500)); // Only hash the first 500 chars for stability
    return `${domainName}-${inputHash}`;
  }
  
  /**
   * Create a simple hash of a string
   */
  private simpleHash(str: string): number {
    let hash = 0;
    if (str.length === 0) return hash;
    
    for (let i = 0; i < Math.min(100, str.length); i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32bit integer
    }
    
    return Math.abs(hash);
  }

  /**
   * Get item from cache
   */
  private getCachedItem(key: string): any {
    // Check memory cache first (fastest)
    if (this.memoryCache.has(key)) {
      const expiry = this.cacheExpiry.get(key);
      if (expiry && expiry > Date.now()) {
        return this.memoryCache.get(key);
      } else {
        // Clean up expired item
        this.memoryCache.delete(key);
        this.cacheExpiry.delete(key);
      }
    }
    
    // Then check localStorage
    try {
      const cachedData = localStorage.getItem(`openai-${key}`);
      if (cachedData) {
        const parsed = JSON.parse(cachedData);
        if (parsed.expiry && parsed.expiry > Date.now()) {
          this.memoryCache.set(key, parsed.data);
          this.cacheExpiry.set(key, parsed.expiry);
          return parsed.data;
        } else {
          localStorage.removeItem(`openai-${key}`);
        }
      }
    } catch (error) {
      console.warn('Error reading from cache:', error);
    }
    
    return null;
  }

  /**
   * Set item in cache
   */
  private setCachedItem(key: string, value: any): void {
    try {
      const expiry = Date.now() + this.cacheTTL;
      
      // Set in memory cache
      this.memoryCache.set(key, value);
      this.cacheExpiry.set(key, expiry);
      
      // Set in localStorage
      localStorage.setItem(`openai-${key}`, JSON.stringify({
        data: value,
        expiry
      }));
    } catch (error) {
      console.warn('Error setting cache:', error);
    }
  }

  /**
   * Get fallback template content
   */
  private getFallbackTemplateContent(domainName: string, templateType: string): string {
    return `# ${templateType}

## Purpose
This template provides a structured framework for ${domainName.toLowerCase()}.

## Key Components

1. **Overview**
   - Purpose and objectives
   - Stakeholders and roles
   - Success criteria

2. **Implementation Guidelines**
   - Assessment phase
   - Design phase
   - Implementation phase
   - Review phase

3. **Key Elements**
   - Required documentation
   - Governance structure
   - Performance metrics
   - Continuous improvement

## How to Use This Template
1. Review all sections
2. Customize for your organization
3. Involve key stakeholders
4. Update periodically

---

*Note: This template should be adapted to your specific organizational needs and context.*`;
  }

  /**
   * Generate a fallback analysis
   */
  private getFallbackAnalysis(domainName: string, domainDescription: string): {content: string, templates: {name: string, content: string}[]} {
    const analysisContent = `# ${domainName} Analysis

## Executive Summary
This analysis provides recommendations for improving your organization's ${domainName.toLowerCase()}. Enhancing capabilities in this area will strengthen your PMO's effectiveness and drive better project outcomes.

## Key Recommendations
1. **Document Current Processes**: Create documentation for existing practices
2. **Establish Standards**: Develop consistent methods across the organization
3. **Implement Training**: Build capabilities through training
4. **Define Metrics**: Create clear KPIs to measure effectiveness
5. **Continuous Improvement**: Set up regular assessment mechanisms

## Implementation Approach
- **Phase 1**: Assessment (Weeks 1-4)
- **Phase 2**: Design (Weeks 5-8)
- **Phase 3**: Implementation (Weeks 9-16)
- **Phase 4**: Monitoring and Improvement (Ongoing)

## Next Steps
Begin with a comprehensive assessment of your current ${domainName.toLowerCase()} practices.`;

    // Create a basic template
    const templateType = this.getPrimaryTemplateForDomain(domainName);
    const template = {
      name: templateType,
      content: this.getFallbackTemplateContent(domainName, templateType)
    };
    
    return {
      content: analysisContent,
      templates: [template]
    };
  }
}

// Export a singleton instance
export const openaiService = new OpenAIService();