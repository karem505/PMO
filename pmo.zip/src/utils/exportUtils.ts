import { jsPDF } from 'jspdf';

export const exportToPdf = async (markdownContent: string, filename: string, onComplete?: () => void) => {
  try {
    console.log('Using direct PDF export method...');

    // Get current language
    const isRTL = document.documentElement.dir === 'rtl';

    // Create PDF with RTL support if needed
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });
    
    // Set font to support Arabic if needed
    if (isRTL) {
      pdf.addFont('https://fonts.gstatic.com/s/cairo/v28/SLXgc1nY6HkvangtZmpQdkhzfH5lkSs2SgRjCAGMQ1z0hOA-a1PiQR3QIH0.woff2', 'Cairo', 'normal');
      pdf.setFont('Cairo');
      pdf.setR2L(true);
    }
    
    // Extract title from markdown
    let title = filename.replace(/\.pdf$/, '').replace(/-/g, ' ');
    const h1Match = markdownContent.match(/^# (.*?)$/m);
    if (h1Match && h1Match[1]) {
      title = h1Match[1];
    }
    
    // Brand colors
    const primaryColor = [95, 45, 248]; // RGB for primary-600
    const secondaryColor = [217, 32, 143]; // RGB for secondary-600
    
    // Add cover page
    pdf.setFillColor(255, 255, 255);
    pdf.rect(0, 0, 210, 297, 'F');
    
    // Add gradient-like header
    for (let i = 0; i < 40; i++) {
      const ratio = i / 40;
      pdf.setDrawColor(
        Math.floor(primaryColor[0] * (1 - ratio) + secondaryColor[0] * ratio),
        Math.floor(primaryColor[1] * (1 - ratio) + secondaryColor[1] * ratio),
        Math.floor(primaryColor[2] * (1 - ratio) + secondaryColor[2] * ratio)
      );
      pdf.setLineWidth(0.5);
      pdf.line(0, i, 210, i);
    }
    
    // Add title
    pdf.setTextColor(40, 40, 40);
    pdf.setFontSize(28);
    const titleX = isRTL ? 190 : 20;
    const titleAlign = isRTL ? 'right' : 'left';
    pdf.text(title, titleX, 80, { align: titleAlign, maxWidth: 170 });
    
    // Add subtitle
    pdf.setFontSize(18);
    pdf.setTextColor(80, 80, 80);
    const subtitleText = isRTL ? 'تقرير شامل لتنفيذ مكتب إدارة المشاريع' : 'Comprehensive PMO Implementation Report';
    pdf.text(subtitleText, titleX, 95, { align: titleAlign });
    
    // Add date
    pdf.setFontSize(12);
    const date = new Date().toLocaleDateString(isRTL ? 'ar-SA' : 'en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
    const generatedText = isRTL ? `تم الإنشاء: ${date}` : `Generated: ${date}`;
    pdf.text(generatedText, titleX, 110, { align: titleAlign });
    
    // Add decorative line
    pdf.setDrawColor(...primaryColor);
    pdf.setLineWidth(1);
    if (isRTL) {
      pdf.line(20, 120, 190, 120);
    } else {
      pdf.line(20, 120, 190, 120);
    }
    
    // Add company info
    pdf.setFontSize(10);
    pdf.setTextColor(100, 100, 100);
    const copyright = isRTL ? '© بناء مكتب إدارة المشاريع باستخدام الذكاء الاصطناعي' : '© PMO Builder using AI by Dr. Ahmed Alsenosy';
    pdf.text(copyright, isRTL ? 190 : 20, 280, { align: titleAlign });
    
    // Parse the markdown into sections for TOC
    const sections = [];
    const mainContent = markdownContent.split(/^## /m);
    const mainTitle = mainContent.shift(); // Remove main title
    
    mainContent.forEach((section, index) => {
      const sectionTitle = section.split('\n')[0].trim();
      sections.push({
        title: sectionTitle,
        pageNumber: index + 3 // Cover + TOC + content pages
      });
    });
    
    // Add TOC page
    pdf.addPage();
    
    // Add header
    pdf.setFillColor(245, 245, 250);
    pdf.rect(0, 0, 210, 15, 'F');
    
    pdf.setFontSize(8);
    pdf.setTextColor(100, 100, 100);
    pdf.text(title, isRTL ? 190 : 20, 10, { align: titleAlign });
    
    // Add TOC title
    pdf.setFontSize(18);
    pdf.setTextColor(...primaryColor);
    const tocTitle = isRTL ? "جدول المحتويات" : "Table of Contents";
    pdf.text(tocTitle, isRTL ? 190 : 20, 30, { align: titleAlign });
    
    // Add TOC entries
    pdf.setFontSize(12);
    pdf.setTextColor(80, 80, 80);
    
    sections.forEach((section, index) => {
      const y = 40 + (index * 8);
      if (y < 270) { // Ensure we don't go beyond the page
        if (isRTL) {
          pdf.text(`${section.title}`, 160, y, { align: 'right' });
          pdf.text(`${section.pageNumber}`, 20, y, { align: 'left' });
        } else {
          pdf.text(`${index + 1}. ${section.title}`, 20, y);
          pdf.text(`${section.pageNumber}`, 180, y);
        }
      }
    });
    
    // Add footer
    pdf.setFillColor(245, 245, 250);
    pdf.rect(0, 282, 210, 15, 'F');
    
    pdf.setFontSize(8);
    const footerCopyright = isRTL ? '© بناء مكتب إدارة المشاريع باستخدام الذكاء الاصطناعي' : '© PMO Builder AI';
    const footerPage = isRTL ? `صفحة 2` : `Page 2`;
    pdf.text(footerCopyright, isRTL ? 190 : 20, 290, { align: titleAlign });
    pdf.text(footerPage, isRTL ? 20 : 180, 290, { align: isRTL ? 'left' : 'right' });
    
    // Process each section
    mainContent.forEach((section, index) => {
      // Add new page for each section
      pdf.addPage();

      // Add header
      pdf.setFillColor(245, 245, 250);
      pdf.rect(0, 0, 210, 15, 'F');

      pdf.setFontSize(8);
      pdf.setTextColor(100, 100, 100);
      pdf.text(title, isRTL ? 190 : 20, 10, { align: titleAlign });

      // Add section content
      const sectionTitle = section.split('\n')[0].trim();
      const sectionContent = section.substring(sectionTitle.length).trim();

      // Add section title
      pdf.setFontSize(18);
      pdf.setTextColor(...primaryColor);
      pdf.text(`${sectionTitle}`, isRTL ? 190 : 20, 30, { align: titleAlign });

      // Add section content with word wrap
      pdf.setFontSize(11);
      pdf.setTextColor(60, 60, 60);

      // Split content into paragraphs
      const paragraphs = sectionContent.split('\n\n');
      let yPosition = 40;

      for (const paragraph of paragraphs) {
        // Skip empty paragraphs
        if (!paragraph.trim()) continue;

        // Check if we need a new page
        if (yPosition > 260) {
          // Add footer to current page
          pdf.setFillColor(245, 245, 250);
          pdf.rect(0, 282, 210, 15, 'F');

          pdf.setFontSize(8);
          pdf.setTextColor(100, 100, 100);
          pdf.text(footerCopyright, isRTL ? 190 : 20, 290, { align: titleAlign });
          const pageNum = isRTL ? `صفحة ${pdf.getNumberOfPages()}` : `Page ${pdf.getNumberOfPages()}`;
          pdf.text(pageNum, isRTL ? 20 : 180, 290, { align: isRTL ? 'left' : 'right' });

          // Add new page
          pdf.addPage();

          // Add header to new page
          pdf.setFillColor(245, 245, 250);
          pdf.rect(0, 0, 210, 15, 'F');

          pdf.setFontSize(8);
          pdf.setTextColor(100, 100, 100);
          pdf.text(title, isRTL ? 190 : 20, 10, { align: titleAlign });

          // Reset y position
          yPosition = 30;

          // Restore text properties
          pdf.setFontSize(11);
          pdf.setTextColor(60, 60, 60);
        }

        // Handle different paragraph types
        if (paragraph.startsWith('### ')) {
          // Subheading
          pdf.setFontSize(14);
          pdf.setTextColor(...primaryColor);
          const subheading = paragraph.substring(4).trim();
          pdf.text(subheading, isRTL ? 190 : 20, yPosition, { align: titleAlign });
          yPosition += 8;

          // Restore text properties
          pdf.setFontSize(11);
          pdf.setTextColor(60, 60, 60);
        } else if (paragraph.startsWith('- ')) {
          // Bullet points
          const listItems = paragraph.split('\n');
          for (const item of listItems) {
            if (item.trim().startsWith('- ')) {
              const listItemText = item.substring(2).trim();
              const textLines = pdf.splitTextToSize(listItemText, 160);

              // Add bullet point
              pdf.text('•', isRTL ? 170 : 20, yPosition);

              // Add list item text with indent
              pdf.text(textLines, isRTL ? 160 : 25, yPosition, { align: isRTL ? 'right' : 'left' });

              // Move down based on number of lines
              yPosition += 5 * textLines.length;
            }
          }
        } else if (paragraph.includes('|')) {
          // Likely a table, handle as text
          const tableLines = paragraph.split('\n');
          for (const line of tableLines) {
            const cleanLine = line.replace(/\|/g, ' | ').trim();
            const textLines = pdf.splitTextToSize(cleanLine, 170);
            pdf.text(textLines, isRTL ? 190 : 20, yPosition, { align: titleAlign });
            yPosition += 5 * textLines.length;
          }
        } else {
          // Regular paragraph
          const textLines = pdf.splitTextToSize(paragraph, 170);
          pdf.text(textLines, isRTL ? 190 : 20, yPosition, { align: titleAlign });
          yPosition += 5 * textLines.length;
        }

        // Add space between paragraphs
        yPosition += 5;
      }

      // Add footer to the last page
      pdf.setFillColor(245, 245, 250);
      pdf.rect(0, 282, 210, 15, 'F');
      
      pdf.setFontSize(8);
      pdf.setTextColor(100, 100, 100);
      pdf.text(footerCopyright, isRTL ? 190 : 20, 290, { align: titleAlign });
      const pageNum = isRTL ? `صفحة ${pdf.getNumberOfPages()}` : `Page ${pdf.getNumberOfPages()}`;
      pdf.text(pageNum, isRTL ? 20 : 180, 290, { align: isRTL ? 'left' : 'right' });
    });
    
    // Save the PDF
    pdf.save(filename);
    
    if (onComplete) {
      onComplete();
    }
  } catch (error) {
    console.error('Direct PDF export error:', error);

    // Fallback to plain text download
    try {
      const element = document.createElement('a');
      const file = new Blob([markdownContent], {type: 'text/plain'});
      element.href = URL.createObjectURL(file);
      element.download = filename.replace('.pdf', '.txt');
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
    } catch (fallbackError) {
      console.error('Fallback text download failed:', fallbackError);
    }

    if (onComplete) {
      onComplete();
    }
  }
};