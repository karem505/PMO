// Utility functions for document processing
import { v4 as uuidv4 } from 'uuid';

/**
 * Creates a deterministic hash of a string (for cache keys)
 */
export function hashString(str: string): string {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32bit integer
  }
  return Math.abs(hash).toString(36);
}

/**
 * Interface representing a chunk of a document
 */
export interface DocumentChunk {
  id: string;
  documentId: string;
  content: string;
  metadata: {
    chunkIndex: number;
    charStart: number;
    charEnd: number;
    tokenCount?: number;
    pageNumber?: number;
    source?: string;
    domainId?: number;
  };
}

/**
 * Interface representing a processed document
 */
export interface ProcessedDocument {
  id: string;
  fileName: string;
  fileType: string;
  totalChunks: number;
  chunks: DocumentChunk[];
  metadata: Record<string, any>;
  createdAt: string;
  updatedAt: string;
  projectId?: string;
  userId?: string;
  domainId?: number;
}

/**
 * Chunks a document into smaller pieces for processing
 * @param text The full document text to split into chunks
 * @param fileName The name of the document
 * @param fileType The type of the document
 * @returns A ProcessedDocument object
 */
export function chunkDocument(
  text: string,
  fileName: string,
  fileType: string = 'text'
): ProcessedDocument {
  if (!text) {
    return {
      id: uuidv4(),
      fileName,
      fileType,
      totalChunks: 0,
      chunks: [],
      metadata: {},
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
  }
  
  const chunks: DocumentChunk[] = [];
  let startIndex = 0;
  let chunkIndex = 0;
  const chunkSize = 1000;
  const overlap = 200;
  const documentId = uuidv4();
  
  while (startIndex < text.length) {
    // Calculate end index with potential overlap
    let endIndex = Math.min(startIndex + chunkSize, text.length);
    
    // If we're not at the end of the text and not at a whitespace, look for a better break point
    if (endIndex < text.length && text[endIndex] !== ' ') {
      // Find the last whitespace within the chunk to make a cleaner break
      const lastWhitespace = text.lastIndexOf(' ', endIndex);
      if (lastWhitespace > startIndex) {
        endIndex = lastWhitespace;
      }
    }
    
    const content = text.substring(startIndex, endIndex).trim();
    
    // Only add chunk if it has content
    if (content) {
      chunks.push({
        id: uuidv4(),
        documentId,
        content,
        metadata: {
          chunkIndex,
          charStart: startIndex,
          charEnd: endIndex,
          tokenCount: content.split(/\s+/).length, // Simple token count as words
          source: fileName
        }
      });
    }
    
    // Move to next chunk with overlap
    startIndex = endIndex - overlap > startIndex ? endIndex - overlap : startIndex + 1;
    chunkIndex++;
  }
  
  return {
    id: documentId,
    fileName,
    fileType,
    totalChunks: chunks.length,
    chunks,
    metadata: {
      charCount: text.length,
      wordCount: text.split(/\s+/).filter(Boolean).length
    },
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
}

/**
 * Creates a simple index of terms from document chunks
 * @param chunks Array of document chunks to index
 * @returns An object mapping terms to chunk IDs
 */
export function createSimpleIndex(chunks: DocumentChunk[]): Record<string, string[]> {
  const index: Record<string, string[]> = {};
  
  for (const chunk of chunks) {
    // Get unique terms from the chunk (simple tokenization)
    const terms = [...new Set(
      chunk.content
        .toLowerCase()
        .replace(/[^\w\s]/g, '')
        .split(/\s+/)
        .filter(term => term.length > 3)
    )];
    
    // Add chunk ID to each term in the index
    for (const term of terms) {
      if (!index[term]) {
        index[term] = [];
      }
      index[term].push(chunk.id);
    }
  }
  
  return index;
}

/**
 * Search document chunks for relevant content
 * @param query Search query
 * @param chunks Array of document chunks to search
 * @param maxResults Maximum number of results to return
 * @returns Array of relevant document chunks
 */
export function searchChunks(
  query: string,
  chunks: DocumentChunk[],
  maxResults: number = 5
): DocumentChunk[] {
  // Simple keyword extraction from query
  const queryTerms = query
    .toLowerCase()
    .replace(/[^\w\s]/g, '')
    .split(/\s+/)
    .filter(term => term.length > 3);
  
  if (queryTerms.length === 0) return [];
  
  // Score each chunk based on term frequency
  const scoredChunks = chunks.map(chunk => {
    const content = chunk.content.toLowerCase();
    let score = 0;
    
    for (const term of queryTerms) {
      // Count occurrences of the term in the chunk
      const regex = new RegExp(term, 'gi');
      const matches = content.match(regex);
      if (matches) {
        score += matches.length;
      }
    }
    
    return { chunk, score };
  });
  
  // Sort by score and return top results
  return scoredChunks
    .filter(item => item.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, maxResults)
    .map(item => item.chunk);
}