import { supabase } from '../services/supabaseClient';

// Only expose these functions in development mode
if (import.meta.env.DEV) {
  // Attach to window for console access
  (window as any).devAuth = {
    // Sign in with email without redirect
    async signInDev(email: string, password: string) {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
      });
      
      if (error) {
        console.error('Dev sign-in failed:', error);
        return null;
      }
      
      console.log('Dev sign-in successful:', data.user);
      window.location.href = '/dashboard';
      return data;
    },
    
    // Create session directly with user ID
    async fakeSession(userId: string = 'your-user-id-here') {
      // This forces a new auth session in Supabase's local storage
      const projectRef = import.meta.env.VITE_SUPABASE_URL.split('//')[1].split('.')[0];
      localStorage.setItem(`sb-${projectRef}-auth-token`, 
        JSON.stringify({
          currentSession: {
            access_token: 'fake-token',
            refresh_token: 'fake-refresh',
            user: { id: userId, email: 'dev@example.com' }
          },
          expiresAt: Date.now() + 3600000
        })
      );
      
      console.log('Fake session created for user ID:', userId);
      window.location.reload();
    }
  };
  
  console.log('🔧 Dev auth helpers loaded. Use window.devAuth.signInDev(email, password) or window.devAuth.fakeSession(userId)');
}

export {}; 