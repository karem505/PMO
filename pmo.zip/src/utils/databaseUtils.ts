import { supabase } from '../services/supabaseClient';
import { validateData } from '../services/schemaValidationService';
import { z } from 'zod';

/**
 * Utility functions for safe database operations with validation
 */

/**
 * Execute a database select query with validation and error handling
 */
export const safeSelect = async <T extends z.ZodType>(
  table: string,
  schema: T,
  options: {
    columns?: string;
    filter?: Record<string, any>;
    limit?: number;
    order?: Record<string, any>;
    single?: boolean;
  } = {}
): Promise<{ data: z.infer<T>[] | null; error: string | null }> => {
  try {
    // Start building query
    let query = supabase.from(table).select(options.columns || '*');
    
    // Add filters if specified
    if (options.filter) {
      for (const [key, value] of Object.entries(options.filter)) {
        if (value !== undefined) {
          if (key.includes('.')) {
            // Handle complex filters like 'column.in'
            const [column, operator] = key.split('.');
            if (operator === 'in') {
              query = query.in(column, value as any[]);
            } else if (operator === 'eq') {
              query = query.eq(column, value);
            } else if (operator === 'neq') {
              query = query.neq(column, value);
            } else if (operator === 'gt') {
              query = query.gt(column, value);
            } else if (operator === 'gte') {
              query = query.gte(column, value);
            } else if (operator === 'lt') {
              query = query.lt(column, value);
            } else if (operator === 'lte') {
              query = query.lte(column, value);
            } else if (operator === 'like') {
              query = query.like(column, value as string);
            } else if (operator === 'ilike') {
              query = query.ilike(column, value as string);
            }
          } else {
            // Simple equality filter
            query = query.eq(key, value);
          }
        }
      }
    }
    
    // Add limit if specified
    if (options.limit) {
      query = query.limit(options.limit);
    }
    
    // Add ordering if specified
    if (options.order) {
      for (const [column, direction] of Object.entries(options.order)) {
        query = query.order(column, { ascending: direction === 'asc' });
      }
    }
    
    // Execute query
    const { data, error } = options.single 
      ? await query.single() 
      : await query;
    
    if (error) {
      throw error;
    }
    
    // Validate data
    const validatedData = options.single && data
      ? validateData(schema, data)
      : Array.isArray(data) 
        ? data.map(item => validateData(schema, item))
        : [];
    
    // Handle validation errors
    if (options.single) {
      if (validatedData && !validatedData.success) {
        return { data: null, error: `Validation error: ${validatedData.error}` };
      }
      return { 
        data: validatedData.success && validatedData.data ? [validatedData.data] : null, 
        error: null 
      };
    } else {
      const errors = Array.isArray(validatedData) 
        ? validatedData.filter(v => !v.success).map(v => v.error)
        : [];
      
      if (errors.length > 0) {
        return { data: null, error: `Validation error: ${errors.join(', ')}` };
      }
      
      return { 
        data: Array.isArray(validatedData) 
          ? validatedData.filter(v => v.success).map(v => v.data) as z.infer<T>[]
          : null, 
        error: null 
      };
    }
  } catch (error) {
    console.error(`Error in safeSelect from ${table}:`, error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    return { data: null, error: errorMessage };
  }
};

/**
 * Execute a database insert operation with validation and error handling
 */
export const safeInsert = async <T extends z.ZodType>(
  table: string,
  schema: T,
  data: unknown,
  options: {
    returning?: boolean;
  } = { returning: true }
): Promise<{ data: z.infer<T> | null; error: string | null }> => {
  try {
    // Validate data against schema
    const validation = validateData(schema, data);
    
    if (!validation.success) {
      return { data: null, error: `Validation error: ${validation.error}` };
    }
    
    // Perform insert operation
    const { data: result, error } = options.returning
      ? await supabase.from(table).insert([validation.data]).select().single()
      : await supabase.from(table).insert([validation.data]);
    
    if (error) {
      throw error;
    }
    
    return { data: result as z.infer<T> || null, error: null };
  } catch (error) {
    console.error(`Error in safeInsert to ${table}:`, error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    return { data: null, error: errorMessage };
  }
};

/**
 * Execute a database update operation with validation and error handling
 */
export const safeUpdate = async <T extends z.ZodType>(
  table: string,
  schema: T, 
  data: unknown,
  filter: Record<string, any>,
  options: {
    returning?: boolean;
  } = { returning: true }
): Promise<{ data: z.infer<T> | null; error: string | null }> => {
  try {
    // For updates, we only validate the fields being updated (partial)
    const partialSchema = schema.partial();
    const validation = validateData(partialSchema, data);
    
    if (!validation.success) {
      return { data: null, error: `Validation error: ${validation.error}` };
    }
    
    // Start building query
    let query = supabase.from(table).update(validation.data);
    
    // Add filters
    for (const [key, value] of Object.entries(filter)) {
      if (value !== undefined) {
        query = query.eq(key, value);
      }
    }
    
    // Execute query
    const { data: result, error } = options.returning
      ? await query.select().single()
      : await query;
    
    if (error) {
      throw error;
    }
    
    return { data: result as z.infer<T> || null, error: null };
  } catch (error) {
    console.error(`Error in safeUpdate to ${table}:`, error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    return { data: null, error: errorMessage };
  }
};

/**
 * Execute a database upsert operation with validation and error handling
 */
export const safeUpsert = async <T extends z.ZodType>(
  table: string,
  schema: T,
  data: unknown,
  onConflict: string,
  options: {
    returning?: boolean;
  } = { returning: true }
): Promise<{ data: z.infer<T> | null; error: string | null }> => {
  try {
    // Validate data against schema
    const validation = validateData(schema, data);
    
    if (!validation.success) {
      return { data: null, error: `Validation error: ${validation.error}` };
    }
    
    // Perform upsert operation
    const { data: result, error } = options.returning
      ? await supabase
          .from(table)
          .upsert([validation.data], { onConflict, ignoreDuplicates: false })
          .select()
          .single()
      : await supabase
          .from(table)
          .upsert([validation.data], { onConflict, ignoreDuplicates: false });
    
    if (error) {
      throw error;
    }
    
    return { data: result as z.infer<T> || null, error: null };
  } catch (error) {
    console.error(`Error in safeUpsert to ${table}:`, error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    return { data: null, error: errorMessage };
  }
};

/**
 * Execute a database delete operation with error handling
 */
export const safeDelete = async (
  table: string,
  filter: Record<string, any>
): Promise<{ success: boolean; error: string | null }> => {
  try {
    // Start building query
    let query = supabase.from(table).delete();
    
    // Add filters
    for (const [key, value] of Object.entries(filter)) {
      if (value !== undefined) {
        query = query.eq(key, value);
      }
    }
    
    // Execute query
    const { error } = await query;
    
    if (error) {
      throw error;
    }
    
    return { success: true, error: null };
  } catch (error) {
    console.error(`Error in safeDelete from ${table}:`, error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    return { success: false, error: errorMessage };
  }
};

/**
 * Execute a transaction with multiple operations and rollback on errors
 */
export const safeTransaction = async <T>(
  operations: (() => Promise<any>)[],
  onSuccess?: (results: any[]) => T
): Promise<{ data: T | null; error: string | null }> => {
  // Note: Supabase doesn't directly support transactions in the client.
  // This is a basic implementation that tries to perform operations in sequence
  // and manages errors manually.
  
  const results: any[] = [];
  
  try {
    for (const operation of operations) {
      const result = await operation();
      results.push(result);
      
      // If any operation returns an object with an error property, abort
      if (result && result.error) {
        throw new Error(result.error);
      }
    }
    
    // Call onSuccess if all operations succeeded
    const finalResult = onSuccess ? onSuccess(results) : results;
    return { data: finalResult as T, error: null };
  } catch (error) {
    console.error('Transaction failed:', error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    return { data: null, error: errorMessage };
  }
};