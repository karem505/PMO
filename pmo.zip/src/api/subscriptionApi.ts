import apiClient from './client';
import { Subscription, SubscriptionTier } from '../services/subscriptionService';

// Cache for subscription data to avoid redundant calls
let subscriptionCache: {
  data: Subscription | null;
  timestamp: number;
} | null = null;

const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

// Map backend tier to frontend SubscriptionTier
const mapBackendTier = (backendTier: string): SubscriptionTier => {
  switch (backendTier.toLowerCase()) {
    case 'pro':
      return SubscriptionTier.PREMIUM;
    case 'enterprise':
      return SubscriptionTier.ENTERPRISE;
    case 'free':
    default:
      return SubscriptionTier.FREE;
  }
};

// API functions for subscription management
export const subscriptionApi = {
  // Get user's subscription from backend
  async getUserSubscription(userId: string): Promise<Subscription | null> {
    try {
      // Check cache first
      if (subscriptionCache && Date.now() - subscriptionCache.timestamp < CACHE_DURATION) {
        return subscriptionCache.data;
      }

      const userEmail = localStorage.getItem('userEmail');
      if (!userEmail) {
        console.warn('No user email found in localStorage');
        return null;
      }

      console.log('DEBUG: Fetching fresh subscription data from backend');
      const response = await apiClient.get(`/subscription/status?user_email=${encodeURIComponent(userEmail)}`);
      console.log('DEBUG: Backend response:', response.data);
      
      if (response.data) {
        const subscription: Subscription = {
          user_id: userId,
          tier: mapBackendTier(response.data.tier || 'free'),
          status: 'active' as const,
          cancel_at_period_end: false,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        };

        console.log('DEBUG: Created subscription object:', subscription);

        // Update cache
        subscriptionCache = {
          data: subscription,
          timestamp: Date.now()
        };

        return subscription;
      }
      return null;
    } catch (error) {
      console.error('Error getting user subscription:', error);
      return null;
    }
  },

  // Initialize subscription for a new user
  async initializeUserSubscription(userId: string): Promise<Subscription | null> {
    try {
      const userEmail = localStorage.getItem('userEmail');
      if (!userEmail) {
        console.warn('No user email found in localStorage');
        return null;
      }
      
      const response = await apiClient.post('/subscription/setup-free', { user_email: userEmail });
      
      if (response.data) {
        const subscription: Subscription = {
          user_id: userId,
          tier: SubscriptionTier.FREE,
          status: 'active' as const,
          payment_provider: 'none',
          cancel_at_period_end: false,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        };

        // Update cache
        subscriptionCache = {
          data: subscription,
          timestamp: Date.now()
        };

        return subscription;
      }
      return null;
    } catch (error) {
      console.error('Error initializing user subscription:', error);
      return null;
    }
  },

  // Update subscription tier
  async updateSubscriptionTier(
    userId: string, 
    tier: SubscriptionTier,
    paymentProvider?: string,
    paymentId?: string
  ): Promise<Subscription | null> {
    try {
      const userEmail = localStorage.getItem('userEmail');
      if (!userEmail) {
        console.error('No user email found in localStorage');
        return null;
      }
      
      // Clear the cache before making the update
      subscriptionCache = null;
      
      // Map frontend tier to backend tier
      const backendTier = tier === SubscriptionTier.PREMIUM ? 'pro' : tier.toLowerCase();
      
      console.log('DEBUG: Updating subscription tier to:', backendTier);
      const response = await apiClient.post('/subscription/set', {
        user_email: userEmail,
        tier: backendTier,
        payment_provider: paymentProvider,
        payment_id: paymentId
      });
      
      console.log('DEBUG: Update response:', response.data);
      
      if (response.data) {
        const subscription = {
          user_id: userId,
          tier,
          status: 'active',
          payment_provider: paymentProvider as any,
          payment_id: paymentId,
          cancel_at_period_end: false,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        };
        
        // Update cache with new data
        subscriptionCache = {
          data: subscription,
          timestamp: Date.now()
        };

        return subscription;
      }
      return null;
    } catch (error) {
      console.error('Error updating subscription tier:', error);
      return null;
    }
  },

  // Get feature usage
  async getFeatureUsage(userId: string, feature: string): Promise<number> {
    try {
      const userEmail = localStorage.getItem('userEmail');
      if (!userEmail) {
        return 0;
      }
      
      // Clear cache to get fresh data
      subscriptionCache = null;
      
      const response = await apiClient.get(`/subscription/status?user_email=${encodeURIComponent(userEmail)}`);
      
      if (response.data) {
        // For token-based features
        if (feature === 'tokens' || feature === 'aiAnalysis') {
          return response.data.remaining_tokens || 0;
        }
        
        // Mock values for other features until backend fully supports all feature types
        return 0;
      }
      return 0;
    } catch (error) {
      console.error(`Error getting ${feature} usage:`, error);
      return 0;
    }
  },

  // Increment feature usage
  async incrementUsage(userId: string, feature: string): Promise<boolean> {
    // This will need to be implemented on the backend later
    // Currently just returning true as a placeholder
    return true;
  },

  // Clear subscription cache
  clearCache() {
    subscriptionCache = null;
  }
}; 