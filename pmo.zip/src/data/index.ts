import { Domain, Task } from '../types';
import { 
  BarChart4, 
  Building2, 
  Cog, 
  LineChart, 
  Workflow,
  Users,
  Briefcase,
  Layout,
  Settings,
  Target,
  Layers,
  Scale
} from 'lucide-react';

export const domains: Domain[] = [
  {
    id: 1,
    name: "Organizational Development and Alignment",
    description: "Aligning the PMO with organizational strategy and culture to ensure effective project management practices.",
    icon: "Building2"
  },
  {
    id: 2,
    name: "Strategic Framework & Governance",
    description: "Developing and implementing strategic frameworks, roadmaps, and governance structures.",
    icon: "Scale"
  },
  {
    id: 3,
    name: "PMO Structure & Design",
    description: "Creating the optimal PMO structure, roles, and responsibilities to meet organizational needs.",
    icon: "Layers"
  },
  {
    id: 4,
    name: "Operational Excellence",
    description: "Establishing operational processes, KPIs, and performance metrics for the PMO.",
    icon: "Settings"
  },
  {
    id: 5,
    name: "Performance & Improvement",
    description: "Continuously improving PMO services, capabilities, and value delivery.",
    icon: "Target"
  },
  {
    id: 6,
    name: "Capability Development",
    description: "Developing and managing the human aspects of the PMO including competency, training, and leadership.",
    icon: "Users"
  }
];

export const tasks: Task[] = [
  // Domain 1: Organizational Development and Alignment
  // INPUTS: Data collection, assessment, and information gathering
  {
    id: "1-input-1",
    domainId: 1,
    domainName: "Organizational Development and Alignment",
    stage: "input",
    title: "Assess Current Competencies",
    description: "Gather data on existing competencies through surveys, interviews, and documentation review.",
    completed: false,
    bestPractices: [
      "Use standardized assessment tools to evaluate current competencies",
      "Collect input from multiple organizational levels",
      "Document both technical and soft skill competencies",
      "Identify competency gaps through structured assessment"
    ]
  },
  {
    id: "1-input-2",
    domainId: 1,
    domainName: "Organizational Development and Alignment",
    stage: "input",
    title: "Assess Organizational Culture",
    description: "Collect data on current organizational culture through surveys, focus groups, and stakeholder interviews.",
    completed: false,
    bestPractices: [
      "Conduct culture assessment surveys",
      "Gather feedback from diverse organizational levels",
      "Document cultural enablers and barriers to project management",
      "Collect historical data on cultural change initiatives"
    ]
  },
  {
    id: "1-input-3",
    domainId: 1,
    domainName: "Organizational Development and Alignment",
    stage: "input",
    title: "Benchmark Against Industry Standards",
    description: "Collect industry benchmarking data and best practices for organizational alignment.",
    completed: false,
    bestPractices: [
      "Select relevant industry benchmarks and standards",
      "Gather data from industry reports and publications",
      "Document peer organization practices",
      "Collect metrics for comparative analysis"
    ]
  },
  // PROCESSING: Analysis, tools, techniques, and methodologies
  {
    id: "1-processing-1",
    domainId: 1,
    domainName: "Organizational Development and Alignment",
    stage: "processing",
    title: "Apply Strategic Analysis Techniques",
    description: "Use strategic analysis tools to develop an integrated strategy with risk management and implementation roadmap.",
    completed: false,
    bestPractices: [
      "Apply SWOT analysis to identify strengths and weaknesses",
      "Use gap analysis to identify improvement areas",
      "Apply risk assessment methodologies",
      "Use roadmapping techniques for implementation planning"
    ]
  },
  {
    id: "1-processing-2",
    domainId: 1,
    domainName: "Organizational Development and Alignment",
    stage: "processing",
    title: "Apply Communication Planning Methodologies",
    description: "Use communication planning techniques to develop stakeholder-specific messaging and feedback mechanisms.",
    completed: false,
    bestPractices: [
      "Apply stakeholder analysis techniques",
      "Use communication matrix development methods",
      "Apply message tailoring methodologies",
      "Use KPI development frameworks for communication effectiveness"
    ]
  },
  {
    id: "1-processing-3",
    domainId: 1,
    domainName: "Organizational Development and Alignment",
    stage: "processing",
    title: "Apply Charter Development Techniques",
    description: "Use charter development methodologies to define PMO scope, authority, and governance structure.",
    completed: false,
    bestPractices: [
      "Apply scope definition techniques",
      "Use RACI matrix development methods",
      "Apply governance framework design methodologies",
      "Use authority mapping techniques"
    ],
    templates: ["PMO Charter Template", "RACI Matrix"]
  },
  // OUTPUTS: Deliverables, implementation, and tangible results
  {
    id: "1-output-1",
    domainId: 1,
    domainName: "Organizational Development and Alignment",
    stage: "output",
    title: "Deliver Integrated Strategy and Roadmap",
    description: "Produce and implement the integrated strategy with risk management plan and phased implementation roadmap.",
    completed: false,
    bestPractices: [
      "Document comprehensive strategy with clear objectives",
      "Create detailed implementation roadmap with milestones",
      "Develop risk management plan with mitigation strategies",
      "Establish strategy review and update mechanisms"
    ]
  },
  {
    id: "1-output-2",
    domainId: 1,
    domainName: "Organizational Development and Alignment",
    stage: "output",
    title: "Establish PMO Vision, Values and Culture",
    description: "Implement vision statement, core values, and cultural change program with leadership engagement.",
    completed: false,
    bestPractices: [
      "Create compelling vision statement aligned with organization",
      "Document core values with behavioral examples",
      "Implement leadership engagement activities",
      "Establish cultural reinforcement mechanisms"
    ],
    templates: ["PMO Vision Statement Template", "Cultural Change Roadmap"]
  },
  {
    id: "1-output-3",
    domainId: 1,
    domainName: "Organizational Development and Alignment",
    stage: "output",
    title: "Implement PMO Charter and Governance",
    description: "Establish and operationalize PMO charter with defined scope, authority, and governance structure.",
    completed: false,
    bestPractices: [
      "Formalize PMO charter with executive approval",
      "Implement governance structure with clear roles",
      "Establish decision-making authorities and processes",
      "Create charter review and update mechanisms"
    ],
    templates: ["PMO Charter Document", "Governance Structure Diagram"]
  },

  // Domain 2: Strategic Framework & Governance
  // INPUTS: Data collection, assessment, and information gathering
  {
    id: "2-input-1",
    domainId: 2,
    domainName: "Strategic Framework & Governance",
    stage: "input",
    title: "Gather Current State Data",
    description: "Collect data on current project management operations, processes, and performance.",
    completed: false,
    bestPractices: [
      "Conduct process documentation review",
      "Gather performance metrics and historical data",
      "Collect stakeholder feedback on current operations",
      "Document existing governance structures"
    ]
  },
  {
    id: "2-input-2",
    domainId: 2,
    domainName: "Strategic Framework & Governance",
    stage: "input",
    title: "Collect Strategic Alignment Information",
    description: "Gather organizational strategic objectives, priorities, and success criteria.",
    completed: false,
    bestPractices: [
      "Review organizational strategic plans",
      "Collect executive leadership priorities",
      "Document business unit objectives",
      "Gather information on strategic initiatives"
    ]
  },
  {
    id: "2-input-3",
    domainId: 2,
    domainName: "Strategic Framework & Governance",
    stage: "input",
    title: "Identify Capability Requirements",
    description: "Collect data on required capabilities through stakeholder interviews and organizational needs assessment.",
    completed: false,
    bestPractices: [
      "Conduct capability needs interviews",
      "Gather industry capability standards",
      "Document capability prioritization criteria",
      "Collect capability maturity benchmarks"
    ]
  },
  // PROCESSING: Analysis, tools, techniques, and methodologies
  {
    id: "2-processing-1",
    domainId: 2,
    domainName: "Strategic Framework & Governance",
    stage: "processing",
    title: "Apply Mandate Development Methodology",
    description: "Use mandate development techniques to define PMO purpose, authority, and responsibilities.",
    completed: false,
    bestPractices: [
      "Apply purpose statement development methods",
      "Use authority mapping techniques",
      "Apply responsibility definition methodologies",
      "Use stakeholder validation approaches"
    ],
    templates: ["PMO Mandate Template", "Executive Sponsorship Agreement"]
  },
  {
    id: "2-processing-2",
    domainId: 2,
    domainName: "Strategic Framework & Governance",
    stage: "processing",
    title: "Apply Charter Development Framework",
    description: "Use charter development framework to create comprehensive PMO charter with roles and governance structure.",
    completed: false,
    bestPractices: [
      "Apply vision and mission statement techniques",
      "Use organizational structure design methods",
      "Apply role definition methodologies",
      "Use governance framework design techniques"
    ],
    templates: ["PMO Charter Template", "Governance Structure Diagram"]
  },
  {
    id: "2-processing-3",
    domainId: 2,
    domainName: "Strategic Framework & Governance",
    stage: "processing",
    title: "Apply Governance Design Methodology",
    description: "Use governance design techniques to develop decision-making processes and oversight mechanisms.",
    completed: false,
    bestPractices: [
      "Apply decision rights mapping techniques",
      "Use escalation path design methods",
      "Apply governance body design methodologies",
      "Use governance communication planning techniques"
    ],
    templates: ["Governance Framework Template", "Decision Rights Matrix"]
  },
  // OUTPUTS: Deliverables, implementation, and tangible results
  {
    id: "2-output-1",
    domainId: 2,
    domainName: "Strategic Framework & Governance",
    stage: "output",
    title: "Establish PMO Mandate and Charter",
    description: "Formalize and implement PMO mandate and charter with defined purpose, authority, and responsibilities.",
    completed: false,
    bestPractices: [
      "Obtain executive approval for mandate and charter",
      "Communicate mandate to all stakeholders",
      "Implement authority structures defined in charter",
      "Establish charter review and update process"
    ],
    templates: ["Approved PMO Mandate", "Finalized PMO Charter"]
  },
  {
    id: "2-output-2",
    domainId: 2,
    domainName: "Strategic Framework & Governance",
    stage: "output",
    title: "Implement Governance Framework",
    description: "Establish and operationalize governance framework with decision-making bodies, processes, and oversight mechanisms.",
    completed: false,
    bestPractices: [
      "Form governance committees with clear charters",
      "Implement decision-making processes and authorities",
      "Establish governance meeting cadence and agendas",
      "Create governance documentation and reporting system"
    ],
    templates: ["Governance Committee Charter", "Decision Authority Matrix"]
  },
  {
    id: "2-output-3",
    domainId: 2,
    domainName: "Strategic Framework & Governance",
    stage: "output",
    title: "Develop Strategic Communication Plan",
    description: "Implement comprehensive communication strategy with stakeholder-specific messaging and feedback mechanisms.",
    completed: false,
    bestPractices: [
      "Create stakeholder-specific communication materials",
      "Establish regular communication cadence",
      "Implement feedback collection mechanisms",
      "Develop communication effectiveness metrics"
    ],
    templates: ["Strategic Communication Plan", "Stakeholder Messaging Matrix"]
  },

  // Domain 3: PMO Structure & Design
  // INPUTS: Data collection, assessment, and information gathering
  {
    id: "3-input-1",
    domainId: 3,
    domainName: "PMO Structure & Design",
    stage: "input",
    title: "Gather Customer Data",
    description: "Collect data on potential PMO customers, their needs, and expectations through surveys and interviews.",
    completed: false,
    bestPractices: [
      "Conduct customer needs assessment surveys",
      "Gather stakeholder interview data",
      "Document customer pain points and expectations",
      "Collect service prioritization information"
    ]
  },
  {
    id: "3-input-2",
    domainId: 3,
    domainName: "PMO Structure & Design",
    stage: "input",
    title: "Collect Service Requirement Data",
    description: "Gather detailed requirements for potential PMO services through workshops and requirements sessions.",
    completed: false,
    bestPractices: [
      "Conduct service requirements workshops",
      "Document service level expectations",
      "Collect service prioritization criteria",
      "Gather benchmark data on similar services"
    ],
    templates: ["Service Requirements Template", "Customer Needs Assessment"]
  },
  {
    id: "3-input-3",
    domainId: 3,
    domainName: "PMO Structure & Design",
    stage: "input",
    title: "Assess Capability Gaps",
    description: "Collect data on current capabilities and gaps through assessment tools and stakeholder feedback.",
    completed: false,
    bestPractices: [
      "Use capability maturity assessment tools",
      "Gather capability benchmark data",
      "Document capability prioritization criteria",
      "Collect resource availability information"
    ]
  },
  // PROCESSING: Analysis, tools, techniques, and methodologies
  {
    id: "3-processing-1",
    domainId: 3,
    domainName: "PMO Structure & Design",
    stage: "processing",
    title: "Apply Persona Development Techniques",
    description: "Use persona development methodologies to create detailed customer personas with needs and expectations.",
    completed: false,
    bestPractices: [
      "Apply customer segmentation techniques",
      "Use persona development frameworks",
      "Apply needs analysis methodologies",
      "Use journey mapping techniques"
    ]
  },
  {
    id: "3-processing-2",
    domainId: 3,
    domainName: "PMO Structure & Design",
    stage: "processing",
    title: "Apply Prioritization Frameworks",
    description: "Use prioritization techniques to develop framework for addressing customer needs systematically.",
    completed: false,
    bestPractices: [
      "Apply value vs. effort prioritization matrix",
      "Use MoSCoW prioritization technique",
      "Apply weighted scoring methodologies",
      "Use impact mapping techniques"
    ]
  },
  {
    id: "3-processing-3",
    domainId: 3,
    domainName: "PMO Structure & Design",
    stage: "processing",
    title: "Apply Service Catalog Design Methodology",
    description: "Use service catalog design techniques to develop comprehensive service offerings with benefits and advantages.",
    completed: false,
    bestPractices: [
      "Apply service definition frameworks",
      "Use service level definition techniques",
      "Apply value proposition development methodologies",
      "Use service categorization techniques"
    ],
    templates: ["Service Catalog Template", "Service Level Agreement Template"]
  },
  // OUTPUTS: Deliverables, implementation, and tangible results
  {
    id: "3-output-1",
    domainId: 3,
    domainName: "PMO Structure & Design",
    stage: "output",
    title: "Deliver Customer Personas and Journey Maps",
    description: "Create and distribute detailed customer personas and journey maps to guide service design and delivery.",
    completed: false,
    bestPractices: [
      "Document comprehensive personas with needs and pain points",
      "Create visual journey maps for key customer interactions",
      "Distribute personas to all service delivery teams",
      "Establish persona update and refinement process"
    ],
    templates: ["Customer Persona Template", "Journey Map Template"]
  },
  {
    id: "3-output-2",
    domainId: 3,
    domainName: "PMO Structure & Design",
    stage: "output",
    title: "Implement Service Catalog and SLAs",
    description: "Launch comprehensive service catalog with service level agreements, processes, and quality standards.",
    completed: false,
    bestPractices: [
      "Create detailed service descriptions with value propositions",
      "Establish service level metrics and targets",
      "Implement service request and delivery processes",
      "Create service catalog review and update mechanism"
    ],
    templates: ["Service Catalog Document", "SLA Documentation"]
  },
  {
    id: "3-output-3",
    domainId: 3,
    domainName: "PMO Structure & Design",
    stage: "output",
    title: "Establish Service Prioritization Framework",
    description: "Implement systematic approach for prioritizing and addressing customer needs and service requests.",
    completed: false,
    bestPractices: [
      "Create prioritization criteria and scoring system",
      "Implement request intake and evaluation process",
      "Establish resource allocation based on priorities",
      "Develop priority review and adjustment mechanisms"
    ],
    templates: ["Prioritization Matrix", "Service Request Form"]
  },

  // Domain 4: Operational Excellence
  // INPUTS: Data collection, assessment, and information gathering
  {
    id: "4-input-1",
    domainId: 4,
    domainName: "Operational Excellence",
    stage: "input",
    title: "Gather Onboarding Requirements",
    description: "Collect requirements and expectations for customer onboarding process through stakeholder input.",
    completed: false,
    bestPractices: [
      "Conduct onboarding needs assessment",
      "Gather stakeholder expectations for onboarding",
      "Document current onboarding challenges",
      "Collect onboarding best practices"
    ]
  },
  {
    id: "4-input-2",
    domainId: 4,
    domainName: "Operational Excellence",
    stage: "input",
    title: "Collect Documentation Requirements",
    description: "Gather requirements for process documentation, user guides, and training materials.",
    completed: false,
    bestPractices: [
      "Conduct documentation needs assessment",
      "Gather user preferences for documentation formats",
      "Document current documentation gaps",
      "Collect documentation best practices"
    ],
    templates: ["Documentation Requirements Template", "User Guide Outline"]
  },
  {
    id: "4-input-3",
    domainId: 4,
    domainName: "Operational Excellence",
    stage: "input",
    title: "Assess Training Needs",
    description: "Collect data on training needs, preferences, and delivery methods through surveys and interviews.",
    completed: false,
    bestPractices: [
      "Conduct training needs assessment",
      "Gather learning style preferences",
      "Document knowledge and skill gaps",
      "Collect training effectiveness criteria"
    ]
  },
  // PROCESSING: Analysis, tools, techniques, and methodologies
  {
    id: "4-processing-1",
    domainId: 4,
    domainName: "Operational Excellence",
    stage: "processing",
    title: "Apply Quality Management Techniques",
    description: "Use quality management methodologies to develop quality control measures and improvement processes.",
    completed: false,
    bestPractices: [
      "Apply quality standards development techniques",
      "Use quality control checkpoint design methods",
      "Apply quality metrics development frameworks",
      "Use continuous improvement methodologies"
    ]
  },
  {
    id: "4-processing-2",
    domainId: 4,
    domainName: "Operational Excellence",
    stage: "processing",
    title: "Apply Resource Management Methodologies",
    description: "Use resource management techniques to develop allocation systems and capacity planning processes.",
    completed: false,
    bestPractices: [
      "Apply resource capacity planning techniques",
      "Use resource allocation prioritization methods",
      "Apply resource forecasting methodologies",
      "Use resource utilization optimization techniques"
    ],
    templates: ["Resource Management Plan", "Capacity Planning Template"]
  },
  {
    id: "4-processing-3",
    domainId: 4,
    domainName: "Operational Excellence",
    stage: "processing",
    title: "Apply Issue Management Framework",
    description: "Use issue management methodologies to develop escalation procedures and resolution processes.",
    completed: false,
    bestPractices: [
      "Apply escalation threshold definition techniques",
      "Use escalation path design methods",
      "Apply issue categorization frameworks",
      "Use resolution time standard development techniques"
    ],
    templates: ["Escalation Procedure Template", "Issue Management Framework"]
  },
  // OUTPUTS: Deliverables, implementation, and tangible results
  {
    id: "4-output-1",
    domainId: 4,
    domainName: "Operational Excellence",
    stage: "output",
    title: "Implement Quality Management System",
    description: "Establish comprehensive quality management system with standards, control processes, and improvement mechanisms.",
    completed: false,
    bestPractices: [
      "Document quality standards for all services",
      "Implement quality control checkpoints and reviews",
      "Establish quality metrics collection and reporting",
      "Create continuous quality improvement process"
    ],
    templates: ["Quality Standards Document", "Quality Review Checklist"]
  },
  {
    id: "4-output-2",
    domainId: 4,
    domainName: "Operational Excellence",
    stage: "output",
    title: "Establish Resource Management System",
    description: "Implement resource management system with capacity planning, allocation processes, and utilization tracking.",
    completed: false,
    bestPractices: [
      "Create resource inventory and skills matrix",
      "Implement capacity planning and forecasting process",
      "Establish resource allocation and assignment procedures",
      "Develop resource utilization tracking and reporting"
    ],
    templates: ["Resource Allocation Matrix", "Capacity Planning Dashboard"]
  },
  {
    id: "4-output-3",
    domainId: 4,
    domainName: "Operational Excellence",
    stage: "output",
    title: "Deploy Issue Management System",
    description: "Implement comprehensive issue management system with escalation procedures, tracking, and resolution processes.",
    completed: false,
    bestPractices: [
      "Establish issue intake and categorization process",
      "Implement escalation paths and notification system",
      "Create issue tracking and status reporting",
      "Develop resolution verification and closure procedures"
    ],
    templates: ["Issue Management Playbook", "Escalation Matrix"]
  },

  // Domain 5: Performance & Improvement
  // INPUTS: Data collection, assessment, and information gathering
  {
    id: "5-input-1",
    domainId: 5,
    domainName: "Performance & Improvement",
    stage: "input",
    title: "Gather Maturity Assessment Data",
    description: "Collect data on current PMO maturity through assessment tools, surveys, and stakeholder feedback.",
    completed: false,
    bestPractices: [
      "Select appropriate maturity assessment tool",
      "Gather comprehensive assessment data",
      "Document maturity baseline across dimensions",
      "Collect maturity target information"
    ]
  },
  {
    id: "5-input-2",
    domainId: 5,
    domainName: "Performance & Improvement",
    stage: "input",
    title: "Collect Performance Data",
    description: "Gather current performance metrics, historical trends, and performance targets.",
    completed: false,
    bestPractices: [
      "Collect current performance metrics",
      "Gather historical performance data",
      "Document performance targets and thresholds",
      "Collect performance benchmark information"
    ]
  },
  {
    id: "5-input-3",
    domainId: 5,
    domainName: "Performance & Improvement",
    stage: "input",
    title: "Assess Value Measurement Approaches",
    description: "Collect data on potential value metrics, measurement approaches, and value demonstration methods.",
    completed: false,
    bestPractices: [
      "Gather value metric options",
      "Collect value measurement methodologies",
      "Document value perception from stakeholders",
      "Assess current value demonstration approaches"
    ]
  },
  // PROCESSING: Analysis, tools, techniques, and methodologies
  {
    id: "5-processing-1",
    domainId: 5,
    domainName: "Performance & Improvement",
    stage: "processing",
    title: "Apply Maturity Roadmapping Techniques",
    description: "Use maturity roadmapping methodologies to develop enhancement plan with milestones and metrics.",
    completed: false,
    bestPractices: [
      "Apply maturity gap analysis techniques",
      "Use capability prioritization methods",
      "Apply milestone development frameworks",
      "Use metric definition techniques"
    ]
  },
  {
    id: "5-processing-2",
    domainId: 5,
    domainName: "Performance & Improvement",
    stage: "processing",
    title: "Apply Change Management Methodologies",
    description: "Use change management techniques to develop implementation approach for maturity initiatives.",
    completed: false,
    bestPractices: [
      "Apply stakeholder impact analysis techniques",
      "Use resistance management methods",
      "Apply communication planning frameworks",
      "Use adoption measurement techniques"
    ],
    templates: ["Change Management Plan", "Stakeholder Engagement Plan"]
  },
  {
    id: "5-processing-3",
    domainId: 5,
    domainName: "Performance & Improvement",
    stage: "processing",
    title: "Apply Continuous Improvement Frameworks",
    description: "Use continuous improvement methodologies to develop systematic improvement processes.",
    completed: false,
    bestPractices: [
      "Apply improvement opportunity identification techniques",
      "Use improvement prioritization methods",
      "Apply implementation planning frameworks",
      "Use effectiveness measurement techniques"
    ]
  },
  // OUTPUTS: Deliverables, implementation, and tangible results
  {
    id: "5-output-1",
    domainId: 5,
    domainName: "Performance & Improvement",
    stage: "output",
    title: "Implement Maturity Enhancement Roadmap",
    description: "Establish and execute comprehensive maturity enhancement roadmap with milestones, metrics, and review processes.",
    completed: false,
    bestPractices: [
      "Document detailed maturity enhancement plan",
      "Implement milestone tracking and reporting",
      "Establish maturity metric collection and analysis",
      "Create regular maturity review and adjustment process"
    ],
    templates: ["Maturity Enhancement Roadmap", "Maturity Metrics Dashboard"]
  },
  {
    id: "5-output-2",
    domainId: 5,
    domainName: "Performance & Improvement",
    stage: "output",
    title: "Establish Value Measurement System",
    description: "Implement comprehensive value measurement system with metrics, reporting, and demonstration mechanisms.",
    completed: false,
    bestPractices: [
      "Define and implement value metrics and KPIs",
      "Create value data collection and analysis process",
      "Establish value reporting and visualization",
      "Develop value demonstration case studies"
    ],
    templates: ["Value Measurement Framework", "Value Dashboard"]
  },
  {
    id: "5-output-3",
    domainId: 5,
    domainName: "Performance & Improvement",
    stage: "output",
    title: "Deploy Continuous Improvement Program",
    description: "Implement systematic continuous improvement program with identification, prioritization, and implementation processes.",
    completed: false,
    bestPractices: [
      "Establish improvement opportunity identification process",
      "Create improvement prioritization and selection system",
      "Implement improvement tracking and reporting",
      "Develop improvement effectiveness measurement"
    ],
    templates: ["Continuous Improvement Playbook", "Improvement Tracking System"]
  },

  // Domain 6: Capability Development
  // INPUTS: Data collection, assessment, and information gathering
  {
    id: "6-input-1",
    domainId: 6,
    domainName: "Capability Development",
    stage: "input",
    title: "Gather Decision-Making Data",
    description: "Collect data on current decision-making processes, data utilization, and improvement opportunities.",
    completed: false,
    bestPractices: [
      "Document current decision-making processes",
      "Assess data utilization in decisions",
      "Identify decision-making bottlenecks",
      "Gather decision quality metrics"
    ]
  },
  {
    id: "6-input-2",
    domainId: 6,
    domainName: "Capability Development",
    stage: "input",
    title: "Assess Competency Requirements",
    description: "Collect data on required competencies, current capabilities, and development needs.",
    completed: false,
    bestPractices: [
      "Document role-specific competency requirements",
      "Assess current competency levels",
      "Identify critical competency gaps",
      "Gather development preference information"
    ],
    templates: ["Competency Assessment Template", "Development Needs Analysis"]
  },
  {
    id: "6-input-3",
    domainId: 6,
    domainName: "Capability Development",
    stage: "input",
    title: "Collect Skills Assessment Data",
    description: "Gather comprehensive skills data through assessments, self-evaluations, and manager feedback.",
    completed: false,
    bestPractices: [
      "Use standardized skills assessment tools",
      "Gather self-assessment data",
      "Collect manager assessment input",
      "Document skills prioritization criteria"
    ]
  },
  // PROCESSING: Analysis, tools, techniques, and methodologies
  {
    id: "6-processing-1",
    domainId: 6,
    domainName: "Capability Development",
    stage: "processing",
    title: "Apply Training Program Design Methodology",
    description: "Use training design techniques to develop comprehensive training and certification programs.",
    completed: false,
    bestPractices: [
      "Apply learning objective development techniques",
      "Use curriculum design methodologies",
      "Apply learning modality selection frameworks",
      "Use training effectiveness measurement design"
    ]
  },
  {
    id: "6-processing-2",
    domainId: 6,
    domainName: "Capability Development",
    stage: "processing",
    title: "Apply Innovation Framework Development",
    description: "Use innovation framework techniques to develop processes for fostering innovation and problem-solving.",
    completed: false,
    bestPractices: [
      "Apply innovation process design methodologies",
      "Use idea generation technique selection",
      "Apply idea evaluation framework development",
      "Use innovation incentive system design"
    ]
  },
  {
    id: "6-processing-3",
    domainId: 6,
    domainName: "Capability Development",
    stage: "processing",
    title: "Apply Knowledge Management Techniques",
    description: "Use knowledge management methodologies to design knowledge-sharing platform and communities of practice.",
    completed: false,
    bestPractices: [
      "Apply knowledge repository design techniques",
      "Use knowledge categorization frameworks",
      "Apply community of practice design methodologies",
      "Use knowledge contribution incentive design"
    ]
  },
  // OUTPUTS: Deliverables, implementation, and tangible results
  {
    id: "6-output-1",
    domainId: 6,
    domainName: "Capability Development",
    stage: "output",
    title: "Implement Competency Development Framework",
    description: "Establish comprehensive competency framework with assessment, development paths, and certification programs.",
    completed: false,
    bestPractices: [
      "Document role-specific competency requirements",
      "Create competency assessment and tracking system",
      "Implement development paths for each competency area",
      "Establish certification and recognition program"
    ],
    templates: ["Competency Framework Document", "Development Path Guide"]
  },
  {
    id: "6-output-2",
    domainId: 6,
    domainName: "Capability Development",
    stage: "output",
    title: "Deploy Innovation and Problem-Solving System",
    description: "Implement structured innovation program with idea generation, evaluation, and implementation processes.",
    completed: false,
    bestPractices: [
      "Establish idea generation and collection system",
      "Create idea evaluation and selection process",
      "Implement innovation implementation support",
      "Develop innovation recognition and incentives"
    ],
    templates: ["Innovation Process Playbook", "Idea Evaluation Matrix"]
  },
  {
    id: "6-output-3",
    domainId: 6,
    domainName: "Capability Development",
    stage: "output",
    title: "Establish Knowledge Management System",
    description: "Implement comprehensive knowledge management system with repository, sharing mechanisms, and communities of practice.",
    completed: false,
    bestPractices: [
      "Create knowledge repository with categorization system",
      "Establish knowledge contribution processes",
      "Form communities of practice with clear charters",
      "Implement knowledge sharing events and activities"
    ],
    templates: ["Knowledge Management Guide", "Community of Practice Charter"]
  }
];

export const getIconComponent = (iconName: string) => {
  if (!iconName) {
    // Return a default icon if iconName is null or undefined
    return Building2;
  }
  
  switch (iconName) {
    case 'Building2':
      return Building2;
    case 'BarChart4':
      return BarChart4;
    case 'Workflow':
      return Workflow;
    case 'Cog':
      return Cog;
    case 'LineChart':
      return LineChart;
    case 'Users':
      return Users;
    case 'Briefcase':
      return Briefcase;
    case 'Layout':
      return Layout;
    case 'Settings':
      return Settings;
    case 'Target':
      return Target;
    case 'Layers':
      return Layers;
    case 'Scale':
      return Scale;
    default:
      return Building2;
  }
};