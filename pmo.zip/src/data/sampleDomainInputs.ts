export const sampleDomainInputs = {
  1: `# Organizational Development and Alignment Assessment

## Current State

Our organization has recently established a PMO to improve project delivery and alignment with strategic objectives. We operate in the financial services industry with approximately 2,500 employees across 12 locations. The organization has grown through several acquisitions, resulting in siloed operations and inconsistent project management practices.

### Cultural Assessment

The organizational culture can be described as hierarchical with strong departmental divisions. Decision-making tends to be slow due to multiple approval layers. There is some resistance to standardization, with departments preferring their established ways of working. However, there is executive support for establishing a more cohesive approach to project management.

### Stakeholder Analysis

Key stakeholders include:

1. Executive Leadership: Focused on strategic alignment and ROI of projects
2. Department Heads: Concerned about autonomy and resource constraints
3. Project Managers: Working in different ways across departments
4. Project Teams: Facing challenges with inconsistent methods and tools
5. Customers: Experiencing variability in project delivery quality and timeliness

### Current Challenges

- Lack of clear alignment between projects and organizational strategy
- Inconsistent project management methodologies across departments
- No standardized project selection or prioritization criteria
- Limited visibility into resource allocation across projects
- Inefficient knowledge transfer between project teams
- Unclear roles and responsibilities in project governance
- Resistance to standardized processes from long-established departments

### Attempted Solutions

We have tried implementing a project management tool organization-wide, but adoption has been inconsistent. We established a project governance committee, but it lacks clear authority and decision-making frameworks. Some departments have developed their own project management approaches, but there's limited sharing of best practices.

## Future State Vision

We aim to create a mature PMO that:

- Ensures all projects align with strategic objectives
- Establishes consistent, scalable project management processes
- Provides clear governance and decision-making frameworks
- Optimizes resource allocation across the organization
- Creates a culture that embraces project management discipline
- Demonstrates measurable value to the organization

## Questions and Concerns

1. How should we structure our PMO to balance standardization with departmental needs?
2. What approach should we take to change management given the cultural resistance?
3. What are the most critical first steps to establish PMO credibility?
4. How can we measure the effectiveness and value of organizational alignment?
5. What governance structure would best suit our organization?`,

  2: `# Strategic Framework & Governance Input

## Current Strategic Approach

Our organization currently lacks a formalized strategic framework for project selection and governance. Project initiation is often driven by departmental priorities rather than enterprise-wide strategic alignment. We face the following challenges:

- No standardized project selection or prioritization methodology
- Project approvals often based on who has the strongest voice rather than strategic value
- Limited executive visibility into the overall project portfolio
- Resources allocated to projects without clear understanding of strategic impact
- No consistent criteria for measuring project success beyond time and budget

## Governance Structures

We have attempted to implement governance through:

1. Monthly project status meetings with department heads
2. Quarterly portfolio reviews with executive leadership
3. Project approval committee for initiatives over $250,000
4. Ad hoc risk escalation process

However, these governance mechanisms face several challenges:

- Inconsistent attendance and engagement from key stakeholders
- Lack of clear decision rights and authorities
- No established escalation paths for issues requiring resolution
- Committee decisions frequently revisited or overturned
- Limited accountability for governance participation

## Strategic Alignment Efforts

We've tried to improve strategic alignment through:

- Annual strategic planning sessions that identify key initiatives
- Requirement for business cases to reference strategic objectives
- Quarterly strategy reviews with project updates
- Department-level OKRs that should connect to projects

The effectiveness of these approaches has been limited because:

- Strategic objectives are often broadly defined and subject to interpretation
- No consistent framework for translating strategy into execution
- Limited metrics to measure how projects contribute to strategic goals
- Project managers struggle to maintain strategic focus during execution

## Decision-Making Framework

Current decision-making for projects follows this general pattern:

1. Ideas generated within departments
2. Department head approval based on departmental budget
3. Cross-departmental projects require multiple approvals
4. Finance review for projects above certain thresholds
5. Executive approval for major initiatives

This approach creates several issues:

- Slow decision-making cycles (average 8 weeks for significant decisions)
- Inconsistent criteria applied across different departments
- Limited consideration of cross-departmental impacts
- No clear process for balancing competing priorities
- Resource conflicts identified late in the process

## Stakeholder Communication

Our current approach to stakeholder communication includes:

- Monthly project status reports to sponsors
- Quarterly presentations to executive leadership
- Ad hoc communications for issues and risks
- Departmental updates on project progress

These communications face challenges:

- Inconsistent formats and content across projects
- Focus on activities rather than outcomes and value
- Limited tailoring of messages to different stakeholder groups
- No established feedback mechanisms to ensure understanding and buy-in

## Desired Outcomes

We aim to develop a strategic framework and governance approach that:

1. Creates clear alignment between organizational strategy and project execution
2. Establishes effective decision-making processes with appropriate authorities
3. Enables consistent project prioritization and resource allocation
4. Provides visibility and transparency into the project portfolio
5. Ensures appropriate stakeholder engagement and communication
6. Demonstrates measurable value from project investments

## Questions for Analysis

1. What strategic framework would best fit our organizational structure and maturity?
2. How should we structure our governance to balance oversight with execution speed?
3. What decision rights and authorities should exist at different organizational levels?
4. How can we create effective strategic alignment without creating bureaucracy?
5. What metrics should we establish to measure the effectiveness of our governance?
6. How should we approach the change management required to implement new governance structures?`,

  3: `# PMO Structure & Design Assessment

## Current PMO Situation

We are in the process of establishing a formalized PMO structure. Currently, project management functions are distributed across departments with varying levels of maturity and approach. There is no centralized body responsible for project oversight, methodology, or governance.

### Organization Size and Scope

- Medium-sized organization with approximately 1,800 employees
- Annual project portfolio of 40-50 concurrent projects
- Projects range from $50K to $5M in budget
- Project types include IT implementations, process improvements, regulatory compliance, and new product/service development
- Geographic presence in 4 countries with operations requiring coordination

### Existing Project Management Capabilities

We have conducted an initial assessment of our project management capabilities:

- 18 full-time project managers distributed across departments
- Varied certification levels (8 with PMP certification)
- Inconsistent methodology application (some departments use agile, others waterfall, many hybrid)
- Basic project management tools with limited integration (mainly Microsoft Project and various collaboration tools)
- No standardized project performance metrics across the organization
- Limited resource management capabilities beyond departmental boundaries

### Stakeholder Requirements for PMO

We have gathered initial requirements from key stakeholders:

1. **Executive Leadership**
   - Improved strategic alignment of projects
   - Better visibility into project status and health
   - Consistent approach to measuring project ROI
   - Transparent resource allocation across the enterprise

2. **Department Heads**
   - Appropriate project governance without excessive bureaucracy
   - Access to project management expertise and support
   - Visibility into cross-departmental resource demands
   - Clear escalation paths for project issues

3. **Project Managers**
   - Standardized methodologies and templates
   - Professional development opportunities
   - Clear role definition and career paths
   - Support for complex project challenges

4. **Project Team Members**
   - Consistent processes and expectations
   - Appropriate training and onboarding
   - Clear roles and responsibilities
   - Workload visibility and management

### Organizational Culture Considerations

Our organizational culture presents both opportunities and challenges:

- Historically decentralized decision-making
- Strong departmental identities and some resistance to centralized control
- Innovation encouraged but balanced with risk management
- Strong emphasis on customer satisfaction and quality
- Some history of failed large projects creating skepticism about new initiatives
- Executive sponsorship for PMO, but concerns about adding bureaucracy

## Potential PMO Models Considered

We are considering several potential PMO models:

1. **Supportive PMO**: Focus on providing best practices, templates, and training
2. **Controlling PMO**: Enforce standards and governance for all projects
3. **Directive PMO**: Directly manage strategic projects with dedicated PMs
4. **Federated Model**: Central PMO with satellite PMO functions in key departments
5. **Center of Excellence**: Focus on methodology, training, and project management capability development

## Key Questions and Concerns

We are seeking guidance on:

1. Which PMO model would best fit our organizational structure, culture, and maturity?
2. How should the PMO be positioned within the organizational hierarchy?
3. What core functions should our PMO prioritize in its initial implementation?
4. What staffing model and roles would be most effective for our PMO?
5. How should we develop and implement a service catalog that meets stakeholder needs?
6. What metrics should we use to measure the effectiveness and value of the PMO?
7. What implementation approach would maximize adoption and value delivery?
8. How should the PMO structure evolve as organizational maturity increases?

## Initial Implementation Constraints

We are working with the following constraints:

- Budget approved for 3-5 dedicated PMO staff in year one
- Executive mandate to show measurable value within first 6 months
- Limited ability to mandate compliance in initial implementation
- Need to work with existing tools in short term before potential investments
- Competing organizational initiatives creating change saturation concerns`,

  4: `# Operational Excellence Assessment

## Current Operational State

Our organization has been managing projects for several years with varying levels of success. We've established some foundational project management practices, but we lack consistent operational excellence across our project portfolio. Here's an assessment of our current state:

### Process Standardization

- Project management methodology varies by department and project manager
- Basic templates exist but usage is inconsistent
- Project documentation quality and completeness varies significantly
- Some processes are well-defined (like change management) while others are ad-hoc
- Estimation practices are inconsistent, leading to frequent schedule overruns
- No standardized approach to lessons learned or continuous improvement

### Project Performance

- On-time delivery rate: approximately 65%
- Within-budget completion: approximately 70%
- Scope management issues in roughly 40% of projects
- Quality measurement is primarily reactive (defects/issues) rather than proactive
- Customer satisfaction varies widely across projects
- Limited ability to predict project outcomes early in lifecycle

### Resource Management

- Resource allocation primarily happens at department level
- Limited visibility into cross-project resource dependencies
- Capacity planning is mostly short-term and reactive
- Skill matching to project needs is informal
- Resource conflicts typically resolved through negotiation rather than prioritization
- No centralized resource management system or process

### Quality Management

- Quality assurance activities vary by project and department
- Testing processes are inconsistently applied
- Acceptance criteria often poorly defined or changed late in projects
- Metrics for quality are not standardized across projects
- Root cause analysis of issues is performed inconsistently
- Limited tracking of quality costs (prevention vs. correction)

### Risk Management

- Risk identification typically occurs at project initiation but not systematically updated
- Risk assessment methodology varies by project manager
- Mitigation strategies often lack ownership or follow-through
- No consistent approach to risk reporting across projects
- Limited aggregation of risks at portfolio level
- Opportunity management (positive risks) rarely formalized

### Tools and Technology

- Multiple project management tools in use across the organization
- Limited integration between systems (financial, project management, resource management)
- Manual data aggregation required for portfolio-level reporting
- Inconsistent use of available tool features
- Limited automation of routine project management processes
- Data quality and timeliness issues in project reporting

## Performance Metrics

We currently track the following metrics, though not consistently across all projects:

- Schedule variance
- Cost variance
- Defect counts
- Resource utilization
- Change request volume
- Issue resolution time
- Stakeholder satisfaction (for some projects)

## Improvement Initiatives

We've attempted several improvement initiatives with mixed results:

- Implemented a project management tool organization-wide (adoption at ~65%)
- Provided project management training to key staff (completion rate of 80%)
- Established a project review board for major projects (meeting consistently but with limited authority)
- Created a small PMO team (2 people) focused on templates and project support
- Developed a basic project dashboard for executive reporting (manual updates, often outdated)

## Desired Future State

We aim to establish operational excellence with the following characteristics:

- Consistent, scalable processes across all projects and departments
- Predictable project outcomes with early warning for potential issues
- Efficient resource allocation aligned with strategic priorities
- Proactive quality management integrated throughout project lifecycle
- Robust risk management with appropriate mitigation and contingency planning
- Integrated tools providing automation and reliable data for decision-making
- Continuous improvement culture with measurable performance gains
- Clear accountability and decision-making frameworks

## Specific Questions

1. What operational excellence framework would best fit our organization?
2. How should we prioritize operational improvements for maximum impact?
3. What metrics would best measure our operational maturity and progress?
4. How can we build a continuous improvement culture?
5. What is the right balance between standardization and flexibility?
6. How should we approach the change management required for operational improvements?

## Contextual Factors

- Industry: Financial Services
- Organization size: Medium (2,500 employees)
- Project portfolio: ~50 active projects
- Geographic spread: Multiple locations in 3 countries
- Regulatory environment: Highly regulated industry
- Recent merger has created additional operational complexity`,

  5: `# Performance & Improvement Assessment

## Current Performance Measurement Approach

Our organization's approach to measuring and improving PMO performance is currently fragmented and inconsistent. We have the following elements in place:

### Project-Level Metrics

We currently measure:
- Schedule performance (planned vs. actual dates)
- Budget performance (planned vs. actual spend)
- Scope change volume (number of approved changes)
- Defect rates during testing and post-implementation
- Project team resource utilization
- Stakeholder satisfaction via post-project surveys (completion rate ~40%)

Challenges with project metrics:
- Inconsistent collection and reporting across projects
- Limited analysis of trends or patterns
- Metrics viewed as reporting requirements rather than improvement tools
- Data quality and timeliness issues
- Limited benchmarking against industry standards

### PMO Performance Metrics

At the PMO level, we track:
- Number of projects managed
- Total portfolio budget managed
- Overall on-time/on-budget percentages
- PMO staff utilization
- Template usage compliance
- Training completion rates

Challenges with PMO metrics:
- Metrics focus on activity rather than value or outcomes
- Limited connection to organizational strategic objectives
- No clear targets or performance thresholds
- Inconsistent review cadence and follow-up actions
- Metrics not effectively communicated to stakeholders

### Value Measurement

Our attempts to measure PMO value include:
- Cost savings from project delivery improvements
- Reduction in failed or canceled projects
- Project manager productivity improvements
- Estimated value of standardized approaches

Challenges with value measurement:
- Difficulty attributing organizational outcomes to PMO activities
- Limited baseline data for comparison
- Qualitative benefits difficult to quantify
- Stakeholder skepticism about claimed benefits
- No formalized value measurement framework

## Current Improvement Processes

Our approach to continuous improvement includes:

### Process Improvement

- Ad hoc identification of improvement opportunities
- Periodic review of project management methodology (approximately annually)
- Some use of lessons learned from projects, but limited systematic application
- Process changes typically driven by problems rather than proactive enhancement
- Limited engagement of broader organization in improvement efforts

### Maturity Assessment

- Conducted one PMO maturity assessment two years ago
- Used a basic capability maturity model approach
- Limited follow-up on identified improvement areas
- No consistent reassessment timeline established
- Results communicated to leadership but not broader organization

### Feedback Mechanisms

- Post-project reviews for major projects
- Annual stakeholder satisfaction survey
- Ad hoc feedback collection from project managers
- Occasional focus groups on specific processes
- Issue/defect tracking for project deliverables

Challenges with feedback:
- Low response rates on surveys and reviews
- Limited analysis of root causes
- Inconsistent implementation of improvement suggestions
- Feedback often focused on problems rather than opportunities
- Limited closing of feedback loops with stakeholders

## Organizational Context

- Medium-sized financial services organization
- PMO established 3 years ago
- Currently at a self-assessed maturity level of 2.5 out of 5
- Approximately 40 projects per year ranging from small initiatives to major programs
- 12 project managers reporting through various departments
- PMO team of 3 full-time staff
- Mixed agile and traditional project approaches

## Strategic Objectives

Our organization has the following strategic objectives relevant to PMO performance:
- Increase speed-to-market for new products and services
- Improve operational efficiency and reduce costs
- Enhance customer experience through digital transformation
- Ensure regulatory compliance and risk management
- Integrate recent acquisitions effectively

## Desired Future State

We aim to develop a comprehensive performance and improvement framework that:
- Demonstrates clear PMO value to the organization
- Aligns with strategic organizational objectives
- Balances efficiency metrics with effectiveness and value metrics
- Provides actionable insights for continuous improvement
- Evolves as PMO maturity increases
- Engages stakeholders in the improvement process
- Creates accountability for performance at all levels

## Specific Questions

1. What performance measurement framework would best suit our organization?
2. Which metrics would most effectively demonstrate PMO value to senior leadership?
3. How should we approach maturity assessment and improvement planning?
4. What benchmarks should we consider for our industry and organization size?
5. How can we better engage stakeholders in the improvement process?
6. What governance structure should oversee performance improvement initiatives?
7. How can we create a culture of continuous improvement within the PMO and beyond?`,

  6: `# Capability Development Assessment

## Current State of PMO Capabilities

Our organization has been operating a PMO for approximately two years, with varying levels of success across different capability areas. Below is an assessment of our current capability development approach and challenges:

### Competency Framework

- No formal competency framework for PMO staff or project managers
- Job descriptions exist but lack detailed competency requirements
- Inconsistent understanding of required skills for project roles
- No clear progression path for project management professionals
- Ad hoc identification of training needs based on performance issues
- Limited distinction between technical and leadership competencies

### Training and Development

- Basic project management training available (2-day course)
- No tailored training paths based on role or experience
- Limited advanced or specialized training offerings
- Inconsistent coaching and mentoring practices
- No formal knowledge sharing mechanisms between project managers
- Training effectiveness measured by completion rather than capability improvement
- Limited budget allocated for professional development (averaging $1,500 per person annually)

### Certification Support

- Inconsistent approach to professional certifications
- No clear policy on certification requirements or support
- Partial reimbursement for certification costs
- Limited recognition for achieving certifications
- No alignment between certification and career advancement
- 40% of project managers currently hold professional certifications

### Resource Capability Management

- Limited visibility into resource capabilities across organization
- No skills database or competency tracking
- Resource allocation based primarily on availability rather than optimal skill match
- No formal approach to building specialized capabilities
- Capacity challenges in specialized skill areas (e.g., risk management, complex stakeholder management)
- Limited cross-training to build versatility in project teams

### Knowledge Management

- Project documentation stored but not effectively organized for knowledge sharing
- No formal lessons learned process or repository
- Limited communities of practice or knowledge exchange forums
- Knowledge retention issues when staff leave the organization
- Reinvention of solutions across projects due to knowledge silos
- No designated responsibility for knowledge management

### Leadership Development

- Limited focus on developing project leadership capabilities
- No defined pathway from technical PM to project leadership roles
- Ad hoc mentoring arrangements for high-potential staff
- Leadership development focused on departmental rather than project management tracks
- Project complexity not effectively matched to leadership capability

## Organizational Context

- Medium-sized organization (~3,000 employees)
- 25 project managers across various departments
- PMO team of 4 staff members
- Project portfolio of approximately 35-40 active projects
- Mix of waterfall, agile, and hybrid project approaches
- Growing complexity in project requirements

## Current Challenges

1. **Skill Gaps**: Identified gaps in benefits realization, strategic alignment, and complex stakeholder management
2. **Retention Issues**: 20% turnover in project management roles in past year
3. **Scaling Challenges**: Difficulty scaling PM capability to meet growing project demands
4. **Inconsistent Performance**: Wide variation in project success rates depending on PM assigned
5. **Knowledge Silos**: Critical knowledge concentrated in few individuals
6. **Limited Career Paths**: Unclear advancement opportunities for project professionals
7. **Resource Optimization**: Suboptimal matching of capabilities to project requirements

## Recent Initiatives

We have attempted several initiatives with mixed results:

- Implemented a project management community of practice (low attendance)
- Provided PMP exam preparation support (7 staff completed)
- Conducted quarterly knowledge sharing sessions (inconsistent quality)
- Created a basic project management methodology guide (moderate adoption)
- Instituted project manager roundtables (good engagement but limited follow-through)

## Stakeholder Expectations

Expectations for capability development include:

- **Executive Leadership**: Wants improved project delivery consistency and strategic alignment
- **Department Managers**: Need resource flexibility and cross-training
- **Project Managers**: Seeking career growth and professional development
- **Project Team Members**: Want clear role definitions and skill development opportunities
- **PMO Leadership**: Aims to build scalable, sustainable project management capability

## Improvement Goals

We aim to develop a comprehensive capability development approach that:

1. Creates a clear competency framework aligned with organizational needs
2. Establishes tailored development paths for different roles and career stages
3. Improves knowledge sharing and retention across the organization
4. Enhances leadership capabilities for complex project environments
5. Builds specialized capabilities for strategic initiatives
6. Establishes measurable improvements in project delivery capability
7. Supports talent retention through clear growth opportunities

## Specific Questions

1. What competency framework would best suit our organizational context?
2. How should we balance technical vs. leadership capability development?
3. What metrics should we use to measure capability improvement?
4. How can we create effective knowledge sharing mechanisms?
5. What approach should we take to match capabilities to project requirements?
6. How can we develop specialized capabilities while maintaining core PM skills?
7. What governance structure should oversee capability development?`
};