import { useRef, useEffect, useState, useCallback } from 'react';
import { captureException } from '../services/sentryService';

/**
 * Custom hook that provides safe DOM operations to prevent 
 * "Cannot read properties of null (reading 'nodeName')" errors
 */
export function useSafeDOM<T extends HTMLElement = HTMLDivElement>() {
  // Create a ref to hold the DOM element
  const elementRef = useRef<T | null>(null);
  
  // Track if the component is mounted
  const isMountedRef = useRef(false);
  
  // Track if the DOM element is ready for interactions
  const [isElementReady, setIsElementReady] = useState(false);
  
  // Track any errors that occur during DOM operations
  const [error, setError] = useState<Error | null>(null);
  
  // Set mounted status on mount/unmount
  useEffect(() => {
    isMountedRef.current = true;
    
    return () => {
      isMountedRef.current = false;
    };
  }, []);
  
  // Check if the element is ready when the ref changes
  useEffect(() => {
    if (elementRef.current && isMountedRef.current) {
      // Use requestAnimationFrame to ensure DOM is ready
      const frameId = requestAnimationFrame(() => {
        if (isMountedRef.current) {
          setIsElementReady(true);
        }
      });
      
      return () => {
        cancelAnimationFrame(frameId);
      };
    }
    
    return () => {
      // No cleanup needed
    };
  }, [elementRef.current]);
  
  /**
   * Safely get a property from the DOM element
   * @param propertyGetter Function to get a property from the element
   * @param defaultValue Default value to return if the element is not available
   */
  const getSafely = useCallback(<P>(
    propertyGetter: (element: T) => P,
    defaultValue: P
  ): P => {
    try {
      if (!elementRef.current || !isMountedRef.current || !isElementReady) {
        return defaultValue;
      }
      
      return propertyGetter(elementRef.current);
    } catch (err) {
      console.error('Error accessing DOM property:', err);
      setError(err instanceof Error ? err : new Error(String(err)));
      return defaultValue;
    }
  }, [isElementReady]);
  
  /**
   * Safely execute a method on the DOM element
   * @param method Function to execute on the element
   * @param fallback Fallback function to execute if the element is not available
   */
  const executeSafely = useCallback(<P extends any[], R>(
    method: (element: T, ...args: P) => R,
    fallback: (...args: P) => R
  ) => {
    return (...args: P): R => {
      try {
        if (!elementRef.current || !isMountedRef.current || !isElementReady) {
          return fallback(...args);
        }
        
        return method(elementRef.current, ...args);
      } catch (err) {
        console.error('Error executing DOM method:', err);
        setError(err instanceof Error ? err : new Error(String(err)));
        return fallback(...args);
      }
    };
  }, [isElementReady]);
  
  /**
   * Safely scroll the element into view
   */
  const scrollIntoViewSafely = useCallback((options?: ScrollIntoViewOptions) => {
    try {
      if (!elementRef.current || !isMountedRef.current || !isElementReady) {
        console.warn('Cannot scroll element into view - element not ready');
        return;
      }
      
      // Use requestAnimationFrame to ensure DOM is ready
      requestAnimationFrame(() => {
        try {
          if (elementRef.current && isMountedRef.current) {
            elementRef.current.scrollIntoView(options || { behavior: 'smooth', block: 'nearest' });
          }
        } catch (scrollError) {
          console.error('Error during scrollIntoView:', scrollError);
          
          // Try a simpler scroll method as fallback
          try {
            if (elementRef.current && isMountedRef.current) {
              // Get the element's position and scroll there manually
              const rect = elementRef.current.getBoundingClientRect();
              window.scrollTo({
                top: window.pageYOffset + rect.top - 20,
                behavior: 'smooth'
              });
            }
          } catch (fallbackError) {
            console.error('Even fallback scroll failed:', fallbackError);
            captureException(fallbackError);
          }
        }
      });
    } catch (err) {
      console.error('Error in scrollIntoViewSafely:', err);
      setError(err instanceof Error ? err : new Error(String(err)));
      captureException(err);
    }
  }, [isElementReady]);
  
  /**
   * Safely get the bounding client rect of the element
   */
  const getBoundingClientRectSafely = useCallback((): DOMRect => {
    return getSafely(
      (element) => element.getBoundingClientRect(),
      new DOMRect(0, 0, 0, 0)
    );
  }, [getSafely]);
  
  /**
   * Safely focus the element
   */
  const focusSafely = useCallback(() => {
    try {
      if (!elementRef.current || !isMountedRef.current || !isElementReady) {
        console.warn('Cannot focus element - element not ready');
        return;
      }
      
      // Use requestAnimationFrame to ensure DOM is ready
      requestAnimationFrame(() => {
        try {
          if (elementRef.current && isMountedRef.current) {
            elementRef.current.focus();
          }
        } catch (focusError) {
          console.error('Error during focus:', focusError);
          captureException(focusError);
        }
      });
    } catch (err) {
      console.error('Error in focusSafely:', err);
      setError(err instanceof Error ? err : new Error(String(err)));
      captureException(err);
    }
  }, [isElementReady]);
  
  /**
   * Safely add an event listener to the element
   */
  const addEventListenerSafely = useCallback(<K extends keyof HTMLElementEventMap>(
    type: K,
    listener: (this: HTMLElement, ev: HTMLElementEventMap[K]) => any,
    options?: boolean | AddEventListenerOptions
  ) => {
    try {
      if (!elementRef.current || !isMountedRef.current || !isElementReady) {
        console.warn(`Cannot add ${type} event listener - element not ready`);
        return () => {}; // Return no-op cleanup function
      }
      
      elementRef.current.addEventListener(type, listener as EventListener, options);
      
      // Return cleanup function
      return () => {
        try {
          if (elementRef.current) {
            elementRef.current.removeEventListener(type, listener as EventListener, options);
          }
        } catch (cleanupError) {
          console.error(`Error removing ${type} event listener:`, cleanupError);
        }
      };
    } catch (err) {
      console.error(`Error in addEventListenerSafely for ${type}:`, err);
      setError(err instanceof Error ? err : new Error(String(err)));
      captureException(err);
      return () => {}; // Return no-op cleanup function
    }
  }, [isElementReady]);
  
  /**
   * Safely set a style property on the element
   */
  const setStyleSafely = useCallback((property: string, value: string) => {
    try {
      if (!elementRef.current || !isMountedRef.current || !isElementReady) {
        console.warn(`Cannot set style ${property} - element not ready`);
        return;
      }
      
      elementRef.current.style[property as any] = value;
    } catch (err) {
      console.error(`Error setting style ${property}:`, err);
      setError(err instanceof Error ? err : new Error(String(err)));
      captureException(err);
    }
  }, [isElementReady]);
  
  /**
   * Safely get a style property from the element
   */
  const getStyleSafely = useCallback((property: string, defaultValue: string = ''): string => {
    return getSafely(
      (element) => window.getComputedStyle(element)[property as any] || defaultValue,
      defaultValue
    );
  }, [getSafely]);
  
  /**
   * Safely get the element's offset dimensions
   */
  const getOffsetDimensions = useCallback(() => {
    return {
      offsetWidth: getSafely((element) => element.offsetWidth, 0),
      offsetHeight: getSafely((element) => element.offsetHeight, 0),
      offsetLeft: getSafely((element) => element.offsetLeft, 0),
      offsetTop: getSafely((element) => element.offsetTop, 0)
    };
  }, [getSafely]);
  
  /**
   * Reset any errors that have occurred
   */
  const resetError = useCallback(() => {
    setError(null);
  }, []);
  
  return {
    ref: elementRef,
    isReady: isElementReady,
    isMounted: isMountedRef,
    error,
    resetError,
    getSafely,
    executeSafely,
    scrollIntoViewSafely,
    getBoundingClientRectSafely,
    focusSafely,
    addEventListenerSafely,
    setStyleSafely,
    getStyleSafely,
    getOffsetDimensions
  };
}

export default useSafeDOM; 