import { useState, useEffect } from 'react';

export const useMediaQuery = (query: string): boolean => {
  const [matches, setMatches] = useState(() => {
    // SSR safety check
    if (typeof window !== 'undefined') {
      return window.matchMedia(query).matches;
    }
    return false;
  });

  useEffect(() => {
    if (typeof window === 'undefined') return undefined;
    
    const mediaQuery = window.matchMedia(query);
    const updateMatches = (e: MediaQueryListEvent) => setMatches(e.matches);
    
    // Set matches initially
    setMatches(mediaQuery.matches);
    
    // Add listener for changes
    mediaQuery.addEventListener('change', updateMatches);
    
    // Clean up listener
    return () => mediaQuery.removeEventListener('change', updateMatches);
  }, [query]);

  return matches;
};