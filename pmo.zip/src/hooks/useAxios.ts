import { useState, useEffect, useCallback } from 'react';
import axios, { AxiosError, AxiosRequestConfig, AxiosResponse } from 'axios';
import apiClient, { safeApiCall } from '../api/client';
import { useToast } from './useToast';

// Generic interface for hook return value
interface UseAxiosResponse<T> {
  data: T | null;
  loading: boolean;
  error: string | null;
  execute: (config?: AxiosRequestConfig) => Promise<{ data: T | null; error: string | null }>;
  reset: () => void;
}

/**
 * Custom hook for making safer API calls with automatic loading and error states
 * @param requestConfig - The Axios request configuration
 * @param executeOnMount - Whether to execute the request on component mount
 * @param showToasts - Whether to show toast messages for errors
 * @returns Object containing data, loading state, error message, and execution function
 */
export function useAxios<T>(
  requestConfig: AxiosRequestConfig,
  executeOnMount: boolean = true,
  showToasts: boolean = true
): UseAxiosResponse<T> {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState<boolean>(executeOnMount);
  const [error, setError] = useState<string | null>(null);
  const toast = useToast();

  // Function to make the API call
  const execute = useCallback(
    async (overrideConfig?: AxiosRequestConfig) => {
      const config = { ...requestConfig, ...overrideConfig };
      
      setLoading(true);
      setError(null);

      try {
        const { data: responseData, error: responseError } = await safeApiCall<T>(
          apiClient(config)
        );

        if (responseError) {
          setError(responseError);
          if (showToasts) {
            toast.error(responseError);
          }
          return { data: null, error: responseError };
        }

        setData(responseData);
        return { data: responseData, error: null };
      } catch (err: any) {
        const errorMessage = err?.message || 'An unexpected error occurred';
        setError(errorMessage);
        if (showToasts) {
          toast.error(errorMessage);
        }
        return { data: null, error: errorMessage };
      } finally {
        setLoading(false);
      }
    },
    [requestConfig, toast, showToasts]
  );

  // Reset function
  const reset = useCallback(() => {
    setData(null);
    setLoading(false);
    setError(null);
  }, []);

  // Execute on mount if requested
  useEffect(() => {
    if (executeOnMount) {
      execute();
    }
  }, [executeOnMount, execute]);

  return { data, loading, error, execute, reset };
}

/**
 * Custom hook for making POST requests
 */
export function usePost<T, D = any>(
  url: string, 
  initialData?: D, 
  executeOnMount: boolean = false,
  showToasts: boolean = true
): UseAxiosResponse<T> & { 
  postData: (data?: D) => Promise<{ data: T | null; error: string | null }> 
} {
  const { data, loading, error, execute, reset } = useAxios<T>(
    {
      url,
      method: 'POST',
      data: initialData
    },
    executeOnMount,
    showToasts
  );

  const postData = useCallback(
    async (newData?: D) => {
      return execute({ data: newData || initialData });
    },
    [execute, initialData]
  );

  return { data, loading, error, execute, reset, postData };
}

/**
 * Custom hook for making GET requests
 */
export function useGet<T>(
  url: string,
  params?: any,
  executeOnMount: boolean = true,
  showToasts: boolean = true
): UseAxiosResponse<T> {
  return useAxios<T>(
    {
      url,
      method: 'GET',
      params
    },
    executeOnMount,
    showToasts
  );
}

export default useAxios; 