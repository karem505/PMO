import { useState, useEffect } from 'react';

/**
 * Hook لتحميل سكريبت بنك مصر للدفع والتأكد من تحميله بشكل صحيح
 */
export function useBankMasrCheckoutScript() {
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  useEffect(() => {
    const scriptId = 'bank-masr-checkout-script';
    
    // إذا كان السكريبت موجودًا بالفعل
    if (document.getElementById(scriptId)) {
      setLoaded(window.Checkout !== undefined);
      return;
    }
    
    // إنشاء عنصر السكريبت
    const script = document.createElement('script');
    script.id = scriptId;
    script.src = 'https://banquemisr.gateway.mastercard.com/checkout/version/72/checkout.js';
    script.async = true;
    
    // حدث عند اكتمال التحميل
    script.onload = () => {
      // تحقق من وجود الكائن Checkout في window
      if (window.Checkout) {
        console.log('Checkout.js loaded successfully');
        setLoaded(true);
      } else {
        console.error('Checkout.js loaded but window.Checkout is undefined');
        setError('Checkout script loaded but API is not available');
      }
    };
    
    // حدث عند الفشل في التحميل
    script.onerror = () => {
      console.error('Failed to load Checkout.js');
      setError('Failed to load payment gateway script');
    };
    
    // إضافة السكريبت إلى DOM
    document.body.appendChild(script);
    
    // تنظيف عند إزالة المكون
    return () => {
      // نحن لا نزيل السكريبت عند إزالة المكون لأننا قد نحتاجه لاحقًا
    };
  }, []);
  
  return { loaded, error };
} 