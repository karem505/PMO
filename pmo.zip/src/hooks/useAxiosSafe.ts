import { useState, useEffect, useCallback } from 'react';
import axios, { AxiosRequestConfig, AxiosResponse, AxiosError } from 'axios';
import { useToast } from './useToast';

interface UseAxiosSafeOptions {
  showLoadingToast?: boolean;
  showErrorToast?: boolean;
  showSuccessToast?: boolean;
  loadingMessage?: string;
  errorMessage?: string;
  successMessage?: string;
  defaultData?: any;
  executeOnMount?: boolean;
}

interface UseAxiosSafeResult<T> {
  data: T | null;
  loading: boolean;
  error: Error | null;
  execute: (config?: AxiosRequestConfig) => Promise<T | null>;
  reset: () => void;
}

/**
 * A custom hook for safely making Axios requests with built-in error handling and loading states
 * @param axiosConfig The Axios request configuration
 * @param options Additional options for the hook
 * @returns An object containing data, loading state, error state, and functions to execute the request and reset the state
 */
export function useAxiosSafe<T = any>(
  axiosConfig: AxiosRequestConfig,
  options: UseAxiosSafeOptions = {}
): UseAxiosSafeResult<T> {
  // Default options
  const {
    showLoadingToast = false,
    showErrorToast = true,
    showSuccessToast = false,
    loadingMessage = 'Loading...',
    errorMessage = 'An error occurred. Please try again.',
    successMessage = 'Success!',
    defaultData = null,
    executeOnMount = false
  } = options;

  // State
  const [data, setData] = useState<T | null>(defaultData);
  const [loading, setLoading] = useState<boolean>(executeOnMount);
  const [error, setError] = useState<Error | null>(null);
  const toast = useToast();

  // Execute the request
  const execute = useCallback(async (overrideConfig?: AxiosRequestConfig): Promise<T | null> => {
    setLoading(true);
    setError(null);

    // Show loading toast if enabled
    const loadingToastId = showLoadingToast ? toast.loading(loadingMessage) : null;

    try {
      // Merge the original config with any override config
      const config = { ...axiosConfig, ...overrideConfig };
      
      // Make the request
      const response: AxiosResponse<T> = await axios(config);
      
      // Check if the response data is valid
      if (response?.data === undefined || response?.data === null) {
        throw new Error('No data returned from the server');
      }
      
      // Set the data
      setData(response.data);
      
      // Show success toast if enabled
      if (showSuccessToast) {
        toast.success(successMessage);
      }
      
      // Clear loading toast if it exists
      if (loadingToastId) {
        toast.dismiss(loadingToastId);
      }
      
      return response.data;
    } catch (err) {
      // Handle the error
      const errorObj = err as Error | AxiosError;
      
      // Create a user-friendly error message
      let userErrorMessage = errorMessage;
      
      if (axios.isAxiosError(errorObj)) {
        // Handle Axios errors
        if (errorObj.response) {
          // Server responded with an error status
          userErrorMessage = errorObj.response.data?.message || 
                            `Error ${errorObj.response.status}: ${errorObj.response.statusText}` || 
                            errorMessage;
        } else if (errorObj.request) {
          // Request was made but no response received
          userErrorMessage = 'No response received from the server. Please check your connection.';
        }
      }
      
      // Set the error state
      setError(errorObj instanceof Error ? errorObj : new Error(userErrorMessage));
      
      // Show error toast if enabled
      if (showErrorToast) {
        toast.error(userErrorMessage);
      }
      
      // Clear loading toast if it exists
      if (loadingToastId) {
        toast.dismiss(loadingToastId);
      }
      
      // Log the error
      console.error('Axios request failed:', errorObj);
      
      // Return null to indicate failure
      return null;
    } finally {
      setLoading(false);
    }
  }, [axiosConfig, showLoadingToast, showErrorToast, showSuccessToast, loadingMessage, errorMessage, successMessage, toast]);

  // Reset the state
  const reset = useCallback(() => {
    setData(defaultData);
    setLoading(false);
    setError(null);
  }, [defaultData]);

  // Execute the request on mount if enabled
  useEffect(() => {
    if (executeOnMount) {
      execute();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [executeOnMount]);

  return { data, loading, error, execute, reset };
}

/**
 * A wrapper around useAxiosSafe for GET requests
 * @param url The URL to request
 * @param config Additional Axios config
 * @param options Additional options for the hook
 * @returns An object containing data, loading state, error state, and functions to execute the request and reset the state
 */
export function useAxiosGet<T = any>(
  url: string,
  config?: Omit<AxiosRequestConfig, 'url' | 'method'>,
  options?: UseAxiosSafeOptions
): UseAxiosSafeResult<T> {
  return useAxiosSafe<T>(
    { url, method: 'GET', ...config },
    options
  );
}

/**
 * A wrapper around useAxiosSafe for POST requests
 * @param url The URL to request
 * @param data The data to send
 * @param config Additional Axios config
 * @param options Additional options for the hook
 * @returns An object containing data, loading state, error state, and functions to execute the request and reset the state
 */
export function useAxiosPost<T = any, D = any>(
  url: string,
  data?: D,
  config?: Omit<AxiosRequestConfig, 'url' | 'method' | 'data'>,
  options?: UseAxiosSafeOptions
): UseAxiosSafeResult<T> {
  return useAxiosSafe<T>(
    { url, method: 'POST', data, ...config },
    options
  );
}

export default useAxiosSafe; 