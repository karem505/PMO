import { useState, useCallback, useRef, useEffect } from 'react';

/**
 * Custom hook to provide a debounced state.
 * Returns state, a debounced setter, and an immediate setter for the state.
 * 
 * @param initialValue - Initial state value
 * @param delay - Debounce delay in milliseconds
 * @returns [state, debouncedSetter, immediateSetter]
 */
function useDebouncedState<T>(initialValue: T, delay: number): [T, (value: T) => void, (value: T) => void] {
  const [state, setState] = useState<T>(initialValue);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);
  const mountedRef = useRef(true);

  // Clear timeout on unmount
  useEffect(() => {
    return () => {
      mountedRef.current = false;
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, []);

  // Debounced setter
  const setDebouncedState = useCallback((value: T) => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    
    console.log(`Debouncing state change to ${String(value)} with delay ${delay}ms`);
    
    timeoutRef.current = setTimeout(() => {
      if (mountedRef.current) {
        console.log(`Debounced state change applied: ${String(value)}`);
        setState(value);
      }
    }, delay);
  }, [delay]);

  // Immediate setter that bypasses debounce
  const setImmediateState = useCallback((value: T) => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
    
    console.log(`Immediate state change: ${String(value)}`);
    setState(value);
  }, []);

  return [state, setDebouncedState, setImmediateState];
}

export default useDebouncedState; 