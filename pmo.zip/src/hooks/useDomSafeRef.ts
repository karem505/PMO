import { useRef, useCallback, useState, useEffect } from 'react';

/**
 * A custom hook that provides safe DOM element references with lifecycle awareness.
 * Specifically designed to prevent "Cannot read properties of null (reading 'nodeName')" errors.
 * 
 * @returns An object with ref callback, element state, and utility functions
 */
export function useDomSafeRef<T extends HTMLElement>() {
  // Store the element in state to trigger re-renders when it changes
  const [element, setElement] = useState<T | null>(null);
  
  // Track if the component is mounted
  const isMountedRef = useRef(true);
  
  // Track if the element is ready for DOM operations
  const [isReady, setIsReady] = useState(false);
  
  // Ref callback to set the element
  const refCallback = useCallback((node: T | null) => {
    if (!isMountedRef.current) return;
    
    // Only update if the element actually changed
    if (node !== element) {
      setElement(node);
      
      // If we're getting a new element, reset the ready state
      if (node) {
        // Small delay to ensure the DOM is fully rendered
        setTimeout(() => {
          if (isMountedRef.current) {
            setIsReady(true);
          }
        }, 50);
      } else {
        setIsReady(false);
      }
    }
  }, [element]);
  
  // Safely perform an operation on the element
  const withElement = useCallback(<R>(
    operation: (el: T) => R,
    fallback?: R
  ): R | undefined => {
    if (!element || !isReady || !isMountedRef.current) {
      return fallback;
    }
    
    try {
      return operation(element);
    } catch (error) {
      console.error('Error in DOM operation:', error);
      return fallback;
    }
  }, [element, isReady]);
  
  // Safely get a property from the element
  const getProperty = useCallback(<K extends keyof T>(
    property: K,
    fallback?: T[K]
  ): T[K] | undefined => {
    if (!element || !isReady || !isMountedRef.current) {
      return fallback;
    }
    
    try {
      return element[property];
    } catch (error) {
      console.error(`Error accessing property ${String(property)}:`, error);
      return fallback;
    }
  }, [element, isReady]);
  
  // Safely call a method on the element
  const callMethod = useCallback(<K extends keyof T>(
    method: K,
    args: any[] = [],
    fallback?: any
  ): any => {
    if (!element || !isReady || !isMountedRef.current) {
      return fallback;
    }
    
    try {
      const fn = element[method];
      if (typeof fn === 'function') {
        return (fn as Function).apply(element, args);
      }
      console.warn(`Property ${String(method)} is not a function`);
      return fallback;
    } catch (error) {
      console.error(`Error calling method ${String(method)}:`, error);
      return fallback;
    }
  }, [element, isReady]);
  
  // Clean up on unmount
  useEffect(() => {
    return () => {
      isMountedRef.current = false;
    };
  }, []);
  
  return {
    ref: refCallback,
    element,
    isReady,
    withElement,
    getProperty,
    callMethod
  };
}

export default useDomSafeRef; 