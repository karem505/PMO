import React from 'react';
import { Chart as ChartJS, RadialLinearScale, PointElement, LineElement, Filler, Tooltip, Legend } from 'chart.js';
import { Radar } from 'react-chartjs-2';
import { useLanguage } from '../contexts/LanguageContext';
ChartJS.register(RadialLinearScale, PointElement, LineElement, Filler, Tooltip, Legend);

interface MaturityRadarChartProps {
  domainMaturity: Record<string, number>; // domain name -> maturity level (1-5)
}

const MaturityRadarChart: React.FC<MaturityRadarChartProps> = ({ domainMaturity }) => {
  const { t } = useLanguage();
  const domains = Object.keys(domainMaturity);
  
  const data = {
    labels: domains.map(name => name.split(' ')[0]), // First word of domain name for brevity
    datasets: [
      {
        label: 'Current Maturity',
        data: domains.map(domain => domainMaturity[domain]),
        backgroundColor: 'rgba(95, 45, 248, 0.2)',
        borderColor: 'rgba(95, 45, 248, 1)',
        borderWidth: 2,
        pointBackgroundColor: 'rgba(95, 45, 248, 1)',
        pointBorderColor: '#fff',
        pointHoverBackgroundColor: '#fff',
        pointHoverBorderColor: 'rgba(95, 45, 248, 1)',
        pointRadius: 4,
      },
      {
        label: 'Target Maturity',
        data: domains.map(() => 5), // Target is always level 5 (Innovative)
        backgroundColor: 'rgba(217, 32, 143, 0.1)',
        borderColor: 'rgba(217, 32, 143, 0.6)',
        borderWidth: 1,
        borderDash: [5, 5],
        pointBackgroundColor: 'rgba(217, 32, 143, 0.6)',
        pointBorderColor: '#fff',
        pointRadius: 2,
        fill: false,
      }
    ]
  };
  
  const options = {
    scales: {
      r: {
        angleLines: {
          display: true,
          color: 'rgba(0, 0, 0, 0.1)'
        },
        suggestedMin: 0,
        suggestedMax: 5,
        ticks: {
          stepSize: 1,
          backdropColor: 'transparent',
          callback: (value: any) => {
            return ['', 'Initial', 'Defined', 'Managed', 'Optimized', 'Innovative'][value];
          }
        },
        grid: {
          color: 'rgba(0, 0, 0, 0.05)'
        },
        pointLabels: {
          font: {
            size: 12
          }
        }
      }
    },
    plugins: {
      legend: {
        position: 'bottom' as const,
      },
      tooltip: {
        callbacks: {
          title: (items: any[]) => {
            const index = items[0].dataIndex;
            return domains[index];
          },
          label: (context: any) => {
            const value = context.raw;
            const levelName = ['Initial', 'Defined', 'Managed', 'Optimized', 'Innovative'][value - 1];
            return `Maturity: ${levelName} (Level ${value})`;
          }
        }
      }
    }
  };
  
  return (
    <div className="w-full h-full p-2">
      <h3 className="text-sm font-medium text-gray-700 mb-2 text-center">{t('dashboard.maturityRadarChart', 'Maturity Radar Chart')}</h3>
      <div className="h-64">
        <Radar data={data} options={options} />
      </div>
      <div className="mt-2 text-xs text-gray-500 text-center">
        <p>{t('dashboard.higherValuesIndicateGreaterMaturity', 'Higher values indicate greater maturity')}</p>
      </div>
    </div>
  );
};

export default MaturityRadarChart;