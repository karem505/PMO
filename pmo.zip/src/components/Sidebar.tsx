import React from 'react';
import { NavLink, useNavigate, useLocation, Link } from 'react-router-dom';
import { useAppStore } from '../store';
import { domains, getIconComponent } from '../data';
import { Home, BookOpen, BarChart as ChartBar, CheckSquare, FileText, Lock } from 'lucide-react';
import mylogo from '../assests/logo.jpg';
import { useLanguage } from '../contexts/LanguageContext';
import { useSubscription } from '../contexts/SubscriptionContext';
import { SubscriptionTier } from '../services/subscriptionService';

const Sidebar: React.FC = () => {
  const { getDomainProgress } = useAppStore();
  const { t, isRTL } = useLanguage();
  const navigate = useNavigate();
  const location = useLocation();
  const { tier } = useSubscription();

  // Handle domain navigation
  const navigateToDomain = (domainId: number, e: React.MouseEvent) => {
    e.preventDefault();
    navigate(`/domain/${domainId}`);
  };
  
  // Determine if a domain link is active
  const isDomainActive = (domainId: number) => {
    return location.pathname === `/domain/${domainId}`;
  };

  return (
    <aside className={`flex flex-col w-64 bg-neutral-900 text-white h-screen overflow-y-auto ${isRTL ? 'right-0' : 'left-0'}`}>
      <div className="p-4 border-b border-neutral-800">
        <div className={`flex items-center ${isRTL ? 'flex-row-reverse' : ''}`}>
          <Link to={"/"}>
            <div className="h-10 w-10 bg-gradient-to-br from-primary-500 to-secondary-500 flex items-center justify-center rounded-lg shadow-md">
              <img src={mylogo} alt="PMO Builder Logo" className="h-10 w-10 rounded-lg" />
            </div>
          </Link>
          <div className={`${isRTL ? 'me-3' : 'ms-3'} text-white`}>
            <div className="text-lg font-bold text-white">
              <span style={{color: 'white'}}>PMO Builder</span>
              <span className={`${isRTL ? 'mr-3' : 'ml-3'} text-xs py-0.5 px-1.5 bg-primary-800 text-white rounded-sm font-medium`}>Beta</span>
            </div>
            <div className="text-xs opacity-75">Powered by AI</div>
          </div>
        </div>
      </div>
      
      <div className="p-4 flex-1 overflow-y-auto">
        <nav>
          <div className="mb-6">
            <h3 className="text-xs font-semibold text-neutral-400 uppercase tracking-wider mb-3">
              {t('common.main', 'Main')}
            </h3>
            <ul className="space-y-1">
              <li>
                <NavLink 
                  to="/dashboard" 
                  className={({ isActive }) => 
                    `flex items-center px-2 py-3 text-neutral-300 hover:bg-neutral-800 rounded-lg transition-all duration-200 ${
                      isActive ? 'bg-primary-900/50 text-white' : ''
                    }`}
                >
                  <Home className={`h-5 w-5 ${isRTL ? 'ml-3' : 'mr-3'} text-primary-400`} />
                  <span>{t('sidebar.dashboard')}</span>
                </NavLink>
              </li>
              <li>
                <NavLink 
                  to="/tasks" 
                  className={({ isActive }) => 
                    `flex items-center px-4 py-3 text-neutral-300 hover:bg-neutral-800 rounded-lg transition-all duration-200 ${isActive ? 'bg-primary-900/50 text-white' : ''}`
                  }
                >
                  <CheckSquare className={`h-5 w-5 ${isRTL ? 'ml-3' : 'mr-3'} text-accent-400`} />
                  <span>{t('sidebar.tasks')}</span>
                </NavLink>
              </li>
              <li>
                <NavLink 
                  to="/maturity-assessment" 
                  className={({ isActive }) => 
                    `flex items-center px-4 py-3 text-neutral-300 hover:bg-neutral-800 rounded-lg transition-all duration-200 ${isActive ? 'bg-primary-900/50 text-white' : ''}`
                  }
                >
                  <ChartBar className={`h-5 w-5 ${isRTL ? 'ml-3' : 'mr-3'} text-secondary-400`} />
                  <span>{t('sidebar.maturityAssessment')}</span>
                </NavLink>
              </li>
              <li>
                <NavLink 
                  to="/resources" 
                  className={({ isActive }) => 
                    `flex items-center px-4 py-3 text-neutral-300 hover:bg-neutral-800 rounded-lg transition-all duration-200 ${isActive ? 'bg-primary-900/50 text-white' : ''}`
                  }
                >
                  <BookOpen className={`h-5 w-5 ${isRTL ? 'ml-3' : 'mr-3'} text-emerald-400`} />
                  <span>{t('sidebar.resources', 'Resources')}</span>
                </NavLink>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xs font-semibold text-neutral-400 uppercase tracking-wider mb-3">
              {t('common.domains', 'Domains')}
            </h3>
            <div className="space-y-1">
              {domains.map(domain => {
                const progress = getDomainProgress(domain.id) || { overallProgress: 0 };
                const IconComponent = getIconComponent(domain.icon);
                const isLocked = tier === SubscriptionTier.FREE && domain.id > 2;
                
                return (
                  <NavLink
                    key={domain.id}
                    to={`/domain/${domain.id}`}
                    className={`flex items-center justify-between group px-2 py-3 text-neutral-300 hover:bg-neutral-800 rounded-lg transition-all duration-200 ${
                      isDomainActive(domain.id) ? 'bg-primary-900/50 text-white' : ''
                    }`}
                  >
                    <div className="flex items-center flex-1">
                      {IconComponent && <IconComponent className={`h-5 w-5 ${isRTL ? 'ml-3' : 'mr-3'} text-primary-400`} />}
                      <div className="flex-1">
                        <div className="flex items-center">
                          <span className="block text-sm">{t(`domains.${domain.id}.name`, domain.name)}</span>
                        </div>
                        <div className="w-full h-1 group-hover:bg-neutral-600 bg-neutral-800 rounded-full mt-1 overflow-hidden transition-all duration-300">
                          <div 
                            className="h-full bg-gradient-to-r from-primary-500 to-secondary-500 rounded-full transition-all duration-300"
                            style={{ width: `${progress.overallProgress}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>
                    {isLocked && <Lock className="h-3.5 w-3.5 ml-2 text-neutral-500 flex-shrink-0" />}
                  </NavLink>
                );
              })}
            </div>
          </div>
        </nav>
      </div>
    </aside>
  );
};

export default Sidebar;