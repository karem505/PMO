import React, { useEffect, useState } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from './AuthContext';
import LoadingScreen from '../common/LoadingScreen';
import DashboardSkeleton from '../common/DashboardSkeleton';

interface ProtectedRouteProps {
  children: React.ReactNode;
  redirectTo?: string;
  requiredPermission?: string;
  resourceType?: string;
  resourceId?: string;
  requiredRole?: string;
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ 
  children, 
  redirectTo = '/login',
  requiredPermission,
  resourceType,
  resourceId,
  requiredRole
}) => {
  const { currentUser, isLoading, hasPermission, hasRole } = useAuth();
  const location = useLocation();
  const [showFullLoading, setShowFullLoading] = useState(false);
  const [longLoading, setLongLoading] = useState(false);
  
  // Only show the full loading screen after a short delay
  useEffect(() => {
    if (isLoading) {
      // After 50ms, show skeleton loading screen if still loading
      const timer = setTimeout(() => {
        setShowFullLoading(true);
      }, 50);
      
      // After 1.5 seconds, show the full loading screen with message
      const longTimer = setTimeout(() => {
        setLongLoading(true);
      }, 1500);
      
      return () => {
        clearTimeout(timer);
        clearTimeout(longTimer);
      };
    } else {
      setShowFullLoading(false);
      setLongLoading(false);
    }
  }, [isLoading]);

  // If loading, show appropriate loading indicators
  if (isLoading) {
    if (longLoading) {
      // Show full loading screen with message after extended time
      return <LoadingScreen message="Loading your account data..." />;
    } else if (showFullLoading) {
      // Show skeleton for dashboard or simplified loading for other routes
      return location.pathname.includes('/dashboard') ? 
        <DashboardSkeleton /> : 
        <LoadingScreen message="Loading..." minHeight="min-h-[500px]" showLogo={false} />;
    } else {
      // Initial loading state - just render nothing briefly to avoid flicker
      return null;
    }
  }

  if (!currentUser) {
    // Save the attempted location to redirect after login
    const currentPath = location.pathname + location.search;
    sessionStorage.setItem('redirectAfterLogin', currentPath);
    return <Navigate to={redirectTo} replace state={{ from: location }} />;
  }
  
  // Check for required permission
  if (requiredPermission) {
    const hasRequiredPermission = hasPermission(
      requiredPermission, 
      resourceType, 
      resourceId
    );
    
    if (!hasRequiredPermission) {
      return <Navigate to="/" replace />;
    }
  }
  
  // Check for required role
  if (requiredRole && !hasRole(requiredRole)) {
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
};

export default ProtectedRoute;