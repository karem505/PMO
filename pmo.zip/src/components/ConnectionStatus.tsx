import React, { useEffect, useState } from 'react';
import { useAppStore } from '../store';
import { AlertTriangle, Wifi, WifiOff, RefreshCw, CheckCircle } from 'lucide-react';
import { testSupabaseConnection } from '../services/supabaseClient';

interface ConnectionStatusProps {
  showDetailed?: boolean;
}

const ConnectionStatus: React.FC<ConnectionStatusProps> = ({ showDetailed = false }) => {
  const { connectionError, setConnectionError, showConnectionErrors } = useAppStore();
  const [isChecking, setIsChecking] = useState(false);
  const [lastChecked, setLastChecked] = useState<Date | null>(null);
  const [manualCheck, setManualCheck] = useState(false);

  // Check connection status periodically or when requested
  useEffect(() => {
    // Only run checks when component is mounted and visible
    const checkConnection = async () => {
      if (isChecking) return;
      
      setIsChecking(true);
      try {
        const result = await testSupabaseConnection();
        setConnectionError(!result.success);
        setLastChecked(new Date());
      } catch (error) {
        console.error('Connection check failed:', error);
        setConnectionError(true);
      } finally {
        setIsChecking(false);
        setManualCheck(false);
      }
    };
    
    // Check on first render
    checkConnection();
    
    // Set up periodic checking with reduced frequency
    const interval = setInterval(() => {
      // Only check if we previously had an error, or if it's been a long time
      if (connectionError || !lastChecked || (Date.now() - lastChecked.getTime() > 10 * 60 * 1000)) {
        checkConnection();
      }
    }, 180000); // Changed from 30s to 3 minutes (180000ms)
    
    // Check when browser comes back online
    const handleOnline = () => {
      checkConnection();
    };
    
    window.addEventListener('online', handleOnline);
    
    // If a manual check was requested
    if (manualCheck) {
      checkConnection();
    }
    
    return () => {
      clearInterval(interval);
      window.removeEventListener('online', handleOnline);
    };
  }, [connectionError, manualCheck]);

  // If no connection error, don't show anything unless detailed view is requested
  if ((!connectionError && !showDetailed) || !showConnectionErrors) {
    return null;
  }

  return (
    <div className={`rounded-lg p-4 ${
      connectionError 
        ? 'bg-amber-50 border border-amber-200' 
        : 'bg-green-50 border border-green-200'
    }`}>
      <div className="flex items-start">
        {connectionError ? (
          <WifiOff className="h-5 w-5 text-amber-500 mt-0.5 mr-2 flex-shrink-0" />
        ) : (
          <Wifi className="h-5 w-5 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
        )}
        <div>
          <p className={`text-sm font-medium ${
            connectionError ? 'text-amber-800' : 'text-green-800'
          }`}>
            {connectionError 
              ? 'Working in offline mode' 
              : 'Connected to database'}
          </p>
          <p className={`text-xs ${
            connectionError ? 'text-amber-700' : 'text-green-700'
          } mt-1`}>
            {connectionError 
              ? 'You can continue working. Changes will be saved locally and synced when your connection is restored.'
              : 'Your changes are being saved to the cloud.'}
          </p>
        </div>
        <button
          onClick={() => setManualCheck(true)}
          className={`ml-auto p-1.5 rounded-md ${
            connectionError 
              ? 'text-amber-700 hover:bg-amber-100' 
              : 'text-green-700 hover:bg-green-100'
          }`}
          disabled={isChecking}
        >
          {isChecking ? (
            <RefreshCw className="h-4 w-4 animate-spin" />
          ) : (
            <RefreshCw className="h-4 w-4" />
          )}
        </button>
      </div>
      {showDetailed && (
        <div className="mt-2 pt-2 border-t border-dashed border-gray-200">
          <div className="flex justify-between items-center text-xs text-gray-500">
            <span>
              Last checked: {lastChecked ? lastChecked.toLocaleTimeString() : 'Never'}
            </span>
            {!connectionError && (
              <span className="flex items-center text-green-600">
                <CheckCircle className="h-3 w-3 mr-1" />
                All systems operational
              </span>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default ConnectionStatus;