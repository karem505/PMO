import React from 'react';
import { useTheme } from '../ThemeContext';
import { useLanguage } from '../LanguageContext';
import { Sun, Moon, LanguagesIcon, Check } from 'lucide-react';
import { useAppStore } from '../store';

interface SettingsOption {
  id: string;
  label: string;
}

const SettingsPanel: React.FC = () => {
  const { toggleDarkMode, darkMode } = useTheme();
  const { language, setLanguage, t, availableLanguages } = useLanguage();
  const { connectionError, showConnectionErrors, setShowConnectionErrors } = useAppStore();
  
  const languageOptions: SettingsOption[] = availableLanguages.map(lang => ({
    id: lang.code,
    label: lang.name
  }));

  return (
    <div className="p-4 space-y-6">
      <div>
        <h3 className="text-lg font-medium mb-3">{t('settings.appearance', 'Appearance')}</h3>
        <div className="flex items-center justify-between">
          <span className="text-sm">{t('settings.darkMode', 'Dark Mode')}</span>
          <button
            onClick={toggleDarkMode}
            className={`p-2 rounded-full ${darkMode ? 'bg-indigo-100 dark:bg-indigo-900/40' : 'bg-amber-100 dark:bg-slate-800'}`}
          >
            {darkMode ? <Moon className="h-5 w-5 text-indigo-600 dark:text-indigo-400" /> : <Sun className="h-5 w-5 text-amber-600" />}
          </button>
        </div>
      </div>
      
      <div>
        <h3 className="text-lg font-medium mb-3">{t('settings.language', 'Language')}</h3>
        <div className="grid grid-cols-2 gap-2">
          {languageOptions.map(option => (
            <button
              key={option.id}
              className={`py-2 px-3 rounded-md flex items-center justify-between ${
                language === option.id 
                  ? 'bg-indigo-100 text-indigo-700 dark:bg-indigo-900/40 dark:text-indigo-300' 
                  : 'bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700'
              }`}
              onClick={() => setLanguage(option.id)}
            >
              <span className="flex items-center">
                <LanguagesIcon className="h-4 w-4 mr-2" />
                {option.label}
              </span>
              {language === option.id && <Check className="h-4 w-4" />}
            </button>
          ))}
        </div>
      </div>
      
      <div>
        <h3 className="text-lg font-medium mb-3">{t('settings.notifications', 'Notifications')}</h3>
        <div className="flex items-center justify-between">
          <span className="text-sm">{t('settings.showConnectionAlerts', 'Show Offline Mode Alerts')}</span>
          <label className="relative inline-flex items-center cursor-pointer">
            <input 
              type="checkbox" 
              className="sr-only peer" 
              checked={showConnectionErrors}
              onChange={() => setShowConnectionErrors(!showConnectionErrors)}
            />
            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
          </label>
        </div>
      </div>
    </div>
  );
};

export default SettingsPanel; 