import React, { useState, useRef, useEffect } from 'react';
import { BarChart as FlowChart, Network, GitBranch, List, Workflow, ChevronDown, X } from 'lucide-react';

interface VisualizeButtonProps {
  onVisualize: (type: string) => void;
  className?: string;
}

const VisualizeButton: React.FC<VisualizeButtonProps> = ({ onVisualize, className = '' }) => {
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);
  const menuItemRefs = useRef<(HTMLButtonElement | null)[]>([]);

  const diagramTypes = [
    { id: 'flowchart', label: 'Process Flow', icon: FlowChart, description: 'Visualize process steps and decision points' },
    { id: 'sequence', label: 'Sequence Diagram', icon: GitBranch, description: 'Show interactions between different components' },
    { id: 'classDiagram', label: 'Structure Chart', icon: Network, description: 'Display organizational or system structures' },
    { id: 'stateDiagram', label: 'State Diagram', icon: Workflow, description: 'Visualize state transitions and conditions' },
    { id: 'gantt', label: 'Gantt Chart', icon: List, description: 'Show project timeline and dependencies' }
  ];

  // Close menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node) && 
          buttonRef.current && !buttonRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    // Close menu when pressing escape
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && isOpen) {
        setIsOpen(false);
        buttonRef.current?.focus();
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('keydown', handleKeyDown);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen]);

  // Focus first menu item when opening
  useEffect(() => {
    if (isOpen && menuItemRefs.current[0]) {
      menuItemRefs.current[0].focus();
    }
  }, [isOpen]);

  const handleSelect = (type: string) => {
    onVisualize(type);
    setIsOpen(false);
    buttonRef.current?.focus();
  };

  return (
    <div className={`relative inline-block ${className}`}>
      <button
        ref={buttonRef}
        onClick={() => setIsOpen(!isOpen)}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ' || e.key === 'ArrowDown') {
            e.preventDefault();
            setIsOpen(true);
          }
        }}
        className="px-3 py-1.5 bg-white border border-gray-200 rounded-md hover:bg-gray-50 text-gray-700 font-medium flex items-center"
        aria-expanded={isOpen}
        aria-haspopup="true"
        id="visualize-button"
      >
        <FlowChart className="h-4 w-4 mr-2 text-primary-600" />
        Visualize
        <ChevronDown className={`h-4 w-4 ml-1.5 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <div 
          ref={menuRef}
          className="origin-top-right absolute right-0 mt-2 w-80 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 z-50"
          role="menu"
          aria-orientation="vertical"
          aria-labelledby="visualize-button"
        >
          <div className="py-1 border-b border-gray-100">
            <div className="px-4 py-2 flex items-center justify-between">
              <h3 className="text-sm font-medium text-gray-800">Generate Visualization</h3>
              <button
                className="rounded-full p-1 hover:bg-gray-100 text-gray-400"
                onClick={() => {
                  setIsOpen(false);
                  buttonRef.current?.focus();
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    setIsOpen(false);
                    buttonRef.current?.focus();
                  }
                }}
                aria-label="Close menu"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>
          
          <div className="p-2 space-y-1">
            {diagramTypes.map((type, index) => (
              <button
                key={type.id}
                ref={(el) => menuItemRefs.current[index] = el}
                className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-md flex items-center"
                onClick={() => handleSelect(type.id)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    handleSelect(type.id);
                  } else if (e.key === 'ArrowDown') {
                    e.preventDefault();
                    const nextIndex = (index + 1) % diagramTypes.length;
                    menuItemRefs.current[nextIndex]?.focus();
                  } else if (e.key === 'ArrowUp') {
                    e.preventDefault();
                    const prevIndex = (index - 1 + diagramTypes.length) % diagramTypes.length;
                    menuItemRefs.current[prevIndex]?.focus();
                  }
                }}
                role="menuitem"
                aria-label={`Generate ${type.label}`}
              >
                <span className="p-1 rounded-md bg-blue-50 mr-3">
                  <type.icon className="h-4 w-4 text-primary-600" />
                </span>
                <div>
                  <span className="font-medium">{type.label}</span>
                  <p className="text-xs text-gray-500 mt-0.5">{type.description}</p>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default VisualizeButton;