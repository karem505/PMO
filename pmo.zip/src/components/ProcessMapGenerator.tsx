import React, { useState, useEffect } from 'react';
import { BarChart as FlowChart, GitBranch, Network, Workflow, Loader2, AlertTriangle, Sparkles, Info } from 'lucide-react';
import DiagramGenerator from './DiagramGenerator';

interface ProcessMapGeneratorProps {
  text: string;
  title?: string;
  onError?: (error: Error) => void;
}

const ProcessMapGenerator: React.FC<ProcessMapGeneratorProps> = ({ 
  text, 
  title = "Process Flow",
  onError
}) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [diagramType, setDiagramType] = useState<string>("flowchart");
  const [processText, setProcessText] = useState<string>("");
  
  // Identify the most suitable diagram type and relevant text
  useEffect(() => {
    if (!text) return;
    
    setIsGenerating(true);
    
    try {
      // Analyze text to determine best diagram type
      const lowerCaseText = text.toLowerCase();
      let selectedType = "flowchart"; // default
      
      // Check for sequence-related content
      if (
        (lowerCaseText.includes("sequence") && lowerCaseText.includes("step")) ||
        (lowerCaseText.includes("first") && lowerCaseText.includes("then") && lowerCaseText.includes("finally")) ||
        (lowerCaseText.includes("communication") && lowerCaseText.includes("between"))
      ) {
        selectedType = "sequence";
      } 
      // Check for organization structure content
      else if (
        (lowerCaseText.includes("structure") && lowerCaseText.includes("organization")) ||
        (lowerCaseText.includes("hierarchy") && lowerCaseText.includes("report")) ||
        (lowerCaseText.includes("department") && lowerCaseText.includes("unit"))
      ) {
        selectedType = "classDiagram";
      }
      // Check for state transition content
      else if (
        (lowerCaseText.includes("state") && lowerCaseText.includes("transition")) ||
        (lowerCaseText.includes("phase") && lowerCaseText.includes("move")) ||
        (lowerCaseText.includes("status") && lowerCaseText.includes("change"))
      ) {
        selectedType = "stateDiagram";
      }
      
      setDiagramType(selectedType);
      
      // Extract relevant section from text
      let relevantText = text;
      
      // Look for headings that might indicate process sections
      const processHeadingRegex = /#{1,3}\s+(process|workflow|procedure|steps|flow|sequence|structure|organization|state)/i;
      const match = text.match(processHeadingRegex);
      
      if (match && match.index !== undefined) {
        // Extract from the heading to the next heading or end
        const startIndex = match.index;
        const nextHeadingMatch = text.substring(startIndex + match[0].length).match(/#{1,3}\s+/);
        
        if (nextHeadingMatch && nextHeadingMatch.index !== undefined) {
          relevantText = text.substring(
            startIndex, 
            startIndex + match[0].length + nextHeadingMatch.index
          );
        } else {
          relevantText = text.substring(startIndex);
        }
      } else {
        // If no process heading found, look for paragraphs with process indicators
        const paragraphs = text.split('\n\n');
        const processParagraphs = paragraphs.filter(p => 
          p.toLowerCase().includes('process') || 
          p.toLowerCase().includes('step') || 
          p.toLowerCase().includes('workflow') ||
          p.toLowerCase().includes('procedure')
        );
        
        if (processParagraphs.length > 0) {
          relevantText = processParagraphs.join('\n\n');
        } else {
          // Just use the beginning of the text (first 2000 chars)
          relevantText = text.substring(0, Math.min(2000, text.length));
        }
      }
      
      setProcessText(relevantText);
      setIsGenerating(false);
      
    } catch (err) {
      console.error('Error analyzing text:', err);
      setError('Failed to analyze text content');
      setIsGenerating(false);
      
      // Call onError prop if provided
      if (onError && err instanceof Error) {
        onError(err);
      } else if (onError) {
        onError(new Error('Failed to analyze text content'));
      }
      
      // Use default values in case of error
      setDiagramType("flowchart");
      setProcessText(text.substring(0, Math.min(2000, text.length)));
    }
  }, [text, onError]);
  
  // Get the appropriate icon for the diagram type
  const getDiagramIcon = () => {
    switch (diagramType) {
      case 'sequence':
        return <GitBranch className="h-5 w-5 text-blue-600" />;
      case 'classDiagram':
        return <Network className="h-5 w-5 text-green-600" />;
      case 'stateDiagram':
        return <Workflow className="h-5 w-5 text-purple-600" />;
      default:
        return <FlowChart className="h-5 w-5 text-blue-600" />;
    }
  };
  
  const getDiagramTitle = () => {
    switch (diagramType) {
      case 'sequence':
        return 'Process Sequence Diagram';
      case 'classDiagram':
        return 'Organizational Structure';
      case 'stateDiagram':
        return 'State Transition Diagram';
      default:
        return 'Process Flow';
    }
  };

  if (isGenerating) {
    return (
      <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200 flex flex-col items-center justify-center">
        <Loader2 className="h-8 w-8 text-blue-600 animate-spin mb-4" />
        <p className="text-gray-700 font-medium">Analyzing content...</p>
        <p className="text-gray-500 text-sm mt-1">Identifying process elements and relationships</p>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
        <div className="flex items-start text-red-600 mb-4">
          <AlertTriangle className="h-5 w-5 mr-2 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-medium">Process Map Generation Error</p>
            <p className="text-sm mt-1">{error}</p>
          </div>
        </div>
        <button
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center"
          onClick={() => {
            setError(null);
            setIsGenerating(true);
            // Reset and try again with default settings
            setDiagramType("flowchart");
            setProcessText(text.substring(0, Math.min(2000, text.length)));
            setIsGenerating(false);
          }}
        >
          <Sparkles className="h-4 w-4 mr-2" />
          Try Again
        </button>
      </div>
    );
  }

  if (!processText) {
    return (
      <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200 text-center">
        <FlowChart className="h-12 w-12 text-gray-300 mx-auto mb-3" />
        <p className="text-gray-600 font-medium">No process content detected</p>
        <p className="text-gray-500 text-sm mt-1 mb-4">
          The system couldn't identify process-related content to visualize
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <DiagramGenerator
        textContent={processText}
        diagramType={diagramType as any}
        title={getDiagramTitle()}
        onError={onError}
      />
      
      <div className="bg-blue-50 p-4 rounded-md border border-blue-100">
        <div className="flex items-start">
          <Info className="h-5 w-5 text-blue-600 mr-3 mt-0.5 flex-shrink-0" />
          <div>
            <p className="text-sm text-blue-700">
              <span className="font-medium">About this visualization:</span> This diagram was automatically generated from the text content using AI. The system analyzes your content to identify processes, relationships, and structures, then creates a visual representation.
            </p>
            <p className="text-sm text-blue-700 mt-2">
              For best results, ensure your text includes clear process steps, decision points, and relationships between elements.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProcessMapGenerator;