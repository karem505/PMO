import React, { useEffect, useRef, useState } from 'react';
import { BarChart as FlowChart, Download, AlertCircle, Loader2 } from 'lucide-react';

interface DiagramGeneratorProps {
  textContent: string;
  diagramType?: 'flowchart' | 'sequence' | 'classDiagram' | 'stateDiagram' | 'gantt' | 'pieChart' | 'er';
  title?: string;
  onError?: (error: Error) => void;
}

const DiagramGenerator: React.FC<DiagramGeneratorProps> = ({ 
  textContent, 
  diagramType = 'flowchart',
  title = 'Process Flow',
  onError
}) => {
  const [diagramCode, setDiagramCode] = useState<string>('');
  const [isRendering, setIsRendering] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const diagramRef = useRef<HTMLDivElement>(null);
  const [renderAttempts, setRenderAttempts] = useState(0);

  // Simple diagram code generation without AI - much faster
  const generateDiagramCode = (): string => {
    // Extract steps or items from text content
    const lines = textContent.split('\n');
    const steps: string[] = [];
    
    // Look for numbered lists, bullet points or section headings
    for (const line of lines) {
      if (/^(\d+\.\s|\-\s|\*\s|#{1,3}\s)(.+)/.test(line)) {
        const match = line.match(/^(?:\d+\.\s|\-\s|\*\s|#{1,3}\s)(.+)/);
        if (match && match[1]) {
          steps.push(match[1].trim());
        }
      }
    }
    
    // If we couldn't find enough steps, look for sentences
    if (steps.length < 3) {
      const sentences = textContent.match(/[^.!?]+[.!?]+/g) || [];
      for (const sentence of sentences) {
        if (sentence.includes('process') || 
            sentence.includes('step') ||
            sentence.includes('phase') ||
            sentence.includes('stage')) {
          steps.push(sentence.trim());
          if (steps.length >= 5) break; // Don't get too many
        }
      }
    }
    
    // Limit steps for performance
    const limitedSteps = steps.slice(0, Math.min(7, steps.length));
    
    // If we still don't have enough steps, create a simple diagram
    if (limitedSteps.length < 3) {
      if (diagramType === 'flowchart') {
        return `graph TD
  A[Start Process] --> B[Assess Current State]
  B --> C{Is Assessment Complete?}
  C -->|Yes| D[Design Solution]
  C -->|No| B
  D --> E[Implement Solution]
  E --> F[Review Results]
  F --> G{Is Successful?}
  G -->|Yes| H[Monitor & Maintain]
  G -->|No| D`;
      } else if (diagramType === 'sequence') {
        return `sequenceDiagram
  participant P as PMO
  participant S as Stakeholders
  participant T as Team
  P->>S: Request Requirements
  S->>P: Provide Requirements
  P->>T: Assign Tasks
  T->>P: Deliver Results
  P->>S: Present Outputs`;
      } else {
        // Default simple diagram
        return `graph TD
  A[Start] --> B[Process]
  B --> C[End]`;
      }
    }
    
    // Create diagram based on type
    if (diagramType === 'flowchart') {
      // Create a flowchart with the steps
      let code = 'graph TD\n';
      
      // Add nodes
      for (let i = 0; i < limitedSteps.length; i++) {
        const step = limitedSteps[i].replace(/"/g, "'");
        code += `  step${i}["${step}"]\n`;
      }
      
      // Add connections
      for (let i = 0; i < limitedSteps.length - 1; i++) {
        code += `  step${i} --> step${i+1}\n`;
      }
      
      return code;
    } else if (diagramType === 'sequence') {
      // Create a sequence diagram with generic participants
      let code = 'sequenceDiagram\n';
      code += '  participant A as PMO\n';
      code += '  participant B as Team\n';
      code += '  participant C as Stakeholders\n';
      
      // Add simple sequences based on the steps
      for (let i = 0; i < limitedSteps.length; i++) {
        const step = limitedSteps[i].replace(/"/g, "'");
        if (i % 3 === 0) {
          code += `  A->>B: ${step}\n`;
        } else if (i % 3 === 1) {
          code += `  B->>C: ${step}\n`;
        } else {
          code += `  C->>A: ${step}\n`;
        }
      }
      
      return code;
    } else if (diagramType === 'classDiagram') {
      // Create a simple class diagram
      let code = 'classDiagram\n';
      code += '  class PMO {\n    +manage()\n  }\n';
      code += '  class Team {\n    +execute()\n  }\n';
      code += '  class Process {\n    +implement()\n  }\n';
      
      // Add relationships
      code += '  PMO --> Team\n';
      code += '  Team --> Process\n';
      
      return code;
    }
    
    // Default simple graph
    return `graph TD
  A[Start] --> B[Process]
  B --> C[End]`;
  };

  useEffect(() => {
    async function initializeDiagram() {
      try {
        // Generate a simple diagram code
        const code = generateDiagramCode();
        setDiagramCode(code);
      } catch (error) {
        console.error('Error generating diagram code:', error);
        setError('Failed to generate diagram code');
        
        // Call onError prop if provided
        if (onError && error instanceof Error) {
          onError(error);
        } else if (onError) {
          onError(new Error('Failed to generate diagram code'));
        }
      }
    }
    
    initializeDiagram();
  }, [textContent, diagramType, onError]);

  useEffect(() => {
    // Render the diagram whenever the code changes
    if (diagramCode) {
      renderDiagram();
    }
  }, [diagramCode, renderAttempts]);

  const renderDiagram = async () => {
    if (!diagramCode || !diagramRef.current) return;
    
    setIsRendering(true);
    setError(null);
    
    try {
      // Clear the container first
      diagramRef.current.innerHTML = '';
      
      // Dynamic import of mermaid - only load when needed
      const mermaidPromise = import('mermaid').then(m => m.default);
      
      // Set a timeout in case mermaid loading takes too long
      const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => reject(new Error('Diagram rendering timed out')), 5000);
      });
      
      // Race between loading mermaid and timeout
      const mermaid = await Promise.race([mermaidPromise, timeoutPromise]) as {
        initialize: (config: any) => void;
        run: () => Promise<void>;
      };
      
      // Configure mermaid with simplified settings for speed
      mermaid.initialize({
        startOnLoad: false,
        theme: 'neutral',
        securityLevel: 'loose',
        fontFamily: 'sans-serif', // Simpler font
        fontSize: 14,
        flowchart: {
          useMaxWidth: true,
          htmlLabels: true,
          curve: 'basis'
        },
        themeVariables: {
          primaryColor: '#3b82f6',
          primaryTextColor: '#ffffff',
          primaryBorderColor: '#3b82f6',
          lineColor: '#666666',
          secondaryColor: '#6366f1',
          tertiaryColor: '#f0f9ff'
        }
      });
      
      // Create a new div for the diagram
      const diagramDiv = document.createElement('div');
      diagramDiv.className = 'mermaid';
      diagramDiv.textContent = diagramCode;
      diagramRef.current.appendChild(diagramDiv);
      
      // Try to render with a timeout
      const renderPromise = mermaid.run();
      await Promise.race([
        renderPromise,
        new Promise((_, reject) => setTimeout(() => reject(new Error('Render timeout')), 5000))
      ]);
      
      setIsRendering(false);
    } catch (err) {
      console.error('Error rendering diagram:', err);
      setError('Failed to render diagram. Trying simplified version...');
      
      // Call onError prop if provided
      if (onError && err instanceof Error) {
        onError(err);
      } else if (onError) {
        onError(new Error('Failed to render diagram'));
      }
      
      // If first attempt failed, try with a much simpler diagram
      if (renderAttempts < 1) {
        setRenderAttempts(prev => prev + 1);
        setDiagramCode(`graph TD
  A[Start] --> B[Process]
  B --> C[End]`);
      } else {
        // If still failing, show error
        setIsRendering(false);
      }
    }
  };

  const handleExportDiagram = () => {
    if (!diagramRef.current) return;
    
    try {
      const svg = diagramRef.current.querySelector('svg');
      if (!svg) {
        console.error('No SVG found for export');
        return;
      }
      
      // Convert SVG to data URL
      const svgData = new XMLSerializer().serializeToString(svg);
      const svgBlob = new Blob([svgData], {type: 'image/svg+xml;charset=utf-8'});
      const url = URL.createObjectURL(svgBlob);
      
      // Download
      const a = document.createElement('a');
      a.href = url;
      a.download = `${title.replace(/\s+/g, '-').toLowerCase()}.svg`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error exporting diagram:', error);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-100 mb-6">
      <div className="flex items-center justify-between p-4 border-b border-gray-100">
        <h3 className="font-semibold text-gray-800 flex items-center">
          <FlowChart className="h-5 w-5 mr-2 text-primary-600" />
          {title}
        </h3>
        
        {!isRendering && !error && diagramCode && (
          <button 
            onClick={handleExportDiagram}
            className="p-1.5 rounded-md border border-gray-200 text-gray-600 hover:bg-gray-50"
          >
            <Download className="h-4 w-4" />
          </button>
        )}
      </div>
      
      <div className="p-4 min-h-[300px] flex items-center justify-center">
        {isRendering ? (
          <div className="flex flex-col items-center justify-center p-8">
            <Loader2 className="h-8 w-8 text-blue-500 animate-spin mb-4" />
            <p className="text-gray-600">Rendering diagram...</p>
          </div>
        ) : error ? (
          <div className="p-6 text-center">
            <AlertCircle className="h-10 w-10 text-red-500 mx-auto mb-4" />
            <p className="text-red-600 font-medium mb-2">{error}</p>
            <p className="text-gray-500 text-sm">Try with shorter text or a different diagram type</p>
          </div>
        ) : (
          <div ref={diagramRef} className="max-w-full overflow-auto" />
        )}
      </div>
    </div>
  );
};

export default DiagramGenerator;