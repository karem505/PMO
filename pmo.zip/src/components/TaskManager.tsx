import React, { useState, useEffect } from 'react';
import { Task, DocumentChunk } from '../types';
import { useAppStore } from '../store';
import { Save, Trash2, Edit, X, Check, Loader2, AlertTriangle, Calendar, Paperclip, Tag, Users, Clock, ArrowUp as FileArrowUp, FileText, Download } from 'lucide-react';
import TaskFileAttachment from './TaskFileAttachment';
import { documentProcessingService } from '../services/documentProcessingService';
import { supabase } from '../services/supabaseClient';
import TaskOutputAcceptance from './TaskOutputAcceptance';
import { useToast } from '../hooks/useToast';

interface TaskManagerProps {
  task: Task;
  onUpdate?: () => void;
  onDelete?: () => void;
}

const TaskManager: React.FC<TaskManagerProps> = ({ task, onUpdate, onDelete }) => {
  const { getActiveProject, updateTaskData } = useAppStore();
  const [isEditing, setIsEditing] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const toast = useToast();
  
  const [notes, setNotes] = useState('');
  const [completed, setCompleted] = useState(false);
  const [attachments, setAttachments] = useState<Array<{name: string, url: string, id: string, size?: number, type?: string}>>([]);
  const [customFields, setCustomFields] = useState<Record<string, any>>({});
  const [relatedDocuments, setRelatedDocuments] = useState<DocumentChunk[]>([]);
  const [acceptanceStatus, setAcceptanceStatus] = useState<'idle' | 'accepted' | 'needs-refinement' | 'rejected'>('idle');
  const [acceptanceTimestamp, setAcceptanceTimestamp] = useState<string | null>(null);

  const activeProject = getActiveProject();

  useEffect(() => {
    // Load existing task data
    if (activeProject) {
      const taskData = activeProject.domainData?.tasks?.[task.id] || {};
      setNotes(taskData.notes || '');
      setCompleted(taskData.completed || false);
      
      // Parse attachments from stored JSON strings
      const storedAttachments = taskData.attachments || [];
      const parsedAttachments = storedAttachments
        .map(att => {
          try {
            return typeof att === 'string' ? JSON.parse(att) : att;
          } catch (e) {
            console.error('Error parsing attachment:', e);
            return null;
          }
        })
        .filter(att => att !== null);
      
      setAttachments(parsedAttachments);
      setCustomFields(taskData.customFields || {});
      
      // Load acceptance status if available
      if (taskData.acceptanceStatus) {
        setAcceptanceStatus(taskData.acceptanceStatus);
      }
      
      if (taskData.acceptanceTimestamp) {
        setAcceptanceTimestamp(taskData.acceptanceTimestamp);
      }
      
      // Fetch related documents
      if (activeProject.id) {
        fetchRelatedDocuments(activeProject.id, task.domainId);
      }
    }
  }, [task.id, activeProject]);
  
  const fetchRelatedDocuments = async (projectId: string, domainId: number) => {
    try {
      const docs = await documentProcessingService.getDomainDocuments(domainId, projectId);
      setRelatedDocuments(docs);
    } catch (error) {
      console.error('Error fetching related documents:', error);
    }
  };
  
  const handleSave = async () => {
    if (!task || !activeProject) return;
    
    setIsSaving(true);
    
    try {
      // Update task data in store
      await updateTaskData(task.id, {
        notes,
        completed,
        attachments: attachments.map(a => typeof a === 'string' ? a : JSON.stringify(a)),
        customFields,
        acceptanceStatus,
        acceptanceTimestamp
      });
      
      // Call onUpdate callback to notify parent component
      if (onUpdate) {
        onUpdate();
      }
      
      setIsEditing(false);
      toast.success('Task data saved successfully');
    } catch (error) {
      console.error('Error saving task:', error);
      toast.error('Failed to save task data');
    } finally {
      setIsSaving(false);
    }
  };
  
  // Function to update local task data
  const setTaskData = (data: any) => {
    // This is just for type compatibility with the earlier code
    // The actual data is updated through the store
    console.log("Task data updated:", data);
  };
  
  const handleDelete = async () => {
    if (!isDeleting) {
      setIsDeleting(true);
      return;
    }
    
    try {
      // In a real implementation, we would delete the task from the database
      // Since we're using a fixed list of tasks, we'll just reset the task data
      updateTaskData(task.id, {
        notes: '',
        completed: false,
        attachments: [],
        customFields: {},
        acceptanceStatus: 'idle',
        acceptanceTimestamp: null
      });
      
      // Delete attachments from storage
      if (activeProject && attachments.length > 0) {
        try {
          const filePaths = attachments.map(att => `tasks/${task.id}/${att.id}`);
          await supabase.storage
            .from('task-attachments')
            .remove(filePaths);
        } catch (error) {
          console.error('Error deleting attachments:', error);
        }
      }
      
      if (onDelete) onDelete();
      setIsDeleting(false);
      toast.info('Task data has been reset');
    } catch (error) {
      console.error('Error deleting task data:', error);
      toast.error('Failed to delete task data. Please try again.');
      setIsDeleting(false);
    }
  };
  
  const handleAttachmentUpdate = (newAttachments: Array<{name: string, url: string, id: string, size: number, type: string}>) => {
    setAttachments(newAttachments);
  };
  
  // Handle output acceptance
  const handleOutputAcceptance = (content: string, status: 'accepted' | 'needs-refinement' | 'rejected', taskCompleted?: boolean) => {
    // Set the status in local state
    setAcceptanceStatus(status);
    setAcceptanceTimestamp(new Date().toISOString());
    
    // Update the notes with the latest content
    setNotes(content);
    
    // If task should be marked complete, update that too
    if (taskCompleted) {
      setCompleted(true);
    }
    
    // Save the changes to the task data
    updateTaskData(task.id, {
      notes: content,
      acceptanceStatus: status,
      acceptanceTimestamp: new Date().toISOString(),
      completed: taskCompleted || completed
    });
  };
  
  // Get task data from active project or fall back to userData
  const getTaskData = () => {
    if (activeProject && activeProject.domainData && activeProject.domainData.tasks && activeProject.domainData.tasks[task.id]) {
      return activeProject.domainData.tasks[task.id];
    }
    
    // Get from userData as fallback for backward compatibility
    const { userData } = useAppStore.getState();
    return userData.tasks[task.id] || { completed: false, notes: '', attachments: [], customFields: {} };
  };
  
  const taskData = getTaskData();
  
  return (
    <div className="p-4 bg-white rounded-lg border border-gray-200 shadow-sm">
      <div className="flex justify-between items-start">
        <h3 className="text-lg font-semibold text-gray-800">{task.title}</h3>
        
        <div className="flex space-x-2">
          {!isEditing ? (
            <button 
              onClick={() => setIsEditing(true)}
              className="p-1.5 text-gray-400 hover:text-blue-500 hover:bg-gray-100 rounded transition-colors"
            >
              <Edit className="h-4 w-4" />
            </button>
          ) : (
            <button 
              onClick={() => setIsEditing(false)}
              className="p-1.5 text-gray-400 hover:text-red-500 hover:bg-gray-100 rounded transition-colors"
            >
              <X className="h-4 w-4" />
            </button>
          )}
          
          <button 
            onClick={handleDelete}
            className={`p-1.5 hover:bg-gray-100 rounded transition-colors ${
              isDeleting ? 'text-red-500' : 'text-gray-400 hover:text-red-500'
            }`}
          >
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      </div>
      
      <p className="text-gray-600 text-sm mt-2">{task.description}</p>
      
      {/* Task status and details section */}
      <div className="mt-4 pt-4 border-t border-gray-100">
        {isEditing ? (
          <div className="space-y-4">
            {/* Completion toggle */}
            <div className="flex items-center">
              <input
                type="checkbox"
                id={`complete-${task.id}`}
                checked={completed}
                onChange={(e) => setCompleted(e.target.checked)}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
              <label htmlFor={`complete-${task.id}`} className="ml-2 text-sm text-gray-700">
                Mark as completed
              </label>
            </div>
            
            {/* Notes editor */}
            <div>
              <label htmlFor={`notes-${task.id}`} className="block text-sm font-medium text-gray-700 mb-1">
                Notes
              </label>
              <textarea
                id={`notes-${task.id}`}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 text-neutral-800 text-sm"
                rows={4}
                placeholder="Add notes about this task..."
              ></textarea>
            </div>
            
            {/* Custom fields - can be expanded based on task requirements */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center">
                <Tag className="h-4 w-4 mr-1.5 text-gray-500" />
                Priority
              </label>
              <select
                value={customFields.priority || 'medium'}
                onChange={(e) => setCustomFields({...customFields, priority: e.target.value})}
                className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 text-neutral-800 text-sm"
              >
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
              </select>
            </div>
            
            {/* Due date field */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center">
                <Calendar className="h-4 w-4 mr-1.5 text-gray-500" />
                Target Completion Date
              </label>
              <input
                type="date"
                value={customFields.dueDate || ''}
                onChange={(e) => setCustomFields({...customFields, dueDate: e.target.value})}
                className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 text-neutral-800 text-sm"
              />
            </div>

            {/* Assigned to */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center">
                <Users className="h-4 w-4 mr-1.5 text-gray-500" />
                Assigned To
              </label>
              <input
                type="text"
                value={customFields.assignedTo || ''}
                onChange={(e) => setCustomFields({...customFields, assignedTo: e.target.value})}
                className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 text-neutral-800 text-sm"
                placeholder="Enter name"
              />
            </div>

            {/* Estimated hours */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center">
                <Clock className="h-4 w-4 mr-1.5 text-gray-500" />
                Estimated Hours
              </label>
              <input
                type="number"
                min="0"
                step="0.5"
                value={customFields.estimatedHours || ''}
                onChange={(e) => setCustomFields({...customFields, estimatedHours: e.target.value})}
                className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 text-neutral-800 text-sm"
              />
            </div>
            
            {/* File attachments */}
            <TaskFileAttachment 
              taskId={task.id}
              projectId={activeProject?.id}
              existingAttachments={attachments}
              onUploadComplete={handleAttachmentUpdate}
            />
            
            {/* Save button */}
            <div className="flex justify-end mt-4">
              <button
                onClick={handleSave}
                disabled={isSaving}
                className={`px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center ${
                  isSaving ? 'opacity-75 cursor-not-allowed' : ''
                }`}
              >
                {isSaving ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="h-4 w-4 mr-2" />
                    Save Changes
                  </>
                )}
              </button>
            </div>
          </div>
        ) : (
          <div>
            {/* Status display */}
            <div className="flex items-center mb-4">
              <div className={`p-1 rounded-md ${completed ? 'bg-green-100' : 'bg-yellow-100'}`}>
                {completed ? (
                  <Check className={`h-4 w-4 text-green-600`} />
                ) : (
                  <Clock className={`h-4 w-4 text-yellow-600`} />
                )}
              </div>
              <span className={`ml-2 text-sm font-medium ${completed ? 'text-green-700' : 'text-yellow-700'}`}>
                {completed ? 'Completed' : 'In Progress'}
              </span>
              
              {customFields.priority && (
                <span className={`ml-4 px-2 py-0.5 text-xs rounded-full ${
                  customFields.priority === 'high' ? 'bg-red-100 text-red-800' :
                  customFields.priority === 'medium' ? 'bg-blue-100 text-blue-800' :
                  'bg-green-100 text-green-800'
                }`}>
                  {customFields.priority.charAt(0).toUpperCase() + customFields.priority.slice(1)} Priority
                </span>
              )}

              {/* Show attachment count if there are any */}
              {attachments.length > 0 && (
                <span className="ml-4 px-2 py-0.5 text-xs rounded-full bg-blue-100 text-blue-800 flex items-center">
                  <Paperclip className="h-3 w-3 mr-1" />
                  {attachments.length} file{attachments.length !== 1 ? 's' : ''}
                </span>
              )}
            </div>
            
            {/* Task Output Acceptance UI */}
            {notes && (
              <div className="mb-5">
                <TaskOutputAcceptance
                  taskId={task.id}
                  content={notes}
                  onSave={handleOutputAcceptance}
                  onRegenerate={() => {
                    // Clear notes to trigger regeneration
                    updateTaskData(task.id, {
                      notes: '',
                      acceptanceStatus: 'idle',
                      acceptanceTimestamp: null
                    });
                    setNotes('');
                    setAcceptanceStatus('idle');
                    setAcceptanceTimestamp(null);
                  }}
                />
              </div>
            )}
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6 mb-4">
              {customFields.dueDate && (
                <div className="bg-blue-50 p-3 rounded-md flex items-center">
                  <Calendar className="h-5 w-5 text-blue-500 mr-2" />
                  <div>
                    <h4 className="text-xs font-medium text-blue-800">Target Completion Date</h4>
                    <p className="text-sm text-blue-700">{new Date(customFields.dueDate).toLocaleDateString()}</p>
                  </div>
                </div>
              )}
              
              {customFields.assignedTo && (
                <div className="bg-purple-50 p-3 rounded-md flex items-center">
                  <Users className="h-5 w-5 text-purple-500 mr-2" />
                  <div>
                    <h4 className="text-xs font-medium text-purple-800">Assigned To</h4>
                    <p className="text-sm text-purple-700">{customFields.assignedTo}</p>
                  </div>
                </div>
              )}
              
              {customFields.estimatedHours && (
                <div className="bg-green-50 p-3 rounded-md flex items-center">
                  <Clock className="h-5 w-5 text-green-500 mr-2" />
                  <div>
                    <h4 className="text-xs font-medium text-green-800">Estimated Hours</h4>
                    <p className="text-sm text-green-700">{customFields.estimatedHours} hours</p>
                  </div>
                </div>
              )}
            </div>
            
            {/* Attachments display */}
            {attachments.length > 0 && (
              <div className="mb-4">
                <h4 className="text-sm font-medium text-gray-700 mb-2 flex items-center">
                  <FileArrowUp className="h-4 w-4 mr-2 text-blue-500" />
                  Attachments ({attachments.length}):
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {attachments.map((attachment, index) => {
                    const extension = attachment.name.split('.').pop()?.toUpperCase();
                    const fileType = getFileTypeLabel(attachment);
                    
                    return (
                      <a 
                        key={index}
                        href={attachment.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center p-3 bg-gray-50 rounded-md border border-gray-200 hover:bg-gray-100 transition-colors group"
                      >
                        <div className="p-2 bg-blue-50 rounded-md mr-3">
                          <FileIcon attachment={attachment} />
                        </div>
                        <div className="overflow-hidden flex-1">
                          <p className="text-sm font-medium text-gray-700 truncate group-hover:text-blue-600 transition-colors">
                            {attachment.name}
                          </p>
                          <div className="flex items-center">
                            <span className="text-xs bg-gray-200 text-gray-700 px-1.5 py-0.5 rounded">
                              {extension || '?'}
                            </span>
                            <span className="mx-2 text-gray-300">•</span>
                            <span className="text-xs text-gray-500">
                              {formatFileSize(attachment.size)}
                            </span>
                          </div>
                        </div>
                        <Download className="h-4 w-4 text-gray-400 group-hover:text-blue-500" />
                      </a>
                    );
                  })}
                </div>
              </div>
            )}
            
            {/* Related documents display */}
            {relatedDocuments.length > 0 && (
              <div>
                <h4 className="text-sm font-medium text-gray-700 mb-2 flex items-center">
                  <FileText className="h-4 w-4 mr-2 text-blue-500" />
                  Related Documents:
                </h4>
                <div className="space-y-2">
                  {relatedDocuments.slice(0, 3).map((doc, index) => (
                    <div key={index} className="flex items-start text-sm text-gray-600 border-l-2 border-blue-200 pl-3">
                      <span>{doc.metadata.source || `Document ${index+1}`}</span>
                    </div>
                  ))}
                  {relatedDocuments.length > 3 && (
                    <p className="text-xs text-gray-500">
                      +{relatedDocuments.length - 3} more documents
                    </p>
                  )}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
      
      {/* Delete confirmation */}
      {isDeleting && (
        <div className="mt-4 pt-4 border-t border-gray-100">
          <div className="p-3 bg-red-50 rounded-md text-red-700 text-sm">
            <p className="font-medium">Are you sure you want to delete this task data?</p>
            <p className="mt-1">This will reset all task progress, notes, and attachments.</p>
            <div className="flex justify-end mt-2 space-x-2">
              <button
                onClick={() => setIsDeleting(false)}
                className="px-3 py-1.5 border border-gray-300 text-sm rounded-md text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleDelete}
                className="px-3 py-1.5 bg-red-600 text-sm text-white rounded-md hover:bg-red-700"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// Helper function to format file size
const formatFileSize = (bytes?: number): string => {
  if (bytes === undefined) return 'Unknown size';
  if (bytes === 0) return '0 Bytes';
  
  const units = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  
  return `${parseFloat((bytes / Math.pow(1024, i)).toFixed(2))} ${units[i]}`;
};

// Helper function to get file type label
const getFileTypeLabel = (file: {name: string, type?: string}): string => {
  if (file.type) {
    if (file.type.startsWith('image/')) return 'Image';
    if (file.type.startsWith('video/')) return 'Video';
    if (file.type.startsWith('audio/')) return 'Audio';
    if (file.type === 'application/pdf') return 'PDF';
    if (file.type.includes('spreadsheet') || file.type.includes('excel')) return 'Spreadsheet';
    if (file.type.includes('document') || file.type.includes('word')) return 'Document';
    if (file.type.includes('presentation') || file.type.includes('powerpoint')) return 'Presentation';
    if (file.type.startsWith('text/')) return 'Text';
  }
  
  // Fallback to extension-based detection
  const extension = file.name.split('.').pop()?.toLowerCase();
  if (!extension) return 'Unknown';
  
  if (['jpg', 'jpeg', 'png', 'gif', 'svg', 'webp'].includes(extension)) return 'Image';
  if (['mp4', 'webm', 'ogg'].includes(extension)) return 'Video';
  if (['mp3', 'wav', 'ogg'].includes(extension)) return 'Audio';
  if (extension === 'pdf') return 'PDF';
  if (['xls', 'xlsx', 'csv'].includes(extension)) return 'Spreadsheet';
  if (['doc', 'docx', 'rtf'].includes(extension)) return 'Document';
  if (['ppt', 'pptx'].includes(extension)) return 'Presentation';
  if (['txt', 'md', 'html', 'css', 'js', 'json', 'xml'].includes(extension)) return 'Text';
  
  return 'File';
};

// Helper component to render file type icon
const FileIcon = ({attachment}: {attachment: {name: string, type?: string}}) => {
  if (!attachment.name) return <FileText className="h-5 w-5 text-gray-500" />;
  
  const extension = attachment.name.split('.').pop()?.toLowerCase();
  
  // Document files
  if (['pdf', 'doc', 'docx', 'rtf', 'odt'].includes(extension || '')) {
    return <FileText className="h-5 w-5 text-blue-500" />;
  }
  
  // Spreadsheet files
  if (['xls', 'xlsx', 'csv', 'ods'].includes(extension || '')) {
    return <FileText className="h-5 w-5 text-green-500" />;
  }
  
  // Presentation files
  if (['ppt', 'pptx', 'odp'].includes(extension || '')) {
    return <FileText className="h-5 w-5 text-orange-500" />;
  }
  
  // Image files
  if (['jpg', 'jpeg', 'png', 'gif', 'svg', 'webp'].includes(extension || '')) {
    return <FileText className="h-5 w-5 text-purple-500" />;
  }
  
  // Code/text files
  if (['txt', 'md', 'json', 'xml', 'html', 'css', 'js', 'ts', 'jsx', 'tsx'].includes(extension || '')) {
    return <FileText className="h-5 w-5 text-gray-500" />;
  }
  
  // Archive files
  if (['zip', 'rar', '7z', 'tar', 'gz'].includes(extension || '')) {
    return <FileText className="h-5 w-5 text-indigo-500" />;
  }
  
  // Default file icon
  return <FileText className="h-5 w-5 text-gray-500" />;
};

export default TaskManager;