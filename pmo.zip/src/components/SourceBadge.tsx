import React from 'react';
import { CheckCircle, AlertTriangle, Shield, HelpCircle } from 'lucide-react';

type SourceBadgeProps = {
  status: 'verified' | 'partially-verified' | 'unverified' | 'needs-review' | 'loading';
  confidence?: number;
  compact?: boolean;
  className?: string;
  onClick?: () => void;
};

const SourceBadge: React.FC<SourceBadgeProps> = ({ 
  status, 
  confidence, 
  compact = false,
  className = '',
  onClick
}) => {
  // Determine badge style based on status
  const getBadgeStyle = () => {
    switch (status) {
      case 'verified':
        return 'bg-green-50 text-green-800 border-green-200';
      case 'partially-verified':
        return 'bg-blue-50 text-blue-800 border-blue-200';
      case 'unverified':
        return 'bg-gray-50 text-gray-800 border-gray-200';
      case 'needs-review':
        return 'bg-yellow-50 text-yellow-800 border-yellow-200';
      case 'loading':
        return 'bg-purple-50 text-purple-800 border-purple-200';
      default:
        return 'bg-gray-50 text-gray-800 border-gray-200';
    }
  };

  // Get badge icon
  const getBadgeIcon = () => {
    switch (status) {
      case 'verified':
        return <CheckCircle className="h-3 w-3 mr-1" />;
      case 'partially-verified':
        return <HelpCircle className="h-3 w-3 mr-1" />;
      case 'unverified':
        return <Shield className="h-3 w-3 mr-1" />;
      case 'needs-review':
        return <AlertTriangle className="h-3 w-3 mr-1" />;
      case 'loading':
        return (
          <svg className="animate-spin h-3 w-3 mr-1" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
        );
      default:
        return <Shield className="h-3 w-3 mr-1" />;
    }
  };

  // Get status text
  const getStatusText = () => {
    switch (status) {
      case 'verified':
        return confidence && !isNaN(confidence) 
          ? `Verified (${Math.round(confidence * 100)}%)` 
          : 'Verified';
      case 'partially-verified':
        return 'Partially Verified';
      case 'unverified':
        return 'Unverified';
      case 'needs-review':
        return 'Needs Review';
      case 'loading':
        return 'Checking Sources...';
      default:
        return 'Unknown';
    }
  };

  // Compact version
  if (compact) {
    return (
      <div 
        className={`inline-flex items-center px-2 py-1 text-xs font-medium rounded-full cursor-pointer ${getBadgeStyle()} ${className}`}
        onClick={onClick}
      >
        {getBadgeIcon()}
        <span className="truncate">{getStatusText()}</span>
      </div>
    );
  }

  // Full version
  return (
    <div 
      className={`flex items-center px-3 py-1.5 text-sm border rounded-md cursor-pointer ${getBadgeStyle()} ${className}`}
      onClick={onClick}
    >
      {getBadgeIcon()}
      <span>{getStatusText()}</span>
      
      {confidence !== undefined && status === 'verified' && (
        <div className="ml-2 w-16 bg-white/50 rounded-full h-1.5">
          <div 
            className="bg-green-500 h-1.5 rounded-full" 
            style={{ width: `${confidence * 100}%` }}
          ></div>
        </div>
      )}
    </div>
  );
};

export default SourceBadge;