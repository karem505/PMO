import React from 'react';
import TaskCard from './TaskCard';

/**
 * Memoized version of TaskCard that only re-renders when relevant props change
 * This significantly improves performance when many task cards are rendered
 */
const MemoizedTaskCard = React.memo(
  TaskCard,
  (prevProps, nextProps) => {
    // Only re-render if these properties change
    return (
      prevProps.task.id === nextProps.task.id &&
      prevProps.task.completed === nextProps.task.completed &&
      prevProps.task.status === nextProps.task.status &&
      prevProps.onClick === nextProps.onClick &&
      prevProps.onToggleComplete === nextProps.onToggleComplete
    );
  }
);

export default MemoizedTaskCard; 