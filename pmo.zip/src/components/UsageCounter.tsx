import React from 'react';
import { useSubscription } from '../contexts/SubscriptionContext';
import { AlertCircle } from 'lucide-react';

interface UsageCounterProps {
  feature: string;
  showLabel?: boolean;
  showLimit?: boolean;
  className?: string;
}

/**
 * Component to display current usage and limits for a specific feature
 */
const UsageCounter: React.FC<UsageCounterProps> = ({
  feature,
  showLabel = true,
  showLimit = true,
  className = '',
}) => {
  const { getUsage, getLimitForFeature, isUsageLimitReached } = useSubscription();
  
  const usage = getUsage(feature);
  const limit = getLimitForFeature(feature);
  const isLimitReached = isUsageLimitReached(feature);
  
  // Format feature name for display
  const formatFeatureName = (name: string): string => {
    switch (name) {
      case 'aiAnalysis':
        return 'AI Analyses';
      case 'projects':
        return 'Projects';
      case 'storage':
        return 'Storage';
      case 'users':
        return 'Team Members';
      default:
        return name.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
    }
  };
  
  // Format limit for display
  const formatLimit = (limit: number | string): string => {
    if (limit === 'unlimited') return 'Unlimited';
    return limit.toString();
  };
  
  // Calculate usage percentage
  const calculatePercentage = (): number => {
    if (limit === 'unlimited') return 0;
    if (typeof limit !== 'number') return 0;
    if (limit === 0) return 0;
    return Math.min(100, Math.round((usage / limit) * 100));
  };
  
  // Get color based on usage percentage
  const getBarColor = (): string => {
    const percentage = calculatePercentage();
    if (percentage >= 90) return 'bg-red-500';
    if (percentage >= 70) return 'bg-yellow-500';
    return 'bg-primary-500';
  };
  
  return (
    <div className={`${className}`}>
      {showLabel && (
        <div className="flex justify-between items-center mb-1">
          <span className="text-xs font-medium text-gray-700">
            {formatFeatureName(feature)}
          </span>
          {showLimit && (
            <span className="text-xs text-gray-500">
              {usage} / {formatLimit(limit)}
              {isLimitReached && (
                <AlertCircle className="inline-block ml-1 h-3 w-3 text-red-500" />
              )}
            </span>
          )}
        </div>
      )}
      
      <div className="w-full bg-gray-200 rounded-full h-1.5">
        <div 
          className={`h-1.5 rounded-full ${getBarColor()}`} 
          style={{ width: `${calculatePercentage()}%` }}
        ></div>
      </div>
    </div>
  );
};

export default UsageCounter;