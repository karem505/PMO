import React, { useState, useEffect } from 'react';
import Joyride, { CallBackProps, STATUS, Step } from 'react-joyride';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';

interface OnboardingTourProps {
  isFirstLogin: boolean;
  onComplete?: () => void;
}

const OnboardingTour: React.FC<OnboardingTourProps> = ({ isFirstLogin, onComplete }) => {
  const navigate = useNavigate();
  const { t, isRTL, language } = useLanguage();
  const [run, setRun] = useState(false);
  const [stepIndex, setStepIndex] = useState(0);
  const [steps, setSteps] = useState<Step[]>([]);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);

  // Handle window resize
  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    window.addEventListener('resize', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  useEffect(() => {
    // Only run the tour for first-time users
    if (isFirstLogin) {
      initializeTour();
      // Delay start to ensure UI is fully loaded
      setTimeout(() => setRun(true), 1000);
    }
  }, [isFirstLogin, language]);

  const initializeTour = () => {
    setSteps([
      {
        target: '.dashboard-overview',
        content: t('tour.dashboardOverview', 'Welcome! Here you\'ll find all your project details at a glance.'),
        disableBeacon: true,
        placement: isMobile ? 'bottom-start' : 'bottom',
        title: t('tour.dashboardOverviewTitle', 'Dashboard Overview')
      },
      {
        target: '.export-project-btn',
        content: t('tour.exportProject', 'Here you can export a detailed report of your project.'),
        placement: isMobile ? 'top' : 'bottom',
        title: t('tour.exportProjectTitle', 'Export Project')
      },
      {
        target: '.projects-tab',
        content: t('tour.projectsTab', 'This is where you\'ll find your existing projects and create new ones.'),
        placement: isMobile ? 'bottom-start' : 'bottom',
        title: t('tour.projectsTabTitle', 'Projects Tab'),
        onClick: () => {
          closeTour();
          navigate('/domain/1');
        }
      },
      {
        target: '.sidebar-domains',
        content: t('tour.projectDomains', 'These are your project domains — think of them as functional areas or stages.'),
        placement: isRTL ? 'left' : 'right',
        title: t('tour.projectDomainsTitle', 'Project Domains')
      },
      {
        target: '.domain-input-task',
        content: t('tour.domainInputTask', 'Here, you can add your inputs to guide the AI in generating content.'),
        placement: isMobile ? 'top' : 'bottom',
        title: t('tour.domainInputTaskTitle', 'Domain Input Task')
      },
      {
        target: '.domain-output-task',
        content: t('tour.domainOutputTask', 'Click here to generate a detailed report for this task using AI.'),
        placement: isMobile ? 'top' : 'bottom',
        title: t('tour.domainOutputTaskTitle', 'Domain Output Task')
      },
      {
        target: '.tokens-display',
        content: t('tour.tokens', 'These are your available tokens for AI usage and content generation.'),
        placement: isMobile ? 'top' : 'bottom',
        title: t('tour.tokensTitle', 'Tokens')
      },
      {
        target: '.upgrade-button',
        content: t('tour.upgradePlan', 'Upgrade your plan here to access more tokens and advanced features.'),
        placement: isMobile ? 'top' : 'bottom',
        title: t('tour.upgradePlanTitle', 'Upgrade Plan')
      },
      {
        target: '.maturity-assessment',
        content: t('tour.maturityAssessment', 'Here, you can perform both self-assessment and AI-assisted assessment of your project\'s maturity.'),
        placement: isRTL ? 'left' : 'right',
        title: t('tour.maturityAssessmentTitle', 'Maturity Assessment')
      },
      {
        target: '.resources-page',
        content: t('tour.resourcesPage', 'Access helpful documentation, guides, and tools for your projects here.'),
        placement: isRTL ? 'left' : 'right',
        title: t('tour.resourcesPageTitle', 'Resources Page')
      }
    ]);
  };

  const handleJoyrideCallback = (data: CallBackProps) => {
    const { status, index, type } = data;
    console.log('Joyride callback:', { status, index, type });

    // Handle navigation between steps that require page changes
    if (type === 'step:after') {
      if (index === 2) {
        // After showing the "Projects Tab", navigate to a domain page
        navigate('/domain/1');
        // Use a longer delay to ensure the page has loaded
        setTimeout(() => setStepIndex(3), 1500);
        return;
      } 
      
      if (index === 3) {
        // Make sure we're on the domain page before proceeding
        setTimeout(() => setStepIndex(4), 1500);
        return;
      } 
      
      if (index === 4) {
        // Make sure we can see the input task
        setTimeout(() => setStepIndex(5), 1500);
        return;
      } 
      
      if (index === 8) {
        // After showing "Maturity Assessment", navigate to resources page
        navigate('/resources');
        setTimeout(() => setStepIndex(9), 1500);
        return;
      }
      
      // For all other steps, auto-advance
      setStepIndex(index + 1);
    }

    // Handle tour completion
    if (status === STATUS.FINISHED || status === STATUS.SKIPPED) {
      setRun(false);
      if (onComplete) {
        onComplete();
      }
      // Mark tour as completed in local storage
      localStorage.setItem('onboardingTourCompleted', 'true');
    }
  };

  return (
    <Joyride
      steps={steps}
      run={run}
      stepIndex={stepIndex}
      continuous
      showProgress
      showSkipButton
      callback={handleJoyrideCallback}
      styles={{
        options: {
          primaryColor: '#4F46E5',
          zIndex: 10000,
          arrowColor: '#fff',
          textColor: '#333',
          width: isMobile ? 290 : 400
        },
        buttonNext: {
          backgroundColor: '#4F46E5'
        },
        buttonBack: {
          color: '#4F46E5'
        },
        spotlight: {
          backgroundColor: 'rgba(0, 0, 0, 0.4)'
        },
        tooltip: {
          padding: isMobile ? 12 : 16,
          borderRadius: 8,
          fontSize: isMobile ? 13 : 14,
          textAlign: isRTL ? 'right' : 'left'
        }
      }}
      locale={{
        back: t('tour.back', 'Back'),
        close: t('tour.close', 'Close'),
        last: t('tour.finish', 'Finish'),
        next: t('tour.next', 'Next'),
        skip: t('tour.skip', 'Skip')
      }}
    />
  );
};

export default OnboardingTour; 