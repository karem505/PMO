import React, { useState, useEffect } from 'react';
import { FileText, BookOpen, Download, Search, Filter, X, Loader, AlertTriangle, FileImage, FileSpreadsheet, FileCode, ChevronDown, FileArchive, File, List, Grid } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import apiClient from '../api/client';
import { useAppStore } from '../store';
import { useToast } from '../hooks/useToast';

interface Document {
  file_url: string;
  name: string;
  domain?: string;
  created_date?: string;
  project_id?: string;
  task_id?: string;
  task_name?: string;
  source: string;
}

interface FilterParams {
  source?: string;
  domainId?: number;
  sortBy?: string;
  sortDirection?: 'asc' | 'desc';
  limit?: number;
}

interface ResourceLibraryProps {
  viewMode?: 'grid' | 'list';
  filterParams?: FilterParams;
  projectId?: string;
}

const ResourceLibrary: React.FC<ResourceLibraryProps> = ({ 
  viewMode = 'grid', 
  filterParams = {}, 
  projectId 
}) => {
  const { t } = useLanguage();
  const [documents, setDocuments] = useState<Document[]>([]);
  const [filteredDocuments, setFilteredDocuments] = useState<Document[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [selectedProject, setSelectedProject] = useState<string | null>(projectId || null);
  const [selectedSource, setSelectedSource] = useState<string | null>(filterParams.source || null);
  const { getActiveProject, getProjects } = useAppStore();
  const toast = useToast();
  
  const projects = getProjects();
  const activeProject = getActiveProject();

  useEffect(() => {
    fetchDocuments();
  }, []);
  
  useEffect(() => {
    if (projectId !== undefined) {
      setSelectedProject(projectId);
    }
  }, [projectId]);
  
  useEffect(() => {
    if (filterParams.source !== undefined) {
      setSelectedSource(filterParams.source);
    }
  }, [filterParams.source]);
  
  useEffect(() => {
    if (documents.length > 0) {
      applyFilters();
    }
  }, [documents, searchTerm, selectedProject, selectedSource, filterParams]);
  
  // Helper function to validate document URLs and filter out invalid entries
  const isValidDocument = (doc: any): doc is Document => {
    // Check if file_url exists and is a string
    if (!doc.file_url || typeof doc.file_url !== 'string') {
      return false;
    }
    
    // Check if file_url is an empty array representation (stringify)
    if (doc.file_url === '[]') {
      return false;
    }
    
    // Special case: Handle entries that are purely JSON corruption with no real file
    if (doc.file_url.includes('uploadDate') && 
        doc.file_url.includes('file\":{}') && 
        !doc.file_url.includes('http')) {
      return false; // These are completely corrupted entries with no actual file URL
    }
    
    // Clean up the file_url instead of filtering out
    let cleanUrl = doc.file_url;
    
    // Clean up file_url if it contains query parameters
    if (cleanUrl.includes('?')) {
      cleanUrl = cleanUrl.split('?')[0];
    }
    
    // Fix corrupted URLs with _]file
    if (cleanUrl.includes('_]file')) {
      cleanUrl = cleanUrl.replace('_]file', '');
    }
    
    // Fix other corrupted formats
    if (cleanUrl.includes('?"]')) {
      cleanUrl = cleanUrl.replace('?"]', '');
    }
    
    // Remove JSON artifacts
    if (cleanUrl.includes('\\\"') || 
        cleanUrl.includes('\",\"uploadDate\"') ||
        cleanUrl.includes('pdf\\",\\\"uploadDate\\\"')) {
      
      // Extract valid URL part if possible
      const validUrlMatch = cleanUrl.match(/(https?:\/\/[^\\\"]+)/);
      if (validUrlMatch) {
        cleanUrl = validUrlMatch[0];
      } else {
        return false; // Can't salvage this URL
      }
    }
    
    // Update the document with cleaned URL
    doc.file_url = cleanUrl;
    
    // Clean up the task_name if it's corrupted
    if (doc.task_name && (doc.task_name.includes('uploadDate') || doc.task_name.includes('file\":{}'))) {
      doc.task_name = t('resources.unknownTask', 'Unknown task');
    }
    
    // Clean up the filename
    if (!doc.name || 
        doc.name.includes('_]file') || 
        doc.name.includes('?"]') ||
        doc.name.includes('uploadDate') ||
        doc.name.includes('file\":{}') ||
        doc.name === '[]') {
      try {
        // Extract filename from URL and clean it
        let filename = cleanUrl.split('/').pop() || t('resources.document', 'Document');
        
        // Clean up the filename
        if (filename.includes('_]file')) {
          filename = filename.replace('_]file', '');
        }
        
        if (filename.includes('?"]')) {
          filename = filename.replace('?"]', '');
        }
        
        // Remove query parameters
        if (filename.includes('?')) {
          filename = filename.split('?')[0];
        }
        
        // Ensure the filename has an extension
        if (!filename.includes('.')) {
          // Try to guess extension from URL path
          const urlParts = cleanUrl.split('.');
          if (urlParts.length > 1) {
            const ext = urlParts[urlParts.length - 1].split(/[?#]/)[0];
            if (ext && ext.length < 5) { // Reasonable extension length
              filename += '.' + ext;
            } else {
              filename += t('resources.docxExtension', '.docx'); // Default to docx
            }
          } else {
            filename += t('resources.docxExtension', '.docx'); // Default to docx
          }
        }
        
        doc.name = filename;
      } catch (e) {
        doc.name = t('resources.documentDocx', 'Document.docx');
      }
    }
    
    return true;
  };
  
  const fetchDocuments = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      // Always get ALL documents for the user, regardless of active project
      const endpoint = '/pmo/user-documents';
      
      const response = await apiClient.get(endpoint);
      
      if (response.data && response.data.documents) {
        // Filter out invalid documents
        const validDocuments = response.data.documents.filter(isValidDocument);
        const invalidCount = response.data.documents.length - validDocuments.length;
        console.log(t('resources.filteredInvalidDocuments', `Filtered out ${invalidCount} invalid document entries`));
        
        setDocuments(validDocuments);
        // Set filtered documents to all documents initially
        setFilteredDocuments(validDocuments);
        
        // Then apply any filters that might be active
        if (searchTerm || selectedProject || selectedSource || Object.keys(filterParams).length > 0) {
          applyFilters(validDocuments);
        }
      } else {
        setDocuments([]);
        setFilteredDocuments([]);
      }
    } catch (err: any) {
      console.error(t('resources.errorFetchingDocuments', 'Error fetching documents:'), err);
      setError(err.response?.data?.detail || err.message || t('resources.failedToLoadDocuments', 'Failed to load documents'));
      toast.error(t('resources.failedToLoadDocuments', 'Failed to load documents. Please try again.'));
    } finally {
      setIsLoading(false);
    }
  };
  
  // Helper function to apply all active filters
  const applyFilters = (docs = documents) => {
    let filtered = [...docs];
    
    // Apply search term filter
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(doc => {
        // Check standard fields
        if (doc.name.toLowerCase().includes(term) || 
            doc.domain?.toLowerCase().includes(term) ||
            doc.task_name?.toLowerCase().includes(term)) {
          return true;
        }
        
        // Extract potential username from filename for searching
        if (doc.name) {
          // Get just the filename without path
          const filenameOnly = doc.name.split('/').pop() || '';
          
          // Check for username pattern like "ghadakhalil4_timestamp.docx"
          const usernameMatch = filenameOnly.match(/^([^_@]+)_\d{4}/);
          if (usernameMatch && usernameMatch[1] && usernameMatch[1].toLowerCase().includes(term)) {
            return true;
          }
          
          // Check if filename starts with an email username (before @)
          const emailUsernameMatch = filenameOnly.match(/^([^@]+)@/);
          if (emailUsernameMatch && emailUsernameMatch[1] && 
              emailUsernameMatch[1].toLowerCase().includes(term)) {
            return true;
          }
        }
        
        return false;
      });
    }
    
    // Apply project filter
    if (selectedProject) {
      filtered = filtered.filter(doc => doc.project_id === selectedProject);
    }
    
    // Apply source filter
    if (selectedSource) {
      filtered = filtered.filter(doc => doc.source === selectedSource);
    }
    
    // Apply domain filter if provided
    if (filterParams?.domainId !== undefined) {
      const domainIdString = filterParams.domainId.toString();
      filtered = filtered.filter(doc => doc.domain === domainIdString);
    }
    
    // Apply sorting if provided
    if (filterParams?.sortBy) {
      filtered.sort((a, b) => {
        if (filterParams.sortBy === 'date') {
          const dateA = a.created_date ? new Date(a.created_date).getTime() : 0;
          const dateB = b.created_date ? new Date(b.created_date).getTime() : 0;
          return filterParams.sortDirection === 'desc' ? dateB - dateA : dateA - dateB;
        }
        return 0;
      });
    }
    
    // Apply limit if provided
    if (filterParams?.limit && filtered.length > filterParams.limit) {
      filtered = filtered.slice(0, filterParams.limit);
    }
    
    setFilteredDocuments(filtered);
  };
  
  const handleDownload = (doc: Document) => {
    try {
      // Create a temporary anchor element for download
      const link = window.document.createElement('a');
      link.href = doc.file_url;
      link.setAttribute('download', doc.name);
      link.setAttribute('target', '_blank'); 
      
      // Standard way for browser download
      link.click();
      
      // Alternative approach - append to DOM, click, then remove
      try {
        document.body.appendChild(link);
        link.click();
        // Safely remove only if it was appended successfully
        if (link && link.parentNode) {
          document.body.removeChild(link);
        }
      } catch (err) {
        console.error(t('resources.errorWithLinkManipulation', 'Error with link manipulation:'), err);
        // The first click should have triggered the download anyway
      }
      
      toast.success(t('resources.downloadInitiated', 'Download initiated'));
    } catch (err) {
      console.error(t('resources.errorDownloadingDocument', 'Error downloading document:'), err);
      toast.error(t('resources.failedToDownloadDocument', 'Failed to download document'));
    }
  };
  
  const clearFilters = () => {
    setSearchTerm('');
    setSelectedProject(null);
    setSelectedSource(null);
    // Just reset to showing all documents
    setFilteredDocuments(documents);
  };
  
  const getFileIcon = (filename: string) => {
    const extension = filename.split('.').pop()?.toLowerCase();
    
    switch (extension) {
      case 'pdf':
        return <File className="h-10 w-10 text-red-500" />;
      case 'doc':
      case 'docx':
        return <FileText className="h-10 w-10 text-blue-500" />;
      case 'xls':
      case 'xlsx':
      case 'csv':
        return <FileSpreadsheet className="h-10 w-10 text-green-500" />;
      case 'jpg':
      case 'jpeg':
      case 'png':
      case 'gif':
      case 'svg':
        return <FileImage className="h-10 w-10 text-purple-500" />;
      case 'zip':
      case 'rar':
      case '7z':
        return <FileArchive className="h-10 w-10 text-yellow-500" />;
      case 'json':
      case 'xml':
      case 'html':
      case 'js':
      case 'ts':
        return <FileCode className="h-10 w-10 text-gray-500" />;
      default:
        return <FileText className="h-10 w-10 text-gray-400" />;
    }
  };
  
  const formatDate = (dateString?: string) => {
    if (!dateString) return t('resources.unknownDate', 'Unknown date');
    
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } catch (e) {
      return t('resources.invalidDate', 'Invalid date');
    }
  };
  
  // Utility function to determine if a string might be a valid file path
  const looksLikeFilePath = (str: string): boolean => {
    return /\.(docx|pdf|xlsx|pptx|txt|csv)($|\?)/.test(str);
  };
  
  // Utility function to get a proper display name for the document
  const getDocumentDisplayName = (doc: Document): string => {
    // First check for common username pattern in filenames
    if (doc.name) {
      // Get the filename without path
      const filenameOnly = doc.name.split('/').pop() || doc.name;
      
      // Check for username pattern like ghadakhalil4_timestamp.docx
      const usernameMatch = filenameOnly.match(/^([^_@]+)_\d{4}/);
      if (usernameMatch && usernameMatch[1]) {
        return usernameMatch[1]; // Return just the username part
      }
      
      // Check if filename starts with an email username (before @)
      const emailUsernameMatch = filenameOnly.match(/^([^@]+)@/);
      if (emailUsernameMatch && emailUsernameMatch[1]) {
        return emailUsernameMatch[1];
      }
    }
  
    // If we have a proper domain or task_name, use it
    if (doc.domain && doc.domain !== t('resources.unknown', 'Unknown') && !looksLikeFilePath(doc.domain)) {
      return doc.domain;
    }
    
    if (doc.task_name && doc.task_name !== t('resources.unknownTask', 'Unknown task') && !looksLikeFilePath(doc.task_name)) {
      return doc.task_name;
    }
    
    // Try to extract a meaningful name from the filename
    if (doc.name) {
      // Remove extension
      const nameWithoutExt = doc.name.split('.')[0];
      
      // If the name follows our naming pattern (username_date_time), extract only the username
      if (nameWithoutExt.includes('_202')) {
        const parts = nameWithoutExt.split('_');
        if (parts.length >= 1) {
          return parts[0]; // Return just the username part
        }
      }
      
      // If no pattern, return the name without extension
      return nameWithoutExt;
    }
    
    return t('resources.document', 'Document');
  };
  
  if (isLoading) {
    return (
      <div className="bg-white dark:bg-neutral-800 rounded-lg shadow-sm p-6 flex items-center justify-center min-h-[300px]">
        <Loader className="h-8 w-8 text-primary-500 animate-spin" />
        <span className="ml-3 text-gray-600 dark:text-gray-300">{t('common.loadingDocuments', 'Loading documents...')}</span>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="bg-white dark:bg-neutral-800 rounded-lg shadow-sm p-6">
        <div className="text-center py-6">
          <AlertTriangle className="h-12 w-12 text-red-500 mx-auto mb-3" />
          <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
            {t('resources.errorLoadingDocuments', 'Error Loading Documents')}
          </h3>
          <p className="text-gray-500 dark:text-gray-400 mb-4">
            {error}
          </p>
          <button 
            onClick={fetchDocuments}
            className="px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 transition-colors"
          >
            {t('resources.tryAgain', 'Try Again')}
          </button>
        </div>
      </div>
    );
  }
  
  if (documents.length === 0) {
  return (
    <div className="bg-white dark:bg-neutral-800 rounded-lg shadow-sm p-6">
      <div className="text-center py-12">
        <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-3" />
        <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
            {t('resources.noDocumentsFound', 'No Documents Found')}
          </h3>
          <p className="text-gray-500 dark:text-gray-400 mb-4">
            {t('resources.noDocumentsMessage', "You don't have any documents yet. Complete tasks to generate documents.")}
          </p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="bg-white dark:bg-neutral-800 rounded-lg shadow-sm p-6 relative z-20">
      {/* Filters and search */}
      <div className="mb-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              placeholder={t('resources.searchDocuments', 'Search documents...')}
              className="pl-10 pr-4 py-2 w-full border border-gray-300 dark:border-gray-600 rounded-md focus:ring-primary-500 focus:border-primary-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="flex gap-2">
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md flex items-center text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-700"
            >
              <Filter className="h-5 w-5 mr-2" />
              {t('resources.filters', 'Filters')}
              <ChevronDown className={`h-5 w-5 ml-1 transition-transform ${showFilters ? 'rotate-180' : ''}`} />
            </button>
            
            {(searchTerm || selectedProject || selectedSource) && (
              <button
                onClick={clearFilters}
                className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md flex items-center text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-700"
              >
                <X className="h-5 w-5 mr-2" />
                {t('resources.clearFilters', 'Clear')}
              </button>
            )}
          </div>
        </div>
        
        {showFilters && (
          <div className="mt-4 p-4 bg-gray-50 dark:bg-gray-700 rounded-md grid grid-cols-1 md:grid-cols-2 gap-4 relative z-30">
            <div>
              <label htmlFor="project-filter" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                {t('resources.filterByProject', 'Filter by Project')}
              </label>
              <select
                id="project-filter"
                className="w-full border border-gray-300 dark:border-gray-600 rounded-md py-2 px-3 focus:ring-primary-500 focus:border-primary-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100"
                value={selectedProject || ''}
                onChange={(e) => setSelectedProject(e.target.value || null)}
              >
                <option value="">{t('resources.allProjects', 'All Projects')}</option>
                {projects.map((project) => (
                  <option key={project.id} value={project.id}>{project.name}</option>
                ))}
              </select>
            </div>
            
            <div>
              <label htmlFor="source-filter" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                {t('resources.filterBySource', 'Filter by Source')}
              </label>
              <select
                id="source-filter"
                className="w-full border border-gray-300 dark:border-gray-600 rounded-md py-2 px-3 focus:ring-primary-500 focus:border-primary-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100"
                value={selectedSource || ''}
                onChange={(e) => setSelectedSource(e.target.value || null)}
              >
                <option value="">{t('resources.allSources', 'All Sources')}</option>
                <option value="domain_outputs">{t('resources.domainOutputs', 'Domain Outputs')}</option>
                <option value="tasks">{t('resources.taskAttachments', 'Task Attachments')}</option>
              </select>
            </div>
          </div>
        )}
      </div>
      
      {/* Documents display */}
      {filteredDocuments.length === 0 ? (
        <div className="text-center py-8">
          <AlertTriangle className="h-10 w-10 text-yellow-500 mx-auto mb-3" />
          <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
            {t('resources.noMatchingDocuments', 'No Matching Documents')}
          </h3>
          <p className="text-gray-500 dark:text-gray-400 mb-4">
            {t('resources.tryAdjustingFilters', 'No documents match your current filters. Try adjusting your search or filters.')}
          </p>
        </div>
      ) : viewMode === 'list' ? (
        <div className="divide-y divide-gray-200 dark:divide-gray-700">
          {filteredDocuments.map((doc, index) => (
            <div key={index} className="py-4 flex items-center hover:bg-gray-50 dark:hover:bg-gray-800 px-3 rounded-md transition-colors">
              <div className="flex-shrink-0">
                {getFileIcon(doc.name)}
              </div>
              <div className="ml-4 flex-1 min-w-0">
                <h3 className="font-medium text-gray-900 dark:text-gray-100 truncate">{getDocumentDisplayName(doc)}</h3>
                <div className="flex flex-wrap gap-x-4 text-sm text-gray-500 dark:text-gray-400">
                  <span>{doc.source === 'domain_outputs' ? t('resources.domainOutput', 'Domain Output') : t('resources.taskAttachment', 'Task Attachment')}</span>
                  <span>{formatDate(doc.created_date)}</span>
                </div>
              </div>
              <button
                onClick={() => handleDownload(doc)}
                className="ml-4 px-3 py-1.5 bg-primary-600 text-white rounded-md hover:bg-primary-700 transition-colors flex items-center"
              >
                <Download className="h-4 w-4 mr-1" />
                {t('resources.download', 'Download')}
              </button>
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredDocuments.map((doc, index) => (
            <div key={index} className="border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden bg-white dark:bg-gray-800 hover:shadow-md transition-shadow">
              <div className="p-4">
                <div className="flex items-center mb-3">
                  {getFileIcon(doc.name)}
                  <div className="ml-3 flex-1 overflow-hidden">
                    <h3 className="font-medium text-gray-900 dark:text-gray-100 truncate">{getDocumentDisplayName(doc)}</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      {(doc.domain && doc.domain !== getDocumentDisplayName(doc)) || 
                       (doc.task_name && doc.task_name !== getDocumentDisplayName(doc)) ? 
                        (doc.domain || doc.task_name || t('resources.unknownSource', 'Unknown source')) : 
                        doc.source === 'domain_outputs' ? t('resources.domainOutput', 'Domain Output') : t('resources.taskAttachment', 'Task Attachment')}
                    </p>
                  </div>
                </div>
                
                <div className="text-xs text-gray-500 dark:text-gray-400 mb-3">
                  <div>{t('resources.source', 'Source')}: {doc.source === 'domain_outputs' ? t('resources.domainOutput', 'Domain Output') : t('resources.taskAttachment', 'Task Attachment')}</div>
                  <div>{t('resources.created', 'Created')}: {formatDate(doc.created_date)}</div>
                </div>
                
                <div className="flex justify-between gap-2">
                  <button
                    onClick={() => handleDownload(doc)}
                    className="px-3 py-1.5 bg-primary-600 text-white rounded-md hover:bg-primary-700 transition-colors flex items-center justify-center w-full"
                  >
                    <Download className="h-4 w-4 mr-1" />
                    {t('resources.download', 'Download')}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ResourceLibrary;