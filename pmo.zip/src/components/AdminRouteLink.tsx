import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from './auth/AuthContext';

interface AdminRouteLinkProps {
  to: string;
  children: React.ReactNode;
  className?: string;
}

// Component that only renders for admin users
const AdminRouteLink: React.FC<AdminRouteLinkProps> = ({ to, children, className }) => {
  const { hasRole } = useAuth();
  
  if (!hasRole('admin')) {
    return null;
  }
  
  return (
    <Link to={to} className={className}>
      {children}
    </Link>
  );
};

export default AdminRouteLink;