import React from 'react';
import { useSubscription } from '../contexts/SubscriptionContext';
import { SubscriptionTier } from '../services/subscriptionService';
import { Sparkles, Zap, Crown } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useNavigate } from 'react-router-dom';

interface SubscriptionBadgeProps {
  showUpgrade?: boolean;
  className?: string;
}

/**
 * Component to display the user's current subscription tier
 */
const SubscriptionBadge: React.FC<SubscriptionBadgeProps> = ({ 
  showUpgrade = false,
  className = ''
}) => {
  const { tier, isActive } = useSubscription();
  const navigate = useNavigate();
  const { t } = useLanguage();
  
  // Different styles and icons based on tier
  const getBadgeStyles = () => {
    switch (tier) {
      case SubscriptionTier.FREE:
        return {
          bg: 'bg-gray-100',
          text: 'text-gray-800',
          icon: <Sparkles className="h-3 w-3 me-1" />
        };
      case SubscriptionTier.PREMIUM:
        return {
          bg: 'bg-blue-100',
          text: 'text-blue-800',
          icon: <Zap className="h-3 w-3 me-1" />
        };
      case SubscriptionTier.ENTERPRISE:
        return {
          bg: 'bg-purple-100',
          text: 'text-purple-800',
          icon: <Crown className="h-3 w-3 me-1" />
        };
      default:
        return {
          bg: 'bg-gray-100',
          text: 'text-gray-800',
          icon: null
        };
    }
  };
  
  const { bg, text, icon } = getBadgeStyles();
  
  // Get tier display name
  const getTierDisplayName = () => {
    switch (tier) {
      case SubscriptionTier.FREE:
        return t('subscription.free', 'Free');
      case SubscriptionTier.PREMIUM:
        return t('subscription.premium', 'Premium');
      case SubscriptionTier.ENTERPRISE:
        return t('subscription.enterprise', 'Enterprise');
      default:
        return tier;
    }
  };
  
  // Handle upgrade click
  const handleUpgradeClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigate('/pricing?utm_source=header_badge');
  };
  
  return (
    <div className={`flex items-center ${className}`}>
      <span className={`${bg} ${text} text-xs px-2 py-1 rounded-full flex items-center`}>
        {icon}
        {getTierDisplayName()}
      </span>
      
      {showUpgrade && tier === SubscriptionTier.FREE && (
        <button 
          className="ms-2 text-xs text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 underline"
          onClick={handleUpgradeClick}
        >
          {t('subscription.upgrade', 'Upgrade')}
        </button>
      )}
    </div>
  );
};

export default SubscriptionBadge;