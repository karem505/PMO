import React, { useEffect, useState } from 'react';
import { useSubscription } from '../contexts/SubscriptionContext';
import UpgradeModal from './UpgradeModal';

interface FeatureGateProps {
  feature: string;
  children: React.ReactNode;
  fallback?: React.ReactNode;
  showUpgradeModal?: boolean;
}

/**
 * Component for gating features based on subscription tier
 * Use this to wrap premium features that should be restricted based on plan
 */
const FeatureGate: React.FC<FeatureGateProps> = ({ 
  feature, 
  children, 
  fallback, 
  showUpgradeModal = true 
}) => {
  const { isFeatureAvailable, isUsageLimitReached, tier } = useSubscription();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [reason, setReason] = useState<string | undefined>(undefined);
  
  // Determine if feature is allowed
  const isAllowed = isFeatureAvailable(feature) && !isUsageLimitReached(feature);
  
  // Show modal if feature is not allowed and modal should be shown
  useEffect(() => {
    if (!isAllowed && showUpgradeModal) {
      const limitReached = isUsageLimitReached(feature);
      if (limitReached) {
        setReason(`You've reached your ${feature} limit on your current plan.`);
      } else {
        setReason(`The ${feature} feature is not available on your current plan.`);
      }
      setIsModalOpen(true);
    }
  }, [isAllowed, showUpgradeModal, feature, isUsageLimitReached]);
  
  // If feature is allowed, render children
  if (isAllowed) {
    return <>{children}</>;
  }
  
  // If feature is not allowed and fallback is provided, render fallback
  if (fallback) {
    return <>{fallback}</>;
  }
  
  // If feature is not allowed and no fallback is provided, render null with modal
  return (
    <>
      {isModalOpen && (
        <UpgradeModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          feature={feature}
          reason={reason}
          currentTier={tier}
        />
      )}
      {null}
    </>
  );
};

export default FeatureGate;