import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppStore } from '../store';
import { Project } from '../types';
import { ChevronDown, Plus, Edit, Trash2, Settings, Check, Calendar, CreditCard, PlusCircle, X, AlertCircle, Target, Users, Shield } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from './auth/AuthContext';
import { useToast } from '../hooks/useToast';

const ProjectSelector: React.FC = () => {
  const navigate = useNavigate();
  const { 
    getProjects, 
    getActiveProject, 
    setActiveProject, 
    createProject, 
    deleteProject 
  } = useAppStore();
  const {currentUser} = useAuth();
  const { t, isRTL } = useLanguage();
  const toast = useToast();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [showNewProjectModal, setShowNewProjectModal] = useState(false);
  const [newProjectData, setNewProjectData] = useState({
    name: '',
    description: '',
    budget: 500000,
    startDate: new Date().toISOString().split('T')[0],
    endDate: new Date(new Date().setMonth(new Date().getMonth() + 6)).toISOString().split('T')[0],
    keyObjectives: ['Establish project governance framework', 'Implement standardized methodologies', 'Deploy resource optimization system'],
    stakeholders: [{ name: 'Executive Team', role: 'Sponsor' }, { name: 'Department Managers', role: 'Key Users' }],
    risks: [{ description: 'Organizational resistance', severity: 'Medium', mitigation: 'Change management plan' }]
  });
  const [activeTab, setActiveTab] = useState<'basic' | 'objectives' | 'stakeholders' | 'risks'>('basic');
  const [deleteConfirmation, setDeleteConfirmation] = useState<string | null>(null);
  const [tempStakeholder, setTempStakeholder] = useState({ name: '', role: '' });
  const [tempObjective, setTempObjective] = useState('');
  const [tempRisk, setTempRisk] = useState({ description: '', severity: 'Low', mitigation: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const projects = getProjects();
  const activeProject = getActiveProject();

  const toggleDropdown = () => {
    setDropdownOpen(!dropdownOpen);
  };

  const handleProjectSelect = (projectId: string) => {
    setActiveProject(projectId);
    setDropdownOpen(false);
  };

  const handleAddStakeholder = () => {
    if (tempStakeholder.name && tempStakeholder.role) {
      setNewProjectData(prev => ({
        ...prev,
        stakeholders: [...prev.stakeholders, { ...tempStakeholder }]
      }));
      setTempStakeholder({ name: '', role: '' });
    }
  };

  const handleRemoveStakeholder = (index: number) => {
    setNewProjectData(prev => ({
      ...prev,
      stakeholders: prev.stakeholders.filter((_, i) => i !== index)
    }));
  };

  const handleAddObjective = () => {
    if (tempObjective) {
      setNewProjectData(prev => ({
        ...prev,
        keyObjectives: [...prev.keyObjectives, tempObjective]
      }));
      setTempObjective('');
    }
  };

  const handleRemoveObjective = (index: number) => {
    setNewProjectData(prev => ({
      ...prev,
      keyObjectives: prev.keyObjectives.filter((_, i) => i !== index)
    }));
  };

  const handleAddRisk = () => {
    if (tempRisk.description && tempRisk.mitigation) {
      setNewProjectData(prev => ({
        ...prev,
        risks: [...prev.risks, { ...tempRisk }]
      }));
      setTempRisk({ description: '', severity: 'Low', mitigation: '' });
    }
  };

  const handleRemoveRisk = (index: number) => {
    setNewProjectData(prev => ({
      ...prev,
      risks: prev.risks.filter((_, i) => i !== index)
    }));
  };

  const handleCreateProject = async () => {
    if (!newProjectData.name) {
      toast.error(t('project.nameRequired', 'Project name is required'));
      return;
    }
    
    setIsSubmitting(true);
    
    // Add a timeout to prevent hanging indefinitely
    const timeoutPromise = new Promise((_, reject) => 
      setTimeout(() => reject(new Error('Request timed out')), 15000)
    );
    
    try {
      console.log('🆕 Creating project:', newProjectData.name);
      
      // Ensure required fields have values
      const projectToCreate = {
        name: newProjectData.name,
        description: newProjectData.description || "",
        budget: parseFloat(newProjectData.budget?.toString() || "500000"),
        startDate: newProjectData.startDate || new Date().toISOString().split('T')[0],
        endDate: newProjectData.endDate || new Date(new Date().setMonth(new Date().getMonth() + 6)).toISOString().split('T')[0],
        keyObjectives: newProjectData.keyObjectives || [],
        stakeholders: newProjectData.stakeholders || [],
        risks: newProjectData.risks || [],
        owner_id: currentUser?.id || "",
        user_id: currentUser?.id || "",
      };
      
      console.log('📊 Project data to create:', projectToCreate);
      
      // Create the project with complete data, with a timeout
      const projectId = await Promise.race([
        createProject(projectToCreate),
        timeoutPromise
      ]);
      
      console.log('✅ Project created with ID:', projectId);
      
      if (projectId) {
        // Force immediate refresh of projects list
        toast.success(t('project.createSuccess', 'Project created successfully'));
        
        // Set the newly created project as active and close the modal
        setActiveProject(projectId);
        setShowNewProjectModal(false);
        
        // Reset form state
        setNewProjectData({
          name: '',
          description: '',
          budget: 500000,
          startDate: new Date().toISOString().split('T')[0],
          endDate: new Date(new Date().setMonth(new Date().getMonth() + 6)).toISOString().split('T')[0],
          keyObjectives: ['Establish project governance framework', 'Implement standardized methodologies', 'Deploy resource optimization system'],
          stakeholders: [{ name: 'Executive Team', role: 'Sponsor' }, { name: 'Department Managers', role: 'Key Users' }],
          risks: [{ description: 'Organizational resistance', severity: 'Medium', mitigation: 'Change management plan' }]
        });
        setActiveTab('basic');
      } else {
        console.error('❌ No project ID returned from createProject');
        toast.error(t('project.createError', 'Failed to create project. Please try again.'));
      }
    } catch (error) {
      console.error('❌ Error creating project:', error);
      let errorMessage = t('project.createError', 'Failed to create project. Please try again.');
      
      if (error instanceof Error) {
        console.error('Error details:', error.message);
        if (error.message === 'Request timed out') {
          // Create a local project instead after timeout
          try {
            const localProject = await createProject({
              ...newProjectData,
              name: newProjectData.name + ' (Local)',
            });
            
            if (localProject) {
              setActiveProject(localProject);
              setShowNewProjectModal(false);
              toast.warning(t('project.createdLocallyWarning', 'Created local project due to connection timeout'));
              return;
            }
          } catch (fallbackError) {
            console.error('Failed to create local project after timeout:', fallbackError);
          }
        }
        errorMessage = `${errorMessage} (${error.message})`;
      }
      
      toast.error(errorMessage);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteConfirm = (projectId: string) => {
    if (projects.length <= 1) {
      toast.error(t('project.cannotDeleteLastProject', "Cannot delete the last project. At least one project must exist."));
      return;
    }
    
    deleteProject(projectId);
    setDeleteConfirmation(null);
    setDropdownOpen(false);
  };

  if (!activeProject) return null;

  return (
    <div className="relative">
      <button
        onClick={toggleDropdown}
        className="flex items-center space-x-2 rtl:space-x-reverse text-gray-700 hover:text-gray-900 py-2 px-3 rounded-lg border border-gray-200 bg-white hover:bg-gray-50 transition-colors duration-200"
      >
        <span className="text-sm font-medium truncate max-w-[180px]">{activeProject.name}</span>
        <ChevronDown className={`h-4 w-4 transition-transform duration-200 ${dropdownOpen ? 'transform rotate-180' : ''}`} />
      </button>

      {dropdownOpen && (
        <div className={`absolute start-0 mt-2 w-72 bg-white rounded-lg shadow-lg border border-gray-200 z-30 overflow-hidden`}>
          <div className="p-2 border-b border-gray-100">
            <p className="text-xs text-gray-500">{t('project.yourProjects', 'Your Projects')}</p>
          </div>
          
          <div className="max-h-64 overflow-y-auto">
            {projects.map((project) => (
              <div 
                key={project.id} 
                className={`flex items-center justify-between px-4 py-3 hover:bg-gray-50 cursor-pointer ${
                  project.id === activeProject.id ? 'bg-blue-50' : ''
                }`}
              >
                <div className="flex items-center" onClick={() => handleProjectSelect(project.id)}>
                  <div className={`p-2 rounded-md me-3 ${project.id === activeProject.id ? 'bg-blue-100' : 'bg-gray-100'}`}>
                    <Settings className={`h-4 w-4 ${project.id === activeProject.id ? 'text-blue-600' : 'text-gray-600'}`} />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-800">{project.name}</p>
                    <div className="flex items-center mt-1">
                      <Calendar className={`h-3 w-3 text-gray-400 me-1`} />
                      <p className="text-xs text-gray-500" dir="ltr">
                        {new Date(project.startDate).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })} - 
                        {new Date(project.endDate).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}
                      </p>
                    </div>
                  </div>
                </div>
                
                {project.id === activeProject.id && (
                  <div className="flex items-center text-blue-600">
                    <Check className="h-4 w-4" />
                  </div>
                )}

                {deleteConfirmation === project.id ? (
                  <div className={`flex items-center space-x-1 ${isRTL ? 'space-x-reverse' : ''}`}>
                    <button 
                      onClick={() => handleDeleteConfirm(project.id)}
                      className="p-1 text-xs bg-red-100 text-red-700 rounded"
                    >
                      {t('common.confirm', 'Confirm')}
                    </button>
                    <button 
                      onClick={() => setDeleteConfirmation(null)}
                      className="p-1 text-xs bg-gray-100 text-gray-700 rounded"
                    >
                      {t('common.cancel', 'Cancel')}
                    </button>
                  </div>
                ) : (
                  projects.length > 1 && (
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        setDeleteConfirmation(project.id);
                      }}
                      className="p-1 text-gray-400 hover:text-red-500 rounded-full hover:bg-gray-100"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  )
                )}
              </div>
            ))}
          </div>
          
          <button
            onClick={() => setShowNewProjectModal(true)}
            className="w-full flex items-center justify-center py-2 border-t border-gray-100 text-sm text-blue-600 hover:bg-blue-50"
          >
            <Plus className={`h-4 w-4 me-1`} />
            {t('dashboard.createNew', 'Create New Project')}
          </button>
        </div>
      )}

      {/* New Project Modal */}
      {showNewProjectModal && (
        <div className="fixed inset-0 bg-black bg-opacity-30 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200">
              <h3 className={`text-lg font-medium text-gray-800 flex items-center ${isRTL ? 'rtl:flex-row-reverse' : ''}`}>
                <PlusCircle className={`h-5 w-5 ms-2 text-blue-600`} />
                {t('dashboard.createNew', 'Create New Project')}
              </h3>
              <button 
                className="text-gray-400 hover:text-gray-500"
                onClick={() => setShowNewProjectModal(false)}
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            
            <div className="p-6">
              {/* Tabs */}
              <div className="flex border-b mb-4">
                <button 
                  className={`pb-2 px-4 ${activeTab === 'basic' ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-500'}`}
                  onClick={() => setActiveTab('basic')}
                >
                  {t('project.basicInfo', 'Basic Info')}
                </button>
                <button 
                  className={`pb-2 px-4 ${activeTab === 'objectives' ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-500'}`}
                  onClick={() => setActiveTab('objectives')}
                >
                  {t('project.objectives', 'Objectives')}
                </button>
                <button 
                  className={`pb-2 px-4 ${activeTab === 'stakeholders' ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-500'}`}
                  onClick={() => setActiveTab('stakeholders')}
                >
                  {t('project.stakeholders', 'Stakeholders')}
                </button>
                <button 
                  className={`pb-2 px-4 ${activeTab === 'risks' ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-500'}`}
                  onClick={() => setActiveTab('risks')}
                >
                  {t('project.risks', 'Risks')}
                </button>
              </div>

              {/* Tab Content */}
              {activeTab === 'basic' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      {t('project.projectName', 'Project Name')}*
                    </label>
                    <input
                      type="text"
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
                      value={newProjectData.name}
                      onChange={(e) => setNewProjectData(prev => ({ ...prev, name: e.target.value }))}
                      placeholder={t('project.projectNamePlaceholder', 'Enterprise PMO Implementation')}
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      {t('project.description', 'Description')}
                    </label>
                    <textarea
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
                      value={newProjectData.description}
                      onChange={(e) => setNewProjectData(prev => ({ ...prev, description: e.target.value }))}
                      placeholder={t('project.descriptionPlaceholder', 'Brief description of your PMO implementation project')}
                      rows={3}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        {t('project.startDate', 'Start Date')}
                      </label>
                      <input
                        type="date"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
                        value={newProjectData.startDate}
                        onChange={(e) => setNewProjectData(prev => ({ ...prev, startDate: e.target.value }))}
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        {t('project.endDate', 'End Date')}
                      </label>
                      <input
                        type="date"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
                        value={newProjectData.endDate}
                        onChange={(e) => setNewProjectData(prev => ({ ...prev, endDate: e.target.value }))}
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      {t('project.budget', 'Budget')}
                    </label>
                    <div className="relative">
                      <div className={`absolute inset-y-0 ${isRTL ? 'right-0 pr-3' : 'left-0 pl-3'} flex items-center pointer-events-none`}>
                        <CreditCard className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        type="number"
                        className={`w-full ${isRTL ? 'pr-10 pl-3' : 'pl-10 pr-3'} py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900`}
                        value={newProjectData.budget}
                        onChange={(e) => setNewProjectData(prev => ({ ...prev, budget: parseInt(e.target.value) || 0 }))}
                        placeholder={t('project.budgetPlaceholder', '500000')}
                      />
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'objectives' && (
                <div className="space-y-4">
                  <p className="text-sm text-gray-600 mb-4">
                    {t('project.objectivesDescription', 'Define key objectives for your project. These will help track progress and success.')}
                  </p>
                  
                  <div className="space-y-2">
                    {newProjectData.keyObjectives.map((objective, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
                        <span className="text-sm text-gray-800">{objective}</span>
                        <button 
                          onClick={() => handleRemoveObjective(index)}
                          className="p-1 text-gray-400 hover:text-red-500 rounded-full hover:bg-gray-100"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                  
                  <div className="mt-2">
                    <div className="flex space-x-2">
                      <input
                        type="text"
                        className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
                        value={tempObjective}
                        onChange={(e) => setTempObjective(e.target.value)}
                        placeholder={t('project.objectivePlaceholder', 'e.g., Implement standardized project tracking')}
                      />
                      <button
                        onClick={handleAddObjective}
                        disabled={!tempObjective}
                        className={`px-3 py-2 rounded-md ${!tempObjective ? 'bg-gray-300 text-gray-500' : 'bg-blue-600 text-white hover:bg-blue-700'}`}
                      >
                        {t('common.add', 'Add')}
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'stakeholders' && (
                <div className="space-y-4">
                  <p className="text-sm text-gray-600 mb-4">
                    {t('project.stakeholdersDescription', 'Identify key stakeholders involved in this project.')}
                  </p>
                  
                  <div className="space-y-2">
                    {newProjectData.stakeholders.map((stakeholder, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
                        <div>
                          <span className="text-sm font-medium text-gray-800">{stakeholder.name}</span>
                          <span className="text-xs text-gray-500 ml-2">({stakeholder.role})</span>
                        </div>
                        <button 
                          onClick={() => handleRemoveStakeholder(index)}
                          className="p-1 text-gray-400 hover:text-red-500 rounded-full hover:bg-gray-100"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                  
                  <div className="mt-2 space-y-2">
                    <div className="flex space-x-2">
                      <input
                        type="text"
                        className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
                        value={tempStakeholder.name}
                        onChange={(e) => setTempStakeholder(prev => ({ ...prev, name: e.target.value }))}
                        placeholder={t('project.stakeholderNamePlaceholder', 'Stakeholder name')}
                      />
                      <input
                        type="text"
                        className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
                        value={tempStakeholder.role}
                        onChange={(e) => setTempStakeholder(prev => ({ ...prev, role: e.target.value }))}
                        placeholder={t('project.stakeholderRolePlaceholder', 'Role')}
                      />
                    </div>
                    <button
                      onClick={handleAddStakeholder}
                      disabled={!tempStakeholder.name || !tempStakeholder.role}
                      className={`w-full px-3 py-2 rounded-md ${!tempStakeholder.name || !tempStakeholder.role ? 'bg-gray-300 text-gray-500' : 'bg-blue-600 text-white hover:bg-blue-700'}`}
                    >
                      {t('project.addStakeholder', 'Add Stakeholder')}
                    </button>
                  </div>
                </div>
              )}

              {activeTab === 'risks' && (
                <div className="space-y-4">
                  <p className="text-sm text-gray-600 mb-4">
                    {t('project.risksDescription', 'Identify potential risks and mitigation strategies.')}
                  </p>
                  
                  <div className="space-y-2">
                    {newProjectData.risks.map((risk, index) => (
                      <div key={index} className="flex items-start justify-between p-3 bg-gray-50 rounded-md">
                        <div>
                          <div className="flex items-center">
                            <span className="text-sm font-medium text-gray-800">{risk.description}</span>
                            <span className={`text-xs ml-2 px-1.5 py-0.5 rounded-full ${
                              risk.severity === 'High' ? 'bg-red-100 text-red-800' : 
                              risk.severity === 'Medium' ? 'bg-yellow-100 text-yellow-800' : 
                              'bg-green-100 text-green-800'
                            }`}>
                              {t(`project.severity.${risk.severity.toLowerCase()}`, risk.severity)}
                            </span>
                          </div>
                          <p className="text-xs text-gray-500 mt-1">{risk.mitigation}</p>
                        </div>
                        <button 
                          onClick={() => handleRemoveRisk(index)}
                          className="p-1 text-gray-400 hover:text-red-500 rounded-full hover:bg-gray-100"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                  
                  <div className="mt-2 space-y-2">
                    <div className="flex flex-col space-y-2">
                      <input
                        type="text"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
                        value={tempRisk.description}
                        onChange={(e) => setTempRisk(prev => ({ ...prev, description: e.target.value }))}
                        placeholder={t('project.riskDescriptionPlaceholder', 'Risk description')}
                      />
                      <div className="flex space-x-2">
                        <select
                          className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
                          value={tempRisk.severity}
                          onChange={(e) => setTempRisk(prev => ({ ...prev, severity: e.target.value }))}
                        >
                          <option value="Low">{t('project.severity.low', 'Low')}</option>
                          <option value="Medium">{t('project.severity.medium', 'Medium')}</option>
                          <option value="High">{t('project.severity.high', 'High')}</option>
                        </select>
                        <input
                          type="text"
                          className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
                          value={tempRisk.mitigation}
                          onChange={(e) => setTempRisk(prev => ({ ...prev, mitigation: e.target.value }))}
                          placeholder={t('project.riskMitigationPlaceholder', 'Mitigation strategy')}
                        />
                      </div>
                      <button
                        onClick={handleAddRisk}
                        disabled={!tempRisk.description || !tempRisk.mitigation}
                        className={`w-full px-3 py-2 rounded-md ${!tempRisk.description || !tempRisk.mitigation ? 'bg-gray-300 text-gray-500' : 'bg-blue-600 text-white hover:bg-blue-700'}`}
                      >
                        {t('project.addRisk', 'Add Risk')}
                      </button>
                    </div>
                  </div>
                </div>
              )}
              
              <div className={`mt-6 flex justify-end space-x-3 ${isRTL ? 'space-x-reverse' : ''}`}>
                <button
                  className="px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50"
                  onClick={() => setShowNewProjectModal(false)}
                  disabled={isSubmitting}
                >
                  {t('common.cancel', 'Cancel')}
                </button>
                <button
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center"
                  onClick={handleCreateProject}
                  disabled={!newProjectData.name || isSubmitting}
                >
                  {isSubmitting ? (
                    <>
                      <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      {t('common.creating', 'Creating...')}
                    </>
                  ) : (
                    t('project.createProject', 'Create Project')
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProjectSelector;