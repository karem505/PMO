import React, { createContext, useContext, useRef, useEffect, useState } from 'react';
import { useNavigate as useRouterNavigate, NavigateOptions } from 'react-router-dom';
import * as Sentry from '@sentry/react';

// Simple context with a navigate function
type NavigationContextType = {
  navigate: (to: string, options?: NavigateOptions) => void;
  isReady: boolean;
};

// Create context with a default value
const NavigationContext = createContext<NavigationContextType>({
  navigate: (to: string) => {
    console.warn('NavigationContext not initialized, falling back to direct navigation');
    window.location.href = to;
  },
  isReady: false
});

// Provider component
export const NavigationGuardProvider: React.FC<{children: React.ReactNode}> = ({ children }) => {
  const routerNavigate = useRouterNavigate();
  const lastNavigationTimeRef = useRef<number>(0);
  const isNavigatingRef = useRef<boolean>(false);
  const appJustLoadedRef = useRef<boolean>(true);
  const [isReady, setIsReady] = useState(false);
  const navigationQueueRef = useRef<{to: string, options?: NavigateOptions}[]>([]);
  
  // Constants for navigation timing
  const MIN_NAVIGATION_DELAY = 300; // milliseconds
  const INITIAL_NAVIGATION_DELAY = 800; // longer delay after initial load
  const DOM_CHECK_INTERVAL = 50; // check DOM readiness every 50ms
  const MAX_DOM_CHECKS = 30; // 30 checks = ~1.5 seconds max waiting time
  
  // Track app initialization and DOM readiness
  useEffect(() => {
    // Set a timeout to mark app as fully loaded after a delay
    const timer = setTimeout(() => {
      appJustLoadedRef.current = false;
      setIsReady(true);
    }, 1500); // Reduced from 2s to 1.5s for better responsiveness
    
    // Alternative DOM-ready check (more reliable)
    let domChecks = 0;
    const checkDomReady = () => {
      if (document.readyState === 'complete' || document.readyState === 'interactive') {
        appJustLoadedRef.current = false;
        setIsReady(true);
        return;
      }
      
      domChecks++;
      if (domChecks < MAX_DOM_CHECKS) {
        setTimeout(checkDomReady, DOM_CHECK_INTERVAL);
      } else {
        // Failsafe - ensure we set ready even if document.readyState never changes
        console.warn('Max DOM readiness checks reached, forcing ready state');
        appJustLoadedRef.current = false;
        setIsReady(true);
      }
    };
    
    // Start checking DOM
    checkDomReady();
    
    return () => clearTimeout(timer);
  }, []);
  
  // Process queued navigations when app becomes ready
  useEffect(() => {
    if (isReady && navigationQueueRef.current.length > 0) {
      console.log(`Processing ${navigationQueueRef.current.length} queued navigation requests`);
      
      // Process one request at a time with delays
      const processNextInQueue = () => {
        if (navigationQueueRef.current.length === 0) return;
        
        const nextNav = navigationQueueRef.current.shift();
        if (nextNav) {
          try {
            console.log(`Processing queued navigation to: ${nextNav.to}`);
            routerNavigate(nextNav.to, nextNav.options);
            
            // Process next item after delay
            if (navigationQueueRef.current.length > 0) {
              setTimeout(processNextInQueue, 300);
            }
          } catch (error) {
            console.error('Error processing queued navigation:', error);
          }
        }
      };
      
      // Start processing queue after a delay
      setTimeout(processNextInQueue, 100);
    }
  }, [isReady, routerNavigate]);
  
  // Safe navigation function with DOM readiness check
  const navigate = (to: string, options?: NavigateOptions) => {
    try {
      // If app not ready, queue the navigation request
      if (!isReady) {
        console.log(`App not ready, queueing navigation to: ${to}`);
        navigationQueueRef.current.push({ to, options });
        return;
      }
      
      // Prevent navigation if already navigating
      if (isNavigatingRef.current) {
        console.warn('Navigation already in progress, ignoring request');
        return;
      }
      
      const now = Date.now();
      const timeSinceLastNavigation = now - lastNavigationTimeRef.current;
      
      // Use longer delay if app just loaded
      const requiredDelay = appJustLoadedRef.current ? INITIAL_NAVIGATION_DELAY : MIN_NAVIGATION_DELAY;
      
      // Check DOM is ready before navigating
      const isDomReady = document.readyState === 'complete' || document.readyState === 'interactive';
      if (!isDomReady) {
        console.warn('DOM not ready, delaying navigation');
        setTimeout(() => navigate(to, options), 200);
        return;
      }
      
      // If navigating too quickly, use direct location change or delay
      if (timeSinceLastNavigation < requiredDelay) {
        console.warn(`Rapid navigation detected (${timeSinceLastNavigation}ms), using safe navigation`);
        
        // Set navigating flag
        isNavigatingRef.current = true;
        
        // For very rapid clicks, use direct navigation
        if (timeSinceLastNavigation < 100) {
          console.warn('Extremely rapid navigation, using direct location change');
          window.location.href = to;
          return;
        }
        
        // Otherwise delay the navigation
        const delayTime = requiredDelay - timeSinceLastNavigation;
        console.log(`Delaying navigation by ${delayTime}ms for safety`);
        
        setTimeout(() => {
          try {
            lastNavigationTimeRef.current = Date.now();
            routerNavigate(to, options);
          } catch (delayedError) {
            console.error('Delayed navigation failed:', delayedError);
            Sentry.captureException(delayedError);
            window.location.href = to;
          } finally {
            // Reset navigating flag after a short delay
            setTimeout(() => {
              isNavigatingRef.current = false;
            }, 150);
          }
        }, delayTime);
        
        return;
      }
      
      // Normal navigation flow
      isNavigatingRef.current = true;
      lastNavigationTimeRef.current = now;
      
      // Use try-catch for the actual navigation
      try {
        routerNavigate(to, options);
      } catch (error) {
        console.error('Navigation error:', error);
        Sentry.captureException(error);
        
        // Fallback to direct navigation
        window.location.href = to;
      } finally {
        // Reset navigating flag after a short delay
        setTimeout(() => {
          isNavigatingRef.current = false;
        }, 150);
      }
    } catch (error) {
      console.error('Navigation wrapper error:', error);
      Sentry.captureException(error);
      
      // Ultimate fallback
      try {
        window.location.href = to;
      } catch (finalError) {
        console.error('Even direct navigation failed:', finalError);
      }
    }
  };
  
  return (
    <NavigationContext.Provider value={{ navigate, isReady }}>
      {children}
    </NavigationContext.Provider>
  );
};

// Hook to use the navigation context
export const useNavigationGuard = () => {
  const context = useContext(NavigationContext);
  if (!context) {
    console.warn('useNavigationGuard must be used within NavigationGuardProvider');
    // Return a fallback navigate function
    return {
      navigate: (to: string) => {
        window.location.href = to;
      },
      isReady: false
    };
  }
  return context;
};

export default NavigationGuardProvider; 