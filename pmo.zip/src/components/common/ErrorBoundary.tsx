import React from 'react';
import { AlertTriangle } from 'lucide-react';
import { captureException } from '../../services/sentryService';

interface Props {
  children: React.ReactNode;
  fallbackRender?: (props: { error: Error; resetErrorBoundary: () => void }) => React.ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

class ErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): State {
    // Check for the specific "Cannot read properties of null (reading 'nodeName')" error
    if (error.message && error.message.includes("Cannot read properties of null (reading 'nodeName')")) {
      console.warn('Caught null nodeName error - this is likely due to a React rendering issue with a component trying to access DOM properties on an unmounted or null element');
      // You could log additional details here for debugging
    }
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('Error caught by ErrorBoundary:', error, errorInfo);
    
    // Report to Sentry with additional context
    captureException(error, {
      componentStack: errorInfo.componentStack,
      errorInfo: errorInfo,
      location: window.location.href,
    });
  }

  resetErrorBoundary = () => {
    this.setState({ hasError: false, error: null });
  };

  render() {
    if (this.state.hasError) {
      if (this.props.fallbackRender) {
        return this.props.fallbackRender({
          error: this.state.error!,
          resetErrorBoundary: this.resetErrorBoundary
        });
      }

      // Special handling for the nodeName error
      const isNodeNameError = this.state.error?.message?.includes("Cannot read properties of null (reading 'nodeName')");

      return (
        <div className="min-h-[calc(100vh-64px)] flex items-center justify-center bg-neutral-50">
          <div className="text-center px-4 max-w-md">
            <AlertTriangle className="h-12 w-12 text-amber-500 mx-auto mb-4" />
            <h1 className="text-3xl font-bold text-neutral-800 mb-2">Something went wrong</h1>
            <p className="text-neutral-600 mb-8">
              {isNodeNameError 
                ? 'The application encountered a rendering issue. This has been automatically handled.' 
                : this.state.error?.message || 'An unexpected error occurred. Please try again.'}
            </p>
            <button
              onClick={this.resetErrorBoundary}
              className="px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 transition-colors"
            >
              Try Again
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary; 