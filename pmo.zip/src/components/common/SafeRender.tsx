import React, { ReactNode } from 'react';
import { AlertTriangle, Loader2 } from 'lucide-react';

interface SafeRenderProps {
  /** The condition that must be true for children to render */
  when: boolean;
  /** Content to render when the condition is true */
  children: ReactNode;
  /** Content to render when the condition is false */
  fallback?: ReactNode;
  /** Whether data is currently loading */
  isLoading?: boolean;
  /** Custom loading component */
  loadingComponent?: ReactNode;
  /** Error object or message */
  error?: Error | string | null;
  /** Custom error component */
  errorComponent?: ReactNode;
  /** Additional CSS class name */
  className?: string;
}

/**
 * A component that safely renders children only when specified conditions are met.
 * Provides fallbacks for loading, error, and false conditions.
 */
export const SafeRender: React.FC<SafeRenderProps> = ({
  when,
  children,
  fallback,
  isLoading = false,
  loadingComponent,
  error = null,
  errorComponent,
  className = '',
}) => {
  // Format error message if it exists
  const errorMessage = error instanceof Error ? error.message : error;
  
  // Default loading component
  const defaultLoadingComponent = (
    <div className="flex items-center justify-center p-4">
      <Loader2 className="h-6 w-6 text-primary-600 animate-spin mr-2" />
      <span className="text-neutral-600">Loading...</span>
    </div>
  );
  
  // Default error component
  const defaultErrorComponent = (
    <div className="bg-amber-50 border border-amber-200 rounded-md p-4 my-2">
      <div className="flex items-center">
        <AlertTriangle className="h-5 w-5 text-amber-500 mr-2" />
        <span className="text-amber-800">
          {errorMessage || 'An error occurred'}
        </span>
      </div>
    </div>
  );
  
  // Default fallback component
  const defaultFallback = (
    <div className="text-neutral-500 italic p-2">No content available</div>
  );
  
  // Render loading state
  if (isLoading) {
    return (
      <div className={className}>
        {loadingComponent || defaultLoadingComponent}
      </div>
    );
  }
  
  // Render error state
  if (error) {
    return (
      <div className={className}>
        {errorComponent || defaultErrorComponent}
      </div>
    );
  }
  
  // Render based on condition
  return (
    <div className={className}>
      {when ? children : (fallback || defaultFallback)}
    </div>
  );
};

/**
 * A component that safely renders a list of items with proper handling for
 * empty arrays, loading states, and errors.
 */
export const SafeList = <T extends unknown>({
  items,
  renderItem,
  keyExtractor,
  isLoading = false,
  loadingComponent,
  error = null,
  errorComponent,
  emptyMessage = 'No items available',
  emptyComponent,
  className = '',
}: {
  /** The array of items to render */
  items: T[] | null | undefined;
  /** Function to render each item */
  renderItem: (item: T, index: number) => ReactNode;
  /** Function to extract a unique key for each item */
  keyExtractor: (item: T, index: number) => string | number;
  /** Whether data is currently loading */
  isLoading?: boolean;
  /** Custom loading component */
  loadingComponent?: ReactNode;
  /** Error object or message */
  error?: Error | string | null;
  /** Custom error component */
  errorComponent?: ReactNode;
  /** Message to display when the list is empty */
  emptyMessage?: string;
  /** Custom component to display when the list is empty */
  emptyComponent?: ReactNode;
  /** Additional CSS class name */
  className?: string;
}) => {
  // Default empty component
  const defaultEmptyComponent = (
    <div className="text-center p-4 text-neutral-500">
      {emptyMessage}
    </div>
  );
  
  return (
    <SafeRender
      when={Boolean(items && items.length > 0)}
      isLoading={isLoading}
      loadingComponent={loadingComponent}
      error={error}
      errorComponent={errorComponent}
      fallback={emptyComponent || defaultEmptyComponent}
      className={className}
    >
      {items?.map((item, index) => (
        <React.Fragment key={keyExtractor(item, index)}>
          {renderItem(item, index)}
        </React.Fragment>
      ))}
    </SafeRender>
  );
};

export default SafeRender; 