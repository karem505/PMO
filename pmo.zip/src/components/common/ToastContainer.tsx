import React from 'react';
import { useNotification } from '../../contexts/NotificationContext';
import Toast from './Toast';

const ToastContainer: React.FC = () => {
  const { notifications, hideNotification } = useNotification();

  return (
    <div className="fixed top-20 right-4 z-[60] flex flex-col gap-4 max-h-screen overflow-hidden max-w-sm w-full">
      {notifications.map((notification) => (
        <Toast
          key={notification.id}
          id={notification.id}
          message={notification.message}
          type={notification.type}
          onClose={hideNotification}
          duration={notification.duration}
        />
      ))}
    </div>
  );
};

export default ToastContainer; 