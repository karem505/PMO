import React, { ReactNode } from 'react';
import { AlertTriangle, Loader2, RefreshCw } from 'lucide-react';
import ErrorBoundary from '../ErrorBoundary';

interface LoadingWrapperProps {
  /**
   * Whether the content is currently loading
   */
  isLoading?: boolean;
  
  /**
   * Error message or object if an error occurred
   */
  error?: string | Error | null;
  
  /**
   * Whether data is available and ready to render
   */
  isDataReady?: boolean;
  
  /**
   * The content to render when data is ready
   */
  children: ReactNode;
  
  /**
   * Custom loading component to show while loading
   */
  loadingComponent?: ReactNode;
  
  /**
   * Custom error component to show when an error occurs
   */
  errorComponent?: ReactNode;
  
  /**
   * Custom empty state component to show when data is not ready
   */
  emptyComponent?: ReactNode;
  
  /**
   * Function to retry loading data if an error occurs
   */
  onRetry?: () => void;
  
  /**
   * Additional CSS class names
   */
  className?: string;
  
  /**
   * Text to display while loading
   */
  loadingText?: string;
  
  /**
   * Whether to show a centered full-page loading indicator
   */
  fullScreen?: boolean;
}

/**
 * A wrapper component that handles loading states, errors, and safely renders children
 * only when data is available.
 */
const LoadingWrapper: React.FC<LoadingWrapperProps> = ({
  isLoading = false,
  error = null,
  isDataReady = true,
  children,
  loadingComponent,
  errorComponent,
  emptyComponent,
  onRetry,
  className = '',
  loadingText = 'Loading...',
  fullScreen = false
}) => {
  // Format error message
  const errorMessage = error instanceof Error ? error.message : error;
  
  // Default loading component
  const defaultLoadingComponent = (
    <div className={`flex flex-col items-center justify-center p-6 ${fullScreen ? 'min-h-[calc(100vh-64px)]' : 'min-h-[200px]'}`}>
      <Loader2 className="h-8 w-8 text-primary-600 animate-spin mb-4" />
      <p className="text-neutral-600 font-medium">{loadingText}</p>
    </div>
  );
  
  // Default error component
  const defaultErrorComponent = (
    <div className="flex flex-col items-center justify-center p-6 bg-white rounded-lg shadow-sm border border-neutral-100">
      <AlertTriangle className="h-8 w-8 text-amber-500 mb-4" />
      <h3 className="text-lg font-semibold text-neutral-800 mb-2">Something went wrong</h3>
      <p className="text-neutral-600 mb-4 text-center">{errorMessage || 'An unexpected error occurred.'}</p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 transition-colors flex items-center"
        >
          <RefreshCw className="h-4 w-4 mr-2" />
          Try Again
        </button>
      )}
    </div>
  );
  
  // Default empty state component
  const defaultEmptyComponent = (
    <div className="flex flex-col items-center justify-center p-6 bg-white rounded-lg shadow-sm border border-neutral-100">
      <p className="text-neutral-600 text-center">No data available.</p>
    </div>
  );
  
  // Render loading state
  if (isLoading) {
    return (
      <div className={className}>
        {loadingComponent || defaultLoadingComponent}
      </div>
    );
  }
  
  // Render error state
  if (error) {
    return (
      <div className={className}>
        {errorComponent || defaultErrorComponent}
      </div>
    );
  }
  
  // Render empty state if data is not ready
  if (!isDataReady) {
    return (
      <div className={className}>
        {emptyComponent || defaultEmptyComponent}
      </div>
    );
  }
  
  // Render children with error boundary
  return (
    <ErrorBoundary>
      <div className={className}>
        {children}
      </div>
    </ErrorBoundary>
  );
};

export default LoadingWrapper; 