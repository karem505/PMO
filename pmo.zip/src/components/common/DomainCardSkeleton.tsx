import React from 'react';
import Skeleton from './Skeleton';

interface DomainCardSkeletonProps {
  className?: string;
}

const DomainCardSkeleton: React.FC<DomainCardSkeletonProps> = ({ className = '' }) => {
  return (
    <div className={`bg-white rounded-xl shadow-sm border border-neutral-100 overflow-hidden transition-all duration-300 ${className}`}>
      <div className="p-6">
        <div className="flex items-start justify-between">
          {/* Icon placeholder */}
          <Skeleton 
            variant="rounded" 
            width={48} 
            height={48} 
            className="bg-primary-50"
          />

          {/* Progress indicator */}
          <div className="text-right">
            <Skeleton variant="text" width={80} height={16} className="mb-2 ml-auto" />
            <div className="flex items-center justify-end">
              <Skeleton variant="circular" width={16} height={16} className="mr-1.5" />
              <Skeleton variant="text" width={40} height={24} />
            </div>
          </div>
        </div>
        
        {/* Domain title and description */}
        <Skeleton variant="text" width="70%" height={24} className="mt-4 mb-2" />
        <Skeleton variant="text" width="95%" height={16} className="mb-1" />
        <Skeleton variant="text" width="90%" height={16} className="mb-1" />
        
        {/* Progress bars */}
        <div className="mt-4 grid grid-cols-3 gap-2">
          {[1, 2, 3].map((_, index) => (
            <div key={index} className="text-center">
              <Skeleton variant="text" width="80%" height={12} className="mx-auto mb-2" />
              <Skeleton variant="rounded" width="100%" height={6} className="mb-1" />
              <Skeleton variant="text" width={24} height={14} className="mx-auto" />
            </div>
          ))}
        </div>
      </div>
      
      {/* Button placeholder */}
      <div className="w-full py-3 px-4 bg-neutral-50 border-t border-neutral-100">
        <Skeleton variant="text" width={120} height={20} className="mx-auto" />
      </div>
    </div>
  );
};

export default DomainCardSkeleton;