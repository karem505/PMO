import React from 'react';
import Skeleton from './Skeleton';

interface ProjectDetailsCardSkeletonProps {
  className?: string;
}

const ProjectDetailsCardSkeleton: React.FC<ProjectDetailsCardSkeletonProps> = ({ className = '' }) => {
  return (
    <div className={`bg-white rounded-lg shadow-sm p-6 mb-6 ${className}`}>
      <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between">
        <div className="w-full lg:w-3/4">
          <div className="flex items-center">
            <Skeleton variant="text" width="40%" height={28} className="mb-1" />
            <div className="ms-3">
              <Skeleton variant="rounded" width={60} height={20} />
            </div>
          </div>
          <Skeleton variant="text" width="90%" height={16} className="mt-2 mb-1" />
          <Skeleton variant="text" width="85%" height={16} className="mb-2" />
          
          <div className="flex flex-wrap items-center mt-3 gap-6">
            <div className="flex items-center">
              <Skeleton variant="circular" width={16} height={16} className="me-1.5" />
              <Skeleton variant="text" width={140} height={14} />
            </div>
            <div className="flex items-center">
              <Skeleton variant="circular" width={16} height={16} className="me-1.5" />
              <Skeleton variant="text" width={100} height={14} />
            </div>
            <Skeleton variant="text" width={80} height={14} />
          </div>
        </div>
        
        <div className="flex md:items-center gap-x-3 mt-4 lg:mt-0">
          <Skeleton variant="rounded" width={140} height={36} />
        </div>
      </div>
      
      {/* Expanded content skeleton (always shown in skeleton) */}
      <div className="mt-6 pt-6 border-t border-gray-100">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[1, 2, 3].map((_, index) => (
            <div key={index}>
              <Skeleton variant="text" width="60%" height={16} className="mb-2" />
              <div className="bg-gray-50 p-3 rounded-lg">
                <div className="flex justify-between items-center mb-1">
                  <Skeleton variant="text" width="30%" height={12} />
                  <Skeleton variant="text" width="25%" height={12} />
                </div>
                <Skeleton variant="rounded" width="100%" height={8} className="mb-2" />
                <div className="flex justify-between items-center">
                  <Skeleton variant="text" width="20%" height={12} />
                  <Skeleton variant="text" width="20%" height={12} />
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <Skeleton variant="text" width="40%" height={16} className="mb-2" />
            <div className="bg-gray-50 p-3 rounded-lg">
              <div className="space-y-2">
                {[1, 2, 3].map((_, index) => (
                  <div key={index} className="flex items-start">
                    <Skeleton variant="circular" width={20} height={20} className="me-2 mt-0.5" />
                    <Skeleton variant="text" width="90%" height={14} />
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          <div>
            <Skeleton variant="text" width="40%" height={16} className="mb-2" />
            <div className="bg-gray-50 p-3 rounded-lg">
              <div className="mb-2 flex justify-between items-center">
                <Skeleton variant="text" width="30%" height={12} />
                <Skeleton variant="text" width="20%" height={12} />
              </div>
              
              <div className="flex items-center mb-4">
                <Skeleton variant="circular" width={24} height={24} className="me-2" />
                <Skeleton variant="text" width="40%" height={14} />
              </div>
              
              <Skeleton variant="text" width="30%" height={12} className="mb-2" />
              
              <div className="flex flex-wrap gap-1">
                {[1, 2, 3].map((_, index) => (
                  <Skeleton key={index} variant="rounded" width={80} height={24} />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectDetailsCardSkeleton; 