import React from 'react';

interface SkeletonProps {
  className?: string;
  variant?: 'text' | 'rectangular' | 'circular' | 'rounded';
  width?: string | number;
  height?: string | number;
  animation?: 'pulse' | 'wave' | 'none';
  count?: number;
}

/**
 * A versatile skeleton loader component to show during content loading
 */
const Skeleton: React.FC<SkeletonProps> = ({
  className = '',
  variant = 'text',
  width,
  height,
  animation = 'pulse',
  count = 1
}) => {
  const getVariantClass = () => {
    switch (variant) {
      case 'circular': 
        return 'rounded-full';
      case 'rectangular': 
        return 'rounded-none';
      case 'rounded':
        return 'rounded-md';
      case 'text':
      default:
        return 'rounded';
    }
  };

  const getAnimationClass = () => {
    switch (animation) {
      case 'wave':
        return 'animate-shimmer';
      case 'none':
        return '';
      case 'pulse':
      default:
        return 'animate-pulse';
    }
  };

  const style: React.CSSProperties = {
    width: width || 'auto',
    height: height || (variant === 'text' ? '1em' : 'auto'),
  };

  return (
    <>
      {Array.from({ length: count }).map((_, index) => (
        <div 
          key={index}
          className={`bg-gray-200 ${getVariantClass()} ${getAnimationClass()} ${className}`}
          style={style}
        />
      ))}
    </>
  );
};

export default Skeleton;

// Predefined skeleton patterns for common UI elements
export const SkeletonText: React.FC<{ lines?: number, className?: string }> = ({ 
  lines = 3, 
  className = ''
}) => (
  <div className={`space-y-2 ${className}`}>
    <Skeleton variant="text" width="100%" height="1.2em" />
    {Array.from({ length: lines - 1 }).map((_, i) => (
      <Skeleton 
        key={i} 
        variant="text" 
        width={`${Math.floor(Math.random() * 30) + 70}%`} 
        height="1.2em" 
      />
    ))}
  </div>
);

export const SkeletonCard: React.FC<{ className?: string }> = ({ className = '' }) => (
  <div className={`bg-white rounded-lg shadow-sm p-4 ${className}`}>
    <div className="flex justify-between items-start mb-4">
      <div className="flex">
        <Skeleton variant="circular" width={40} height={40} className="mr-3" />
        <div>
          <Skeleton variant="text" width={120} className="mb-2" />
          <Skeleton variant="text" width={80} />
        </div>
      </div>
      <Skeleton variant="rounded" width={60} height={24} />
    </div>
    <SkeletonText lines={2} />
    <div className="mt-4">
      <Skeleton variant="rounded" width="100%" height={40} />
    </div>
  </div>
);

export const SkeletonTable: React.FC<{ rows?: number, cols?: number, className?: string }> = ({ 
  rows = 5, 
  cols = 4,
  className = '' 
}) => (
  <div className={`bg-white rounded-lg shadow-sm overflow-hidden ${className}`}>
    <div className="p-4 border-b">
      <Skeleton variant="text" width={180} />
    </div>
    <div className="grid" style={{ gridTemplateColumns: `repeat(${cols}, 1fr)` }}>
      {/* Header row */}
      {Array.from({ length: cols }).map((_, i) => (
        <div key={`header-${i}`} className="p-3 bg-gray-50 border-b">
          <Skeleton variant="text" width="80%" />
        </div>
      ))}
      
      {/* Data rows */}
      {Array.from({ length: rows }).map((_, rowIndex) => (
        Array.from({ length: cols }).map((_, colIndex) => (
          <div key={`cell-${rowIndex}-${colIndex}`} className="p-3 border-b">
            <Skeleton variant="text" width={`${Math.floor(Math.random() * 40) + 60}%`} />
          </div>
        ))
      ))}
    </div>
  </div>
);

// Add the shimmer animation to Tailwind config if needed
// This can be manually added to tailwind.config.js
/*
  animation: {
    shimmer: 'shimmer 2s infinite linear',
  },
  keyframes: {
    shimmer: {
      '0%': { backgroundPosition: '-200px 0' },
      '100%': { backgroundPosition: '200px 0' },
    },
  },
*/ 