import React, { useState } from 'react';
import { Check, ChevronDown, ChevronUp, Clipboard, ExternalLink, Clock, Calendar } from 'lucide-react';

interface RecommendationsListProps {
  recommendations: string[];
}

const RecommendationsList: React.FC<RecommendationsListProps> = ({ recommendations }) => {
  const [expandedItem, setExpandedItem] = useState<number | null>(null);
  const [copiedItem, setCopiedItem] = useState<number | null>(null);
  
  const handleCopy = (text: string, index: number) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopiedItem(index);
      setTimeout(() => setCopiedItem(null), 2000);
    });
  };
  
  const toggleItem = (index: number) => {
    setExpandedItem(expandedItem === index ? null : index);
  };
  
  // Generate some mock implementation details and resources for each recommendation
  const getImplementationDetails = (recommendation: string, index: number) => {
    const timeframes = ['Short-term (1-3 months)', 'Medium-term (3-6 months)', 'Long-term (6-12 months)'];
    const timeframe = timeframes[index % timeframes.length];
    
    const difficultyLevels = ['Low', 'Medium', 'High'];
    const difficulty = difficultyLevels[index % difficultyLevels.length];
    
    // Generate some steps based on the recommendation
    const steps = [
      `Assess current state of ${recommendation.toLowerCase().split(' ').slice(1, 3).join(' ')}`,
      `Develop ${recommendation.toLowerCase().split(' ').slice(0, 2).join(' ')} framework`,
      `Pilot the implementation with a select group`,
      `Gather feedback and refine approach`,
      `Roll out to entire organization`
    ];
    
    // Generate some resources based on the recommendation
    const resources = [
      `PMI guide to ${recommendation.toLowerCase().split(' ').slice(0, 3).join(' ')}`,
      `${recommendation.split(' ')[0]} template in resource library`,
      `External benchmark data for ${recommendation.toLowerCase().split(' ').slice(-2).join(' ')}`
    ];
    
    return { timeframe, difficulty, steps, resources };
  };
  
  return (
    <div className="space-y-4">
      {recommendations.map((recommendation, index) => {
        const details = getImplementationDetails(recommendation, index);
        
        return (
          <div 
            key={index} 
            className={`bg-white rounded-lg border transition-shadow ${
              expandedItem === index ? 'shadow-md border-primary-200' : 'border-gray-200 hover:border-gray-300'
            }`}
          >
            <div 
              className="p-4 flex items-start justify-between cursor-pointer"
              onClick={() => toggleItem(index)}
            >
              <div className="flex items-start">
                <div className={`flex items-center justify-center w-6 h-6 rounded-full mt-0.5 mr-3 ${
                  index < 3 ? 'bg-primary-100 text-primary-800' : 'bg-gray-100 text-gray-800'
                }`}>
                  <span className="text-xs font-semibold">{index + 1}</span>
                </div>
                <div>
                  <h3 className="font-medium text-gray-800">{recommendation}</h3>
                  <div className="flex items-center mt-1 space-x-4 text-xs text-gray-500">
                    <span className="flex items-center">
                      <Clock className="h-3.5 w-3.5 mr-1" />
                      {details.timeframe}
                    </span>
                    <span className="flex items-center">
                      <span className={`w-2 h-2 rounded-full mr-1 ${
                        details.difficulty === 'Low' ? 'bg-green-500' :
                        details.difficulty === 'Medium' ? 'bg-amber-500' : 'bg-red-500'
                      }`}></span>
                      {details.difficulty} difficulty
                    </span>
                  </div>
                </div>
              </div>
              <div>
                {expandedItem === index ? (
                  <ChevronUp className="h-5 w-5 text-gray-400" />
                ) : (
                  <ChevronDown className="h-5 w-5 text-gray-400" />
                )}
              </div>
            </div>
            
            {expandedItem === index && (
              <div className="px-4 pb-4 border-t border-gray-100 mt-2 pt-3">
                <div className="mb-3">
                  <h4 className="text-xs font-medium text-gray-700 mb-1">Implementation Steps</h4>
                  <ol className="space-y-1 pl-4 text-xs text-gray-600 list-decimal">
                    {details.steps.map((step, stepIndex) => (
                      <li key={stepIndex}>{step}</li>
                    ))}
                  </ol>
                </div>
                
                <div className="mb-3">
                  <h4 className="text-xs font-medium text-gray-700 mb-1">Helpful Resources</h4>
                  <ul className="space-y-1 pl-1 text-xs">
                    {details.resources.map((resource, resIndex) => (
                      <li key={resIndex} className="flex items-center">
                        <ExternalLink className="h-3.5 w-3.5 text-blue-600 mr-1.5" />
                        <a href="#" className="text-blue-600 hover:underline">{resource}</a>
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div className="flex justify-end mt-4">
                  <button 
                    className="flex items-center text-xs bg-gray-100 hover:bg-gray-200 text-gray-700 px-2 py-1 rounded"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleCopy(recommendation, index);
                    }}
                  >
                    {copiedItem === index ? (
                      <>
                        <Check className="h-3.5 w-3.5 mr-1.5 text-green-600" />
                        Copied!
                      </>
                    ) : (
                      <>
                        <Clipboard className="h-3.5 w-3.5 mr-1.5" />
                        Copy Recommendation
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};

export default RecommendationsList;