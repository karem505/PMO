import React, { useState, useEffect } from 'react';
import { Link, FileText, ChevronDown, ChevronUp, Clock } from 'lucide-react';
import { documentProcessingService } from '../services/documentProcessingService';
import { DocumentChunk } from '../types';
import { useAppStore } from '../store';
import { useLanguage } from '../contexts/LanguageContext';
interface CrossDomainReferenceProps {
  domainId: number;
  keyword?: string;
}

const CrossDomainReference: React.FC<CrossDomainReferenceProps> = ({ domainId, keyword }) => {
  const [expanded, setExpanded] = useState(false);
  const [loading, setLoading] = useState(false);
  const [references, setReferences] = useState<DocumentChunk[]>([]);
  const { t } = useLanguage();
  const { getActiveProject } = useAppStore();
  const activeProject = getActiveProject();
  
  useEffect(() => {
    if (expanded && references.length === 0) {
      loadReferences();
    }
  }, [expanded]);
  
  const loadReferences = async () => {
    if (!activeProject) return;
    
    setLoading(true);
    try {
      // Use the document service to get cross-domain references
      const chunks = await documentProcessingService.getRelevantCrossDomainChunks(
        keyword || `domain ${domainId}`,
        domainId,
        activeProject.id,
        5
      );
      
      setReferences(chunks);
    } catch (error) {
      console.error('Error loading cross-domain references:', error);
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <div className="bg-blue-50 rounded-lg border border-blue-100 p-4 mt-4">
      <div 
        className="flex items-center justify-between cursor-pointer"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="flex items-center">
          <Link className="h-5 w-5 me-2 text-blue-600" />
          <h3 className="font-medium text-blue-800">{t('domain.crossDomainReferences', 'Cross-Domain References')}</h3>
          <span className="ms-2 px-2 py-0.5 bg-blue-200 text-blue-800 text-xs rounded-full">
            {t('domain.aiEnhanced', 'AI-Enhanced')}
          </span>
        </div>
        {expanded ? (
          <ChevronUp className="h-5 w-5 text-blue-600" />
        ) : (
          <ChevronDown className="h-5 w-5 text-blue-600" />
        )}
      </div>
      
      {expanded && (
        <div className="mt-4">
          {loading ? (
            <div className="flex items-center justify-center py-4">
              <Clock className="h-5 w-5 text-blue-600 animate-pulse me-2" />
              <span className="text-blue-700">{t('domain.loadingReferences', 'Loading references...')}</span>
            </div>
          ) : references.length > 0 ? (
            <div className="space-y-3">
              <p className="text-sm text-blue-700">
                {t('domain.relevantInformationFromOtherDomainsThatCanEnhanceYourWorkInThisDomain', 'Relevant information from other domains that can enhance your work in this domain:')}
              </p>
              {references.map((chunk, index) => (
                <div key={index} className="bg-white rounded-md p-3 border border-blue-200">
                  <div className="flex items-center mb-1">
                    <FileText className="h-4 w-4 me-2 text-blue-600" />
                    <span className="text-sm font-medium text-blue-800">
                      {chunk.metadata.source || `Document from Domain ${chunk.metadata.domainId}`}
                    </span>
                  </div>
                  <p className="text-sm text-gray-700 line-clamp-3">
                    {chunk.content.substring(0, 200)}...
                  </p>
                  <div className="mt-1 text-xs text-gray-500">
                    Domain {chunk.metadata.domainId}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-blue-700 py-2">
              {t('domain.noCrossDomainReferencesFound', 'No cross-domain references found. As you add more documents to other domains, relevant information will appear here automatically.')}
            </p>
          )}
        </div>
      )}
    </div>
  );
};

export default CrossDomainReference;