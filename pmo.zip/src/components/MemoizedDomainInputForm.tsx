import React from 'react';
import DomainInputForm from './DomainInputForm';

/**
 * Memoized version of DomainInputForm that only re-renders when domain or onAnalyze props change
 * This improves performance by preventing unnecessary re-renders
 */
const MemoizedDomainInputForm = React.memo(
  DomainInputForm,
  (prevProps, nextProps) => {
    // Only re-render if domain or onAnalyze changes
    return (
      prevProps.domain.id === nextProps.domain.id &&
      prevProps.onAnalyze === nextProps.onAnalyze
    );
  }
);

export default MemoizedDomainInputForm; 