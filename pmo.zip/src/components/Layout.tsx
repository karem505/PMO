import React, { useEffect, useState } from 'react';
import { Outlet, useLocation, useParams, useNavigate } from 'react-router-dom';
import Sidebar from './Sidebar';
import Header from './Header';
import MobileNav from './MobileNav';
import { useTheme } from '../contexts/ThemeContext';
import { useLanguage } from '../contexts/LanguageContext';
import { useAppStore } from '../store';
import ConnectionStatus from './ConnectionStatus';
import { useAuth } from './auth/AuthContext';

const Layout: React.FC = () => {
  const { darkMode } = useTheme();
  const { isRTL } = useLanguage();
  const { connectionError, showConnectionErrors } = useAppStore();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 1024);
  const location = useLocation();
  const { currentUser, isLoading } = useAuth();
  const navigate = useNavigate();

  // Handle resize events for responsive layout
  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 1024);
      if (window.innerWidth >= 1024) {
        setSidebarOpen(false);
      }
    };
    
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    setSidebarOpen(false);
  }, [location.pathname]);
  
  // Ensure the RTL attribute is properly applied
  useEffect(() => {
    document.documentElement.dir = isRTL ? 'rtl' : 'ltr';
    document.documentElement.lang = isRTL ? 'ar' : 'en';
    
    if (isRTL) {
      document.body.classList.add('rtl');
    } else {
      document.body.classList.remove('rtl');
    }
    
    document.body.style.display = 'none';
    document.body.offsetHeight;
    document.body.style.display = '';
  }, [isRTL]);

  useEffect(() => {
    if (!isLoading && !currentUser) {
      navigate('/login');
    }
  }, [currentUser, isLoading, navigate]);

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };
  
  if (isLoading) {
    return <div className="h-screen w-full flex items-center justify-center bg-gray-50">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
    </div>;
  }

  return (
    <div className={`flex min-h-screen w-full overflow-x-hidden ${darkMode ? 'dark' : ''} ${isRTL ? 'rtl' : 'ltr'}`}>
      {/* Mobile sidebar overlay */}
      {sidebarOpen && isMobile && (
        <div 
          className="fixed inset-0 z-40 bg-black bg-opacity-50 transition-opacity lg:hidden"
          onClick={() => setSidebarOpen(false)}
          aria-hidden="true"
        ></div>
      )}
      
      {/* Sidebar */}
      <div 
        className={`
          fixed top-0 bottom-0 z-[60] bg-neutral-900
          w-64 transform transition-transform duration-300 ease-in-out h-screen
          ${!isRTL ? (sidebarOpen ? 'translate-x-0' : '-translate-x-full') : (sidebarOpen ? 'translate-x-0' : 'translate-x-full')}
          lg:fixed lg:translate-x-0 lg:z-30
          ${isRTL ? 'right-0 left-auto' : 'left-0 right-auto'}
        `}
      >
        <Sidebar />
      </div>
      
      {/* Main content */}
      <div className={`flex-1 flex flex-col h-screen overflow-hidden ${isMobile ? '' : (isRTL ? 'pr-64' : 'pl-64')}`}>
        <Header toggleSidebar={toggleSidebar} sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} />
        
        {/* Mobile navigation bar */}
        {isMobile && <MobileNav />}
        
        {/* Main content area */}
        <main className={`flex-1 w-full px-4 py-6 sm:px-6 lg:px-8 overflow-x-hidden overflow-y-auto bg-dashboard-pattern ${isMobile ? 'pb-28' : ''}`}>
          <div className="max-w-7xl mx-auto">
            {connectionError && showConnectionErrors && (
              <div className="bg-amber-50 border-b border-amber-100 dark:bg-amber-900/30 dark:border-amber-800 py-1 px-4">
                <ConnectionStatus />
              </div>
            )}
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
};

export default Layout;