import React, { useState, useEffect } from 'react';
import { X, Download, Maximize, Minimize, FileText, ExternalLink } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface DocumentViewerProps {
  url: string;
  filename: string;
  onClose: () => void;
}

const DocumentViewer: React.FC<DocumentViewerProps> = ({ url, filename, onClose }) => {
  const { t } = useLanguage();
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [downloadInProgress, setDownloadInProgress] = useState(false);

  // Clean URL by removing query parameters or trailing characters
  const cleanUrl = React.useMemo(() => {
    let cleanedUrl = url;
    
    // Remove query parameters
    if (cleanedUrl.includes('?')) {
      cleanedUrl = cleanedUrl.split('?')[0];
    }
    
    return cleanedUrl;
  }, [url]);

  useEffect(() => {
    // Reset state when URL changes
    setIsLoading(true);
    setError(null);
  }, [url]);

  const getFileType = (): string => {
    const extension = filename.split('.').pop()?.toLowerCase() || '';

    if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'].includes(extension)) {
      return 'image';
    } else if (['pdf'].includes(extension)) {
      return 'pdf';
    } else if (['doc', 'docx'].includes(extension)) {
      return 'word';
    } else if (['xls', 'xlsx', 'csv'].includes(extension)) {
      return 'excel';
    } else if (['ppt', 'pptx'].includes(extension)) {
      return 'powerpoint';
    } else if (['txt', 'md', 'json', 'xml', 'html', 'css', 'js'].includes(extension)) {
      return 'text';
    } else {
      return 'unknown';
    }
  };

  const handleDownload = (e?: React.MouseEvent | React.KeyboardEvent) => {
    // Prevent event propagation
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }

    // Use a timeout to prevent accidental double clicks
    if (downloadInProgress) return;
    setDownloadInProgress(true);
    
    try {
      const link = document.createElement('a');
      link.href = cleanUrl;
      link.setAttribute('download', filename);
      link.setAttribute('target', '_blank');
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      // Add page refresh after successful download to prevent auto-download issues
      setTimeout(() => {
        window.location.reload();
      }, 1500);
    } catch (error) {
      console.error('Download error:', error);
    } finally {
      // Reset download flag after a short delay
      setTimeout(() => {
        setDownloadInProgress(false);
      }, 1000);
    }
  };

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  const openExternal = () => {
    window.open(cleanUrl, '_blank');
  };

  const renderDocumentContent = () => {
    const fileType = getFileType();

    const handleLoad = () => {
      setIsLoading(false);
    };

    const handleError = () => {
      setIsLoading(false);
      setError('Failed to load document. Try downloading it instead.');
    };

    switch (fileType) {
      case 'image':
        return (
          <div className="flex items-center justify-center h-full">
            <img 
              src={cleanUrl} 
              alt={filename} 
              className="max-w-full max-h-full object-contain" 
              onLoad={handleLoad}
              onError={handleError}
            />
          </div>
        );
      case 'pdf':
        return (
          <iframe 
            src={`${cleanUrl}#toolbar=0&navpanes=0`} 
            className="w-full h-full border-0" 
            onLoad={handleLoad}
            onError={handleError}
            title={filename}
          />
        );
      case 'word':
        return (
          <iframe 
            src={`https://view.officeapps.live.com/op/embed.aspx?src=${encodeURIComponent(cleanUrl)}`}
            className="w-full h-full border-0" 
            onLoad={handleLoad}
            onError={handleError}
            title={filename}
          />
        );
      case 'excel':
      case 'powerpoint':
        // Use Microsoft Office Web Viewer as primary option, Google Docs Viewer as fallback
        return (
          <iframe 
            src={`https://view.officeapps.live.com/op/embed.aspx?src=${encodeURIComponent(cleanUrl)}`}
            className="w-full h-full border-0" 
            onLoad={handleLoad}
            onError={handleError}
            title={filename}
          />
        );
      case 'text':
        return (
          <iframe 
            src={cleanUrl} 
            className="w-full h-full border-0"
            onLoad={handleLoad}
            onError={handleError}
            title={filename}
          />
        );
      default:
        // For unsupported file types, show a message and open in external viewer option
        return (
          <div className="flex flex-col items-center justify-center h-full">
            <FileText className="w-16 h-16 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-800 mb-2">{filename}</h3>
            <p className="text-gray-600 mb-4">
              {t('documents.previewNotAvailable', 'Preview is not available for this file type.')}
            </p>
            <div className="flex space-x-4">
              <button
                onClick={openExternal}
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center"
              >
                <ExternalLink className="h-4 w-4 mr-2" />
                {t('documents.openExternal', 'Open in Browser')}
              </button>
              <button
                onClick={(e) => handleDownload(e)}
                className="px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 flex items-center"
              >
                <Download className="h-4 w-4 mr-2" />
                {t('documents.download', 'Download')}
              </button>
            </div>
          </div>
        );
    }
  };

  return (
    <div className={`fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 ${isFullscreen ? 'p-0' : 'p-4 md:p-10'}`}>
      <div className={`bg-white rounded-lg overflow-hidden shadow-xl flex flex-col ${isFullscreen ? 'w-full h-full' : 'w-full max-w-4xl h-[80vh]'}`}>
        {/* Header */}
        <div className="bg-gray-100 px-4 py-3 flex items-center justify-between border-b border-gray-200">
          <h3 className="font-medium text-gray-800 truncate">{filename}</h3>
          <div className="flex items-center space-x-2">
            <button
              onClick={(e) => handleDownload(e)}
              className="p-1.5 rounded-md hover:bg-gray-200 text-gray-600"
              title={t('documents.download', 'Download')}
            >
              <Download className="h-5 w-5" />
            </button>
            <button
              onClick={toggleFullscreen}
              className="p-1.5 rounded-md hover:bg-gray-200 text-gray-600"
              title={isFullscreen ? t('documents.exitFullscreen', 'Exit Fullscreen') : t('documents.fullscreen', 'Fullscreen')}
            >
              {isFullscreen ? <Minimize className="h-5 w-5" /> : <Maximize className="h-5 w-5" />}
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-md hover:bg-gray-200 text-gray-600"
              title={t('documents.close', 'Close')}
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>
        
        {/* Document content */}
        <div className="flex-1 overflow-auto relative">
          {isLoading && (
            <div className="absolute inset-0 flex items-center justify-center bg-white bg-opacity-75">
              <div className="animate-spin rounded-full h-12 w-12 border-4 border-gray-200 border-t-blue-600"></div>
            </div>
          )}
          
          {error && (
            <div className="absolute inset-0 flex items-center justify-center bg-white">
              <div className="text-center p-4">
                <div className="text-red-500 text-lg mb-2">{error}</div>
                <button
                  onClick={(e) => handleDownload(e)}
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center mx-auto"
                >
                  <Download className="h-4 w-4 mr-2" />
                  {t('documents.download', 'Download File')}
                </button>
              </div>
            </div>
          )}
          
          {renderDocumentContent()}
        </div>
      </div>
    </div>
  );
};

export default DocumentViewer; 