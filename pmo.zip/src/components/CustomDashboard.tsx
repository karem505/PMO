import React, { useState, useEffect } from 'react';
import { Chart as ChartJS, ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement } from 'chart.js';
import { Doughnut, Bar } from 'react-chartjs-2';
import { ArrowRight, CheckCircle2, Clock, FileText, Sparkles, Brain, Zap, Target, Plus, BarChart as ChartBar, Layers, CheckSquare, Settings, ArrowLeft } from 'lucide-react';
import { Project, UserData } from '../types';
import ProjectDetailsCard from './ProjectDetailsCard';
import ProgressChart from './ProgressChart';
import DomainCard from './PMODomainTile';
import GanttChart from './GanttChart';
import { domains, getIconComponent } from '../data';
import { useAppStore } from '../store';
import { useNavigationGuard } from '../hooks/useNavigationGuard';

ChartJS.register(ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement);

interface CustomDashboardProps {
  activeProject: Project | undefined;
  overallProgress: number;
  completedTasks: number;
  totalTasks: number;
  userData: UserData;
  layout: 'grid' | 'list';
  enabledWidgets: string[];
  domainProgressData: { domain: string; progress: number }[];
  onNavigate: (path: string, state?: Record<string, any>) => void;
  t: (key: string, defaultValue?: string) => string;
  isRTL: boolean;
}

const CustomDashboard: React.FC<CustomDashboardProps> = ({
  activeProject,
  overallProgress,
  completedTasks,
  totalTasks,
  userData,
  layout,
  enabledWidgets,
  domainProgressData,
  onNavigate,
  t,
  isRTL
}) => {
  // Get the AppStore for accessing state
  const appStore = useAppStore();
  const [activeChartView, setActiveChartView] = useState<'bar' | 'gantt'>('bar');
  const [isMounted, setIsMounted] = useState(false);
  const { navigate } = useNavigationGuard();

  // Add safety check for DOM operations
  useEffect(() => {
    // Mark component as mounted
    setIsMounted(true);
    
    // Clean up when component unmounts
    return () => {
      setIsMounted(false);
    };
  }, []);

  // Safer approach to prevent "Cannot read properties of null (reading 'nodeName')" error
  const safeNavigate = (path: string, state?: Record<string, any>) => {
    // Only navigate if component is still mounted
    if (isMounted) {
      onNavigate(path, state);
    }
  };

  // Prepare data for doughnut chart
  const doughnutChartData = {
    labels: ['Completed', 'Remaining'],
    datasets: [
      {
        data: [completedTasks, totalTasks - completedTasks],
        backgroundColor: [
          'rgba(72, 187, 120, 0.8)',
          'rgba(237, 242, 247, 0.8)',
        ],
        borderColor: [
          'rgba(72, 187, 120, 1)',
          'rgba(237, 242, 247, 1)',
        ],
        borderWidth: 1,
      },
    ],
  };

  // Prepare data for bar chart
  const barChartData = {
    labels: domainProgressData.slice(0, 6).map(d => t('domain.' + d.domain.split(' ')[0], d.domain.split(' ')[0])), // First word only
    datasets: [
      {
        label: t('domain.domainProgress', 'Domain Progress (%)'),
        data: domainProgressData.slice(0, 6).map(d => Math.round(d.progress)),
        backgroundColor: 'rgba(79, 70, 229, 0.8)',
      },
    ],
  };

  const handleViewAllTasks = () => {
    navigate('/tasks');
  };

  return (
    <>
      {/* Project Details Card */}
      {activeProject && enabledWidgets.includes('progress') && (
        <ProjectDetailsCard activeProject={activeProject} />
      )}
      
      {enabledWidgets.includes('progress') && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white rounded-xl shadow-sm border border-neutral-100 p-6 hover:shadow-md transition-all duration-300">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium text-neutral-800">{t('common.overallProgress', 'Overall Progress')}</h3>
              <div className="p-2 bg-primary-100 rounded-full">
                <FileText className="h-5 w-5 text-primary-600" />
              </div>
            </div>
            <div className="mt-4">
              <div className="flex items-end justify-between">
                <p className="text-3xl font-bold bg-gradient-to-r from-primary-600 to-secondary-600 bg-clip-text text-transparent">{Math.round(completedTasks / totalTasks * 100)}%</p>
                <p className="text-sm text-neutral-500">
                  {completedTasks} {t('dashboard.of', 'of')} {totalTasks} {t('dashboard.tasksCompleted', 'tasks completed')}
                </p>
              </div>
              <div className="mt-4 h-4 w-full bg-neutral-100 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-primary-500 to-secondary-500 rounded-full transition-all duration-700"
                  style={{ width: `${Math.round(completedTasks / totalTasks * 100)}%` }}
                ></div>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-xl shadow-sm border border-neutral-100 p-6 hover:shadow-md transition-all duration-300">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium text-neutral-800">{t('dashboard.completedTasks')}</h3>
              <div className="p-2 bg-accent-100 rounded-full">
                <CheckCircle2 className="h-5 w-5 text-accent-600" />
              </div>
            </div>
            <div className="mt-4 flex flex-col items-center">
              <div className="h-32 w-32">
                <Doughnut 
                  data={doughnutChartData}
                  options={{
                    cutout: '70%',
                    plugins: {
                      legend: {
                        display: false
                      },
                      tooltip: {
                        callbacks: {
                          label: function(context) {
                            return `${context.label}: ${context.raw} (${Math.round(
                              (context.raw as number) / totalTasks * 100
                            )}%)`;
                          }
                        }
                      }
                    },
                  }}
                />
              </div>
              <div className="text-center mt-2">
                <p className="text-lg font-semibold">{Math.round(completedTasks / totalTasks * 100)}% {t('common.Complete', 'Complete')}</p>
                <p className="text-sm text-gray-500">{completedTasks} {t('dashboard.of', 'of')} {totalTasks} {t('dashboard.tasksCompleted', 'tasks completed')}</p>
              </div>
              <button 
                className={`mt-4 text-sm text-primary-600 font-medium flex items-center hover:text-primary-700 transition-colors`}
                onClick={handleViewAllTasks}
              >
                {isRTL ? (
                  <>
                    {t('dashboard.viewAllTasks', 'View all tasks')}
                    <ArrowLeft className="ms-1 h-4 w-4 transform rotate-180 group-hover:-translate-x-1 transition-transform duration-200" />
                  </>
                ) : (
                  <>
                    {t('dashboard.viewAllTasks', 'View all tasks')}
                    <ArrowRight className="ml-1 h-4 w-4 transform group-hover:translate-x-1 transition-transform duration-200" />
                  </>
                )}
              </button>
            </div>
          </div>
          
          <div className="bg-white rounded-xl shadow-sm border border-neutral-100 p-6 hover:shadow-md transition-all duration-300">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium text-neutral-800">{t('dashboard.organization')}</h3>
              <div className="p-2 bg-secondary-100 rounded-full">
                <Settings className="h-5 w-5 text-secondary-600" />
              </div>
            </div>
            <div className="mt-4">
              <p className="text-xl font-bold text-neutral-800">{userData.organizationName || t('dashboard.notSet', 'Not set')}</p>
              <p className="text-sm text-neutral-500 mt-1">
                {t('dashboard.industry', 'Industry')}: {userData.industry || t('dashboard.notSet', 'Not set')}
              </p>
              <p className="text-sm text-neutral-500 mt-1">
                {t('dashboard.pmoMaturityLevel')}: {userData.pmoMaturityLevel || 'Initial'}
              </p>
              <div className="mt-4 h-2 w-full bg-neutral-100 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-secondary-500 rounded-full"
                  style={{ width: `${
                    userData.pmoMaturityLevel === 'Initial' ? 20 :
                    userData.pmoMaturityLevel === 'Defined' ? 40 :
                    userData.pmoMaturityLevel === 'Managed' ? 60 :
                    userData.pmoMaturityLevel === 'Optimized' ? 80 :
                    userData.pmoMaturityLevel === 'Innovative' ? 100 : 20
                  }%` }}
                ></div>
              </div>
              <p className="text-xs text-neutral-500 mt-1 text-right">
                {t('dashboard.maturityLevel', 'Maturity Level')}: {
                  userData.pmoMaturityLevel === 'Initial' ? '1/5' :
                  userData.pmoMaturityLevel === 'Defined' ? '2/5' :
                  userData.pmoMaturityLevel === 'Managed' ? '3/5' :
                  userData.pmoMaturityLevel === 'Optimized' ? '4/5' :
                  userData.pmoMaturityLevel === 'Innovative' ? '5/5' : '1/5'
                }
              </p>
            </div>
          </div>
        </div>
      )}
      
      {enabledWidgets.includes('charts') && (
        <div className="mt-6">
          {/* Chart type switcher */}
          <div className="flex mb-4 border-b border-gray-200">
            <button
              className={`mr-4 py-2 px-1 text-sm font-medium ${
                activeChartView === 'bar'
                  ? 'text-primary-600 border-b-2 border-primary-500'
                  : 'text-gray-100 hover:text-gray-300'
              }`}
              onClick={() => setActiveChartView('bar')}
            >
              {t('dashboard.barCharts', 'Bar Charts')}
            </button>
            <button
              className={`mr-4 py-2 px-1 text-sm font-medium ${
                activeChartView === 'gantt'
                  ? 'text-primary-600 border-b-2 border-primary-500'
                  : 'text-gray-100 hover:text-gray-300'
              }`}
              onClick={() => setActiveChartView('gantt')}
            >
              {t('dashboard.ganttTimeline', 'Gantt Timeline')}
            </button>
          </div>
          
          {activeChartView === 'bar' ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
              <div className="bg-white rounded-xl shadow-sm border border-neutral-100 p-6 hover:shadow-md transition-all duration-300">
                <h3 className="text-lg font-medium text-neutral-800 mb-4 text-center sm:text-left">{t('dashboard.domainProcessComparison','Domain Progress Comparison')}</h3>
                <div className="h-auto min-h-[300px] flex items-center justify-center px-2">
                  <div className="w-full mx-auto">
                    <Bar
                      data={barChartData}
                      options={{
                        indexAxis: 'y',
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                          legend: {
                            display: false
                          }
                        },
                        scales: {
                          y: {
                            beginAtZero: true,
                            ticks: {
                              autoSkip: false,
                              font: {
                                size: 9
                              }
                            }
                          },
                          x: {
                            max: 100,
                            title: {
                              display: true,
                              font: {
                                size: 10
                              },
                              text: t('domain.domainProgress', 'Domain Progress (%)')
                            },
                            ticks: {
                              font: {
                                size: 9
                              }
                            }
                          }
                        }
                      }}
                    />
                  </div>
                </div>
              </div>
              
              <div className="bg-white rounded-xl shadow-sm border border-neutral-100 p-6 hover:shadow-md transition-all duration-300">
                <h3 className="text-lg font-medium text-neutral-800 mb-4 flex items-center">
                  <Target className={`h-5 w-5 text-primary-600 me-2`} />
                  {t('dashboard.nextSteps', 'Next Steps')}
                </h3>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <div className="flex-shrink-0 h-5 w-5 rounded-full bg-primary-100 flex items-center justify-center mt-0.5">
                      <span className="text-primary-600 text-xs font-bold">1</span>
                    </div>
                    <div className="ms-3">
                      <p className="text-neutral-800 font-medium">{t('dashboard.completePmoMaturityAssessment', 'Complete a PMO Maturity Assessment')}</p>
                      <div className="flex justify-between items-center">
                        <p className="text-sm text-neutral-600">{t('dashboard.getInsightsAboutPmoMaturityLevel', `Get insights about your PMO's current maturity level`)}</p>
                        <span className="text-xs font-medium px-2 py-0.5 bg-yellow-100 text-yellow-800 rounded-full text-center">45% {t('common.Complete', 'Complete')}</span>
                      </div>
                      <div className="mt-1 h-1.5 w-full bg-neutral-100 rounded-full overflow-hidden">
                        <div className="h-full bg-yellow-500 rounded-full" style={{ width: '45%' }}></div>
                      </div>
                    </div>
                  </li>
                  
                  <li className="flex items-start">
                    <div className="flex-shrink-0 h-5 w-5 rounded-full bg-primary-100 flex items-center justify-center mt-0.5">
                      <span className="text-primary-600 text-xs font-bold">2</span>
                    </div>
                    <div className="ms-3">
                      <p className="text-neutral-800 font-medium">{t('dashboard.analysisDocuments', 'Upload supporting documents for AI analysis')}</p>
                      <div className="flex justify-between items-center">
                        <p className="text-sm text-neutral-600">{t('dashboard.analysisDocumentsDesc', `Enhance AI recommendations with your organization's context`)}</p>
                        <span className="text-xs font-medium px-2 py-0.5 bg-blue-100 text-blue-800 rounded-full text-center">20% {t('common.Complete', 'Complete')}</span>
                      </div>
                      <div className="mt-1 h-1.5 w-full bg-neutral-100 rounded-full overflow-hidden">
                        <div className="h-full bg-blue-500 rounded-full" style={{ width: '20%' }}></div>
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          ) : (
            <GanttChart className="mb-6" />
          )}
        </div>
      )}

      {/* Domain Progress Section */}
      {enabledWidgets.includes('domains') && (
        <>
          <div className="flex items-center justify-between mt-8 mb-4">
            <h2 className="text-xl font-bold ">{t('dashboard.pmoDomains')}</h2>
            <a href="#" className={`text-sm text-primary-600 hover:text-primary-700 flex items-center transition-colors`}>
              {isRTL ? (
                <>
                  {t('dashboard.viewAll')}
                  <ArrowLeft className="h-4 w-4 ms-1" />
                </>
              ) : (
                <>
                  {t('dashboard.viewAll')}
                  <ArrowRight className="h-4 w-4 ms-1" />
                </>
              )}
            </a>
          </div>
          
          {layout === 'grid' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {domains.map(domain => (
                <DomainCard key={domain.id} domain={domain} />
              ))}
            </div>
          ) : (
            <div className="space-y-3">
              {domains.map(domain => {
                // Get domain progress using the appStore hook instance
                const progress = appStore.getDomainProgress(domain.id);
                const IconComponent = getIconComponent(domain.icon);
                
                return (
                  <div 
                    key={domain.id} 
                    className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 hover:shadow-md transition-all duration-200 cursor-pointer" 
                    onClick={() => safeNavigate(`/domain/${domain.id}`)}
                  >
                    <div className="flex justify-between items-center">
                      <div className="flex items-center">
                        <div className="p-2 bg-primary-100 rounded-lg me-3">
                          {IconComponent && <IconComponent className="h-5 w-5 text-primary-600" />}
                        </div>
                        <div>
                          <h3 className="font-medium text-gray-800">{t(`domains.${domain.id}.name`, domain.name)}</h3>
                          <p className="text-sm text-gray-600 line-clamp-1">{t(`domains.${domain.id}.description`)}</p>
                        </div>
                      </div>
                      <div className="flex flex-col items-end">
                        <span className="text-xl font-bold text-primary-600">{Math.round(progress.overallProgress)}%</span>
                        <div className="w-24 h-2 bg-gray-100 rounded-full mt-1 overflow-hidden">
                          <div 
                            className="h-full bg-primary-600 rounded-full" 
                            style={{ width: `${progress.overallProgress}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-3 grid grid-cols-3 gap-2">
                      <div className="text-center">
                        <p className="text-xs font-medium text-neutral-500">{t('domain.inputStage')}</p>
                        <div className="mt-1 h-1.5 w-full bg-neutral-100 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-green-500 rounded-full transition-all duration-500" 
                            style={{ width: `${progress.inputProgress}%` }}
                          ></div>
                        </div>
                        <p className="mt-1 text-xs font-semibold">{Math.round(progress.inputProgress)}%</p>
                      </div>
                      <div className="text-center">
                        <p className="text-xs font-medium text-neutral-500">{t('domain.processingStage')}</p>
                        <div className="mt-1 h-1.5 w-full bg-neutral-100 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-amber-500 rounded-full transition-all duration-500" 
                            style={{ width: `${progress.processingProgress}%` }}
                          ></div>
                        </div>
                        <p className="mt-1 text-xs font-semibold">{Math.round(progress.processingProgress)}%</p>
                      </div>
                      <div className="text-center">
                        <p className="text-xs font-medium text-neutral-500">{t('domain.outputStage')}</p>
                        <div className="mt-1 h-1.5 w-full bg-neutral-100 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-secondary-500 rounded-full transition-all duration-500" 
                            style={{ width: `${progress.outputProgress}%` }}
                          ></div>
                        </div>
                        <p className="mt-1 text-xs font-semibold">{Math.round(progress.outputProgress)}%</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </>
      )}

      {enabledWidgets.includes('progress') && (
        <div className="mt-10 bg-gradient-to-br from-primary-800 to-secondary-900 rounded-xl shadow-md p-8 text-white">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div className="mb-6 md:mb-0 md:mr-6 rtl:md:mr-0 rtl:md:ml-6">
              <div className="flex items-center">
                <Brain className={`h-8 w-8 ${isRTL ? 'ml-3' : 'mr-3'} text-white opacity-80`} />
                <p className="text-xl font-bold text-white">{t('dashboard.tryAiAnalysis')}</p>
              </div>
            </div>
            <div className="md:mr-6 rtl:md:mr-0 rtl:md:ml-6">
              <button 
                className="px-6 py-3 bg-white text-primary-700 rounded-lg hover:bg-primary-50 transition-colors shadow-lg flex items-center font-medium"
                onClick={() => safeNavigate('/domain/1')}
              >
                {t('dashboard.tryAiAnalysis')} <Sparkles className={`${isRTL ? 'mr-2' : 'ml-2'} h-5 w-5 text-secondary-500`} />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default CustomDashboard;