import React from 'react';
import { Layers, ArrowUp } from 'lucide-react';

interface MaturityLevelDescriptionsProps {
  currentLevel: string;
}

const MaturityLevelDescriptions: React.FC<MaturityLevelDescriptionsProps> = ({ currentLevel }) => {
  const levels = [
    {
      value: 'initial',
      label: 'Initial',
      description: 'Processes are ad-hoc and chaotic.',
      characteristics: [
        'No standardized processes',
        'Reactive approach',
        'Success depends on individual effort',
        'Limited documentation',
        'No performance metrics'
      ],
      color: 'bg-red-100 text-red-800 border-red-200'
    },
    {
      value: 'defined',
      label: 'Defined',
      description: 'Processes are documented and standardized.',
      characteristics: [
        'Documented processes',
        'Standardized templates',
        'Basic governance',
        'Defined roles and responsibilities',
        'Limited metrics'
      ],
      color: 'bg-amber-100 text-amber-800 border-amber-200'
    },
    {
      value: 'managed',
      label: 'Managed',
      description: 'Processes are measured and controlled.',
      characteristics: [
        'Quantitative objectives',
        'Performance metrics',
        'Data-driven decisions',
        'Predictable outcomes',
        'Effective controls'
      ],
      color: 'bg-green-100 text-green-800 border-green-200'
    },
    {
      value: 'optimized',
      label: 'Optimized',
      description: 'Focus on continuous improvement.',
      characteristics: [
        'Process optimization',
        'Continuous improvement',
        'Innovation integration',
        'Proactive problem solving',
        'Leading indicators'
      ],
      color: 'bg-blue-100 text-blue-800 border-blue-200'
    },
    {
      value: 'innovative',
      label: 'Innovative',
      description: 'Driving industry innovation and adaptation.',
      characteristics: [
        'Industry leadership',
        'Cutting-edge approaches',
        'Organizational agility',
        'Pioneering techniques',
        'Research & development'
      ],
      color: 'bg-purple-100 text-purple-800 border-purple-200'
    }
  ];
  
  const currentLevelIndex = levels.findIndex(level => level.value === currentLevel);
  const nextLevel = currentLevelIndex < levels.length - 1 ? levels[currentLevelIndex + 1] : null;
  
  const currentLevelObj = levels.find(level => level.value === currentLevel) || levels[0];
  
  return (
    <div className="space-y-4">
      <div className={`p-4 rounded-lg border ${currentLevelObj.color}`}>
        <div className="flex items-center mb-2">
          <Layers className="h-5 w-5 mr-2" />
          <h3 className="font-medium">Current: {currentLevelObj.label}</h3>
        </div>
        <p className="text-sm mb-2">{currentLevelObj.description}</p>
        <h4 className="text-xs font-medium mb-1">Key Characteristics:</h4>
        <ul className="text-xs space-y-1 list-disc list-inside">
          {currentLevelObj.characteristics.map((item, idx) => (
            <li key={idx}>{item}</li>
          ))}
        </ul>
      </div>
      
      {nextLevel && (
        <div>
          <div className="flex justify-center mb-2">
            <ArrowUp className="h-5 w-5 text-gray-400" />
          </div>
          
          <div className={`p-4 rounded-lg border border-gray-200 bg-white`}>
            <div className="flex items-center mb-2">
              <h3 className="font-medium text-gray-800">Next: {nextLevel.label}</h3>
            </div>
            <p className="text-sm text-gray-600 mb-1">{nextLevel.description}</p>
            <h4 className="text-xs font-medium text-gray-700 mb-1">Focus Areas:</h4>
            <ul className="text-xs space-y-1 list-disc list-inside text-gray-600">
              {nextLevel.characteristics.map((item, idx) => (
                <li key={idx}>{item}</li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};

export default MaturityLevelDescriptions;