import React, { useState, useEffect } from 'react';
import { Download, Loader2, Calendar, CreditCard, Check, ChevronDown, ChevronUp, PieChart, Edit, DollarSign, AlertTriangle } from 'lucide-react';
import ProjectPermissionsModal from './ProjectPermissionsModal';
import { Project } from '../types';
import { useLanguage } from '../contexts/LanguageContext';
import { useAppStore } from '../store';
import apiClient from '../api/client';
import { useAuth } from '../components/auth/AuthContext';
import { useToast } from '../hooks/useToast';
import ProjectDetailsCardSkeleton from './common/ProjectDetailsCardSkeleton';
import { ErrorIndicator } from './common/withSafeDataHandling';

interface ProjectDetailsCardProps {
  activeProject: Project | null;
  isLoading?: boolean;
}

const ProjectDetailsCard: React.FC<ProjectDetailsCardProps> = ({ activeProject, isLoading }) => {
  const [showPermissionsModal, setShowPermissionsModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { t, language, isRTL } = useLanguage();
  const { currentUser } = useAuth();
  const toast = useToast();
  
  // Reset export state when project changes
  useEffect(() => {
    if (activeProject) {
      setIsExporting(false);
      setError(null);
    }
  }, [activeProject]);
  
  const handleExportReport = async () => {
    if (!activeProject?.id) {
      toast.error('No active project selected');
      return;
    }

    setIsExporting(true);
    setError(null);
    
    try {
      // Make the API call using the default apiClient which already has auth headers set
      const response = await apiClient.get(`/pmo/export-project/${activeProject.id}`);
      // The X-User-Email header is now automatically added in the apiClient interceptor
  
      const { public_url, filename } = response.data || {};
  
      if (public_url) {
        const link = document.createElement("a");
        link.href = public_url;
        link.download = filename || "report.docx";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      } else {
        throw new Error('Export URL not received from server');
      }
    } catch (error: any) {
      console.error('Error exporting project report:', error);
      setError(error?.response?.data?.message || error?.message || 'Failed to export project report');
      toast.error(error?.response?.data?.message || error?.message || 'Failed to export project report');
    } finally {
      setIsExporting(false);
    }
  };
  
  // Show skeleton during loading
  if (isLoading) {
    return <ProjectDetailsCardSkeleton />;
  }
  
  if (!activeProject) {
    return (
      <div className="bg-white rounded-lg shadow-sm p-6 mb-6 flex justify-center items-center">
        <p className="text-gray-500">No active project selected</p>
      </div>
    );
  }

  if (error) {
    return (
      <ErrorIndicator 
        error={error} 
        onRetry={() => setError(null)} 
      />
    );
  }

  // Calculate days left in project
  const startDate = new Date(activeProject.startDate || Date.now());
  const endDate = new Date(activeProject.endDate || Date.now());
  const today = new Date();
  const totalDays = Math.floor((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
  const daysLeft = Math.max(0, Math.floor((endDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24)));
  const daysProgress = Math.min(100, Math.max(0, ((totalDays - daysLeft) / totalDays) * 100));
  
  // Calculate budget spent percentage
  const budgetPercentage = activeProject.budget 
    ? Math.min(100, Math.max(0, ((activeProject.budgetSpent || 0) / activeProject.budget) * 100)) 
    : 0;

  // Check if this is the default project (PMO Implementation Starter)
  const isDefaultProject = activeProject.name === "PMO Implementation Starter";
  
  // Get the project name based on the language and whether it's the default project
  const projectName = isDefaultProject && language === 'ar' 
    ? "بدء تنفيذ مكتب إدارة المشاريع" 
    : activeProject.name || 'Untitled Project';
    
  // Get the project description based on language and whether it's the default project
  const projectDescription = isDefaultProject && language === 'ar'
    ? "مرحبًا بك في مشروع تنفيذ مكتب إدارة المشاريع! يتضمن هذا المشروع البدئي أنشطة إعداد أساسية لمكتب إدارة المشاريع. الأهداف الرئيسية: • إنشاء إطار حوكمة مكتب إدارة المشاريع • تحديد منهجية إدارة المشاريع • إعداد تتبع محفظة المشاريع • إنشاء قوالب وأدوات • تخطيط تدريب الفريق وتطويره"
    : activeProject.description || 'No description provided';

  return (
    <div className="bg-white rounded-lg shadow-sm p-6 mb-6 dashboard-overview">
      <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between">
        <div>
          <div className="flex items-center">
            <h2 className="text-xl font-bold text-gray-800">{projectName}</h2>
            <div className="ms-3 px-2 py-0.5 bg-blue-100 text-blue-800 text-xs rounded-full">{t('common.active', 'Active')}</div>
          </div>
          <p className="text-gray-600 mt-1">{projectDescription}</p>
          
          <div className="flex flex-wrap items-center mt-3 gap-6">
            <div className="flex items-center text-sm text-gray-500">
              <Calendar className="h-4 w-4 me-1.5 text-gray-400" />
              <span>
                {new Date(activeProject.startDate || Date.now()).toLocaleDateString(language === 'ar' ? 'ar-SA' : undefined)} - {new Date(activeProject.endDate || Date.now()).toLocaleDateString(language === 'ar' ? 'ar-SA' : undefined)}
              </span>
            </div>
            <div className="flex items-center text-sm text-gray-500">
              <CreditCard className="h-4 w-4 me-1.5 text-gray-400" />
              <span>
                {t('dashboard.budget', 'Budget')} : ${(activeProject.budget || 0).toLocaleString()}
              </span>
            </div>
            <button 
              onClick={() => setExpanded(!expanded)}
              className="text-sm text-primary-600 flex items-center"
            >
              {expanded ? (
                <>
                  <ChevronUp className={`h-4 w-4 ${isRTL ? 'ms-1' : 'me-1'}`} />
                  {t('common.showLess', 'Show Less')}
                </>
              ) : (
                <>
                  <ChevronDown className={`h-4 w-4 ${isRTL ? 'ms-1' : 'me-1'}`} />
                  {t('common.showMore', 'Show More')}
                </>
              )}
            </button>
          </div>
        </div>
        
        <div className="flex md:items-center gap-x-3 mt-4 lg:mt-0">
          <button 
            className={`px-4 py-2 border border-neutral-200 text-neutral-700 rounded-md hover:bg-neutral-50 flex items-center ${
              isExporting ? 'opacity-50 cursor-not-allowed' : ''
            } transition-all duration-200 export-project-btn`}
            onClick={handleExportReport}
            disabled={isExporting}
          >
            {isExporting ? (
              <>
                <Loader2 className={`h-4 w-4 ${isRTL ? 'ms-2' : 'me-2'} animate-spin`} />
                <span>{t('dashboard.generating', 'Generating...')}</span>
              </>
            ) : (
              <>
                <Download className={`h-4 w-4 ${isRTL ? 'ms-2' : 'me-2'}`} />
                {t('dashboard.exportReport', 'Export Report')}
              </>
            )}
          </button>
        </div>
      </div>
      
      {expanded && (
        <div className="mt-6 pt-6 border-t border-gray-100">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-2">{t('dashboard.timelineProgress', 'Timeline Progress')}</h3>
              <div className="bg-gray-50 p-3 rounded-lg">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-xs text-gray-500">{Math.round(daysProgress)}% {t('common.Complete', 'Complete')}</span>
                  <span className="text-xs text-gray-500">{daysLeft} {t('common.daysLeft', 'days left')}</span>
                </div>
                <div className="h-2 w-full bg-gray-200 rounded-full overflow-hidden">
                  <div className="h-full bg-blue-500 rounded-full" style={{ width: `${daysProgress}%` }}></div>
                </div>
                <div className="flex justify-between items-center mt-2">
                  <span className="text-xs text-gray-500">
                    {new Date(activeProject.startDate || Date.now()).toLocaleDateString()}
                  </span>
                  <span className="text-xs text-gray-500">
                    {new Date(activeProject.endDate || Date.now()).toLocaleDateString()}
                  </span>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-2">{t('dashboard.budgetUtilization', 'Budget Utilization')}</h3>
              <div className="bg-gray-50 p-3 rounded-lg">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-xs text-gray-500">${(activeProject.budgetSpent || 0).toLocaleString()} {t('common.spent', 'Spent')}</span>
                  <span className="text-xs text-gray-500">{Math.round(budgetPercentage)}% {t('common.used', 'Used')}</span>
                </div>
                <div className="h-2 w-full bg-gray-200 rounded-full overflow-hidden">
                  <div 
                    className={`h-full rounded-full ${
                      budgetPercentage > 90 ? 'bg-red-500' : 
                      budgetPercentage > 75 ? 'bg-amber-500' : 
                      'bg-green-500'
                    }`}
                    style={{ width: `${budgetPercentage}%` }}
                  ></div>
                </div>
                <div className="flex justify-between items-center mt-2">
                  <span className="text-xs text-gray-500">$0</span>
                  <span className="text-xs text-gray-500">${(activeProject.budget || 0).toLocaleString()}</span>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-2">{t('dashboard.projectStatus', 'Project Status')}</h3>
              <div className="bg-gray-50 p-3 rounded-lg">
                <div className="flex gap-x-2">
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs text-gray-500">{t('common.tasks', 'Tasks')}</span>
                      <span className="text-xs font-medium text-green-600">72%</span>
                    </div>
                    <div className="h-2 w-full bg-gray-200 rounded-full overflow-hidden">
                      <div className="h-full bg-green-500 rounded-full" style={{ width: '72%' }}></div>
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs text-gray-500">{t('common.domains', 'Domains')}</span>
                      <span className="text-xs font-medium text-blue-600">45%</span>
                    </div>
                    <div className="h-2 w-full bg-gray-200 rounded-full overflow-hidden">
                      <div className="h-full bg-blue-500 rounded-full" style={{ width: '45%' }}></div>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center justify-between mt-4">
                  <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full flex items-center">
                    <Check className="h-3 w-3 me-1" />
                    {t('common.onTrack', 'On Track')}
                  </span>
                  <button className="text-xs text-primary-600 flex items-center">
                    <PieChart className="h-3 w-3 me-1" />
                    {t('common.viewDetails', 'View Details')}
                  </button>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-2">{t('dashboard.keyObjectives', 'Key Objectives')}</h3>
              <div className="bg-gray-50 p-3 rounded-lg">
                <ul className="space-y-2">
                  {(activeProject.keyObjectives || []).map((objective, index) => (
                    <li key={index} className="flex items-start">
                      <div className="flex-shrink-0 h-5 w-5 rounded-full bg-primary-100 flex items-center justify-center mt-0.5">
                        <span className="text-primary-600 text-xs font-bold">{index + 1}</span>
                      </div>
                      <span className="ms-2 text-sm text-gray-700">
                        {isDefaultProject && language === 'ar' && index === 0 ? 'إنشاء إطار حوكمة مكتب إدارة المشاريع' : 
                         isDefaultProject && language === 'ar' && index === 1 ? 'تطوير منهجيات قياسية' : 
                         isDefaultProject && language === 'ar' && index === 2 ? 'تنفيذ مقاييس الأداء' : objective}
                      </span>
                    </li>
                  ))}
                  {(!activeProject.keyObjectives || activeProject.keyObjectives.length === 0) && (
                    <li className="text-sm text-gray-500">No objectives defined</li>
                  )}
                </ul>
              </div>
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-2">{t('dashboard.teamMembers', 'Team Members')}</h3>
              <div className="bg-gray-50 p-3 rounded-lg flex flex-col">
                <div className="mb-2 flex justify-between items-center">
                  <span className="text-xs text-gray-500">{t('dashboard.projectOwner', 'Project Owner')}</span>
                  <button className="text-xs text-blue-600" onClick={() => setShowPermissionsModal(true)}>
                    {t('common.manage', 'Manage')}
                  </button>
                </div>
                
                <div className="flex items-center">
                  <div className="w-6 h-6 rounded-full bg-purple-500 flex items-center justify-center text-white text-xs">
                    {(activeProject.owner?.slice(0, 1) || 'U').toUpperCase()}
                  </div>
                  <span className="ms-2 text-sm text-gray-700">{activeProject.owner || 'No owner'}</span>
                </div>
                
                <div className="mt-4 mb-2">
                  <span className="text-xs text-gray-500">{t('dashboard.collaborators', 'Collaborators')}</span>
                </div>
                
                <div className="flex flex-wrap gap-1">
                  {(activeProject.members || []).length > 0 ? (
                    activeProject.members.map((member, index) => (
                      <div key={index} className="bg-gray-100 px-2 py-1 rounded-full flex items-center">
                        <div className="w-4 h-4 rounded-full bg-blue-500 flex items-center justify-center text-white text-xs">
                          {member.slice(0, 1).toUpperCase()}
                        </div>
                        <span className="ms-1 text-xs text-gray-700">{member}</span>
                      </div>
                    ))
                  ) : (
                    <span className="text-xs text-gray-500">No team members added yet</span>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Project permissions modal */}
      {showPermissionsModal && (
        <ProjectPermissionsModal 
          project={activeProject} 
          onClose={() => setShowPermissionsModal(false)} 
        />
      )}
    </div>
  );
};

export default ProjectDetailsCard;