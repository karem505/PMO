import React, { useState, useEffect } from 'react';
import { useAppStore } from '../store';
import { Domain } from '../types';
import { Save, ArrowDownCircle, ArrowRightCircle, FileText, Sparkles, AlertTriangle, CheckCircle, Loader2, ZapOff } from 'lucide-react';
import { sampleDomainInputs } from '../data/sampleDomainInputs';
import CrossDomainReference from './CrossDomainReference';
import { useAuth } from './auth/AuthContext';
import { useMediaQuery } from '../hooks/useMediaQuery';
import { useLanguage } from '../contexts/LanguageContext';
import { useToast } from '../hooks/useToast';

interface DomainInputFormProps {
  domain: Domain;
  onAnalyze: () => void;
}

const DomainInputForm: React.FC<DomainInputFormProps> = ({ domain, onAnalyze }) => {
  const { getDomainInput, updateDomainInput, getDomainOutput, getPreviousDomainId, getActiveProject, connectionError, showConnectionErrors } = useAppStore();
  const [inputContent, setInputContent] = useState('');
  const [showPreviousDomainContent, setShowPreviousDomainContent] = useState(false);
  const [showSampleData, setShowSampleData] = useState(false);
  const [savingDraft, setSavingDraft] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [inputLength, setInputLength] = useState(0);
  const [inputWarning, setInputWarning] = useState(false);
  const [isDirty, setIsDirty] = useState(false);
  const isMobile = useMediaQuery('(max-width: 768px)');
  const { t } = useLanguage();
  const { currentUser } = useAuth();
  const toast = useToast();
  
  const previousDomainId = getPreviousDomainId(domain.id);
  const previousDomainOutput = previousDomainId ? getDomainOutput(previousDomainId) : null;
  const activeProject = getActiveProject();
  
  // Update character count
  useEffect(() => {
    setInputLength(inputContent.length);
    // Added warning if input is very long (can cause slower analysis)
    setInputWarning(inputContent.length > 3000);
    // Track if content has changed since last save
    setIsDirty(true);
  }, [inputContent]);
  
  // Fetch existing input when domain changes or user switches projects
  useEffect(() => {
    const existingInput = getDomainInput(domain.id);
    if (existingInput) {
      setInputContent(existingInput.content);
      setInputLength(existingInput.content.length);
      setInputWarning(existingInput.content.length > 3000);
      setIsDirty(false); // Content matches saved content
    } else {
      setInputContent(''); // Reset input when switching domains or projects
      setInputLength(0);
      setInputWarning(false);
      setIsDirty(false);
    }
  }, [domain.id, getDomainInput, activeProject?.id]);
  
  // Auto-save draft periodically if content has changed
  useEffect(() => {
    if (isDirty && inputContent.trim().length > 0) {
      const autoSaveTimer = setTimeout(() => {
        handleSave(true); // Auto-save
      }, 10000); // 10 seconds
      
      return () => clearTimeout(autoSaveTimer);
    }
  }, [inputContent, isDirty]);
  
  const handleSave = (isAutoSave = false) => {
    if (!isDirty) return;
    
    if (!isAutoSave) {
      setSavingDraft(true);
    }
    
    // If it's an auto-save, don't show UI indicators
    updateDomainInput(domain.id, inputContent);
    
    if (!isAutoSave) {
      // Only show UI feedback for manual save
      setTimeout(() => {
        setSavingDraft(false);
        setSaveSuccess(true);
        
        // Reset success message after 2 seconds
        setTimeout(() => {
          setSaveSuccess(false);
        }, 2000);
      }, 300);
    }
    
    // Content now matches saved version
    setIsDirty(false);
  };
  
  const handleAnalyze = () => {
    if (inputContent.trim().length < 50) {
      toast.error(t('domain.provideMoreDetailedInformation', 'Please provide more detailed information (at least 50 characters) for accurate analysis.'));
      return;
    }
    
    // Log the analysis start time for performance tracking
    console.log("[Performance] Analysis requested for domain:", domain.id, "at", new Date().toISOString());
    console.log("[Performance] Input length:", inputContent.length, "characters");
    
    // Save input first
    updateDomainInput(domain.id, inputContent);
    setIsDirty(false);
    
    // Then trigger analysis
    onAnalyze();
  };
  
  const importFromPreviousDomain = () => {
    if (previousDomainOutput) {
      // Add content from previous domain analysis as input for this domain
      // But truncate it significantly for better processing performance
      const prevContent = previousDomainOutput.content;
      const truncatedContent = prevContent.length > 1000 
        ? prevContent.substring(0, 1000) + "...[content truncated for better performance]" 
        : prevContent;
      
      const newContent = inputContent + 
        `\n\n--- IMPORTED FROM PREVIOUS DOMAIN ANALYSIS ---\n\n${truncatedContent}\n\n`;
      
      setInputContent(newContent);
      setInputLength(newContent.length);
      setInputWarning(newContent.length > 3000);
      setShowPreviousDomainContent(false);
    }
  };
  
  const loadSampleData = () => {
    if (domain && domain.id && sampleDomainInputs[domain.id]) {
      // Check if sample data is long and truncate if needed for better performance
      let sampleData = sampleDomainInputs[domain.id];
      if (sampleData.length > 3000) {
        // Extract key sections instead of just truncating
        const lines = sampleData.split('\n');
        let importantLines: string[] = [];
        
        // Get heading lines
        for (let i = 0; i < lines.length; i++) {
          if (lines[i].startsWith('#')) {
            importantLines.push(lines[i]);
            // Get a few lines after each heading
            for (let j = 1; j < 4 && i + j < lines.length; j++) {
              if (lines[i + j].trim().length > 0) {
                importantLines.push(lines[i + j]);
              }
            }
          }
        }
        
        // If we got too few important lines, just take the beginning
        if (importantLines.length < 10) {
          sampleData = sampleData.substring(0, 3000) + "...[sample truncated for better performance]";
        } else {
          sampleData = importantLines.join('\n') + "\n\n[sample optimized for better performance]";
        }
      }
      
      setInputContent(sampleData);
      setInputLength(sampleData.length);
      setInputWarning(sampleData.length > 3000);
      setShowSampleData(false);
    }
  };
  
  return (
    <div className="bg-white rounded-lg shadow-sm p-4 md:p-6 mt-6 dark:bg-neutral-800 dark:border dark:border-neutral-700">
      <h2 className="text-lg font-semibold text-gray-800 mb-4 dark:text-gray-100">
        {domain && domain.id && t(`domains.${domain.id}.name`, domain.name)}
      </h2>
      <p className="text-sm text-gray-600 mb-4 dark:text-gray-300">
        {t('domain.provideInformationAboutYourOrganizationApproachToDomainName', 'Provide information about your organization\'s approach to')} {domain && domain.id && t(`domains.${domain.id}.name`, domain.name)}
        {t('domain.thisDataWillBeAnalyzedToGenerateComprehensiveRecommendationsAndCompletedTemplates', 'This data will be analyzed to generate comprehensive recommendations and completed templates.')}
      </p>
      
      {connectionError && showConnectionErrors && (
        <div className="bg-amber-50 dark:bg-amber-900/30 border border-amber-200 dark:border-amber-800 rounded-md p-4 mb-4 flex items-start">
          <AlertTriangle className="h-5 w-5 text-amber-600 dark:text-amber-500 mt-0.5 me-2 flex-shrink-0" />
          <div>
            <p className="text-sm font-medium text-amber-800 dark:text-amber-400">
              {t('domain.workingInOfflineMode', 'Working in offline mode')}
            </p>
            <p className="text-xs text-amber-700 dark:text-amber-300 mt-1">
              {t('domain.youAppearToBeWorkingOfflineOrHaveConnectionIssuesWithTheDatabase', 'You appear to be working offline or have connection issues with the database. ')}
              {t('domain.youCanContinueWorkingAndChangesWillBeSavedLocally', 'You can continue working, and changes will be saved locally.')}
            </p>
          </div>
        </div>
      )}
      
      {inputWarning && (
        <div className="bg-amber-50 dark:bg-amber-900/30 border border-amber-200 dark:border-amber-800 rounded-md p-4 mb-4 flex items-start">
          <AlertTriangle className="h-5 w-5 text-amber-600 dark:text-amber-500 mt-0.5 me-2 flex-shrink-0" />
          <div>
            <p className="text-sm font-medium text-amber-800 dark:text-amber-400">
              {t('domain.longInputDetected', 'Long input detected')}
            </p>
            <p className="text-xs text-amber-700 dark:text-amber-300 mt-1">
              {t('domain.yourInputIsQuiteLong', 'Your input is quite long ({inputLength.toLocaleString()} characters). For faster analysis, consider focusing on key information and removing less relevant details.')}
            </p>
          </div>
        </div>
      )}
      
      <div className="flex flex-wrap gap-3 mb-4">
        <button
          onClick={() => setShowSampleData(!showSampleData)}
          className="flex items-center text-blue-600 text-sm font-medium dark:text-blue-400"
        >
          <FileText className="h-4 we4 mr-2" />
          {showSampleData ? t('domain.hideSampleData', 'Hide Sample Data') : t('domain.showSampleData', 'Show Sample Data')}
        </button>
        
        {previousDomainOutput && (
          <button
            onClick={() => setShowPreviousDomainContent(!showPreviousDomainContent)}
            className="flex items-center text-blue-600 text-sm font-medium dark:text-blue-400"
          >
            <ArrowRightCircle className="h-4 we4 mr-2" />
            {showPreviousDomainContent ? t('domain.hidePreviousDomainOutput', 'Hide') : t('domain.showPreviousDomainOutput', 'Show')} previous domain output
          </button>
        )}
      </div>
      
      {showSampleData && domain && domain.id && sampleDomainInputs[domain.id] && (
        <div className="mt-3 p-4 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-100 dark:border-green-800 mb-4">
          <div className="flex justify-between items-center mb-2">
            <h3 className="text-sm font-medium text-green-800 dark:text-green-400">{t('domain.sampleInputData', 'Sample Input Data')}</h3>
            <button
              className="text-xs bg-green-600 text-white dark:bg-green-700 px-2 py-1 rounded flex items-center"
              onClick={loadSampleData}
            >
              <Sparkles className="h-3 w-3 mr-1" />
              {t('domain.useSampleData', 'Use Sample Data')}
            </button>
          </div>
          <div className="text-sm text-gray-700 dark:text-gray-300 max-h-60 overflow-y-auto">
            <p className="whitespace-pre-line">{sampleDomainInputs[domain.id].substring(0, 300)}...</p>
          </div>
        </div>
      )}
      
      {previousDomainOutput && showPreviousDomainContent && (
        <div className="mt-3 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-100 dark:border-blue-800 mb-4">
          <div className="flex justify-between items-center mb-2">
            <h3 className="text-sm font-medium text-blue-800 dark:text-blue-400">Previous Domain Analysis</h3>
            <button
              className="text-xs bg-blue-600 text-white dark:bg-blue-700 px-2 py-1 rounded flex items-center"
              onClick={importFromPreviousDomain}
            >
              <ArrowDownCircle className="h-3 w-3 mr-1" />
              Import as Input
            </button>
          </div>
          <div className="text-sm text-gray-700 dark:text-gray-300 max-h-60 overflow-y-auto">
            <p className="whitespace-pre-line">{previousDomainOutput.content.substring(0, 300)}...</p>
          </div>
        </div>
      )}
      
      <div className="mb-2">
        <textarea
          className="w-full h-60 p-4 border border-gray-300 dark:border-neutral-600 rounded-lg focus:ring-blue-500 focus:border-blue-500 dark:bg-neutral-900 dark:text-white transition-colors"
          placeholder={`${t('domain.enterInformationAboutYourOrganizationPractices', 'Enter information about your organization\'s')} ${t(`domains.${domain.id}.name`, domain.name)} ${t('domain.practices', 'practices...')}`}
          value={inputContent}
          onChange={(e) => setInputContent(e.target.value)}
          spellCheck
        ></textarea>
        <div className="flex justify-end mt-1">
          <span className={`text-xs ${inputWarning ? 'text-amber-600 dark:text-amber-400 font-medium' : 'text-gray-500 dark:text-gray-400'}`}>
            {inputLength.toLocaleString()} {t('domain.characters', 'characters')} {inputWarning && t('domain.shorterInputsAreAnalyzedFaster', '(shorter inputs are analyzed faster)')}
          </span>
        </div>
      </div>
      
      {/* Cross-Domain References Component */}
      <CrossDomainReference 
        domainId={domain.id}
        keyword={inputContent.substring(0, 100)}
      />
      
      <div className="flex flex-wrap justify-end gap-3 mt-4">
        <button
          className={`px-4 py-2 border border-gray-300 dark:border-neutral-600 rounded-md text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-neutral-700 flex items-center transition-colors ${
            savingDraft ? 'opacity-75 cursor-not-allowed' : saveSuccess ? 'border-green-300 bg-green-50 text-green-700 dark:border-green-800 dark:bg-green-900/30 dark:text-green-300' : isDirty ? 'border-blue-200 bg-blue-50 dark:border-blue-800 dark:bg-blue-900/20' : ''
          }`}
          onClick={() => handleSave(false)}
          disabled={savingDraft || !isDirty}
        >
          {savingDraft ? (
            <>
              <Loader2 className="h-4 w-4 mr-2eanimate-spin" />
              {t('domain.saving', 'Saving...')}
            </>
          ) : saveSuccess ? (
            <>
              <CheckCircle className="h-4 w-4 me-2 text-green-600 dark:text-green-400" />
              {t('domain.saved', 'Saved!')}
            </>
          ) : (
            <>
              <Save className="h-4 we4 mr-2" />
              {isDirty ? t('domain.saveDraft', 'Save Draft') : t('domain.saved', 'Saved')}
            </>
          )}
        </button>
        {connectionError ? (
          <div className="px-4 py-2 bg-amber-100 dark:bg-amber-900/40 text-amber-800 dark:text-amber-300 rounded-md flex items-center">
            <ZapOff className="h-4 w-4 mr-1.5" />
            {t('domain.offlineMode', 'Offline Mode')} - {t('domain.analysisLimited', 'Analysis Limited')}
          </div>
        ) : (
          <button
            className={`px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center dark:bg-blue-700 dark:hover:bg-blue-800 ${
              inputContent.trim().length < 50 ? 'opacity-60 cursor-not-allowed' : ''
            }`}
            onClick={handleAnalyze}
            disabled={inputContent.trim().length < 50}
          >
            <>
              {isMobile ? t('domain.aiAnalysis', 'AI Analysis') : t('domain.quickAnalysisWithOpenAI', 'Quick Analysis with OpenAI')}
              <Sparkles className="ms-1.5 h-4 w-4" />
            </>
          </button>
        )}
      </div>
      
      <p className="text-xs text-gray-500 dark:text-gray-400 mt-3">
        {t('domain.analysisTypicallyTakes2040SecondsToCompleteDependingOnInputLength', 'Analysis typically takes 20-40 seconds to complete depending on input length.')}
      </p>
    </div>
  );
};

export default DomainInputForm;