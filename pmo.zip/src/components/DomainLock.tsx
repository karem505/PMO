import React from 'react';
import { Lock } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';

interface DomainLockProps {
  domainName: string;
}

const DomainLock: React.FC<DomainLockProps> = ({ domainName }) => {
  const navigate = useNavigate();
  const { t } = useLanguage();
  
  const handleUpgradeClick = (e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent parent click from triggering
    navigate('/pricing');
  };
  
  return (
    <div className="absolute inset-0 bg-gray-900/60 backdrop-blur-[2px] flex flex-col items-center justify-center z-10 rounded-lg">
      <div className="p-2 rounded-full bg-white/10 mb-2">
        <Lock className="h-6 w-6 text-white" />
      </div>
      <h3 className="text-white text-lg font-semibold text-center px-3 mb-1">
        {domainName}
      </h3>
      <p className="text-white/80 text-center text-xs mb-3 px-4">
        {t('subscription.thisDomainAvailable', 'This domain is available on Premium plans')}
      </p>
      <button 
        onClick={handleUpgradeClick}
        className="px-4 py-1.5 bg-primary-600 dark:bg-primary-500 text-white text-sm rounded-md font-medium hover:bg-primary-700 dark:hover:bg-primary-400 transition-colors"
      >
        {t('subscription.upgradeToUnlock', 'Upgrade to Unlock')}
      </button>
    </div>
  );
};

export default DomainLock; 