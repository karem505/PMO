import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { Globe } from 'lucide-react';

interface LanguageSwitcherProps {
  minimal?: boolean;
}

const LanguageSwitcher: React.FC<LanguageSwitcherProps> = ({ minimal = false }) => {
  const { language, setLanguage, t, isRTL } = useLanguage();

  const toggleLanguage = () => {
    setLanguage(language === 'en' ? 'ar' : 'en');
  };

  if (minimal) {
    return (
      <div style={{ direction: 'ltr' }}>
        <button 
          className="p-2 rounded-full hover:bg-primary-50 dark:hover:bg-primary-900/20 transition-colors"
          onClick={toggleLanguage}
          aria-label={language === 'en' ? 'Switch to Arabic' : 'Switch to English'}
        >
          <Globe className="h-5 w-5 text-neutral-600 dark:text-neutral-300" />
        </button>
      </div>
    );
  }

  // Fix for RTL toggle - force LTR display for the toggle container regardless of page direction
  return (
    <div className="relative" style={{ direction: 'ltr' }}>
      <div className="flex items-center" style={{ direction: 'ltr' }}>
        <button
          className={`px-3 py-1.5 rounded-md text-sm font-medium ${
            language === 'en'
              ? 'bg-primary-100 text-primary-700 dark:bg-primary-900/50 dark:text-primary-300'
              : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'
          } mr-2`}
          onClick={() => setLanguage('en')}
        >
          English
        </button>
        <button
          className={`px-3 py-1.5 rounded-md text-sm font-medium ${
            language === 'ar'
              ? 'bg-primary-100 text-primary-700 dark:bg-primary-900/50 dark:text-primary-300'
              : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'
          }`}
          onClick={() => setLanguage('ar')}
        >
          العربية
        </button>
      </div>
    </div>
  );
};

export default LanguageSwitcher;