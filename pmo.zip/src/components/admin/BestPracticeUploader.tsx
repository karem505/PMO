import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../auth/AuthContext';
import { 
  Upload, 
  Save, 
  FileText, 
  Tag, 
  Loader2, 
  CheckCircle, 
  AlertTriangle, 
  Trash2, 
  File, 
  X, 
  Eye, 
  Plus,
  BookOpen,
  Filter,
  Search
} from 'lucide-react';
import { supabase } from '../../services/supabaseClient';
import { useNavigate } from 'react-router-dom';
import ReactMarkdown from 'react-markdown';

interface Category {
  id: string;
  name: string;
  icon: string;
  color: string;
  description?: string;
}

interface BestPracticeTag {
  id: string;
  name: string;
  description?: string;
}

interface BestPracticeDocument {
  id?: string;
  title: string;
  summary?: string;
  content: string;
  category_id?: string;
  document_type: string;
  format: string;
  status: string;
  featured: boolean;
  tags: string[];
  is_public: boolean;
}

const documentTypes = [
  { value: 'template', label: 'Template' },
  { value: 'guide', label: 'Guide' },
  { value: 'checklist', label: 'Checklist' },
  { value: 'whitepaper', label: 'White Paper' },
  { value: 'case-study', label: 'Case Study' },
  { value: 'standard', label: 'Standard' },
  { value: 'reference', label: 'Reference' },
  { value: 'tool', label: 'Tool' }
];

const BestPracticeUploader: React.FC = () => {
  const { hasRole } = useAuth();
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // States for UI
  const [activeTab, setActiveTab] = useState<'upload' | 'manage'>('manage');
  const [isLoading, setIsLoading] = useState(false);
  const [categories, setCategories] = useState<Category[]>([]);
  const [tags, setTags] = useState<BestPracticeTag[]>([]);
  const [documents, setDocuments] = useState<BestPracticeDocument[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  
  // States for document form
  const [formData, setFormData] = useState<BestPracticeDocument>({
    title: '',
    summary: '',
    content: '',
    document_type: 'guide',
    format: 'markdown',
    status: 'draft',
    featured: false,
    tags: [],
    is_public: true
  });
  
  // Preview state
  const [showPreview, setShowPreview] = useState(false);
  
  // Edit state
  const [editingDocumentId, setEditingDocumentId] = useState<string | null>(null);
  
  // Filters for document list
  const [filterCategory, setFilterCategory] = useState<string>('');
  const [filterType, setFilterType] = useState<string>('');
  const [searchTerm, setSearchTerm] = useState<string>('');
  
  // Pagination
  const [page, setPage] = useState(1);
  const pageSize = 10;
  
  // Check if user is admin
  useEffect(() => {
    if (!hasRole('admin')) {
      navigate('/dashboard');
    }
  }, [hasRole, navigate]);
  
  // Load categories, tags, and documents
  useEffect(() => {
    loadCategories();
    loadTags();
    loadDocuments();
  }, [filterCategory, filterType, searchTerm, page]);
  
  const loadCategories = async () => {
    try {
      const { data, error } = await supabase
        .from('best_practice_categories')
        .select('*')
        .order('display_order', { ascending: true });
        
      if (error) throw error;
      if (data) setCategories(data);
    } catch (error) {
      console.error('Error loading categories:', error);
      setError('Failed to load categories');
    }
  };
  
  const loadTags = async () => {
    try {
      const { data, error } = await supabase
        .from('best_practice_tags')
        .select('*')
        .order('name', { ascending: true });
        
      if (error) throw error;
      if (data) setTags(data);
    } catch (error) {
      console.error('Error loading tags:', error);
      setError('Failed to load tags');
    }
  };
  
  const loadDocuments = async () => {
    setIsLoading(true);
    try {
      let query = supabase
        .from('best_practice_documents')
        .select(`
          *,
          category:category_id(name, icon, color),
          document_tags:best_practice_document_tags(tag_id)
        `)
        .order('updated_at', { ascending: false })
        .range((page - 1) * pageSize, page * pageSize - 1);
      
      // Apply filters
      if (filterCategory) {
        query = query.eq('category_id', filterCategory);
      }
      
      if (filterType) {
        query = query.eq('document_type', filterType);
      }
      
      if (searchTerm) {
        query = query.or(`title.ilike.%${searchTerm}%,summary.ilike.%${searchTerm}%,content.ilike.%${searchTerm}%`);
      }
        
      const { data, error } = await query;
        
      if (error) throw error;
      
      if (data) {
        // Process document tags into simple array of tag IDs
        const processedDocs = data.map(doc => {
          const tagIds = doc.document_tags 
            ? doc.document_tags.map((t: any) => t.tag_id)
            : [];
            
          return {
            ...doc,
            tags: tagIds
          };
        });
        
        setDocuments(processedDocs);
      }
    } catch (error) {
      console.error('Error loading documents:', error);
      setError('Failed to load documents');
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    setError(null);
    const files = e.target.files;
    if (!files || files.length === 0) return;
    
    const file = files[0];
    
    // Check file size (10MB limit)
    if (file.size > 10 * 1024 * 1024) {
      setError('File too large. Maximum size is 10MB.');
      return;
    }
    
    // Read file based on type
    if (file.type === 'application/pdf') {
      setError('PDF files are not supported for direct content extraction. Please paste the content manually.');
      return;
    }
    
    // Read text-based files
    const reader = new FileReader();
    reader.onload = (e) => {
      if (e.target?.result) {
        // Update form with file content
        setFormData(prev => ({
          ...prev,
          title: file.name.replace(/\.[^/.]+$/, ""), // Remove file extension
          content: e.target?.result as string,
          format: getFormatFromFileName(file.name)
        }));
        
        setSuccess('File uploaded successfully. Please review and save.');
        
        // Clear success message after 3 seconds
        setTimeout(() => setSuccess(null), 3000);
      }
    };
    reader.onerror = () => {
      setError('Error reading file. Please try again or paste content manually.');
    };
    
    reader.readAsText(file);
  };
  
  const getFormatFromFileName = (fileName: string): string => {
    const ext = fileName.split('.').pop()?.toLowerCase() || '';
    
    if (ext === 'md') return 'markdown';
    if (ext === 'html' || ext === 'htm') return 'html';
    if (ext === 'txt') return 'plaintext';
    
    return 'markdown'; // Default
  };
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    
    if (type === 'checkbox') {
      const target = e.target as HTMLInputElement;
      setFormData(prev => ({
        ...prev,
        [name]: target.checked
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: value
      }));
    }
  };
  
  const handleTagChange = (tagId: string, checked: boolean) => {
    setFormData(prev => {
      if (checked) {
        return {
          ...prev,
          tags: [...prev.tags, tagId]
        };
      } else {
        return {
          ...prev,
          tags: prev.tags.filter(id => id !== tagId)
        };
      }
    });
  };
  
  const resetForm = () => {
    setFormData({
      title: '',
      summary: '',
      content: '',
      document_type: 'guide',
      format: 'markdown',
      status: 'draft',
      featured: false,
      tags: [],
      is_public: true
    });
    setEditingDocumentId(null);
    setShowPreview(false);
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    
    // Validate form
    if (!formData.title) {
      setError('Title is required');
      return;
    }
    
    if (!formData.content || formData.content.length < 10) {
      setError('Content is too short');
      return;
    }
    
    // Set loading
    setIsLoading(true);
    setUploadProgress(0);
    
    try {
      // Simulate progress
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => Math.min(prev + 10, 90));
      }, 200);
      
      let documentId: string | undefined = editingDocumentId || undefined;
      
      // Insert or update document
      if (editingDocumentId) {
        // Update existing document
        const { error } = await supabase
          .from('best_practice_documents')
          .update({
            title: formData.title,
            summary: formData.summary,
            content: formData.content,
            category_id: formData.category_id,
            document_type: formData.document_type,
            format: formData.format,
            status: formData.status,
            featured: formData.featured,
            is_public: formData.is_public,
            updated_at: new Date().toISOString()
          })
          .eq('id', editingDocumentId);
          
        if (error) throw error;
      } else {
        // Insert new document
        const { data, error } = await supabase
          .from('best_practice_documents')
          .insert({
            title: formData.title,
            summary: formData.summary,
            content: formData.content,
            category_id: formData.category_id,
            document_type: formData.document_type,
            format: formData.format,
            status: formData.status,
            featured: formData.featured,
            is_public: formData.is_public
          })
          .select('id')
          .single();
          
        if (error) throw error;
        documentId = data.id;
      }
      
      // Handle tags if document was created/updated successfully
      if (documentId) {
        // First, delete existing tag associations if editing
        if (editingDocumentId) {
          await supabase
            .from('best_practice_document_tags')
            .delete()
            .eq('document_id', documentId);
        }
        
        // Then insert new tag associations
        if (formData.tags.length > 0) {
          const tagInserts = formData.tags.map(tagId => ({
            document_id: documentId,
            tag_id: tagId
          }));
          
          const { error: tagError } = await supabase
            .from('best_practice_document_tags')
            .insert(tagInserts);
            
          if (tagError) throw tagError;
        }
      }
      
      clearInterval(progressInterval);
      setUploadProgress(100);
      
      // Show success message and reset form
      setSuccess(editingDocumentId 
        ? 'Document updated successfully' 
        : 'Document uploaded successfully');
      
      // Reload documents
      loadDocuments();
      
      // Clear the form if adding new document
      if (!editingDocumentId) {
        resetForm();
      }
      
      // Switch to manage tab
      setActiveTab('manage');
      
      // Clear success message after 3 seconds
      setTimeout(() => {
        setSuccess(null);
      }, 3000);
    } catch (error) {
      console.error('Error saving document:', error);
      setError('Failed to save document: ' + (error instanceof Error ? error.message : String(error)));
    } finally {
      setIsLoading(false);
      setUploadProgress(0);
    }
  };
  
  const handleEdit = (document: BestPracticeDocument) => {
    setFormData({
      title: document.title,
      summary: document.summary || '',
      content: document.content,
      category_id: document.category_id,
      document_type: document.document_type,
      format: document.format || 'markdown',
      status: document.status || 'published',
      featured: document.featured || false,
      tags: document.tags || [],
      is_public: document.is_public
    });
    
    setEditingDocumentId(document.id);
    setActiveTab('upload');
    setShowPreview(false);
  };
  
  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this document? This action cannot be undone.')) {
      try {
        const { error } = await supabase
          .from('best_practice_documents')
          .delete()
          .eq('id', id);
          
        if (error) throw error;
        
        setSuccess('Document deleted successfully');
        
        // Reload documents
        loadDocuments();
        
        // Clear success message after 3 seconds
        setTimeout(() => {
          setSuccess(null);
        }, 3000);
      } catch (error) {
        console.error('Error deleting document:', error);
        setError('Failed to delete document');
      }
    }
  };
  
  const formatDate = (dateString: string) => {
    if (!dateString) return 'N/A';
    
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
  };
  
  return (
    <div className="max-w-5xl mx-auto pb-12">
      <h1 className="text-2xl font-bold  mb-6 flex items-center">
        <BookOpen className="mr-3 text-blue-600" />
        Best Practice Document Management
      </h1>
      
      {error && (
        <div className="mb-6 p-3 bg-red-50 text-red-800 rounded-md flex items-start">
          <AlertTriangle className="h-5 w-5 text-red-500 mt-0.5 mr-2" />
          <p>{error}</p>
        </div>
      )}
      
      {success && (
        <div className="mb-6 p-3 bg-green-50 text-green-800 rounded-md flex items-start">
          <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 mr-2" />
          <p>{success}</p>
        </div>
      )}
      
      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="flex border-b border-gray-200">
          <button
            className={`px-4 py-3 text-sm font-medium ${
              activeTab === 'upload'
                ? 'border-b-2 border-blue-500 text-blue-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
            onClick={() => setActiveTab('upload')}
          >
            <Upload className="h-4 w-4 inline mr-2" />
            {editingDocumentId ? 'Edit Document' : 'Upload New Document'}
          </button>
          <button
            className={`px-4 py-3 text-sm font-medium ${
              activeTab === 'manage'
                ? 'border-b-2 border-blue-500 text-blue-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
            onClick={() => setActiveTab('manage')}
          >
            <FileText className="h-4 w-4 inline mr-2" />
            Manage Documents
          </button>
        </div>
        
        <div className="p-6">
          {activeTab === 'upload' ? (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-lg font-medium text-gray-900">
                  {editingDocumentId ? 'Edit Document' : 'Upload New Best Practice Document'}
                </h2>
                <div className="flex space-x-3">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="px-3 py-1.5 text-sm border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50"
                    disabled={isLoading}
                  >
                    <Upload className="h-4 w-4 inline mr-1.5" />
                    Upload File
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowPreview(!showPreview)}
                    className="px-3 py-1.5 text-sm border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50"
                  >
                    <Eye className="h-4 w-4 inline mr-1.5" />
                    {showPreview ? 'Hide Preview' : 'Show Preview'}
                  </button>
                </div>
                <input
                  type="file"
                  ref={fileInputRef}
                  className="hidden"
                  accept=".md,.txt,.html"
                  onChange={handleFileUpload}
                />
              </div>
              
              {showPreview ? (
                <div className="bg-gray-50 border border-gray-200 rounded-lg p-6">
                  <h3 className="text-xl font-bold mb-4">{formData.title || 'Document Preview'}</h3>
                  {formData.summary && (
                    <p className="text-gray-600 mb-4 italic">{formData.summary}</p>
                  )}
                  <div className="prose max-w-none">
                    <ReactMarkdown>{formData.content}</ReactMarkdown>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                        Title *
                      </label>
                      <input
                        type="text"
                        id="title"
                        name="title"
                        value={formData.title}
                        onChange={handleInputChange}
                        className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                        required
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="category_id" className="block text-sm font-medium text-gray-700 mb-1">
                        Category
                      </label>
                      <select
                        id="category_id"
                        name="category_id"
                        value={formData.category_id || ''}
                        onChange={handleInputChange}
                        className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                      >
                        <option value="">Select a category</option>
                        {categories.map((category) => (
                          <option key={category.id} value={category.id}>
                            {category.name}
                          </option>
                        ))}
                      </select>
                    </div>
                    
                    <div>
                      <label htmlFor="document_type" className="block text-sm font-medium text-gray-700 mb-1">
                        Document Type *
                      </label>
                      <select
                        id="document_type"
                        name="document_type"
                        value={formData.document_type}
                        onChange={handleInputChange}
                        className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                        required
                      >
                        {documentTypes.map((type) => (
                          <option key={type.value} value={type.value}>
                            {type.label}
                          </option>
                        ))}
                      </select>
                    </div>
                    
                    <div>
                      <label htmlFor="format" className="block text-sm font-medium text-gray-700 mb-1">
                        Format
                      </label>
                      <select
                        id="format"
                        name="format"
                        value={formData.format}
                        onChange={handleInputChange}
                        className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                      >
                        <option value="markdown">Markdown</option>
                        <option value="html">HTML</option>
                        <option value="plaintext">Plain Text</option>
                      </select>
                    </div>
                    
                    <div>
                      <label htmlFor="status" className="block text-sm font-medium text-gray-700 mb-1">
                        Status
                      </label>
                      <select
                        id="status"
                        name="status"
                        value={formData.status}
                        onChange={handleInputChange}
                        className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                      >
                        <option value="draft">Draft</option>
                        <option value="published">Published</option>
                        <option value="archived">Archived</option>
                      </select>
                    </div>
                    
                    <div>
                      <label htmlFor="summary" className="block text-sm font-medium text-gray-700 mb-1">
                        Summary
                      </label>
                      <input
                        type="text"
                        id="summary"
                        name="summary"
                        value={formData.summary}
                        onChange={handleInputChange}
                        className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                      />
                    </div>
                    
                    <div className="md:col-span-2 flex items-center space-x-6">
                      <div className="flex items-center">
                        <input
                          type="checkbox"
                          id="featured"
                          name="featured"
                          checked={formData.featured}
                          onChange={(e) => setFormData(prev => ({ ...prev, featured: e.target.checked }))}
                          className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                        />
                        <label htmlFor="featured" className="ml-2 block text-sm text-gray-900">
                          Featured Document
                        </label>
                      </div>
                      
                      <div className="flex items-center">
                        <input
                          type="checkbox"
                          id="is_public"
                          name="is_public"
                          checked={formData.is_public}
                          onChange={(e) => setFormData(prev => ({ ...prev, is_public: e.target.checked }))}
                          className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                        />
                        <label htmlFor="is_public" className="ml-2 block text-sm text-gray-900">
                          Publicly Visible
                        </label>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <label htmlFor="content" className="block text-sm font-medium text-gray-700 mb-1">
                      Content *
                    </label>
                    <textarea
                      id="content"
                      name="content"
                      value={formData.content}
                      onChange={handleInputChange}
                      rows={15}
                      className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm font-mono"
                      required
                    />
                    <p className="mt-1 text-xs text-gray-500">
                      {formData.format === 'markdown' ? 'Markdown formatting is supported.' : 
                       formData.format === 'html' ? 'HTML formatting is supported.' : 
                       'Plain text only.'}
                    </p>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Tags
                    </label>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                      {tags.map((tag) => (
                        <div key={tag.id} className="flex items-center">
                          <input
                            type="checkbox"
                            id={`tag-${tag.id}`}
                            checked={formData.tags.includes(tag.id)}
                            onChange={(e) => handleTagChange(tag.id, e.target.checked)}
                            className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                          />
                          <label htmlFor={`tag-${tag.id}`} className="ml-2 block text-sm text-gray-900">
                            {tag.name}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  {isLoading && uploadProgress > 0 && (
                    <div className="mt-4">
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div 
                          className="bg-blue-600 h-2.5 rounded-full" 
                          style={{ width: `${uploadProgress}%` }}
                        ></div>
                      </div>
                      <p className="mt-1 text-sm text-gray-500 text-right">{uploadProgress}%</p>
                    </div>
                  )}
                  
                  <div className="flex justify-end space-x-3">
                    <button
                      type="button"
                      onClick={() => {
                        resetForm();
                        setActiveTab('manage');
                      }}
                      className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={isLoading}
                      className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 flex items-center"
                    >
                      {isLoading ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-1.5 animate-spin" />
                          {editingDocumentId ? 'Saving...' : 'Uploading...'}
                        </>
                      ) : (
                        <>
                          <Save className="h-4 w-4 mr-1.5" />
                          {editingDocumentId ? 'Update Document' : 'Save Document'}
                        </>
                      )}
                    </button>
                  </div>
                </form>
              )}
            </div>
          ) : (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-lg font-medium text-gray-900">Manage Best Practice Documents</h2>
                <button
                  onClick={() => {
                    resetForm();
                    setActiveTab('upload');
                  }}
                  className="px-3 py-1.5 text-sm bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center"
                >
                  <Plus className="h-4 w-4 mr-1.5" />
                  Add New Document
                </button>
              </div>
              
              {/* Filters */}
              <div className="flex flex-col md:flex-row md:items-center space-y-3 md:space-y-0 md:space-x-4">
                <div className="relative flex-1">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search className="h-4 w-4 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    placeholder="Search documents..."
                    className="pl-10 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                
                <div className="flex space-x-3">
                  <select
                    value={filterCategory}
                    onChange={(e) => setFilterCategory(e.target.value)}
                    className="block rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                    aria-label="Filter by category"
                  >
                    <option value="">All Categories</option>
                    {categories.map((category) => (
                      <option key={category.id} value={category.id}>
                        {category.name}
                      </option>
                    ))}
                  </select>
                  
                  <select
                    value={filterType}
                    onChange={(e) => setFilterType(e.target.value)}
                    className="block rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                    aria-label="Filter by type"
                  >
                    <option value="">All Types</option>
                    {documentTypes.map((type) => (
                      <option key={type.value} value={type.value}>
                        {type.label}
                      </option>
                    ))}
                  </select>
                  
                  <button
                    onClick={() => {
                      setFilterCategory('');
                      setFilterType('');
                      setSearchTerm('');
                    }}
                    className="px-3 py-1.5 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 flex items-center text-sm"
                  >
                    <Filter className="h-4 w-4 mr-1.5" />
                    Reset
                  </button>
                </div>
              </div>
              
              {/* Document list */}
              {isLoading ? (
                <div className="flex justify-center items-center py-12">
                  <Loader2 className="h-8 w-8 text-blue-500 animate-spin" />
                </div>
              ) : documents.length === 0 ? (
                <div className="text-center py-12 bg-gray-50 rounded-lg border border-gray-200">
                  <FileText className="h-12 w-12 text-gray-400 mx-auto mb-3" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No documents found</h3>
                  <p className="text-gray-500 mb-4">
                    {searchTerm || filterCategory || filterType 
                      ? 'No documents match your search criteria. Try different filters.' 
                      : 'Get started by adding a new best practice document.'}
                  </p>
                  <button
                    onClick={() => {
                      resetForm();
                      setActiveTab('upload');
                    }}
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 inline-flex items-center text-sm"
                  >
                    <Plus className="h-4 w-4 mr-1.5" />
                    Add Document
                  </button>
                </div>
              ) : (
                <div className="overflow-hidden border border-gray-200 rounded-lg">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Document
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Category
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Type
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Status
                        </th>
                        <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Actions
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {documents.map((document) => (
                        <tr key={document.id}>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              <div className="flex-shrink-0">
                                {document.featured ? (
                                  <div className="h-10 w-10 rounded-full bg-yellow-100 flex items-center justify-center">
                                    <Star className="h-6 w-6 text-yellow-600" />
                                  </div>
                                ) : (
                                  <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                                    <File className="h-6 w-6 text-blue-600" />
                                  </div>
                                )}
                              </div>
                              <div className="ml-4">
                                <div className="text-sm font-medium text-gray-900">
                                  {document.title}
                                  {document.featured && (
                                    <span className="ml-2 px-2 py-0.5 text-xs bg-yellow-100 text-yellow-800 rounded-full">
                                      Featured
                                    </span>
                                  )}
                                </div>
                                {document.summary && (
                                  <div className="text-xs text-gray-500">{document.summary}</div>
                                )}
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            {document.category ? (
                              <span className="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                                {(document.category as any).name}
                              </span>
                            ) : (
                              <span className="text-gray-500 text-sm">—</span>
                            )}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-purple-100 text-purple-800">
                              {document.document_type}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                              document.status === 'published' ? 'bg-green-100 text-green-800' :
                              document.status === 'draft' ? 'bg-yellow-100 text-yellow-800' :
                              'bg-gray-100 text-gray-800'
                            }`}>
                              {document.status}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <div className="flex justify-end space-x-2">
                              <button
                                onClick={() => handleEdit(document)}
                                className="text-blue-600 hover:text-blue-900"
                              >
                                Edit
                              </button>
                              <button
                                onClick={() => handleDelete(document.id!)}
                                className="text-red-600 hover:text-red-900"
                              >
                                Delete
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
              
              {/* Pagination */}
              <div className="flex items-center justify-between border-t border-gray-200 px-4 py-3 sm:px-6">
                <div className="flex items-center">
                  <p className="text-sm text-gray-700">
                    Showing <span className="font-medium">{documents.length}</span> results
                  </p>
                </div>
                <div className="flex justify-between">
                  <button
                    onClick={() => setPage(page > 1 ? page - 1 : page)}
                    disabled={page === 1}
                    className="relative inline-flex items-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Previous
                  </button>
                  <div className="mx-2 flex items-center">
                    <span className="text-gray-700">{page}</span>
                  </div>
                  <button
                    onClick={() => setPage(page + 1)}
                    disabled={documents.length < pageSize}
                    className="relative ml-3 inline-flex items-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Next
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// Star icon component
const Star = ({ className }: { className?: string }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2"
    strokeLinecap="round" 
    strokeLinejoin="round"
    className={className}
  >
    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
  </svg>
);

export default BestPracticeUploader;