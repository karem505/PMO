import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { Home, CheckSquare, BarChart, BookOpen, Settings } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useNavigationGuard } from '../hooks/useNavigationGuard';

const MobileNav: React.FC = () => {
  const { t, isRTL } = useLanguage();
  const { navigate } = useNavigationGuard();
  const location = useLocation();
  
  // Check if the current route matches
  const isActive = (path: string) => {
    return location.pathname === path;
  };
  
  // Safe navigation handler
  const handleNavigation = (path: string) => {
    navigate(path);
  };
  
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-neutral-800 border-t border-gray-200 dark:border-neutral-700 px-2 py-2 z-40">
      <div className="flex justify-around items-center">
        <button 
          onClick={() => handleNavigation('/dashboard')}
          className={`flex flex-col items-center px-3 py-2 rounded-lg ${
            isActive('/dashboard') ? 'text-primary-600 dark:text-primary-400' : 'text-gray-600 dark:text-gray-400'
          }`}
        >
          <Home className="h-6 w-6" />
          <span className="text-xs mt-1">{t('sidebar.dashboard', 'Dashboard')}</span>
        </button>
        
        <button 
          onClick={() => handleNavigation('/tasks')}
          className={`flex flex-col items-center px-3 py-2 rounded-lg ${
            isActive('/tasks') ? 'text-primary-600 dark:text-primary-400' : 'text-gray-600 dark:text-gray-400'
          }`}
        >
          <CheckSquare className="h-6 w-6" />
          <span className="text-xs mt-1">{t('sidebar.tasks', 'Tasks')}</span>
        </button>
        
        <button 
          onClick={() => handleNavigation('/maturity-assessment')}
          className={`flex flex-col items-center px-3 py-2 rounded-lg ${
            isActive('/maturity-assessment') ? 'text-primary-600 dark:text-primary-400' : 'text-gray-600 dark:text-gray-400'
          }`}
        >
          <BarChart className="h-6 w-6" />
          <span className="text-xs mt-1">{t('sidebar.maturityAssessment', 'Assessment')}</span>
        </button>
        
        <button 
          onClick={() => handleNavigation('/resources')}
          className={`flex flex-col items-center px-3 py-2 rounded-lg ${
            isActive('/resources') ? 'text-primary-600 dark:text-primary-400' : 'text-gray-600 dark:text-gray-400'
          }`}
        >
          <BookOpen className="h-6 w-6" />
          <span className="text-xs mt-1">{t('common.resources', 'Project Assets')}</span>
        </button>
        
        <button 
          onClick={() => handleNavigation('/settings')}
          className={`flex flex-col items-center px-3 py-2 rounded-lg ${
            isActive('/settings') ? 'text-primary-600 dark:text-primary-400' : 'text-gray-600 dark:text-gray-400'
          }`}
        >
          <Settings className="h-6 w-6" />
          <span className="text-xs mt-1">{t('sidebar.settings', 'Settings')}</span>
        </button>
      </div>
    </div>
  );
};

export default MobileNav;