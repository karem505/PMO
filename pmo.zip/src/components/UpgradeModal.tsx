import React from 'react';
import { useNavigate } from 'react-router-dom';
import { X, Zap, ArrowRight, ShieldCheck, Users, Check } from 'lucide-react';
import { SubscriptionTier, TIER_FEATURES } from '../services/subscriptionService';

interface UpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  feature?: string;
  reason?: string;
  currentTier: SubscriptionTier;
}

const UpgradeModal: React.FC<UpgradeModalProps> = ({ 
  isOpen, 
  onClose, 
  feature, 
  reason, 
  currentTier 
}) => {
  const navigate = useNavigate();

  if (!isOpen) return null;

  // Determine the target tier to upgrade to
  const targetTier = currentTier === SubscriptionTier.FREE 
    ? SubscriptionTier.PREMIUM 
    : SubscriptionTier.ENTERPRISE;
  
  const handleUpgrade = () => {
    navigate(`/pricing?utm_source=upgrade_modal&utm_medium=upgrade_prompt&utm_campaign=${feature || 'general'}`);
    onClose();
  };

  // Get feature display name
  const getFeatureDisplayName = (featureKey?: string) => {
    if (!featureKey) return 'more features';
    
    switch (featureKey) {
      case 'projects':
        return 'more projects';
      case 'aiAnalysis':
        return 'more AI analyses';
      case 'storage':
        return 'more storage space';
      case 'users':
        return 'more team members';
      case 'teamCollaboration':
        return 'team collaboration';
      case 'customDomains':
        return 'custom domains';
      case 'whiteLabeling':
        return 'white-labeling';
      default:
        return featureKey.replace(/([A-Z])/g, ' $1').toLowerCase();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center" onClick={onClose}>
      <div className="absolute inset-0 bg-gray-900 opacity-50"></div>
      
      <div 
        className="bg-white rounded-lg shadow-xl max-w-md w-full z-10 overflow-hidden"
        onClick={e => e.stopPropagation()}  
      >
        <div className="bg-gradient-to-r from-primary-600 to-secondary-600 p-6 text-white relative">
          <button 
            className="absolute top-4 right-4 text-white hover:text-white/80"
            onClick={onClose}
          >
            <X className="h-5 w-5" />
          </button>
          
          <Zap className="h-10 w-10 mb-4" />
          <h3 className="text-xl font-bold">Upgrade to {targetTier === SubscriptionTier.PREMIUM ? 'Premium' : 'Enterprise'}</h3>
          <p className="mt-2 text-white/90">
            {reason || `Unlock ${getFeatureDisplayName(feature)} by upgrading your plan.`}
          </p>
        </div>
        
        <div className="p-6">
          <h4 className="font-medium text-gray-900 mb-4">
            {targetTier === SubscriptionTier.PREMIUM ? 'Premium' : 'Enterprise'} includes:
          </h4>
          
          <ul className="space-y-3 mb-6">
            {TIER_FEATURES[targetTier].slice(0, 5).map((feature, index) => (
              <li key={index} className="flex items-start">
                <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                <span className="text-gray-600">{feature}</span>
              </li>
            ))}
          </ul>
          
          <div className="flex space-x-3 mt-6">
            <button 
              className="px-4 py-2 rounded-md border border-gray-300 text-gray-700 flex-grow hover:bg-gray-50"
              onClick={onClose}
            >
              Not Now
            </button>
            <button
              className="px-4 py-2 bg-primary-600 dark:bg-primary-500 text-white rounded-md flex-grow hover:bg-primary-700 dark:hover:bg-primary-400"
              onClick={handleUpgrade}
            >
              View Plans
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UpgradeModal;