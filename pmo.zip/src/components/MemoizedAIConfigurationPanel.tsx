import React from 'react';
import AIConfigurationPanel from './AIConfigurationPanel';

/**
 * Memoized version of AIConfigurationPanel that only re-renders when domain or onStartAnalysis props change
 * This improves performance by preventing unnecessary re-renders when parent components update
 */
const MemoizedAIConfigurationPanel = React.memo(
  AIConfigurationPanel,
  (prevProps, nextProps) => {
    // Only re-render if domain or onStartAnalysis changes
    return (
      prevProps.domain.id === nextProps.domain.id &&
      prevProps.onStartAnalysis === nextProps.onStartAnalysis
    );
  }
);

export default MemoizedAIConfigurationPanel; 