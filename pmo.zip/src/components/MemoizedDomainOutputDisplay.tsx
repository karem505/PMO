import React from 'react';
import DomainOutputDisplay from './DomainOutputDisplay';

/**
 * Memoized version of DomainOutputDisplay that only re-renders when domain prop changes
 * This improves performance by preventing unnecessary re-renders when parent components update
 */
const MemoizedDomainOutputDisplay = React.memo(
  DomainOutputDisplay,
  (prevProps, nextProps) => {
    // Only re-render if domain changes
    return prevProps.domain.id === nextProps.domain.id;
  }
);

export default MemoizedDomainOutputDisplay; 