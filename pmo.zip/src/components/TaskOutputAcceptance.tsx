import React, { useState, useEffect, useCallback } from 'react';
import { useAppStore } from '../store';
import { 
  CheckCircle, 
  Pencil, 
  RefreshCw, 
  Save, 
  XCircle, 
  Sparkles, 
  Clock, 
  AlertTriangle,
  Check,
  ThumbsUp,
  Download
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { Task } from '../types';
import { exportToPdf } from '../utils/exportUtils';

interface TaskOutputAcceptanceProps {
  taskId: string;
  content: string;
  onSave: (content: string, status: 'accepted' | 'needs-refinement' | 'rejected', taskCompleted?: boolean) => void;
  onRegenerate?: () => void;
}

const TaskOutputAcceptance: React.FC<TaskOutputAcceptanceProps> = ({
  taskId,
  content,
  onSave,
  onRegenerate
}) => {
  const { getActiveProject } = useAppStore();
  const [editMode, setEditMode] = useState(false);
  const [editedContent, setEditedContent] = useState(content);
  const [status, setStatus] = useState<'idle' | 'accepted' | 'needs-refinement' | 'rejected'>('idle');
  const [isExporting, setIsExporting] = useState(false);
  const [markCompleted, setMarkCompleted] = useState(false);
  const [taskData, setTaskData] = useState<any>(null);
  const [acceptanceTimestamp, setAcceptanceTimestamp] = useState<string | null>(null);
  const activeProject = getActiveProject();
  
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const getTaskData = useCallback((taskId: string) => {
    if (activeProject && activeProject.domainData && activeProject.domainData.tasks && activeProject.domainData.tasks[taskId]) {
      return activeProject.domainData.tasks[taskId];
    }
    
    // Get from userData as fallback for backward compatibility
    const { userData } = useAppStore.getState();
    return userData.tasks[taskId] || { completed: false, notes: '', attachments: [], customFields: {} };
  });

  // Get task data to initialize state
  useEffect(() => {
    const activeProject = getActiveProject();
    if (activeProject) {
      const data = getTaskData(taskId);
      setTaskData(data);
      
      // Initialize state from task data
      if (data?.acceptanceStatus) {
        setStatus(data.acceptanceStatus);
      }
      
      if (data?.acceptanceTimestamp) {
        setAcceptanceTimestamp(data.acceptanceTimestamp);
      }
      
      // Initialize mark completed checkbox based on task completion status
      setMarkCompleted(data?.completed || false);
    }
  }, [taskId, getActiveProject, getTaskData]);

  // Update edited content when content prop changes
  useEffect(() => {
    setEditedContent(content);
  }, [content]);

  const handleAccept = () => {
    const timestamp = new Date().toISOString();
    setStatus('accepted');
    setAcceptanceTimestamp(timestamp);
    onSave(content, 'accepted', markCompleted);
  };

  const handleReject = () => {
    setStatus('rejected');
    onSave(content, 'rejected', false);
    if (onRegenerate) {
      onRegenerate();
    }
  };

  const handleNeedsRefinement = () => {
    setStatus('needs-refinement');
    setEditMode(true);
    onSave(content, 'needs-refinement', false);
  };

  const handleSaveEdits = () => {
    setEditMode(false);
    onSave(editedContent, 'needs-refinement', false);
  };

  const handleEditCancel = () => {
    setEditMode(false);
    setEditedContent(content);
  };

  const handleExportPdf = async () => {
    setIsExporting(true);
    try {
      const task = await getTaskData(taskId);
      const fileName = `Task-Output-${taskId.replace(/[^a-zA-Z0-9]/g, '-')}.pdf`;
      await exportToPdf(editMode ? editedContent : content, fileName);
    } catch (error) {
      console.error('Error exporting to PDF:', error);
    } finally {
      setIsExporting(false);
    }
  };

  // Calculate time ago from timestamp
  const getTimeAgo = (timestamp: string) => {
    if (!timestamp) return '';

    const now = new Date();
    const then = new Date(timestamp);
    const diffInSeconds = Math.floor((now.getTime() - then.getTime()) / 1000);

    if (diffInSeconds < 60) {
      return 'just now';
    } else if (diffInSeconds < 3600) {
      const minutes = Math.floor(diffInSeconds / 60);
      return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
    } else if (diffInSeconds < 86400) {
      const hours = Math.floor(diffInSeconds / 3600);
      return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    } else {
      const days = Math.floor(diffInSeconds / 86400);
      return `${days} day${days > 1 ? 's' : ''} ago`;
    }
  };

  return (
    <div className="bg-white border border-gray-200 rounded-lg">
      {/* Header section */}
      <div className="p-4 bg-gray-50 border-b border-gray-200 flex justify-between items-center">
        <div className="flex items-center">
          <div className="mr-2">
            {status === 'accepted' ? (
              <CheckCircle className="h-5 w-5 text-green-500" />
            ) : status === 'needs-refinement' ? (
              <Pencil className="h-5 w-5 text-blue-500" />
            ) : status === 'rejected' ? (
              <XCircle className="h-5 w-5 text-red-500" />
            ) : (
              <Clock className="h-5 w-5 text-yellow-500" />
            )}
          </div>
          
          <div>
            <h3 className="text-sm font-medium text-gray-700">
              {status === 'accepted' ? 'Accepted Output' : 
               status === 'needs-refinement' ? 'Needs Refinement' : 
               status === 'rejected' ? 'Rejected Output' : 
               'Review Generated Output'}
            </h3>
            {acceptanceTimestamp && status === 'accepted' && (
              <p className="text-xs text-gray-500">Accepted {getTimeAgo(acceptanceTimestamp)}</p>
            )}
          </div>
        </div>

        <div className="flex space-x-2">
          <button
            onClick={handleExportPdf}
            disabled={isExporting}
            className="px-3 py-1.5 text-sm border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 flex items-center"
          >
            {isExporting ? (
              <Clock className="h-4 w-4 mr-1.5 animate-spin" />
            ) : (
              <Download className="h-4 w-4 mr-1.5" />
            )}
            Export PDF
          </button>
          
          {editMode && (
            <>
              <button 
                onClick={handleEditCancel}
                className="px-3 py-1.5 text-sm border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50"
              >
                Cancel
              </button>
              <button 
                onClick={handleSaveEdits}
                className="px-3 py-1.5 text-sm bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center"
              >
                <Save className="h-4 w-4 mr-1.5" />
                Save
              </button>
            </>
          )}
        </div>
      </div>

      {/* Content section */}
      <div className="p-4">
        {editMode ? (
          <div className="mb-4">
            <textarea
              className="w-full h-96 p-3 border border-gray-300 rounded-md font-mono text-sm focus:border-blue-500 focus:ring-blue-500"
              value={editedContent}
              onChange={(e) => setEditedContent(e.target.value)}
            />
            <p className="text-xs text-gray-500 mt-1">
              Edit the content above to refine the output. Supports Markdown formatting.
            </p>
          </div>
        ) : (
          <div className="prose prose-sm max-w-none bg-gray-50 p-5 rounded-md border border-gray-200 mb-4 min-h-[300px] max-h-[500px] overflow-y-auto">
            <ReactMarkdown>{editedContent || content}</ReactMarkdown>
          </div>
        )}

        {/* Mark as completed checkbox */}
        {(status === 'idle' || status === 'needs-refinement') && (
          <div className="flex items-center mb-4">
            <input
              type="checkbox"
              id="markCompleted"
              checked={markCompleted}
              onChange={() => setMarkCompleted(!markCompleted)}
              className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
            />
            <label htmlFor="markCompleted" className="ml-2 block text-sm text-gray-700">
              Mark task as completed when accepting output
            </label>
          </div>
        )}

        {/* Action buttons */}
        {status !== 'accepted' && (
          <div className="flex space-x-3">
            {!editMode && status !== 'rejected' && (
              <button
                onClick={handleAccept}
                className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 flex items-center"
              >
                <Check className="h-4 w-4 mr-1.5" />
                Accept Output
              </button>
            )}
            
            {!editMode && status !== 'rejected' && (
              <button
                onClick={handleNeedsRefinement}
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center"
              >
                <Pencil className="h-4 w-4 mr-1.5" />
                Refine Output
              </button>
            )}
            
            {!editMode && status !== 'rejected' && onRegenerate && (
              <button
                onClick={handleReject}
                className="px-4 py-2 border border-red-300 text-red-700 rounded-md hover:bg-red-50 flex items-center"
              >
                <XCircle className="h-4 w-4 mr-1.5" />
                Reject & Regenerate
              </button>
            )}
          </div>
        )}

        {status === 'accepted' && (
          <div className="flex items-center justify-start text-green-700 bg-green-50 p-3 rounded-md">
            <ThumbsUp className="h-5 w-5 mr-2" />
            <span>This output has been accepted and finalized.</span>
          </div>
        )}
        
        {status === 'rejected' && onRegenerate && (
          <div>
            <div className="flex items-center justify-start text-red-700 bg-red-50 p-3 rounded-md mb-4">
              <AlertTriangle className="h-5 w-5 mr-2" />
              <span>This output has been rejected. You can regenerate a new output.</span>
            </div>
            <button
              onClick={onRegenerate}
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center"
            >
              <Sparkles className="h-4 w-4 mr-1.5" />
              Generate New Output
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default TaskOutputAcceptance;