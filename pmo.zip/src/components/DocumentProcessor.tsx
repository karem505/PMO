import React, { useState, useRef, useEffect } from 'react';
import { Upload, FileText, Check, AlertCircle, Loader2, Info, AlertTriangle } from 'lucide-react';
import { documentProcessingService } from '../services/documentProcessingService';
import { ProcessedDocument } from '../utils/documentUtils';
import { useAuth } from './auth/AuthContext';
import { useAppStore } from '../store';
import { useLanguage } from '../contexts/LanguageContext';

interface DocumentProcessorProps {
  onProcessingComplete?: (processedDocument: ProcessedDocument) => void;
  domainId?: number;
  autoAddToAnalysis?: boolean; // Add ability to auto-add to analysis
}

const DocumentProcessor: React.FC<DocumentProcessorProps> = ({ 
  onProcessingComplete,
  domainId,
  autoAddToAnalysis = true // Default to true for automatic linking
}) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingStatus, setProcessingStatus] = useState<'idle' | 'processing' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [processedDoc, setProcessedDoc] = useState<ProcessedDocument | null>(null);
  const [recentlyProcessedDocs, setRecentlyProcessedDocs] = useState<ProcessedDocument[]>([]);
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { t } = useLanguage();
  const { currentUser } = useAuth();
  const { getActiveProject, addProcessedDocument, connectionError, showConnectionErrors } = useAppStore();
  const activeProject = getActiveProject();

  // On mount, retrieve recently processed documents to display
  useEffect(() => {
    if (domainId && activeProject) {
      // Load recently processed documents for this domain
      const loadRecentDocuments = async () => {
        try {
          const recentDocs = await documentProcessingService.getDomainDocuments(
            domainId, 
            activeProject.id
          );
          
          // Convert to ProcessedDocument format for display
          const processedDocs: ProcessedDocument[] = recentDocs.map(doc => ({
            id: doc.documentId,
            fileName: doc.metadata.source || 'Unknown document',
            fileType: 'auto',
            chunks: [doc],
            totalChunks: 1,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            domainId: domainId,
            projectId: activeProject.id,
          }));
          
          setRecentlyProcessedDocs(processedDocs);
        } catch (error) {
          console.error('Error loading recent documents:', error);
        }
      };
      
      loadRecentDocuments();
    }
  }, [domainId, activeProject]);
  
  // Handle drag events
  const handleDrag = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };
  
  // Handle drop event
  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      
      // Check file extension
      const fileExtension = file.name.split('.').pop()?.toLowerCase() || '';
      if (fileExtension !== 'docx' && fileExtension !== 'pdf') {
        setErrorMessage('Only .docx and .pdf files are supported. Please upload a valid document format.');
        setProcessingStatus('error');
        return;
      }
      
      // Additional validation using MIME type
      const validMimeTypes = [
        'application/pdf',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
      ];
      
      if (!validMimeTypes.includes(file.type)) {
        setErrorMessage(`Invalid file type: ${file.type}. Only Word Documents (.docx) and PDF files are allowed.`);
        setProcessingStatus('error');
        return;
      }
      
      setSelectedFile(file);
      setProcessingStatus('idle');
      setErrorMessage(null);
    }
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    
    const file = files[0];
    
    // Validate file extension
    const fileExtension = file.name.split('.').pop()?.toLowerCase() || '';
    if (fileExtension !== 'docx' && fileExtension !== 'pdf') {
      setErrorMessage('Only .docx and .pdf files are supported. Please upload a valid document format.');
      setProcessingStatus('error');
      return;
    }
    
    // Additional validation using MIME type
    const validMimeTypes = [
      'application/pdf',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    ];
    
    if (!validMimeTypes.includes(file.type)) {
      setErrorMessage(`Invalid file type: ${file.type}. Only Word Documents (.docx) and PDF files are allowed.`);
      setProcessingStatus('error');
      return;
    }
    
    setSelectedFile(file);
    setProcessingStatus('idle');
    setErrorMessage(null);
  };
  
  const handleProcessFile = async () => {
    if (!selectedFile) {
      setErrorMessage('Please select a file first');
      return;
    }
    
    // Validate file extension again before processing
    const fileExtension = selectedFile.name.split('.').pop()?.toLowerCase() || '';
    if (fileExtension !== 'docx' && fileExtension !== 'pdf') {
      setErrorMessage('Only .docx and .pdf files are supported. Please upload a valid document format.');
      setProcessingStatus('error');
      return;
    }
    
    setIsProcessing(true);
    setProcessingStatus('processing');
    setErrorMessage(null);
    
    try {
      let processedDocument: ProcessedDocument;
      
      // Process based on file type
      const fileType = getFileType(selectedFile.name);
      
      if (fileType === 'pdf') {
        // For PDFs we need to use the PDF parser
        const fileBuffer = await readFileAsArrayBuffer(selectedFile);
        processedDocument = await documentProcessingService.processPdfDocument(
          selectedFile.name,
          fileBuffer,
          currentUser?.id,
          activeProject?.id
        );
      } else {
        // For text-based files
        const text = await readFileAsText(selectedFile);
        processedDocument = await documentProcessingService.processTextDocument(
          selectedFile.name,
          text,
          fileType,
          currentUser?.id,
          activeProject?.id
        );
      }
      
      // Add domain ID if provided
      if (domainId) {
        processedDocument.domainId = domainId;
      }
      
      // Add project ID if available
      if (activeProject?.id) {
        processedDocument.projectId = activeProject.id;
      }
      
      setProcessedDoc(processedDocument);
      setProcessingStatus('success');
      
      // Add document to store
      addProcessedDocument(processedDocument);
      
      // Update recent documents list
      setRecentlyProcessedDocs(prev => [processedDocument, ...prev]);
      
      // Call the callback if provided
      if (onProcessingComplete) {
        onProcessingComplete(processedDocument);
      }
      
      // Reset file input
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } catch (error) {
      console.error('Error processing document:', error);
      setProcessingStatus('error');
      setErrorMessage(error instanceof Error ? error.message : 'An error occurred while processing the document');
    } finally {
      setIsProcessing(false);
      setSelectedFile(null);
    }
  };
  
  const readFileAsText = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          resolve(event.target.result as string);
        } else {
          reject(new Error('Failed to read file'));
        }
      };
      reader.onerror = () => reject(reader.error);
      reader.readAsText(file);
    });
  };
  
  const readFileAsArrayBuffer = (file: File): Promise<ArrayBuffer> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          resolve(event.target.result as ArrayBuffer);
        } else {
          reject(new Error('Failed to read file'));
        }
      };
      reader.onerror = () => reject(reader.error);
      reader.readAsArrayBuffer(file);
    });
  };
  
  const getFileType = (fileName: string): string => {
    const extension = fileName.split('.').pop()?.toLowerCase() || '';
    if (extension !== 'docx' && extension !== 'pdf') {
      throw new Error('Unsupported file format. Only .docx and .pdf files are allowed.');
    }
    return extension;
  };
  
  const handleSelectFile = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };
  
  const resetProcessor = () => {
    setSelectedFile(null);
    setProcessedDoc(null);
    setProcessingStatus('idle');
    setErrorMessage(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };
  
  return (
    <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
      <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
        <FileText className="h-5 w-5 mr-2 text-blue-600" />
        {t('documentProcessor.title', 'Document Processor')}
      </h2>

      {connectionError && showConnectionErrors && (
        <div className="bg-amber-50 dark:bg-amber-900/30 border border-amber-200 dark:border-amber-800 rounded-md p-4 mb-4 flex items-start">
          <AlertTriangle className="h-5 w-5 text-amber-600 dark:text-amber-500 mt-0.5 me-2 flex-shrink-0" />
          <div>
            <p className="text-sm font-medium text-amber-800 dark:text-amber-400">
              Working in offline mode
            </p>
            <p className="text-xs text-amber-700 dark:text-amber-300 mt-1">
              You appear to be working offline. Document processing may be limited.
            </p>
          </div>
        </div>
      )}
      
      {/* File Upload Area */}
      <div 
        className={`border-2 border-dashed rounded-lg p-6 text-center ${
          dragActive ? 'border-blue-400 bg-blue-50' :
          selectedFile ? 'border-green-300 bg-green-50' : 'border-gray-300 bg-gray-50 hover:bg-gray-100'
        } transition-colors duration-200`}
        onDragEnter={handleDrag}
        onDragOver={handleDrag}
        onDragLeave={handleDrag}
        onDrop={handleDrop}
      >
        {!selectedFile ? (
          <div>
            <Upload className="h-8 w-8 text-gray-400 mx-auto mb-4" />
            <p className="text-sm text-gray-600">
              {t('documentProcessor.dragAndDropYourDocumentHereOrClickToBrowse', 'Drag and drop your document here, or click to browse')}
            </p>
            <p className="text-xs text-gray-500 mt-1">
              {t('documentProcessor.supportedFormats', 'Supported formats: .docx, .pdf files only')}
            </p>
            <p className="text-xs text-amber-600 font-medium mt-1">
              Note: Only Microsoft Word (.docx) and PDF files can be uploaded
            </p>
            
            {/* Custom file selection buttons */}
            <div className="mt-4 flex justify-center space-x-3">
              <button
                type="button"
                onClick={() => {
                  if (fileInputRef.current) {
                    fileInputRef.current.setAttribute('accept', '.pdf,application/pdf');
                    fileInputRef.current.click();
                  }
                }}
                className="px-4 py-2 bg-red-600 text-white text-sm rounded-md hover:bg-red-700 flex items-center"
              >
                <FileText className="h-4 w-4 mr-2" />
                {t('documentProcessor.selectPdf', 'Select PDF')}
              </button>
              
              <button
                type="button"
                onClick={() => {
                  if (fileInputRef.current) {
                    fileInputRef.current.setAttribute('accept', '.docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document');
                    fileInputRef.current.click();
                  }
                }}
                className="px-4 py-2 bg-blue-600 text-white text-sm rounded-md hover:bg-blue-700 flex items-center"
              >
                <FileText className="h-4 w-4 mr-2" />
                {t('documentProcessor.selectWordDoc', 'Select Word Doc')}
              </button>
            </div>
          </div>
        ) : (
          <div>
            <Check className="h-8 w-8 text-green-500 mx-auto mb-4" />
            <p className="text-sm font-medium text-gray-800">
              {selectedFile.name}
            </p>
            <p className="text-xs text-gray-600 mt-1">
              {(selectedFile.size / 1024).toFixed(2)} KB
            </p>
            <div className="mt-4 flex justify-center space-x-3">
              <button
                type="button"
                onClick={resetProcessor}
                className="px-3 py-1.5 border border-gray-300 text-gray-700 text-sm rounded-md hover:bg-gray-50"
              >
                {t('documentProcessor.change', 'Change')}
              </button>
              <button
                type="button"
                onClick={handleProcessFile}
                disabled={isProcessing}
                className={`px-3 py-1.5 bg-blue-600 text-white text-sm rounded-md hover:bg-blue-700 flex items-center ${
                  isProcessing ? 'opacity-70 cursor-not-allowed' : ''
                }`}
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-1.5 animate-spin" />
                    {t('documentProcessor.processing', 'Processing...')}
                  </>
                ) : (
                  t('documentProcessor.processDocument', 'Process Document')
                )}
              </button>
            </div>
          </div>
        )}
        
        <input
          type="file"
          ref={fileInputRef}
          className="hidden"
          onChange={handleFileChange}
          accept=".docx,.pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/pdf"
          data-accept-file-types="application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        />
      </div>
      
      {/* Processing Status */}
      {processingStatus === 'success' && processedDoc && (
        <div className="bg-green-50 border border-green-200 rounded-md p-4 mt-4">
          <div className="flex items-start">
            <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
            <div>
              <h3 className="text-sm font-medium text-green-800">{t('documentProcessor.documentProcessedSuccessfully', 'Document processed successfully')}</h3>
              <div className="mt-2 text-xs text-green-700">
                <p>{t('documentProcessor.documentSplitIntoChunksForOptimalAnalysis', 'Document split into {processedDoc.totalChunks} chunks for optimal analysis.')}</p>
                <p className="mt-1">
                  <strong>{t('documentProcessor.documentAutomaticallyAddedToAnalysis', 'Document automatically added to analysis.')}</strong> {t('documentProcessor.itWillBeUsedToEnhanceAIResponsesInThisDomain', 'It will be used to enhance AI responses in this domain.')}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Error message */}
      {processingStatus === 'error' && errorMessage && (
        <div className="mb-4 mt-4 p-3 bg-red-50 text-red-700 text-sm rounded-md flex items-start">
          <AlertCircle className="h-4 w-4 mt-0.5 mr-2 flex-shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}
      
      {/* Recently Processed Documents */}
      {recentlyProcessedDocs.length > 0 && (
        <div className="mt-4 border-t border-gray-100 pt-4">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-gray-700">{t('documentProcessor.recentlyProcessedDocuments', 'Recently Processed Documents')}</h3>
            <span className="text-xs text-gray-500">{recentlyProcessedDocs.length} document{recentlyProcessedDocs.length !== 1 ? 's' : ''}</span>
          </div>
          <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
            {recentlyProcessedDocs.map((doc, index) => (
              <div key={doc.id || index} className="flex items-center p-2 bg-gray-50 rounded-lg border border-gray-100 text-sm">
                <FileText className="h-4 w-4 text-blue-500 mr-2 flex-shrink-0" />
                <div className="flex-1 truncate">
                  <p className="font-medium text-gray-700 truncate">{doc.fileName}</p>
                  <p className="text-xs text-gray-500">
                    {new Date(doc.createdAt).toLocaleDateString()} • {doc.totalChunks} chunks
                  </p>
                </div>
                <span className="px-2 py-0.5 bg-green-100 text-green-800 text-xs rounded-full">
                  {t('documentProcessor.availableInAnalysis', 'Available in Analysis')}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
      
      {/* Help Text */}
      <div className="text-xs text-gray-500 mt-4 p-3 bg-blue-50 rounded-md border border-blue-100 flex items-start">
        <Info className="h-4 w-4 text-blue-500 me-2 mt-0.5 flex-shrink-0" />
        <div>
          <p className="font-medium text-blue-700">{t('documentProcessor.whyProcessDocuments', 'Why process documents?')}</p>
          <p className="mt-1 text-blue-600">
            {t('documentProcessor.breakingDownLargeDocumentsAllowsAIToAnalyzeThemMoreEffectivelyAndReferenceSpecificSections', 'Breaking down large documents allows the AI to analyze them more effectively and reference specific sections.')}
            {t('documentProcessor.processedDocumentsAppearAutomaticallyInTheAnalysisTabAndEnhanceAIResponsesWithYourDomainSpecificContext', 'Processed documents appear automatically in the analysis tab and enhance AI responses with your domain-specific context.')}
          </p>
        </div>
      </div>
    </div>
  );
};

export default DocumentProcessor;