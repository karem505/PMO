import React, { Suspense, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, UNSAFE_NavigationContext } from 'react-router-dom';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import ProfilePage from './pages/ProfilePage';
import { AuthProvider } from './components/auth/AuthContext';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import LandingPage from './pages/LandingPage';
import VerifyEmailPage from './pages/VerifyEmailPage';
import AuthCallback from './pages/AuthCallback';
import ProtectedRoute from './components/auth/ProtectedRoute';
import NotFoundPage from './pages/NotFoundPage';
import { ThemeProvider } from './contexts/ThemeContext';
import { LanguageProvider } from './contexts/LanguageContext';
import SupabaseTestPage from './pages/SupabaseTestPage';
import LoadingScreen from './components/common/LoadingScreen';
import { ErrorBoundary } from 'react-error-boundary';
import { useAppStore } from './store';
import { SubscriptionProvider } from './contexts/SubscriptionContext';
import PricingPage from './pages/PricingPage';
import SubscriptionPage from './pages/SubscriptionPage';
import { baseURL } from './api/client';
import { NotificationProvider } from './contexts/NotificationContext';
import ToastContainer from './components/common/ToastContainer';
import { OnboardingProvider } from './contexts/OnboardingContext';
import OnboardingTourManager from './components/OnboardingTourManager';
import { NavigationGuardProvider } from './components/NavigationGuardProvider';
// Lazily load less critical routes
const DomainDetail = React.lazy(() => import('./pages/DomainDetail'));
const ResourcesPage = React.lazy(() => import('./pages/ResourcesPage'));
const SettingsPage = React.lazy(() => import('./pages/SettingsPage'));
const HelpPage = React.lazy(() => import('./pages/HelpPage'));
const NotificationsPage = React.lazy(() => import('./pages/NotificationsPage'));
const TeamsPage = React.lazy(() => import('./pages/TeamsPage'));
const InvitationsPage = React.lazy(() => import('./pages/InvitationsPage'));
const TasksPage = React.lazy(() => import('./pages/TasksPage'));
const TaskDetailPage = React.lazy(() => import('./pages/TaskDetailPage'));
const MaturityAssessmentPage = React.lazy(() => import('./pages/MaturityAssessmentPage'));
const AdminPage = React.lazy(() => import('./pages/AdminPage'));
const UserManagementPage = React.lazy(() => import('./pages/admin/UserManagementPage'));
const RolePermissionPage = React.lazy(() => import('./pages/admin/RolePermissionPage'));
const ConnectionStatusPage = React.lazy(() => import('./pages/ConnectionStatusPage'));
const TestPage = React.lazy(() => import('./pages/TestPage'));
const DebugPage = React.lazy(() => import('./pages/DebugPage'));

// Add global navigation guard to prevent rapid navigation issues
if (typeof window !== 'undefined') {
  // Track last navigation time
  let lastNavigationTime = 0;
  let navigationCount = 0;
  const MIN_NAVIGATION_DELAY = 300; // milliseconds
  const NAVIGATION_RESET_DELAY = 2000; // reset navigation count after 2 seconds
  const MAX_NAVIGATION_COUNT = 5; // maximum number of navigations in quick succession
  
  // Store the original pushState and replaceState methods
  const originalPushState = window.history.pushState;
  const originalReplaceState = window.history.replaceState;
  
  // Override pushState
  window.history.pushState = function(data, title, url) {
    const now = Date.now();
    const timeSinceLastNavigation = now - lastNavigationTime;
    
    // Reset navigation count if it's been a while
    if (timeSinceLastNavigation > NAVIGATION_RESET_DELAY) {
      navigationCount = 0;
    }
    
    // Increment navigation count
    navigationCount++;
    
    // If navigating too quickly or too many times in succession, use direct location change instead
    if (timeSinceLastNavigation < MIN_NAVIGATION_DELAY || navigationCount > MAX_NAVIGATION_COUNT) {
      console.log(`Rapid navigation detected (${timeSinceLastNavigation}ms, count: ${navigationCount}), using direct navigation`);
      
      // For very rapid or excessive navigation, delay and use direct location change
      setTimeout(() => {
        try {
          window.location.href = url as string;
        } catch (error) {
          console.error('Direct navigation failed:', error);
        }
      }, navigationCount > MAX_NAVIGATION_COUNT ? 500 : MIN_NAVIGATION_DELAY - timeSinceLastNavigation);
      
      return;
    }
    
    // Otherwise use normal pushState
    lastNavigationTime = now;
    return originalPushState.apply(this, [data, title, url]);
  };
  
  // Override replaceState
  window.history.replaceState = function(data, title, url) {
    const now = Date.now();
    lastNavigationTime = now;
    return originalReplaceState.apply(this, [data, title, url]);
  };
  
  // Add global error handler specifically for nodeName errors
  window.addEventListener('error', (event) => {
    if (event.error && event.error.message && event.error.message.includes("Cannot read properties of null (reading 'nodeName')")) {
      // Prevent the error from propagating
      event.preventDefault();
      event.stopPropagation();
      
      console.warn('Intercepted nodeName error and prevented app crash');
      
      // Force a synchronous layout calculation to ensure DOM is up to date
      try {
        document.body.getBoundingClientRect();
      } catch (err) {
        console.error('Error forcing layout calculation:', err);
      }
      
      return false;
    }
  }, true);
}

// Custom Router component to prevent unnecessary reloads
const CustomRouter: React.FC<{children: React.ReactNode}> = ({ children }) => {
  // Add handler to prevent default page reload on form submissions
  useEffect(() => {
    const handleFormSubmit = (e: any) => {
      // Check if the form has a specific flag to allow reload
      if (e.target && e.target.getAttribute('data-allow-reload') !== 'true') {
        e.preventDefault();
      }
    };

    document.addEventListener('submit', handleFormSubmit);
    return () => {
      document.removeEventListener('submit', handleFormSubmit);
    };
  }, []);

  return (
    <Router future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
      <NavigationGuardProvider>
        {children}
      </NavigationGuardProvider>
    </Router>
  );
};

// Simple loading component for lazy loaded routes
const LazyLoadingFallback = () => (
  <LoadingScreen message="Loading page..." minHeight="min-h-[500px]" showLogo={false} />
);

// Error fallback component
const ErrorFallback = ({ error, resetErrorBoundary }: any) => (
  <div className="min-h-screen flex items-center justify-center bg-gray-50">
    <div className="max-w-md w-full bg-white rounded-lg shadow p-8 text-center">
      <h2 className="text-2xl font-bold  text-red-600 mb-4">Something went wrong</h2>
      <p className="text-gray-700 mb-4">{error.message}</p>
      <button
        onClick={resetErrorBoundary}
        className="px-4 py-2 bg-blue-600 text-white rounded-md"
      >
        Try again
      </button>
    </div>
  </div>
);

// Connection monitor
const ConnectionMonitor: React.FC<{children: React.ReactNode}> = ({ children }) => {
  const { connectionError, setConnectionError } = useAppStore();
  
  useEffect(() => {
    // Function to check connection status
    const checkConnection = async () => {
      try {
        // Only check if the page has been active in the last 10 minutes
        const lastActivity = window.localStorage.getItem('lastUserActivity');
        const now = Date.now();
        const tenMinutesAgo = now - 10 * 60 * 1000;
        
        if (!lastActivity || parseInt(lastActivity, 10) < tenMinutesAgo) {
          // Skip this check if user is inactive
          return;
        }
        
        const response = await fetch(`${baseURL}/healthcheck`, { 
          method: 'GET',
          cache: 'no-store',
          headers: { 'pragma': 'no-cache' }
        });
        setConnectionError(!response.ok);
      } catch (error) {
        // Network error, likely offline
        setConnectionError(true);
      }
    };
    
    // Check connection immediately
    checkConnection();
    
    // Set up periodic connection check with a much longer interval
    const interval = setInterval(checkConnection, 600000); // Changed to 10 minutes (600000ms)
    
    // Also check when browser goes online/offline
    const handleOnline = () => setConnectionError(false);
    const handleOffline = () => setConnectionError(true);
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    return () => {
      clearInterval(interval);
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [setConnectionError]);
  
  return <>{children}</>;
};

// Add debounce utility
const debounce = (func: Function, wait: number) => {
  let timeout: NodeJS.Timeout;
  return function executedFunction(...args: any[]) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
};

// Add message handler optimization
const setupMessageHandler = () => {
  let isProcessing = false;
  let pendingMessages: any[] = [];
  let frameId: number | null = null;
  
  const processMessages = () => {
    if (pendingMessages.length === 0) {
      isProcessing = false;
      frameId = null;
      return;
    }
    
    const message = pendingMessages.shift();
    try {
      // Process message here
      console.log('Processing message:', message);
    } catch (error) {
      console.error('Error processing message:', error);
    }
    
    // Schedule next message processing
    frameId = requestAnimationFrame(processMessages);
  };
  
  const handleMessage = (event: MessageEvent) => {
    // Add message to queue
    pendingMessages.push(event.data);
    
    // Start processing if not already processing
    if (!isProcessing) {
      isProcessing = true;
      frameId = requestAnimationFrame(processMessages);
    }
  };
  
  // Add event listener with debounce
  const debouncedHandler = debounce(handleMessage, 16); // ~60fps
  window.addEventListener('message', debouncedHandler);
  
  // Cleanup function
  return () => {
    window.removeEventListener('message', debouncedHandler);
    if (frameId !== null) {
      cancelAnimationFrame(frameId);
    }
  };
};

function App() {
  const { syncWithSupabase } = useAppStore();
  
  // Add message handler setup
  useEffect(() => {
    return setupMessageHandler();
  }, []);
  
  // Ensure data is loaded on app start
  useEffect(() => {
    const loadInitialData = async () => {
      try {
        // Don't force reload on initial data load
        const stateModified = await syncWithSupabase(false);
        console.log('Initial data synchronization completed, state modified:', stateModified);
      } catch (error) {
        console.error('Error during initial data synchronization:', error);
      }
    };
    
    loadInitialData();
  }, [syncWithSupabase]);

  // Add a global error handler to intercept DOM node errors
  useEffect(() => {
    const originalError = window.console.error;
    
    // Override console.error to intercept specific DOM errors
    window.console.error = (...args) => {
      const errorMessage = args.join(' ');
      
      // Check if this is the nodeName error we're trying to catch
      if (errorMessage.includes("Cannot read properties of null (reading 'nodeName')")) {
        console.warn('Intercepted DOM nodeName error, preventing crash');
        
        // Wait for DOM to be ready before allowing more navigation
        setTimeout(() => {
          // Force a re-render of the current route to ensure DOM is updated
          window.dispatchEvent(new Event('navigate-safe'));
        }, 100);
        
        return; // Prevent the error from propagating
      }
      
      // For all other errors, use the original console.error
      originalError.apply(console, args);
    };
    
    // Cleanup function
    return () => {
      window.console.error = originalError;
    };
  }, []);

  // Add event listeners for history state changes to prevent rapid navigation
  useEffect(() => {
    const originalPushState = window.history.pushState;
    const originalReplaceState = window.history.replaceState;
    
    let lastNavTime = 0;
    let navCount = 0;
    const MIN_NAV_DELAY = 300; // ms
    const NAV_RESET_DELAY = 2000; // ms
    const MAX_NAV_COUNT = 3; // max number of navigations in quick succession
    
    // Reset counter after delay
    const resetNavCounter = () => {
      setTimeout(() => {
        navCount = 0;
      }, NAV_RESET_DELAY);
    };
    
    // Override pushState with proper typing
    window.history.pushState = function(
      data: any, 
      title: string, 
      url?: string | URL | null
    ) {
      const now = Date.now();
      const timeSinceLastNav = now - lastNavTime;
      
      // Check for rapid navigation
      if (timeSinceLastNav < MIN_NAV_DELAY) {
        navCount++;
        
        // If too many rapid navigations, delay this one
        if (navCount > MAX_NAV_COUNT) {
          console.warn(`Too many rapid navigations (${navCount}), delaying`);
          setTimeout(() => {
            originalPushState.call(this, data, title, url);
          }, MIN_NAV_DELAY);
          return;
        }
      } else {
        // Reset counter if navigation isn't rapid
        navCount = 0;
      }
      
      // Update last navigation time
      lastNavTime = now;
      resetNavCounter();
      
      // Regular navigation
      return originalPushState.call(this, data, title, url);
    };
    
    // Override replaceState with similar logic and proper typing
    window.history.replaceState = function(
      data: any, 
      title: string, 
      url?: string | URL | null
    ) {
      const now = Date.now();
      const timeSinceLastNav = now - lastNavTime;
      
      if (timeSinceLastNav < MIN_NAV_DELAY) {
        navCount++;
        if (navCount > MAX_NAV_COUNT) {
          console.warn(`Too many rapid replacements (${navCount}), delaying`);
          setTimeout(() => {
            originalReplaceState.call(this, data, title, url);
          }, MIN_NAV_DELAY);
          return;
        }
      } else {
        navCount = 0;
      }
      
      lastNavTime = now;
      resetNavCounter();
      
      return originalReplaceState.call(this, data, title, url);
    };
    
    // Cleanup function
    return () => {
      window.history.pushState = originalPushState;
      window.history.replaceState = originalReplaceState;
    };
  }, []);

  // Add a global handler for Node errors to prevent crashes
  useEffect(() => {
    // Capture the original addEventListener
    const originalAddEventListener = Element.prototype.addEventListener;
    
    // Create a wrapper function with proper typing that catches "Cannot read properties of null" errors
    Element.prototype.addEventListener = function<K extends keyof ElementEventMap>(
      type: K,
      listener: (this: Element, ev: ElementEventMap[K]) => any,
      options?: boolean | AddEventListenerOptions
    ): void {
      // Create a properly typed wrapped listener
      const wrappedListener = function(this: Element, event: ElementEventMap[K]) {
        try {
          listener.call(this, event);
        } catch (error: unknown) {
          // Check if this is the specific node error
          if (
            error instanceof Error && 
            error.message && 
            error.message.includes("Cannot read properties of null (reading 'nodeName')")
          ) {
            console.warn('Prevented crash from nodeName error in event listener');
            // Optionally report to monitoring 
            // Sentry.captureException(error);
          } else {
            // For other errors, re-throw
            throw error;
          }
        }
      };
      
      // Call the original addEventListener with our wrapped listener
      return originalAddEventListener.call(this, type, wrappedListener as EventListener, options);
    };
    
    // Clean up the patch on unmount
    return () => {
      Element.prototype.addEventListener = originalAddEventListener;
    };
  }, []);

  return (
    <ErrorBoundary FallbackComponent={ErrorFallback}>
      <AuthProvider>
        <LanguageProvider>
          <ThemeProvider>
            <NotificationProvider>
              <SubscriptionProvider>
                <OnboardingProvider>
                  <ConnectionMonitor>
                    <CustomRouter>
                      <ToastContainer />
                      <OnboardingTourManager />
                      <Routes>
                        {/* Public routes */}
                        <Route path="/" element={<LandingPage />} />
                        <Route path="/login" element={<LoginPage />} />
                        <Route path="/register" element={<RegisterPage />} />
                        <Route path="/verify-email" element={<VerifyEmailPage />} />
                        <Route path="/auth/callback" element={<AuthCallback />} />
                        {/* Handle OAuth errors */}
                        <Route path="/oauth-error" element={<AuthCallback />} />
                        <Route path="/supabase-test" element={<SupabaseTestPage />} />
                        <Route path="/pricing" element={<PricingPage />} />
                        
                        {/* Protected dashboard routes */}
                        <Route path="/dashboard" element={
                          <ProtectedRoute>
                            <Layout />
                          </ProtectedRoute>
                        }>
                          <Route index element={<Dashboard />} />
                          <Route path="test" element={
                            <Suspense fallback={<LazyLoadingFallback />}>
                              <TestPage />
                            </Suspense>
                          } />
                          <Route path="debug" element={
                            <Suspense fallback={<LazyLoadingFallback />}>
                              <DebugPage />
                            </Suspense>
                          } />
                          <Route path="profile" element={<ProfilePage />} />
                          <Route path="resources" element={
                            <Suspense fallback={<LazyLoadingFallback />}>
                              <ResourcesPage />
                            </Suspense>
                          } />
                          <Route path="settings" element={
                            <Suspense fallback={<LazyLoadingFallback />}>
                              <SettingsPage />
                            </Suspense>
                          } />
                          <Route path="settings/subscription" element={<SubscriptionPage />} />
                          <Route path="help" element={
                            <Suspense fallback={<LazyLoadingFallback />}>
                              <HelpPage />
                            </Suspense>
                          } />
                          <Route path="notifications" element={
                            <Suspense fallback={<LazyLoadingFallback />}>
                              <NotificationsPage />
                            </Suspense>
                          } />
                          <Route path="teams" element={
                            <Suspense fallback={<LazyLoadingFallback />}>
                              <TeamsPage />
                            </Suspense>
                          } />
                          <Route path="invitations" element={
                            <Suspense fallback={<LazyLoadingFallback />}>
                              <InvitationsPage />
                            </Suspense>
                          } />
                          <Route path="tasks" element={
                            <Suspense fallback={<LazyLoadingFallback />}>
                              <TasksPage />
                            </Suspense>
                          } />
                          <Route path="tasks/:taskId" element={
                            <Suspense fallback={<LazyLoadingFallback />}>
                              <TaskDetailPage />
                            </Suspense>
                          } />
                          <Route path="maturity-assessment" element={
                            <Suspense fallback={<LazyLoadingFallback />}>
                              <MaturityAssessmentPage />
                            </Suspense>
                          } />
                          <Route path="connection-status" element={
                            <Suspense fallback={<LazyLoadingFallback />}>
                              <ConnectionStatusPage />
                            </Suspense>
                          } />
                          
                          {/* Admin routes */}
                          <Route path="admin" element={
                            <ProtectedRoute requiredRole="admin">
                              <Suspense fallback={<LazyLoadingFallback />}>
                                <AdminPage />
                              </Suspense>
                            </ProtectedRoute>
                          } />
                          <Route path="admin/users" element={
                            <ProtectedRoute requiredRole="admin">
                              <Suspense fallback={<LazyLoadingFallback />}>
                                <UserManagementPage />
                              </Suspense>
                            </ProtectedRoute>
                          } />
                          <Route path="admin/roles" element={
                            <ProtectedRoute requiredRole="admin">
                              <Suspense fallback={<LazyLoadingFallback />}>
                                <RolePermissionPage />
                              </Suspense>
                            </ProtectedRoute>
                          } />
                        </Route>
                        
                        {/* Direct route to resources */}
                        <Route path="/resources" element={
                          <ProtectedRoute>
                            <Layout />
                          </ProtectedRoute>
                        }>
                          <Route index element={
                            <Suspense fallback={<LazyLoadingFallback />}>
                              <ResourcesPage />
                            </Suspense>
                          } />
                        </Route>
                        
                        {/* Direct route to maturity assessment */}
                        <Route path="/maturity-assessment" element={
                          <ProtectedRoute>
                            <Layout />
                          </ProtectedRoute>
                        }>
                          <Route index element={
                            <Suspense fallback={<LazyLoadingFallback />}>
                              <MaturityAssessmentPage />
                            </Suspense>
                          } />
                        </Route>
                        
                        {/* Direct route to tasks */}
                        <Route path="/tasks" element={
                          <ProtectedRoute>
                            <Layout />
                          </ProtectedRoute>
                        }>
                          <Route index element={
                            <Suspense fallback={<LazyLoadingFallback />}>
                              <TasksPage />
                            </Suspense>
                          } />
                        </Route>
                        
                        {/* Direct route to task detail */}
                        <Route path="/tasks/:taskId" element={
                          <ProtectedRoute>
                            <Layout />
                          </ProtectedRoute>
                        }>
                          <Route index element={
                            <Suspense fallback={<LazyLoadingFallback />}>
                              <TaskDetailPage />
                            </Suspense>
                          } />
                        </Route>
                        
                        {/* Domain routes - dedicated route for domains to avoid nesting issues */}
                        <Route path="/domains/:id" element={
                          <ProtectedRoute>
                            <Layout />
                          </ProtectedRoute>
                        }>
                          <Route index element={
                            <Suspense fallback={<LazyLoadingFallback />}>
                              <DomainDetail />
                            </Suspense>
                          } />
                        </Route>
                        
                        {/* Legacy route support */}
                        <Route path="/domain/:id" element={
                          <ProtectedRoute>
                            <Layout />
                          </ProtectedRoute>
                        }>
                          <Route index element={
                            <Suspense fallback={<LazyLoadingFallback />}>
                              <DomainDetail />
                            </Suspense>
                          } />
                        </Route>
                        
                        {/* Fallback route - redirect to landing page if not authenticated */}
                        <Route path="*" element={<Navigate to="/" replace />} />
                      </Routes>
                    </CustomRouter>
                  </ConnectionMonitor>
                </OnboardingProvider>
              </SubscriptionProvider>
            </NotificationProvider>
          </ThemeProvider>
        </LanguageProvider>
      </AuthProvider>
    </ErrorBoundary>
  );
}

export default App;