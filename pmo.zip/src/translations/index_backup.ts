// Translation keys organized by component/page
// English translations
const en = {
  // Common components
  common: {
    pleaseWait: "Please wait while we prepare your content.",
    Complete : "Complete",
    search: "Search",
    save: "Save",
    saveAssessment: "Save Assessment",
    saved: "Saved!",
    showLess: "Show less",
    showMore: "Show more",
    cancel: "Cancel",
    edit: "Edit",
    delete: "Delete",
    close: "Close",
    loading: "Loading...",
    submit: "Submit",
    active: "Active",
    back: "Back",
    spent: "Spent",
    used: "Used",
    onTrack: "On Track",
    viewDetails: "View Details",
    tasks: "Tasks",
    domains: "Domains",
    budget: "Budget",
    daysLeft: "days left",
    next: "Next",
    progress: "Progress",
    notifications: "Notifications",
    help: "Help",
    settings: "Settings",
    profile: "Profile",
    signOut: "Sign Out",
    dashboard: "Dashboard",
    export: "Export",
    import: "Import",
    share: "Share",
    days: "days",
    darkMode: "Dark Mode",
    lightMode: "Light Mode",
    confirm: "Confirm",
    remainingTokens: "Remaining Tokens"
  },
  
  // Header component
  header: {
    search: "Search...",
    myTeams: "My Teams",
    invitations: "Invitations",
    setupProfile: "Setup Profile",
    subscription: "Subscription",
    settings: "Settings",
    adminPanel: "Admin Panel",
    signOut: "Sign out",
    profile: "Profile",
  },
  
  // Dashboard page
  dashboard: {
    title: "Dashboard",
    subtitle: "Build and track your PMO across all essential domains",
    budget: "Budget",
    editDetails: "Edit Details",
    exportReport: "Export Report",
    access: "Access",
    timelineProgress: "Timeline Progress",
    budgetUtilization: "Budget Utilization",
    projectStatus: "Project Status",
    maturityAssessment: "Maturity Assessment",
    keyObjectives: "Key Objectives",
    stakeholders: "Stakeholders",
    overallProgress: "Overall Progress",
    completedTasks: "Completed Tasks",
    domainProcessComparison:"Domain Progress Comparison",
    organization: "Organization",
    industry: "Industry",
    dashboardCustomization: "Dashboard Customization",
    displayLayout: "Display Layout",
    gridView: "Grid View",
    listView: "List View",
    widgetSelection: "Widget Selection",
    assessMaturityLevel: "Assess Your Maturity Level",
    maturityLevel: "Maturity Level",
    progressOverview: "Progress Overview",
    tasksStatus: "Tasks Status",
    domains: "Domains",
    chartsAnalytics: "Charts & Analytics",
    pmoMaturityLevel: "PMO Maturity Level",
    pmoDomains: "PMO Domains",
    aiAnalysis: "Accelerate with AI",
    aiDescription: "Let our advanced AI analyze your PMO data and generate comprehensive recommendations tailored to your organization's unique needs.",
    tryAiAnalysis: "Try AI Analysis",
    viewAll: "View all",
    of: "of",
    tasksCompleted: "tasks completed",
    notSet: "Not set",
    updateProfile: "Update profile",
    viewAllTasks: "View all tasks",
    nextSteps: "Next Steps",
    uploadDocuments: "Upload documents",
    analysisDocuments: "Upload supporting documents for AI analysis",
    analysisDocumentsDesc: "Enhance AI recommendations with your organization's context",
    completePmoMaturityAssessment: "Complete a PMO Maturity Assessment",
    getInsightsAboutPmoMaturityLevel: "Get insights about your PMO's current maturity level",
    reviewPractices: "Review best practices",
    explorePractices: "Explore the best practices library for guidance",
    viewResources: "View resources",
    goToAssessment: "Go to assessment",
    objective1: "Establish PMO governance framework",
    objective2: "Develop standard methodologies",
    objective3: "Implement performance metrics",
    sampleProject: "Sample PMO Implementation",
    sampleDescription: "A sample project with pre-populated data for demonstration",
    createFirstProject: "Create Your First PMO Project",
    firstProjectDesc: "Get started by creating your first PMO implementation project. You can set up project details, track progress across domains, and generate AI-powered recommendations.",
    createSample: "Create Sample Project",
    aiFeature1: "Custom templates based on your current maturity level",
    aiFeature2: "Detailed implementation roadmaps for each domain",
    aiFeature3: "Best practices tailored to your industry and context",
    maturityRadarChart: "Maturity Radar Chart",
    higherValuesIndicateGreaterMaturity: "Higher values indicate greater maturity",
    pmoMaturityAssessment: "PMO Maturity Assessment",
    assessPmoMaturity: "Assess your PMO's maturity level across all domains to identify strengths and improvement opportunities",
    selfAssessment: "Self-Assessment",
    aiGeneratedAssessment: "AI-Generated Assessment",
    notSpecified: "Not specified",
    currentMaturityProfile: "Current Maturity Profile",
    organizationDetails: "Organization Details",
    assessmentType: "Assessment Type",
    currentMaturityProfileDescription: "Your organization's PMO is currently at the",
    currentMaturityProfileDescription2: "level. This assessment will help you identify areas for improvement and create a roadmap for advancing your PMO capabilities.",
    assessmentDate: "Assessment Date",
    selfAssessmentQuestionnaire: "Self-Assessment Questionnaire",
    selfAssessmentDescription: "Rate your PMO's maturity level for each domain. Consider your processes, documentation, measurement capabilities, and continuous improvement efforts when making your assessment.",
    documentation: "Documentation",
    metrics: "Metrics",
    minimalToNone: "Minimal to none",
    basicDocumentation: "Basic documentation",
    comprehensiveDocumentation: "Comprehensive",
    regularlyUpdated: "Regularly updated",
    leadingPractice: "Leading practice",
    adHocOrNone: "Ad-hoc or none",
    basicTracking: "Basic tracking",
    notes: "Notes (Optional)",
    notesPlaceholder: "Add any notes or context about your assessment...",
    createNew: "Create New Project",
    generateAIAssessment: "Generate an AI Assessment",
    aiAssessmentDescription: "Our AI will analyze your domain inputs, project data, and uploaded documents to provide an objective assessment of your PMO's maturity across all domains.",
    aiAssessmentSummary: "AI Assessment Summary",
    aiAssessmentSummaryDescription: "Based on our analysis, your PMO is currently at the",
    keyStrengths: "Key Strengths",
    areasForImprovement: "Areas for Improvement",
    domainSpecificAssessment: "Domain-Specific Assessment",
    maturityProgression: "Maturity Progression",
    recommendations: "Recommendations",
    generatingReport: "Generating Report...",
    exportAssessmentReport: "Export Assessment Report",
    detailedMaturityGuide: "Detailed Maturity Guide",
    maturityModelReference: "Maturity Model Reference",
    generateAssessment: "Generate Assessment",
    generatingAssessment: "Generating Assessment...",
    generatingAssessmentDescription: "Our AI is analyzing your PMO data across all domains. This may take a few moments.",
    
  },
  
  // Domain detail page
  domain: {
    BestPractices: "Best Practices",
    backToDashboard: "Back to Dashboard",
    prevDomain: "Previous Domain",
    nextDomain: "Next Domain",
    viewDomain: "View Domain",
    progress: "Progress",
    tasks: "Tasks & Progress",
    input: "Domain Input & Analysis",
    analyzing: "Analyzing Domain Input",
    processingData: "Our AI is processing your input data...",
    inputStage: "Input",
    inputDesc: "Collect data, assess current state, and gather requirements for this domain.",
    processingStage: "Processing",
    processingDesc: "Analyze data, develop frameworks, and design solutions for this domain.",
    outputStage: "Output",
    outputDesc: "Create deliverables, implement solutions, and establish frameworks for this domain.",
    loading: "Loading domain data...",
    notFound: "Domain not found",
    provideInputFirst: "Please provide domain input data before analyzing",
    aiGeneratedAnalysis: "AI-Generated Analysis for",
    generated: "Generated",
    analysis: "Analysis",
    domainProgress: "Domain Progress (%)",
    templates: "Templates",
    downloadMarkdown: "Download Markdown",
    downloadPdf: "Download PDF",
    generatingPdf: "Generating PDF...",
    generating: "Generating...",
    allTemplates: "All Available Templates",
    markdownFormat: "Markdown",
    words: "words",
    usingTemplates: "Using These Templates",
    templateDescription: "These templates are available in Markdown and PDF formats. Markdown can be imported into document editors, project management tools, or converted to other formats. PDF files are ready for printing or sharing with stakeholders.",
    noTemplates: "No templates available for this domain",
    aiConfigTitle: "AI Analysis Configuration",
    selectDomainPrompt: "Select a domain to analyze with our advanced AI. The analysis will generate comprehensive recommendations and templates based on your organization's specific context.",
    selectDomain: "Select Domain",
    analysisDepth: "Analysis Depth",
    basic: "Basic",
    quickOverview: "Quick overview",
    standard: "Standard",
    balancedAnalysis: "Balanced analysis",
    detailed: "Detailed",
    inDepthReview: "In-depth review",
    comprehensive: "Comprehensive",
    maximumDetail: "Maximum detail",
    geminiPowered: "Gemini AI Powered Analysis",
    advancedAiDesc: "Advanced AI will analyze your inputs and generate tailored recommendations",
    startAnalysis: "Start Analysis"
  },
  
  // Project management
  project: {
    projectName: "Project Name",
    projectNamePlaceholder: "Enterprise PMO Implementation",
    description: "Description",
    descriptionPlaceholder: "Brief description of your PMO implementation project",
    budget: "Budget",
    yourProjects: "Your Projects",
    createProject: "Create Project"
  },
  
  // Sidebar
  sidebar: {
    dashboard: "Dashboard",
    pmoDomains: "PMO Domains",
    tools: "Tools & Assessment",
    resources: "Resources",
    tasks: "Tasks",
    bestPractices: "Best Practices",
    maturityAssessment: "Maturity Assessment",
    assessment: "Assessment",
  },
  
  // Auth pages
  auth: {
    copyright: "© 2025 PMO Builder using AI by Dr. Ahmed Alsenosy"
  },
  
  // Maturity levels
  maturityLevels: {
    initial: {
      label: 'Initial',
      description: 'Processes are ad hoc and chaotic.'
    },
    defined: {
      label: 'Defined',
      description: 'Processes are documented and standardized.'
    },
    managed: {
      label: 'Managed',
      description: 'Processes are measured and controlled.'
    },
    optimized: {
      label: 'Optimized',
      description: 'Focus on continuous improvement.'
    },
    innovative: {
      label: 'Innovative',
      description: 'Driving industry innovation and adaptation.'
    }
  },

  //profile page
  profile: {
    title: "Organization Profile",
    description: "Set up your organization details to personalize your PMO journey",
    organizationName: "Organization Name",
    organizationNamePlaceholder: "Enter your organization name",
    industry: "Industry",
    industryPlaceholder: "Enter your industry",
    pmoMaturityLevel: "PMO Maturity Level",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "Select the maturity level that best describes your current PMO",
    saveProfile: "Save Profile",
    cancel: "Cancel",
    initial: "Initial - Ad hoc processes",
    defined: "Defined - Basic processes established",
    managed: "Managed - Standardized processes",
    optimized: "Optimized - Continuously improving",
    notEstablished: "Not Established - No formal PMO",
  },
  
  //settings page
  settings: {
    title: "Settings",
    description: "Manage your account settings and preferences",
    personal: "Personal",
    subscription: "Subscription",
    notifications: "Notifications",
    security: "Security",
    data: "Data",
    saveProfile: "Save Profile",
    cancel: "Cancel",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "Select the maturity level that best describes your current PMO",
    organizationName: "Organization Name",
    organizationNamePlaceholder: "Enter your organization name",
    industry: "Industry",
    industryPlaceholder: "Enter your industry",
    pmoMaturityLevel: "PMO Maturity Level",
    notEstablished: "Not Established - No formal PMO",
    initial: "Initial - Ad hoc processes",
    defined: "Defined - Basic processes established",
    managed: "Managed - Standardized processes",
    optimized: "Optimized - Continuously improving",
  },

  // Resources page
  resources: {
    title: "Resources",
    noDocuments: "No documents available",
    errorLoading: "Error loading documents",
    downloadError: "Error downloading document",
    uploadNew: "Upload New Document",
    filter: "Filter Documents",
    sortBy: "Sort By",
    search: "Search Documents",
    lastModified: "Last Modified",
    fileName: "File Name",
    fileSize: "File Size",
    taskName: "Task Name",
    projectId: "Project ID"
  },
 // Help page
  help: {
    title: "Help & Support",
    description: "Learn how to use the PMO Domains Application Tool effectively",
    gettingStarted: "Getting Started",
    whatIsPmoDomainsTool: "What is the PMO Domains Tool?",
    whatIsPmoDomainsToolDescription: `The PMO Domains Application Tool helps PMO professionals apply and monitor the five key PMO domains using a structured "Inputs – Processing – Outputs" framework. The tool guides you through each domain's tasks, ensuring best practices and benchmarking against industry standards.`, 
    howToUseThisTool: "How to Use This Tool",
    howToUseThisToolDescription: "The PMO Domains Application Tool is a web-based application that helps organizations implement and improve their PMO capabilities across all domains.",
    canIExportMyData: "Can I export my data?",
    canIExportMyDataDescription: "Yes, you can export your data from the Settings page. This allows you to back up your progress or transfer it to another system.",
    canICustomizeTheToolForMyOrganization: "Can I customize the tool for my organization?",
    canICustomizeTheToolForMyOrganizationDescription: "The tool is designed to be applicable across different organizations and industries. You can add custom notes to each task to tailor it to your specific organizational context.",
    whatIfINotReadyToCompleteAllDomains: "What if I'm not ready to complete all domains?",
    whatIfINotReadyToCompleteAllDomainsDescription: "You can work on domains in any order that makes sense for your organization. The tool will track your progress across all domains, allowing you to focus on your priorities.",
    contactSupport: "Contact Support",
    contactSupportDescription: "If you need additional help or have questions about the PMO Domains Application Tool, please contact our support team.",
    supportContact: "Support Contact",
    supportContactEmail: "Email: support@pmobuilder.ai",
    supportContactPhone: "Phone: (555) 123-4567",
    supportContactHours: "Hours: Monday-Friday, 9am-5pm EST",
    startBySettingUpYourOrganizationProfile: "Start by setting up your organization profile in the Profile section",
    navigateToEachDomainUsingTheSidebarMenu: "Navigate to each domain using the sidebar menu",
    completeTasksInTheRecommendedOrder: "Complete tasks in the recommended order: Input → Processing → Output",
    markTasksAsCompleteAsYouProgress: "Mark tasks as complete as you progress",
    useTheDashboardToTrackYourOverallProgress: "Use the dashboard to track your overall progress",
    referToTheBestPracticesLibraryForGuidance: "Refer to the Best Practices Library for guidance",
    organizationalDevelopmentAndAlignment: "1. Organizational Development and Alignment",
    organizationalDevelopmentAndAlignmentDescription: "This domain focuses on aligning the PMO with organizational strategy and culture to ensure effective project management practices. It includes organizational assessment, stakeholder analysis, and developing alignment strategies.",
    strategicElementsOfThePmo: "2. Strategic Elements of the PMO",
    strategicElementsOfThePmoDescription: "This domain involves developing and implementing strategic frameworks, roadmaps, and governance structures. It includes strategic objectives review, portfolio analysis, and governance structure design.",
    pMODesignAndStructuring: "3. PMO Design and Structuring",
    pMODesignAndStructuringDescription: "This domain focuses on creating the optimal PMO structure, roles, and responsibilities to meet organizational needs. It includes requirements gathering, resource assessment, and service catalog development.",
    pMOOperationAndPerformance: "4. PMO Operation and Performance",
    pMOOperationAndPerformanceDescription: "This domain establishes operational processes, KPIs, and performance metrics for the PMO. It includes process assessment, performance metrics identification, and performance measurement systems.",
    pMOEnhancementAndEffectiveness: "5. PMO Enhancement and Effectiveness",
    pMOEnhancementAndEffectivenessDescription: "This domain focuses on continuously improving PMO services, capabilities, and value delivery. It includes maturity assessment, value delivery analysis, and continuous improvement planning.",
    frequentlyAskedQuestions: "Frequently Asked Questions",
    frequentlyAskedQuestionsDescription: "The PMO Domains Application Tool is a web-based application that helps organizations implement and improve their PMO capabilities across all domains.",
    howToAccessTemplates: "How do I access templates?",
    howToAccessTemplatesDescription: "Templates are available within specific tasks that have template resources. You can also find a collection of templates in the Best Practices Library",
    understandingTheFiveDomains: "Understanding the Five Domains",
  },
    
  subscription: {
    title: "Subscription Management",
    currentPlan: "Current Plan",
    trial: "Trial",
    cancelsAtPeriodEnd: "Cancels at period end",
    upgradePlan: "Upgrade Plan",
    manageSubscription: "Manage Subscription",
    processing: "Processing...",
    billingPeriod: "Billing Period",
    nextBillingDate: "Next Billing Date",
    paymentMethod: "Payment Method",
    projects: "Projects",
    aiAnalysis: "AI Analysis",
    storage: "Storage",
    freePlanLimitations: "Free plan limitations",
    freePlanLimitationsDescription: "You're currently on the Free plan, which has limitations on projects, AI analyses, and storage. Upgrade to Premium or Enterprise for increased limits and additional features.",
    upgradeNow: "Upgrade Now",
    upgradeToGetMore: "Upgrade to Get More",
    premiumPlanBenefits: "Premium Plan Benefits",
    upTo20Projects: "Up to 20 projects (vs. 3 on Free)",
    upTo100AiAnalyses: "100 AI analyses per month (vs. 3 on Free)",
    teamCollaboration: "Team collaboration with up to 5 users",
    prioritySupport: "Priority support",
    enterprisePlanBenefits: "Enterprise Plan Benefits",
    unlimitedProjectsAndAiAnalyses: "Unlimited projects and AI analyses",
    unlimitedTeamMembers: "Unlimited team members",
    whiteLabelingOptions: "White-labeling options",
    dedicatedSupport: "Dedicated support",
    upgradeToEnterprise: "Upgrade to Enterprise",
    unlimited: "Unlimited",
    unknown: "Unknown",
    free: "Free",
    premium: "Premium",
    enterprise: "Enterprise",
    usageAndLimits: "Usage & Limits",
    perMonth: "per month",
    mb: "MB",
    none: "None",
    creditCard: "Credit Card",
    paypal: "PayPal",
    notAvailable: "Not available",
  },
  
  //notifications
  notifications: {
    '1': {
      title: "PMO Maturity Assessment Due",
      description: "Complete your quarterly PMO maturity assessment by Friday.",
      time: "2 days ago",
    },
    '2': {
      title: "Strategic Elements Domain Updated",
      description: "New templates and resources have been added to the Strategic Elements domain.",
      time: "3 days ago",
    },
    '3': {
      title: "Team Meeting: PMO Enhancement",
      description: "Upcoming team meeting to discuss PMO Enhancement strategies.",
      time: "Tomorrow, 10:00 AM",
    },
    '4': {
      title: "New Message from Admin",
      description: "You have a new message regarding your Organization Development domain progress.",
      time: "1 week ago",
    },
    '5': {
      title: "Data Backup Complete",
      description: "Your PMO data has been successfully backed up to cloud storage.",
      time: "2 weeks ago",
    },
    title: "Notifications",
    description: "Stay updated with your PMO activities and important alerts",
    markAllAsRead: "Mark all as read",
    clearAll: "Clear all",
    markAllAsReadDescription: "Mark all notifications as read",
    clearAllDescription: "Clear all notifications",
    markAllAsReadButton: "Mark all as read",
    clearAllButton: "Clear all",
    unread: "Unread",
    all: "All",
    recentNotifications: "Recent Notifications",
    markAsUnread: "Mark as unread",
    markAsRead: "Mark as read",
    viewDetails: "View details",
    loadMore: "Load more notifications",
    customizeNotifications: "Customize how and when you receive notifications about your PMO activities",
    notificationPreferences: "Notification Preferences",
    managePreferences: "Manage Preferences",
    

  },
  // Domain names
  domains: {
    "1": {
      name: "Organizational Development and Alignment",
      description: "Aligning the PMO with organizational strategy and culture to ensure effective project management practices.",
      tasks: {
        "1-input-1": {
          stage: "input",
          title: "Assess Current Competencies",
          description: "Gather data on existing competencies through surveys, interviews, and documentation review.",
          bestPractices: [
            "Use standardized assessment tools to evaluate current competencies",
            "Collect input from multiple organizational levels",
            "Document both technical and soft skill competencies",
            "Identify competency gaps through structured assessment"
          ]
        },
        "1-input-2": {
          stage: "input",
          title: "Assess Organizational Culture",
          description: "Collect data on current organizational culture through surveys, focus groups, and stakeholder interviews.",
          bestPractices: [
            "Conduct culture assessment surveys",
            "Gather feedback from diverse organizational levels",
            "Document cultural enablers and barriers to project management",
            "Collect historical data on cultural change initiatives"
          ]
        },
        "1-input-3": {
          stage: "input",
          title: "Benchmark Against Industry Standards",
          description: "Collect industry benchmarking data and best practices for organizational alignment.",
          bestPractices: [
            "Select relevant industry benchmarks and standards",
            "Gather data from industry reports and publications",
            "Document peer organization practices",
            "Collect metrics for comparative analysis"
          ]
        },
        "1-processing-1": {
          stage: "processing",
          title: "Apply Strategic Analysis Techniques",
          description: "Use strategic analysis tools to develop an integrated strategy with risk management and implementation roadmap.",
          bestPractices: [
            "Apply SWOT analysis to identify strengths and weaknesses",
            "Use gap analysis to identify improvement areas",
            "Apply risk assessment methodologies",
            "Use roadmapping techniques for implementation planning"
          ]
        },
        "1-processing-2": {
          stage: "processing",
          title: "Apply Communication Planning Methodologies",
          description: "Use communication planning techniques to develop stakeholder-specific messaging and feedback mechanisms.",
          bestPractices: [
            "Apply stakeholder analysis techniques",
            "Use communication matrix development methods",
            "Apply message tailoring methodologies",
            "Use KPI development frameworks for communication effectiveness"
          ]
        },
        "1-processing-3": {
          stage: "processing",
          title: "Apply Charter Development Techniques",
          description: "Use charter development methodologies to define PMO scope, authority, and governance structure.",
          bestPractices: [
            "Apply scope definition techniques",
            "Use RACI matrix development methods",
            "Apply governance framework design methodologies",
            "Use authority mapping techniques"
          ],
          templates: ["PMO Charter Template", "RACI Matrix"]
        },
        "1-output-1": {
          stage: "output",
          title: "Deliver Integrated Strategy and Roadmap",
          description: "Produce and implement the integrated strategy with risk management plan and phased implementation roadmap.",
          bestPractices: [
            "Document comprehensive strategy with clear objectives",
            "Create detailed implementation roadmap with milestones",
            "Develop risk management plan with mitigation strategies",
            "Establish strategy review and update mechanisms"
          ]
        },
        "1-output-2": {
          stage: "output",
          title: "Establish PMO Vision, Values and Culture",
          description: "Implement vision statement, core values, and cultural change program with leadership engagement.",
          bestPractices: [
            "Create compelling vision statement aligned with organization",
            "Document core values with behavioral examples",
            "Implement leadership engagement activities",
            "Establish cultural reinforcement mechanisms"
          ],
          templates: ["PMO Vision Statement Template", "Cultural Change Roadmap"]
        },
        "1-output-3": {
          stage: "output",
          title: "Implement PMO Charter and Governance",
          description: "Establish and operationalize PMO charter with defined scope, authority, and governance structure.",
          bestPractices: [
            "Formalize PMO charter with executive approval",
            "Implement governance structure with clear roles",
            "Establish decision-making authorities and processes",
            "Create charter review and update mechanisms"
          ],
          templates: ["PMO Charter Document", "Governance Structure Diagram"]
        },
      },
    },
    "2": {
      name: "Strategic Framework & Governance",
      description: "Creating the optimal PMO structure, roles, and responsibilities to meet organizational needs.",
      tasks: {
        "2-input-1": {
          stage: "input",
          title: "Gather Current State Data",
          description: "Collect data on current project management operations, processes, and performance.",
          bestPractices: [
            "Conduct process documentation review",
            "Gather performance metrics and historical data",
            "Collect stakeholder feedback on current operations",
            "Document existing governance structures"
          ]
        },
        "2-input-2": {
          stage: "input",
          title: "Collect Strategic Alignment Information",
          description: "Gather organizational strategic objectives, priorities, and success criteria.",
          bestPractices: [
            "Review organizational strategic plans",
            "Collect executive leadership priorities",
            "Document business unit objectives",
            "Gather information on strategic initiatives"
          ]
        },
        "2-input-3": {
          stage: "input",
          title: "Identify Capability Requirements",
          description: "Collect data on required capabilities through stakeholder interviews and organizational needs assessment.",
          bestPractices: [
            "Conduct capability needs interviews",
            "Gather industry capability standards",
            "Document capability prioritization criteria",
            "Collect capability maturity benchmarks"
          ]
        },
        "2-processing-1": {
          stage: "processing",
          title: "Apply Mandate Development Methodology",
          description: "Use mandate development techniques to define PMO purpose, authority, and responsibilities.",
          bestPractices: [
            "Apply purpose statement development methods",
            "Use authority mapping techniques",
            "Apply responsibility definition methodologies",
            "Use stakeholder validation approaches"
          ],
          templates: ["PMO Mandate Template", "Executive Sponsorship Agreement"]
        },
        "2-processing-2": {
          stage: "processing",
          title: "Apply Charter Development Framework",
          description: "Use charter development framework to create comprehensive PMO charter with roles and governance structure.",
          bestPractices: [
            "Apply vision and mission statement techniques",
            "Use organizational structure design methods",
            "Apply role definition methodologies",
            "Use governance framework design techniques"
          ],
          templates: ["PMO Charter Template", "Governance Structure Diagram"]
        },
        "2-processing-3": {
          stage: "processing",
          title: "Apply Governance Design Methodology",
          description: "Use governance design techniques to develop decision-making processes and oversight mechanisms.",
          bestPractices: [
            "Apply decision rights mapping techniques",
            "Use escalation path design methods",
            "Apply governance body design methodologies",
            "Use governance communication planning techniques"
          ],
          templates: ["Governance Framework Template", "Decision Rights Matrix"]
        },
        "2-output-1": {
          stage: "output",
          title: "Establish PMO Mandate and Charter",
          description: "Formalize and implement PMO mandate and charter with defined purpose, authority, and responsibilities.",
          bestPractices: [
            "Obtain executive approval for mandate and charter",
            "Communicate mandate to all stakeholders",
            "Implement authority structures defined in charter",
            "Establish charter review and update process"
          ],
          templates: ["Approved PMO Mandate", "Finalized PMO Charter"]
        },
        "2-output-2": {
          stage: "output",
          title: "Implement Governance Framework",
          description: "Establish and operationalize governance framework with decision-making bodies, processes, and oversight mechanisms.",
          bestPractices: [
            "Form governance committees with clear charters",
            "Implement decision-making processes and authorities",
            "Establish governance meeting cadence and agendas",
            "Create governance documentation and reporting system"
          ],
          templates: ["Governance Committee Charter", "Decision Authority Matrix"]
        },
        "2-output-3": {
          stage: "output",
          title: "Develop Strategic Communication Plan",
          description: "Implement comprehensive communication strategy with stakeholder-specific messaging and feedback mechanisms.",
          bestPractices: [
            "Create stakeholder-specific communication materials",
            "Establish regular communication cadence",
            "Implement feedback collection mechanisms",
            "Develop communication effectiveness metrics"
          ],
          templates: ["Strategic Communication Plan", "Stakeholder Messaging Matrix"]
        },      
      }
    },
    "3": {
      name: "PMO Structure & Design",
      description: "Establishing operational processes, KPIs, and performance metrics for the PMO.",
      tasks: {
        "3-input-1": {
          stage: "input",
          title: "Gather Customer Data",
          description: "Collect data on potential PMO customers, their needs, and expectations through surveys and interviews.",
          bestPractices: [
            "Conduct customer needs assessment surveys",
            "Gather stakeholder interview data",
            "Document customer pain points and expectations",
            "Collect service prioritization information"
          ]
        },
        "3-input-2": {
          stage: "input",
          title: "Collect Service Requirement Data",
          description: "Gather detailed requirements for potential PMO services through workshops and requirements sessions.",
          bestPractices: [
            "Conduct service requirements workshops",
            "Document service level expectations",
            "Collect service prioritization criteria",
            "Gather benchmark data on similar services"
          ],
          templates: ["Service Requirements Template", "Customer Needs Assessment"]
        },
        "3-input-3": {
          stage: "input",
          title: "Assess Capability Gaps",
          description: "Collect data on current capabilities and gaps through assessment tools and stakeholder feedback.",
          bestPractices: [
            "Use capability maturity assessment tools",
            "Gather capability benchmark data",
            "Document capability prioritization criteria",
            "Collect resource availability information"
          ]
        },
        "3-processing-1": {
          stage: "processing",
          title: "Apply Persona Development Techniques",
          description: "Use persona development methodologies to create detailed customer personas with needs and expectations.",
          bestPractices: [
            "Apply customer segmentation techniques",
            "Use persona development frameworks",
            "Apply needs analysis methodologies",
            "Use journey mapping techniques"
          ]
        },
        "3-processing-2": {
          stage: "processing",
          title: "Apply Prioritization Frameworks",
          description: "Use prioritization techniques to develop framework for addressing customer needs systematically.",
          bestPractices: [
            "Apply value vs. effort prioritization matrix",
            "Use MoSCoW prioritization technique",
            "Apply weighted scoring methodologies",
            "Use impact mapping techniques"
          ]
        },
        "3-processing-3": {
          stage: "processing",
          title: "Apply Service Catalog Design Methodology",
          description: "Use service catalog design techniques to develop comprehensive service offerings with benefits and advantages.",
          bestPractices: [
            "Apply service definition frameworks",
            "Use service level definition techniques",
            "Apply value proposition development methodologies",
            "Use service categorization techniques"
          ],
          templates: ["Service Catalog Template", "Service Level Agreement Template"]
        },
        "3-output-1": {
          stage: "output",
          title: "Deliver Customer Personas and Journey Maps",
          description: "Create and distribute detailed customer personas and journey maps to guide service design and delivery.",
          bestPractices: [
            "Document comprehensive personas with needs and pain points",
            "Create visual journey maps for key customer interactions",
            "Distribute personas to all service delivery teams",
            "Establish persona update and refinement process"
          ],
          templates: ["Customer Persona Template", "Journey Map Template"]
        },
        "3-output-2": {
          stage: "output",
          title: "Implement Service Catalog and SLAs",
          description: "Launch comprehensive service catalog with service level agreements, processes, and quality standards.",
          bestPractices: [
            "Create detailed service descriptions with value propositions",
            "Establish service level metrics and targets",
            "Implement service request and delivery processes",
            "Create service catalog review and update mechanism"
          ],
          templates: ["Service Catalog Document", "SLA Documentation"]
        },
        "3-output-3": {
          stage: "output",
          title: "Establish Service Prioritization Framework",
          description: "Implement systematic approach for prioritizing and addressing customer needs and service requests.",
          bestPractices: [
            "Create prioritization criteria and scoring system",
            "Implement request intake and evaluation process",
            "Establish resource allocation based on priorities",
            "Develop priority review and adjustment mechanisms"
          ],
          templates: ["Prioritization Matrix", "Service Request Form"]
        },      
      }
    },
  }
};

// Translation keys organized by component/page
// English translations
const en = {
  // Common components
  common: {
    pleaseWait: "Please wait while we prepare your content.",
    Complete : "Complete",
    search: "Search",
    save: "Save",
    saveAssessment: "Save Assessment",
    saved: "Saved!",
    showLess: "Show less",
    showMore: "Show more",
    cancel: "Cancel",
    edit: "Edit",
    delete: "Delete",
    close: "Close",
    loading: "Loading...",
    submit: "Submit",
    active: "Active",
    back: "Back",
    spent: "Spent",
    used: "Used",
    onTrack: "On Track",
    viewDetails: "View Details",
    tasks: "Tasks",
    domains: "Domains",
    budget: "Budget",
    daysLeft: "days left",
    next: "Next",
    progress: "Progress",
    notifications: "Notifications",
    help: "Help",
    settings: "Settings",
    profile: "Profile",
    signOut: "Sign Out",
    dashboard: "Dashboard",
    export: "Export",
    import: "Import",
    share: "Share",
    days: "days",
    darkMode: "Dark Mode",
    lightMode: "Light Mode",
    confirm: "Confirm",
    remainingTokens: "Remaining Tokens"
  },
  
  // Header component
  header: {
    search: "Search...",
    myTeams: "My Teams",
    invitations: "Invitations",
    setupProfile: "Setup Profile",
    subscription: "Subscription",
    settings: "Settings",
    adminPanel: "Admin Panel",
    signOut: "Sign out",
    profile: "Profile",
  },
  
  // Dashboard page
  dashboard: {
    title: "Dashboard",
    subtitle: "Build and track your PMO across all essential domains",
    budget: "Budget",
    editDetails: "Edit Details",
    exportReport: "Export Report",
    access: "Access",
    timelineProgress: "Timeline Progress",
    budgetUtilization: "Budget Utilization",
    projectStatus: "Project Status",
    maturityAssessment: "Maturity Assessment",
    keyObjectives: "Key Objectives",
    stakeholders: "Stakeholders",
    overallProgress: "Overall Progress",
    completedTasks: "Completed Tasks",
    domainProcessComparison:"Domain Progress Comparison",
    organization: "Organization",
    industry: "Industry",
    dashboardCustomization: "Dashboard Customization",
    displayLayout: "Display Layout",
    gridView: "Grid View",
    listView: "List View",
    widgetSelection: "Widget Selection",
    assessMaturityLevel: "Assess Your Maturity Level",
    maturityLevel: "Maturity Level",
    progressOverview: "Progress Overview",
    tasksStatus: "Tasks Status",
    domains: "Domains",
    chartsAnalytics: "Charts & Analytics",
    pmoMaturityLevel: "PMO Maturity Level",
    pmoDomains: "PMO Domains",
    aiAnalysis: "Accelerate with AI",
    aiDescription: "Let our advanced AI analyze your PMO data and generate comprehensive recommendations tailored to your organization's unique needs.",
    tryAiAnalysis: "Try AI Analysis",
    viewAll: "View all",
    of: "of",
    tasksCompleted: "tasks completed",
    notSet: "Not set",
    updateProfile: "Update profile",
    viewAllTasks: "View all tasks",
    nextSteps: "Next Steps",
    uploadDocuments: "Upload documents",
    analysisDocuments: "Upload supporting documents for AI analysis",
    analysisDocumentsDesc: "Enhance AI recommendations with your organization's context",
    completePmoMaturityAssessment: "Complete a PMO Maturity Assessment",
    getInsightsAboutPmoMaturityLevel: "Get insights about your PMO's current maturity level",
    reviewPractices: "Review best practices",
    explorePractices: "Explore the best practices library for guidance",
    viewResources: "View resources",
    goToAssessment: "Go to assessment",
    objective1: "Establish PMO governance framework",
    objective2: "Develop standard methodologies",
    objective3: "Implement performance metrics",
    sampleProject: "Sample PMO Implementation",
    sampleDescription: "A sample project with pre-populated data for demonstration",
    createFirstProject: "Create Your First PMO Project",
    firstProjectDesc: "Get started by creating your first PMO implementation project. You can set up project details, track progress across domains, and generate AI-powered recommendations.",
    createSample: "Create Sample Project",
    aiFeature1: "Custom templates based on your current maturity level",
    aiFeature2: "Detailed implementation roadmaps for each domain",
    aiFeature3: "Best practices tailored to your industry and context",
    maturityRadarChart: "Maturity Radar Chart",
    higherValuesIndicateGreaterMaturity: "Higher values indicate greater maturity",
    pmoMaturityAssessment: "PMO Maturity Assessment",
    assessPmoMaturity: "Assess your PMO's maturity level across all domains to identify strengths and improvement opportunities",
    selfAssessment: "Self-Assessment",
    aiGeneratedAssessment: "AI-Generated Assessment",
    notSpecified: "Not specified",
    currentMaturityProfile: "Current Maturity Profile",
    organizationDetails: "Organization Details",
    assessmentType: "Assessment Type",
    currentMaturityProfileDescription: "Your organization's PMO is currently at the",
    currentMaturityProfileDescription2: "level. This assessment will help you identify areas for improvement and create a roadmap for advancing your PMO capabilities.",
    assessmentDate: "Assessment Date",
    selfAssessmentQuestionnaire: "Self-Assessment Questionnaire",
    selfAssessmentDescription: "Rate your PMO's maturity level for each domain. Consider your processes, documentation, measurement capabilities, and continuous improvement efforts when making your assessment.",
    documentation: "Documentation",
    metrics: "Metrics",
    minimalToNone: "Minimal to none",
    basicDocumentation: "Basic documentation",
    comprehensiveDocumentation: "Comprehensive",
    regularlyUpdated: "Regularly updated",
    leadingPractice: "Leading practice",
    adHocOrNone: "Ad-hoc or none",
    basicTracking: "Basic tracking",
    notes: "Notes (Optional)",
    notesPlaceholder: "Add any notes or context about your assessment...",
    createNew: "Create New Project",
    generateAIAssessment: "Generate an AI Assessment",
    aiAssessmentDescription: "Our AI will analyze your domain inputs, project data, and uploaded documents to provide an objective assessment of your PMO's maturity across all domains.",
    aiAssessmentSummary: "AI Assessment Summary",
    aiAssessmentSummaryDescription: "Based on our analysis, your PMO is currently at the",
    keyStrengths: "Key Strengths",
    areasForImprovement: "Areas for Improvement",
    domainSpecificAssessment: "Domain-Specific Assessment",
    maturityProgression: "Maturity Progression",
    recommendations: "Recommendations",
    generatingReport: "Generating Report...",
    exportAssessmentReport: "Export Assessment Report",
    detailedMaturityGuide: "Detailed Maturity Guide",
    maturityModelReference: "Maturity Model Reference",
    generateAssessment: "Generate Assessment",
    generatingAssessment: "Generating Assessment...",
    generatingAssessmentDescription: "Our AI is analyzing your PMO data across all domains. This may take a few moments.",
    
  },
  
  // Domain detail page
  domain: {
    BestPractices: "Best Practices",
    backToDashboard: "Back to Dashboard",
    prevDomain: "Previous Domain",
    nextDomain: "Next Domain",
    viewDomain: "View Domain",
    progress: "Progress",
    tasks: "Tasks & Progress",
    input: "Domain Input & Analysis",
    analyzing: "Analyzing Domain Input",
    processingData: "Our AI is processing your input data...",
    inputStage: "Input",
    inputDesc: "Collect data, assess current state, and gather requirements for this domain.",
    processingStage: "Processing",
    processingDesc: "Analyze data, develop frameworks, and design solutions for this domain.",
    outputStage: "Output",
    outputDesc: "Create deliverables, implement solutions, and establish frameworks for this domain.",
    loading: "Loading domain data...",
    notFound: "Domain not found",
    provideInputFirst: "Please provide domain input data before analyzing",
    aiGeneratedAnalysis: "AI-Generated Analysis for",
    generated: "Generated",
    analysis: "Analysis",
    domainProgress: "Domain Progress (%)",
    templates: "Templates",
    downloadMarkdown: "Download Markdown",
    downloadPdf: "Download PDF",
    generatingPdf: "Generating PDF...",
    generating: "Generating...",
    allTemplates: "All Available Templates",
    markdownFormat: "Markdown",
    words: "words",
    usingTemplates: "Using These Templates",
    templateDescription: "These templates are available in Markdown and PDF formats. Markdown can be imported into document editors, project management tools, or converted to other formats. PDF files are ready for printing or sharing with stakeholders.",
    noTemplates: "No templates available for this domain",
    aiConfigTitle: "AI Analysis Configuration",
    selectDomainPrompt: "Select a domain to analyze with our advanced AI. The analysis will generate comprehensive recommendations and templates based on your organization's specific context.",
    selectDomain: "Select Domain",
    analysisDepth: "Analysis Depth",
    basic: "Basic",
    quickOverview: "Quick overview",
    standard: "Standard",
    balancedAnalysis: "Balanced analysis",
    detailed: "Detailed",
    inDepthReview: "In-depth review",
    comprehensive: "Comprehensive",
    maximumDetail: "Maximum detail",
    geminiPowered: "Gemini AI Powered Analysis",
    advancedAiDesc: "Advanced AI will analyze your inputs and generate tailored recommendations",
    startAnalysis: "Start Analysis"
  },
  
  // Project management
  project: {
    projectName: "Project Name",
    projectNamePlaceholder: "Enterprise PMO Implementation",
    description: "Description",
    descriptionPlaceholder: "Brief description of your PMO implementation project",
    budget: "Budget",
    yourProjects: "Your Projects",
    createProject: "Create Project"
  },
  
  // Sidebar
  sidebar: {
    dashboard: "Dashboard",
    pmoDomains: "PMO Domains",
    tools: "Tools & Assessment",
    resources: "Resources",
    tasks: "Tasks",
    bestPractices: "Best Practices",
    maturityAssessment: "Maturity Assessment",
    assessment: "Assessment",
  },
  
  // Auth pages
  auth: {
    copyright: "© 2025 PMO Builder using AI by Dr. Ahmed Alsenosy"
  },
  
  // Maturity levels
  maturityLevels: {
    initial: {
      label: 'Initial',
      description: 'Processes are ad hoc and chaotic.'
    },
    defined: {
      label: 'Defined',
      description: 'Processes are documented and standardized.'
    },
    managed: {
      label: 'Managed',
      description: 'Processes are measured and controlled.'
    },
    optimized: {
      label: 'Optimized',
      description: 'Focus on continuous improvement.'
    },
    innovative: {
      label: 'Innovative',
      description: 'Driving industry innovation and adaptation.'
    }
  },

  //profile page
  profile: {
    title: "Organization Profile",
    description: "Set up your organization details to personalize your PMO journey",
    organizationName: "Organization Name",
    organizationNamePlaceholder: "Enter your organization name",
    industry: "Industry",
    industryPlaceholder: "Enter your industry",
    pmoMaturityLevel: "PMO Maturity Level",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "Select the maturity level that best describes your current PMO",
    saveProfile: "Save Profile",
    cancel: "Cancel",
    initial: "Initial - Ad hoc processes",
    defined: "Defined - Basic processes established",
    managed: "Managed - Standardized processes",
    optimized: "Optimized - Continuously improving",
    notEstablished: "Not Established - No formal PMO",
  },
  
  //settings page
  settings: {
    title: "Settings",
    description: "Manage your account settings and preferences",
    personal: "Personal",
    subscription: "Subscription",
    notifications: "Notifications",
    security: "Security",
    data: "Data",
    saveProfile: "Save Profile",
    cancel: "Cancel",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "Select the maturity level that best describes your current PMO",
    organizationName: "Organization Name",
    organizationNamePlaceholder: "Enter your organization name",
    industry: "Industry",
    industryPlaceholder: "Enter your industry",
    pmoMaturityLevel: "PMO Maturity Level",
    notEstablished: "Not Established - No formal PMO",
    initial: "Initial - Ad hoc processes",
    defined: "Defined - Basic processes established",
    managed: "Managed - Standardized processes",
    optimized: "Optimized - Continuously improving",
  },

  // Resources page
  resources: {
    title: "Resources",
    noDocuments: "No documents available",
    errorLoading: "Error loading documents",
    downloadError: "Error downloading document",
    uploadNew: "Upload New Document",
    filter: "Filter Documents",
    sortBy: "Sort By",
    search: "Search Documents",
    lastModified: "Last Modified",
    fileName: "File Name",
    fileSize: "File Size",
    taskName: "Task Name",
    projectId: "Project ID"
  },
 // Help page
  help: {
    title: "Help & Support",
    description: "Learn how to use the PMO Domains Application Tool effectively",
    gettingStarted: "Getting Started",
    whatIsPmoDomainsTool: "What is the PMO Domains Tool?",
    whatIsPmoDomainsToolDescription: `The PMO Domains Application Tool helps PMO professionals apply and monitor the five key PMO domains using a structured "Inputs – Processing – Outputs" framework. The tool guides you through each domain's tasks, ensuring best practices and benchmarking against industry standards.`, 
    howToUseThisTool: "How to Use This Tool",
    howToUseThisToolDescription: "The PMO Domains Application Tool is a web-based application that helps organizations implement and improve their PMO capabilities across all domains.",
    canIExportMyData: "Can I export my data?",
    canIExportMyDataDescription: "Yes, you can export your data from the Settings page. This allows you to back up your progress or transfer it to another system.",
    canICustomizeTheToolForMyOrganization: "Can I customize the tool for my organization?",
    canICustomizeTheToolForMyOrganizationDescription: "The tool is designed to be applicable across different organizations and industries. You can add custom notes to each task to tailor it to your specific organizational context.",
    whatIfINotReadyToCompleteAllDomains: "What if I'm not ready to complete all domains?",
    whatIfINotReadyToCompleteAllDomainsDescription: "You can work on domains in any order that makes sense for your organization. The tool will track your progress across all domains, allowing you to focus on your priorities.",
    contactSupport: "Contact Support",
    contactSupportDescription: "If you need additional help or have questions about the PMO Domains Application Tool, please contact our support team.",
    supportContact: "Support Contact",
    supportContactEmail: "Email: support@pmobuilder.ai",
    supportContactPhone: "Phone: (555) 123-4567",
    supportContactHours: "Hours: Monday-Friday, 9am-5pm EST",
    startBySettingUpYourOrganizationProfile: "Start by setting up your organization profile in the Profile section",
    navigateToEachDomainUsingTheSidebarMenu: "Navigate to each domain using the sidebar menu",
    completeTasksInTheRecommendedOrder: "Complete tasks in the recommended order: Input → Processing → Output",
    markTasksAsCompleteAsYouProgress: "Mark tasks as complete as you progress",
    useTheDashboardToTrackYourOverallProgress: "Use the dashboard to track your overall progress",
    referToTheBestPracticesLibraryForGuidance: "Refer to the Best Practices Library for guidance",
    organizationalDevelopmentAndAlignment: "1. Organizational Development and Alignment",
    organizationalDevelopmentAndAlignmentDescription: "This domain focuses on aligning the PMO with organizational strategy and culture to ensure effective project management practices. It includes organizational assessment, stakeholder analysis, and developing alignment strategies.",
    strategicElementsOfThePmo: "2. Strategic Elements of the PMO",
    strategicElementsOfThePmoDescription: "This domain involves developing and implementing strategic frameworks, roadmaps, and governance structures. It includes strategic objectives review, portfolio analysis, and governance structure design.",
    pMODesignAndStructuring: "3. PMO Design and Structuring",
    pMODesignAndStructuringDescription: "This domain focuses on creating the optimal PMO structure, roles, and responsibilities to meet organizational needs. It includes requirements gathering, resource assessment, and service catalog development.",
    pMOOperationAndPerformance: "4. PMO Operation and Performance",
    pMOOperationAndPerformanceDescription: "This domain establishes operational processes, KPIs, and performance metrics for the PMO. It includes process assessment, performance metrics identification, and performance measurement systems.",
    pMOEnhancementAndEffectiveness: "5. PMO Enhancement and Effectiveness",
    pMOEnhancementAndEffectivenessDescription: "This domain focuses on continuously improving PMO services, capabilities, and value delivery. It includes maturity assessment, value delivery analysis, and continuous improvement planning.",
    frequentlyAskedQuestions: "Frequently Asked Questions",
    frequentlyAskedQuestionsDescription: "The PMO Domains Application Tool is a web-based application that helps organizations implement and improve their PMO capabilities across all domains.",
    howToAccessTemplates: "How do I access templates?",
    howToAccessTemplatesDescription: "Templates are available within specific tasks that have template resources. You can also find a collection of templates in the Best Practices Library",
    understandingTheFiveDomains: "Understanding the Five Domains",
  },
    
  subscription: {
    title: "Subscription Management",
    currentPlan: "Current Plan",
    trial: "Trial",
    cancelsAtPeriodEnd: "Cancels at period end",
    upgradePlan: "Upgrade Plan",
    manageSubscription: "Manage Subscription",
    processing: "Processing...",
    billingPeriod: "Billing Period",
    nextBillingDate: "Next Billing Date",
    paymentMethod: "Payment Method",
    projects: "Projects",
    aiAnalysis: "AI Analysis",
    storage: "Storage",
    freePlanLimitations: "Free plan limitations",
    freePlanLimitationsDescription: "You're currently on the Free plan, which has limitations on projects, AI analyses, and storage. Upgrade to Premium or Enterprise for increased limits and additional features.",
    upgradeNow: "Upgrade Now",
    upgradeToGetMore: "Upgrade to Get More",
    premiumPlanBenefits: "Premium Plan Benefits",
    upTo20Projects: "Up to 20 projects (vs. 3 on Free)",
    upTo100AiAnalyses: "100 AI analyses per month (vs. 3 on Free)",
    teamCollaboration: "Team collaboration with up to 5 users",
    prioritySupport: "Priority support",
    enterprisePlanBenefits: "Enterprise Plan Benefits",
    unlimitedProjectsAndAiAnalyses: "Unlimited projects and AI analyses",
    unlimitedTeamMembers: "Unlimited team members",
    whiteLabelingOptions: "White-labeling options",
    dedicatedSupport: "Dedicated support",
    upgradeToEnterprise: "Upgrade to Enterprise",
    unlimited: "Unlimited",
    unknown: "Unknown",
    free: "Free",
    premium: "Premium",
    enterprise: "Enterprise",
    usageAndLimits: "Usage & Limits",
    perMonth: "per month",
    mb: "MB",
    none: "None",
    creditCard: "Credit Card",
    paypal: "PayPal",
    notAvailable: "Not available",
  },
  
  //notifications
  notifications: {
    '1': {
      title: "PMO Maturity Assessment Due",
      description: "Complete your quarterly PMO maturity assessment by Friday.",
      time: "2 days ago",
    },
    '2': {
      title: "Strategic Elements Domain Updated",
      description: "New templates and resources have been added to the Strategic Elements domain.",
      time: "3 days ago",
    },
    '3': {
      title: "Team Meeting: PMO Enhancement",
      description: "Upcoming team meeting to discuss PMO Enhancement strategies.",
      time: "Tomorrow, 10:00 AM",
    },
    '4': {
      title: "New Message from Admin",
      description: "You have a new message regarding your Organization Development domain progress.",
      time: "1 week ago",
    },
    '5': {
      title: "Data Backup Complete",
      description: "Your PMO data has been successfully backed up to cloud storage.",
      time: "2 weeks ago",
    },
    title: "Notifications",
    description: "Stay updated with your PMO activities and important alerts",
    markAllAsRead: "Mark all as read",
    clearAll: "Clear all",
    markAllAsReadDescription: "Mark all notifications as read",
    clearAllDescription: "Clear all notifications",
    markAllAsReadButton: "Mark all as read",
    clearAllButton: "Clear all",
    unread: "Unread",
    all: "All",
    recentNotifications: "Recent Notifications",
    markAsUnread: "Mark as unread",
    markAsRead: "Mark as read",
    viewDetails: "View details",
    loadMore: "Load more notifications",
    customizeNotifications: "Customize how and when you receive notifications about your PMO activities",
    notificationPreferences: "Notification Preferences",
    managePreferences: "Manage Preferences",
    

  },
  // Domain names
  domains: {
    "1": {
      name: "Organizational Development and Alignment",
      description: "Aligning the PMO with organizational strategy and culture to ensure effective project management practices.",
      tasks: {
        "1-input-1": {
          stage: "input",
          title: "Assess Current Competencies",
          description: "Gather data on existing competencies through surveys, interviews, and documentation review.",
          bestPractices: [
            "Use standardized assessment tools to evaluate current competencies",
            "Collect input from multiple organizational levels",
            "Document both technical and soft skill competencies",
            "Identify competency gaps through structured assessment"
          ]
        },
        "1-input-2": {
          stage: "input",
          title: "Assess Organizational Culture",
          description: "Collect data on current organizational culture through surveys, focus groups, and stakeholder interviews.",
          bestPractices: [
            "Conduct culture assessment surveys",
            "Gather feedback from diverse organizational levels",
            "Document cultural enablers and barriers to project management",
            "Collect historical data on cultural change initiatives"
          ]
        },
        "1-input-3": {
          stage: "input",
          title: "Benchmark Against Industry Standards",
          description: "Collect industry benchmarking data and best practices for organizational alignment.",
          bestPractices: [
            "Select relevant industry benchmarks and standards",
            "Gather data from industry reports and publications",
            "Document peer organization practices",
            "Collect metrics for comparative analysis"
          ]
        },
        "1-processing-1": {
          stage: "processing",
          title: "Apply Strategic Analysis Techniques",
          description: "Use strategic analysis tools to develop an integrated strategy with risk management and implementation roadmap.",
          bestPractices: [
            "Apply SWOT analysis to identify strengths and weaknesses",
            "Use gap analysis to identify improvement areas",
            "Apply risk assessment methodologies",
            "Use roadmapping techniques for implementation planning"
          ]
        },
        "1-processing-2": {
          stage: "processing",
          title: "Apply Communication Planning Methodologies",
          description: "Use communication planning techniques to develop stakeholder-specific messaging and feedback mechanisms.",
          bestPractices: [
            "Apply stakeholder analysis techniques",
            "Use communication matrix development methods",
            "Apply message tailoring methodologies",
            "Use KPI development frameworks for communication effectiveness"
          ]
        },
        "1-processing-3": {
          stage: "processing",
          title: "Apply Charter Development Techniques",
          description: "Use charter development methodologies to define PMO scope, authority, and governance structure.",
          bestPractices: [
            "Apply scope definition techniques",
            "Use RACI matrix development methods",
            "Apply governance framework design methodologies",
            "Use authority mapping techniques"
          ],
          templates: ["PMO Charter Template", "RACI Matrix"]
        },
        "1-output-1": {
          stage: "output",
          title: "Deliver Integrated Strategy and Roadmap",
          description: "Produce and implement the integrated strategy with risk management plan and phased implementation roadmap.",
          bestPractices: [
            "Document comprehensive strategy with clear objectives",
            "Create detailed implementation roadmap with milestones",
            "Develop risk management plan with mitigation strategies",
            "Establish strategy review and update mechanisms"
          ]
        },
        "1-output-2": {
          stage: "output",
          title: "Establish PMO Vision, Values and Culture",
          description: "Implement vision statement, core values, and cultural change program with leadership engagement.",
          bestPractices: [
            "Create compelling vision statement aligned with organization",
            "Document core values with behavioral examples",
            "Implement leadership engagement activities",
            "Establish cultural reinforcement mechanisms"
          ],
          templates: ["PMO Vision Statement Template", "Cultural Change Roadmap"]
        },
        "1-output-3": {
          stage: "output",
          title: "Implement PMO Charter and Governance",
          description: "Establish and operationalize PMO charter with defined scope, authority, and governance structure.",
          bestPractices: [
            "Formalize PMO charter with executive approval",
            "Implement governance structure with clear roles",
            "Establish decision-making authorities and processes",
            "Create charter review and update mechanisms"
          ],
          templates: ["PMO Charter Document", "Governance Structure Diagram"]
        },
      },
    },
    "2": {
      name: "Strategic Framework & Governance",
      description: "Creating the optimal PMO structure, roles, and responsibilities to meet organizational needs.",
      tasks: {
        "2-input-1": {
          stage: "input",
          title: "Gather Current State Data",
          description: "Collect data on current project management operations, processes, and performance.",
          bestPractices: [
            "Conduct process documentation review",
            "Gather performance metrics and historical data",
            "Collect stakeholder feedback on current operations",
            "Document existing governance structures"
          ]
        },
        "2-input-2": {
          stage: "input",
          title: "Collect Strategic Alignment Information",
          description: "Gather organizational strategic objectives, priorities, and success criteria.",
          bestPractices: [
            "Review organizational strategic plans",
            "Collect executive leadership priorities",
            "Document business unit objectives",
            "Gather information on strategic initiatives"
          ]
        },
        "2-input-3": {
          stage: "input",
          title: "Identify Capability Requirements",
          description: "Collect data on required capabilities through stakeholder interviews and organizational needs assessment.",
          bestPractices: [
            "Conduct capability needs interviews",
            "Gather industry capability standards",
            "Document capability prioritization criteria",
            "Collect capability maturity benchmarks"
          ]
        },
        "2-processing-1": {
          stage: "processing",
          title: "Apply Mandate Development Methodology",
          description: "Use mandate development techniques to define PMO purpose, authority, and responsibilities.",
          bestPractices: [
            "Apply purpose statement development methods",
            "Use authority mapping techniques",
            "Apply responsibility definition methodologies",
            "Use stakeholder validation approaches"
          ],
          templates: ["PMO Mandate Template", "Executive Sponsorship Agreement"]
        },
        "2-processing-2": {
          stage: "processing",
          title: "Apply Charter Development Framework",
          description: "Use charter development framework to create comprehensive PMO charter with roles and governance structure.",
          bestPractices: [
            "Apply vision and mission statement techniques",
            "Use organizational structure design methods",
            "Apply role definition methodologies",
            "Use governance framework design techniques"
          ],
          templates: ["PMO Charter Template", "Governance Structure Diagram"]
        },
        "2-processing-3": {
          stage: "processing",
          title: "Apply Governance Design Methodology",
          description: "Use governance design techniques to develop decision-making processes and oversight mechanisms.",
          bestPractices: [
            "Apply decision rights mapping techniques",
            "Use escalation path design methods",
            "Apply governance body design methodologies",
            "Use governance communication planning techniques"
          ],
          templates: ["Governance Framework Template", "Decision Rights Matrix"]
        },
        "2-output-1": {
          stage: "output",
          title: "Establish PMO Mandate and Charter",
          description: "Formalize and implement PMO mandate and charter with defined purpose, authority, and responsibilities.",
          bestPractices: [
            "Obtain executive approval for mandate and charter",
            "Communicate mandate to all stakeholders",
            "Implement authority structures defined in charter",
            "Establish charter review and update process"
          ],
          templates: ["Approved PMO Mandate", "Finalized PMO Charter"]
        },
        "2-output-2": {
          stage: "output",
          title: "Implement Governance Framework",
          description: "Establish and operationalize governance framework with decision-making bodies, processes, and oversight mechanisms.",
          bestPractices: [
            "Form governance committees with clear charters",
            "Implement decision-making processes and authorities",
            "Establish governance meeting cadence and agendas",
            "Create governance documentation and reporting system"
          ],
          templates: ["Governance Committee Charter", "Decision Authority Matrix"]
        },
        "2-output-3": {
          stage: "output",
          title: "Develop Strategic Communication Plan",
          description: "Implement comprehensive communication strategy with stakeholder-specific messaging and feedback mechanisms.",
          bestPractices: [
            "Create stakeholder-specific communication materials",
            "Establish regular communication cadence",
            "Implement feedback collection mechanisms",
            "Develop communication effectiveness metrics"
          ],
          templates: ["Strategic Communication Plan", "Stakeholder Messaging Matrix"]
        },      
      }
    },
    "3": {
      name: "PMO Structure & Design",
      description: "Establishing operational processes, KPIs, and performance metrics for the PMO.",
      tasks: {
        "3-input-1": {
          stage: "input",
          title: "Gather Customer Data",
          description: "Collect data on potential PMO customers, their needs, and expectations through surveys and interviews.",
          bestPractices: [
            "Conduct customer needs assessment surveys",
            "Gather stakeholder interview data",
            "Document customer pain points and expectations",
            "Collect service prioritization information"
          ]
        },
        "3-input-2": {
          stage: "input",
          title: "Collect Service Requirement Data",
          description: "Gather detailed requirements for potential PMO services through workshops and requirements sessions.",
          bestPractices: [
            "Conduct service requirements workshops",
            "Document service level expectations",
            "Collect service prioritization criteria",
            "Gather benchmark data on similar services"
          ],
          templates: ["Service Requirements Template", "Customer Needs Assessment"]
        },
        "3-input-3": {
          stage: "input",
          title: "Assess Capability Gaps",
          description: "Collect data on current capabilities and gaps through assessment tools and stakeholder feedback.",
          bestPractices: [
            "Use capability maturity assessment tools",
            "Gather capability benchmark data",
            "Document capability prioritization criteria",
            "Collect resource availability information"
          ]
        },
        "3-processing-1": {
          stage: "processing",
          title: "Apply Persona Development Techniques",
          description: "Use persona development methodologies to create detailed customer personas with needs and expectations.",
          bestPractices: [
            "Apply customer segmentation techniques",
            "Use persona development frameworks",
            "Apply needs analysis methodologies",
            "Use journey mapping techniques"
          ]
        },
        "3-processing-2": {
          stage: "processing",
          title: "Apply Prioritization Frameworks",
          description: "Use prioritization techniques to develop framework for addressing customer needs systematically.",
          bestPractices: [
            "Apply value vs. effort prioritization matrix",
            "Use MoSCoW prioritization technique",
            "Apply weighted scoring methodologies",
            "Use impact mapping techniques"
          ]
        },
        "3-processing-3": {
          stage: "processing",
          title: "Apply Service Catalog Design Methodology",
          description: "Use service catalog design techniques to develop comprehensive service offerings with benefits and advantages.",
          bestPractices: [
            "Apply service definition frameworks",
            "Use service level definition techniques",
            "Apply value proposition development methodologies",
            "Use service categorization techniques"
          ],
          templates: ["Service Catalog Template", "Service Level Agreement Template"]
        },
        "3-output-1": {
          stage: "output",
          title: "Deliver Customer Personas and Journey Maps",
          description: "Create and distribute detailed customer personas and journey maps to guide service design and delivery.",
          bestPractices: [
            "Document comprehensive personas with needs and pain points",
            "Create visual journey maps for key customer interactions",
            "Distribute personas to all service delivery teams",
            "Establish persona update and refinement process"
          ],
          templates: ["Customer Persona Template", "Journey Map Template"]
        },
        "3-output-2": {
          stage: "output",
          title: "Implement Service Catalog and SLAs",
          description: "Launch comprehensive service catalog with service level agreements, processes, and quality standards.",
          bestPractices: [
            "Create detailed service descriptions with value propositions",
            "Establish service level metrics and targets",
            "Implement service request and delivery processes",
            "Create service catalog review and update mechanism"
          ],
          templates: ["Service Catalog Document", "SLA Documentation"]
        },
        "3-output-3": {
          stage: "output",
          title: "Establish Service Prioritization Framework",
          description: "Implement systematic approach for prioritizing and addressing customer needs and service requests.",
          bestPractices: [
            "Create prioritization criteria and scoring system",
            "Implement request intake and evaluation process",
            "Establish resource allocation based on priorities",
            "Develop priority review and adjustment mechanisms"
          ],
          templates: ["Prioritization Matrix", "Service Request Form"]
        },      
      }
    },
    "4": {
      name: "Operational Excellence",
      description: "Ensuring efficient and effective project management processes and tools.",
      tasks: {
        "4-input-1": {
          stage: "input",
          title: "Gather Onboarding Requirements",
          description: "Collect requirements and expectations for customer onboarding process through stakeholder input.",
          bestPractices: [
            "Conduct onboarding needs assessment",
            "Gather stakeholder expectations for onboarding",
            "Document current onboarding challenges",
            "Collect onboarding best practices"
          ]
        },
        "4-input-2": {
          stage: "input",
          title: "Collect Documentation Requirements",
          description: "Gather requirements for process documentation, user guides, and training materials.",
          bestPractices: [
            "Conduct documentation needs assessment",
            "Gather user preferences for documentation formats",
            "Document current documentation gaps",
            "Collect documentation best practices"
          ],
          templates: ["Documentation Requirements Template", "User Guide Outline"]
        },
        "4-input-3": {
          stage: "input",
          title: "Assess Training Needs",
          description: "Collect data on training needs, preferences, and delivery methods through surveys and interviews.",
          bestPractices: [
            "Conduct training needs assessment",
            "Gather learning style preferences",
            "Document knowledge and skill gaps",
            "Collect training effectiveness criteria"
          ]
        },
        "4-processing-1": {
          stage: "processing",
          title: "Apply Quality Management Techniques",
          description: "Use quality management methodologies to develop quality control measures and improvement processes.",
          bestPractices: [
            "Apply quality standards development techniques",
            "Use quality control checkpoint design methods",
            "Apply quality metrics development frameworks",
            "Use continuous improvement methodologies"
          ]
        },
        "4-processing-2": {
          stage: "processing",
          title: "Apply Resource Management Methodologies",
          description: "Use resource management techniques to develop allocation systems and capacity planning processes.",
          bestPractices: [
            "Apply resource capacity planning techniques",
            "Use resource allocation prioritization methods",
            "Apply resource forecasting methodologies",
            "Use resource utilization optimization techniques"
          ],
          templates: ["Resource Management Plan", "Capacity Planning Template"]
        },
        "4-processing-3": {
          stage: "processing",
          title: "Apply Issue Management Framework",
          description: "Use issue management methodologies to develop escalation procedures and resolution processes.",
          bestPractices: [
            "Apply escalation threshold definition techniques",
            "Use escalation path design methods",
            "Apply issue categorization frameworks",
            "Use resolution time standard development techniques"
          ],
          templates: ["Escalation Procedure Template", "Issue Management Framework"]
        },
        "4-output-1": {
          stage: "output",
          title: "Implement Quality Management System",
          description: "Establish comprehensive quality management system with standards, control processes, and improvement mechanisms.",
          bestPractices: [
            "Document quality standards for all services",
            "Implement quality control checkpoints and reviews",
            "Establish quality metrics collection and reporting",
            "Create continuous quality improvement process"
          ],
          templates: ["Quality Standards Document", "Quality Review Checklist"]
        },
        "4-output-2": {
          stage: "output",
          title: "Establish Resource Management System",
          description: "Implement resource management system with capacity planning, allocation processes, and utilization tracking.",
          bestPractices: [
            "Create resource inventory and skills matrix",
            "Implement capacity planning and forecasting process",
            "Establish resource allocation and assignment procedures",
            "Develop resource utilization tracking and reporting"
          ],
          templates: ["Resource Allocation Matrix", "Capacity Planning Dashboard"]
        },
        "4-output-3": {
          stage: "output",
          title: "Deploy Issue Management System",
          description: "Implement comprehensive issue management system with escalation procedures, tracking, and resolution processes.",
          bestPractices: [
            "Establish issue intake and categorization process",
            "Implement escalation paths and notification system",
            "Create issue tracking and status reporting",
            "Develop resolution verification and closure procedures"
          ],
          templates: ["Issue Management Playbook", "Escalation Matrix"]
        },      
      }
    },
    "5": {
      name: "Performance & Improvement",
      description: "Continuously improving PMO services, capabilities, and value delivery.",
      tasks: {
        "5-input-1": {
          stage: "input",
          title: "Gather Maturity Assessment Data",
          description: "Collect data on current PMO maturity through assessment tools, surveys, and stakeholder feedback.",
          bestPractices: [
            "Select appropriate maturity assessment tool",
            "Gather comprehensive assessment data",
            "Document maturity baseline across dimensions",
            "Collect maturity target information"
          ]
        },
        "5-input-2": {
          stage: "input",
          title: "Collect Performance Data",
          description: "Gather current performance metrics, historical trends, and performance targets.",
          bestPractices: [
            "Collect current performance metrics",
            "Gather historical performance data",
            "Document performance targets and thresholds",
            "Collect performance benchmark information"
          ]
        },
        "5-input-3": {
          stage: "input",
          title: "Assess Value Measurement Approaches",
          description: "Collect data on potential value metrics, measurement approaches, and value demonstration methods.",
          bestPractices: [
            "Gather value metric options",
            "Collect value measurement methodologies",
            "Document value perception from stakeholders",
            "Assess current value demonstration approaches"
          ]
        },
        "5-processing-1": {
          stage: "processing",
          title: "Apply Maturity Roadmapping Techniques",
          description: "Use maturity roadmapping methodologies to develop enhancement plan with milestones and metrics.",
          bestPractices: [
            "Apply maturity gap analysis techniques",
            "Use capability prioritization methods",
            "Apply milestone development frameworks",
            "Use metric definition techniques"
          ]
        },
        "5-processing-2": {
          stage: "processing",
          title: "Apply Change Management Methodologies",
          description: "Use change management techniques to develop implementation approach for maturity initiatives.",
          bestPractices: [
            "Apply stakeholder impact analysis techniques",
            "Use resistance management methods",
            "Apply communication planning frameworks",
            "Use adoption measurement techniques"
          ],
          templates: ["Change Management Plan", "Stakeholder Engagement Plan"]
        },
        "5-processing-3": {
          stage: "processing",
          title: "Apply Continuous Improvement Frameworks",
          description: "Use continuous improvement methodologies to develop systematic improvement processes.",
          bestPractices: [
            "Apply improvement opportunity identification techniques",
            "Use improvement prioritization methods",
            "Apply implementation planning frameworks",
            "Use effectiveness measurement techniques"
          ]
        },
        "5-output-1": {
          stage: "output",
          title: "Implement Maturity Enhancement Roadmap",
          description: "Establish and execute comprehensive maturity enhancement roadmap with milestones, metrics, and review processes.",
          bestPractices: [
            "Document detailed maturity enhancement plan",
            "Implement milestone tracking and reporting",
            "Establish maturity metric collection and analysis",
            "Create regular maturity review and adjustment process"
          ],
          templates: ["Maturity Enhancement Roadmap", "Maturity Metrics Dashboard"]
        },
        "5-output-2": {
          stage: "output",
          title: "Establish Value Measurement System",
          description: "Implement comprehensive value measurement system with metrics, reporting, and demonstration mechanisms.",
          bestPractices: [
            "Define and implement value metrics and KPIs",
            "Create value data collection and analysis process",
            "Establish value reporting and visualization",
            "Develop value demonstration case studies"
          ],
          templates: ["Value Measurement Framework", "Value Dashboard"]
        },
        "5-output-3": {
          stage: "output",
          title: "Deploy Continuous Improvement Program",
          description: "Implement systematic continuous improvement program with identification, prioritization, and implementation processes.",
          bestPractices: [
            "Establish improvement opportunity identification process",
            "Create improvement prioritization and selection system",
            "Implement improvement tracking and reporting",
            "Develop improvement effectiveness measurement"
          ],
          templates: ["Continuous Improvement Playbook", "Improvement Tracking System"]
        },      
      }
    },
    "6": {
      name: "Capability Development",
      description: "Developing and managing the human aspects of the PMO including competency, training, and leadership.",
      tasks: {
        "6-input-1": {
          stage: "input",
          title: "Gather Decision-Making Data",
          description: "Collect data on current decision-making processes, data utilization, and improvement opportunities.",
          bestPractices: [
            "Document current decision-making processes",
            "Assess data utilization in decisions",
            "Identify decision-making bottlenecks",
            "Gather decision quality metrics"
          ]
        },
        "6-input-2": {
          stage: "input",
          title: "Assess Competency Requirements",
          description: "Collect data on required competencies, current capabilities, and development needs.",
          bestPractices: [
            "Document role-specific competency requirements",
            "Assess current competency levels",
            "Identify critical competency gaps",
            "Gather development preference information"
          ],
          templates: ["Competency Assessment Template", "Development Needs Analysis"]
        },
        "6-input-3": {
          stage: "input",
          title: "Collect Skills Assessment Data",
          description: "Gather comprehensive skills data through assessments, self-evaluations, and manager feedback.",
          bestPractices: [
            "Use standardized skills assessment tools",
            "Gather self-assessment data",
            "Collect manager assessment input",
            "Document skills prioritization criteria"
          ]
        },
        "6-processing-1": {
          stage: "processing",
          title: "Apply Training Program Design Methodology",
          description: "Use training design techniques to develop comprehensive training and certification programs.",
          bestPractices: [
            "Apply learning objective development techniques",
            "Use curriculum design methodologies",
            "Apply learning modality selection frameworks",
            "Use training effectiveness measurement design"
          ]
        },
        "6-processing-2": {
          stage: "processing",
          title: "Apply Innovation Framework Development",
          description: "Use innovation framework techniques to develop processes for fostering innovation and problem-solving.",
          bestPractices: [
            "Apply innovation process design methodologies",
            "Use idea generation technique selection",
            "Apply idea evaluation framework development",
            "Use innovation incentive system design"
          ]
        },
        "6-processing-3": {
          stage: "processing",
          title: "Apply Knowledge Management Techniques",
          description: "Use knowledge management methodologies to design knowledge-sharing platform and communities of practice.",
          bestPractices: [
            "Apply knowledge repository design techniques",
            "Use knowledge categorization frameworks",
            "Apply community of practice design methodologies",
            "Use knowledge contribution incentive design"
          ]
        },
        "6-output-1": {
          stage: "output",
          title: "Implement Competency Development Framework",
          description: "Establish comprehensive competency framework with assessment, development paths, and certification programs.",
          bestPractices: [
            "Document role-specific competency requirements",
            "Create competency assessment and tracking system",
            "Implement development paths for each competency area",
            "Establish certification and recognition program"
          ],
          templates: ["Competency Framework Document", "Development Path Guide"]
        },
        "6-output-2": {
          stage: "output",
          title: "Deploy Innovation and Problem-Solving System",
          description: "Implement structured innovation program with idea generation, evaluation, and implementation processes.",
          bestPractices: [
            "Establish idea generation and collection system",
            "Create idea evaluation and selection process",
            "Implement innovation implementation support",
            "Develop innovation recognition and incentives"
          ],
          templates: ["Innovation Process Playbook", "Idea Evaluation Matrix"]
        },
        "6-output-3": {
          stage: "output",
          title: "Establish Knowledge Management System",
          description: "Implement comprehensive knowledge management system with repository, sharing mechanisms, and communities of practice.",
          bestPractices: [
            "Create knowledge repository with categorization system",
            "Establish knowledge contribution processes",
            "Form communities of practice with clear charters",
            "Implement knowledge sharing events and activities"
          ],
          templates: ["Knowledge Management Guide", "Community of Practice Charter"]
        }
      }
    }
  },

  // Tasks
  tasks: {
    tasks: "Tasks",
    manageAndTrackYourPmoImplementationTasks: "Manage and track your PMO implementation tasks",
    allTasks: "All Tasks",
    completed: "Completed",
    incomplete: "Incomplete",
    progress: "Progress",
    total: "Total",
    rate: "Rate",
    addCustomTask: "Add Custom Task",
    searchTasks: "Search tasks...",
    filters: "Filters",
    clear: "Clear",
    allDomains: "All Domains",
    allStages: "All Stages",
    input: "Input",
    processing: "Processing",
    output: "Output",
    domain: "Domain",
    stage: "Stage",
    status: "Status",
    clearFilters: "Clear Filters",
    noTasksFound: "No tasks found",
    noTasksMatchFilters: "No tasks match your current filters. Try adjusting or clearing your filters.",
    noTasksAvailable: "No tasks available. Start by creating a new task.",
    taskManagementTips: "Task Management Tips",
    taskManagementTipsDescription: "Prioritize tasks based on your PMO maturity level and organizational goals. Complete the Input stage tasks first before moving to Processing and Output stages for the best results.",
    viewBestPractices: "View Best Practices",
    relatedDocuments: "Related Documents",
    viewFullContent: "View Full Content",
    generateTaskOutput: "Generate Task Output",
    templates: "Templates",
    templateForStandardizedImplementation: "Template for standardized implementation",
    viewTemplate: "View Template",
    bestPractices: "Best Practices",
    priority: "Priority",
    targetCompletionDate: "Target Completion Date",
    assignedTo: "Assigned To",
    estimatedHours: "Estimated Hours",
    attachments: "Attachments",
    notes: "Notes",
    availableTemplates: "Available Templates",
    purpose: "Purpose",
    templateForStandardized: "This template provides a structured framework for implementing and managing",
    withinYourPMO: "processes within your PMO",
    overview: "Overview",
    download: "Download",
    useTemplate: "Use Template",
    close: "Close",
    save:"Save",
    template: `
## Template Sections

### 1. Introduction
- Purpose and objectives
- Scope and applicability
- Key stakeholders

### 2. Process Framework
- Methodology overview
- Key activities and deliverables
- Roles and responsibilities

### 3. Implementation Guide
- Step-by-step instructions
- Best practices and guidelines
- Common challenges and solutions

### 4. Monitoring and Control
- Key performance indicators
- Quality assurance measures
- Reporting requirements

### 5. Continuous Improvement
- Feedback mechanisms
- Review process
- Update procedures

## Appendices
- Related templates and tools
- Reference materials
- Glossary of terms

---

*This template is part of the PMO Builder library. Customize it to fit your organization's specific needs.*`,
  }
};

// Translation keys organized by component/page
// English translations
const en = {
  // Common components
  common: {
    pleaseWait: "Please wait while we prepare your content.",
    Complete : "Complete",
    search: "Search",
    save: "Save",
    saveAssessment: "Save Assessment",
    saved: "Saved!",
    showLess: "Show less",
    showMore: "Show more",
    cancel: "Cancel",
    edit: "Edit",
    delete: "Delete",
    close: "Close",
    loading: "Loading...",
    submit: "Submit",
    active: "Active",
    back: "Back",
    spent: "Spent",
    used: "Used",
    onTrack: "On Track",
    viewDetails: "View Details",
    tasks: "Tasks",
    domains: "Domains",
    budget: "Budget",
    daysLeft: "days left",
    next: "Next",
    progress: "Progress",
    notifications: "Notifications",
    help: "Help",
    settings: "Settings",
    profile: "Profile",
    signOut: "Sign Out",
    dashboard: "Dashboard",
    export: "Export",
    import: "Import",
    share: "Share",
    days: "days",
    darkMode: "Dark Mode",
    lightMode: "Light Mode",
    confirm: "Confirm",
    remainingTokens: "Remaining Tokens"
  },
  
  // Header component
  header: {
    search: "Search...",
    myTeams: "My Teams",
    invitations: "Invitations",
    setupProfile: "Setup Profile",
    subscription: "Subscription",
    settings: "Settings",
    adminPanel: "Admin Panel",
    signOut: "Sign out",
    profile: "Profile",
  },
  
  // Dashboard page
  dashboard: {
    title: "Dashboard",
    subtitle: "Build and track your PMO across all essential domains",
    budget: "Budget",
    editDetails: "Edit Details",
    exportReport: "Export Report",
    access: "Access",
    timelineProgress: "Timeline Progress",
    budgetUtilization: "Budget Utilization",
    projectStatus: "Project Status",
    maturityAssessment: "Maturity Assessment",
    keyObjectives: "Key Objectives",
    stakeholders: "Stakeholders",
    overallProgress: "Overall Progress",
    completedTasks: "Completed Tasks",
    domainProcessComparison:"Domain Progress Comparison",
    organization: "Organization",
    industry: "Industry",
    dashboardCustomization: "Dashboard Customization",
    displayLayout: "Display Layout",
    gridView: "Grid View",
    listView: "List View",
    widgetSelection: "Widget Selection",
    assessMaturityLevel: "Assess Your Maturity Level",
    maturityLevel: "Maturity Level",
    progressOverview: "Progress Overview",
    tasksStatus: "Tasks Status",
    domains: "Domains",
    chartsAnalytics: "Charts & Analytics",
    pmoMaturityLevel: "PMO Maturity Level",
    pmoDomains: "PMO Domains",
    aiAnalysis: "Accelerate with AI",
    aiDescription: "Let our advanced AI analyze your PMO data and generate comprehensive recommendations tailored to your organization's unique needs.",
    tryAiAnalysis: "Try AI Analysis",
    viewAll: "View all",
    of: "of",
    tasksCompleted: "tasks completed",
    notSet: "Not set",
    updateProfile: "Update profile",
    viewAllTasks: "View all tasks",
    nextSteps: "Next Steps",
    uploadDocuments: "Upload documents",
    analysisDocuments: "Upload supporting documents for AI analysis",
    analysisDocumentsDesc: "Enhance AI recommendations with your organization's context",
    completePmoMaturityAssessment: "Complete a PMO Maturity Assessment",
    getInsightsAboutPmoMaturityLevel: "Get insights about your PMO's current maturity level",
    reviewPractices: "Review best practices",
    explorePractices: "Explore the best practices library for guidance",
    viewResources: "View resources",
    goToAssessment: "Go to assessment",
    objective1: "Establish PMO governance framework",
    objective2: "Develop standard methodologies",
    objective3: "Implement performance metrics",
    sampleProject: "Sample PMO Implementation",
    sampleDescription: "A sample project with pre-populated data for demonstration",
    createFirstProject: "Create Your First PMO Project",
    firstProjectDesc: "Get started by creating your first PMO implementation project. You can set up project details, track progress across domains, and generate AI-powered recommendations.",
    createSample: "Create Sample Project",
    aiFeature1: "Custom templates based on your current maturity level",
    aiFeature2: "Detailed implementation roadmaps for each domain",
    aiFeature3: "Best practices tailored to your industry and context",
    maturityRadarChart: "Maturity Radar Chart",
    higherValuesIndicateGreaterMaturity: "Higher values indicate greater maturity",
    pmoMaturityAssessment: "PMO Maturity Assessment",
    assessPmoMaturity: "Assess your PMO's maturity level across all domains to identify strengths and improvement opportunities",
    selfAssessment: "Self-Assessment",
    aiGeneratedAssessment: "AI-Generated Assessment",
    notSpecified: "Not specified",
    currentMaturityProfile: "Current Maturity Profile",
    organizationDetails: "Organization Details",
    assessmentType: "Assessment Type",
    currentMaturityProfileDescription: "Your organization's PMO is currently at the",
    currentMaturityProfileDescription2: "level. This assessment will help you identify areas for improvement and create a roadmap for advancing your PMO capabilities.",
    assessmentDate: "Assessment Date",
    selfAssessmentQuestionnaire: "Self-Assessment Questionnaire",
    selfAssessmentDescription: "Rate your PMO's maturity level for each domain. Consider your processes, documentation, measurement capabilities, and continuous improvement efforts when making your assessment.",
    documentation: "Documentation",
    metrics: "Metrics",
    minimalToNone: "Minimal to none",
    basicDocumentation: "Basic documentation",
    comprehensiveDocumentation: "Comprehensive",
    regularlyUpdated: "Regularly updated",
    leadingPractice: "Leading practice",
    adHocOrNone: "Ad-hoc or none",
    basicTracking: "Basic tracking",
    notes: "Notes (Optional)",
    notesPlaceholder: "Add any notes or context about your assessment...",
    createNew: "Create New Project",
    generateAIAssessment: "Generate an AI Assessment",
    aiAssessmentDescription: "Our AI will analyze your domain inputs, project data, and uploaded documents to provide an objective assessment of your PMO's maturity across all domains.",
    aiAssessmentSummary: "AI Assessment Summary",
    aiAssessmentSummaryDescription: "Based on our analysis, your PMO is currently at the",
    keyStrengths: "Key Strengths",
    areasForImprovement: "Areas for Improvement",
    domainSpecificAssessment: "Domain-Specific Assessment",
    maturityProgression: "Maturity Progression",
    recommendations: "Recommendations",
    generatingReport: "Generating Report...",
    exportAssessmentReport: "Export Assessment Report",
    detailedMaturityGuide: "Detailed Maturity Guide",
    maturityModelReference: "Maturity Model Reference",
    generateAssessment: "Generate Assessment",
    generatingAssessment: "Generating Assessment...",
    generatingAssessmentDescription: "Our AI is analyzing your PMO data across all domains. This may take a few moments.",
    
  },
  
  // Domain detail page
  domain: {
    BestPractices: "Best Practices",
    backToDashboard: "Back to Dashboard",
    prevDomain: "Previous Domain",
    nextDomain: "Next Domain",
    viewDomain: "View Domain",
    progress: "Progress",
    tasks: "Tasks & Progress",
    input: "Domain Input & Analysis",
    analyzing: "Analyzing Domain Input",
    processingData: "Our AI is processing your input data...",
    inputStage: "Input",
    inputDesc: "Collect data, assess current state, and gather requirements for this domain.",
    processingStage: "Processing",
    processingDesc: "Analyze data, develop frameworks, and design solutions for this domain.",
    outputStage: "Output",
    outputDesc: "Create deliverables, implement solutions, and establish frameworks for this domain.",
    loading: "Loading domain data...",
    notFound: "Domain not found",
    provideInputFirst: "Please provide domain input data before analyzing",
    aiGeneratedAnalysis: "AI-Generated Analysis for",
    generated: "Generated",
    analysis: "Analysis",
    domainProgress: "Domain Progress (%)",
    templates: "Templates",
    downloadMarkdown: "Download Markdown",
    downloadPdf: "Download PDF",
    generatingPdf: "Generating PDF...",
    generating: "Generating...",
    allTemplates: "All Available Templates",
    markdownFormat: "Markdown",
    words: "words",
    usingTemplates: "Using These Templates",
    templateDescription: "These templates are available in Markdown and PDF formats. Markdown can be imported into document editors, project management tools, or converted to other formats. PDF files are ready for printing or sharing with stakeholders.",
    noTemplates: "No templates available for this domain",
    aiConfigTitle: "AI Analysis Configuration",
    selectDomainPrompt: "Select a domain to analyze with our advanced AI. The analysis will generate comprehensive recommendations and templates based on your organization's specific context.",
    selectDomain: "Select Domain",
    analysisDepth: "Analysis Depth",
    basic: "Basic",
    quickOverview: "Quick overview",
    standard: "Standard",
    balancedAnalysis: "Balanced analysis",
    detailed: "Detailed",
    inDepthReview: "In-depth review",
    comprehensive: "Comprehensive",
    maximumDetail: "Maximum detail",
    geminiPowered: "Gemini AI Powered Analysis",
    advancedAiDesc: "Advanced AI will analyze your inputs and generate tailored recommendations",
    startAnalysis: "Start Analysis"
  },
  
  // Project management
  project: {
    projectName: "Project Name",
    projectNamePlaceholder: "Enterprise PMO Implementation",
    description: "Description",
    descriptionPlaceholder: "Brief description of your PMO implementation project",
    budget: "Budget",
    yourProjects: "Your Projects",
    createProject: "Create Project"
  },
  
  // Sidebar
  sidebar: {
    dashboard: "Dashboard",
    pmoDomains: "PMO Domains",
    tools: "Tools & Assessment",
    resources: "Resources",
    tasks: "Tasks",
    bestPractices: "Best Practices",
    maturityAssessment: "Maturity Assessment",
    assessment: "Assessment",
  },
  
  // Auth pages
  auth: {
    copyright: "© 2025 PMO Builder using AI by Dr. Ahmed Alsenosy"
  },
  
  // Maturity levels
  maturityLevels: {
    initial: {
      label: 'Initial',
      description: 'Processes are ad hoc and chaotic.'
    },
    defined: {
      label: 'Defined',
      description: 'Processes are documented and standardized.'
    },
    managed: {
      label: 'Managed',
      description: 'Processes are measured and controlled.'
    },
    optimized: {
      label: 'Optimized',
      description: 'Focus on continuous improvement.'
    },
    innovative: {
      label: 'Innovative',
      description: 'Driving industry innovation and adaptation.'
    }
  },

  //profile page
  profile: {
    title: "Organization Profile",
    description: "Set up your organization details to personalize your PMO journey",
    organizationName: "Organization Name",
    organizationNamePlaceholder: "Enter your organization name",
    industry: "Industry",
    industryPlaceholder: "Enter your industry",
    pmoMaturityLevel: "PMO Maturity Level",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "Select the maturity level that best describes your current PMO",
    saveProfile: "Save Profile",
    cancel: "Cancel",
    initial: "Initial - Ad hoc processes",
    defined: "Defined - Basic processes established",
    managed: "Managed - Standardized processes",
    optimized: "Optimized - Continuously improving",
    notEstablished: "Not Established - No formal PMO",
  },
  
  //settings page
  settings: {
    title: "Settings",
    description: "Manage your account settings and preferences",
    personal: "Personal",
    subscription: "Subscription",
    notifications: "Notifications",
    security: "Security",
    data: "Data",
    saveProfile: "Save Profile",
    cancel: "Cancel",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "Select the maturity level that best describes your current PMO",
    organizationName: "Organization Name",
    organizationNamePlaceholder: "Enter your organization name",
    industry: "Industry",
    industryPlaceholder: "Enter your industry",
    pmoMaturityLevel: "PMO Maturity Level",
    notEstablished: "Not Established - No formal PMO",
    initial: "Initial - Ad hoc processes",
    defined: "Defined - Basic processes established",
    managed: "Managed - Standardized processes",
    optimized: "Optimized - Continuously improving",
  },

  // Resources page
  resources: {
    title: "Resources",
    noDocuments: "No documents available",
    errorLoading: "Error loading documents",
    downloadError: "Error downloading document",
    uploadNew: "Upload New Document",
    filter: "Filter Documents",
    sortBy: "Sort By",
    search: "Search Documents",
    lastModified: "Last Modified",
    fileName: "File Name",
    fileSize: "File Size",
    taskName: "Task Name",
    projectId: "Project ID"
  },
 // Help page
  help: {
    title: "Help & Support",
    description: "Learn how to use the PMO Domains Application Tool effectively",
    gettingStarted: "Getting Started",
    whatIsPmoDomainsTool: "What is the PMO Domains Tool?",
    whatIsPmoDomainsToolDescription: `The PMO Domains Application Tool helps PMO professionals apply and monitor the five key PMO domains using a structured "Inputs – Processing – Outputs" framework. The tool guides you through each domain's tasks, ensuring best practices and benchmarking against industry standards.`, 
    howToUseThisTool: "How to Use This Tool",
    howToUseThisToolDescription: "The PMO Domains Application Tool is a web-based application that helps organizations implement and improve their PMO capabilities across all domains.",
    canIExportMyData: "Can I export my data?",
    canIExportMyDataDescription: "Yes, you can export your data from the Settings page. This allows you to back up your progress or transfer it to another system.",
    canICustomizeTheToolForMyOrganization: "Can I customize the tool for my organization?",
    canICustomizeTheToolForMyOrganizationDescription: "The tool is designed to be applicable across different organizations and industries. You can add custom notes to each task to tailor it to your specific organizational context.",
    whatIfINotReadyToCompleteAllDomains: "What if I'm not ready to complete all domains?",
    whatIfINotReadyToCompleteAllDomainsDescription: "You can work on domains in any order that makes sense for your organization. The tool will track your progress across all domains, allowing you to focus on your priorities.",
    contactSupport: "Contact Support",
    contactSupportDescription: "If you need additional help or have questions about the PMO Domains Application Tool, please contact our support team.",
    supportContact: "Support Contact",
    supportContactEmail: "Email: support@pmobuilder.ai",
    supportContactPhone: "Phone: (555) 123-4567",
    supportContactHours: "Hours: Monday-Friday, 9am-5pm EST",
    startBySettingUpYourOrganizationProfile: "Start by setting up your organization profile in the Profile section",
    navigateToEachDomainUsingTheSidebarMenu: "Navigate to each domain using the sidebar menu",
    completeTasksInTheRecommendedOrder: "Complete tasks in the recommended order: Input → Processing → Output",
    markTasksAsCompleteAsYouProgress: "Mark tasks as complete as you progress",
    useTheDashboardToTrackYourOverallProgress: "Use the dashboard to track your overall progress",
    referToTheBestPracticesLibraryForGuidance: "Refer to the Best Practices Library for guidance",
    organizationalDevelopmentAndAlignment: "1. Organizational Development and Alignment",
    organizationalDevelopmentAndAlignmentDescription: "This domain focuses on aligning the PMO with organizational strategy and culture to ensure effective project management practices. It includes organizational assessment, stakeholder analysis, and developing alignment strategies.",
    strategicElementsOfThePmo: "2. Strategic Elements of the PMO",
    strategicElementsOfThePmoDescription: "This domain involves developing and implementing strategic frameworks, roadmaps, and governance structures. It includes strategic objectives review, portfolio analysis, and governance structure design.",
    pMODesignAndStructuring: "3. PMO Design and Structuring",
    pMODesignAndStructuringDescription: "This domain focuses on creating the optimal PMO structure, roles, and responsibilities to meet organizational needs. It includes requirements gathering, resource assessment, and service catalog development.",
    pMOOperationAndPerformance: "4. PMO Operation and Performance",
    pMOOperationAndPerformanceDescription: "This domain establishes operational processes, KPIs, and performance metrics for the PMO. It includes process assessment, performance metrics identification, and performance measurement systems.",
    pMOEnhancementAndEffectiveness: "5. PMO Enhancement and Effectiveness",
    pMOEnhancementAndEffectivenessDescription: "This domain focuses on continuously improving PMO services, capabilities, and value delivery. It includes maturity assessment, value delivery analysis, and continuous improvement planning.",
    frequentlyAskedQuestions: "Frequently Asked Questions",
    frequentlyAskedQuestionsDescription: "The PMO Domains Application Tool is a web-based application that helps organizations implement and improve their PMO capabilities across all domains.",
    howToAccessTemplates: "How do I access templates?",
    howToAccessTemplatesDescription: "Templates are available within specific tasks that have template resources. You can also find a collection of templates in the Best Practices Library",
    understandingTheFiveDomains: "Understanding the Five Domains",
  },
    
  subscription: {
    title: "Subscription Management",
    currentPlan: "Current Plan",
    trial: "Trial",
    cancelsAtPeriodEnd: "Cancels at period end",
    upgradePlan: "Upgrade Plan",
    manageSubscription: "Manage Subscription",
    processing: "Processing...",
    billingPeriod: "Billing Period",
    nextBillingDate: "Next Billing Date",
    paymentMethod: "Payment Method",
    projects: "Projects",
    aiAnalysis: "AI Analysis",
    storage: "Storage",
    freePlanLimitations: "Free plan limitations",
    freePlanLimitationsDescription: "You're currently on the Free plan, which has limitations on projects, AI analyses, and storage. Upgrade to Premium or Enterprise for increased limits and additional features.",
    upgradeNow: "Upgrade Now",
    upgradeToGetMore: "Upgrade to Get More",
    premiumPlanBenefits: "Premium Plan Benefits",
    upTo20Projects: "Up to 20 projects (vs. 3 on Free)",
    upTo100AiAnalyses: "100 AI analyses per month (vs. 3 on Free)",
    teamCollaboration: "Team collaboration with up to 5 users",
    prioritySupport: "Priority support",
    enterprisePlanBenefits: "Enterprise Plan Benefits",
    unlimitedProjectsAndAiAnalyses: "Unlimited projects and AI analyses",
    unlimitedTeamMembers: "Unlimited team members",
    whiteLabelingOptions: "White-labeling options",
    dedicatedSupport: "Dedicated support",
    upgradeToEnterprise: "Upgrade to Enterprise",
    unlimited: "Unlimited",
    unknown: "Unknown",
    free: "Free",
    premium: "Premium",
    enterprise: "Enterprise",
    usageAndLimits: "Usage & Limits",
    perMonth: "per month",
    mb: "MB",
    none: "None",
    creditCard: "Credit Card",
    paypal: "PayPal",
    notAvailable: "Not available",
  },
  
  //notifications
  notifications: {
    '1': {
      title: "PMO Maturity Assessment Due",
      description: "Complete your quarterly PMO maturity assessment by Friday.",
      time: "2 days ago",
    },
    '2': {
      title: "Strategic Elements Domain Updated",
      description: "New templates and resources have been added to the Strategic Elements domain.",
      time: "3 days ago",
    },
    '3': {
      title: "Team Meeting: PMO Enhancement",
      description: "Upcoming team meeting to discuss PMO Enhancement strategies.",
      time: "Tomorrow, 10:00 AM",
    },
    '4': {
      title: "New Message from Admin",
      description: "You have a new message regarding your Organization Development domain progress.",
      time: "1 week ago",
    },
    '5': {
      title: "Data Backup Complete",
      description: "Your PMO data has been successfully backed up to cloud storage.",
      time: "2 weeks ago",
    },
    title: "Notifications",
    description: "Stay updated with your PMO activities and important alerts",
    markAllAsRead: "Mark all as read",
    clearAll: "Clear all",
    markAllAsReadDescription: "Mark all notifications as read",
    clearAllDescription: "Clear all notifications",
    markAllAsReadButton: "Mark all as read",
    clearAllButton: "Clear all",
    unread: "Unread",
    all: "All",
    recentNotifications: "Recent Notifications",
    markAsUnread: "Mark as unread",
    markAsRead: "Mark as read",
    viewDetails: "View details",
    loadMore: "Load more notifications",
    customizeNotifications: "Customize how and when you receive notifications about your PMO activities",
    notificationPreferences: "Notification Preferences",
    managePreferences: "Manage Preferences",
    

  },
  // Domain names
  domains: {
    "1": {
      name: "Organizational Development and Alignment",
      description: "Aligning the PMO with organizational strategy and culture to ensure effective project management practices.",
      tasks: {
        "1-input-1": {
          stage: "input",
          title: "Assess Current Competencies",
          description: "Gather data on existing competencies through surveys, interviews, and documentation review.",
          bestPractices: [
            "Use standardized assessment tools to evaluate current competencies",
            "Collect input from multiple organizational levels",
            "Document both technical and soft skill competencies",
            "Identify competency gaps through structured assessment"
          ]
        },
        "1-input-2": {
          stage: "input",
          title: "Assess Organizational Culture",
          description: "Collect data on current organizational culture through surveys, focus groups, and stakeholder interviews.",
          bestPractices: [
            "Conduct culture assessment surveys",
            "Gather feedback from diverse organizational levels",
            "Document cultural enablers and barriers to project management",
            "Collect historical data on cultural change initiatives"
          ]
        },
        "1-input-3": {
          stage: "input",
          title: "Benchmark Against Industry Standards",
          description: "Collect industry benchmarking data and best practices for organizational alignment.",
          bestPractices: [
            "Select relevant industry benchmarks and standards",
            "Gather data from industry reports and publications",
            "Document peer organization practices",
            "Collect metrics for comparative analysis"
          ]
        },
        "1-processing-1": {
          stage: "processing",
          title: "Apply Strategic Analysis Techniques",
          description: "Use strategic analysis tools to develop an integrated strategy with risk management and implementation roadmap.",
          bestPractices: [
            "Apply SWOT analysis to identify strengths and weaknesses",
            "Use gap analysis to identify improvement areas",
            "Apply risk assessment methodologies",
            "Use roadmapping techniques for implementation planning"
          ]
        },
        "1-processing-2": {
          stage: "processing",
          title: "Apply Communication Planning Methodologies",
          description: "Use communication planning techniques to develop stakeholder-specific messaging and feedback mechanisms.",
          bestPractices: [
            "Apply stakeholder analysis techniques",
            "Use communication matrix development methods",
            "Apply message tailoring methodologies",
            "Use KPI development frameworks for communication effectiveness"
          ]
        },
        "1-processing-3": {
          stage: "processing",
          title: "Apply Charter Development Techniques",
          description: "Use charter development methodologies to define PMO scope, authority, and governance structure.",
          bestPractices: [
            "Apply scope definition techniques",
            "Use RACI matrix development methods",
            "Apply governance framework design methodologies",
            "Use authority mapping techniques"
          ],
          templates: ["PMO Charter Template", "RACI Matrix"]
        },
        "1-output-1": {
          stage: "output",
          title: "Deliver Integrated Strategy and Roadmap",
          description: "Produce and implement the integrated strategy with risk management plan and phased implementation roadmap.",
          bestPractices: [
            "Document comprehensive strategy with clear objectives",
            "Create detailed implementation roadmap with milestones",
            "Develop risk management plan with mitigation strategies",
            "Establish strategy review and update mechanisms"
          ]
        },
        "1-output-2": {
          stage: "output",
          title: "Establish PMO Vision, Values and Culture",
          description: "Implement vision statement, core values, and cultural change program with leadership engagement.",
          bestPractices: [
            "Create compelling vision statement aligned with organization",
            "Document core values with behavioral examples",
            "Implement leadership engagement activities",
            "Establish cultural reinforcement mechanisms"
          ],
          templates: ["PMO Vision Statement Template", "Cultural Change Roadmap"]
        },
        "1-output-3": {
          stage: "output",
          title: "Implement PMO Charter and Governance",
          description: "Establish and operationalize PMO charter with defined scope, authority, and governance structure.",
          bestPractices: [
            "Formalize PMO charter with executive approval",
            "Implement governance structure with clear roles",
            "Establish decision-making authorities and processes",
            "Create charter review and update mechanisms"
          ],
          templates: ["PMO Charter Document", "Governance Structure Diagram"]
        },
      },
    },
    "2": {
      name: "Strategic Framework & Governance",
      description: "Creating the optimal PMO structure, roles, and responsibilities to meet organizational needs.",
      tasks: {
        "2-input-1": {
          stage: "input",
          title: "Gather Current State Data",
          description: "Collect data on current project management operations, processes, and performance.",
          bestPractices: [
            "Conduct process documentation review",
            "Gather performance metrics and historical data",
            "Collect stakeholder feedback on current operations",
            "Document existing governance structures"
          ]
        },
        "2-input-2": {
          stage: "input",
          title: "Collect Strategic Alignment Information",
          description: "Gather organizational strategic objectives, priorities, and success criteria.",
          bestPractices: [
            "Review organizational strategic plans",
            "Collect executive leadership priorities",
            "Document business unit objectives",
            "Gather information on strategic initiatives"
          ]
        },
        "2-input-3": {
          stage: "input",
          title: "Identify Capability Requirements",
          description: "Collect data on required capabilities through stakeholder interviews and organizational needs assessment.",
          bestPractices: [
            "Conduct capability needs interviews",
            "Gather industry capability standards",
            "Document capability prioritization criteria",
            "Collect capability maturity benchmarks"
          ]
        },
        "2-processing-1": {
          stage: "processing",
          title: "Apply Mandate Development Methodology",
          description: "Use mandate development techniques to define PMO purpose, authority, and responsibilities.",
          bestPractices: [
            "Apply purpose statement development methods",
            "Use authority mapping techniques",
            "Apply responsibility definition methodologies",
            "Use stakeholder validation approaches"
          ],
          templates: ["PMO Mandate Template", "Executive Sponsorship Agreement"]
        },
        "2-processing-2": {
          stage: "processing",
          title: "Apply Charter Development Framework",
          description: "Use charter development framework to create comprehensive PMO charter with roles and governance structure.",
          bestPractices: [
            "Apply vision and mission statement techniques",
            "Use organizational structure design methods",
            "Apply role definition methodologies",
            "Use governance framework design techniques"
          ],
          templates: ["PMO Charter Template", "Governance Structure Diagram"]
        },
        "2-processing-3": {
          stage: "processing",
          title: "Apply Governance Design Methodology",
          description: "Use governance design techniques to develop decision-making processes and oversight mechanisms.",
          bestPractices: [
            "Apply decision rights mapping techniques",
            "Use escalation path design methods",
            "Apply governance body design methodologies",
            "Use governance communication planning techniques"
          ],
          templates: ["Governance Framework Template", "Decision Rights Matrix"]
        },
        "2-output-1": {
          stage: "output",
          title: "Establish PMO Mandate and Charter",
          description: "Formalize and implement PMO mandate and charter with defined purpose, authority, and responsibilities.",
          bestPractices: [
            "Obtain executive approval for mandate and charter",
            "Communicate mandate to all stakeholders",
            "Implement authority structures defined in charter",
            "Establish charter review and update process"
          ],
          templates: ["Approved PMO Mandate", "Finalized PMO Charter"]
        },
        "2-output-2": {
          stage: "output",
          title: "Implement Governance Framework",
          description: "Establish and operationalize governance framework with decision-making bodies, processes, and oversight mechanisms.",
          bestPractices: [
            "Form governance committees with clear charters",
            "Implement decision-making processes and authorities",
            "Establish governance meeting cadence and agendas",
            "Create governance documentation and reporting system"
          ],
          templates: ["Governance Committee Charter", "Decision Authority Matrix"]
        },
        "2-output-3": {
          stage: "output",
          title: "Develop Strategic Communication Plan",
          description: "Implement comprehensive communication strategy with stakeholder-specific messaging and feedback mechanisms.",
          bestPractices: [
            "Create stakeholder-specific communication materials",
            "Establish regular communication cadence",
            "Implement feedback collection mechanisms",
            "Develop communication effectiveness metrics"
          ],
          templates: ["Strategic Communication Plan", "Stakeholder Messaging Matrix"]
        },      
      }
    },
    "3": {
      name: "PMO Structure & Design",
      description: "Establishing operational processes, KPIs, and performance metrics for the PMO.",
      tasks: {
        "3-input-1": {
          stage: "input",
          title: "Gather Customer Data",
          description: "Collect data on potential PMO customers, their needs, and expectations through surveys and interviews.",
          bestPractices: [
            "Conduct customer needs assessment surveys",
            "Gather stakeholder interview data",
            "Document customer pain points and expectations",
            "Collect service prioritization information"
          ]
        },
        "3-input-2": {
          stage: "input",
          title: "Collect Service Requirement Data",
          description: "Gather detailed requirements for potential PMO services through workshops and requirements sessions.",
          bestPractices: [
            "Conduct service requirements workshops",
            "Document service level expectations",
            "Collect service prioritization criteria",
            "Gather benchmark data on similar services"
          ],
          templates: ["Service Requirements Template", "Customer Needs Assessment"]
        },
        "3-input-3": {
          stage: "input",
          title: "Assess Capability Gaps",
          description: "Collect data on current capabilities and gaps through assessment tools and stakeholder feedback.",
          bestPractices: [
            "Use capability maturity assessment tools",
            "Gather capability benchmark data",
            "Document capability prioritization criteria",
            "Collect resource availability information"
          ]
        },
        "3-processing-1": {
          stage: "processing",
          title: "Apply Persona Development Techniques",
          description: "Use persona development methodologies to create detailed customer personas with needs and expectations.",
          bestPractices: [
            "Apply customer segmentation techniques",
            "Use persona development frameworks",
            "Apply needs analysis methodologies",
            "Use journey mapping techniques"
          ]
        },
        "3-processing-2": {
          stage: "processing",
          title: "Apply Prioritization Frameworks",
          description: "Use prioritization techniques to develop framework for addressing customer needs systematically.",
          bestPractices: [
            "Apply value vs. effort prioritization matrix",
            "Use MoSCoW prioritization technique",
            "Apply weighted scoring methodologies",
            "Use impact mapping techniques"
          ]
        },
        "3-processing-3": {
          stage: "processing",
          title: "Apply Service Catalog Design Methodology",
          description: "Use service catalog design techniques to develop comprehensive service offerings with benefits and advantages.",
          bestPractices: [
            "Apply service definition frameworks",
            "Use service level definition techniques",
            "Apply value proposition development methodologies",
            "Use service categorization techniques"
          ],
          templates: ["Service Catalog Template", "Service Level Agreement Template"]
        },
        "3-output-1": {
          stage: "output",
          title: "Deliver Customer Personas and Journey Maps",
          description: "Create and distribute detailed customer personas and journey maps to guide service design and delivery.",
          bestPractices: [
            "Document comprehensive personas with needs and pain points",
            "Create visual journey maps for key customer interactions",
            "Distribute personas to all service delivery teams",
            "Establish persona update and refinement process"
          ],
          templates: ["Customer Persona Template", "Journey Map Template"]
        },
        "3-output-2": {
          stage: "output",
          title: "Implement Service Catalog and SLAs",
          description: "Launch comprehensive service catalog with service level agreements, processes, and quality standards.",
          bestPractices: [
            "Create detailed service descriptions with value propositions",
            "Establish service level metrics and targets",
            "Implement service request and delivery processes",
            "Create service catalog review and update mechanism"
          ],
          templates: ["Service Catalog Document", "SLA Documentation"]
        },
        "3-output-3": {
          stage: "output",
          title: "Establish Service Prioritization Framework",
          description: "Implement systematic approach for prioritizing and addressing customer needs and service requests.",
          bestPractices: [
            "Create prioritization criteria and scoring system",
            "Implement request intake and evaluation process",
            "Establish resource allocation based on priorities",
            "Develop priority review and adjustment mechanisms"
          ],
          templates: ["Prioritization Matrix", "Service Request Form"]
        },      
      }
// Translation keys organized by component/page
// English translations
const en = {
  // Common components
  common: {
    pleaseWait: "Please wait while we prepare your content.",
    Complete : "Complete",
    search: "Search",
    save: "Save",
    saveAssessment: "Save Assessment",
    saved: "Saved!",
    showLess: "Show less",
    showMore: "Show more",
    cancel: "Cancel",
    edit: "Edit",
    delete: "Delete",
    close: "Close",
    loading: "Loading...",
    submit: "Submit",
    active: "Active",
    back: "Back",
    spent: "Spent",
    used: "Used",
    onTrack: "On Track",
    viewDetails: "View Details",
    tasks: "Tasks",
    domains: "Domains",
    budget: "Budget",
    daysLeft: "days left",
    next: "Next",
    progress: "Progress",
    notifications: "Notifications",
    help: "Help",
    settings: "Settings",
    profile: "Profile",
    signOut: "Sign Out",
    dashboard: "Dashboard",
    export: "Export",
    import: "Import",
    share: "Share",
    days: "days",
    darkMode: "Dark Mode",
    lightMode: "Light Mode",
    confirm: "Confirm",
    remainingTokens: "Remaining Tokens"
  },
  
  // Header component
  header: {
    search: "Search...",
    myTeams: "My Teams",
    invitations: "Invitations",
    setupProfile: "Setup Profile",
    subscription: "Subscription",
    settings: "Settings",
    adminPanel: "Admin Panel",
    signOut: "Sign out",
    profile: "Profile",
  },
  
  // Dashboard page
  dashboard: {
    title: "Dashboard",
    subtitle: "Build and track your PMO across all essential domains",
    budget: "Budget",
    editDetails: "Edit Details",
    exportReport: "Export Report",
    access: "Access",
    timelineProgress: "Timeline Progress",
    budgetUtilization: "Budget Utilization",
    projectStatus: "Project Status",
    maturityAssessment: "Maturity Assessment",
    keyObjectives: "Key Objectives",
    stakeholders: "Stakeholders",
    overallProgress: "Overall Progress",
    completedTasks: "Completed Tasks",
    domainProcessComparison:"Domain Progress Comparison",
    organization: "Organization",
    industry: "Industry",
    dashboardCustomization: "Dashboard Customization",
    displayLayout: "Display Layout",
    gridView: "Grid View",
    listView: "List View",
    widgetSelection: "Widget Selection",
    assessMaturityLevel: "Assess Your Maturity Level",
    maturityLevel: "Maturity Level",
    progressOverview: "Progress Overview",
    tasksStatus: "Tasks Status",
    domains: "Domains",
    chartsAnalytics: "Charts & Analytics",
    pmoMaturityLevel: "PMO Maturity Level",
    pmoDomains: "PMO Domains",
    aiAnalysis: "Accelerate with AI",
    aiDescription: "Let our advanced AI analyze your PMO data and generate comprehensive recommendations tailored to your organization's unique needs.",
    tryAiAnalysis: "Try AI Analysis",
    viewAll: "View all",
    of: "of",
    tasksCompleted: "tasks completed",
    notSet: "Not set",
    updateProfile: "Update profile",
    viewAllTasks: "View all tasks",
    nextSteps: "Next Steps",
    uploadDocuments: "Upload documents",
    analysisDocuments: "Upload supporting documents for AI analysis",
    analysisDocumentsDesc: "Enhance AI recommendations with your organization's context",
    completePmoMaturityAssessment: "Complete a PMO Maturity Assessment",
    getInsightsAboutPmoMaturityLevel: "Get insights about your PMO's current maturity level",
    reviewPractices: "Review best practices",
    explorePractices: "Explore the best practices library for guidance",
    viewResources: "View resources",
    goToAssessment: "Go to assessment",
    objective1: "Establish PMO governance framework",
    objective2: "Develop standard methodologies",
    objective3: "Implement performance metrics",
    sampleProject: "Sample PMO Implementation",
    sampleDescription: "A sample project with pre-populated data for demonstration",
    createFirstProject: "Create Your First PMO Project",
    firstProjectDesc: "Get started by creating your first PMO implementation project. You can set up project details, track progress across domains, and generate AI-powered recommendations.",
    createSample: "Create Sample Project",
    aiFeature1: "Custom templates based on your current maturity level",
    aiFeature2: "Detailed implementation roadmaps for each domain",
    aiFeature3: "Best practices tailored to your industry and context",
    maturityRadarChart: "Maturity Radar Chart",
    higherValuesIndicateGreaterMaturity: "Higher values indicate greater maturity",
    pmoMaturityAssessment: "PMO Maturity Assessment",
    assessPmoMaturity: "Assess your PMO's maturity level across all domains to identify strengths and improvement opportunities",
    selfAssessment: "Self-Assessment",
    aiGeneratedAssessment: "AI-Generated Assessment",
    notSpecified: "Not specified",
    currentMaturityProfile: "Current Maturity Profile",
    organizationDetails: "Organization Details",
    assessmentType: "Assessment Type",
    currentMaturityProfileDescription: "Your organization's PMO is currently at the",
    currentMaturityProfileDescription2: "level. This assessment will help you identify areas for improvement and create a roadmap for advancing your PMO capabilities.",
    assessmentDate: "Assessment Date",
    selfAssessmentQuestionnaire: "Self-Assessment Questionnaire",
    selfAssessmentDescription: "Rate your PMO's maturity level for each domain. Consider your processes, documentation, measurement capabilities, and continuous improvement efforts when making your assessment.",
    documentation: "Documentation",
    metrics: "Metrics",
    minimalToNone: "Minimal to none",
    basicDocumentation: "Basic documentation",
    comprehensiveDocumentation: "Comprehensive",
    regularlyUpdated: "Regularly updated",
    leadingPractice: "Leading practice",
    adHocOrNone: "Ad-hoc or none",
    basicTracking: "Basic tracking",
    notes: "Notes (Optional)",
    notesPlaceholder: "Add any notes or context about your assessment...",
    createNew: "Create New Project",
    generateAIAssessment: "Generate an AI Assessment",
    aiAssessmentDescription: "Our AI will analyze your domain inputs, project data, and uploaded documents to provide an objective assessment of your PMO's maturity across all domains.",
    aiAssessmentSummary: "AI Assessment Summary",
    aiAssessmentSummaryDescription: "Based on our analysis, your PMO is currently at the",
    keyStrengths: "Key Strengths",
    areasForImprovement: "Areas for Improvement",
    domainSpecificAssessment: "Domain-Specific Assessment",
    maturityProgression: "Maturity Progression",
    recommendations: "Recommendations",
    generatingReport: "Generating Report...",
    exportAssessmentReport: "Export Assessment Report",
    detailedMaturityGuide: "Detailed Maturity Guide",
    maturityModelReference: "Maturity Model Reference",
    generateAssessment: "Generate Assessment",
    generatingAssessment: "Generating Assessment...",
    generatingAssessmentDescription: "Our AI is analyzing your PMO data across all domains. This may take a few moments.",
    
  },
  
  // Domain detail page
  domain: {
    BestPractices: "Best Practices",
    backToDashboard: "Back to Dashboard",
    prevDomain: "Previous Domain",
    nextDomain: "Next Domain",
    viewDomain: "View Domain",
    progress: "Progress",
    tasks: "Tasks & Progress",
    input: "Domain Input & Analysis",
    analyzing: "Analyzing Domain Input",
    processingData: "Our AI is processing your input data...",
    inputStage: "Input",
    inputDesc: "Collect data, assess current state, and gather requirements for this domain.",
    processingStage: "Processing",
    processingDesc: "Analyze data, develop frameworks, and design solutions for this domain.",
    outputStage: "Output",
    outputDesc: "Create deliverables, implement solutions, and establish frameworks for this domain.",
    loading: "Loading domain data...",
    notFound: "Domain not found",
    provideInputFirst: "Please provide domain input data before analyzing",
    aiGeneratedAnalysis: "AI-Generated Analysis for",
    generated: "Generated",
    analysis: "Analysis",
    domainProgress: "Domain Progress (%)",
    templates: "Templates",
    downloadMarkdown: "Download Markdown",
    downloadPdf: "Download PDF",
    generatingPdf: "Generating PDF...",
    generating: "Generating...",
    allTemplates: "All Available Templates",
    markdownFormat: "Markdown",
    words: "words",
    usingTemplates: "Using These Templates",
    templateDescription: "These templates are available in Markdown and PDF formats. Markdown can be imported into document editors, project management tools, or converted to other formats. PDF files are ready for printing or sharing with stakeholders.",
    noTemplates: "No templates available for this domain",
    aiConfigTitle: "AI Analysis Configuration",
    selectDomainPrompt: "Select a domain to analyze with our advanced AI. The analysis will generate comprehensive recommendations and templates based on your organization's specific context.",
    selectDomain: "Select Domain",
    analysisDepth: "Analysis Depth",
    basic: "Basic",
    quickOverview: "Quick overview",
    standard: "Standard",
    balancedAnalysis: "Balanced analysis",
    detailed: "Detailed",
    inDepthReview: "In-depth review",
    comprehensive: "Comprehensive",
    maximumDetail: "Maximum detail",
    geminiPowered: "Gemini AI Powered Analysis",
    advancedAiDesc: "Advanced AI will analyze your inputs and generate tailored recommendations",
    startAnalysis: "Start Analysis"
  },
  
  // Project management
  project: {
    projectName: "Project Name",
    projectNamePlaceholder: "Enterprise PMO Implementation",
    description: "Description",
    descriptionPlaceholder: "Brief description of your PMO implementation project",
    budget: "Budget",
    yourProjects: "Your Projects",
    createProject: "Create Project"
  },
  
  // Sidebar
  sidebar: {
    dashboard: "Dashboard",
    pmoDomains: "PMO Domains",
    tools: "Tools & Assessment",
    resources: "Resources",
    tasks: "Tasks",
    bestPractices: "Best Practices",
    maturityAssessment: "Maturity Assessment",
    assessment: "Assessment",
  },
  
  // Auth pages
  auth: {
    copyright: "© 2025 PMO Builder using AI by Dr. Ahmed Alsenosy"
  },
  
  // Maturity levels
  maturityLevels: {
    initial: {
      label: 'Initial',
      description: 'Processes are ad hoc and chaotic.'
    },
    defined: {
      label: 'Defined',
      description: 'Processes are documented and standardized.'
    },
    managed: {
      label: 'Managed',
      description: 'Processes are measured and controlled.'
    },
    optimized: {
      label: 'Optimized',
      description: 'Focus on continuous improvement.'
    },
    innovative: {
      label: 'Innovative',
      description: 'Driving industry innovation and adaptation.'
    }
  },

  //profile page
  profile: {
    title: "Organization Profile",
    description: "Set up your organization details to personalize your PMO journey",
    organizationName: "Organization Name",
    organizationNamePlaceholder: "Enter your organization name",
    industry: "Industry",
    industryPlaceholder: "Enter your industry",
    pmoMaturityLevel: "PMO Maturity Level",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "Select the maturity level that best describes your current PMO",
    saveProfile: "Save Profile",
    cancel: "Cancel",
    initial: "Initial - Ad hoc processes",
    defined: "Defined - Basic processes established",
    managed: "Managed - Standardized processes",
    optimized: "Optimized - Continuously improving",
    notEstablished: "Not Established - No formal PMO",
  },
  
  //settings page
  settings: {
    title: "Settings",
    description: "Manage your account settings and preferences",
    personal: "Personal",
    subscription: "Subscription",
    notifications: "Notifications",
    security: "Security",
    data: "Data",
    saveProfile: "Save Profile",
    cancel: "Cancel",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "Select the maturity level that best describes your current PMO",
    organizationName: "Organization Name",
    organizationNamePlaceholder: "Enter your organization name",
    industry: "Industry",
    industryPlaceholder: "Enter your industry",
    pmoMaturityLevel: "PMO Maturity Level",
    notEstablished: "Not Established - No formal PMO",
    initial: "Initial - Ad hoc processes",
    defined: "Defined - Basic processes established",
    managed: "Managed - Standardized processes",
    optimized: "Optimized - Continuously improving",
  },

  // Resources page
  resources: {
    title: "Resources",
    noDocuments: "No documents available",
    errorLoading: "Error loading documents",
    downloadError: "Error downloading document",
    uploadNew: "Upload New Document",
    filter: "Filter Documents",
    sortBy: "Sort By",
    search: "Search Documents",
    lastModified: "Last Modified",
    fileName: "File Name",
    fileSize: "File Size",
    taskName: "Task Name",
    projectId: "Project ID"
  },
 // Help page
  help: {
    title: "Help & Support",
    description: "Learn how to use the PMO Domains Application Tool effectively",
    gettingStarted: "Getting Started",
    whatIsPmoDomainsTool: "What is the PMO Domains Tool?",
    whatIsPmoDomainsToolDescription: `The PMO Domains Application Tool helps PMO professionals apply and monitor the five key PMO domains using a structured "Inputs – Processing – Outputs" framework. The tool guides you through each domain's tasks, ensuring best practices and benchmarking against industry standards.`, 
    howToUseThisTool: "How to Use This Tool",
    howToUseThisToolDescription: "The PMO Domains Application Tool is a web-based application that helps organizations implement and improve their PMO capabilities across all domains.",
    canIExportMyData: "Can I export my data?",
    canIExportMyDataDescription: "Yes, you can export your data from the Settings page. This allows you to back up your progress or transfer it to another system.",
    canICustomizeTheToolForMyOrganization: "Can I customize the tool for my organization?",
    canICustomizeTheToolForMyOrganizationDescription: "The tool is designed to be applicable across different organizations and industries. You can add custom notes to each task to tailor it to your specific organizational context.",
    whatIfINotReadyToCompleteAllDomains: "What if I'm not ready to complete all domains?",
    whatIfINotReadyToCompleteAllDomainsDescription: "You can work on domains in any order that makes sense for your organization. The tool will track your progress across all domains, allowing you to focus on your priorities.",
    contactSupport: "Contact Support",
    contactSupportDescription: "If you need additional help or have questions about the PMO Domains Application Tool, please contact our support team.",
    supportContact: "Support Contact",
    supportContactEmail: "Email: support@pmobuilder.ai",
    supportContactPhone: "Phone: (555) 123-4567",
    supportContactHours: "Hours: Monday-Friday, 9am-5pm EST",
    startBySettingUpYourOrganizationProfile: "Start by setting up your organization profile in the Profile section",
    navigateToEachDomainUsingTheSidebarMenu: "Navigate to each domain using the sidebar menu",
    completeTasksInTheRecommendedOrder: "Complete tasks in the recommended order: Input → Processing → Output",
    markTasksAsCompleteAsYouProgress: "Mark tasks as complete as you progress",
    useTheDashboardToTrackYourOverallProgress: "Use the dashboard to track your overall progress",
    referToTheBestPracticesLibraryForGuidance: "Refer to the Best Practices Library for guidance",
    organizationalDevelopmentAndAlignment: "1. Organizational Development and Alignment",
    organizationalDevelopmentAndAlignmentDescription: "This domain focuses on aligning the PMO with organizational strategy and culture to ensure effective project management practices. It includes organizational assessment, stakeholder analysis, and developing alignment strategies.",
    strategicElementsOfThePmo: "2. Strategic Elements of the PMO",
    strategicElementsOfThePmoDescription: "This domain involves developing and implementing strategic frameworks, roadmaps, and governance structures. It includes strategic objectives review, portfolio analysis, and governance structure design.",
    pMODesignAndStructuring: "3. PMO Design and Structuring",
    pMODesignAndStructuringDescription: "This domain focuses on creating the optimal PMO structure, roles, and responsibilities to meet organizational needs. It includes requirements gathering, resource assessment, and service catalog development.",
    pMOOperationAndPerformance: "4. PMO Operation and Performance",
    pMOOperationAndPerformanceDescription: "This domain establishes operational processes, KPIs, and performance metrics for the PMO. It includes process assessment, performance metrics identification, and performance measurement systems.",
    pMOEnhancementAndEffectiveness: "5. PMO Enhancement and Effectiveness",
    pMOEnhancementAndEffectivenessDescription: "This domain focuses on continuously improving PMO services, capabilities, and value delivery. It includes maturity assessment, value delivery analysis, and continuous improvement planning.",
    frequentlyAskedQuestions: "Frequently Asked Questions",
    frequentlyAskedQuestionsDescription: "The PMO Domains Application Tool is a web-based application that helps organizations implement and improve their PMO capabilities across all domains.",
    howToAccessTemplates: "How do I access templates?",
    howToAccessTemplatesDescription: "Templates are available within specific tasks that have template resources. You can also find a collection of templates in the Best Practices Library",
    understandingTheFiveDomains: "Understanding the Five Domains",
  },
    
  subscription: {
    title: "Subscription Management",
    currentPlan: "Current Plan",
    trial: "Trial",
    cancelsAtPeriodEnd: "Cancels at period end",
    upgradePlan: "Upgrade Plan",
    manageSubscription: "Manage Subscription",
    processing: "Processing...",
    billingPeriod: "Billing Period",
    nextBillingDate: "Next Billing Date",
    paymentMethod: "Payment Method",
    projects: "Projects",
    aiAnalysis: "AI Analysis",
    storage: "Storage",
    freePlanLimitations: "Free plan limitations",
    freePlanLimitationsDescription: "You're currently on the Free plan, which has limitations on projects, AI analyses, and storage. Upgrade to Premium or Enterprise for increased limits and additional features.",
    upgradeNow: "Upgrade Now",
    upgradeToGetMore: "Upgrade to Get More",
    premiumPlanBenefits: "Premium Plan Benefits",
    upTo20Projects: "Up to 20 projects (vs. 3 on Free)",
    upTo100AiAnalyses: "100 AI analyses per month (vs. 3 on Free)",
    teamCollaboration: "Team collaboration with up to 5 users",
    prioritySupport: "Priority support",
    enterprisePlanBenefits: "Enterprise Plan Benefits",
    unlimitedProjectsAndAiAnalyses: "Unlimited projects and AI analyses",
    unlimitedTeamMembers: "Unlimited team members",
    whiteLabelingOptions: "White-labeling options",
    dedicatedSupport: "Dedicated support",
    upgradeToEnterprise: "Upgrade to Enterprise",
    unlimited: "Unlimited",
    unknown: "Unknown",
    free: "Free",
    premium: "Premium",
    enterprise: "Enterprise",
    usageAndLimits: "Usage & Limits",
    perMonth: "per month",
    mb: "MB",
    none: "None",
    creditCard: "Credit Card",
    paypal: "PayPal",
    notAvailable: "Not available",
  },
  
  //notifications
  notifications: {
    '1': {
      title: "PMO Maturity Assessment Due",
      description: "Complete your quarterly PMO maturity assessment by Friday.",
      time: "2 days ago",
    },
    '2': {
      title: "Strategic Elements Domain Updated",
      description: "New templates and resources have been added to the Strategic Elements domain.",
      time: "3 days ago",
    },
    '3': {
      title: "Team Meeting: PMO Enhancement",
      description: "Upcoming team meeting to discuss PMO Enhancement strategies.",
      time: "Tomorrow, 10:00 AM",
    },
    '4': {
      title: "New Message from Admin",
      description: "You have a new message regarding your Organization Development domain progress.",
      time: "1 week ago",
    },
    '5': {
      title: "Data Backup Complete",
      description: "Your PMO data has been successfully backed up to cloud storage.",
      time: "2 weeks ago",
    },
    title: "Notifications",
    description: "Stay updated with your PMO activities and important alerts",
    markAllAsRead: "Mark all as read",
    clearAll: "Clear all",
    markAllAsReadDescription: "Mark all notifications as read",
    clearAllDescription: "Clear all notifications",
    markAllAsReadButton: "Mark all as read",
    clearAllButton: "Clear all",
    unread: "Unread",
    all: "All",
    recentNotifications: "Recent Notifications",
    markAsUnread: "Mark as unread",
    markAsRead: "Mark as read",
    viewDetails: "View details",
    loadMore: "Load more notifications",
    customizeNotifications: "Customize how and when you receive notifications about your PMO activities",
    notificationPreferences: "Notification Preferences",
    managePreferences: "Manage Preferences",
    

  },
  // Domain names
  domains: {
    "1": {
      name: "Organizational Development and Alignment",
      description: "Aligning the PMO with organizational strategy and culture to ensure effective project management practices.",
      tasks: {
        "1-input-1": {
          stage: "input",
          title: "Assess Current Competencies",
          description: "Gather data on existing competencies through surveys, interviews, and documentation review.",
          bestPractices: [
            "Use standardized assessment tools to evaluate current competencies",
            "Collect input from multiple organizational levels",
            "Document both technical and soft skill competencies",
            "Identify competency gaps through structured assessment"
          ]
        },
        "1-input-2": {
          stage: "input",
          title: "Assess Organizational Culture",
          description: "Collect data on current organizational culture through surveys, focus groups, and stakeholder interviews.",
          bestPractices: [
            "Conduct culture assessment surveys",
            "Gather feedback from diverse organizational levels",
            "Document cultural enablers and barriers to project management",
            "Collect historical data on cultural change initiatives"
          ]
        },
        "1-input-3": {
          stage: "input",
          title: "Benchmark Against Industry Standards",
          description: "Collect industry benchmarking data and best practices for organizational alignment.",
          bestPractices: [
            "Select relevant industry benchmarks and standards",
            "Gather data from industry reports and publications",
            "Document peer organization practices",
            "Collect metrics for comparative analysis"
          ]
        },
        "1-processing-1": {
          stage: "processing",
          title: "Apply Strategic Analysis Techniques",
          description: "Use strategic analysis tools to develop an integrated strategy with risk management and implementation roadmap.",
          bestPractices: [
            "Apply SWOT analysis to identify strengths and weaknesses",
            "Use gap analysis to identify improvement areas",
            "Apply risk assessment methodologies",
            "Use roadmapping techniques for implementation planning"
          ]
        },
        "1-processing-2": {
          stage: "processing",
          title: "Apply Communication Planning Methodologies",
          description: "Use communication planning techniques to develop stakeholder-specific messaging and feedback mechanisms.",
          bestPractices: [
            "Apply stakeholder analysis techniques",
            "Use communication matrix development methods",
            "Apply message tailoring methodologies",
            "Use KPI development frameworks for communication effectiveness"
          ]
        },
        "1-processing-3": {
          stage: "processing",
          title: "Apply Charter Development Techniques",
          description: "Use charter development methodologies to define PMO scope, authority, and governance structure.",
          bestPractices: [
            "Apply scope definition techniques",
            "Use RACI matrix development methods",
            "Apply governance framework design methodologies",
            "Use authority mapping techniques"
          ],
          templates: ["PMO Charter Template", "RACI Matrix"]
        },
        "1-output-1": {
          stage: "output",
          title: "Deliver Integrated Strategy and Roadmap",
          description: "Produce and implement the integrated strategy with risk management plan and phased implementation roadmap.",
          bestPractices: [
            "Document comprehensive strategy with clear objectives",
            "Create detailed implementation roadmap with milestones",
            "Develop risk management plan with mitigation strategies",
            "Establish strategy review and update mechanisms"
          ]
        },
        "1-output-2": {
          stage: "output",
          title: "Establish PMO Vision, Values and Culture",
          description: "Implement vision statement, core values, and cultural change program with leadership engagement.",
          bestPractices: [
            "Create compelling vision statement aligned with organization",
            "Document core values with behavioral examples",
            "Implement leadership engagement activities",
            "Establish cultural reinforcement mechanisms"
          ],
          templates: ["PMO Vision Statement Template", "Cultural Change Roadmap"]
        },
        "1-output-3": {
          stage: "output",
          title: "Implement PMO Charter and Governance",
          description: "Establish and operationalize PMO charter with defined scope, authority, and governance structure.",
          bestPractices: [
            "Formalize PMO charter with executive approval",
            "Implement governance structure with clear roles",
            "Establish decision-making authorities and processes",
            "Create charter review and update mechanisms"
          ],
          templates: ["PMO Charter Document", "Governance Structure Diagram"]
        },
      },
    },
    "2": {
      name: "Strategic Framework & Governance",
      description: "Creating the optimal PMO structure, roles, and responsibilities to meet organizational needs.",
      tasks: {
        "2-input-1": {
          stage: "input",
          title: "Gather Current State Data",
          description: "Collect data on current project management operations, processes, and performance.",
          bestPractices: [
            "Conduct process documentation review",
            "Gather performance metrics and historical data",
            "Collect stakeholder feedback on current operations",
            "Document existing governance structures"
          ]
        },
        "2-input-2": {
          stage: "input",
          title: "Collect Strategic Alignment Information",
          description: "Gather organizational strategic objectives, priorities, and success criteria.",
          bestPractices: [
            "Review organizational strategic plans",
            "Collect executive leadership priorities",
            "Document business unit objectives",
            "Gather information on strategic initiatives"
          ]
        },
        "2-input-3": {
          stage: "input",
          title: "Identify Capability Requirements",
          description: "Collect data on required capabilities through stakeholder interviews and organizational needs assessment.",
          bestPractices: [
            "Conduct capability needs interviews",
            "Gather industry capability standards",
            "Document capability prioritization criteria",
            "Collect capability maturity benchmarks"
          ]
        },
        "2-processing-1": {
          stage: "processing",
          title: "Apply Mandate Development Methodology",
          description: "Use mandate development techniques to define PMO purpose, authority, and responsibilities.",
          bestPractices: [
            "Apply purpose statement development methods",
            "Use authority mapping techniques",
            "Apply responsibility definition methodologies",
            "Use stakeholder validation approaches"
          ],
          templates: ["PMO Mandate Template", "Executive Sponsorship Agreement"]
        },
        "2-processing-2": {
          stage: "processing",
          title: "Apply Charter Development Framework",
          description: "Use charter development framework to create comprehensive PMO charter with roles and governance structure.",
          bestPractices: [
            "Apply vision and mission statement techniques",
            "Use organizational structure design methods",
            "Apply role definition methodologies",
            "Use governance framework design techniques"
          ],
          templates: ["PMO Charter Template", "Governance Structure Diagram"]
        },
        "2-processing-3": {
          stage: "processing",
          title: "Apply Governance Design Methodology",
          description: "Use governance design techniques to develop decision-making processes and oversight mechanisms.",
          bestPractices: [
            "Apply decision rights mapping techniques",
            "Use escalation path design methods",
            "Apply governance body design methodologies",
            "Use governance communication planning techniques"
          ],
          templates: ["Governance Framework Template", "Decision Rights Matrix"]
        },
        "2-output-1": {
          stage: "output",
          title: "Establish PMO Mandate and Charter",
          description: "Formalize and implement PMO mandate and charter with defined purpose, authority, and responsibilities.",
          bestPractices: [
            "Obtain executive approval for mandate and charter",
            "Communicate mandate to all stakeholders",
            "Implement authority structures defined in charter",
            "Establish charter review and update process"
          ],
          templates: ["Approved PMO Mandate", "Finalized PMO Charter"]
        },
        "2-output-2": {
          stage: "output",
          title: "Implement Governance Framework",
          description: "Establish and operationalize governance framework with decision-making bodies, processes, and oversight mechanisms.",
          bestPractices: [
            "Form governance committees with clear charters",
            "Implement decision-making processes and authorities",
            "Establish governance meeting cadence and agendas",
            "Create governance documentation and reporting system"
          ],
          templates: ["Governance Committee Charter", "Decision Authority Matrix"]
        },
        "2-output-3": {
          stage: "output",
          title: "Develop Strategic Communication Plan",
          description: "Implement comprehensive communication strategy with stakeholder-specific messaging and feedback mechanisms.",
          bestPractices: [
            "Create stakeholder-specific communication materials",
            "Establish regular communication cadence",
            "Implement feedback collection mechanisms",
            "Develop communication effectiveness metrics"
          ],
          templates: ["Strategic Communication Plan", "Stakeholder Messaging Matrix"]
        },      
      }
    },
    "3": {
      name: "PMO Structure & Design",
      description: "Establishing operational processes, KPIs, and performance metrics for the PMO.",
      tasks: {
        "3-input-1": {
          stage: "input",
          title: "Gather Customer Data",
          description: "Collect data on potential PMO customers, their needs, and expectations through surveys and interviews.",
          bestPractices: [
            "Conduct customer needs assessment surveys",
            "Gather stakeholder interview data",
            "Document customer pain points and expectations",
            "Collect service prioritization information"
          ]
        },
        "3-input-2": {
          stage: "input",
          title: "Collect Service Requirement Data",
          description: "Gather detailed requirements for potential PMO services through workshops and requirements sessions.",
          bestPractices: [
            "Conduct service requirements workshops",
            "Document service level expectations",
            "Collect service prioritization criteria",
            "Gather benchmark data on similar services"
          ],
          templates: ["Service Requirements Template", "Customer Needs Assessment"]
        },
        "3-input-3": {
          stage: "input",
          title: "Assess Capability Gaps",
          description: "Collect data on current capabilities and gaps through assessment tools and stakeholder feedback.",
          bestPractices: [
            "Use capability maturity assessment tools",
            "Gather capability benchmark data",
            "Document capability prioritization criteria",
            "Collect resource availability information"
          ]
        },
        "3-processing-1": {
          stage: "processing",
          title: "Apply Persona Development Techniques",
          description: "Use persona development methodologies to create detailed customer personas with needs and expectations.",
          bestPractices: [
            "Apply customer segmentation techniques",
            "Use persona development frameworks",
            "Apply needs analysis methodologies",
            "Use journey mapping techniques"
          ]
        },
        "3-processing-2": {
          stage: "processing",
          title: "Apply Prioritization Frameworks",
          description: "Use prioritization techniques to develop framework for addressing customer needs systematically.",
          bestPractices: [
            "Apply value vs. effort prioritization matrix",
            "Use MoSCoW prioritization technique",
            "Apply weighted scoring methodologies",
            "Use impact mapping techniques"
          ]
        },
        "3-processing-3": {
          stage: "processing",
          title: "Apply Service Catalog Design Methodology",
          description: "Use service catalog design techniques to develop comprehensive service offerings with benefits and advantages.",
          bestPractices: [
            "Apply service definition frameworks",
            "Use service level definition techniques",
            "Apply value proposition development methodologies",
            "Use service categorization techniques"
          ],
          templates: ["Service Catalog Template", "Service Level Agreement Template"]
        },
        "3-output-1": {
          stage: "output",
          title: "Deliver Customer Personas and Journey Maps",
          description: "Create and distribute detailed customer personas and journey maps to guide service design and delivery.",
          bestPractices: [
            "Document comprehensive personas with needs and pain points",
            "Create visual journey maps for key customer interactions",
            "Distribute personas to all service delivery teams",
            "Establish persona update and refinement process"
          ],
          templates: ["Customer Persona Template", "Journey Map Template"]
        },
        "3-output-2": {
          stage: "output",
          title: "Implement Service Catalog and SLAs",
          description: "Launch comprehensive service catalog with service level agreements, processes, and quality standards.",
          bestPractices: [
            "Create detailed service descriptions with value propositions",
            "Establish service level metrics and targets",
            "Implement service request and delivery processes",
            "Create service catalog review and update mechanism"
          ],
          templates: ["Service Catalog Document", "SLA Documentation"]
        },
        "3-output-3": {
          stage: "output",
          title: "Establish Service Prioritization Framework",
          description: "Implement systematic approach for prioritizing and addressing customer needs and service requests.",
          bestPractices: [
            "Create prioritization criteria and scoring system",
            "Implement request intake and evaluation process",
            "Establish resource allocation based on priorities",
            "Develop priority review and adjustment mechanisms"
          ],
          templates: ["Prioritization Matrix", "Service Request Form"]
        },      
      }
    },
// Translation keys organized by component/page
// English translations
const en = {
  // Common components
  common: {
    pleaseWait: "Please wait while we prepare your content.",
    Complete : "Complete",
    search: "Search",
    save: "Save",
    saveAssessment: "Save Assessment",
    saved: "Saved!",
    showLess: "Show less",
    showMore: "Show more",
    cancel: "Cancel",
    edit: "Edit",
    delete: "Delete",
    close: "Close",
    loading: "Loading...",
    submit: "Submit",
    active: "Active",
    back: "Back",
    spent: "Spent",
    used: "Used",
    onTrack: "On Track",
    viewDetails: "View Details",
    tasks: "Tasks",
    domains: "Domains",
    budget: "Budget",
    daysLeft: "days left",
    next: "Next",
    progress: "Progress",
    notifications: "Notifications",
    help: "Help",
    settings: "Settings",
    profile: "Profile",
    signOut: "Sign Out",
    dashboard: "Dashboard",
    export: "Export",
    import: "Import",
    share: "Share",
    days: "days",
    darkMode: "Dark Mode",
    lightMode: "Light Mode",
    confirm: "Confirm",
    remainingTokens: "Remaining Tokens"
  },
  
  // Header component
  header: {
    search: "Search...",
    myTeams: "My Teams",
    invitations: "Invitations",
    setupProfile: "Setup Profile",
    subscription: "Subscription",
    settings: "Settings",
    adminPanel: "Admin Panel",
    signOut: "Sign out",
    profile: "Profile",
  },
  
  // Dashboard page
  dashboard: {
    title: "Dashboard",
    subtitle: "Build and track your PMO across all essential domains",
    budget: "Budget",
    editDetails: "Edit Details",
    exportReport: "Export Report",
    access: "Access",
    timelineProgress: "Timeline Progress",
    budgetUtilization: "Budget Utilization",
    projectStatus: "Project Status",
    maturityAssessment: "Maturity Assessment",
    keyObjectives: "Key Objectives",
    stakeholders: "Stakeholders",
    overallProgress: "Overall Progress",
    completedTasks: "Completed Tasks",
    domainProcessComparison:"Domain Progress Comparison",
    organization: "Organization",
    industry: "Industry",
    dashboardCustomization: "Dashboard Customization",
    displayLayout: "Display Layout",
    gridView: "Grid View",
    listView: "List View",
    widgetSelection: "Widget Selection",
    assessMaturityLevel: "Assess Your Maturity Level",
    maturityLevel: "Maturity Level",
    progressOverview: "Progress Overview",
    tasksStatus: "Tasks Status",
    domains: "Domains",
    chartsAnalytics: "Charts & Analytics",
    pmoMaturityLevel: "PMO Maturity Level",
    pmoDomains: "PMO Domains",
    aiAnalysis: "Accelerate with AI",
    aiDescription: "Let our advanced AI analyze your PMO data and generate comprehensive recommendations tailored to your organization's unique needs.",
    tryAiAnalysis: "Try AI Analysis",
    viewAll: "View all",
    of: "of",
    tasksCompleted: "tasks completed",
    notSet: "Not set",
    updateProfile: "Update profile",
    viewAllTasks: "View all tasks",
    nextSteps: "Next Steps",
    uploadDocuments: "Upload documents",
    analysisDocuments: "Upload supporting documents for AI analysis",
    analysisDocumentsDesc: "Enhance AI recommendations with your organization's context",
    completePmoMaturityAssessment: "Complete a PMO Maturity Assessment",
    getInsightsAboutPmoMaturityLevel: "Get insights about your PMO's current maturity level",
    reviewPractices: "Review best practices",
    explorePractices: "Explore the best practices library for guidance",
    viewResources: "View resources",
    goToAssessment: "Go to assessment",
    objective1: "Establish PMO governance framework",
    objective2: "Develop standard methodologies",
    objective3: "Implement performance metrics",
    sampleProject: "Sample PMO Implementation",
    sampleDescription: "A sample project with pre-populated data for demonstration",
    createFirstProject: "Create Your First PMO Project",
    firstProjectDesc: "Get started by creating your first PMO implementation project. You can set up project details, track progress across domains, and generate AI-powered recommendations.",
    createSample: "Create Sample Project",
    aiFeature1: "Custom templates based on your current maturity level",
    aiFeature2: "Detailed implementation roadmaps for each domain",
    aiFeature3: "Best practices tailored to your industry and context",
    maturityRadarChart: "Maturity Radar Chart",
    higherValuesIndicateGreaterMaturity: "Higher values indicate greater maturity",
    pmoMaturityAssessment: "PMO Maturity Assessment",
    assessPmoMaturity: "Assess your PMO's maturity level across all domains to identify strengths and improvement opportunities",
    selfAssessment: "Self-Assessment",
    aiGeneratedAssessment: "AI-Generated Assessment",
    notSpecified: "Not specified",
    currentMaturityProfile: "Current Maturity Profile",
    organizationDetails: "Organization Details",
    assessmentType: "Assessment Type",
    currentMaturityProfileDescription: "Your organization's PMO is currently at the",
    currentMaturityProfileDescription2: "level. This assessment will help you identify areas for improvement and create a roadmap for advancing your PMO capabilities.",
    assessmentDate: "Assessment Date",
    selfAssessmentQuestionnaire: "Self-Assessment Questionnaire",
    selfAssessmentDescription: "Rate your PMO's maturity level for each domain. Consider your processes, documentation, measurement capabilities, and continuous improvement efforts when making your assessment.",
    documentation: "Documentation",
    metrics: "Metrics",
    minimalToNone: "Minimal to none",
    basicDocumentation: "Basic documentation",
    comprehensiveDocumentation: "Comprehensive",
    regularlyUpdated: "Regularly updated",
    leadingPractice: "Leading practice",
    adHocOrNone: "Ad-hoc or none",
    basicTracking: "Basic tracking",
    notes: "Notes (Optional)",
    notesPlaceholder: "Add any notes or context about your assessment...",
    createNew: "Create New Project",
    generateAIAssessment: "Generate an AI Assessment",
    aiAssessmentDescription: "Our AI will analyze your domain inputs, project data, and uploaded documents to provide an objective assessment of your PMO's maturity across all domains.",
    aiAssessmentSummary: "AI Assessment Summary",
    aiAssessmentSummaryDescription: "Based on our analysis, your PMO is currently at the",
    keyStrengths: "Key Strengths",
    areasForImprovement: "Areas for Improvement",
    domainSpecificAssessment: "Domain-Specific Assessment",
    maturityProgression: "Maturity Progression",
    recommendations: "Recommendations",
    generatingReport: "Generating Report...",
    exportAssessmentReport: "Export Assessment Report",
    detailedMaturityGuide: "Detailed Maturity Guide",
    maturityModelReference: "Maturity Model Reference",
    generateAssessment: "Generate Assessment",
    generatingAssessment: "Generating Assessment...",
    generatingAssessmentDescription: "Our AI is analyzing your PMO data across all domains. This may take a few moments.",
    
  },
  
  // Domain detail page
  domain: {
    BestPractices: "Best Practices",
    backToDashboard: "Back to Dashboard",
    prevDomain: "Previous Domain",
    nextDomain: "Next Domain",
    viewDomain: "View Domain",
    progress: "Progress",
    tasks: "Tasks & Progress",
    input: "Domain Input & Analysis",
    analyzing: "Analyzing Domain Input",
    processingData: "Our AI is processing your input data...",
    inputStage: "Input",
    inputDesc: "Collect data, assess current state, and gather requirements for this domain.",
    processingStage: "Processing",
    processingDesc: "Analyze data, develop frameworks, and design solutions for this domain.",
    outputStage: "Output",
    outputDesc: "Create deliverables, implement solutions, and establish frameworks for this domain.",
    loading: "Loading domain data...",
    notFound: "Domain not found",
    provideInputFirst: "Please provide domain input data before analyzing",
    aiGeneratedAnalysis: "AI-Generated Analysis for",
    generated: "Generated",
    analysis: "Analysis",
    domainProgress: "Domain Progress (%)",
    templates: "Templates",
    downloadMarkdown: "Download Markdown",
    downloadPdf: "Download PDF",
    generatingPdf: "Generating PDF...",
    generating: "Generating...",
    allTemplates: "All Available Templates",
    markdownFormat: "Markdown",
    words: "words",
    usingTemplates: "Using These Templates",
    templateDescription: "These templates are available in Markdown and PDF formats. Markdown can be imported into document editors, project management tools, or converted to other formats. PDF files are ready for printing or sharing with stakeholders.",
    noTemplates: "No templates available for this domain",
    aiConfigTitle: "AI Analysis Configuration",
    selectDomainPrompt: "Select a domain to analyze with our advanced AI. The analysis will generate comprehensive recommendations and templates based on your organization's specific context.",
    selectDomain: "Select Domain",
    analysisDepth: "Analysis Depth",
    basic: "Basic",
    quickOverview: "Quick overview",
    standard: "Standard",
    balancedAnalysis: "Balanced analysis",
    detailed: "Detailed",
    inDepthReview: "In-depth review",
    comprehensive: "Comprehensive",
    maximumDetail: "Maximum detail",
    geminiPowered: "Gemini AI Powered Analysis",
    advancedAiDesc: "Advanced AI will analyze your inputs and generate tailored recommendations",
    startAnalysis: "Start Analysis"
  },
  
  // Project management
  project: {
    projectName: "Project Name",
    projectNamePlaceholder: "Enterprise PMO Implementation",
    description: "Description",
    descriptionPlaceholder: "Brief description of your PMO implementation project",
    budget: "Budget",
    yourProjects: "Your Projects",
    createProject: "Create Project"
  },
  
  // Sidebar
  sidebar: {
    dashboard: "Dashboard",
    pmoDomains: "PMO Domains",
    tools: "Tools & Assessment",
    resources: "Resources",
    tasks: "Tasks",
    bestPractices: "Best Practices",
    maturityAssessment: "Maturity Assessment",
    assessment: "Assessment",
  },
  
  // Auth pages
  auth: {
    copyright: "© 2025 PMO Builder using AI by Dr. Ahmed Alsenosy"
  },
  
  // Maturity levels
  maturityLevels: {
    initial: {
      label: 'Initial',
      description: 'Processes are ad hoc and chaotic.'
    },
    defined: {
      label: 'Defined',
      description: 'Processes are documented and standardized.'
    },
    managed: {
      label: 'Managed',
      description: 'Processes are measured and controlled.'
    },
    optimized: {
      label: 'Optimized',
      description: 'Focus on continuous improvement.'
    },
    innovative: {
      label: 'Innovative',
      description: 'Driving industry innovation and adaptation.'
    }
  },

  //profile page
  profile: {
    title: "Organization Profile",
    description: "Set up your organization details to personalize your PMO journey",
    organizationName: "Organization Name",
    organizationNamePlaceholder: "Enter your organization name",
    industry: "Industry",
    industryPlaceholder: "Enter your industry",
    pmoMaturityLevel: "PMO Maturity Level",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "Select the maturity level that best describes your current PMO",
    saveProfile: "Save Profile",
    cancel: "Cancel",
    initial: "Initial - Ad hoc processes",
    defined: "Defined - Basic processes established",
    managed: "Managed - Standardized processes",
    optimized: "Optimized - Continuously improving",
    notEstablished: "Not Established - No formal PMO",
  },
  
  //settings page
  settings: {
    title: "Settings",
    description: "Manage your account settings and preferences",
    personal: "Personal",
    subscription: "Subscription",
    notifications: "Notifications",
    security: "Security",
    data: "Data",
    saveProfile: "Save Profile",
    cancel: "Cancel",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "Select the maturity level that best describes your current PMO",
    organizationName: "Organization Name",
    organizationNamePlaceholder: "Enter your organization name",
    industry: "Industry",
    industryPlaceholder: "Enter your industry",
    pmoMaturityLevel: "PMO Maturity Level",
    notEstablished: "Not Established - No formal PMO",
    initial: "Initial - Ad hoc processes",
    defined: "Defined - Basic processes established",
    managed: "Managed - Standardized processes",
    optimized: "Optimized - Continuously improving",
  },

  // Resources page
  resources: {
    title: "Resources",
    noDocuments: "No documents available",
    errorLoading: "Error loading documents",
    downloadError: "Error downloading document",
    uploadNew: "Upload New Document",
    filter: "Filter Documents",
    sortBy: "Sort By",
    search: "Search Documents",
    lastModified: "Last Modified",
    fileName: "File Name",
    fileSize: "File Size",
    taskName: "Task Name",
    projectId: "Project ID"
  },
 // Help page
  help: {
    title: "Help & Support",
    description: "Learn how to use the PMO Domains Application Tool effectively",
    gettingStarted: "Getting Started",
    whatIsPmoDomainsTool: "What is the PMO Domains Tool?",
    whatIsPmoDomainsToolDescription: `The PMO Domains Application Tool helps PMO professionals apply and monitor the five key PMO domains using a structured "Inputs – Processing – Outputs" framework. The tool guides you through each domain's tasks, ensuring best practices and benchmarking against industry standards.`, 
    howToUseThisTool: "How to Use This Tool",
    howToUseThisToolDescription: "The PMO Domains Application Tool is a web-based application that helps organizations implement and improve their PMO capabilities across all domains.",
    canIExportMyData: "Can I export my data?",
    canIExportMyDataDescription: "Yes, you can export your data from the Settings page. This allows you to back up your progress or transfer it to another system.",
    canICustomizeTheToolForMyOrganization: "Can I customize the tool for my organization?",
    canICustomizeTheToolForMyOrganizationDescription: "The tool is designed to be applicable across different organizations and industries. You can add custom notes to each task to tailor it to your specific organizational context.",
    whatIfINotReadyToCompleteAllDomains: "What if I'm not ready to complete all domains?",
    whatIfINotReadyToCompleteAllDomainsDescription: "You can work on domains in any order that makes sense for your organization. The tool will track your progress across all domains, allowing you to focus on your priorities.",
    contactSupport: "Contact Support",
    contactSupportDescription: "If you need additional help or have questions about the PMO Domains Application Tool, please contact our support team.",
    supportContact: "Support Contact",
    supportContactEmail: "Email: support@pmobuilder.ai",
    supportContactPhone: "Phone: (555) 123-4567",
    supportContactHours: "Hours: Monday-Friday, 9am-5pm EST",
    startBySettingUpYourOrganizationProfile: "Start by setting up your organization profile in the Profile section",
    navigateToEachDomainUsingTheSidebarMenu: "Navigate to each domain using the sidebar menu",
    completeTasksInTheRecommendedOrder: "Complete tasks in the recommended order: Input → Processing → Output",
    markTasksAsCompleteAsYouProgress: "Mark tasks as complete as you progress",
    useTheDashboardToTrackYourOverallProgress: "Use the dashboard to track your overall progress",
    referToTheBestPracticesLibraryForGuidance: "Refer to the Best Practices Library for guidance",
    organizationalDevelopmentAndAlignment: "1. Organizational Development and Alignment",
    organizationalDevelopmentAndAlignmentDescription: "This domain focuses on aligning the PMO with organizational strategy and culture to ensure effective project management practices. It includes organizational assessment, stakeholder analysis, and developing alignment strategies.",
    strategicElementsOfThePmo: "2. Strategic Elements of the PMO",
    strategicElementsOfThePmoDescription: "This domain involves developing and implementing strategic frameworks, roadmaps, and governance structures. It includes strategic objectives review, portfolio analysis, and governance structure design.",
    pMODesignAndStructuring: "3. PMO Design and Structuring",
    pMODesignAndStructuringDescription: "This domain focuses on creating the optimal PMO structure, roles, and responsibilities to meet organizational needs. It includes requirements gathering, resource assessment, and service catalog development.",
    pMOOperationAndPerformance: "4. PMO Operation and Performance",
    pMOOperationAndPerformanceDescription: "This domain establishes operational processes, KPIs, and performance metrics for the PMO. It includes process assessment, performance metrics identification, and performance measurement systems.",
    pMOEnhancementAndEffectiveness: "5. PMO Enhancement and Effectiveness",
    pMOEnhancementAndEffectivenessDescription: "This domain focuses on continuously improving PMO services, capabilities, and value delivery. It includes maturity assessment, value delivery analysis, and continuous improvement planning.",
    frequentlyAskedQuestions: "Frequently Asked Questions",
    frequentlyAskedQuestionsDescription: "The PMO Domains Application Tool is a web-based application that helps organizations implement and improve their PMO capabilities across all domains.",
    howToAccessTemplates: "How do I access templates?",
    howToAccessTemplatesDescription: "Templates are available within specific tasks that have template resources. You can also find a collection of templates in the Best Practices Library",
    understandingTheFiveDomains: "Understanding the Five Domains",
  },
    
  subscription: {
    title: "Subscription Management",
    currentPlan: "Current Plan",
    trial: "Trial",
    cancelsAtPeriodEnd: "Cancels at period end",
    upgradePlan: "Upgrade Plan",
    manageSubscription: "Manage Subscription",
    processing: "Processing...",
    billingPeriod: "Billing Period",
    nextBillingDate: "Next Billing Date",
    paymentMethod: "Payment Method",
    projects: "Projects",
    aiAnalysis: "AI Analysis",
    storage: "Storage",
    freePlanLimitations: "Free plan limitations",
    freePlanLimitationsDescription: "You're currently on the Free plan, which has limitations on projects, AI analyses, and storage. Upgrade to Premium or Enterprise for increased limits and additional features.",
    upgradeNow: "Upgrade Now",
    upgradeToGetMore: "Upgrade to Get More",
    premiumPlanBenefits: "Premium Plan Benefits",
    upTo20Projects: "Up to 20 projects (vs. 3 on Free)",
    upTo100AiAnalyses: "100 AI analyses per month (vs. 3 on Free)",
    teamCollaboration: "Team collaboration with up to 5 users",
    prioritySupport: "Priority support",
    enterprisePlanBenefits: "Enterprise Plan Benefits",
    unlimitedProjectsAndAiAnalyses: "Unlimited projects and AI analyses",
    unlimitedTeamMembers: "Unlimited team members",
    whiteLabelingOptions: "White-labeling options",
    dedicatedSupport: "Dedicated support",
    upgradeToEnterprise: "Upgrade to Enterprise",
    unlimited: "Unlimited",
    unknown: "Unknown",
    free: "Free",
    premium: "Premium",
    enterprise: "Enterprise",
    usageAndLimits: "Usage & Limits",
    perMonth: "per month",
    mb: "MB",
    none: "None",
    creditCard: "Credit Card",
    paypal: "PayPal",
    notAvailable: "Not available",
  },
  
  //notifications
  notifications: {
    '1': {
      title: "PMO Maturity Assessment Due",
      description: "Complete your quarterly PMO maturity assessment by Friday.",
      time: "2 days ago",
    },
    '2': {
      title: "Strategic Elements Domain Updated",
      description: "New templates and resources have been added to the Strategic Elements domain.",
      time: "3 days ago",
    },
    '3': {
      title: "Team Meeting: PMO Enhancement",
      description: "Upcoming team meeting to discuss PMO Enhancement strategies.",
      time: "Tomorrow, 10:00 AM",
    },
    '4': {
      title: "New Message from Admin",
      description: "You have a new message regarding your Organization Development domain progress.",
      time: "1 week ago",
    },
    '5': {
      title: "Data Backup Complete",
      description: "Your PMO data has been successfully backed up to cloud storage.",
      time: "2 weeks ago",
    },
    title: "Notifications",
    description: "Stay updated with your PMO activities and important alerts",
    markAllAsRead: "Mark all as read",
    clearAll: "Clear all",
    markAllAsReadDescription: "Mark all notifications as read",
    clearAllDescription: "Clear all notifications",
    markAllAsReadButton: "Mark all as read",
    clearAllButton: "Clear all",
    unread: "Unread",
    all: "All",
    recentNotifications: "Recent Notifications",
    markAsUnread: "Mark as unread",
    markAsRead: "Mark as read",
    viewDetails: "View details",
    loadMore: "Load more notifications",
    customizeNotifications: "Customize how and when you receive notifications about your PMO activities",
    notificationPreferences: "Notification Preferences",
    managePreferences: "Manage Preferences",
    

  },
  // Domain names
  domains: {
    "1": {
      name: "Organizational Development and Alignment",
      description: "Aligning the PMO with organizational strategy and culture to ensure effective project management practices.",
      tasks: {
        "1-input-1": {
          stage: "input",
          title: "Assess Current Competencies",
          description: "Gather data on existing competencies through surveys, interviews, and documentation review.",
          bestPractices: [
            "Use standardized assessment tools to evaluate current competencies",
            "Collect input from multiple organizational levels",
            "Document both technical and soft skill competencies",
            "Identify competency gaps through structured assessment"
          ]
        },
        "1-input-2": {
          stage: "input",
          title: "Assess Organizational Culture",
          description: "Collect data on current organizational culture through surveys, focus groups, and stakeholder interviews.",
          bestPractices: [
            "Conduct culture assessment surveys",
            "Gather feedback from diverse organizational levels",
            "Document cultural enablers and barriers to project management",
            "Collect historical data on cultural change initiatives"
          ]
        },
        "1-input-3": {
          stage: "input",
          title: "Benchmark Against Industry Standards",
          description: "Collect industry benchmarking data and best practices for organizational alignment.",
          bestPractices: [
            "Select relevant industry benchmarks and standards",
            "Gather data from industry reports and publications",
            "Document peer organization practices",
            "Collect metrics for comparative analysis"
          ]
        },
        "1-processing-1": {
          stage: "processing",
          title: "Apply Strategic Analysis Techniques",
          description: "Use strategic analysis tools to develop an integrated strategy with risk management and implementation roadmap.",
          bestPractices: [
            "Apply SWOT analysis to identify strengths and weaknesses",
            "Use gap analysis to identify improvement areas",
            "Apply risk assessment methodologies",
            "Use roadmapping techniques for implementation planning"
          ]
        },
        "1-processing-2": {
          stage: "processing",
          title: "Apply Communication Planning Methodologies",
          description: "Use communication planning techniques to develop stakeholder-specific messaging and feedback mechanisms.",
          bestPractices: [
            "Apply stakeholder analysis techniques",
            "Use communication matrix development methods",
            "Apply message tailoring methodologies",
            "Use KPI development frameworks for communication effectiveness"
          ]
        },
        "1-processing-3": {
          stage: "processing",
          title: "Apply Charter Development Techniques",
          description: "Use charter development methodologies to define PMO scope, authority, and governance structure.",
          bestPractices: [
            "Apply scope definition techniques",
            "Use RACI matrix development methods",
            "Apply governance framework design methodologies",
            "Use authority mapping techniques"
          ],
          templates: ["PMO Charter Template", "RACI Matrix"]
        },
        "1-output-1": {
          stage: "output",
          title: "Deliver Integrated Strategy and Roadmap",
          description: "Produce and implement the integrated strategy with risk management plan and phased implementation roadmap.",
          bestPractices: [
            "Document comprehensive strategy with clear objectives",
            "Create detailed implementation roadmap with milestones",
            "Develop risk management plan with mitigation strategies",
            "Establish strategy review and update mechanisms"
          ]
        },
        "1-output-2": {
          stage: "output",
          title: "Establish PMO Vision, Values and Culture",
          description: "Implement vision statement, core values, and cultural change program with leadership engagement.",
          bestPractices: [
            "Create compelling vision statement aligned with organization",
            "Document core values with behavioral examples",
            "Implement leadership engagement activities",
            "Establish cultural reinforcement mechanisms"
          ],
          templates: ["PMO Vision Statement Template", "Cultural Change Roadmap"]
        },
        "1-output-3": {
          stage: "output",
          title: "Implement PMO Charter and Governance",
          description: "Establish and operationalize PMO charter with defined scope, authority, and governance structure.",
          bestPractices: [
            "Formalize PMO charter with executive approval",
            "Implement governance structure with clear roles",
            "Establish decision-making authorities and processes",
            "Create charter review and update mechanisms"
          ],
          templates: ["PMO Charter Document", "Governance Structure Diagram"]
        },
      },
    },
    "2": {
      name: "Strategic Framework & Governance",
      description: "Creating the optimal PMO structure, roles, and responsibilities to meet organizational needs.",
      tasks: {
        "2-input-1": {
          stage: "input",
          title: "Gather Current State Data",
          description: "Collect data on current project management operations, processes, and performance.",
          bestPractices: [
            "Conduct process documentation review",
            "Gather performance metrics and historical data",
            "Collect stakeholder feedback on current operations",
            "Document existing governance structures"
          ]
        },
        "2-input-2": {
          stage: "input",
          title: "Collect Strategic Alignment Information",
          description: "Gather organizational strategic objectives, priorities, and success criteria.",
          bestPractices: [
            "Review organizational strategic plans",
            "Collect executive leadership priorities",
            "Document business unit objectives",
            "Gather information on strategic initiatives"
          ]
        },
        "2-input-3": {
          stage: "input",
          title: "Identify Capability Requirements",
          description: "Collect data on required capabilities through stakeholder interviews and organizational needs assessment.",
          bestPractices: [
            "Conduct capability needs interviews",
            "Gather industry capability standards",
            "Document capability prioritization criteria",
            "Collect capability maturity benchmarks"
          ]
        },
        "2-processing-1": {
          stage: "processing",
          title: "Apply Mandate Development Methodology",
          description: "Use mandate development techniques to define PMO purpose, authority, and responsibilities.",
          bestPractices: [
            "Apply purpose statement development methods",
            "Use authority mapping techniques",
            "Apply responsibility definition methodologies",
            "Use stakeholder validation approaches"
          ],
          templates: ["PMO Mandate Template", "Executive Sponsorship Agreement"]
        },
        "2-processing-2": {
          stage: "processing",
          title: "Apply Charter Development Framework",
          description: "Use charter development framework to create comprehensive PMO charter with roles and governance structure.",
          bestPractices: [
            "Apply vision and mission statement techniques",
            "Use organizational structure design methods",
            "Apply role definition methodologies",
            "Use governance framework design techniques"
          ],
          templates: ["PMO Charter Template", "Governance Structure Diagram"]
        },
        "2-processing-3": {
          stage: "processing",
          title: "Apply Governance Design Methodology",
          description: "Use governance design techniques to develop decision-making processes and oversight mechanisms.",
          bestPractices: [
            "Apply decision rights mapping techniques",
            "Use escalation path design methods",
            "Apply governance body design methodologies",
            "Use governance communication planning techniques"
          ],
          templates: ["Governance Framework Template", "Decision Rights Matrix"]
        },
        "2-output-1": {
          stage: "output",
          title: "Establish PMO Mandate and Charter",
          description: "Formalize and implement PMO mandate and charter with defined purpose, authority, and responsibilities.",
          bestPractices: [
            "Obtain executive approval for mandate and charter",
            "Communicate mandate to all stakeholders",
            "Implement authority structures defined in charter",
            "Establish charter review and update process"
          ],
          templates: ["Approved PMO Mandate", "Finalized PMO Charter"]
        },
        "2-output-2": {
          stage: "output",
          title: "Implement Governance Framework",
          description: "Establish and operationalize governance framework with decision-making bodies, processes, and oversight mechanisms.",
          bestPractices: [
            "Form governance committees with clear charters",
            "Implement decision-making processes and authorities",
            "Establish governance meeting cadence and agendas",
            "Create governance documentation and reporting system"
          ],
          templates: ["Governance Committee Charter", "Decision Authority Matrix"]
        },
        "2-output-3": {
          stage: "output",
          title: "Develop Strategic Communication Plan",
          description: "Implement comprehensive communication strategy with stakeholder-specific messaging and feedback mechanisms.",
          bestPractices: [
            "Create stakeholder-specific communication materials",
            "Establish regular communication cadence",
            "Implement feedback collection mechanisms",
            "Develop communication effectiveness metrics"
          ],
          templates: ["Strategic Communication Plan", "Stakeholder Messaging Matrix"]
        },      
      }
    },
    "3": {
      name: "PMO Structure & Design",
      description: "Establishing operational processes, KPIs, and performance metrics for the PMO.",
      tasks: {
        "3-input-1": {
          stage: "input",
          title: "Gather Customer Data",
          description: "Collect data on potential PMO customers, their needs, and expectations through surveys and interviews.",
          bestPractices: [
            "Conduct customer needs assessment surveys",
            "Gather stakeholder interview data",
            "Document customer pain points and expectations",
            "Collect service prioritization information"
          ]
        },
        "3-input-2": {
          stage: "input",
          title: "Collect Service Requirement Data",
          description: "Gather detailed requirements for potential PMO services through workshops and requirements sessions.",
          bestPractices: [
            "Conduct service requirements workshops",
            "Document service level expectations",
            "Collect service prioritization criteria",
            "Gather benchmark data on similar services"
          ],
          templates: ["Service Requirements Template", "Customer Needs Assessment"]
        },
        "3-input-3": {
          stage: "input",
          title: "Assess Capability Gaps",
          description: "Collect data on current capabilities and gaps through assessment tools and stakeholder feedback.",
          bestPractices: [
            "Use capability maturity assessment tools",
            "Gather capability benchmark data",
            "Document capability prioritization criteria",
            "Collect resource availability information"
          ]
        },
        "3-processing-1": {
          stage: "processing",
          title: "Apply Persona Development Techniques",
          description: "Use persona development methodologies to create detailed customer personas with needs and expectations.",
          bestPractices: [
            "Apply customer segmentation techniques",
            "Use persona development frameworks",
            "Apply needs analysis methodologies",
            "Use journey mapping techniques"
          ]
        },
        "3-processing-2": {
          stage: "processing",
          title: "Apply Prioritization Frameworks",
          description: "Use prioritization techniques to develop framework for addressing customer needs systematically.",
          bestPractices: [
            "Apply value vs. effort prioritization matrix",
            "Use MoSCoW prioritization technique",
            "Apply weighted scoring methodologies",
            "Use impact mapping techniques"
          ]
        },
        "3-processing-3": {
          stage: "processing",
          title: "Apply Service Catalog Design Methodology",
          description: "Use service catalog design techniques to develop comprehensive service offerings with benefits and advantages.",
          bestPractices: [
            "Apply service definition frameworks",
            "Use service level definition techniques",
            "Apply value proposition development methodologies",
            "Use service categorization techniques"
          ],
          templates: ["Service Catalog Template", "Service Level Agreement Template"]
        },
        "3-output-1": {
          stage: "output",
          title: "Deliver Customer Personas and Journey Maps",
          description: "Create and distribute detailed customer personas and journey maps to guide service design and delivery.",
          bestPractices: [
            "Document comprehensive personas with needs and pain points",
            "Create visual journey maps for key customer interactions",
            "Distribute personas to all service delivery teams",
            "Establish persona update and refinement process"
          ],
          templates: ["Customer Persona Template", "Journey Map Template"]
        },
        "3-output-2": {
          stage: "output",
          title: "Implement Service Catalog and SLAs",
          description: "Launch comprehensive service catalog with service level agreements, processes, and quality standards.",
          bestPractices: [
            "Create detailed service descriptions with value propositions",
            "Establish service level metrics and targets",
            "Implement service request and delivery processes",
            "Create service catalog review and update mechanism"
          ],
          templates: ["Service Catalog Document", "SLA Documentation"]
        },
        "3-output-3": {
          stage: "output",
          title: "Establish Service Prioritization Framework",
          description: "Implement systematic approach for prioritizing and addressing customer needs and service requests.",
          bestPractices: [
            "Create prioritization criteria and scoring system",
            "Implement request intake and evaluation process",
            "Establish resource allocation based on priorities",
            "Develop priority review and adjustment mechanisms"
          ],
          templates: ["Prioritization Matrix", "Service Request Form"]
        },      
      }
// Translation keys organized by component/page
// English translations
const en = {
  // Common components
  common: {
    pleaseWait: "Please wait while we prepare your content.",
    Complete : "Complete",
    search: "Search",
    save: "Save",
    saveAssessment: "Save Assessment",
    saved: "Saved!",
    showLess: "Show less",
    showMore: "Show more",
    cancel: "Cancel",
    edit: "Edit",
    delete: "Delete",
    close: "Close",
    loading: "Loading...",
    submit: "Submit",
    active: "Active",
    back: "Back",
    spent: "Spent",
    used: "Used",
    onTrack: "On Track",
    viewDetails: "View Details",
    tasks: "Tasks",
    domains: "Domains",
    budget: "Budget",
    daysLeft: "days left",
    next: "Next",
    progress: "Progress",
    notifications: "Notifications",
    help: "Help",
    settings: "Settings",
    profile: "Profile",
    signOut: "Sign Out",
    dashboard: "Dashboard",
    export: "Export",
    import: "Import",
    share: "Share",
    days: "days",
    darkMode: "Dark Mode",
    lightMode: "Light Mode",
    confirm: "Confirm",
    remainingTokens: "Remaining Tokens"
  },
  
  // Header component
  header: {
    search: "Search...",
    myTeams: "My Teams",
    invitations: "Invitations",
    setupProfile: "Setup Profile",
    subscription: "Subscription",
    settings: "Settings",
    adminPanel: "Admin Panel",
    signOut: "Sign out",
    profile: "Profile",
  },
  
  // Dashboard page
  dashboard: {
    title: "Dashboard",
    subtitle: "Build and track your PMO across all essential domains",
    budget: "Budget",
    editDetails: "Edit Details",
    exportReport: "Export Report",
    access: "Access",
    timelineProgress: "Timeline Progress",
    budgetUtilization: "Budget Utilization",
    projectStatus: "Project Status",
    maturityAssessment: "Maturity Assessment",
    keyObjectives: "Key Objectives",
    stakeholders: "Stakeholders",
    overallProgress: "Overall Progress",
    completedTasks: "Completed Tasks",
    domainProcessComparison:"Domain Progress Comparison",
    organization: "Organization",
    industry: "Industry",
    dashboardCustomization: "Dashboard Customization",
    displayLayout: "Display Layout",
    gridView: "Grid View",
    listView: "List View",
    widgetSelection: "Widget Selection",
    assessMaturityLevel: "Assess Your Maturity Level",
    maturityLevel: "Maturity Level",
    progressOverview: "Progress Overview",
    tasksStatus: "Tasks Status",
    domains: "Domains",
    chartsAnalytics: "Charts & Analytics",
    pmoMaturityLevel: "PMO Maturity Level",
    pmoDomains: "PMO Domains",
    aiAnalysis: "Accelerate with AI",
    aiDescription: "Let our advanced AI analyze your PMO data and generate comprehensive recommendations tailored to your organization's unique needs.",
    tryAiAnalysis: "Try AI Analysis",
    viewAll: "View all",
    of: "of",
    tasksCompleted: "tasks completed",
    notSet: "Not set",
    updateProfile: "Update profile",
    viewAllTasks: "View all tasks",
    nextSteps: "Next Steps",
    uploadDocuments: "Upload documents",
    analysisDocuments: "Upload supporting documents for AI analysis",
    analysisDocumentsDesc: "Enhance AI recommendations with your organization's context",
    completePmoMaturityAssessment: "Complete a PMO Maturity Assessment",
    getInsightsAboutPmoMaturityLevel: "Get insights about your PMO's current maturity level",
    reviewPractices: "Review best practices",
    explorePractices: "Explore the best practices library for guidance",
    viewResources: "View resources",
    goToAssessment: "Go to assessment",
    objective1: "Establish PMO governance framework",
    objective2: "Develop standard methodologies",
    objective3: "Implement performance metrics",
    sampleProject: "Sample PMO Implementation",
    sampleDescription: "A sample project with pre-populated data for demonstration",
    createFirstProject: "Create Your First PMO Project",
    firstProjectDesc: "Get started by creating your first PMO implementation project. You can set up project details, track progress across domains, and generate AI-powered recommendations.",
    createSample: "Create Sample Project",
    aiFeature1: "Custom templates based on your current maturity level",
    aiFeature2: "Detailed implementation roadmaps for each domain",
    aiFeature3: "Best practices tailored to your industry and context",
    maturityRadarChart: "Maturity Radar Chart",
    higherValuesIndicateGreaterMaturity: "Higher values indicate greater maturity",
    pmoMaturityAssessment: "PMO Maturity Assessment",
    assessPmoMaturity: "Assess your PMO's maturity level across all domains to identify strengths and improvement opportunities",
    selfAssessment: "Self-Assessment",
    aiGeneratedAssessment: "AI-Generated Assessment",
    notSpecified: "Not specified",
    currentMaturityProfile: "Current Maturity Profile",
    organizationDetails: "Organization Details",
    assessmentType: "Assessment Type",
    currentMaturityProfileDescription: "Your organization's PMO is currently at the",
    currentMaturityProfileDescription2: "level. This assessment will help you identify areas for improvement and create a roadmap for advancing your PMO capabilities.",
    assessmentDate: "Assessment Date",
    selfAssessmentQuestionnaire: "Self-Assessment Questionnaire",
    selfAssessmentDescription: "Rate your PMO's maturity level for each domain. Consider your processes, documentation, measurement capabilities, and continuous improvement efforts when making your assessment.",
    documentation: "Documentation",
    metrics: "Metrics",
    minimalToNone: "Minimal to none",
    basicDocumentation: "Basic documentation",
    comprehensiveDocumentation: "Comprehensive",
    regularlyUpdated: "Regularly updated",
    leadingPractice: "Leading practice",
    adHocOrNone: "Ad-hoc or none",
    basicTracking: "Basic tracking",
    notes: "Notes (Optional)",
    notesPlaceholder: "Add any notes or context about your assessment...",
    createNew: "Create New Project",
    generateAIAssessment: "Generate an AI Assessment",
    aiAssessmentDescription: "Our AI will analyze your domain inputs, project data, and uploaded documents to provide an objective assessment of your PMO's maturity across all domains.",
    aiAssessmentSummary: "AI Assessment Summary",
    aiAssessmentSummaryDescription: "Based on our analysis, your PMO is currently at the",
    keyStrengths: "Key Strengths",
    areasForImprovement: "Areas for Improvement",
    domainSpecificAssessment: "Domain-Specific Assessment",
    maturityProgression: "Maturity Progression",
    recommendations: "Recommendations",
    generatingReport: "Generating Report...",
    exportAssessmentReport: "Export Assessment Report",
    detailedMaturityGuide: "Detailed Maturity Guide",
    maturityModelReference: "Maturity Model Reference",
    generateAssessment: "Generate Assessment",
    generatingAssessment: "Generating Assessment...",
    generatingAssessmentDescription: "Our AI is analyzing your PMO data across all domains. This may take a few moments.",
    
  },
  
  // Domain detail page
  domain: {
    BestPractices: "Best Practices",
    backToDashboard: "Back to Dashboard",
    prevDomain: "Previous Domain",
    nextDomain: "Next Domain",
    viewDomain: "View Domain",
    progress: "Progress",
    tasks: "Tasks & Progress",
    input: "Domain Input & Analysis",
    analyzing: "Analyzing Domain Input",
    processingData: "Our AI is processing your input data...",
    inputStage: "Input",
    inputDesc: "Collect data, assess current state, and gather requirements for this domain.",
    processingStage: "Processing",
    processingDesc: "Analyze data, develop frameworks, and design solutions for this domain.",
    outputStage: "Output",
    outputDesc: "Create deliverables, implement solutions, and establish frameworks for this domain.",
    loading: "Loading domain data...",
    notFound: "Domain not found",
    provideInputFirst: "Please provide domain input data before analyzing",
    aiGeneratedAnalysis: "AI-Generated Analysis for",
    generated: "Generated",
    analysis: "Analysis",
    domainProgress: "Domain Progress (%)",
    templates: "Templates",
    downloadMarkdown: "Download Markdown",
    downloadPdf: "Download PDF",
    generatingPdf: "Generating PDF...",
    generating: "Generating...",
    allTemplates: "All Available Templates",
    markdownFormat: "Markdown",
    words: "words",
    usingTemplates: "Using These Templates",
    templateDescription: "These templates are available in Markdown and PDF formats. Markdown can be imported into document editors, project management tools, or converted to other formats. PDF files are ready for printing or sharing with stakeholders.",
    noTemplates: "No templates available for this domain",
    aiConfigTitle: "AI Analysis Configuration",
    selectDomainPrompt: "Select a domain to analyze with our advanced AI. The analysis will generate comprehensive recommendations and templates based on your organization's specific context.",
    selectDomain: "Select Domain",
    analysisDepth: "Analysis Depth",
    basic: "Basic",
    quickOverview: "Quick overview",
    standard: "Standard",
    balancedAnalysis: "Balanced analysis",
    detailed: "Detailed",
    inDepthReview: "In-depth review",
    comprehensive: "Comprehensive",
    maximumDetail: "Maximum detail",
    geminiPowered: "Gemini AI Powered Analysis",
    advancedAiDesc: "Advanced AI will analyze your inputs and generate tailored recommendations",
    startAnalysis: "Start Analysis"
  },
  
  // Project management
  project: {
    projectName: "Project Name",
    projectNamePlaceholder: "Enterprise PMO Implementation",
    description: "Description",
    descriptionPlaceholder: "Brief description of your PMO implementation project",
    budget: "Budget",
    yourProjects: "Your Projects",
    createProject: "Create Project"
  },
  
  // Sidebar
  sidebar: {
    dashboard: "Dashboard",
    pmoDomains: "PMO Domains",
    tools: "Tools & Assessment",
    resources: "Resources",
    tasks: "Tasks",
    bestPractices: "Best Practices",
    maturityAssessment: "Maturity Assessment",
    assessment: "Assessment",
  },
  
  // Auth pages
  auth: {
    copyright: "© 2025 PMO Builder using AI by Dr. Ahmed Alsenosy"
  },
  
  // Maturity levels
  maturityLevels: {
    initial: {
      label: 'Initial',
      description: 'Processes are ad hoc and chaotic.'
    },
    defined: {
      label: 'Defined',
      description: 'Processes are documented and standardized.'
    },
    managed: {
      label: 'Managed',
      description: 'Processes are measured and controlled.'
    },
    optimized: {
      label: 'Optimized',
      description: 'Focus on continuous improvement.'
    },
    innovative: {
      label: 'Innovative',
      description: 'Driving industry innovation and adaptation.'
    }
  },

  //profile page
  profile: {
    title: "Organization Profile",
    description: "Set up your organization details to personalize your PMO journey",
    organizationName: "Organization Name",
    organizationNamePlaceholder: "Enter your organization name",
    industry: "Industry",
    industryPlaceholder: "Enter your industry",
    pmoMaturityLevel: "PMO Maturity Level",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "Select the maturity level that best describes your current PMO",
    saveProfile: "Save Profile",
    cancel: "Cancel",
    initial: "Initial - Ad hoc processes",
    defined: "Defined - Basic processes established",
    managed: "Managed - Standardized processes",
    optimized: "Optimized - Continuously improving",
    notEstablished: "Not Established - No formal PMO",
  },
  
  //settings page
  settings: {
    title: "Settings",
    description: "Manage your account settings and preferences",
    personal: "Personal",
    subscription: "Subscription",
    notifications: "Notifications",
    security: "Security",
    data: "Data",
    saveProfile: "Save Profile",
    cancel: "Cancel",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "Select the maturity level that best describes your current PMO",
    organizationName: "Organization Name",
    organizationNamePlaceholder: "Enter your organization name",
    industry: "Industry",
    industryPlaceholder: "Enter your industry",
    pmoMaturityLevel: "PMO Maturity Level",
    notEstablished: "Not Established - No formal PMO",
    initial: "Initial - Ad hoc processes",
    defined: "Defined - Basic processes established",
    managed: "Managed - Standardized processes",
    optimized: "Optimized - Continuously improving",
  },

  // Resources page
  resources: {
    title: "Resources",
    noDocuments: "No documents available",
    errorLoading: "Error loading documents",
    downloadError: "Error downloading document",
    uploadNew: "Upload New Document",
    filter: "Filter Documents",
    sortBy: "Sort By",
    search: "Search Documents",
    lastModified: "Last Modified",
    fileName: "File Name",
    fileSize: "File Size",
    taskName: "Task Name",
    projectId: "Project ID"
  },
 // Help page
  help: {
    title: "Help & Support",
    description: "Learn how to use the PMO Domains Application Tool effectively",
    gettingStarted: "Getting Started",
    whatIsPmoDomainsTool: "What is the PMO Domains Tool?",
    whatIsPmoDomainsToolDescription: `The PMO Domains Application Tool helps PMO professionals apply and monitor the five key PMO domains using a structured "Inputs – Processing – Outputs" framework. The tool guides you through each domain's tasks, ensuring best practices and benchmarking against industry standards.`, 
    howToUseThisTool: "How to Use This Tool",
    howToUseThisToolDescription: "The PMO Domains Application Tool is a web-based application that helps organizations implement and improve their PMO capabilities across all domains.",
    canIExportMyData: "Can I export my data?",
    canIExportMyDataDescription: "Yes, you can export your data from the Settings page. This allows you to back up your progress or transfer it to another system.",
    canICustomizeTheToolForMyOrganization: "Can I customize the tool for my organization?",
    canICustomizeTheToolForMyOrganizationDescription: "The tool is designed to be applicable across different organizations and industries. You can add custom notes to each task to tailor it to your specific organizational context.",
    whatIfINotReadyToCompleteAllDomains: "What if I'm not ready to complete all domains?",
    whatIfINotReadyToCompleteAllDomainsDescription: "You can work on domains in any order that makes sense for your organization. The tool will track your progress across all domains, allowing you to focus on your priorities.",
    contactSupport: "Contact Support",
    contactSupportDescription: "If you need additional help or have questions about the PMO Domains Application Tool, please contact our support team.",
    supportContact: "Support Contact",
    supportContactEmail: "Email: support@pmobuilder.ai",
    supportContactPhone: "Phone: (555) 123-4567",
    supportContactHours: "Hours: Monday-Friday, 9am-5pm EST",
    startBySettingUpYourOrganizationProfile: "Start by setting up your organization profile in the Profile section",
    navigateToEachDomainUsingTheSidebarMenu: "Navigate to each domain using the sidebar menu",
    completeTasksInTheRecommendedOrder: "Complete tasks in the recommended order: Input → Processing → Output",
    markTasksAsCompleteAsYouProgress: "Mark tasks as complete as you progress",
    useTheDashboardToTrackYourOverallProgress: "Use the dashboard to track your overall progress",
    referToTheBestPracticesLibraryForGuidance: "Refer to the Best Practices Library for guidance",
    organizationalDevelopmentAndAlignment: "1. Organizational Development and Alignment",
    organizationalDevelopmentAndAlignmentDescription: "This domain focuses on aligning the PMO with organizational strategy and culture to ensure effective project management practices. It includes organizational assessment, stakeholder analysis, and developing alignment strategies.",
    strategicElementsOfThePmo: "2. Strategic Elements of the PMO",
    strategicElementsOfThePmoDescription: "This domain involves developing and implementing strategic frameworks, roadmaps, and governance structures. It includes strategic objectives review, portfolio analysis, and governance structure design.",
    pMODesignAndStructuring: "3. PMO Design and Structuring",
    pMODesignAndStructuringDescription: "This domain focuses on creating the optimal PMO structure, roles, and responsibilities to meet organizational needs. It includes requirements gathering, resource assessment, and service catalog development.",
    pMOOperationAndPerformance: "4. PMO Operation and Performance",
    pMOOperationAndPerformanceDescription: "This domain establishes operational processes, KPIs, and performance metrics for the PMO. It includes process assessment, performance metrics identification, and performance measurement systems.",
    pMOEnhancementAndEffectiveness: "5. PMO Enhancement and Effectiveness",
    pMOEnhancementAndEffectivenessDescription: "This domain focuses on continuously improving PMO services, capabilities, and value delivery. It includes maturity assessment, value delivery analysis, and continuous improvement planning.",
    frequentlyAskedQuestions: "Frequently Asked Questions",
    frequentlyAskedQuestionsDescription: "The PMO Domains Application Tool is a web-based application that helps organizations implement and improve their PMO capabilities across all domains.",
    howToAccessTemplates: "How do I access templates?",
    howToAccessTemplatesDescription: "Templates are available within specific tasks that have template resources. You can also find a collection of templates in the Best Practices Library",
    understandingTheFiveDomains: "Understanding the Five Domains",
  },
    
  subscription: {
    title: "Subscription Management",
    currentPlan: "Current Plan",
    trial: "Trial",
    cancelsAtPeriodEnd: "Cancels at period end",
    upgradePlan: "Upgrade Plan",
    manageSubscription: "Manage Subscription",
    processing: "Processing...",
    billingPeriod: "Billing Period",
    nextBillingDate: "Next Billing Date",
    paymentMethod: "Payment Method",
    projects: "Projects",
    aiAnalysis: "AI Analysis",
    storage: "Storage",
    freePlanLimitations: "Free plan limitations",
    freePlanLimitationsDescription: "You're currently on the Free plan, which has limitations on projects, AI analyses, and storage. Upgrade to Premium or Enterprise for increased limits and additional features.",
    upgradeNow: "Upgrade Now",
    upgradeToGetMore: "Upgrade to Get More",
    premiumPlanBenefits: "Premium Plan Benefits",
    upTo20Projects: "Up to 20 projects (vs. 3 on Free)",
    upTo100AiAnalyses: "100 AI analyses per month (vs. 3 on Free)",
    teamCollaboration: "Team collaboration with up to 5 users",
    prioritySupport: "Priority support",
    enterprisePlanBenefits: "Enterprise Plan Benefits",
    unlimitedProjectsAndAiAnalyses: "Unlimited projects and AI analyses",
    unlimitedTeamMembers: "Unlimited team members",
    whiteLabelingOptions: "White-labeling options",
    dedicatedSupport: "Dedicated support",
    upgradeToEnterprise: "Upgrade to Enterprise",
    unlimited: "Unlimited",
    unknown: "Unknown",
    free: "Free",
    premium: "Premium",
    enterprise: "Enterprise",
    usageAndLimits: "Usage & Limits",
    perMonth: "per month",
    mb: "MB",
    none: "None",
    creditCard: "Credit Card",
    paypal: "PayPal",
    notAvailable: "Not available",
  },
  
  //notifications
  notifications: {
    '1': {
      title: "PMO Maturity Assessment Due",
      description: "Complete your quarterly PMO maturity assessment by Friday.",
      time: "2 days ago",
    },
    '2': {
      title: "Strategic Elements Domain Updated",
      description: "New templates and resources have been added to the Strategic Elements domain.",
      time: "3 days ago",
    },
    '3': {
      title: "Team Meeting: PMO Enhancement",
      description: "Upcoming team meeting to discuss PMO Enhancement strategies.",
      time: "Tomorrow, 10:00 AM",
    },
    '4': {
      title: "New Message from Admin",
      description: "You have a new message regarding your Organization Development domain progress.",
      time: "1 week ago",
    },
    '5': {
      title: "Data Backup Complete",
      description: "Your PMO data has been successfully backed up to cloud storage.",
      time: "2 weeks ago",
    },
    title: "Notifications",
    description: "Stay updated with your PMO activities and important alerts",
    markAllAsRead: "Mark all as read",
    clearAll: "Clear all",
    markAllAsReadDescription: "Mark all notifications as read",
    clearAllDescription: "Clear all notifications",
    markAllAsReadButton: "Mark all as read",
    clearAllButton: "Clear all",
    unread: "Unread",
    all: "All",
    recentNotifications: "Recent Notifications",
    markAsUnread: "Mark as unread",
    markAsRead: "Mark as read",
    viewDetails: "View details",
    loadMore: "Load more notifications",
    customizeNotifications: "Customize how and when you receive notifications about your PMO activities",
    notificationPreferences: "Notification Preferences",
    managePreferences: "Manage Preferences",
    

  },
  // Domain names
  domains: {
    "1": {
      name: "Organizational Development and Alignment",
      description: "Aligning the PMO with organizational strategy and culture to ensure effective project management practices.",
      tasks: {
        "1-input-1": {
          stage: "input",
          title: "Assess Current Competencies",
          description: "Gather data on existing competencies through surveys, interviews, and documentation review.",
          bestPractices: [
            "Use standardized assessment tools to evaluate current competencies",
            "Collect input from multiple organizational levels",
            "Document both technical and soft skill competencies",
            "Identify competency gaps through structured assessment"
          ]
        },
        "1-input-2": {
          stage: "input",
          title: "Assess Organizational Culture",
          description: "Collect data on current organizational culture through surveys, focus groups, and stakeholder interviews.",
          bestPractices: [
            "Conduct culture assessment surveys",
            "Gather feedback from diverse organizational levels",
            "Document cultural enablers and barriers to project management",
            "Collect historical data on cultural change initiatives"
          ]
        },
        "1-input-3": {
          stage: "input",
          title: "Benchmark Against Industry Standards",
          description: "Collect industry benchmarking data and best practices for organizational alignment.",
          bestPractices: [
            "Select relevant industry benchmarks and standards",
            "Gather data from industry reports and publications",
            "Document peer organization practices",
            "Collect metrics for comparative analysis"
          ]
        },
        "1-processing-1": {
          stage: "processing",
          title: "Apply Strategic Analysis Techniques",
          description: "Use strategic analysis tools to develop an integrated strategy with risk management and implementation roadmap.",
          bestPractices: [
            "Apply SWOT analysis to identify strengths and weaknesses",
            "Use gap analysis to identify improvement areas",
            "Apply risk assessment methodologies",
            "Use roadmapping techniques for implementation planning"
          ]
        },
        "1-processing-2": {
          stage: "processing",
          title: "Apply Communication Planning Methodologies",
          description: "Use communication planning techniques to develop stakeholder-specific messaging and feedback mechanisms.",
          bestPractices: [
            "Apply stakeholder analysis techniques",
            "Use communication matrix development methods",
            "Apply message tailoring methodologies",
            "Use KPI development frameworks for communication effectiveness"
          ]
        },
        "1-processing-3": {
          stage: "processing",
          title: "Apply Charter Development Techniques",
          description: "Use charter development methodologies to define PMO scope, authority, and governance structure.",
          bestPractices: [
            "Apply scope definition techniques",
            "Use RACI matrix development methods",
            "Apply governance framework design methodologies",
            "Use authority mapping techniques"
          ],
          templates: ["PMO Charter Template", "RACI Matrix"]
        },
        "1-output-1": {
          stage: "output",
          title: "Deliver Integrated Strategy and Roadmap",
          description: "Produce and implement the integrated strategy with risk management plan and phased implementation roadmap.",
          bestPractices: [
            "Document comprehensive strategy with clear objectives",
            "Create detailed implementation roadmap with milestones",
            "Develop risk management plan with mitigation strategies",
            "Establish strategy review and update mechanisms"
          ]
        },
        "1-output-2": {
          stage: "output",
          title: "Establish PMO Vision, Values and Culture",
          description: "Implement vision statement, core values, and cultural change program with leadership engagement.",
          bestPractices: [
            "Create compelling vision statement aligned with organization",
            "Document core values with behavioral examples",
            "Implement leadership engagement activities",
            "Establish cultural reinforcement mechanisms"
          ],
          templates: ["PMO Vision Statement Template", "Cultural Change Roadmap"]
        },
        "1-output-3": {
          stage: "output",
          title: "Implement PMO Charter and Governance",
          description: "Establish and operationalize PMO charter with defined scope, authority, and governance structure.",
          bestPractices: [
            "Formalize PMO charter with executive approval",
            "Implement governance structure with clear roles",
            "Establish decision-making authorities and processes",
            "Create charter review and update mechanisms"
          ],
          templates: ["PMO Charter Document", "Governance Structure Diagram"]
        },
      },
    },
    "2": {
      name: "Strategic Framework & Governance",
      description: "Creating the optimal PMO structure, roles, and responsibilities to meet organizational needs.",
      tasks: {
        "2-input-1": {
          stage: "input",
          title: "Gather Current State Data",
          description: "Collect data on current project management operations, processes, and performance.",
          bestPractices: [
            "Conduct process documentation review",
            "Gather performance metrics and historical data",
            "Collect stakeholder feedback on current operations",
            "Document existing governance structures"
          ]
        },
        "2-input-2": {
          stage: "input",
          title: "Collect Strategic Alignment Information",
          description: "Gather organizational strategic objectives, priorities, and success criteria.",
          bestPractices: [
            "Review organizational strategic plans",
            "Collect executive leadership priorities",
            "Document business unit objectives",
            "Gather information on strategic initiatives"
          ]
        },
        "2-input-3": {
          stage: "input",
          title: "Identify Capability Requirements",
          description: "Collect data on required capabilities through stakeholder interviews and organizational needs assessment.",
          bestPractices: [
            "Conduct capability needs interviews",
            "Gather industry capability standards",
            "Document capability prioritization criteria",
            "Collect capability maturity benchmarks"
          ]
        },
        "2-processing-1": {
          stage: "processing",
          title: "Apply Mandate Development Methodology",
          description: "Use mandate development techniques to define PMO purpose, authority, and responsibilities.",
          bestPractices: [
            "Apply purpose statement development methods",
            "Use authority mapping techniques",
            "Apply responsibility definition methodologies",
            "Use stakeholder validation approaches"
          ],
          templates: ["PMO Mandate Template", "Executive Sponsorship Agreement"]
        },
        "2-processing-2": {
          stage: "processing",
          title: "Apply Charter Development Framework",
          description: "Use charter development framework to create comprehensive PMO charter with roles and governance structure.",
          bestPractices: [
            "Apply vision and mission statement techniques",
            "Use organizational structure design methods",
            "Apply role definition methodologies",
            "Use governance framework design techniques"
          ],
          templates: ["PMO Charter Template", "Governance Structure Diagram"]
        },
        "2-processing-3": {
          stage: "processing",
          title: "Apply Governance Design Methodology",
          description: "Use governance design techniques to develop decision-making processes and oversight mechanisms.",
          bestPractices: [
            "Apply decision rights mapping techniques",
            "Use escalation path design methods",
            "Apply governance body design methodologies",
            "Use governance communication planning techniques"
          ],
          templates: ["Governance Framework Template", "Decision Rights Matrix"]
        },
        "2-output-1": {
          stage: "output",
          title: "Establish PMO Mandate and Charter",
          description: "Formalize and implement PMO mandate and charter with defined purpose, authority, and responsibilities.",
          bestPractices: [
            "Obtain executive approval for mandate and charter",
            "Communicate mandate to all stakeholders",
            "Implement authority structures defined in charter",
            "Establish charter review and update process"
          ],
          templates: ["Approved PMO Mandate", "Finalized PMO Charter"]
        },
        "2-output-2": {
          stage: "output",
          title: "Implement Governance Framework",
          description: "Establish and operationalize governance framework with decision-making bodies, processes, and oversight mechanisms.",
          bestPractices: [
            "Form governance committees with clear charters",
            "Implement decision-making processes and authorities",
            "Establish governance meeting cadence and agendas",
            "Create governance documentation and reporting system"
          ],
          templates: ["Governance Committee Charter", "Decision Authority Matrix"]
        },
        "2-output-3": {
          stage: "output",
          title: "Develop Strategic Communication Plan",
          description: "Implement comprehensive communication strategy with stakeholder-specific messaging and feedback mechanisms.",
          bestPractices: [
            "Create stakeholder-specific communication materials",
            "Establish regular communication cadence",
            "Implement feedback collection mechanisms",
            "Develop communication effectiveness metrics"
          ],
          templates: ["Strategic Communication Plan", "Stakeholder Messaging Matrix"]
        },      
      }
    },
    "3": {
      name: "PMO Structure & Design",
      description: "Establishing operational processes, KPIs, and performance metrics for the PMO.",
      tasks: {
        "3-input-1": {
          stage: "input",
          title: "Gather Customer Data",
          description: "Collect data on potential PMO customers, their needs, and expectations through surveys and interviews.",
          bestPractices: [
            "Conduct customer needs assessment surveys",
            "Gather stakeholder interview data",
            "Document customer pain points and expectations",
            "Collect service prioritization information"
          ]
        },
        "3-input-2": {
          stage: "input",
          title: "Collect Service Requirement Data",
          description: "Gather detailed requirements for potential PMO services through workshops and requirements sessions.",
          bestPractices: [
            "Conduct service requirements workshops",
            "Document service level expectations",
            "Collect service prioritization criteria",
            "Gather benchmark data on similar services"
          ],
          templates: ["Service Requirements Template", "Customer Needs Assessment"]
        },
        "3-input-3": {
          stage: "input",
          title: "Assess Capability Gaps",
          description: "Collect data on current capabilities and gaps through assessment tools and stakeholder feedback.",
          bestPractices: [
            "Use capability maturity assessment tools",
            "Gather capability benchmark data",
            "Document capability prioritization criteria",
            "Collect resource availability information"
          ]
        },
        "3-processing-1": {
          stage: "processing",
          title: "Apply Persona Development Techniques",
          description: "Use persona development methodologies to create detailed customer personas with needs and expectations.",
          bestPractices: [
            "Apply customer segmentation techniques",
            "Use persona development frameworks",
            "Apply needs analysis methodologies",
            "Use journey mapping techniques"
          ]
        },
        "3-processing-2": {
          stage: "processing",
          title: "Apply Prioritization Frameworks",
          description: "Use prioritization techniques to develop framework for addressing customer needs systematically.",
          bestPractices: [
            "Apply value vs. effort prioritization matrix",
            "Use MoSCoW prioritization technique",
            "Apply weighted scoring methodologies",
            "Use impact mapping techniques"
          ]
        },
        "3-processing-3": {
          stage: "processing",
          title: "Apply Service Catalog Design Methodology",
          description: "Use service catalog design techniques to develop comprehensive service offerings with benefits and advantages.",
          bestPractices: [
            "Apply service definition frameworks",
            "Use service level definition techniques",
            "Apply value proposition development methodologies",
            "Use service categorization techniques"
          ],
          templates: ["Service Catalog Template", "Service Level Agreement Template"]
        },
        "3-output-1": {
          stage: "output",
          title: "Deliver Customer Personas and Journey Maps",
          description: "Create and distribute detailed customer personas and journey maps to guide service design and delivery.",
          bestPractices: [
            "Document comprehensive personas with needs and pain points",
            "Create visual journey maps for key customer interactions",
            "Distribute personas to all service delivery teams",
            "Establish persona update and refinement process"
          ],
          templates: ["Customer Persona Template", "Journey Map Template"]
        },
        "3-output-2": {
          stage: "output",
          title: "Implement Service Catalog and SLAs",
          description: "Launch comprehensive service catalog with service level agreements, processes, and quality standards.",
          bestPractices: [
            "Create detailed service descriptions with value propositions",
            "Establish service level metrics and targets",
            "Implement service request and delivery processes",
            "Create service catalog review and update mechanism"
          ],
          templates: ["Service Catalog Document", "SLA Documentation"]
        },
        "3-output-3": {
          stage: "output",
          title: "Establish Service Prioritization Framework",
          description: "Implement systematic approach for prioritizing and addressing customer needs and service requests.",
          bestPractices: [
            "Create prioritization criteria and scoring system",
            "Implement request intake and evaluation process",
            "Establish resource allocation based on priorities",
            "Develop priority review and adjustment mechanisms"
          ],
          templates: ["Prioritization Matrix", "Service Request Form"]
        },      
      }
    },
    "4": {
      name: "Operational Excellence",
      description: "Ensuring efficient and effective project management processes and tools.",
      tasks: {
        "4-input-1": {
          stage: "input",
          title: "Gather Onboarding Requirements",
          description: "Collect requirements and expectations for customer onboarding process through stakeholder input.",
          bestPractices: [
            "Conduct onboarding needs assessment",
            "Gather stakeholder expectations for onboarding",
            "Document current onboarding challenges",
            "Collect onboarding best practices"
          ]
        },
        "4-input-2": {
          stage: "input",
          title: "Collect Documentation Requirements",
          description: "Gather requirements for process documentation, user guides, and training materials.",
          bestPractices: [
            "Conduct documentation needs assessment",
            "Gather user preferences for documentation formats",
            "Document current documentation gaps",
            "Collect documentation best practices"
          ],
          templates: ["Documentation Requirements Template", "User Guide Outline"]
        },
        "4-input-3": {
          stage: "input",
          title: "Assess Training Needs",
          description: "Collect data on training needs, preferences, and delivery methods through surveys and interviews.",
          bestPractices: [
            "Conduct training needs assessment",
            "Gather learning style preferences",
            "Document knowledge and skill gaps",
            "Collect training effectiveness criteria"
          ]
        },
        "4-processing-1": {
          stage: "processing",
          title: "Apply Quality Management Techniques",
          description: "Use quality management methodologies to develop quality control measures and improvement processes.",
          bestPractices: [
            "Apply quality standards development techniques",
            "Use quality control checkpoint design methods",
            "Apply quality metrics development frameworks",
            "Use continuous improvement methodologies"
          ]
        },
        "4-processing-2": {
          stage: "processing",
          title: "Apply Resource Management Methodologies",
          description: "Use resource management techniques to develop allocation systems and capacity planning processes.",
          bestPractices: [
            "Apply resource capacity planning techniques",
            "Use resource allocation prioritization methods",
            "Apply resource forecasting methodologies",
            "Use resource utilization optimization techniques"
          ],
          templates: ["Resource Management Plan", "Capacity Planning Template"]
        },
        "4-processing-3": {
          stage: "processing",
          title: "Apply Issue Management Framework",
          description: "Use issue management methodologies to develop escalation procedures and resolution processes.",
          bestPractices: [
            "Apply escalation threshold definition techniques",
            "Use escalation path design methods",
            "Apply issue categorization frameworks",
            "Use resolution time standard development techniques"
          ],
          templates: ["Escalation Procedure Template", "Issue Management Framework"]
        },
        "4-output-1": {
          stage: "output",
          title: "Implement Quality Management System",
          description: "Establish comprehensive quality management system with standards, control processes, and improvement mechanisms.",
          bestPractices: [
            "Document quality standards for all services",
            "Implement quality control checkpoints and reviews",
            "Establish quality metrics collection and reporting",
            "Create continuous quality improvement process"
          ],
          templates: ["Quality Standards Document", "Quality Review Checklist"]
        },
        "4-output-2": {
          stage: "output",
          title: "Establish Resource Management System",
          description: "Implement resource management system with capacity planning, allocation processes, and utilization tracking.",
          bestPractices: [
            "Create resource inventory and skills matrix",
            "Implement capacity planning and forecasting process",
            "Establish resource allocation and assignment procedures",
            "Develop resource utilization tracking and reporting"
          ],
          templates: ["Resource Allocation Matrix", "Capacity Planning Dashboard"]
        },
        "4-output-3": {
          stage: "output",
          title: "Deploy Issue Management System",
          description: "Implement comprehensive issue management system with escalation procedures, tracking, and resolution processes.",
          bestPractices: [
            "Establish issue intake and categorization process",
            "Implement escalation paths and notification system",
            "Create issue tracking and status reporting",
            "Develop resolution verification and closure procedures"
          ],
          templates: ["Issue Management Playbook", "Escalation Matrix"]
        },      
      }
    },
    "5": {
      name: "Performance & Improvement",
      description: "Continuously improving PMO services, capabilities, and value delivery.",
      tasks: {
        "5-input-1": {
          stage: "input",
          title: "Gather Maturity Assessment Data",
          description: "Collect data on current PMO maturity through assessment tools, surveys, and stakeholder feedback.",
          bestPractices: [
            "Select appropriate maturity assessment tool",
            "Gather comprehensive assessment data",
            "Document maturity baseline across dimensions",
            "Collect maturity target information"
          ]
        },
        "5-input-2": {
          stage: "input",
          title: "Collect Performance Data",
          description: "Gather current performance metrics, historical trends, and performance targets.",
          bestPractices: [
            "Collect current performance metrics",
            "Gather historical performance data",
            "Document performance targets and thresholds",
            "Collect performance benchmark information"
          ]
        },
        "5-input-3": {
          stage: "input",
          title: "Assess Value Measurement Approaches",
          description: "Collect data on potential value metrics, measurement approaches, and value demonstration methods.",
          bestPractices: [
            "Gather value metric options",
            "Collect value measurement methodologies",
            "Document value perception from stakeholders",
            "Assess current value demonstration approaches"
          ]
        },
        "5-processing-1": {
          stage: "processing",
          title: "Apply Maturity Roadmapping Techniques",
          description: "Use maturity roadmapping methodologies to develop enhancement plan with milestones and metrics.",
          bestPractices: [
            "Apply maturity gap analysis techniques",
            "Use capability prioritization methods",
            "Apply milestone development frameworks",
            "Use metric definition techniques"
          ]
        },
        "5-processing-2": {
          stage: "processing",
          title: "Apply Change Management Methodologies",
          description: "Use change management techniques to develop implementation approach for maturity initiatives.",
          bestPractices: [
            "Apply stakeholder impact analysis techniques",
            "Use resistance management methods",
            "Apply communication planning frameworks",
            "Use adoption measurement techniques"
          ],
          templates: ["Change Management Plan", "Stakeholder Engagement Plan"]
        },
        "5-processing-3": {
          stage: "processing",
          title: "Apply Continuous Improvement Frameworks",
          description: "Use continuous improvement methodologies to develop systematic improvement processes.",
          bestPractices: [
            "Apply improvement opportunity identification techniques",
            "Use improvement prioritization methods",
            "Apply implementation planning frameworks",
            "Use effectiveness measurement techniques"
          ]
        },
        "5-output-1": {
          stage: "output",
          title: "Implement Maturity Enhancement Roadmap",
          description: "Establish and execute comprehensive maturity enhancement roadmap with milestones, metrics, and review processes.",
          bestPractices: [
            "Document detailed maturity enhancement plan",
            "Implement milestone tracking and reporting",
            "Establish maturity metric collection and analysis",
            "Create regular maturity review and adjustment process"
          ],
          templates: ["Maturity Enhancement Roadmap", "Maturity Metrics Dashboard"]
        },
        "5-output-2": {
          stage: "output",
          title: "Establish Value Measurement System",
          description: "Implement comprehensive value measurement system with metrics, reporting, and demonstration mechanisms.",
          bestPractices: [
            "Define and implement value metrics and KPIs",
            "Create value data collection and analysis process",
            "Establish value reporting and visualization",
            "Develop value demonstration case studies"
          ],
          templates: ["Value Measurement Framework", "Value Dashboard"]
        },
        "5-output-3": {
          stage: "output",
          title: "Deploy Continuous Improvement Program",
          description: "Implement systematic continuous improvement program with identification, prioritization, and implementation processes.",
          bestPractices: [
            "Establish improvement opportunity identification process",
            "Create improvement prioritization and selection system",
            "Implement improvement tracking and reporting",
            "Develop improvement effectiveness measurement"
          ],
          templates: ["Continuous Improvement Playbook", "Improvement Tracking System"]
        },      
      }
    },
    "6": {
      name: "Capability Development",
      description: "Developing and managing the human aspects of the PMO including competency, training, and leadership.",
      tasks: {
        "6-input-1": {
          stage: "input",
          title: "Gather Decision-Making Data",
          description: "Collect data on current decision-making processes, data utilization, and improvement opportunities.",
          bestPractices: [
            "Document current decision-making processes",
            "Assess data utilization in decisions",
            "Identify decision-making bottlenecks",
            "Gather decision quality metrics"
          ]
        },
        "6-input-2": {
          stage: "input",
          title: "Assess Competency Requirements",
          description: "Collect data on required competencies, current capabilities, and development needs.",
          bestPractices: [
            "Document role-specific competency requirements",
            "Assess current competency levels",
            "Identify critical competency gaps",
            "Gather development preference information"
          ],
          templates: ["Competency Assessment Template", "Development Needs Analysis"]
        },
        "6-input-3": {
          stage: "input",
          title: "Collect Skills Assessment Data",
          description: "Gather comprehensive skills data through assessments, self-evaluations, and manager feedback.",
          bestPractices: [
            "Use standardized skills assessment tools",
            "Gather self-assessment data",
            "Collect manager assessment input",
            "Document skills prioritization criteria"
          ]
        },
        "6-processing-1": {
          stage: "processing",
          title: "Apply Training Program Design Methodology",
          description: "Use training design techniques to develop comprehensive training and certification programs.",
          bestPractices: [
            "Apply learning objective development techniques",
            "Use curriculum design methodologies",
            "Apply learning modality selection frameworks",
            "Use training effectiveness measurement design"
          ]
        },
        "6-processing-2": {
          stage: "processing",
          title: "Apply Innovation Framework Development",
          description: "Use innovation framework techniques to develop processes for fostering innovation and problem-solving.",
          bestPractices: [
            "Apply innovation process design methodologies",
            "Use idea generation technique selection",
            "Apply idea evaluation framework development",
            "Use innovation incentive system design"
          ]
        },
        "6-processing-3": {
          stage: "processing",
          title: "Apply Knowledge Management Techniques",
          description: "Use knowledge management methodologies to design knowledge-sharing platform and communities of practice.",
          bestPractices: [
            "Apply knowledge repository design techniques",
            "Use knowledge categorization frameworks",
            "Apply community of practice design methodologies",
            "Use knowledge contribution incentive design"
          ]
        },
        "6-output-1": {
          stage: "output",
          title: "Implement Competency Development Framework",
          description: "Establish comprehensive competency framework with assessment, development paths, and certification programs.",
          bestPractices: [
            "Document role-specific competency requirements",
            "Create competency assessment and tracking system",
            "Implement development paths for each competency area",
            "Establish certification and recognition program"
          ],
          templates: ["Competency Framework Document", "Development Path Guide"]
        },
        "6-output-2": {
          stage: "output",
          title: "Deploy Innovation and Problem-Solving System",
          description: "Implement structured innovation program with idea generation, evaluation, and implementation processes.",
          bestPractices: [
            "Establish idea generation and collection system",
            "Create idea evaluation and selection process",
            "Implement innovation implementation support",
            "Develop innovation recognition and incentives"
          ],
          templates: ["Innovation Process Playbook", "Idea Evaluation Matrix"]
        },
        "6-output-3": {
          stage: "output",
          title: "Establish Knowledge Management System",
          description: "Implement comprehensive knowledge management system with repository, sharing mechanisms, and communities of practice.",
          bestPractices: [
            "Create knowledge repository with categorization system",
            "Establish knowledge contribution processes",
            "Form communities of practice with clear charters",
            "Implement knowledge sharing events and activities"
          ],
          templates: ["Knowledge Management Guide", "Community of Practice Charter"]
        }
      }
    }
  },

  // Tasks
  tasks: {
    tasks: "Tasks",
    manageAndTrackYourPmoImplementationTasks: "Manage and track your PMO implementation tasks",
    allTasks: "All Tasks",
    completed: "Completed",
    incomplete: "Incomplete",
    progress: "Progress",
    total: "Total",
    rate: "Rate",
    addCustomTask: "Add Custom Task",
    searchTasks: "Search tasks...",
    filters: "Filters",
    clear: "Clear",
    allDomains: "All Domains",
    allStages: "All Stages",
    input: "Input",
    processing: "Processing",
    output: "Output",
    domain: "Domain",
    stage: "Stage",
    status: "Status",
    clearFilters: "Clear Filters",
    noTasksFound: "No tasks found",
    noTasksMatchFilters: "No tasks match your current filters. Try adjusting or clearing your filters.",
    noTasksAvailable: "No tasks available. Start by creating a new task.",
    taskManagementTips: "Task Management Tips",
    taskManagementTipsDescription: "Prioritize tasks based on your PMO maturity level and organizational goals. Complete the Input stage tasks first before moving to Processing and Output stages for the best results.",
    viewBestPractices: "View Best Practices",
    relatedDocuments: "Related Documents",
    viewFullContent: "View Full Content",
    generateTaskOutput: "Generate Task Output",
    templates: "Templates",
    templateForStandardizedImplementation: "Template for standardized implementation",
    viewTemplate: "View Template",
    bestPractices: "Best Practices",
    priority: "Priority",
    targetCompletionDate: "Target Completion Date",
    assignedTo: "Assigned To",
    estimatedHours: "Estimated Hours",
    attachments: "Attachments",
    notes: "Notes",
    availableTemplates: "Available Templates",
    purpose: "Purpose",
    templateForStandardized: "This template provides a structured framework for implementing and managing",
    withinYourPMO: "processes within your PMO",
    overview: "Overview",
    download: "Download",
    useTemplate: "Use Template",
    close: "Close",
    save:"Save",
    template: `
## Template Sections

### 1. Introduction
- Purpose and objectives
- Scope and applicability
- Key stakeholders

### 2. Process Framework
- Methodology overview
- Key activities and deliverables
- Roles and responsibilities

### 3. Implementation Guide
- Step-by-step instructions
- Best practices and guidelines
- Common challenges and solutions

### 4. Monitoring and Control
- Key performance indicators
- Quality assurance measures
- Reporting requirements

### 5. Continuous Improvement
- Feedback mechanisms
- Review process
- Update procedures

## Appendices
- Related templates and tools
- Reference materials
- Glossary of terms

---

*This template is part of the PMO Builder library. Customize it to fit your organization's specific needs.*`,
  }
};

// Translation keys organized by component/page
// English translations
const en = {
  // Common components
  common: {
    pleaseWait: "Please wait while we prepare your content.",
    Complete : "Complete",
    search: "Search",
    save: "Save",
    saveAssessment: "Save Assessment",
    saved: "Saved!",
    showLess: "Show less",
    showMore: "Show more",
    cancel: "Cancel",
    edit: "Edit",
    delete: "Delete",
    close: "Close",
    loading: "Loading...",
    submit: "Submit",
    active: "Active",
    back: "Back",
    spent: "Spent",
    used: "Used",
    onTrack: "On Track",
    viewDetails: "View Details",
    tasks: "Tasks",
    domains: "Domains",
    budget: "Budget",
    daysLeft: "days left",
    next: "Next",
    progress: "Progress",
    notifications: "Notifications",
    help: "Help",
    settings: "Settings",
    profile: "Profile",
    signOut: "Sign Out",
    dashboard: "Dashboard",
    export: "Export",
    import: "Import",
    share: "Share",
    days: "days",
    darkMode: "Dark Mode",
    lightMode: "Light Mode",
    confirm: "Confirm",
    remainingTokens: "Remaining Tokens"
  },
  
  // Header component
  header: {
    search: "Search...",
    myTeams: "My Teams",
    invitations: "Invitations",
    setupProfile: "Setup Profile",
    subscription: "Subscription",
    settings: "Settings",
    adminPanel: "Admin Panel",
    signOut: "Sign out",
    profile: "Profile",
  },
  
  // Dashboard page
  dashboard: {
    title: "Dashboard",
    subtitle: "Build and track your PMO across all essential domains",
    budget: "Budget",
    editDetails: "Edit Details",
    exportReport: "Export Report",
    access: "Access",
    timelineProgress: "Timeline Progress",
    budgetUtilization: "Budget Utilization",
    projectStatus: "Project Status",
    maturityAssessment: "Maturity Assessment",
    keyObjectives: "Key Objectives",
    stakeholders: "Stakeholders",
    overallProgress: "Overall Progress",
    completedTasks: "Completed Tasks",
    domainProcessComparison:"Domain Progress Comparison",
    organization: "Organization",
    industry: "Industry",
    dashboardCustomization: "Dashboard Customization",
    displayLayout: "Display Layout",
    gridView: "Grid View",
    listView: "List View",
    widgetSelection: "Widget Selection",
    assessMaturityLevel: "Assess Your Maturity Level",
    maturityLevel: "Maturity Level",
    progressOverview: "Progress Overview",
    tasksStatus: "Tasks Status",
    domains: "Domains",
    chartsAnalytics: "Charts & Analytics",
    pmoMaturityLevel: "PMO Maturity Level",
    pmoDomains: "PMO Domains",
    aiAnalysis: "Accelerate with AI",
    aiDescription: "Let our advanced AI analyze your PMO data and generate comprehensive recommendations tailored to your organization's unique needs.",
    tryAiAnalysis: "Try AI Analysis",
    viewAll: "View all",
    of: "of",
    tasksCompleted: "tasks completed",
    notSet: "Not set",
    updateProfile: "Update profile",
    viewAllTasks: "View all tasks",
    nextSteps: "Next Steps",
    uploadDocuments: "Upload documents",
    analysisDocuments: "Upload supporting documents for AI analysis",
    analysisDocumentsDesc: "Enhance AI recommendations with your organization's context",
    completePmoMaturityAssessment: "Complete a PMO Maturity Assessment",
    getInsightsAboutPmoMaturityLevel: "Get insights about your PMO's current maturity level",
    reviewPractices: "Review best practices",
    explorePractices: "Explore the best practices library for guidance",
    viewResources: "View resources",
    goToAssessment: "Go to assessment",
    objective1: "Establish PMO governance framework",
    objective2: "Develop standard methodologies",
    objective3: "Implement performance metrics",
    sampleProject: "Sample PMO Implementation",
    sampleDescription: "A sample project with pre-populated data for demonstration",
    createFirstProject: "Create Your First PMO Project",
    firstProjectDesc: "Get started by creating your first PMO implementation project. You can set up project details, track progress across domains, and generate AI-powered recommendations.",
    createSample: "Create Sample Project",
    aiFeature1: "Custom templates based on your current maturity level",
    aiFeature2: "Detailed implementation roadmaps for each domain",
    aiFeature3: "Best practices tailored to your industry and context",
    maturityRadarChart: "Maturity Radar Chart",
    higherValuesIndicateGreaterMaturity: "Higher values indicate greater maturity",
    pmoMaturityAssessment: "PMO Maturity Assessment",
    assessPmoMaturity: "Assess your PMO's maturity level across all domains to identify strengths and improvement opportunities",
    selfAssessment: "Self-Assessment",
    aiGeneratedAssessment: "AI-Generated Assessment",
    notSpecified: "Not specified",
    currentMaturityProfile: "Current Maturity Profile",
    organizationDetails: "Organization Details",
    assessmentType: "Assessment Type",
    currentMaturityProfileDescription: "Your organization's PMO is currently at the",
    currentMaturityProfileDescription2: "level. This assessment will help you identify areas for improvement and create a roadmap for advancing your PMO capabilities.",
    assessmentDate: "Assessment Date",
    selfAssessmentQuestionnaire: "Self-Assessment Questionnaire",
    selfAssessmentDescription: "Rate your PMO's maturity level for each domain. Consider your processes, documentation, measurement capabilities, and continuous improvement efforts when making your assessment.",
    documentation: "Documentation",
    metrics: "Metrics",
    minimalToNone: "Minimal to none",
    basicDocumentation: "Basic documentation",
    comprehensiveDocumentation: "Comprehensive",
    regularlyUpdated: "Regularly updated",
    leadingPractice: "Leading practice",
    adHocOrNone: "Ad-hoc or none",
    basicTracking: "Basic tracking",
    notes: "Notes (Optional)",
    notesPlaceholder: "Add any notes or context about your assessment...",
    createNew: "Create New Project",
    generateAIAssessment: "Generate an AI Assessment",
    aiAssessmentDescription: "Our AI will analyze your domain inputs, project data, and uploaded documents to provide an objective assessment of your PMO's maturity across all domains.",
    aiAssessmentSummary: "AI Assessment Summary",
    aiAssessmentSummaryDescription: "Based on our analysis, your PMO is currently at the",
    keyStrengths: "Key Strengths",
    areasForImprovement: "Areas for Improvement",
    domainSpecificAssessment: "Domain-Specific Assessment",
    maturityProgression: "Maturity Progression",
    recommendations: "Recommendations",
    generatingReport: "Generating Report...",
    exportAssessmentReport: "Export Assessment Report",
    detailedMaturityGuide: "Detailed Maturity Guide",
    maturityModelReference: "Maturity Model Reference",
    generateAssessment: "Generate Assessment",
    generatingAssessment: "Generating Assessment...",
    generatingAssessmentDescription: "Our AI is analyzing your PMO data across all domains. This may take a few moments.",
    
  },
  
  // Domain detail page
  domain: {
    BestPractices: "Best Practices",
    backToDashboard: "Back to Dashboard",
    prevDomain: "Previous Domain",
    nextDomain: "Next Domain",
    viewDomain: "View Domain",
    progress: "Progress",
    tasks: "Tasks & Progress",
    input: "Domain Input & Analysis",
    analyzing: "Analyzing Domain Input",
    processingData: "Our AI is processing your input data...",
    inputStage: "Input",
    inputDesc: "Collect data, assess current state, and gather requirements for this domain.",
    processingStage: "Processing",
    processingDesc: "Analyze data, develop frameworks, and design solutions for this domain.",
    outputStage: "Output",
    outputDesc: "Create deliverables, implement solutions, and establish frameworks for this domain.",
    loading: "Loading domain data...",
    notFound: "Domain not found",
    provideInputFirst: "Please provide domain input data before analyzing",
    aiGeneratedAnalysis: "AI-Generated Analysis for",
    generated: "Generated",
    analysis: "Analysis",
    domainProgress: "Domain Progress (%)",
    templates: "Templates",
    downloadMarkdown: "Download Markdown",
    downloadPdf: "Download PDF",
    generatingPdf: "Generating PDF...",
    generating: "Generating...",
    allTemplates: "All Available Templates",
    markdownFormat: "Markdown",
    words: "words",
    usingTemplates: "Using These Templates",
    templateDescription: "These templates are available in Markdown and PDF formats. Markdown can be imported into document editors, project management tools, or converted to other formats. PDF files are ready for printing or sharing with stakeholders.",
    noTemplates: "No templates available for this domain",
    aiConfigTitle: "AI Analysis Configuration",
    selectDomainPrompt: "Select a domain to analyze with our advanced AI. The analysis will generate comprehensive recommendations and templates based on your organization's specific context.",
    selectDomain: "Select Domain",
    analysisDepth: "Analysis Depth",
    basic: "Basic",
    quickOverview: "Quick overview",
    standard: "Standard",
    balancedAnalysis: "Balanced analysis",
    detailed: "Detailed",
    inDepthReview: "In-depth review",
    comprehensive: "Comprehensive",
    maximumDetail: "Maximum detail",
    geminiPowered: "Gemini AI Powered Analysis",
    advancedAiDesc: "Advanced AI will analyze your inputs and generate tailored recommendations",
    startAnalysis: "Start Analysis"
  },
  
  // Project management
  project: {
    projectName: "Project Name",
    projectNamePlaceholder: "Enterprise PMO Implementation",
    description: "Description",
    descriptionPlaceholder: "Brief description of your PMO implementation project",
    budget: "Budget",
    yourProjects: "Your Projects",
    createProject: "Create Project"
  },
  
  // Sidebar
  sidebar: {
    dashboard: "Dashboard",
    pmoDomains: "PMO Domains",
    tools: "Tools & Assessment",
    resources: "Resources",
    tasks: "Tasks",
    bestPractices: "Best Practices",
    maturityAssessment: "Maturity Assessment",
    assessment: "Assessment",
  },
  
  // Auth pages
  auth: {
    copyright: "© 2025 PMO Builder using AI by Dr. Ahmed Alsenosy"
  },
  
  // Maturity levels
  maturityLevels: {
    initial: {
      label: 'Initial',
      description: 'Processes are ad hoc and chaotic.'
    },
    defined: {
      label: 'Defined',
      description: 'Processes are documented and standardized.'
    },
    managed: {
      label: 'Managed',
      description: 'Processes are measured and controlled.'
    },
    optimized: {
      label: 'Optimized',
      description: 'Focus on continuous improvement.'
    },
    innovative: {
      label: 'Innovative',
      description: 'Driving industry innovation and adaptation.'
    }
  },

  //profile page
  profile: {
    title: "Organization Profile",
    description: "Set up your organization details to personalize your PMO journey",
    organizationName: "Organization Name",
    organizationNamePlaceholder: "Enter your organization name",
    industry: "Industry",
    industryPlaceholder: "Enter your industry",
    pmoMaturityLevel: "PMO Maturity Level",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "Select the maturity level that best describes your current PMO",
    saveProfile: "Save Profile",
    cancel: "Cancel",
    initial: "Initial - Ad hoc processes",
    defined: "Defined - Basic processes established",
    managed: "Managed - Standardized processes",
    optimized: "Optimized - Continuously improving",
    notEstablished: "Not Established - No formal PMO",
  },
  
  //settings page
  settings: {
    title: "Settings",
    description: "Manage your account settings and preferences",
    personal: "Personal",
    subscription: "Subscription",
    notifications: "Notifications",
    security: "Security",
    data: "Data",
    saveProfile: "Save Profile",
    cancel: "Cancel",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "Select the maturity level that best describes your current PMO",
    organizationName: "Organization Name",
    organizationNamePlaceholder: "Enter your organization name",
    industry: "Industry",
    industryPlaceholder: "Enter your industry",
    pmoMaturityLevel: "PMO Maturity Level",
    notEstablished: "Not Established - No formal PMO",
    initial: "Initial - Ad hoc processes",
    defined: "Defined - Basic processes established",
    managed: "Managed - Standardized processes",
    optimized: "Optimized - Continuously improving",
  },

  // Resources page
  resources: {
    title: "Resources",
    noDocuments: "No documents available",
    errorLoading: "Error loading documents",
    downloadError: "Error downloading document",
    uploadNew: "Upload New Document",
    filter: "Filter Documents",
    sortBy: "Sort By",
    search: "Search Documents",
    lastModified: "Last Modified",
    fileName: "File Name",
    fileSize: "File Size",
    taskName: "Task Name",
    projectId: "Project ID"
  },
 // Help page
  help: {
    title: "Help & Support",
    description: "Learn how to use the PMO Domains Application Tool effectively",
    gettingStarted: "Getting Started",
    whatIsPmoDomainsTool: "What is the PMO Domains Tool?",
    whatIsPmoDomainsToolDescription: `The PMO Domains Application Tool helps PMO professionals apply and monitor the five key PMO domains using a structured "Inputs – Processing – Outputs" framework. The tool guides you through each domain's tasks, ensuring best practices and benchmarking against industry standards.`, 
    howToUseThisTool: "How to Use This Tool",
    howToUseThisToolDescription: "The PMO Domains Application Tool is a web-based application that helps organizations implement and improve their PMO capabilities across all domains.",
    canIExportMyData: "Can I export my data?",
    canIExportMyDataDescription: "Yes, you can export your data from the Settings page. This allows you to back up your progress or transfer it to another system.",
    canICustomizeTheToolForMyOrganization: "Can I customize the tool for my organization?",
    canICustomizeTheToolForMyOrganizationDescription: "The tool is designed to be applicable across different organizations and industries. You can add custom notes to each task to tailor it to your specific organizational context.",
    whatIfINotReadyToCompleteAllDomains: "What if I'm not ready to complete all domains?",
    whatIfINotReadyToCompleteAllDomainsDescription: "You can work on domains in any order that makes sense for your organization. The tool will track your progress across all domains, allowing you to focus on your priorities.",
    contactSupport: "Contact Support",
    contactSupportDescription: "If you need additional help or have questions about the PMO Domains Application Tool, please contact our support team.",
    supportContact: "Support Contact",
    supportContactEmail: "Email: support@pmobuilder.ai",
    supportContactPhone: "Phone: (555) 123-4567",
    supportContactHours: "Hours: Monday-Friday, 9am-5pm EST",
    startBySettingUpYourOrganizationProfile: "Start by setting up your organization profile in the Profile section",
    navigateToEachDomainUsingTheSidebarMenu: "Navigate to each domain using the sidebar menu",
    completeTasksInTheRecommendedOrder: "Complete tasks in the recommended order: Input → Processing → Output",
    markTasksAsCompleteAsYouProgress: "Mark tasks as complete as you progress",
    useTheDashboardToTrackYourOverallProgress: "Use the dashboard to track your overall progress",
    referToTheBestPracticesLibraryForGuidance: "Refer to the Best Practices Library for guidance",
    organizationalDevelopmentAndAlignment: "1. Organizational Development and Alignment",
    organizationalDevelopmentAndAlignmentDescription: "This domain focuses on aligning the PMO with organizational strategy and culture to ensure effective project management practices. It includes organizational assessment, stakeholder analysis, and developing alignment strategies.",
    strategicElementsOfThePmo: "2. Strategic Elements of the PMO",
    strategicElementsOfThePmoDescription: "This domain involves developing and implementing strategic frameworks, roadmaps, and governance structures. It includes strategic objectives review, portfolio analysis, and governance structure design.",
    pMODesignAndStructuring: "3. PMO Design and Structuring",
    pMODesignAndStructuringDescription: "This domain focuses on creating the optimal PMO structure, roles, and responsibilities to meet organizational needs. It includes requirements gathering, resource assessment, and service catalog development.",
    pMOOperationAndPerformance: "4. PMO Operation and Performance",
    pMOOperationAndPerformanceDescription: "This domain establishes operational processes, KPIs, and performance metrics for the PMO. It includes process assessment, performance metrics identification, and performance measurement systems.",
    pMOEnhancementAndEffectiveness: "5. PMO Enhancement and Effectiveness",
    pMOEnhancementAndEffectivenessDescription: "This domain focuses on continuously improving PMO services, capabilities, and value delivery. It includes maturity assessment, value delivery analysis, and continuous improvement planning.",
    frequentlyAskedQuestions: "Frequently Asked Questions",
    frequentlyAskedQuestionsDescription: "The PMO Domains Application Tool is a web-based application that helps organizations implement and improve their PMO capabilities across all domains.",
    howToAccessTemplates: "How do I access templates?",
    howToAccessTemplatesDescription: "Templates are available within specific tasks that have template resources. You can also find a collection of templates in the Best Practices Library",
    understandingTheFiveDomains: "Understanding the Five Domains",
  },
    
  subscription: {
    title: "Subscription Management",
    currentPlan: "Current Plan",
    trial: "Trial",
    cancelsAtPeriodEnd: "Cancels at period end",
    upgradePlan: "Upgrade Plan",
    manageSubscription: "Manage Subscription",
    processing: "Processing...",
    billingPeriod: "Billing Period",
    nextBillingDate: "Next Billing Date",
    paymentMethod: "Payment Method",
    projects: "Projects",
    aiAnalysis: "AI Analysis",
    storage: "Storage",
    freePlanLimitations: "Free plan limitations",
    freePlanLimitationsDescription: "You're currently on the Free plan, which has limitations on projects, AI analyses, and storage. Upgrade to Premium or Enterprise for increased limits and additional features.",
    upgradeNow: "Upgrade Now",
    upgradeToGetMore: "Upgrade to Get More",
    premiumPlanBenefits: "Premium Plan Benefits",
    upTo20Projects: "Up to 20 projects (vs. 3 on Free)",
    upTo100AiAnalyses: "100 AI analyses per month (vs. 3 on Free)",
    teamCollaboration: "Team collaboration with up to 5 users",
    prioritySupport: "Priority support",
    enterprisePlanBenefits: "Enterprise Plan Benefits",
    unlimitedProjectsAndAiAnalyses: "Unlimited projects and AI analyses",
    unlimitedTeamMembers: "Unlimited team members",
    whiteLabelingOptions: "White-labeling options",
    dedicatedSupport: "Dedicated support",
    upgradeToEnterprise: "Upgrade to Enterprise",
    unlimited: "Unlimited",
    unknown: "Unknown",
    free: "Free",
    premium: "Premium",
    enterprise: "Enterprise",
    usageAndLimits: "Usage & Limits",
    perMonth: "per month",
    mb: "MB",
    none: "None",
    creditCard: "Credit Card",
    paypal: "PayPal",
    notAvailable: "Not available",
  },
  
  //notifications
  notifications: {
    '1': {
      title: "PMO Maturity Assessment Due",
      description: "Complete your quarterly PMO maturity assessment by Friday.",
      time: "2 days ago",
    },
    '2': {
      title: "Strategic Elements Domain Updated",
      description: "New templates and resources have been added to the Strategic Elements domain.",
      time: "3 days ago",
    },
    '3': {
      title: "Team Meeting: PMO Enhancement",
      description: "Upcoming team meeting to discuss PMO Enhancement strategies.",
      time: "Tomorrow, 10:00 AM",
    },
    '4': {
      title: "New Message from Admin",
      description: "You have a new message regarding your Organization Development domain progress.",
      time: "1 week ago",
    },
    '5': {
      title: "Data Backup Complete",
      description: "Your PMO data has been successfully backed up to cloud storage.",
      time: "2 weeks ago",
    },
    title: "Notifications",
    description: "Stay updated with your PMO activities and important alerts",
    markAllAsRead: "Mark all as read",
    clearAll: "Clear all",
    markAllAsReadDescription: "Mark all notifications as read",
    clearAllDescription: "Clear all notifications",
    markAllAsReadButton: "Mark all as read",
    clearAllButton: "Clear all",
    unread: "Unread",
    all: "All",
    recentNotifications: "Recent Notifications",
    markAsUnread: "Mark as unread",
    markAsRead: "Mark as read",
    viewDetails: "View details",
    loadMore: "Load more notifications",
    customizeNotifications: "Customize how and when you receive notifications about your PMO activities",
    notificationPreferences: "Notification Preferences",
    managePreferences: "Manage Preferences",
    

  },
  // Domain names
  domains: {
    "1": {
      name: "Organizational Development and Alignment",
      description: "Aligning the PMO with organizational strategy and culture to ensure effective project management practices.",
      tasks: {
        "1-input-1": {
          stage: "input",
          title: "Assess Current Competencies",
          description: "Gather data on existing competencies through surveys, interviews, and documentation review.",
          bestPractices: [
            "Use standardized assessment tools to evaluate current competencies",
            "Collect input from multiple organizational levels",
            "Document both technical and soft skill competencies",
            "Identify competency gaps through structured assessment"
          ]
        },
        "1-input-2": {
          stage: "input",
          title: "Assess Organizational Culture",
          description: "Collect data on current organizational culture through surveys, focus groups, and stakeholder interviews.",
          bestPractices: [
            "Conduct culture assessment surveys",
            "Gather feedback from diverse organizational levels",
            "Document cultural enablers and barriers to project management",
            "Collect historical data on cultural change initiatives"
          ]
        },
        "1-input-3": {
          stage: "input",
          title: "Benchmark Against Industry Standards",
          description: "Collect industry benchmarking data and best practices for organizational alignment.",
          bestPractices: [
            "Select relevant industry benchmarks and standards",
            "Gather data from industry reports and publications",
            "Document peer organization practices",
            "Collect metrics for comparative analysis"
          ]
        },
        "1-processing-1": {
          stage: "processing",
          title: "Apply Strategic Analysis Techniques",
          description: "Use strategic analysis tools to develop an integrated strategy with risk management and implementation roadmap.",
          bestPractices: [
            "Apply SWOT analysis to identify strengths and weaknesses",
            "Use gap analysis to identify improvement areas",
            "Apply risk assessment methodologies",
            "Use roadmapping techniques for implementation planning"
          ]
        },
        "1-processing-2": {
          stage: "processing",
          title: "Apply Communication Planning Methodologies",
          description: "Use communication planning techniques to develop stakeholder-specific messaging and feedback mechanisms.",
          bestPractices: [
            "Apply stakeholder analysis techniques",
            "Use communication matrix development methods",
            "Apply message tailoring methodologies",
            "Use KPI development frameworks for communication effectiveness"
          ]
        },
        "1-processing-3": {
          stage: "processing",
          title: "Apply Charter Development Techniques",
          description: "Use charter development methodologies to define PMO scope, authority, and governance structure.",
          bestPractices: [
            "Apply scope definition techniques",
            "Use RACI matrix development methods",
            "Apply governance framework design methodologies",
            "Use authority mapping techniques"
          ],
          templates: ["PMO Charter Template", "RACI Matrix"]
        },
        "1-output-1": {
          stage: "output",
          title: "Deliver Integrated Strategy and Roadmap",
          description: "Produce and implement the integrated strategy with risk management plan and phased implementation roadmap.",
          bestPractices: [
            "Document comprehensive strategy with clear objectives",
            "Create detailed implementation roadmap with milestones",
            "Develop risk management plan with mitigation strategies",
            "Establish strategy review and update mechanisms"
          ]
        },
        "1-output-2": {
          stage: "output",
          title: "Establish PMO Vision, Values and Culture",
          description: "Implement vision statement, core values, and cultural change program with leadership engagement.",
          bestPractices: [
            "Create compelling vision statement aligned with organization",
            "Document core values with behavioral examples",
            "Implement leadership engagement activities",
            "Establish cultural reinforcement mechanisms"
          ],
          templates: ["PMO Vision Statement Template", "Cultural Change Roadmap"]
        },
        "1-output-3": {
          stage: "output",
          title: "Implement PMO Charter and Governance",
          description: "Establish and operationalize PMO charter with defined scope, authority, and governance structure.",
          bestPractices: [
            "Formalize PMO charter with executive approval",
            "Implement governance structure with clear roles",
            "Establish decision-making authorities and processes",
            "Create charter review and update mechanisms"
          ],
          templates: ["PMO Charter Document", "Governance Structure Diagram"]
        },
      },
    },
    "2": {
      name: "Strategic Framework & Governance",
      description: "Creating the optimal PMO structure, roles, and responsibilities to meet organizational needs.",
      tasks: {
        "2-input-1": {
          stage: "input",
          title: "Gather Current State Data",
          description: "Collect data on current project management operations, processes, and performance.",
          bestPractices: [
            "Conduct process documentation review",
            "Gather performance metrics and historical data",
            "Collect stakeholder feedback on current operations",
            "Document existing governance structures"
          ]
        },
        "2-input-2": {
          stage: "input",
          title: "Collect Strategic Alignment Information",
          description: "Gather organizational strategic objectives, priorities, and success criteria.",
          bestPractices: [
            "Review organizational strategic plans",
            "Collect executive leadership priorities",
            "Document business unit objectives",
            "Gather information on strategic initiatives"
          ]
        },
        "2-input-3": {
          stage: "input",
          title: "Identify Capability Requirements",
          description: "Collect data on required capabilities through stakeholder interviews and organizational needs assessment.",
          bestPractices: [
            "Conduct capability needs interviews",
            "Gather industry capability standards",
            "Document capability prioritization criteria",
            "Collect capability maturity benchmarks"
          ]
        },
        "2-processing-1": {
          stage: "processing",
          title: "Apply Mandate Development Methodology",
          description: "Use mandate development techniques to define PMO purpose, authority, and responsibilities.",
          bestPractices: [
            "Apply purpose statement development methods",
            "Use authority mapping techniques",
            "Apply responsibility definition methodologies",
            "Use stakeholder validation approaches"
          ],
          templates: ["PMO Mandate Template", "Executive Sponsorship Agreement"]
        },
        "2-processing-2": {
          stage: "processing",
          title: "Apply Charter Development Framework",
          description: "Use charter development framework to create comprehensive PMO charter with roles and governance structure.",
          bestPractices: [
            "Apply vision and mission statement techniques",
            "Use organizational structure design methods",
            "Apply role definition methodologies",
            "Use governance framework design techniques"
          ],
          templates: ["PMO Charter Template", "Governance Structure Diagram"]
        },
        "2-processing-3": {
          stage: "processing",
          title: "Apply Governance Design Methodology",
          description: "Use governance design techniques to develop decision-making processes and oversight mechanisms.",
          bestPractices: [
            "Apply decision rights mapping techniques",
            "Use escalation path design methods",
            "Apply governance body design methodologies",
            "Use governance communication planning techniques"
          ],
          templates: ["Governance Framework Template", "Decision Rights Matrix"]
        },
        "2-output-1": {
          stage: "output",
          title: "Establish PMO Mandate and Charter",
          description: "Formalize and implement PMO mandate and charter with defined purpose, authority, and responsibilities.",
          bestPractices: [
            "Obtain executive approval for mandate and charter",
            "Communicate mandate to all stakeholders",
            "Implement authority structures defined in charter",
            "Establish charter review and update process"
          ],
          templates: ["Approved PMO Mandate", "Finalized PMO Charter"]
        },
        "2-output-2": {
          stage: "output",
          title: "Implement Governance Framework",
          description: "Establish and operationalize governance framework with decision-making bodies, processes, and oversight mechanisms.",
          bestPractices: [
            "Form governance committees with clear charters",
            "Implement decision-making processes and authorities",
            "Establish governance meeting cadence and agendas",
            "Create governance documentation and reporting system"
          ],
          templates: ["Governance Committee Charter", "Decision Authority Matrix"]
        },
        "2-output-3": {
          stage: "output",
          title: "Develop Strategic Communication Plan",
          description: "Implement comprehensive communication strategy with stakeholder-specific messaging and feedback mechanisms.",
          bestPractices: [
            "Create stakeholder-specific communication materials",
            "Establish regular communication cadence",
            "Implement feedback collection mechanisms",
            "Develop communication effectiveness metrics"
          ],
          templates: ["Strategic Communication Plan", "Stakeholder Messaging Matrix"]
        },      
      }
    },
    "3": {
      name: "PMO Structure & Design",
      description: "Establishing operational processes, KPIs, and performance metrics for the PMO.",
      tasks: {
        "3-input-1": {
          stage: "input",
          title: "Gather Customer Data",
          description: "Collect data on potential PMO customers, their needs, and expectations through surveys and interviews.",
          bestPractices: [
            "Conduct customer needs assessment surveys",
            "Gather stakeholder interview data",
            "Document customer pain points and expectations",
            "Collect service prioritization information"
          ]
        },
        "3-input-2": {
          stage: "input",
          title: "Collect Service Requirement Data",
          description: "Gather detailed requirements for potential PMO services through workshops and requirements sessions.",
          bestPractices: [
            "Conduct service requirements workshops",
            "Document service level expectations",
            "Collect service prioritization criteria",
            "Gather benchmark data on similar services"
          ],
          templates: ["Service Requirements Template", "Customer Needs Assessment"]
        },
        "3-input-3": {
          stage: "input",
          title: "Assess Capability Gaps",
          description: "Collect data on current capabilities and gaps through assessment tools and stakeholder feedback.",
          bestPractices: [
            "Use capability maturity assessment tools",
            "Gather capability benchmark data",
            "Document capability prioritization criteria",
            "Collect resource availability information"
          ]
        },
        "3-processing-1": {
          stage: "processing",
          title: "Apply Persona Development Techniques",
          description: "Use persona development methodologies to create detailed customer personas with needs and expectations.",
          bestPractices: [
            "Apply customer segmentation techniques",
            "Use persona development frameworks",
            "Apply needs analysis methodologies",
            "Use journey mapping techniques"
          ]
        },
        "3-processing-2": {
          stage: "processing",
          title: "Apply Prioritization Frameworks",
          description: "Use prioritization techniques to develop framework for addressing customer needs systematically.",
          bestPractices: [
            "Apply value vs. effort prioritization matrix",
            "Use MoSCoW prioritization technique",
            "Apply weighted scoring methodologies",
            "Use impact mapping techniques"
          ]
        },
        "3-processing-3": {
          stage: "processing",
          title: "Apply Service Catalog Design Methodology",
          description: "Use service catalog design techniques to develop comprehensive service offerings with benefits and advantages.",
          bestPractices: [
            "Apply service definition frameworks",
            "Use service level definition techniques",
            "Apply value proposition development methodologies",
            "Use service categorization techniques"
          ],
          templates: ["Service Catalog Template", "Service Level Agreement Template"]
        },
        "3-output-1": {
          stage: "output",
          title: "Deliver Customer Personas and Journey Maps",
          description: "Create and distribute detailed customer personas and journey maps to guide service design and delivery.",
          bestPractices: [
            "Document comprehensive personas with needs and pain points",
            "Create visual journey maps for key customer interactions",
            "Distribute personas to all service delivery teams",
            "Establish persona update and refinement process"
          ],
          templates: ["Customer Persona Template", "Journey Map Template"]
        },
        "3-output-2": {
          stage: "output",
          title: "Implement Service Catalog and SLAs",
          description: "Launch comprehensive service catalog with service level agreements, processes, and quality standards.",
          bestPractices: [
            "Create detailed service descriptions with value propositions",
            "Establish service level metrics and targets",
            "Implement service request and delivery processes",
            "Create service catalog review and update mechanism"
          ],
          templates: ["Service Catalog Document", "SLA Documentation"]
        },
        "3-output-3": {
          stage: "output",
          title: "Establish Service Prioritization Framework",
          description: "Implement systematic approach for prioritizing and addressing customer needs and service requests.",
          bestPractices: [
            "Create prioritization criteria and scoring system",
            "Implement request intake and evaluation process",
            "Establish resource allocation based on priorities",
            "Develop priority review and adjustment mechanisms"
          ],
          templates: ["Prioritization Matrix", "Service Request Form"]
        },      
      }
// Translation keys organized by component/page
// English translations
const en = {
  // Common components
  common: {
    pleaseWait: "Please wait while we prepare your content.",
    Complete : "Complete",
    search: "Search",
    save: "Save",
    saveAssessment: "Save Assessment",
    saved: "Saved!",
    showLess: "Show less",
    showMore: "Show more",
    cancel: "Cancel",
    edit: "Edit",
    delete: "Delete",
    close: "Close",
    loading: "Loading...",
    submit: "Submit",
    active: "Active",
    back: "Back",
    spent: "Spent",
    used: "Used",
    onTrack: "On Track",
    viewDetails: "View Details",
    tasks: "Tasks",
    domains: "Domains",
    budget: "Budget",
    daysLeft: "days left",
    next: "Next",
    progress: "Progress",
    notifications: "Notifications",
    help: "Help",
    settings: "Settings",
    profile: "Profile",
    signOut: "Sign Out",
    dashboard: "Dashboard",
    export: "Export",
    import: "Import",
    share: "Share",
    days: "days",
    darkMode: "Dark Mode",
    lightMode: "Light Mode",
    confirm: "Confirm",
    remainingTokens: "Remaining Tokens"
  },
  
  // Header component
  header: {
    search: "Search...",
    myTeams: "My Teams",
    invitations: "Invitations",
    setupProfile: "Setup Profile",
    subscription: "Subscription",
    settings: "Settings",
    adminPanel: "Admin Panel",
    signOut: "Sign out",
    profile: "Profile",
  },
  
  // Dashboard page
  dashboard: {
    title: "Dashboard",
    subtitle: "Build and track your PMO across all essential domains",
    budget: "Budget",
    editDetails: "Edit Details",
    exportReport: "Export Report",
    access: "Access",
    timelineProgress: "Timeline Progress",
    budgetUtilization: "Budget Utilization",
    projectStatus: "Project Status",
    maturityAssessment: "Maturity Assessment",
    keyObjectives: "Key Objectives",
    stakeholders: "Stakeholders",
    overallProgress: "Overall Progress",
    completedTasks: "Completed Tasks",
    domainProcessComparison:"Domain Progress Comparison",
    organization: "Organization",
    industry: "Industry",
    dashboardCustomization: "Dashboard Customization",
    displayLayout: "Display Layout",
    gridView: "Grid View",
    listView: "List View",
    widgetSelection: "Widget Selection",
    assessMaturityLevel: "Assess Your Maturity Level",
    maturityLevel: "Maturity Level",
    progressOverview: "Progress Overview",
    tasksStatus: "Tasks Status",
    domains: "Domains",
    chartsAnalytics: "Charts & Analytics",
    pmoMaturityLevel: "PMO Maturity Level",
    pmoDomains: "PMO Domains",
    aiAnalysis: "Accelerate with AI",
    aiDescription: "Let our advanced AI analyze your PMO data and generate comprehensive recommendations tailored to your organization's unique needs.",
    tryAiAnalysis: "Try AI Analysis",
    viewAll: "View all",
    of: "of",
    tasksCompleted: "tasks completed",
    notSet: "Not set",
    updateProfile: "Update profile",
    viewAllTasks: "View all tasks",
    nextSteps: "Next Steps",
    uploadDocuments: "Upload documents",
    analysisDocuments: "Upload supporting documents for AI analysis",
    analysisDocumentsDesc: "Enhance AI recommendations with your organization's context",
    completePmoMaturityAssessment: "Complete a PMO Maturity Assessment",
    getInsightsAboutPmoMaturityLevel: "Get insights about your PMO's current maturity level",
    reviewPractices: "Review best practices",
    explorePractices: "Explore the best practices library for guidance",
    viewResources: "View resources",
    goToAssessment: "Go to assessment",
    objective1: "Establish PMO governance framework",
    objective2: "Develop standard methodologies",
    objective3: "Implement performance metrics",
    sampleProject: "Sample PMO Implementation",
    sampleDescription: "A sample project with pre-populated data for demonstration",
    createFirstProject: "Create Your First PMO Project",
    firstProjectDesc: "Get started by creating your first PMO implementation project. You can set up project details, track progress across domains, and generate AI-powered recommendations.",
    createSample: "Create Sample Project",
    aiFeature1: "Custom templates based on your current maturity level",
    aiFeature2: "Detailed implementation roadmaps for each domain",
    aiFeature3: "Best practices tailored to your industry and context",
    maturityRadarChart: "Maturity Radar Chart",
    higherValuesIndicateGreaterMaturity: "Higher values indicate greater maturity",
    pmoMaturityAssessment: "PMO Maturity Assessment",
    assessPmoMaturity: "Assess your PMO's maturity level across all domains to identify strengths and improvement opportunities",
    selfAssessment: "Self-Assessment",
    aiGeneratedAssessment: "AI-Generated Assessment",
    notSpecified: "Not specified",
    currentMaturityProfile: "Current Maturity Profile",
    organizationDetails: "Organization Details",
    assessmentType: "Assessment Type",
    currentMaturityProfileDescription: "Your organization's PMO is currently at the",
    currentMaturityProfileDescription2: "level. This assessment will help you identify areas for improvement and create a roadmap for advancing your PMO capabilities.",
    assessmentDate: "Assessment Date",
    selfAssessmentQuestionnaire: "Self-Assessment Questionnaire",
    selfAssessmentDescription: "Rate your PMO's maturity level for each domain. Consider your processes, documentation, measurement capabilities, and continuous improvement efforts when making your assessment.",
    documentation: "Documentation",
    metrics: "Metrics",
    minimalToNone: "Minimal to none",
    basicDocumentation: "Basic documentation",
    comprehensiveDocumentation: "Comprehensive",
    regularlyUpdated: "Regularly updated",
    leadingPractice: "Leading practice",
    adHocOrNone: "Ad-hoc or none",
    basicTracking: "Basic tracking",
    notes: "Notes (Optional)",
    notesPlaceholder: "Add any notes or context about your assessment...",
    createNew: "Create New Project",
    generateAIAssessment: "Generate an AI Assessment",
    aiAssessmentDescription: "Our AI will analyze your domain inputs, project data, and uploaded documents to provide an objective assessment of your PMO's maturity across all domains.",
    aiAssessmentSummary: "AI Assessment Summary",
    aiAssessmentSummaryDescription: "Based on our analysis, your PMO is currently at the",
    keyStrengths: "Key Strengths",
    areasForImprovement: "Areas for Improvement",
    domainSpecificAssessment: "Domain-Specific Assessment",
    maturityProgression: "Maturity Progression",
    recommendations: "Recommendations",
    generatingReport: "Generating Report...",
    exportAssessmentReport: "Export Assessment Report",
    detailedMaturityGuide: "Detailed Maturity Guide",
    maturityModelReference: "Maturity Model Reference",
    generateAssessment: "Generate Assessment",
    generatingAssessment: "Generating Assessment...",
    generatingAssessmentDescription: "Our AI is analyzing your PMO data across all domains. This may take a few moments.",
    
  },
  
  // Domain detail page
  domain: {
    BestPractices: "Best Practices",
    backToDashboard: "Back to Dashboard",
    prevDomain: "Previous Domain",
    nextDomain: "Next Domain",
    viewDomain: "View Domain",
    progress: "Progress",
    tasks: "Tasks & Progress",
    input: "Domain Input & Analysis",
    analyzing: "Analyzing Domain Input",
    processingData: "Our AI is processing your input data...",
    inputStage: "Input",
    inputDesc: "Collect data, assess current state, and gather requirements for this domain.",
    processingStage: "Processing",
    processingDesc: "Analyze data, develop frameworks, and design solutions for this domain.",
    outputStage: "Output",
    outputDesc: "Create deliverables, implement solutions, and establish frameworks for this domain.",
    loading: "Loading domain data...",
    notFound: "Domain not found",
    provideInputFirst: "Please provide domain input data before analyzing",
    aiGeneratedAnalysis: "AI-Generated Analysis for",
    generated: "Generated",
    analysis: "Analysis",
    domainProgress: "Domain Progress (%)",
    templates: "Templates",
    downloadMarkdown: "Download Markdown",
    downloadPdf: "Download PDF",
    generatingPdf: "Generating PDF...",
    generating: "Generating...",
    allTemplates: "All Available Templates",
    markdownFormat: "Markdown",
    words: "words",
    usingTemplates: "Using These Templates",
    templateDescription: "These templates are available in Markdown and PDF formats. Markdown can be imported into document editors, project management tools, or converted to other formats. PDF files are ready for printing or sharing with stakeholders.",
    noTemplates: "No templates available for this domain",
    aiConfigTitle: "AI Analysis Configuration",
    selectDomainPrompt: "Select a domain to analyze with our advanced AI. The analysis will generate comprehensive recommendations and templates based on your organization's specific context.",
    selectDomain: "Select Domain",
    analysisDepth: "Analysis Depth",
    basic: "Basic",
    quickOverview: "Quick overview",
    standard: "Standard",
    balancedAnalysis: "Balanced analysis",
    detailed: "Detailed",
    inDepthReview: "In-depth review",
    comprehensive: "Comprehensive",
    maximumDetail: "Maximum detail",
    geminiPowered: "Gemini AI Powered Analysis",
    advancedAiDesc: "Advanced AI will analyze your inputs and generate tailored recommendations",
    startAnalysis: "Start Analysis"
  },
  
  // Project management
  project: {
    projectName: "Project Name",
    projectNamePlaceholder: "Enterprise PMO Implementation",
    description: "Description",
    descriptionPlaceholder: "Brief description of your PMO implementation project",
    budget: "Budget",
    yourProjects: "Your Projects",
    createProject: "Create Project"
  },
  
  // Sidebar
  sidebar: {
    dashboard: "Dashboard",
    pmoDomains: "PMO Domains",
    tools: "Tools & Assessment",
    resources: "Resources",
    tasks: "Tasks",
    bestPractices: "Best Practices",
    maturityAssessment: "Maturity Assessment",
    assessment: "Assessment",
  },
  
  // Auth pages
  auth: {
    copyright: "© 2025 PMO Builder using AI by Dr. Ahmed Alsenosy"
  },
  
  // Maturity levels
  maturityLevels: {
    initial: {
      label: 'Initial',
      description: 'Processes are ad hoc and chaotic.'
    },
    defined: {
      label: 'Defined',
      description: 'Processes are documented and standardized.'
    },
    managed: {
      label: 'Managed',
      description: 'Processes are measured and controlled.'
    },
    optimized: {
      label: 'Optimized',
      description: 'Focus on continuous improvement.'
    },
    innovative: {
      label: 'Innovative',
      description: 'Driving industry innovation and adaptation.'
    }
  },

  //profile page
  profile: {
    title: "Organization Profile",
    description: "Set up your organization details to personalize your PMO journey",
    organizationName: "Organization Name",
    organizationNamePlaceholder: "Enter your organization name",
    industry: "Industry",
    industryPlaceholder: "Enter your industry",
    pmoMaturityLevel: "PMO Maturity Level",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "Select the maturity level that best describes your current PMO",
    saveProfile: "Save Profile",
    cancel: "Cancel",
    initial: "Initial - Ad hoc processes",
    defined: "Defined - Basic processes established",
    managed: "Managed - Standardized processes",
    optimized: "Optimized - Continuously improving",
    notEstablished: "Not Established - No formal PMO",
  },
  
  //settings page
  settings: {
    title: "Settings",
    description: "Manage your account settings and preferences",
    personal: "Personal",
    subscription: "Subscription",
    notifications: "Notifications",
    security: "Security",
    data: "Data",
    saveProfile: "Save Profile",
    cancel: "Cancel",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "Select the maturity level that best describes your current PMO",
    organizationName: "Organization Name",
    organizationNamePlaceholder: "Enter your organization name",
    industry: "Industry",
    industryPlaceholder: "Enter your industry",
    pmoMaturityLevel: "PMO Maturity Level",
    notEstablished: "Not Established - No formal PMO",
    initial: "Initial - Ad hoc processes",
    defined: "Defined - Basic processes established",
    managed: "Managed - Standardized processes",
    optimized: "Optimized - Continuously improving",
  },

  // Resources page
  resources: {
    title: "Resources",
    noDocuments: "No documents available",
    errorLoading: "Error loading documents",
    downloadError: "Error downloading document",
    uploadNew: "Upload New Document",
    filter: "Filter Documents",
    sortBy: "Sort By",
    search: "Search Documents",
    lastModified: "Last Modified",
    fileName: "File Name",
    fileSize: "File Size",
    taskName: "Task Name",
    projectId: "Project ID"
  },
 // Help page
  help: {
    title: "Help & Support",
    description: "Learn how to use the PMO Domains Application Tool effectively",
    gettingStarted: "Getting Started",
    whatIsPmoDomainsTool: "What is the PMO Domains Tool?",
    whatIsPmoDomainsToolDescription: `The PMO Domains Application Tool helps PMO professionals apply and monitor the five key PMO domains using a structured "Inputs – Processing – Outputs" framework. The tool guides you through each domain's tasks, ensuring best practices and benchmarking against industry standards.`, 
    howToUseThisTool: "How to Use This Tool",
    howToUseThisToolDescription: "The PMO Domains Application Tool is a web-based application that helps organizations implement and improve their PMO capabilities across all domains.",
    canIExportMyData: "Can I export my data?",
    canIExportMyDataDescription: "Yes, you can export your data from the Settings page. This allows you to back up your progress or transfer it to another system.",
    canICustomizeTheToolForMyOrganization: "Can I customize the tool for my organization?",
    canICustomizeTheToolForMyOrganizationDescription: "The tool is designed to be applicable across different organizations and industries. You can add custom notes to each task to tailor it to your specific organizational context.",
    whatIfINotReadyToCompleteAllDomains: "What if I'm not ready to complete all domains?",
    whatIfINotReadyToCompleteAllDomainsDescription: "You can work on domains in any order that makes sense for your organization. The tool will track your progress across all domains, allowing you to focus on your priorities.",
    contactSupport: "Contact Support",
    contactSupportDescription: "If you need additional help or have questions about the PMO Domains Application Tool, please contact our support team.",
    supportContact: "Support Contact",
    supportContactEmail: "Email: support@pmobuilder.ai",
    supportContactPhone: "Phone: (555) 123-4567",
    supportContactHours: "Hours: Monday-Friday, 9am-5pm EST",
    startBySettingUpYourOrganizationProfile: "Start by setting up your organization profile in the Profile section",
    navigateToEachDomainUsingTheSidebarMenu: "Navigate to each domain using the sidebar menu",
    completeTasksInTheRecommendedOrder: "Complete tasks in the recommended order: Input → Processing → Output",
    markTasksAsCompleteAsYouProgress: "Mark tasks as complete as you progress",
    useTheDashboardToTrackYourOverallProgress: "Use the dashboard to track your overall progress",
    referToTheBestPracticesLibraryForGuidance: "Refer to the Best Practices Library for guidance",
    organizationalDevelopmentAndAlignment: "1. Organizational Development and Alignment",
    organizationalDevelopmentAndAlignmentDescription: "This domain focuses on aligning the PMO with organizational strategy and culture to ensure effective project management practices. It includes organizational assessment, stakeholder analysis, and developing alignment strategies.",
    strategicElementsOfThePmo: "2. Strategic Elements of the PMO",
    strategicElementsOfThePmoDescription: "This domain involves developing and implementing strategic frameworks, roadmaps, and governance structures. It includes strategic objectives review, portfolio analysis, and governance structure design.",
    pMODesignAndStructuring: "3. PMO Design and Structuring",
    pMODesignAndStructuringDescription: "This domain focuses on creating the optimal PMO structure, roles, and responsibilities to meet organizational needs. It includes requirements gathering, resource assessment, and service catalog development.",
    pMOOperationAndPerformance: "4. PMO Operation and Performance",
    pMOOperationAndPerformanceDescription: "This domain establishes operational processes, KPIs, and performance metrics for the PMO. It includes process assessment, performance metrics identification, and performance measurement systems.",
    pMOEnhancementAndEffectiveness: "5. PMO Enhancement and Effectiveness",
    pMOEnhancementAndEffectivenessDescription: "This domain focuses on continuously improving PMO services, capabilities, and value delivery. It includes maturity assessment, value delivery analysis, and continuous improvement planning.",
    frequentlyAskedQuestions: "Frequently Asked Questions",
    frequentlyAskedQuestionsDescription: "The PMO Domains Application Tool is a web-based application that helps organizations implement and improve their PMO capabilities across all domains.",
    howToAccessTemplates: "How do I access templates?",
    howToAccessTemplatesDescription: "Templates are available within specific tasks that have template resources. You can also find a collection of templates in the Best Practices Library",
    understandingTheFiveDomains: "Understanding the Five Domains",
  },
    
  subscription: {
    title: "Subscription Management",
    currentPlan: "Current Plan",
    trial: "Trial",
    cancelsAtPeriodEnd: "Cancels at period end",
    upgradePlan: "Upgrade Plan",
    manageSubscription: "Manage Subscription",
    processing: "Processing...",
    billingPeriod: "Billing Period",
    nextBillingDate: "Next Billing Date",
    paymentMethod: "Payment Method",
    projects: "Projects",
    aiAnalysis: "AI Analysis",
    storage: "Storage",
    freePlanLimitations: "Free plan limitations",
    freePlanLimitationsDescription: "You're currently on the Free plan, which has limitations on projects, AI analyses, and storage. Upgrade to Premium or Enterprise for increased limits and additional features.",
    upgradeNow: "Upgrade Now",
    upgradeToGetMore: "Upgrade to Get More",
    premiumPlanBenefits: "Premium Plan Benefits",
    upTo20Projects: "Up to 20 projects (vs. 3 on Free)",
    upTo100AiAnalyses: "100 AI analyses per month (vs. 3 on Free)",
    teamCollaboration: "Team collaboration with up to 5 users",
    prioritySupport: "Priority support",
    enterprisePlanBenefits: "Enterprise Plan Benefits",
    unlimitedProjectsAndAiAnalyses: "Unlimited projects and AI analyses",
    unlimitedTeamMembers: "Unlimited team members",
    whiteLabelingOptions: "White-labeling options",
    dedicatedSupport: "Dedicated support",
    upgradeToEnterprise: "Upgrade to Enterprise",
    unlimited: "Unlimited",
    unknown: "Unknown",
    free: "Free",
    premium: "Premium",
    enterprise: "Enterprise",
    usageAndLimits: "Usage & Limits",
    perMonth: "per month",
    mb: "MB",
    none: "None",
    creditCard: "Credit Card",
    paypal: "PayPal",
    notAvailable: "Not available",
  },
  
  //notifications
  notifications: {
    '1': {
      title: "PMO Maturity Assessment Due",
      description: "Complete your quarterly PMO maturity assessment by Friday.",
      time: "2 days ago",
    },
    '2': {
      title: "Strategic Elements Domain Updated",
      description: "New templates and resources have been added to the Strategic Elements domain.",
      time: "3 days ago",
    },
    '3': {
      title: "Team Meeting: PMO Enhancement",
      description: "Upcoming team meeting to discuss PMO Enhancement strategies.",
      time: "Tomorrow, 10:00 AM",
    },
    '4': {
      title: "New Message from Admin",
      description: "You have a new message regarding your Organization Development domain progress.",
      time: "1 week ago",
    },
    '5': {
      title: "Data Backup Complete",
      description: "Your PMO data has been successfully backed up to cloud storage.",
      time: "2 weeks ago",
    },
    title: "Notifications",
    description: "Stay updated with your PMO activities and important alerts",
    markAllAsRead: "Mark all as read",
    clearAll: "Clear all",
    markAllAsReadDescription: "Mark all notifications as read",
    clearAllDescription: "Clear all notifications",
    markAllAsReadButton: "Mark all as read",
    clearAllButton: "Clear all",
    unread: "Unread",
    all: "All",
    recentNotifications: "Recent Notifications",
    markAsUnread: "Mark as unread",
    markAsRead: "Mark as read",
    viewDetails: "View details",
    loadMore: "Load more notifications",
    customizeNotifications: "Customize how and when you receive notifications about your PMO activities",
    notificationPreferences: "Notification Preferences",
    managePreferences: "Manage Preferences",
    

  },
  // Domain names
  domains: {
    "1": {
      name: "Organizational Development and Alignment",
      description: "Aligning the PMO with organizational strategy and culture to ensure effective project management practices.",
      tasks: {
        "1-input-1": {
          stage: "input",
          title: "Assess Current Competencies",
          description: "Gather data on existing competencies through surveys, interviews, and documentation review.",
          bestPractices: [
            "Use standardized assessment tools to evaluate current competencies",
            "Collect input from multiple organizational levels",
            "Document both technical and soft skill competencies",
            "Identify competency gaps through structured assessment"
          ]
        },
        "1-input-2": {
          stage: "input",
          title: "Assess Organizational Culture",
          description: "Collect data on current organizational culture through surveys, focus groups, and stakeholder interviews.",
          bestPractices: [
            "Conduct culture assessment surveys",
            "Gather feedback from diverse organizational levels",
            "Document cultural enablers and barriers to project management",
            "Collect historical data on cultural change initiatives"
          ]
        },
        "1-input-3": {
          stage: "input",
          title: "Benchmark Against Industry Standards",
          description: "Collect industry benchmarking data and best practices for organizational alignment.",
          bestPractices: [
            "Select relevant industry benchmarks and standards",
            "Gather data from industry reports and publications",
            "Document peer organization practices",
            "Collect metrics for comparative analysis"
          ]
        },
        "1-processing-1": {
          stage: "processing",
          title: "Apply Strategic Analysis Techniques",
          description: "Use strategic analysis tools to develop an integrated strategy with risk management and implementation roadmap.",
          bestPractices: [
            "Apply SWOT analysis to identify strengths and weaknesses",
            "Use gap analysis to identify improvement areas",
            "Apply risk assessment methodologies",
            "Use roadmapping techniques for implementation planning"
          ]
        },
        "1-processing-2": {
          stage: "processing",
          title: "Apply Communication Planning Methodologies",
          description: "Use communication planning techniques to develop stakeholder-specific messaging and feedback mechanisms.",
          bestPractices: [
            "Apply stakeholder analysis techniques",
            "Use communication matrix development methods",
            "Apply message tailoring methodologies",
            "Use KPI development frameworks for communication effectiveness"
          ]
        },
        "1-processing-3": {
          stage: "processing",
          title: "Apply Charter Development Techniques",
          description: "Use charter development methodologies to define PMO scope, authority, and governance structure.",
          bestPractices: [
            "Apply scope definition techniques",
            "Use RACI matrix development methods",
            "Apply governance framework design methodologies",
            "Use authority mapping techniques"
          ],
          templates: ["PMO Charter Template", "RACI Matrix"]
        },
        "1-output-1": {
          stage: "output",
          title: "Deliver Integrated Strategy and Roadmap",
          description: "Produce and implement the integrated strategy with risk management plan and phased implementation roadmap.",
          bestPractices: [
            "Document comprehensive strategy with clear objectives",
            "Create detailed implementation roadmap with milestones",
            "Develop risk management plan with mitigation strategies",
            "Establish strategy review and update mechanisms"
          ]
        },
        "1-output-2": {
          stage: "output",
          title: "Establish PMO Vision, Values and Culture",
          description: "Implement vision statement, core values, and cultural change program with leadership engagement.",
          bestPractices: [
            "Create compelling vision statement aligned with organization",
            "Document core values with behavioral examples",
            "Implement leadership engagement activities",
            "Establish cultural reinforcement mechanisms"
          ],
          templates: ["PMO Vision Statement Template", "Cultural Change Roadmap"]
        },
        "1-output-3": {
          stage: "output",
          title: "Implement PMO Charter and Governance",
          description: "Establish and operationalize PMO charter with defined scope, authority, and governance structure.",
          bestPractices: [
            "Formalize PMO charter with executive approval",
            "Implement governance structure with clear roles",
            "Establish decision-making authorities and processes",
            "Create charter review and update mechanisms"
          ],
          templates: ["PMO Charter Document", "Governance Structure Diagram"]
        },
      },
    },
    "2": {
      name: "Strategic Framework & Governance",
      description: "Creating the optimal PMO structure, roles, and responsibilities to meet organizational needs.",
      tasks: {
        "2-input-1": {
          stage: "input",
          title: "Gather Current State Data",
          description: "Collect data on current project management operations, processes, and performance.",
          bestPractices: [
            "Conduct process documentation review",
            "Gather performance metrics and historical data",
            "Collect stakeholder feedback on current operations",
            "Document existing governance structures"
          ]
        },
        "2-input-2": {
          stage: "input",
          title: "Collect Strategic Alignment Information",
          description: "Gather organizational strategic objectives, priorities, and success criteria.",
          bestPractices: [
            "Review organizational strategic plans",
            "Collect executive leadership priorities",
            "Document business unit objectives",
            "Gather information on strategic initiatives"
          ]
        },
        "2-input-3": {
          stage: "input",
          title: "Identify Capability Requirements",
          description: "Collect data on required capabilities through stakeholder interviews and organizational needs assessment.",
          bestPractices: [
            "Conduct capability needs interviews",
            "Gather industry capability standards",
            "Document capability prioritization criteria",
            "Collect capability maturity benchmarks"
          ]
        },
        "2-processing-1": {
          stage: "processing",
          title: "Apply Mandate Development Methodology",
          description: "Use mandate development techniques to define PMO purpose, authority, and responsibilities.",
          bestPractices: [
            "Apply purpose statement development methods",
            "Use authority mapping techniques",
            "Apply responsibility definition methodologies",
            "Use stakeholder validation approaches"
          ],
          templates: ["PMO Mandate Template", "Executive Sponsorship Agreement"]
        },
        "2-processing-2": {
          stage: "processing",
          title: "Apply Charter Development Framework",
          description: "Use charter development framework to create comprehensive PMO charter with roles and governance structure.",
          bestPractices: [
            "Apply vision and mission statement techniques",
            "Use organizational structure design methods",
            "Apply role definition methodologies",
            "Use governance framework design techniques"
          ],
          templates: ["PMO Charter Template", "Governance Structure Diagram"]
        },
        "2-processing-3": {
          stage: "processing",
          title: "Apply Governance Design Methodology",
          description: "Use governance design techniques to develop decision-making processes and oversight mechanisms.",
          bestPractices: [
            "Apply decision rights mapping techniques",
            "Use escalation path design methods",
            "Apply governance body design methodologies",
            "Use governance communication planning techniques"
          ],
          templates: ["Governance Framework Template", "Decision Rights Matrix"]
        },
        "2-output-1": {
          stage: "output",
          title: "Establish PMO Mandate and Charter",
          description: "Formalize and implement PMO mandate and charter with defined purpose, authority, and responsibilities.",
          bestPractices: [
            "Obtain executive approval for mandate and charter",
            "Communicate mandate to all stakeholders",
            "Implement authority structures defined in charter",
            "Establish charter review and update process"
          ],
          templates: ["Approved PMO Mandate", "Finalized PMO Charter"]
        },
        "2-output-2": {
          stage: "output",
          title: "Implement Governance Framework",
          description: "Establish and operationalize governance framework with decision-making bodies, processes, and oversight mechanisms.",
          bestPractices: [
            "Form governance committees with clear charters",
            "Implement decision-making processes and authorities",
            "Establish governance meeting cadence and agendas",
            "Create governance documentation and reporting system"
          ],
          templates: ["Governance Committee Charter", "Decision Authority Matrix"]
        },
        "2-output-3": {
          stage: "output",
          title: "Develop Strategic Communication Plan",
          description: "Implement comprehensive communication strategy with stakeholder-specific messaging and feedback mechanisms.",
          bestPractices: [
            "Create stakeholder-specific communication materials",
            "Establish regular communication cadence",
            "Implement feedback collection mechanisms",
            "Develop communication effectiveness metrics"
          ],
          templates: ["Strategic Communication Plan", "Stakeholder Messaging Matrix"]
        },      
      }
    },
    "3": {
      name: "PMO Structure & Design",
      description: "Establishing operational processes, KPIs, and performance metrics for the PMO.",
      tasks: {
        "3-input-1": {
          stage: "input",
          title: "Gather Customer Data",
          description: "Collect data on potential PMO customers, their needs, and expectations through surveys and interviews.",
          bestPractices: [
            "Conduct customer needs assessment surveys",
            "Gather stakeholder interview data",
            "Document customer pain points and expectations",
            "Collect service prioritization information"
          ]
        },
        "3-input-2": {
          stage: "input",
          title: "Collect Service Requirement Data",
          description: "Gather detailed requirements for potential PMO services through workshops and requirements sessions.",
          bestPractices: [
            "Conduct service requirements workshops",
            "Document service level expectations",
            "Collect service prioritization criteria",
            "Gather benchmark data on similar services"
          ],
          templates: ["Service Requirements Template", "Customer Needs Assessment"]
        },
        "3-input-3": {
          stage: "input",
          title: "Assess Capability Gaps",
          description: "Collect data on current capabilities and gaps through assessment tools and stakeholder feedback.",
          bestPractices: [
            "Use capability maturity assessment tools",
            "Gather capability benchmark data",
            "Document capability prioritization criteria",
            "Collect resource availability information"
          ]
        },
        "3-processing-1": {
          stage: "processing",
          title: "Apply Persona Development Techniques",
          description: "Use persona development methodologies to create detailed customer personas with needs and expectations.",
          bestPractices: [
            "Apply customer segmentation techniques",
            "Use persona development frameworks",
            "Apply needs analysis methodologies",
            "Use journey mapping techniques"
          ]
        },
        "3-processing-2": {
          stage: "processing",
          title: "Apply Prioritization Frameworks",
          description: "Use prioritization techniques to develop framework for addressing customer needs systematically.",
          bestPractices: [
            "Apply value vs. effort prioritization matrix",
            "Use MoSCoW prioritization technique",
            "Apply weighted scoring methodologies",
            "Use impact mapping techniques"
          ]
        },
        "3-processing-3": {
          stage: "processing",
          title: "Apply Service Catalog Design Methodology",
          description: "Use service catalog design techniques to develop comprehensive service offerings with benefits and advantages.",
          bestPractices: [
            "Apply service definition frameworks",
            "Use service level definition techniques",
            "Apply value proposition development methodologies",
            "Use service categorization techniques"
          ],
          templates: ["Service Catalog Template", "Service Level Agreement Template"]
        },
        "3-output-1": {
          stage: "output",
          title: "Deliver Customer Personas and Journey Maps",
          description: "Create and distribute detailed customer personas and journey maps to guide service design and delivery.",
          bestPractices: [
            "Document comprehensive personas with needs and pain points",
            "Create visual journey maps for key customer interactions",
            "Distribute personas to all service delivery teams",
            "Establish persona update and refinement process"
          ],
          templates: ["Customer Persona Template", "Journey Map Template"]
        },
        "3-output-2": {
          stage: "output",
          title: "Implement Service Catalog and SLAs",
          description: "Launch comprehensive service catalog with service level agreements, processes, and quality standards.",
          bestPractices: [
            "Create detailed service descriptions with value propositions",
            "Establish service level metrics and targets",
            "Implement service request and delivery processes",
            "Create service catalog review and update mechanism"
          ],
          templates: ["Service Catalog Document", "SLA Documentation"]
        },
        "3-output-3": {
          stage: "output",
          title: "Establish Service Prioritization Framework",
          description: "Implement systematic approach for prioritizing and addressing customer needs and service requests.",
          bestPractices: [
            "Create prioritization criteria and scoring system",
            "Implement request intake and evaluation process",
            "Establish resource allocation based on priorities",
            "Develop priority review and adjustment mechanisms"
          ],
          templates: ["Prioritization Matrix", "Service Request Form"]
        },      
      }
    },
// Translation keys organized by component/page
// English translations
const en = {
  // Common components
  common: {
    pleaseWait: "Please wait while we prepare your content.",
    Complete : "Complete",
    search: "Search",
    save: "Save",
    saveAssessment: "Save Assessment",
    saved: "Saved!",
    showLess: "Show less",
    showMore: "Show more",
    cancel: "Cancel",
    edit: "Edit",
    delete: "Delete",
    close: "Close",
    loading: "Loading...",
    submit: "Submit",
    active: "Active",
    back: "Back",
    spent: "Spent",
    used: "Used",
    onTrack: "On Track",
    viewDetails: "View Details",
    tasks: "Tasks",
    domains: "Domains",
    budget: "Budget",
    daysLeft: "days left",
    next: "Next",
    progress: "Progress",
    notifications: "Notifications",
    help: "Help",
    settings: "Settings",
    profile: "Profile",
    signOut: "Sign Out",
    dashboard: "Dashboard",
    export: "Export",
    import: "Import",
    share: "Share",
    days: "days",
    darkMode: "Dark Mode",
    lightMode: "Light Mode",
    confirm: "Confirm",
    remainingTokens: "Remaining Tokens"
  },
  
  // Header component
  header: {
    search: "Search...",
    myTeams: "My Teams",
    invitations: "Invitations",
    setupProfile: "Setup Profile",
    subscription: "Subscription",
    settings: "Settings",
    adminPanel: "Admin Panel",
    signOut: "Sign out",
    profile: "Profile",
  },
  
  // Dashboard page
  dashboard: {
    title: "Dashboard",
    subtitle: "Build and track your PMO across all essential domains",
    budget: "Budget",
    editDetails: "Edit Details",
    exportReport: "Export Report",
    access: "Access",
    timelineProgress: "Timeline Progress",
    budgetUtilization: "Budget Utilization",
    projectStatus: "Project Status",
    maturityAssessment: "Maturity Assessment",
    keyObjectives: "Key Objectives",
    stakeholders: "Stakeholders",
    overallProgress: "Overall Progress",
    completedTasks: "Completed Tasks",
    domainProcessComparison:"Domain Progress Comparison",
    organization: "Organization",
    industry: "Industry",
    dashboardCustomization: "Dashboard Customization",
    displayLayout: "Display Layout",
    gridView: "Grid View",
    listView: "List View",
    widgetSelection: "Widget Selection",
    assessMaturityLevel: "Assess Your Maturity Level",
    maturityLevel: "Maturity Level",
    progressOverview: "Progress Overview",
    tasksStatus: "Tasks Status",
    domains: "Domains",
    chartsAnalytics: "Charts & Analytics",
    pmoMaturityLevel: "PMO Maturity Level",
    pmoDomains: "PMO Domains",
    aiAnalysis: "Accelerate with AI",
    aiDescription: "Let our advanced AI analyze your PMO data and generate comprehensive recommendations tailored to your organization's unique needs.",
    tryAiAnalysis: "Try AI Analysis",
    viewAll: "View all",
    of: "of",
    tasksCompleted: "tasks completed",
    notSet: "Not set",
    updateProfile: "Update profile",
    viewAllTasks: "View all tasks",
    nextSteps: "Next Steps",
    uploadDocuments: "Upload documents",
    analysisDocuments: "Upload supporting documents for AI analysis",
    analysisDocumentsDesc: "Enhance AI recommendations with your organization's context",
    completePmoMaturityAssessment: "Complete a PMO Maturity Assessment",
    getInsightsAboutPmoMaturityLevel: "Get insights about your PMO's current maturity level",
    reviewPractices: "Review best practices",
    explorePractices: "Explore the best practices library for guidance",
    viewResources: "View resources",
    goToAssessment: "Go to assessment",
    objective1: "Establish PMO governance framework",
    objective2: "Develop standard methodologies",
    objective3: "Implement performance metrics",
    sampleProject: "Sample PMO Implementation",
    sampleDescription: "A sample project with pre-populated data for demonstration",
    createFirstProject: "Create Your First PMO Project",
    firstProjectDesc: "Get started by creating your first PMO implementation project. You can set up project details, track progress across domains, and generate AI-powered recommendations.",
    createSample: "Create Sample Project",
    aiFeature1: "Custom templates based on your current maturity level",
    aiFeature2: "Detailed implementation roadmaps for each domain",
    aiFeature3: "Best practices tailored to your industry and context",
    maturityRadarChart: "Maturity Radar Chart",
    higherValuesIndicateGreaterMaturity: "Higher values indicate greater maturity",
    pmoMaturityAssessment: "PMO Maturity Assessment",
    assessPmoMaturity: "Assess your PMO's maturity level across all domains to identify strengths and improvement opportunities",
    selfAssessment: "Self-Assessment",
    aiGeneratedAssessment: "AI-Generated Assessment",
    notSpecified: "Not specified",
    currentMaturityProfile: "Current Maturity Profile",
    organizationDetails: "Organization Details",
    assessmentType: "Assessment Type",
    currentMaturityProfileDescription: "Your organization's PMO is currently at the",
    currentMaturityProfileDescription2: "level. This assessment will help you identify areas for improvement and create a roadmap for advancing your PMO capabilities.",
    assessmentDate: "Assessment Date",
    selfAssessmentQuestionnaire: "Self-Assessment Questionnaire",
    selfAssessmentDescription: "Rate your PMO's maturity level for each domain. Consider your processes, documentation, measurement capabilities, and continuous improvement efforts when making your assessment.",
    documentation: "Documentation",
    metrics: "Metrics",
    minimalToNone: "Minimal to none",
    basicDocumentation: "Basic documentation",
    comprehensiveDocumentation: "Comprehensive",
    regularlyUpdated: "Regularly updated",
    leadingPractice: "Leading practice",
    adHocOrNone: "Ad-hoc or none",
    basicTracking: "Basic tracking",
    notes: "Notes (Optional)",
    notesPlaceholder: "Add any notes or context about your assessment...",
    createNew: "Create New Project",
    generateAIAssessment: "Generate an AI Assessment",
    aiAssessmentDescription: "Our AI will analyze your domain inputs, project data, and uploaded documents to provide an objective assessment of your PMO's maturity across all domains.",
    aiAssessmentSummary: "AI Assessment Summary",
    aiAssessmentSummaryDescription: "Based on our analysis, your PMO is currently at the",
    keyStrengths: "Key Strengths",
    areasForImprovement: "Areas for Improvement",
    domainSpecificAssessment: "Domain-Specific Assessment",
    maturityProgression: "Maturity Progression",
    recommendations: "Recommendations",
    generatingReport: "Generating Report...",
    exportAssessmentReport: "Export Assessment Report",
    detailedMaturityGuide: "Detailed Maturity Guide",
    maturityModelReference: "Maturity Model Reference",
    generateAssessment: "Generate Assessment",
    generatingAssessment: "Generating Assessment...",
    generatingAssessmentDescription: "Our AI is analyzing your PMO data across all domains. This may take a few moments.",
    
  },
  
  // Domain detail page
  domain: {
    BestPractices: "Best Practices",
    backToDashboard: "Back to Dashboard",
    prevDomain: "Previous Domain",
    nextDomain: "Next Domain",
    viewDomain: "View Domain",
    progress: "Progress",
    tasks: "Tasks & Progress",
    input: "Domain Input & Analysis",
    analyzing: "Analyzing Domain Input",
    processingData: "Our AI is processing your input data...",
    inputStage: "Input",
    inputDesc: "Collect data, assess current state, and gather requirements for this domain.",
    processingStage: "Processing",
    processingDesc: "Analyze data, develop frameworks, and design solutions for this domain.",
    outputStage: "Output",
    outputDesc: "Create deliverables, implement solutions, and establish frameworks for this domain.",
    loading: "Loading domain data...",
    notFound: "Domain not found",
    provideInputFirst: "Please provide domain input data before analyzing",
    aiGeneratedAnalysis: "AI-Generated Analysis for",
    generated: "Generated",
    analysis: "Analysis",
    domainProgress: "Domain Progress (%)",
    templates: "Templates",
    downloadMarkdown: "Download Markdown",
    downloadPdf: "Download PDF",
    generatingPdf: "Generating PDF...",
    generating: "Generating...",
    allTemplates: "All Available Templates",
    markdownFormat: "Markdown",
    words: "words",
    usingTemplates: "Using These Templates",
    templateDescription: "These templates are available in Markdown and PDF formats. Markdown can be imported into document editors, project management tools, or converted to other formats. PDF files are ready for printing or sharing with stakeholders.",
    noTemplates: "No templates available for this domain",
    aiConfigTitle: "AI Analysis Configuration",
    selectDomainPrompt: "Select a domain to analyze with our advanced AI. The analysis will generate comprehensive recommendations and templates based on your organization's specific context.",
    selectDomain: "Select Domain",
    analysisDepth: "Analysis Depth",
    basic: "Basic",
    quickOverview: "Quick overview",
    standard: "Standard",
    balancedAnalysis: "Balanced analysis",
    detailed: "Detailed",
    inDepthReview: "In-depth review",
    comprehensive: "Comprehensive",
    maximumDetail: "Maximum detail",
    geminiPowered: "Gemini AI Powered Analysis",
    advancedAiDesc: "Advanced AI will analyze your inputs and generate tailored recommendations",
    startAnalysis: "Start Analysis"
  },
  
  // Project management
  project: {
    projectName: "Project Name",
    projectNamePlaceholder: "Enterprise PMO Implementation",
    description: "Description",
    descriptionPlaceholder: "Brief description of your PMO implementation project",
    budget: "Budget",
    yourProjects: "Your Projects",
    createProject: "Create Project"
  },
  
  // Sidebar
  sidebar: {
    dashboard: "Dashboard",
    pmoDomains: "PMO Domains",
    tools: "Tools & Assessment",
    resources: "Resources",
    tasks: "Tasks",
    bestPractices: "Best Practices",
    maturityAssessment: "Maturity Assessment",
    assessment: "Assessment",
  },
  
  // Auth pages
  auth: {
    copyright: "© 2025 PMO Builder using AI by Dr. Ahmed Alsenosy"
  },
  
  // Maturity levels
  maturityLevels: {
    initial: {
      label: 'Initial',
      description: 'Processes are ad hoc and chaotic.'
    },
    defined: {
      label: 'Defined',
      description: 'Processes are documented and standardized.'
    },
    managed: {
      label: 'Managed',
      description: 'Processes are measured and controlled.'
    },
    optimized: {
      label: 'Optimized',
      description: 'Focus on continuous improvement.'
    },
    innovative: {
      label: 'Innovative',
      description: 'Driving industry innovation and adaptation.'
    }
  },

  //profile page
  profile: {
    title: "Organization Profile",
    description: "Set up your organization details to personalize your PMO journey",
    organizationName: "Organization Name",
    organizationNamePlaceholder: "Enter your organization name",
    industry: "Industry",
    industryPlaceholder: "Enter your industry",
    pmoMaturityLevel: "PMO Maturity Level",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "Select the maturity level that best describes your current PMO",
    saveProfile: "Save Profile",
    cancel: "Cancel",
    initial: "Initial - Ad hoc processes",
    defined: "Defined - Basic processes established",
    managed: "Managed - Standardized processes",
    optimized: "Optimized - Continuously improving",
    notEstablished: "Not Established - No formal PMO",
  },
  
  //settings page
  settings: {
    title: "Settings",
    description: "Manage your account settings and preferences",
    personal: "Personal",
    subscription: "Subscription",
    notifications: "Notifications",
    security: "Security",
    data: "Data",
    saveProfile: "Save Profile",
    cancel: "Cancel",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "Select the maturity level that best describes your current PMO",
    organizationName: "Organization Name",
    organizationNamePlaceholder: "Enter your organization name",
    industry: "Industry",
    industryPlaceholder: "Enter your industry",
    pmoMaturityLevel: "PMO Maturity Level",
    notEstablished: "Not Established - No formal PMO",
    initial: "Initial - Ad hoc processes",
    defined: "Defined - Basic processes established",
    managed: "Managed - Standardized processes",
    optimized: "Optimized - Continuously improving",
  },

  // Resources page
  resources: {
    title: "Resources",
    noDocuments: "No documents available",
    errorLoading: "Error loading documents",
    downloadError: "Error downloading document",
    uploadNew: "Upload New Document",
    filter: "Filter Documents",
    sortBy: "Sort By",
    search: "Search Documents",
    lastModified: "Last Modified",
    fileName: "File Name",
    fileSize: "File Size",
    taskName: "Task Name",
    projectId: "Project ID"
  },
 // Help page
  help: {
    title: "Help & Support",
    description: "Learn how to use the PMO Domains Application Tool effectively",
    gettingStarted: "Getting Started",
    whatIsPmoDomainsTool: "What is the PMO Domains Tool?",
    whatIsPmoDomainsToolDescription: `The PMO Domains Application Tool helps PMO professionals apply and monitor the five key PMO domains using a structured "Inputs – Processing – Outputs" framework. The tool guides you through each domain's tasks, ensuring best practices and benchmarking against industry standards.`, 
    howToUseThisTool: "How to Use This Tool",
    howToUseThisToolDescription: "The PMO Domains Application Tool is a web-based application that helps organizations implement and improve their PMO capabilities across all domains.",
    canIExportMyData: "Can I export my data?",
    canIExportMyDataDescription: "Yes, you can export your data from the Settings page. This allows you to back up your progress or transfer it to another system.",
    canICustomizeTheToolForMyOrganization: "Can I customize the tool for my organization?",
    canICustomizeTheToolForMyOrganizationDescription: "The tool is designed to be applicable across different organizations and industries. You can add custom notes to each task to tailor it to your specific organizational context.",
    whatIfINotReadyToCompleteAllDomains: "What if I'm not ready to complete all domains?",
    whatIfINotReadyToCompleteAllDomainsDescription: "You can work on domains in any order that makes sense for your organization. The tool will track your progress across all domains, allowing you to focus on your priorities.",
    contactSupport: "Contact Support",
    contactSupportDescription: "If you need additional help or have questions about the PMO Domains Application Tool, please contact our support team.",
    supportContact: "Support Contact",
    supportContactEmail: "Email: support@pmobuilder.ai",
    supportContactPhone: "Phone: (555) 123-4567",
    supportContactHours: "Hours: Monday-Friday, 9am-5pm EST",
    startBySettingUpYourOrganizationProfile: "Start by setting up your organization profile in the Profile section",
    navigateToEachDomainUsingTheSidebarMenu: "Navigate to each domain using the sidebar menu",
    completeTasksInTheRecommendedOrder: "Complete tasks in the recommended order: Input → Processing → Output",
    markTasksAsCompleteAsYouProgress: "Mark tasks as complete as you progress",
    useTheDashboardToTrackYourOverallProgress: "Use the dashboard to track your overall progress",
    referToTheBestPracticesLibraryForGuidance: "Refer to the Best Practices Library for guidance",
    organizationalDevelopmentAndAlignment: "1. Organizational Development and Alignment",
    organizationalDevelopmentAndAlignmentDescription: "This domain focuses on aligning the PMO with organizational strategy and culture to ensure effective project management practices. It includes organizational assessment, stakeholder analysis, and developing alignment strategies.",
    strategicElementsOfThePmo: "2. Strategic Elements of the PMO",
    strategicElementsOfThePmoDescription: "This domain involves developing and implementing strategic frameworks, roadmaps, and governance structures. It includes strategic objectives review, portfolio analysis, and governance structure design.",
    pMODesignAndStructuring: "3. PMO Design and Structuring",
    pMODesignAndStructuringDescription: "This domain focuses on creating the optimal PMO structure, roles, and responsibilities to meet organizational needs. It includes requirements gathering, resource assessment, and service catalog development.",
    pMOOperationAndPerformance: "4. PMO Operation and Performance",
    pMOOperationAndPerformanceDescription: "This domain establishes operational processes, KPIs, and performance metrics for the PMO. It includes process assessment, performance metrics identification, and performance measurement systems.",
    pMOEnhancementAndEffectiveness: "5. PMO Enhancement and Effectiveness",
    pMOEnhancementAndEffectivenessDescription: "This domain focuses on continuously improving PMO services, capabilities, and value delivery. It includes maturity assessment, value delivery analysis, and continuous improvement planning.",
    frequentlyAskedQuestions: "Frequently Asked Questions",
    frequentlyAskedQuestionsDescription: "The PMO Domains Application Tool is a web-based application that helps organizations implement and improve their PMO capabilities across all domains.",
    howToAccessTemplates: "How do I access templates?",
    howToAccessTemplatesDescription: "Templates are available within specific tasks that have template resources. You can also find a collection of templates in the Best Practices Library",
    understandingTheFiveDomains: "Understanding the Five Domains",
  },
    
  subscription: {
    title: "Subscription Management",
    currentPlan: "Current Plan",
    trial: "Trial",
    cancelsAtPeriodEnd: "Cancels at period end",
    upgradePlan: "Upgrade Plan",
    manageSubscription: "Manage Subscription",
    processing: "Processing...",
    billingPeriod: "Billing Period",
    nextBillingDate: "Next Billing Date",
    paymentMethod: "Payment Method",
    projects: "Projects",
    aiAnalysis: "AI Analysis",
    storage: "Storage",
    freePlanLimitations: "Free plan limitations",
    freePlanLimitationsDescription: "You're currently on the Free plan, which has limitations on projects, AI analyses, and storage. Upgrade to Premium or Enterprise for increased limits and additional features.",
    upgradeNow: "Upgrade Now",
    upgradeToGetMore: "Upgrade to Get More",
    premiumPlanBenefits: "Premium Plan Benefits",
    upTo20Projects: "Up to 20 projects (vs. 3 on Free)",
    upTo100AiAnalyses: "100 AI analyses per month (vs. 3 on Free)",
    teamCollaboration: "Team collaboration with up to 5 users",
    prioritySupport: "Priority support",
    enterprisePlanBenefits: "Enterprise Plan Benefits",
    unlimitedProjectsAndAiAnalyses: "Unlimited projects and AI analyses",
    unlimitedTeamMembers: "Unlimited team members",
    whiteLabelingOptions: "White-labeling options",
    dedicatedSupport: "Dedicated support",
    upgradeToEnterprise: "Upgrade to Enterprise",
    unlimited: "Unlimited",
    unknown: "Unknown",
    free: "Free",
    premium: "Premium",
    enterprise: "Enterprise",
    usageAndLimits: "Usage & Limits",
    perMonth: "per month",
    mb: "MB",
    none: "None",
    creditCard: "Credit Card",
    paypal: "PayPal",
    notAvailable: "Not available",
  },
  
  //notifications
  notifications: {
    '1': {
      title: "PMO Maturity Assessment Due",
      description: "Complete your quarterly PMO maturity assessment by Friday.",
      time: "2 days ago",
    },
    '2': {
      title: "Strategic Elements Domain Updated",
      description: "New templates and resources have been added to the Strategic Elements domain.",
      time: "3 days ago",
    },
    '3': {
      title: "Team Meeting: PMO Enhancement",
      description: "Upcoming team meeting to discuss PMO Enhancement strategies.",
      time: "Tomorrow, 10:00 AM",
    },
    '4': {
      title: "New Message from Admin",
      description: "You have a new message regarding your Organization Development domain progress.",
      time: "1 week ago",
    },
    '5': {
      title: "Data Backup Complete",
      description: "Your PMO data has been successfully backed up to cloud storage.",
      time: "2 weeks ago",
    },
    title: "Notifications",
    description: "Stay updated with your PMO activities and important alerts",
    markAllAsRead: "Mark all as read",
    clearAll: "Clear all",
    markAllAsReadDescription: "Mark all notifications as read",
    clearAllDescription: "Clear all notifications",
    markAllAsReadButton: "Mark all as read",
    clearAllButton: "Clear all",
    unread: "Unread",
    all: "All",
    recentNotifications: "Recent Notifications",
    markAsUnread: "Mark as unread",
    markAsRead: "Mark as read",
    viewDetails: "View details",
    loadMore: "Load more notifications",
    customizeNotifications: "Customize how and when you receive notifications about your PMO activities",
    notificationPreferences: "Notification Preferences",
    managePreferences: "Manage Preferences",
    

  },
  // Domain names
  domains: {
    "1": {
      name: "Organizational Development and Alignment",
      description: "Aligning the PMO with organizational strategy and culture to ensure effective project management practices.",
      tasks: {
        "1-input-1": {
          stage: "input",
          title: "Assess Current Competencies",
          description: "Gather data on existing competencies through surveys, interviews, and documentation review.",
          bestPractices: [
            "Use standardized assessment tools to evaluate current competencies",
            "Collect input from multiple organizational levels",
            "Document both technical and soft skill competencies",
            "Identify competency gaps through structured assessment"
          ]
        },
        "1-input-2": {
          stage: "input",
          title: "Assess Organizational Culture",
          description: "Collect data on current organizational culture through surveys, focus groups, and stakeholder interviews.",
          bestPractices: [
            "Conduct culture assessment surveys",
            "Gather feedback from diverse organizational levels",
            "Document cultural enablers and barriers to project management",
            "Collect historical data on cultural change initiatives"
          ]
        },
        "1-input-3": {
          stage: "input",
          title: "Benchmark Against Industry Standards",
          description: "Collect industry benchmarking data and best practices for organizational alignment.",
          bestPractices: [
            "Select relevant industry benchmarks and standards",
            "Gather data from industry reports and publications",
            "Document peer organization practices",
            "Collect metrics for comparative analysis"
          ]
        },
        "1-processing-1": {
          stage: "processing",
          title: "Apply Strategic Analysis Techniques",
          description: "Use strategic analysis tools to develop an integrated strategy with risk management and implementation roadmap.",
          bestPractices: [
            "Apply SWOT analysis to identify strengths and weaknesses",
            "Use gap analysis to identify improvement areas",
            "Apply risk assessment methodologies",
            "Use roadmapping techniques for implementation planning"
          ]
        },
        "1-processing-2": {
          stage: "processing",
          title: "Apply Communication Planning Methodologies",
          description: "Use communication planning techniques to develop stakeholder-specific messaging and feedback mechanisms.",
          bestPractices: [
            "Apply stakeholder analysis techniques",
            "Use communication matrix development methods",
            "Apply message tailoring methodologies",
            "Use KPI development frameworks for communication effectiveness"
          ]
        },
        "1-processing-3": {
          stage: "processing",
          title: "Apply Charter Development Techniques",
          description: "Use charter development methodologies to define PMO scope, authority, and governance structure.",
          bestPractices: [
            "Apply scope definition techniques",
            "Use RACI matrix development methods",
            "Apply governance framework design methodologies",
            "Use authority mapping techniques"
          ],
          templates: ["PMO Charter Template", "RACI Matrix"]
        },
        "1-output-1": {
          stage: "output",
          title: "Deliver Integrated Strategy and Roadmap",
          description: "Produce and implement the integrated strategy with risk management plan and phased implementation roadmap.",
          bestPractices: [
            "Document comprehensive strategy with clear objectives",
            "Create detailed implementation roadmap with milestones",
            "Develop risk management plan with mitigation strategies",
            "Establish strategy review and update mechanisms"
          ]
        },
        "1-output-2": {
          stage: "output",
          title: "Establish PMO Vision, Values and Culture",
          description: "Implement vision statement, core values, and cultural change program with leadership engagement.",
          bestPractices: [
            "Create compelling vision statement aligned with organization",
            "Document core values with behavioral examples",
            "Implement leadership engagement activities",
            "Establish cultural reinforcement mechanisms"
          ],
          templates: ["PMO Vision Statement Template", "Cultural Change Roadmap"]
        },
        "1-output-3": {
          stage: "output",
          title: "Implement PMO Charter and Governance",
          description: "Establish and operationalize PMO charter with defined scope, authority, and governance structure.",
          bestPractices: [
            "Formalize PMO charter with executive approval",
            "Implement governance structure with clear roles",
            "Establish decision-making authorities and processes",
            "Create charter review and update mechanisms"
          ],
          templates: ["PMO Charter Document", "Governance Structure Diagram"]
        },
      },
    },
    "2": {
      name: "Strategic Framework & Governance",
      description: "Creating the optimal PMO structure, roles, and responsibilities to meet organizational needs.",
      tasks: {
        "2-input-1": {
          stage: "input",
          title: "Gather Current State Data",
          description: "Collect data on current project management operations, processes, and performance.",
          bestPractices: [
            "Conduct process documentation review",
            "Gather performance metrics and historical data",
            "Collect stakeholder feedback on current operations",
            "Document existing governance structures"
          ]
        },
        "2-input-2": {
          stage: "input",
          title: "Collect Strategic Alignment Information",
          description: "Gather organizational strategic objectives, priorities, and success criteria.",
          bestPractices: [
            "Review organizational strategic plans",
            "Collect executive leadership priorities",
            "Document business unit objectives",
            "Gather information on strategic initiatives"
          ]
        },
        "2-input-3": {
          stage: "input",
          title: "Identify Capability Requirements",
          description: "Collect data on required capabilities through stakeholder interviews and organizational needs assessment.",
          bestPractices: [
            "Conduct capability needs interviews",
            "Gather industry capability standards",
            "Document capability prioritization criteria",
            "Collect capability maturity benchmarks"
          ]
        },
        "2-processing-1": {
          stage: "processing",
          title: "Apply Mandate Development Methodology",
          description: "Use mandate development techniques to define PMO purpose, authority, and responsibilities.",
          bestPractices: [
            "Apply purpose statement development methods",
            "Use authority mapping techniques",
            "Apply responsibility definition methodologies",
            "Use stakeholder validation approaches"
          ],
          templates: ["PMO Mandate Template", "Executive Sponsorship Agreement"]
        },
        "2-processing-2": {
          stage: "processing",
          title: "Apply Charter Development Framework",
          description: "Use charter development framework to create comprehensive PMO charter with roles and governance structure.",
          bestPractices: [
            "Apply vision and mission statement techniques",
            "Use organizational structure design methods",
            "Apply role definition methodologies",
            "Use governance framework design techniques"
          ],
          templates: ["PMO Charter Template", "Governance Structure Diagram"]
        },
        "2-processing-3": {
          stage: "processing",
          title: "Apply Governance Design Methodology",
          description: "Use governance design techniques to develop decision-making processes and oversight mechanisms.",
          bestPractices: [
            "Apply decision rights mapping techniques",
            "Use escalation path design methods",
            "Apply governance body design methodologies",
            "Use governance communication planning techniques"
          ],
          templates: ["Governance Framework Template", "Decision Rights Matrix"]
        },
        "2-output-1": {
          stage: "output",
          title: "Establish PMO Mandate and Charter",
          description: "Formalize and implement PMO mandate and charter with defined purpose, authority, and responsibilities.",
          bestPractices: [
            "Obtain executive approval for mandate and charter",
            "Communicate mandate to all stakeholders",
            "Implement authority structures defined in charter",
            "Establish charter review and update process"
          ],
          templates: ["Approved PMO Mandate", "Finalized PMO Charter"]
        },
        "2-output-2": {
          stage: "output",
          title: "Implement Governance Framework",
          description: "Establish and operationalize governance framework with decision-making bodies, processes, and oversight mechanisms.",
          bestPractices: [
            "Form governance committees with clear charters",
            "Implement decision-making processes and authorities",
            "Establish governance meeting cadence and agendas",
            "Create governance documentation and reporting system"
          ],
          templates: ["Governance Committee Charter", "Decision Authority Matrix"]
        },
        "2-output-3": {
          stage: "output",
          title: "Develop Strategic Communication Plan",
          description: "Implement comprehensive communication strategy with stakeholder-specific messaging and feedback mechanisms.",
          bestPractices: [
            "Create stakeholder-specific communication materials",
            "Establish regular communication cadence",
            "Implement feedback collection mechanisms",
            "Develop communication effectiveness metrics"
          ],
          templates: ["Strategic Communication Plan", "Stakeholder Messaging Matrix"]
        },      
      }
    },
    "3": {
      name: "PMO Structure & Design",
      description: "Establishing operational processes, KPIs, and performance metrics for the PMO.",
      tasks: {
        "3-input-1": {
          stage: "input",
          title: "Gather Customer Data",
          description: "Collect data on potential PMO customers, their needs, and expectations through surveys and interviews.",
          bestPractices: [
            "Conduct customer needs assessment surveys",
            "Gather stakeholder interview data",
            "Document customer pain points and expectations",
            "Collect service prioritization information"
          ]
        },
        "3-input-2": {
          stage: "input",
          title: "Collect Service Requirement Data",
          description: "Gather detailed requirements for potential PMO services through workshops and requirements sessions.",
          bestPractices: [
            "Conduct service requirements workshops",
            "Document service level expectations",
            "Collect service prioritization criteria",
            "Gather benchmark data on similar services"
          ],
          templates: ["Service Requirements Template", "Customer Needs Assessment"]
        },
        "3-input-3": {
          stage: "input",
          title: "Assess Capability Gaps",
          description: "Collect data on current capabilities and gaps through assessment tools and stakeholder feedback.",
          bestPractices: [
            "Use capability maturity assessment tools",
            "Gather capability benchmark data",
            "Document capability prioritization criteria",
            "Collect resource availability information"
          ]
        },
        "3-processing-1": {
          stage: "processing",
          title: "Apply Persona Development Techniques",
          description: "Use persona development methodologies to create detailed customer personas with needs and expectations.",
          bestPractices: [
            "Apply customer segmentation techniques",
            "Use persona development frameworks",
            "Apply needs analysis methodologies",
            "Use journey mapping techniques"
          ]
        },
        "3-processing-2": {
          stage: "processing",
          title: "Apply Prioritization Frameworks",
          description: "Use prioritization techniques to develop framework for addressing customer needs systematically.",
          bestPractices: [
            "Apply value vs. effort prioritization matrix",
            "Use MoSCoW prioritization technique",
            "Apply weighted scoring methodologies",
            "Use impact mapping techniques"
          ]
        },
        "3-processing-3": {
          stage: "processing",
          title: "Apply Service Catalog Design Methodology",
          description: "Use service catalog design techniques to develop comprehensive service offerings with benefits and advantages.",
          bestPractices: [
            "Apply service definition frameworks",
            "Use service level definition techniques",
            "Apply value proposition development methodologies",
            "Use service categorization techniques"
          ],
          templates: ["Service Catalog Template", "Service Level Agreement Template"]
        },
        "3-output-1": {
          stage: "output",
          title: "Deliver Customer Personas and Journey Maps",
          description: "Create and distribute detailed customer personas and journey maps to guide service design and delivery.",
          bestPractices: [
            "Document comprehensive personas with needs and pain points",
            "Create visual journey maps for key customer interactions",
            "Distribute personas to all service delivery teams",
            "Establish persona update and refinement process"
          ],
          templates: ["Customer Persona Template", "Journey Map Template"]
        },
        "3-output-2": {
          stage: "output",
          title: "Implement Service Catalog and SLAs",
          description: "Launch comprehensive service catalog with service level agreements, processes, and quality standards.",
          bestPractices: [
            "Create detailed service descriptions with value propositions",
            "Establish service level metrics and targets",
            "Implement service request and delivery processes",
            "Create service catalog review and update mechanism"
          ],
          templates: ["Service Catalog Document", "SLA Documentation"]
        },
        "3-output-3": {
          stage: "output",
          title: "Establish Service Prioritization Framework",
          description: "Implement systematic approach for prioritizing and addressing customer needs and service requests.",
          bestPractices: [
            "Create prioritization criteria and scoring system",
            "Implement request intake and evaluation process",
            "Establish resource allocation based on priorities",
            "Develop priority review and adjustment mechanisms"
          ],
          templates: ["Prioritization Matrix", "Service Request Form"]
        },      
      }
// Translation keys organized by component/page
// English translations
const en = {
  // Common components
  common: {
    pleaseWait: "Please wait while we prepare your content.",
    Complete : "Complete",
    search: "Search",
    save: "Save",
    saveAssessment: "Save Assessment",
    saved: "Saved!",
    showLess: "Show less",
    showMore: "Show more",
    cancel: "Cancel",
    edit: "Edit",
    delete: "Delete",
    close: "Close",
    loading: "Loading...",
    submit: "Submit",
    active: "Active",
    back: "Back",
    spent: "Spent",
    used: "Used",
    onTrack: "On Track",
    viewDetails: "View Details",
    tasks: "Tasks",
    domains: "Domains",
    budget: "Budget",
    daysLeft: "days left",
    next: "Next",
    progress: "Progress",
    notifications: "Notifications",
    help: "Help",
    settings: "Settings",
    profile: "Profile",
    signOut: "Sign Out",
    dashboard: "Dashboard",
    export: "Export",
    import: "Import",
    share: "Share",
    days: "days",
    darkMode: "Dark Mode",
    lightMode: "Light Mode",
    confirm: "Confirm",
    remainingTokens: "Remaining Tokens"
  },
  
  // Header component
  header: {
    search: "Search...",
    myTeams: "My Teams",
    invitations: "Invitations",
    setupProfile: "Setup Profile",
    subscription: "Subscription",
    settings: "Settings",
    adminPanel: "Admin Panel",
    signOut: "Sign out",
    profile: "Profile",
  },
  
  // Dashboard page
  dashboard: {
    title: "Dashboard",
    subtitle: "Build and track your PMO across all essential domains",
    budget: "Budget",
    editDetails: "Edit Details",
    exportReport: "Export Report",
    access: "Access",
    timelineProgress: "Timeline Progress",
    budgetUtilization: "Budget Utilization",
    projectStatus: "Project Status",
    maturityAssessment: "Maturity Assessment",
    keyObjectives: "Key Objectives",
    stakeholders: "Stakeholders",
    overallProgress: "Overall Progress",
    completedTasks: "Completed Tasks",
    domainProcessComparison:"Domain Progress Comparison",
    organization: "Organization",
    industry: "Industry",
    dashboardCustomization: "Dashboard Customization",
    displayLayout: "Display Layout",
    gridView: "Grid View",
    listView: "List View",
    widgetSelection: "Widget Selection",
    assessMaturityLevel: "Assess Your Maturity Level",
    maturityLevel: "Maturity Level",
    progressOverview: "Progress Overview",
    tasksStatus: "Tasks Status",
    domains: "Domains",
    chartsAnalytics: "Charts & Analytics",
    pmoMaturityLevel: "PMO Maturity Level",
    pmoDomains: "PMO Domains",
    aiAnalysis: "Accelerate with AI",
    aiDescription: "Let our advanced AI analyze your PMO data and generate comprehensive recommendations tailored to your organization's unique needs.",
    tryAiAnalysis: "Try AI Analysis",
    viewAll: "View all",
    of: "of",
    tasksCompleted: "tasks completed",
    notSet: "Not set",
    updateProfile: "Update profile",
    viewAllTasks: "View all tasks",
    nextSteps: "Next Steps",
    uploadDocuments: "Upload documents",
    analysisDocuments: "Upload supporting documents for AI analysis",
    analysisDocumentsDesc: "Enhance AI recommendations with your organization's context",
    completePmoMaturityAssessment: "Complete a PMO Maturity Assessment",
    getInsightsAboutPmoMaturityLevel: "Get insights about your PMO's current maturity level",
    reviewPractices: "Review best practices",
    explorePractices: "Explore the best practices library for guidance",
    viewResources: "View resources",
    goToAssessment: "Go to assessment",
    objective1: "Establish PMO governance framework",
    objective2: "Develop standard methodologies",
    objective3: "Implement performance metrics",
    sampleProject: "Sample PMO Implementation",
    sampleDescription: "A sample project with pre-populated data for demonstration",
    createFirstProject: "Create Your First PMO Project",
    firstProjectDesc: "Get started by creating your first PMO implementation project. You can set up project details, track progress across domains, and generate AI-powered recommendations.",
    createSample: "Create Sample Project",
    aiFeature1: "Custom templates based on your current maturity level",
    aiFeature2: "Detailed implementation roadmaps for each domain",
    aiFeature3: "Best practices tailored to your industry and context",
    maturityRadarChart: "Maturity Radar Chart",
    higherValuesIndicateGreaterMaturity: "Higher values indicate greater maturity",
    pmoMaturityAssessment: "PMO Maturity Assessment",
    assessPmoMaturity: "Assess your PMO's maturity level across all domains to identify strengths and improvement opportunities",
    selfAssessment: "Self-Assessment",
    aiGeneratedAssessment: "AI-Generated Assessment",
    notSpecified: "Not specified",
    currentMaturityProfile: "Current Maturity Profile",
    organizationDetails: "Organization Details",
    assessmentType: "Assessment Type",
    currentMaturityProfileDescription: "Your organization's PMO is currently at the",
    currentMaturityProfileDescription2: "level. This assessment will help you identify areas for improvement and create a roadmap for advancing your PMO capabilities.",
    assessmentDate: "Assessment Date",
    selfAssessmentQuestionnaire: "Self-Assessment Questionnaire",
    selfAssessmentDescription: "Rate your PMO's maturity level for each domain. Consider your processes, documentation, measurement capabilities, and continuous improvement efforts when making your assessment.",
    documentation: "Documentation",
    metrics: "Metrics",
    minimalToNone: "Minimal to none",
    basicDocumentation: "Basic documentation",
    comprehensiveDocumentation: "Comprehensive",
    regularlyUpdated: "Regularly updated",
    leadingPractice: "Leading practice",
    adHocOrNone: "Ad-hoc or none",
    basicTracking: "Basic tracking",
    notes: "Notes (Optional)",
    notesPlaceholder: "Add any notes or context about your assessment...",
    createNew: "Create New Project",
    generateAIAssessment: "Generate an AI Assessment",
    aiAssessmentDescription: "Our AI will analyze your domain inputs, project data, and uploaded documents to provide an objective assessment of your PMO's maturity across all domains.",
    aiAssessmentSummary: "AI Assessment Summary",
    aiAssessmentSummaryDescription: "Based on our analysis, your PMO is currently at the",
    keyStrengths: "Key Strengths",
    areasForImprovement: "Areas for Improvement",
    domainSpecificAssessment: "Domain-Specific Assessment",
    maturityProgression: "Maturity Progression",
    recommendations: "Recommendations",
    generatingReport: "Generating Report...",
    exportAssessmentReport: "Export Assessment Report",
    detailedMaturityGuide: "Detailed Maturity Guide",
    maturityModelReference: "Maturity Model Reference",
    generateAssessment: "Generate Assessment",
    generatingAssessment: "Generating Assessment...",
    generatingAssessmentDescription: "Our AI is analyzing your PMO data across all domains. This may take a few moments.",
    
  },
  
  // Domain detail page
  domain: {
    BestPractices: "Best Practices",
    backToDashboard: "Back to Dashboard",
    prevDomain: "Previous Domain",
    nextDomain: "Next Domain",
    viewDomain: "View Domain",
    progress: "Progress",
    tasks: "Tasks & Progress",
    input: "Domain Input & Analysis",
    analyzing: "Analyzing Domain Input",
    processingData: "Our AI is processing your input data...",
    inputStage: "Input",
    inputDesc: "Collect data, assess current state, and gather requirements for this domain.",
    processingStage: "Processing",
    processingDesc: "Analyze data, develop frameworks, and design solutions for this domain.",
    outputStage: "Output",
    outputDesc: "Create deliverables, implement solutions, and establish frameworks for this domain.",
    loading: "Loading domain data...",
    notFound: "Domain not found",
    provideInputFirst: "Please provide domain input data before analyzing",
    aiGeneratedAnalysis: "AI-Generated Analysis for",
    generated: "Generated",
    analysis: "Analysis",
    domainProgress: "Domain Progress (%)",
    templates: "Templates",
    downloadMarkdown: "Download Markdown",
    downloadPdf: "Download PDF",
    generatingPdf: "Generating PDF...",
    generating: "Generating...",
    allTemplates: "All Available Templates",
    markdownFormat: "Markdown",
    words: "words",
    usingTemplates: "Using These Templates",
    templateDescription: "These templates are available in Markdown and PDF formats. Markdown can be imported into document editors, project management tools, or converted to other formats. PDF files are ready for printing or sharing with stakeholders.",
    noTemplates: "No templates available for this domain",
    aiConfigTitle: "AI Analysis Configuration",
    selectDomainPrompt: "Select a domain to analyze with our advanced AI. The analysis will generate comprehensive recommendations and templates based on your organization's specific context.",
    selectDomain: "Select Domain",
    analysisDepth: "Analysis Depth",
    basic: "Basic",
    quickOverview: "Quick overview",
    standard: "Standard",
    balancedAnalysis: "Balanced analysis",
    detailed: "Detailed",
    inDepthReview: "In-depth review",
    comprehensive: "Comprehensive",
    maximumDetail: "Maximum detail",
    geminiPowered: "Gemini AI Powered Analysis",
    advancedAiDesc: "Advanced AI will analyze your inputs and generate tailored recommendations",
    startAnalysis: "Start Analysis"
  },
  
  // Project management
  project: {
    projectName: "Project Name",
    projectNamePlaceholder: "Enterprise PMO Implementation",
    description: "Description",
    descriptionPlaceholder: "Brief description of your PMO implementation project",
    budget: "Budget",
    yourProjects: "Your Projects",
    createProject: "Create Project"
  },
  
  // Sidebar
  sidebar: {
    dashboard: "Dashboard",
    pmoDomains: "PMO Domains",
    tools: "Tools & Assessment",
    resources: "Resources",
    tasks: "Tasks",
    bestPractices: "Best Practices",
    maturityAssessment: "Maturity Assessment",
    assessment: "Assessment",
  },
  
  // Auth pages
  auth: {
    copyright: "© 2025 PMO Builder using AI by Dr. Ahmed Alsenosy"
  },
  
  // Maturity levels
  maturityLevels: {
    initial: {
      label: 'Initial',
      description: 'Processes are ad hoc and chaotic.'
    },
    defined: {
      label: 'Defined',
      description: 'Processes are documented and standardized.'
    },
    managed: {
      label: 'Managed',
      description: 'Processes are measured and controlled.'
    },
    optimized: {
      label: 'Optimized',
      description: 'Focus on continuous improvement.'
    },
    innovative: {
      label: 'Innovative',
      description: 'Driving industry innovation and adaptation.'
    }
  },

  //profile page
  profile: {
    title: "Organization Profile",
    description: "Set up your organization details to personalize your PMO journey",
    organizationName: "Organization Name",
    organizationNamePlaceholder: "Enter your organization name",
    industry: "Industry",
    industryPlaceholder: "Enter your industry",
    pmoMaturityLevel: "PMO Maturity Level",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "Select the maturity level that best describes your current PMO",
    saveProfile: "Save Profile",
    cancel: "Cancel",
    initial: "Initial - Ad hoc processes",
    defined: "Defined - Basic processes established",
    managed: "Managed - Standardized processes",
    optimized: "Optimized - Continuously improving",
    notEstablished: "Not Established - No formal PMO",
  },
  
  //settings page
  settings: {
    title: "Settings",
    description: "Manage your account settings and preferences",
    personal: "Personal",
    subscription: "Subscription",
    notifications: "Notifications",
    security: "Security",
    data: "Data",
    saveProfile: "Save Profile",
    cancel: "Cancel",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "Select the maturity level that best describes your current PMO",
    organizationName: "Organization Name",
    organizationNamePlaceholder: "Enter your organization name",
    industry: "Industry",
    industryPlaceholder: "Enter your industry",
    pmoMaturityLevel: "PMO Maturity Level",
    notEstablished: "Not Established - No formal PMO",
    initial: "Initial - Ad hoc processes",
    defined: "Defined - Basic processes established",
    managed: "Managed - Standardized processes",
    optimized: "Optimized - Continuously improving",
  },

  // Resources page
  resources: {
    title: "Resources",
    noDocuments: "No documents available",
    errorLoading: "Error loading documents",
    downloadError: "Error downloading document",
    uploadNew: "Upload New Document",
    filter: "Filter Documents",
    sortBy: "Sort By",
    search: "Search Documents",
    lastModified: "Last Modified",
    fileName: "File Name",
    fileSize: "File Size",
    taskName: "Task Name",
    projectId: "Project ID"
  },
 // Help page
  help: {
    title: "Help & Support",
    description: "Learn how to use the PMO Domains Application Tool effectively",
    gettingStarted: "Getting Started",
    whatIsPmoDomainsTool: "What is the PMO Domains Tool?",
    whatIsPmoDomainsToolDescription: `The PMO Domains Application Tool helps PMO professionals apply and monitor the five key PMO domains using a structured "Inputs – Processing – Outputs" framework. The tool guides you through each domain's tasks, ensuring best practices and benchmarking against industry standards.`, 
    howToUseThisTool: "How to Use This Tool",
    howToUseThisToolDescription: "The PMO Domains Application Tool is a web-based application that helps organizations implement and improve their PMO capabilities across all domains.",
    canIExportMyData: "Can I export my data?",
    canIExportMyDataDescription: "Yes, you can export your data from the Settings page. This allows you to back up your progress or transfer it to another system.",
    canICustomizeTheToolForMyOrganization: "Can I customize the tool for my organization?",
    canICustomizeTheToolForMyOrganizationDescription: "The tool is designed to be applicable across different organizations and industries. You can add custom notes to each task to tailor it to your specific organizational context.",
    whatIfINotReadyToCompleteAllDomains: "What if I'm not ready to complete all domains?",
    whatIfINotReadyToCompleteAllDomainsDescription: "You can work on domains in any order that makes sense for your organization. The tool will track your progress across all domains, allowing you to focus on your priorities.",
    contactSupport: "Contact Support",
    contactSupportDescription: "If you need additional help or have questions about the PMO Domains Application Tool, please contact our support team.",
    supportContact: "Support Contact",
    supportContactEmail: "Email: support@pmobuilder.ai",
    supportContactPhone: "Phone: (555) 123-4567",
    supportContactHours: "Hours: Monday-Friday, 9am-5pm EST",
    startBySettingUpYourOrganizationProfile: "Start by setting up your organization profile in the Profile section",
    navigateToEachDomainUsingTheSidebarMenu: "Navigate to each domain using the sidebar menu",
    completeTasksInTheRecommendedOrder: "Complete tasks in the recommended order: Input → Processing → Output",
    markTasksAsCompleteAsYouProgress: "Mark tasks as complete as you progress",
    useTheDashboardToTrackYourOverallProgress: "Use the dashboard to track your overall progress",
    referToTheBestPracticesLibraryForGuidance: "Refer to the Best Practices Library for guidance",
    organizationalDevelopmentAndAlignment: "1. Organizational Development and Alignment",
    organizationalDevelopmentAndAlignmentDescription: "This domain focuses on aligning the PMO with organizational strategy and culture to ensure effective project management practices. It includes organizational assessment, stakeholder analysis, and developing alignment strategies.",
    strategicElementsOfThePmo: "2. Strategic Elements of the PMO",
    strategicElementsOfThePmoDescription: "This domain involves developing and implementing strategic frameworks, roadmaps, and governance structures. It includes strategic objectives review, portfolio analysis, and governance structure design.",
    pMODesignAndStructuring: "3. PMO Design and Structuring",
    pMODesignAndStructuringDescription: "This domain focuses on creating the optimal PMO structure, roles, and responsibilities to meet organizational needs. It includes requirements gathering, resource assessment, and service catalog development.",
    pMOOperationAndPerformance: "4. PMO Operation and Performance",
    pMOOperationAndPerformanceDescription: "This domain establishes operational processes, KPIs, and performance metrics for the PMO. It includes process assessment, performance metrics identification, and performance measurement systems.",
    pMOEnhancementAndEffectiveness: "5. PMO Enhancement and Effectiveness",
    pMOEnhancementAndEffectivenessDescription: "This domain focuses on continuously improving PMO services, capabilities, and value delivery. It includes maturity assessment, value delivery analysis, and continuous improvement planning.",
    frequentlyAskedQuestions: "Frequently Asked Questions",
    frequentlyAskedQuestionsDescription: "The PMO Domains Application Tool is a web-based application that helps organizations implement and improve their PMO capabilities across all domains.",
    howToAccessTemplates: "How do I access templates?",
    howToAccessTemplatesDescription: "Templates are available within specific tasks that have template resources. You can also find a collection of templates in the Best Practices Library",
    understandingTheFiveDomains: "Understanding the Five Domains",
  },
    
  subscription: {
    title: "Subscription Management",
    currentPlan: "Current Plan",
    trial: "Trial",
    cancelsAtPeriodEnd: "Cancels at period end",
    upgradePlan: "Upgrade Plan",
    manageSubscription: "Manage Subscription",
    processing: "Processing...",
    billingPeriod: "Billing Period",
    nextBillingDate: "Next Billing Date",
    paymentMethod: "Payment Method",
    projects: "Projects",
    aiAnalysis: "AI Analysis",
    storage: "Storage",
    freePlanLimitations: "Free plan limitations",
    freePlanLimitationsDescription: "You're currently on the Free plan, which has limitations on projects, AI analyses, and storage. Upgrade to Premium or Enterprise for increased limits and additional features.",
    upgradeNow: "Upgrade Now",
    upgradeToGetMore: "Upgrade to Get More",
    premiumPlanBenefits: "Premium Plan Benefits",
    upTo20Projects: "Up to 20 projects (vs. 3 on Free)",
    upTo100AiAnalyses: "100 AI analyses per month (vs. 3 on Free)",
    teamCollaboration: "Team collaboration with up to 5 users",
    prioritySupport: "Priority support",
    enterprisePlanBenefits: "Enterprise Plan Benefits",
    unlimitedProjectsAndAiAnalyses: "Unlimited projects and AI analyses",
    unlimitedTeamMembers: "Unlimited team members",
    whiteLabelingOptions: "White-labeling options",
    dedicatedSupport: "Dedicated support",
    upgradeToEnterprise: "Upgrade to Enterprise",
    unlimited: "Unlimited",
    unknown: "Unknown",
    free: "Free",
    premium: "Premium",
    enterprise: "Enterprise",
    usageAndLimits: "Usage & Limits",
    perMonth: "per month",
    mb: "MB",
    none: "None",
    creditCard: "Credit Card",
    paypal: "PayPal",
    notAvailable: "Not available",
  },
  
  //notifications
  notifications: {
    '1': {
      title: "PMO Maturity Assessment Due",
      description: "Complete your quarterly PMO maturity assessment by Friday.",
      time: "2 days ago",
    },
    '2': {
      title: "Strategic Elements Domain Updated",
      description: "New templates and resources have been added to the Strategic Elements domain.",
      time: "3 days ago",
    },
    '3': {
      title: "Team Meeting: PMO Enhancement",
      description: "Upcoming team meeting to discuss PMO Enhancement strategies.",
      time: "Tomorrow, 10:00 AM",
    },
    '4': {
      title: "New Message from Admin",
      description: "You have a new message regarding your Organization Development domain progress.",
      time: "1 week ago",
    },
    '5': {
      title: "Data Backup Complete",
      description: "Your PMO data has been successfully backed up to cloud storage.",
      time: "2 weeks ago",
    },
    title: "Notifications",
    description: "Stay updated with your PMO activities and important alerts",
    markAllAsRead: "Mark all as read",
    clearAll: "Clear all",
    markAllAsReadDescription: "Mark all notifications as read",
    clearAllDescription: "Clear all notifications",
    markAllAsReadButton: "Mark all as read",
    clearAllButton: "Clear all",
    unread: "Unread",
    all: "All",
    recentNotifications: "Recent Notifications",
    markAsUnread: "Mark as unread",
    markAsRead: "Mark as read",
    viewDetails: "View details",
    loadMore: "Load more notifications",
    customizeNotifications: "Customize how and when you receive notifications about your PMO activities",
    notificationPreferences: "Notification Preferences",
    managePreferences: "Manage Preferences",
    

  },
  // Domain names
  domains: {
    "1": {
      name: "Organizational Development and Alignment",
      description: "Aligning the PMO with organizational strategy and culture to ensure effective project management practices.",
      tasks: {
        "1-input-1": {
          stage: "input",
          title: "Assess Current Competencies",
          description: "Gather data on existing competencies through surveys, interviews, and documentation review.",
          bestPractices: [
            "Use standardized assessment tools to evaluate current competencies",
            "Collect input from multiple organizational levels",
            "Document both technical and soft skill competencies",
            "Identify competency gaps through structured assessment"
          ]
        },
        "1-input-2": {
          stage: "input",
          title: "Assess Organizational Culture",
          description: "Collect data on current organizational culture through surveys, focus groups, and stakeholder interviews.",
          bestPractices: [
            "Conduct culture assessment surveys",
            "Gather feedback from diverse organizational levels",
            "Document cultural enablers and barriers to project management",
            "Collect historical data on cultural change initiatives"
          ]
        },
        "1-input-3": {
          stage: "input",
          title: "Benchmark Against Industry Standards",
          description: "Collect industry benchmarking data and best practices for organizational alignment.",
          bestPractices: [
            "Select relevant industry benchmarks and standards",
            "Gather data from industry reports and publications",
            "Document peer organization practices",
            "Collect metrics for comparative analysis"
          ]
        },
        "1-processing-1": {
          stage: "processing",
          title: "Apply Strategic Analysis Techniques",
          description: "Use strategic analysis tools to develop an integrated strategy with risk management and implementation roadmap.",
          bestPractices: [
            "Apply SWOT analysis to identify strengths and weaknesses",
            "Use gap analysis to identify improvement areas",
            "Apply risk assessment methodologies",
            "Use roadmapping techniques for implementation planning"
          ]
        },
        "1-processing-2": {
          stage: "processing",
          title: "Apply Communication Planning Methodologies",
          description: "Use communication planning techniques to develop stakeholder-specific messaging and feedback mechanisms.",
          bestPractices: [
            "Apply stakeholder analysis techniques",
            "Use communication matrix development methods",
            "Apply message tailoring methodologies",
            "Use KPI development frameworks for communication effectiveness"
          ]
        },
        "1-processing-3": {
          stage: "processing",
          title: "Apply Charter Development Techniques",
          description: "Use charter development methodologies to define PMO scope, authority, and governance structure.",
          bestPractices: [
            "Apply scope definition techniques",
            "Use RACI matrix development methods",
            "Apply governance framework design methodologies",
            "Use authority mapping techniques"
          ],
          templates: ["PMO Charter Template", "RACI Matrix"]
        },
        "1-output-1": {
          stage: "output",
          title: "Deliver Integrated Strategy and Roadmap",
          description: "Produce and implement the integrated strategy with risk management plan and phased implementation roadmap.",
          bestPractices: [
            "Document comprehensive strategy with clear objectives",
            "Create detailed implementation roadmap with milestones",
            "Develop risk management plan with mitigation strategies",
            "Establish strategy review and update mechanisms"
          ]
        },
        "1-output-2": {
          stage: "output",
          title: "Establish PMO Vision, Values and Culture",
          description: "Implement vision statement, core values, and cultural change program with leadership engagement.",
          bestPractices: [
            "Create compelling vision statement aligned with organization",
            "Document core values with behavioral examples",
            "Implement leadership engagement activities",
            "Establish cultural reinforcement mechanisms"
          ],
          templates: ["PMO Vision Statement Template", "Cultural Change Roadmap"]
        },
        "1-output-3": {
          stage: "output",
          title: "Implement PMO Charter and Governance",
          description: "Establish and operationalize PMO charter with defined scope, authority, and governance structure.",
          bestPractices: [
            "Formalize PMO charter with executive approval",
            "Implement governance structure with clear roles",
            "Establish decision-making authorities and processes",
            "Create charter review and update mechanisms"
          ],
          templates: ["PMO Charter Document", "Governance Structure Diagram"]
        },
      },
    },
    "2": {
      name: "Strategic Framework & Governance",
      description: "Creating the optimal PMO structure, roles, and responsibilities to meet organizational needs.",
      tasks: {
        "2-input-1": {
          stage: "input",
          title: "Gather Current State Data",
          description: "Collect data on current project management operations, processes, and performance.",
          bestPractices: [
            "Conduct process documentation review",
            "Gather performance metrics and historical data",
            "Collect stakeholder feedback on current operations",
            "Document existing governance structures"
          ]
        },
        "2-input-2": {
          stage: "input",
          title: "Collect Strategic Alignment Information",
          description: "Gather organizational strategic objectives, priorities, and success criteria.",
          bestPractices: [
            "Review organizational strategic plans",
            "Collect executive leadership priorities",
            "Document business unit objectives",
            "Gather information on strategic initiatives"
          ]
        },
        "2-input-3": {
          stage: "input",
          title: "Identify Capability Requirements",
          description: "Collect data on required capabilities through stakeholder interviews and organizational needs assessment.",
          bestPractices: [
            "Conduct capability needs interviews",
            "Gather industry capability standards",
            "Document capability prioritization criteria",
            "Collect capability maturity benchmarks"
          ]
        },
        "2-processing-1": {
          stage: "processing",
          title: "Apply Mandate Development Methodology",
          description: "Use mandate development techniques to define PMO purpose, authority, and responsibilities.",
          bestPractices: [
            "Apply purpose statement development methods",
            "Use authority mapping techniques",
            "Apply responsibility definition methodologies",
            "Use stakeholder validation approaches"
          ],
          templates: ["PMO Mandate Template", "Executive Sponsorship Agreement"]
        },
        "2-processing-2": {
          stage: "processing",
          title: "Apply Charter Development Framework",
          description: "Use charter development framework to create comprehensive PMO charter with roles and governance structure.",
          bestPractices: [
            "Apply vision and mission statement techniques",
            "Use organizational structure design methods",
            "Apply role definition methodologies",
            "Use governance framework design techniques"
          ],
          templates: ["PMO Charter Template", "Governance Structure Diagram"]
        },
        "2-processing-3": {
          stage: "processing",
          title: "Apply Governance Design Methodology",
          description: "Use governance design techniques to develop decision-making processes and oversight mechanisms.",
          bestPractices: [
            "Apply decision rights mapping techniques",
            "Use escalation path design methods",
            "Apply governance body design methodologies",
            "Use governance communication planning techniques"
          ],
          templates: ["Governance Framework Template", "Decision Rights Matrix"]
        },
        "2-output-1": {
          stage: "output",
          title: "Establish PMO Mandate and Charter",
          description: "Formalize and implement PMO mandate and charter with defined purpose, authority, and responsibilities.",
          bestPractices: [
            "Obtain executive approval for mandate and charter",
            "Communicate mandate to all stakeholders",
            "Implement authority structures defined in charter",
            "Establish charter review and update process"
          ],
          templates: ["Approved PMO Mandate", "Finalized PMO Charter"]
        },
        "2-output-2": {
          stage: "output",
          title: "Implement Governance Framework",
          description: "Establish and operationalize governance framework with decision-making bodies, processes, and oversight mechanisms.",
          bestPractices: [
            "Form governance committees with clear charters",
            "Implement decision-making processes and authorities",
            "Establish governance meeting cadence and agendas",
            "Create governance documentation and reporting system"
          ],
          templates: ["Governance Committee Charter", "Decision Authority Matrix"]
        },
        "2-output-3": {
          stage: "output",
          title: "Develop Strategic Communication Plan",
          description: "Implement comprehensive communication strategy with stakeholder-specific messaging and feedback mechanisms.",
          bestPractices: [
            "Create stakeholder-specific communication materials",
            "Establish regular communication cadence",
            "Implement feedback collection mechanisms",
            "Develop communication effectiveness metrics"
          ],
          templates: ["Strategic Communication Plan", "Stakeholder Messaging Matrix"]
        },      
      }
    },
    "3": {
      name: "PMO Structure & Design",
      description: "Establishing operational processes, KPIs, and performance metrics for the PMO.",
      tasks: {
        "3-input-1": {
          stage: "input",
          title: "Gather Customer Data",
          description: "Collect data on potential PMO customers, their needs, and expectations through surveys and interviews.",
          bestPractices: [
            "Conduct customer needs assessment surveys",
            "Gather stakeholder interview data",
            "Document customer pain points and expectations",
            "Collect service prioritization information"
          ]
        },
        "3-input-2": {
          stage: "input",
          title: "Collect Service Requirement Data",
          description: "Gather detailed requirements for potential PMO services through workshops and requirements sessions.",
          bestPractices: [
            "Conduct service requirements workshops",
            "Document service level expectations",
            "Collect service prioritization criteria",
            "Gather benchmark data on similar services"
          ],
          templates: ["Service Requirements Template", "Customer Needs Assessment"]
        },
        "3-input-3": {
          stage: "input",
          title: "Assess Capability Gaps",
          description: "Collect data on current capabilities and gaps through assessment tools and stakeholder feedback.",
          bestPractices: [
            "Use capability maturity assessment tools",
            "Gather capability benchmark data",
            "Document capability prioritization criteria",
            "Collect resource availability information"
          ]
        },
        "3-processing-1": {
          stage: "processing",
          title: "Apply Persona Development Techniques",
          description: "Use persona development methodologies to create detailed customer personas with needs and expectations.",
          bestPractices: [
            "Apply customer segmentation techniques",
            "Use persona development frameworks",
            "Apply needs analysis methodologies",
            "Use journey mapping techniques"
          ]
        },
        "3-processing-2": {
          stage: "processing",
          title: "Apply Prioritization Frameworks",
          description: "Use prioritization techniques to develop framework for addressing customer needs systematically.",
          bestPractices: [
            "Apply value vs. effort prioritization matrix",
            "Use MoSCoW prioritization technique",
            "Apply weighted scoring methodologies",
            "Use impact mapping techniques"
          ]
        },
        "3-processing-3": {
          stage: "processing",
          title: "Apply Service Catalog Design Methodology",
          description: "Use service catalog design techniques to develop comprehensive service offerings with benefits and advantages.",
          bestPractices: [
            "Apply service definition frameworks",
            "Use service level definition techniques",
            "Apply value proposition development methodologies",
            "Use service categorization techniques"
          ],
          templates: ["Service Catalog Template", "Service Level Agreement Template"]
        },
        "3-output-1": {
          stage: "output",
          title: "Deliver Customer Personas and Journey Maps",
          description: "Create and distribute detailed customer personas and journey maps to guide service design and delivery.",
          bestPractices: [
            "Document comprehensive personas with needs and pain points",
            "Create visual journey maps for key customer interactions",
            "Distribute personas to all service delivery teams",
            "Establish persona update and refinement process"
          ],
          templates: ["Customer Persona Template", "Journey Map Template"]
        },
        "3-output-2": {
          stage: "output",
          title: "Implement Service Catalog and SLAs",
          description: "Launch comprehensive service catalog with service level agreements, processes, and quality standards.",
          bestPractices: [
            "Create detailed service descriptions with value propositions",
            "Establish service level metrics and targets",
            "Implement service request and delivery processes",
            "Create service catalog review and update mechanism"
          ],
          templates: ["Service Catalog Document", "SLA Documentation"]
        },
        "3-output-3": {
          stage: "output",
          title: "Establish Service Prioritization Framework",
          description: "Implement systematic approach for prioritizing and addressing customer needs and service requests.",
          bestPractices: [
            "Create prioritization criteria and scoring system",
            "Implement request intake and evaluation process",
            "Establish resource allocation based on priorities",
            "Develop priority review and adjustment mechanisms"
          ],
          templates: ["Prioritization Matrix", "Service Request Form"]
        },      
      }
    },
    "4": {
      name: "Operational Excellence",
      description: "Ensuring efficient and effective project management processes and tools.",
      tasks: {
        "4-input-1": {
          stage: "input",
          title: "Gather Onboarding Requirements",
          description: "Collect requirements and expectations for customer onboarding process through stakeholder input.",
          bestPractices: [
            "Conduct onboarding needs assessment",
            "Gather stakeholder expectations for onboarding",
            "Document current onboarding challenges",
            "Collect onboarding best practices"
          ]
        },
        "4-input-2": {
          stage: "input",
          title: "Collect Documentation Requirements",
          description: "Gather requirements for process documentation, user guides, and training materials.",
          bestPractices: [
            "Conduct documentation needs assessment",
            "Gather user preferences for documentation formats",
            "Document current documentation gaps",
            "Collect documentation best practices"
          ],
          templates: ["Documentation Requirements Template", "User Guide Outline"]
        },
        "4-input-3": {
          stage: "input",
          title: "Assess Training Needs",
          description: "Collect data on training needs, preferences, and delivery methods through surveys and interviews.",
          bestPractices: [
            "Conduct training needs assessment",
            "Gather learning style preferences",
            "Document knowledge and skill gaps",
            "Collect training effectiveness criteria"
          ]
        },
        "4-processing-1": {
          stage: "processing",
          title: "Apply Quality Management Techniques",
          description: "Use quality management methodologies to develop quality control measures and improvement processes.",
          bestPractices: [
            "Apply quality standards development techniques",
            "Use quality control checkpoint design methods",
            "Apply quality metrics development frameworks",
            "Use continuous improvement methodologies"
          ]
        },
        "4-processing-2": {
          stage: "processing",
          title: "Apply Resource Management Methodologies",
          description: "Use resource management techniques to develop allocation systems and capacity planning processes.",
          bestPractices: [
            "Apply resource capacity planning techniques",
            "Use resource allocation prioritization methods",
            "Apply resource forecasting methodologies",
            "Use resource utilization optimization techniques"
          ],
          templates: ["Resource Management Plan", "Capacity Planning Template"]
        },
        "4-processing-3": {
          stage: "processing",
          title: "Apply Issue Management Framework",
          description: "Use issue management methodologies to develop escalation procedures and resolution processes.",
          bestPractices: [
            "Apply escalation threshold definition techniques",
            "Use escalation path design methods",
            "Apply issue categorization frameworks",
            "Use resolution time standard development techniques"
          ],
          templates: ["Escalation Procedure Template", "Issue Management Framework"]
        },
        "4-output-1": {
          stage: "output",
          title: "Implement Quality Management System",
          description: "Establish comprehensive quality management system with standards, control processes, and improvement mechanisms.",
          bestPractices: [
            "Document quality standards for all services",
            "Implement quality control checkpoints and reviews",
            "Establish quality metrics collection and reporting",
            "Create continuous quality improvement process"
          ],
          templates: ["Quality Standards Document", "Quality Review Checklist"]
        },
        "4-output-2": {
          stage: "output",
          title: "Establish Resource Management System",
          description: "Implement resource management system with capacity planning, allocation processes, and utilization tracking.",
          bestPractices: [
            "Create resource inventory and skills matrix",
            "Implement capacity planning and forecasting process",
            "Establish resource allocation and assignment procedures",
            "Develop resource utilization tracking and reporting"
          ],
          templates: ["Resource Allocation Matrix", "Capacity Planning Dashboard"]
        },
        "4-output-3": {
          stage: "output",
          title: "Deploy Issue Management System",
          description: "Implement comprehensive issue management system with escalation procedures, tracking, and resolution processes.",
          bestPractices: [
            "Establish issue intake and categorization process",
            "Implement escalation paths and notification system",
            "Create issue tracking and status reporting",
            "Develop resolution verification and closure procedures"
          ],
          templates: ["Issue Management Playbook", "Escalation Matrix"]
        },      
      }
    },
    "5": {
      name: "Performance & Improvement",
      description: "Continuously improving PMO services, capabilities, and value delivery.",
      tasks: {
        "5-input-1": {
          stage: "input",
          title: "Gather Maturity Assessment Data",
          description: "Collect data on current PMO maturity through assessment tools, surveys, and stakeholder feedback.",
          bestPractices: [
            "Select appropriate maturity assessment tool",
            "Gather comprehensive assessment data",
            "Document maturity baseline across dimensions",
            "Collect maturity target information"
          ]
        },
        "5-input-2": {
          stage: "input",
          title: "Collect Performance Data",
          description: "Gather current performance metrics, historical trends, and performance targets.",
          bestPractices: [
            "Collect current performance metrics",
            "Gather historical performance data",
            "Document performance targets and thresholds",
            "Collect performance benchmark information"
          ]
        },
        "5-input-3": {
          stage: "input",
          title: "Assess Value Measurement Approaches",
          description: "Collect data on potential value metrics, measurement approaches, and value demonstration methods.",
          bestPractices: [
            "Gather value metric options",
            "Collect value measurement methodologies",
            "Document value perception from stakeholders",
            "Assess current value demonstration approaches"
          ]
        },
        "5-processing-1": {
          stage: "processing",
          title: "Apply Maturity Roadmapping Techniques",
          description: "Use maturity roadmapping methodologies to develop enhancement plan with milestones and metrics.",
          bestPractices: [
            "Apply maturity gap analysis techniques",
            "Use capability prioritization methods",
            "Apply milestone development frameworks",
            "Use metric definition techniques"
          ]
        },
        "5-processing-2": {
          stage: "processing",
          title: "Apply Change Management Methodologies",
          description: "Use change management techniques to develop implementation approach for maturity initiatives.",
          bestPractices: [
            "Apply stakeholder impact analysis techniques",
            "Use resistance management methods",
            "Apply communication planning frameworks",
            "Use adoption measurement techniques"
          ],
          templates: ["Change Management Plan", "Stakeholder Engagement Plan"]
        },
        "5-processing-3": {
          stage: "processing",
          title: "Apply Continuous Improvement Frameworks",
          description: "Use continuous improvement methodologies to develop systematic improvement processes.",
          bestPractices: [
            "Apply improvement opportunity identification techniques",
            "Use improvement prioritization methods",
            "Apply implementation planning frameworks",
            "Use effectiveness measurement techniques"
          ]
        },
        "5-output-1": {
          stage: "output",
          title: "Implement Maturity Enhancement Roadmap",
          description: "Establish and execute comprehensive maturity enhancement roadmap with milestones, metrics, and review processes.",
          bestPractices: [
            "Document detailed maturity enhancement plan",
            "Implement milestone tracking and reporting",
            "Establish maturity metric collection and analysis",
            "Create regular maturity review and adjustment process"
          ],
          templates: ["Maturity Enhancement Roadmap", "Maturity Metrics Dashboard"]
        },
        "5-output-2": {
          stage: "output",
          title: "Establish Value Measurement System",
          description: "Implement comprehensive value measurement system with metrics, reporting, and demonstration mechanisms.",
          bestPractices: [
            "Define and implement value metrics and KPIs",
            "Create value data collection and analysis process",
            "Establish value reporting and visualization",
            "Develop value demonstration case studies"
          ],
          templates: ["Value Measurement Framework", "Value Dashboard"]
        },
        "5-output-3": {
          stage: "output",
          title: "Deploy Continuous Improvement Program",
          description: "Implement systematic continuous improvement program with identification, prioritization, and implementation processes.",
          bestPractices: [
            "Establish improvement opportunity identification process",
            "Create improvement prioritization and selection system",
            "Implement improvement tracking and reporting",
            "Develop improvement effectiveness measurement"
          ],
          templates: ["Continuous Improvement Playbook", "Improvement Tracking System"]
        },      
      }
    },
    "6": {
      name: "Capability Development",
      description: "Developing and managing the human aspects of the PMO including competency, training, and leadership.",
      tasks: {
        "6-input-1": {
          stage: "input",
          title: "Gather Decision-Making Data",
          description: "Collect data on current decision-making processes, data utilization, and improvement opportunities.",
          bestPractices: [
            "Document current decision-making processes",
            "Assess data utilization in decisions",
            "Identify decision-making bottlenecks",
            "Gather decision quality metrics"
          ]
        },
        "6-input-2": {
          stage: "input",
          title: "Assess Competency Requirements",
          description: "Collect data on required competencies, current capabilities, and development needs.",
          bestPractices: [
            "Document role-specific competency requirements",
            "Assess current competency levels",
            "Identify critical competency gaps",
            "Gather development preference information"
          ],
          templates: ["Competency Assessment Template", "Development Needs Analysis"]
        },
        "6-input-3": {
          stage: "input",
          title: "Collect Skills Assessment Data",
          description: "Gather comprehensive skills data through assessments, self-evaluations, and manager feedback.",
          bestPractices: [
            "Use standardized skills assessment tools",
            "Gather self-assessment data",
            "Collect manager assessment input",
            "Document skills prioritization criteria"
          ]
        },
        "6-processing-1": {
          stage: "processing",
          title: "Apply Training Program Design Methodology",
          description: "Use training design techniques to develop comprehensive training and certification programs.",
          bestPractices: [
            "Apply learning objective development techniques",
            "Use curriculum design methodologies",
            "Apply learning modality selection frameworks",
            "Use training effectiveness measurement design"
          ]
        },
        "6-processing-2": {
          stage: "processing",
          title: "Apply Innovation Framework Development",
          description: "Use innovation framework techniques to develop processes for fostering innovation and problem-solving.",
          bestPractices: [
            "Apply innovation process design methodologies",
            "Use idea generation technique selection",
            "Apply idea evaluation framework development",
            "Use innovation incentive system design"
          ]
        },
        "6-processing-3": {
          stage: "processing",
          title: "Apply Knowledge Management Techniques",
          description: "Use knowledge management methodologies to design knowledge-sharing platform and communities of practice.",
          bestPractices: [
            "Apply knowledge repository design techniques",
            "Use knowledge categorization frameworks",
            "Apply community of practice design methodologies",
            "Use knowledge contribution incentive design"
          ]
        },
        "6-output-1": {
          stage: "output",
          title: "Implement Competency Development Framework",
          description: "Establish comprehensive competency framework with assessment, development paths, and certification programs.",
          bestPractices: [
            "Document role-specific competency requirements",
            "Create competency assessment and tracking system",
            "Implement development paths for each competency area",
            "Establish certification and recognition program"
          ],
          templates: ["Competency Framework Document", "Development Path Guide"]
        },
        "6-output-2": {
          stage: "output",
          title: "Deploy Innovation and Problem-Solving System",
          description: "Implement structured innovation program with idea generation, evaluation, and implementation processes.",
          bestPractices: [
            "Establish idea generation and collection system",
            "Create idea evaluation and selection process",
            "Implement innovation implementation support",
            "Develop innovation recognition and incentives"
          ],
          templates: ["Innovation Process Playbook", "Idea Evaluation Matrix"]
        },
        "6-output-3": {
          stage: "output",
          title: "Establish Knowledge Management System",
          description: "Implement comprehensive knowledge management system with repository, sharing mechanisms, and communities of practice.",
          bestPractices: [
            "Create knowledge repository with categorization system",
            "Establish knowledge contribution processes",
            "Form communities of practice with clear charters",
            "Implement knowledge sharing events and activities"
          ],
          templates: ["Knowledge Management Guide", "Community of Practice Charter"]
        }
      }
    }
  },

  // Tasks
  tasks: {
    tasks: "Tasks",
    manageAndTrackYourPmoImplementationTasks: "Manage and track your PMO implementation tasks",
    allTasks: "All Tasks",
    completed: "Completed",
    incomplete: "Incomplete",
    progress: "Progress",
    total: "Total",
    rate: "Rate",
    addCustomTask: "Add Custom Task",
    searchTasks: "Search tasks...",
    filters: "Filters",
    clear: "Clear",
    allDomains: "All Domains",
    allStages: "All Stages",
    input: "Input",
    processing: "Processing",
    output: "Output",
    domain: "Domain",
    stage: "Stage",
    status: "Status",
    clearFilters: "Clear Filters",
    noTasksFound: "No tasks found",
    noTasksMatchFilters: "No tasks match your current filters. Try adjusting or clearing your filters.",
    noTasksAvailable: "No tasks available. Start by creating a new task.",
    taskManagementTips: "Task Management Tips",
    taskManagementTipsDescription: "Prioritize tasks based on your PMO maturity level and organizational goals. Complete the Input stage tasks first before moving to Processing and Output stages for the best results.",
    viewBestPractices: "View Best Practices",
    relatedDocuments: "Related Documents",
    viewFullContent: "View Full Content",
    generateTaskOutput: "Generate Task Output",
    templates: "Templates",
    templateForStandardizedImplementation: "Template for standardized implementation",
    viewTemplate: "View Template",
    bestPractices: "Best Practices",
    priority: "Priority",
    targetCompletionDate: "Target Completion Date",
    assignedTo: "Assigned To",
    estimatedHours: "Estimated Hours",
    attachments: "Attachments",
    notes: "Notes",
    availableTemplates: "Available Templates",
    purpose: "Purpose",
    templateForStandardized: "This template provides a structured framework for implementing and managing",
    withinYourPMO: "processes within your PMO",
    overview: "Overview",
    download: "Download",
    useTemplate: "Use Template",
    close: "Close",
    save:"Save",
    template: `
## Template Sections

### 1. Introduction
- Purpose and objectives
- Scope and applicability
- Key stakeholders

### 2. Process Framework
- Methodology overview
- Key activities and deliverables
- Roles and responsibilities

### 3. Implementation Guide
- Step-by-step instructions
- Best practices and guidelines
- Common challenges and solutions

### 4. Monitoring and Control
- Key performance indicators
- Quality assurance measures
- Reporting requirements

### 5. Continuous Improvement
- Feedback mechanisms
- Review process
- Update procedures

## Appendices
- Related templates and tools
- Reference materials
- Glossary of terms

---

*This template is part of the PMO Builder library. Customize it to fit your organization's specific needs.*`,
  }
};

// Translation keys organized by component/page
// English translations
const en = {
  // Common components
  common: {
    pleaseWait: "Please wait while we prepare your content.",
    Complete : "Complete",
    search: "Search",
    save: "Save",
    saveAssessment: "Save Assessment",
    saved: "Saved!",
    showLess: "Show less",
    showMore: "Show more",
    cancel: "Cancel",
    edit: "Edit",
    delete: "Delete",
    close: "Close",
    loading: "Loading...",
    submit: "Submit",
    active: "Active",
    back: "Back",
    spent: "Spent",
    used: "Used",
    onTrack: "On Track",
    viewDetails: "View Details",
    tasks: "Tasks",
    domains: "Domains",
    budget: "Budget",
    daysLeft: "days left",
    next: "Next",
    progress: "Progress",
    notifications: "Notifications",
    help: "Help",
    settings: "Settings",
    profile: "Profile",
    signOut: "Sign Out",
    dashboard: "Dashboard",
    export: "Export",
    import: "Import",
    share: "Share",
    days: "days",
    darkMode: "Dark Mode",
    lightMode: "Light Mode",
    confirm: "Confirm",
    remainingTokens: "Remaining Tokens"
  },
  
  // Header component
  header: {
    search: "Search...",
    myTeams: "My Teams",
    invitations: "Invitations",
    setupProfile: "Setup Profile",
    subscription: "Subscription",
    settings: "Settings",
    adminPanel: "Admin Panel",
    signOut: "Sign out",
    profile: "Profile",
  },
  
  // Dashboard page
  dashboard: {
    title: "Dashboard",
    subtitle: "Build and track your PMO across all essential domains",
    budget: "Budget",
    editDetails: "Edit Details",
    exportReport: "Export Report",
    access: "Access",
    timelineProgress: "Timeline Progress",
    budgetUtilization: "Budget Utilization",
    projectStatus: "Project Status",
    maturityAssessment: "Maturity Assessment",
    keyObjectives: "Key Objectives",
    stakeholders: "Stakeholders",
    overallProgress: "Overall Progress",
    completedTasks: "Completed Tasks",
    domainProcessComparison:"Domain Progress Comparison",
    organization: "Organization",
    industry: "Industry",
    dashboardCustomization: "Dashboard Customization",
    displayLayout: "Display Layout",
    gridView: "Grid View",
    listView: "List View",
    widgetSelection: "Widget Selection",
    assessMaturityLevel: "Assess Your Maturity Level",
    maturityLevel: "Maturity Level",
    progressOverview: "Progress Overview",
    tasksStatus: "Tasks Status",
    domains: "Domains",
    chartsAnalytics: "Charts & Analytics",
    pmoMaturityLevel: "PMO Maturity Level",
    pmoDomains: "PMO Domains",
    aiAnalysis: "Accelerate with AI",
    aiDescription: "Let our advanced AI analyze your PMO data and generate comprehensive recommendations tailored to your organization's unique needs.",
    tryAiAnalysis: "Try AI Analysis",
    viewAll: "View all",
    of: "of",
    tasksCompleted: "tasks completed",
    notSet: "Not set",
    updateProfile: "Update profile",
    viewAllTasks: "View all tasks",
    nextSteps: "Next Steps",
    uploadDocuments: "Upload documents",
    analysisDocuments: "Upload supporting documents for AI analysis",
    analysisDocumentsDesc: "Enhance AI recommendations with your organization's context",
    completePmoMaturityAssessment: "Complete a PMO Maturity Assessment",
    getInsightsAboutPmoMaturityLevel: "Get insights about your PMO's current maturity level",
    reviewPractices: "Review best practices",
    explorePractices: "Explore the best practices library for guidance",
    viewResources: "View resources",
    goToAssessment: "Go to assessment",
    objective1: "Establish PMO governance framework",
    objective2: "Develop standard methodologies",
    objective3: "Implement performance metrics",
    sampleProject: "Sample PMO Implementation",
    sampleDescription: "A sample project with pre-populated data for demonstration",
    createFirstProject: "Create Your First PMO Project",
    firstProjectDesc: "Get started by creating your first PMO implementation project. You can set up project details, track progress across domains, and generate AI-powered recommendations.",
    createSample: "Create Sample Project",
    aiFeature1: "Custom templates based on your current maturity level",
    aiFeature2: "Detailed implementation roadmaps for each domain",
    aiFeature3: "Best practices tailored to your industry and context",
    maturityRadarChart: "Maturity Radar Chart",
    higherValuesIndicateGreaterMaturity: "Higher values indicate greater maturity",
    pmoMaturityAssessment: "PMO Maturity Assessment",
    assessPmoMaturity: "Assess your PMO's maturity level across all domains to identify strengths and improvement opportunities",
    selfAssessment: "Self-Assessment",
    aiGeneratedAssessment: "AI-Generated Assessment",
    notSpecified: "Not specified",
    currentMaturityProfile: "Current Maturity Profile",
    organizationDetails: "Organization Details",
    assessmentType: "Assessment Type",
    currentMaturityProfileDescription: "Your organization's PMO is currently at the",
    currentMaturityProfileDescription2: "level. This assessment will help you identify areas for improvement and create a roadmap for advancing your PMO capabilities.",
    assessmentDate: "Assessment Date",
    selfAssessmentQuestionnaire: "Self-Assessment Questionnaire",
    selfAssessmentDescription: "Rate your PMO's maturity level for each domain. Consider your processes, documentation, measurement capabilities, and continuous improvement efforts when making your assessment.",
    documentation: "Documentation",
    metrics: "Metrics",
    minimalToNone: "Minimal to none",
    basicDocumentation: "Basic documentation",
    comprehensiveDocumentation: "Comprehensive",
    regularlyUpdated: "Regularly updated",
    leadingPractice: "Leading practice",
    adHocOrNone: "Ad-hoc or none",
    basicTracking: "Basic tracking",
    notes: "Notes (Optional)",
    notesPlaceholder: "Add any notes or context about your assessment...",
    createNew: "Create New Project",
    generateAIAssessment: "Generate an AI Assessment",
    aiAssessmentDescription: "Our AI will analyze your domain inputs, project data, and uploaded documents to provide an objective assessment of your PMO's maturity across all domains.",
    aiAssessmentSummary: "AI Assessment Summary",
    aiAssessmentSummaryDescription: "Based on our analysis, your PMO is currently at the",
    keyStrengths: "Key Strengths",
    areasForImprovement: "Areas for Improvement",
    domainSpecificAssessment: "Domain-Specific Assessment",
    maturityProgression: "Maturity Progression",
    recommendations: "Recommendations",
    generatingReport: "Generating Report...",
    exportAssessmentReport: "Export Assessment Report",
    detailedMaturityGuide: "Detailed Maturity Guide",
    maturityModelReference: "Maturity Model Reference",
    generateAssessment: "Generate Assessment",
    generatingAssessment: "Generating Assessment...",
    generatingAssessmentDescription: "Our AI is analyzing your PMO data across all domains. This may take a few moments.",
    
  },
  
  // Domain detail page
  domain: {
    BestPractices: "Best Practices",
    backToDashboard: "Back to Dashboard",
    prevDomain: "Previous Domain",
    nextDomain: "Next Domain",
    viewDomain: "View Domain",
    progress: "Progress",
    tasks: "Tasks & Progress",
    input: "Domain Input & Analysis",
    analyzing: "Analyzing Domain Input",
    processingData: "Our AI is processing your input data...",
    inputStage: "Input",
    inputDesc: "Collect data, assess current state, and gather requirements for this domain.",
    processingStage: "Processing",
    processingDesc: "Analyze data, develop frameworks, and design solutions for this domain.",
    outputStage: "Output",
    outputDesc: "Create deliverables, implement solutions, and establish frameworks for this domain.",
    loading: "Loading domain data...",
    notFound: "Domain not found",
    provideInputFirst: "Please provide domain input data before analyzing",
    aiGeneratedAnalysis: "AI-Generated Analysis for",
    generated: "Generated",
    analysis: "Analysis",
    domainProgress: "Domain Progress (%)",
    templates: "Templates",
    downloadMarkdown: "Download Markdown",
    downloadPdf: "Download PDF",
    generatingPdf: "Generating PDF...",
    generating: "Generating...",
    allTemplates: "All Available Templates",
    markdownFormat: "Markdown",
    words: "words",
    usingTemplates: "Using These Templates",
    templateDescription: "These templates are available in Markdown and PDF formats. Markdown can be imported into document editors, project management tools, or converted to other formats. PDF files are ready for printing or sharing with stakeholders.",
    noTemplates: "No templates available for this domain",
    aiConfigTitle: "AI Analysis Configuration",
    selectDomainPrompt: "Select a domain to analyze with our advanced AI. The analysis will generate comprehensive recommendations and templates based on your organization's specific context.",
    selectDomain: "Select Domain",
    analysisDepth: "Analysis Depth",
    basic: "Basic",
    quickOverview: "Quick overview",
    standard: "Standard",
    balancedAnalysis: "Balanced analysis",
    detailed: "Detailed",
    inDepthReview: "In-depth review",
    comprehensive: "Comprehensive",
    maximumDetail: "Maximum detail",
    geminiPowered: "Gemini AI Powered Analysis",
    advancedAiDesc: "Advanced AI will analyze your inputs and generate tailored recommendations",
    startAnalysis: "Start Analysis"
  },
  
  // Project management
  project: {
    projectName: "Project Name",
    projectNamePlaceholder: "Enterprise PMO Implementation",
    description: "Description",
    descriptionPlaceholder: "Brief description of your PMO implementation project",
    budget: "Budget",
    yourProjects: "Your Projects",
    createProject: "Create Project"
  },
  
  // Sidebar
  sidebar: {
    dashboard: "Dashboard",
    pmoDomains: "PMO Domains",
    tools: "Tools & Assessment",
    resources: "Resources",
    tasks: "Tasks",
    bestPractices: "Best Practices",
    maturityAssessment: "Maturity Assessment",
    assessment: "Assessment",
  },
  
  // Auth pages
  auth: {
    copyright: "© 2025 PMO Builder using AI by Dr. Ahmed Alsenosy"
  },
  
  // Maturity levels
  maturityLevels: {
    initial: {
      label: 'Initial',
      description: 'Processes are ad hoc and chaotic.'
    },
    defined: {
      label: 'Defined',
      description: 'Processes are documented and standardized.'
    },
    managed: {
      label: 'Managed',
      description: 'Processes are measured and controlled.'
    },
    optimized: {
      label: 'Optimized',
      description: 'Focus on continuous improvement.'
    },
    innovative: {
      label: 'Innovative',
      description: 'Driving industry innovation and adaptation.'
    }
  },

  //profile page
  profile: {
    title: "Organization Profile",
    description: "Set up your organization details to personalize your PMO journey",
    organizationName: "Organization Name",
    organizationNamePlaceholder: "Enter your organization name",
    industry: "Industry",
    industryPlaceholder: "Enter your industry",
    pmoMaturityLevel: "PMO Maturity Level",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "Select the maturity level that best describes your current PMO",
    saveProfile: "Save Profile",
    cancel: "Cancel",
    initial: "Initial - Ad hoc processes",
    defined: "Defined - Basic processes established",
    managed: "Managed - Standardized processes",
    optimized: "Optimized - Continuously improving",
    notEstablished: "Not Established - No formal PMO",
  },
  
  //settings page
  settings: {
    title: "Settings",
    description: "Manage your account settings and preferences",
    personal: "Personal",
    subscription: "Subscription",
    notifications: "Notifications",
    security: "Security",
    data: "Data",
    saveProfile: "Save Profile",
    cancel: "Cancel",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "Select the maturity level that best describes your current PMO",
    organizationName: "Organization Name",
    organizationNamePlaceholder: "Enter your organization name",
    industry: "Industry",
    industryPlaceholder: "Enter your industry",
    pmoMaturityLevel: "PMO Maturity Level",
    notEstablished: "Not Established - No formal PMO",
    initial: "Initial - Ad hoc processes",
    defined: "Defined - Basic processes established",
    managed: "Managed - Standardized processes",
    optimized: "Optimized - Continuously improving",
  },

  // Resources page
  resources: {
    title: "Resources",
    noDocuments: "No documents available",
    errorLoading: "Error loading documents",
    downloadError: "Error downloading document",
    uploadNew: "Upload New Document",
    filter: "Filter Documents",
    sortBy: "Sort By",
    search: "Search Documents",
    lastModified: "Last Modified",
    fileName: "File Name",
    fileSize: "File Size",
    taskName: "Task Name",
    projectId: "Project ID"
  },
 // Help page
  help: {
    title: "Help & Support",
    description: "Learn how to use the PMO Domains Application Tool effectively",
    gettingStarted: "Getting Started",
    whatIsPmoDomainsTool: "What is the PMO Domains Tool?",
    whatIsPmoDomainsToolDescription: `The PMO Domains Application Tool helps PMO professionals apply and monitor the five key PMO domains using a structured "Inputs – Processing – Outputs" framework. The tool guides you through each domain's tasks, ensuring best practices and benchmarking against industry standards.`, 
    howToUseThisTool: "How to Use This Tool",
    howToUseThisToolDescription: "The PMO Domains Application Tool is a web-based application that helps organizations implement and improve their PMO capabilities across all domains.",
    canIExportMyData: "Can I export my data?",
    canIExportMyDataDescription: "Yes, you can export your data from the Settings page. This allows you to back up your progress or transfer it to another system.",
    canICustomizeTheToolForMyOrganization: "Can I customize the tool for my organization?",
    canICustomizeTheToolForMyOrganizationDescription: "The tool is designed to be applicable across different organizations and industries. You can add custom notes to each task to tailor it to your specific organizational context.",
    whatIfINotReadyToCompleteAllDomains: "What if I'm not ready to complete all domains?",
    whatIfINotReadyToCompleteAllDomainsDescription: "You can work on domains in any order that makes sense for your organization. The tool will track your progress across all domains, allowing you to focus on your priorities.",
    contactSupport: "Contact Support",
    contactSupportDescription: "If you need additional help or have questions about the PMO Domains Application Tool, please contact our support team.",
    supportContact: "Support Contact",
    supportContactEmail: "Email: support@pmobuilder.ai",
    supportContactPhone: "Phone: (555) 123-4567",
    supportContactHours: "Hours: Monday-Friday, 9am-5pm EST",
    startBySettingUpYourOrganizationProfile: "Start by setting up your organization profile in the Profile section",
    navigateToEachDomainUsingTheSidebarMenu: "Navigate to each domain using the sidebar menu",
    completeTasksInTheRecommendedOrder: "Complete tasks in the recommended order: Input → Processing → Output",
    markTasksAsCompleteAsYouProgress: "Mark tasks as complete as you progress",
    useTheDashboardToTrackYourOverallProgress: "Use the dashboard to track your overall progress",
    referToTheBestPracticesLibraryForGuidance: "Refer to the Best Practices Library for guidance",
    organizationalDevelopmentAndAlignment: "1. Organizational Development and Alignment",
    organizationalDevelopmentAndAlignmentDescription: "This domain focuses on aligning the PMO with organizational strategy and culture to ensure effective project management practices. It includes organizational assessment, stakeholder analysis, and developing alignment strategies.",
    strategicElementsOfThePmo: "2. Strategic Elements of the PMO",
    strategicElementsOfThePmoDescription: "This domain involves developing and implementing strategic frameworks, roadmaps, and governance structures. It includes strategic objectives review, portfolio analysis, and governance structure design.",
    pMODesignAndStructuring: "3. PMO Design and Structuring",
    pMODesignAndStructuringDescription: "This domain focuses on creating the optimal PMO structure, roles, and responsibilities to meet organizational needs. It includes requirements gathering, resource assessment, and service catalog development.",
    pMOOperationAndPerformance: "4. PMO Operation and Performance",
    pMOOperationAndPerformanceDescription: "This domain establishes operational processes, KPIs, and performance metrics for the PMO. It includes process assessment, performance metrics identification, and performance measurement systems.",
    pMOEnhancementAndEffectiveness: "5. PMO Enhancement and Effectiveness",
    pMOEnhancementAndEffectivenessDescription: "This domain focuses on continuously improving PMO services, capabilities, and value delivery. It includes maturity assessment, value delivery analysis, and continuous improvement planning.",
    frequentlyAskedQuestions: "Frequently Asked Questions",
    frequentlyAskedQuestionsDescription: "The PMO Domains Application Tool is a web-based application that helps organizations implement and improve their PMO capabilities across all domains.",
    howToAccessTemplates: "How do I access templates?",
    howToAccessTemplatesDescription: "Templates are available within specific tasks that have template resources. You can also find a collection of templates in the Best Practices Library",
    understandingTheFiveDomains: "Understanding the Five Domains",
  },
    
  subscription: {
    title: "Subscription Management",
    currentPlan: "Current Plan",
    trial: "Trial",
    cancelsAtPeriodEnd: "Cancels at period end",
    upgradePlan: "Upgrade Plan",
    manageSubscription: "Manage Subscription",
    processing: "Processing...",
    billingPeriod: "Billing Period",
    nextBillingDate: "Next Billing Date",
    paymentMethod: "Payment Method",
    projects: "Projects",
    aiAnalysis: "AI Analysis",
    storage: "Storage",
    freePlanLimitations: "Free plan limitations",
    freePlanLimitationsDescription: "You're currently on the Free plan, which has limitations on projects, AI analyses, and storage. Upgrade to Premium or Enterprise for increased limits and additional features.",
    upgradeNow: "Upgrade Now",
    upgradeToGetMore: "Upgrade to Get More",
    premiumPlanBenefits: "Premium Plan Benefits",
    upTo20Projects: "Up to 20 projects (vs. 3 on Free)",
    upTo100AiAnalyses: "100 AI analyses per month (vs. 3 on Free)",
    teamCollaboration: "Team collaboration with up to 5 users",
    prioritySupport: "Priority support",
    enterprisePlanBenefits: "Enterprise Plan Benefits",
    unlimitedProjectsAndAiAnalyses: "Unlimited projects and AI analyses",
    unlimitedTeamMembers: "Unlimited team members",
    whiteLabelingOptions: "White-labeling options",
    dedicatedSupport: "Dedicated support",
    upgradeToEnterprise: "Upgrade to Enterprise",
    unlimited: "Unlimited",
    unknown: "Unknown",
    free: "Free",
    premium: "Premium",
    enterprise: "Enterprise",
    usageAndLimits: "Usage & Limits",
    perMonth: "per month",
    mb: "MB",
    none: "None",
    creditCard: "Credit Card",
    paypal: "PayPal",
    notAvailable: "Not available",
  },
  
  //notifications
  notifications: {
    '1': {
      title: "PMO Maturity Assessment Due",
      description: "Complete your quarterly PMO maturity assessment by Friday.",
      time: "2 days ago",
    },
    '2': {
      title: "Strategic Elements Domain Updated",
      description: "New templates and resources have been added to the Strategic Elements domain.",
      time: "3 days ago",
    },
    '3': {
      title: "Team Meeting: PMO Enhancement",
      description: "Upcoming team meeting to discuss PMO Enhancement strategies.",
      time: "Tomorrow, 10:00 AM",
    },
    '4': {
      title: "New Message from Admin",
      description: "You have a new message regarding your Organization Development domain progress.",
      time: "1 week ago",
    },
    '5': {
      title: "Data Backup Complete",
      description: "Your PMO data has been successfully backed up to cloud storage.",
      time: "2 weeks ago",
    },
    title: "Notifications",
    description: "Stay updated with your PMO activities and important alerts",
    markAllAsRead: "Mark all as read",
    clearAll: "Clear all",
    markAllAsReadDescription: "Mark all notifications as read",
    clearAllDescription: "Clear all notifications",
    markAllAsReadButton: "Mark all as read",
    clearAllButton: "Clear all",
    unread: "Unread",
    all: "All",
    recentNotifications: "Recent Notifications",
    markAsUnread: "Mark as unread",
    markAsRead: "Mark as read",
    viewDetails: "View details",
    loadMore: "Load more notifications",
    customizeNotifications: "Customize how and when you receive notifications about your PMO activities",
    notificationPreferences: "Notification Preferences",
    managePreferences: "Manage Preferences",
    

  },
  // Domain names
  domains: {
    "1": {
      name: "Organizational Development and Alignment",
      description: "Aligning the PMO with organizational strategy and culture to ensure effective project management practices.",
      tasks: {
        "1-input-1": {
          stage: "input",
          title: "Assess Current Competencies",
          description: "Gather data on existing competencies through surveys, interviews, and documentation review.",
          bestPractices: [
            "Use standardized assessment tools to evaluate current competencies",
            "Collect input from multiple organizational levels",
            "Document both technical and soft skill competencies",
            "Identify competency gaps through structured assessment"
          ]
        },
        "1-input-2": {
          stage: "input",
          title: "Assess Organizational Culture",
          description: "Collect data on current organizational culture through surveys, focus groups, and stakeholder interviews.",
          bestPractices: [
            "Conduct culture assessment surveys",
            "Gather feedback from diverse organizational levels",
            "Document cultural enablers and barriers to project management",
            "Collect historical data on cultural change initiatives"
          ]
        },
        "1-input-3": {
          stage: "input",
          title: "Benchmark Against Industry Standards",
          description: "Collect industry benchmarking data and best practices for organizational alignment.",
          bestPractices: [
            "Select relevant industry benchmarks and standards",
            "Gather data from industry reports and publications",
            "Document peer organization practices",
            "Collect metrics for comparative analysis"
          ]
        },
        "1-processing-1": {
          stage: "processing",
          title: "Apply Strategic Analysis Techniques",
          description: "Use strategic analysis tools to develop an integrated strategy with risk management and implementation roadmap.",
          bestPractices: [
            "Apply SWOT analysis to identify strengths and weaknesses",
            "Use gap analysis to identify improvement areas",
            "Apply risk assessment methodologies",
            "Use roadmapping techniques for implementation planning"
          ]
        },
        "1-processing-2": {
          stage: "processing",
          title: "Apply Communication Planning Methodologies",
          description: "Use communication planning techniques to develop stakeholder-specific messaging and feedback mechanisms.",
          bestPractices: [
            "Apply stakeholder analysis techniques",
            "Use communication matrix development methods",
            "Apply message tailoring methodologies",
            "Use KPI development frameworks for communication effectiveness"
          ]
        },
        "1-processing-3": {
          stage: "processing",
          title: "Apply Charter Development Techniques",
          description: "Use charter development methodologies to define PMO scope, authority, and governance structure.",
          bestPractices: [
            "Apply scope definition techniques",
            "Use RACI matrix development methods",
            "Apply governance framework design methodologies",
            "Use authority mapping techniques"
          ],
          templates: ["PMO Charter Template", "RACI Matrix"]
        },
        "1-output-1": {
          stage: "output",
          title: "Deliver Integrated Strategy and Roadmap",
          description: "Produce and implement the integrated strategy with risk management plan and phased implementation roadmap.",
          bestPractices: [
            "Document comprehensive strategy with clear objectives",
            "Create detailed implementation roadmap with milestones",
            "Develop risk management plan with mitigation strategies",
            "Establish strategy review and update mechanisms"
          ]
        },
        "1-output-2": {
          stage: "output",
          title: "Establish PMO Vision, Values and Culture",
          description: "Implement vision statement, core values, and cultural change program with leadership engagement.",
          bestPractices: [
            "Create compelling vision statement aligned with organization",
            "Document core values with behavioral examples",
            "Implement leadership engagement activities",
            "Establish cultural reinforcement mechanisms"
          ],
          templates: ["PMO Vision Statement Template", "Cultural Change Roadmap"]
        },
        "1-output-3": {
          stage: "output",
          title: "Implement PMO Charter and Governance",
          description: "Establish and operationalize PMO charter with defined scope, authority, and governance structure.",
          bestPractices: [
            "Formalize PMO charter with executive approval",
            "Implement governance structure with clear roles",
            "Establish decision-making authorities and processes",
            "Create charter review and update mechanisms"
          ],
          templates: ["PMO Charter Document", "Governance Structure Diagram"]
        },
      },
    },
    "2": {
      name: "Strategic Framework & Governance",
      description: "Creating the optimal PMO structure, roles, and responsibilities to meet organizational needs.",
      tasks: {
        "2-input-1": {
          stage: "input",
          title: "Gather Current State Data",
          description: "Collect data on current project management operations, processes, and performance.",
          bestPractices: [
            "Conduct process documentation review",
            "Gather performance metrics and historical data",
            "Collect stakeholder feedback on current operations",
            "Document existing governance structures"
          ]
        },
        "2-input-2": {
          stage: "input",
          title: "Collect Strategic Alignment Information",
          description: "Gather organizational strategic objectives, priorities, and success criteria.",
          bestPractices: [
            "Review organizational strategic plans",
            "Collect executive leadership priorities",
            "Document business unit objectives",
            "Gather information on strategic initiatives"
          ]
        },
        "2-input-3": {
          stage: "input",
          title: "Identify Capability Requirements",
          description: "Collect data on required capabilities through stakeholder interviews and organizational needs assessment.",
          bestPractices: [
            "Conduct capability needs interviews",
            "Gather industry capability standards",
            "Document capability prioritization criteria",
            "Collect capability maturity benchmarks"
          ]
        },
        "2-processing-1": {
          stage: "processing",
          title: "Apply Mandate Development Methodology",
          description: "Use mandate development techniques to define PMO purpose, authority, and responsibilities.",
          bestPractices: [
            "Apply purpose statement development methods",
            "Use authority mapping techniques",
            "Apply responsibility definition methodologies",
            "Use stakeholder validation approaches"
          ],
          templates: ["PMO Mandate Template", "Executive Sponsorship Agreement"]
        },
        "2-processing-2": {
          stage: "processing",
          title: "Apply Charter Development Framework",
          description: "Use charter development framework to create comprehensive PMO charter with roles and governance structure.",
          bestPractices: [
            "Apply vision and mission statement techniques",
            "Use organizational structure design methods",
            "Apply role definition methodologies",
            "Use governance framework design techniques"
          ],
          templates: ["PMO Charter Template", "Governance Structure Diagram"]
        },
        "2-processing-3": {
          stage: "processing",
          title: "Apply Governance Design Methodology",
          description: "Use governance design techniques to develop decision-making processes and oversight mechanisms.",
          bestPractices: [
            "Apply decision rights mapping techniques",
            "Use escalation path design methods",
            "Apply governance body design methodologies",
            "Use governance communication planning techniques"
          ],
          templates: ["Governance Framework Template", "Decision Rights Matrix"]
        },
        "2-output-1": {
          stage: "output",
          title: "Establish PMO Mandate and Charter",
          description: "Formalize and implement PMO mandate and charter with defined purpose, authority, and responsibilities.",
          bestPractices: [
            "Obtain executive approval for mandate and charter",
            "Communicate mandate to all stakeholders",
            "Implement authority structures defined in charter",
            "Establish charter review and update process"
          ],
          templates: ["Approved PMO Mandate", "Finalized PMO Charter"]
        },
        "2-output-2": {
          stage: "output",
          title: "Implement Governance Framework",
          description: "Establish and operationalize governance framework with decision-making bodies, processes, and oversight mechanisms.",
          bestPractices: [
            "Form governance committees with clear charters",
            "Implement decision-making processes and authorities",
            "Establish governance meeting cadence and agendas",
            "Create governance documentation and reporting system"
          ],
          templates: ["Governance Committee Charter", "Decision Authority Matrix"]
        },
        "2-output-3": {
          stage: "output",
          title: "Develop Strategic Communication Plan",
          description: "Implement comprehensive communication strategy with stakeholder-specific messaging and feedback mechanisms.",
          bestPractices: [
            "Create stakeholder-specific communication materials",
            "Establish regular communication cadence",
            "Implement feedback collection mechanisms",
            "Develop communication effectiveness metrics"
          ],
          templates: ["Strategic Communication Plan", "Stakeholder Messaging Matrix"]
        },      
      }
    },
    "3": {
      name: "PMO Structure & Design",
      description: "Establishing operational processes, KPIs, and performance metrics for the PMO.",
      tasks: {
        "3-input-1": {
          stage: "input",
          title: "Gather Customer Data",
          description: "Collect data on potential PMO customers, their needs, and expectations through surveys and interviews.",
          bestPractices: [
            "Conduct customer needs assessment surveys",
            "Gather stakeholder interview data",
            "Document customer pain points and expectations",
            "Collect service prioritization information"
          ]
        },
        "3-input-2": {
          stage: "input",
          title: "Collect Service Requirement Data",
          description: "Gather detailed requirements for potential PMO services through workshops and requirements sessions.",
          bestPractices: [
            "Conduct service requirements workshops",
            "Document service level expectations",
            "Collect service prioritization criteria",
            "Gather benchmark data on similar services"
          ],
          templates: ["Service Requirements Template", "Customer Needs Assessment"]
        },
        "3-input-3": {
          stage: "input",
          title: "Assess Capability Gaps",
          description: "Collect data on current capabilities and gaps through assessment tools and stakeholder feedback.",
          bestPractices: [
            "Use capability maturity assessment tools",
            "Gather capability benchmark data",
            "Document capability prioritization criteria",
            "Collect resource availability information"
          ]
        },
        "3-processing-1": {
          stage: "processing",
          title: "Apply Persona Development Techniques",
          description: "Use persona development methodologies to create detailed customer personas with needs and expectations.",
          bestPractices: [
            "Apply customer segmentation techniques",
            "Use persona development frameworks",
            "Apply needs analysis methodologies",
            "Use journey mapping techniques"
          ]
        },
        "3-processing-2": {
          stage: "processing",
          title: "Apply Prioritization Frameworks",
          description: "Use prioritization techniques to develop framework for addressing customer needs systematically.",
          bestPractices: [
            "Apply value vs. effort prioritization matrix",
            "Use MoSCoW prioritization technique",
            "Apply weighted scoring methodologies",
            "Use impact mapping techniques"
          ]
        },
        "3-processing-3": {
          stage: "processing",
          title: "Apply Service Catalog Design Methodology",
          description: "Use service catalog design techniques to develop comprehensive service offerings with benefits and advantages.",
          bestPractices: [
            "Apply service definition frameworks",
            "Use service level definition techniques",
            "Apply value proposition development methodologies",
            "Use service categorization techniques"
          ],
          templates: ["Service Catalog Template", "Service Level Agreement Template"]
        },
        "3-output-1": {
          stage: "output",
          title: "Deliver Customer Personas and Journey Maps",
          description: "Create and distribute detailed customer personas and journey maps to guide service design and delivery.",
          bestPractices: [
            "Document comprehensive personas with needs and pain points",
            "Create visual journey maps for key customer interactions",
            "Distribute personas to all service delivery teams",
            "Establish persona update and refinement process"
          ],
          templates: ["Customer Persona Template", "Journey Map Template"]
        },
        "3-output-2": {
          stage: "output",
          title: "Implement Service Catalog and SLAs",
          description: "Launch comprehensive service catalog with service level agreements, processes, and quality standards.",
          bestPractices: [
            "Create detailed service descriptions with value propositions",
            "Establish service level metrics and targets",
            "Implement service request and delivery processes",
            "Create service catalog review and update mechanism"
          ],
          templates: ["Service Catalog Document", "SLA Documentation"]
        },
        "3-output-3": {
          stage: "output",
          title: "Establish Service Prioritization Framework",
          description: "Implement systematic approach for prioritizing and addressing customer needs and service requests.",
          bestPractices: [
            "Create prioritization criteria and scoring system",
            "Implement request intake and evaluation process",
            "Establish resource allocation based on priorities",
            "Develop priority review and adjustment mechanisms"
          ],
          templates: ["Prioritization Matrix", "Service Request Form"]
        },      
      }
// Translation keys organized by component/page
// English translations
const en = {
  // Common components
  common: {
    pleaseWait: "Please wait while we prepare your content.",
    Complete : "Complete",
    search: "Search",
    save: "Save",
    saveAssessment: "Save Assessment",
    saved: "Saved!",
    showLess: "Show less",
    showMore: "Show more",
    cancel: "Cancel",
    edit: "Edit",
    delete: "Delete",
    close: "Close",
    loading: "Loading...",
    submit: "Submit",
    active: "Active",
    back: "Back",
    spent: "Spent",
    used: "Used",
    onTrack: "On Track",
    viewDetails: "View Details",
    tasks: "Tasks",
    domains: "Domains",
    budget: "Budget",
    daysLeft: "days left",
    next: "Next",
    progress: "Progress",
    notifications: "Notifications",
    help: "Help",
    settings: "Settings",
    profile: "Profile",
    signOut: "Sign Out",
    dashboard: "Dashboard",
    export: "Export",
    import: "Import",
    share: "Share",
    days: "days",
    darkMode: "Dark Mode",
    lightMode: "Light Mode",
    confirm: "Confirm",
    remainingTokens: "Remaining Tokens"
  },
  
  // Header component
  header: {
    search: "Search...",
    myTeams: "My Teams",
    invitations: "Invitations",
    setupProfile: "Setup Profile",
    subscription: "Subscription",
    settings: "Settings",
    adminPanel: "Admin Panel",
    signOut: "Sign out",
    profile: "Profile",
  },
  
  // Dashboard page
  dashboard: {
    title: "Dashboard",
    subtitle: "Build and track your PMO across all essential domains",
    budget: "Budget",
    editDetails: "Edit Details",
    exportReport: "Export Report",
    access: "Access",
    timelineProgress: "Timeline Progress",
    budgetUtilization: "Budget Utilization",
    projectStatus: "Project Status",
    maturityAssessment: "Maturity Assessment",
    keyObjectives: "Key Objectives",
    stakeholders: "Stakeholders",
    overallProgress: "Overall Progress",
    completedTasks: "Completed Tasks",
    domainProcessComparison:"Domain Progress Comparison",
    organization: "Organization",
    industry: "Industry",
    dashboardCustomization: "Dashboard Customization",
    displayLayout: "Display Layout",
    gridView: "Grid View",
    listView: "List View",
    widgetSelection: "Widget Selection",
    assessMaturityLevel: "Assess Your Maturity Level",
    maturityLevel: "Maturity Level",
    progressOverview: "Progress Overview",
    tasksStatus: "Tasks Status",
    domains: "Domains",
    chartsAnalytics: "Charts & Analytics",
    pmoMaturityLevel: "PMO Maturity Level",
    pmoDomains: "PMO Domains",
    aiAnalysis: "Accelerate with AI",
    aiDescription: "Let our advanced AI analyze your PMO data and generate comprehensive recommendations tailored to your organization's unique needs.",
    tryAiAnalysis: "Try AI Analysis",
    viewAll: "View all",
    of: "of",
    tasksCompleted: "tasks completed",
    notSet: "Not set",
    updateProfile: "Update profile",
    viewAllTasks: "View all tasks",
    nextSteps: "Next Steps",
    uploadDocuments: "Upload documents",
    analysisDocuments: "Upload supporting documents for AI analysis",
    analysisDocumentsDesc: "Enhance AI recommendations with your organization's context",
    completePmoMaturityAssessment: "Complete a PMO Maturity Assessment",
    getInsightsAboutPmoMaturityLevel: "Get insights about your PMO's current maturity level",
    reviewPractices: "Review best practices",
    explorePractices: "Explore the best practices library for guidance",
    viewResources: "View resources",
    goToAssessment: "Go to assessment",
    objective1: "Establish PMO governance framework",
    objective2: "Develop standard methodologies",
    objective3: "Implement performance metrics",
    sampleProject: "Sample PMO Implementation",
    sampleDescription: "A sample project with pre-populated data for demonstration",
    createFirstProject: "Create Your First PMO Project",
    firstProjectDesc: "Get started by creating your first PMO implementation project. You can set up project details, track progress across domains, and generate AI-powered recommendations.",
    createSample: "Create Sample Project",
    aiFeature1: "Custom templates based on your current maturity level",
    aiFeature2: "Detailed implementation roadmaps for each domain",
    aiFeature3: "Best practices tailored to your industry and context",
    maturityRadarChart: "Maturity Radar Chart",
    higherValuesIndicateGreaterMaturity: "Higher values indicate greater maturity",
    pmoMaturityAssessment: "PMO Maturity Assessment",
    assessPmoMaturity: "Assess your PMO's maturity level across all domains to identify strengths and improvement opportunities",
    selfAssessment: "Self-Assessment",
    aiGeneratedAssessment: "AI-Generated Assessment",
    notSpecified: "Not specified",
    currentMaturityProfile: "Current Maturity Profile",
    organizationDetails: "Organization Details",
    assessmentType: "Assessment Type",
    currentMaturityProfileDescription: "Your organization's PMO is currently at the",
    currentMaturityProfileDescription2: "level. This assessment will help you identify areas for improvement and create a roadmap for advancing your PMO capabilities.",
    assessmentDate: "Assessment Date",
    selfAssessmentQuestionnaire: "Self-Assessment Questionnaire",
    selfAssessmentDescription: "Rate your PMO's maturity level for each domain. Consider your processes, documentation, measurement capabilities, and continuous improvement efforts when making your assessment.",
    documentation: "Documentation",
    metrics: "Metrics",
    minimalToNone: "Minimal to none",
    basicDocumentation: "Basic documentation",
    comprehensiveDocumentation: "Comprehensive",
    regularlyUpdated: "Regularly updated",
    leadingPractice: "Leading practice",
    adHocOrNone: "Ad-hoc or none",
    basicTracking: "Basic tracking",
    notes: "Notes (Optional)",
    notesPlaceholder: "Add any notes or context about your assessment...",
    createNew: "Create New Project",
    generateAIAssessment: "Generate an AI Assessment",
    aiAssessmentDescription: "Our AI will analyze your domain inputs, project data, and uploaded documents to provide an objective assessment of your PMO's maturity across all domains.",
    aiAssessmentSummary: "AI Assessment Summary",
    aiAssessmentSummaryDescription: "Based on our analysis, your PMO is currently at the",
    keyStrengths: "Key Strengths",
    areasForImprovement: "Areas for Improvement",
    domainSpecificAssessment: "Domain-Specific Assessment",
    maturityProgression: "Maturity Progression",
    recommendations: "Recommendations",
    generatingReport: "Generating Report...",
    exportAssessmentReport: "Export Assessment Report",
    detailedMaturityGuide: "Detailed Maturity Guide",
    maturityModelReference: "Maturity Model Reference",
    generateAssessment: "Generate Assessment",
    generatingAssessment: "Generating Assessment...",
    generatingAssessmentDescription: "Our AI is analyzing your PMO data across all domains. This may take a few moments.",
    
  },
  
  // Domain detail page
  domain: {
    BestPractices: "Best Practices",
    backToDashboard: "Back to Dashboard",
    prevDomain: "Previous Domain",
    nextDomain: "Next Domain",
    viewDomain: "View Domain",
    progress: "Progress",
    tasks: "Tasks & Progress",
    input: "Domain Input & Analysis",
    analyzing: "Analyzing Domain Input",
    processingData: "Our AI is processing your input data...",
    inputStage: "Input",
    inputDesc: "Collect data, assess current state, and gather requirements for this domain.",
    processingStage: "Processing",
    processingDesc: "Analyze data, develop frameworks, and design solutions for this domain.",
    outputStage: "Output",
    outputDesc: "Create deliverables, implement solutions, and establish frameworks for this domain.",
    loading: "Loading domain data...",
    notFound: "Domain not found",
    provideInputFirst: "Please provide domain input data before analyzing",
    aiGeneratedAnalysis: "AI-Generated Analysis for",
    generated: "Generated",
    analysis: "Analysis",
    domainProgress: "Domain Progress (%)",
    templates: "Templates",
    downloadMarkdown: "Download Markdown",
    downloadPdf: "Download PDF",
    generatingPdf: "Generating PDF...",
    generating: "Generating...",
    allTemplates: "All Available Templates",
    markdownFormat: "Markdown",
    words: "words",
    usingTemplates: "Using These Templates",
    templateDescription: "These templates are available in Markdown and PDF formats. Markdown can be imported into document editors, project management tools, or converted to other formats. PDF files are ready for printing or sharing with stakeholders.",
    noTemplates: "No templates available for this domain",
    aiConfigTitle: "AI Analysis Configuration",
    selectDomainPrompt: "Select a domain to analyze with our advanced AI. The analysis will generate comprehensive recommendations and templates based on your organization's specific context.",
    selectDomain: "Select Domain",
    analysisDepth: "Analysis Depth",
    basic: "Basic",
    quickOverview: "Quick overview",
    standard: "Standard",
    balancedAnalysis: "Balanced analysis",
    detailed: "Detailed",
    inDepthReview: "In-depth review",
    comprehensive: "Comprehensive",
    maximumDetail: "Maximum detail",
    geminiPowered: "Gemini AI Powered Analysis",
    advancedAiDesc: "Advanced AI will analyze your inputs and generate tailored recommendations",
    startAnalysis: "Start Analysis"
  },
  
  // Project management
  project: {
    projectName: "Project Name",
    projectNamePlaceholder: "Enterprise PMO Implementation",
    description: "Description",
    descriptionPlaceholder: "Brief description of your PMO implementation project",
    budget: "Budget",
    yourProjects: "Your Projects",
    createProject: "Create Project"
  },
  
  // Sidebar
  sidebar: {
    dashboard: "Dashboard",
    pmoDomains: "PMO Domains",
    tools: "Tools & Assessment",
    resources: "Resources",
    tasks: "Tasks",
    bestPractices: "Best Practices",
    maturityAssessment: "Maturity Assessment",
    assessment: "Assessment",
  },
  
  // Auth pages
  auth: {
    copyright: "© 2025 PMO Builder using AI by Dr. Ahmed Alsenosy"
  },
  
  // Maturity levels
  maturityLevels: {
    initial: {
      label: 'Initial',
      description: 'Processes are ad hoc and chaotic.'
    },
    defined: {
      label: 'Defined',
      description: 'Processes are documented and standardized.'
    },
    managed: {
      label: 'Managed',
      description: 'Processes are measured and controlled.'
    },
    optimized: {
      label: 'Optimized',
      description: 'Focus on continuous improvement.'
    },
    innovative: {
      label: 'Innovative',
      description: 'Driving industry innovation and adaptation.'
    }
  },

  //profile page
  profile: {
    title: "Organization Profile",
    description: "Set up your organization details to personalize your PMO journey",
    organizationName: "Organization Name",
    organizationNamePlaceholder: "Enter your organization name",
    industry: "Industry",
    industryPlaceholder: "Enter your industry",
    pmoMaturityLevel: "PMO Maturity Level",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "Select the maturity level that best describes your current PMO",
    saveProfile: "Save Profile",
    cancel: "Cancel",
    initial: "Initial - Ad hoc processes",
    defined: "Defined - Basic processes established",
    managed: "Managed - Standardized processes",
    optimized: "Optimized - Continuously improving",
    notEstablished: "Not Established - No formal PMO",
  },
  
  //settings page
  settings: {
    title: "Settings",
    description: "Manage your account settings and preferences",
    personal: "Personal",
    subscription: "Subscription",
    notifications: "Notifications",
    security: "Security",
    data: "Data",
    saveProfile: "Save Profile",
    cancel: "Cancel",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "Select the maturity level that best describes your current PMO",
    organizationName: "Organization Name",
    organizationNamePlaceholder: "Enter your organization name",
    industry: "Industry",
    industryPlaceholder: "Enter your industry",
    pmoMaturityLevel: "PMO Maturity Level",
    notEstablished: "Not Established - No formal PMO",
    initial: "Initial - Ad hoc processes",
    defined: "Defined - Basic processes established",
    managed: "Managed - Standardized processes",
    optimized: "Optimized - Continuously improving",
  },

  // Resources page
  resources: {
    title: "Resources",
    noDocuments: "No documents available",
    errorLoading: "Error loading documents",
    downloadError: "Error downloading document",
    uploadNew: "Upload New Document",
    filter: "Filter Documents",
    sortBy: "Sort By",
    search: "Search Documents",
    lastModified: "Last Modified",
    fileName: "File Name",
    fileSize: "File Size",
    taskName: "Task Name",
    projectId: "Project ID"
  },
 // Help page
  help: {
    title: "Help & Support",
    description: "Learn how to use the PMO Domains Application Tool effectively",
    gettingStarted: "Getting Started",
    whatIsPmoDomainsTool: "What is the PMO Domains Tool?",
    whatIsPmoDomainsToolDescription: `The PMO Domains Application Tool helps PMO professionals apply and monitor the five key PMO domains using a structured "Inputs – Processing – Outputs" framework. The tool guides you through each domain's tasks, ensuring best practices and benchmarking against industry standards.`, 
    howToUseThisTool: "How to Use This Tool",
    howToUseThisToolDescription: "The PMO Domains Application Tool is a web-based application that helps organizations implement and improve their PMO capabilities across all domains.",
    canIExportMyData: "Can I export my data?",
    canIExportMyDataDescription: "Yes, you can export your data from the Settings page. This allows you to back up your progress or transfer it to another system.",
    canICustomizeTheToolForMyOrganization: "Can I customize the tool for my organization?",
    canICustomizeTheToolForMyOrganizationDescription: "The tool is designed to be applicable across different organizations and industries. You can add custom notes to each task to tailor it to your specific organizational context.",
    whatIfINotReadyToCompleteAllDomains: "What if I'm not ready to complete all domains?",
    whatIfINotReadyToCompleteAllDomainsDescription: "You can work on domains in any order that makes sense for your organization. The tool will track your progress across all domains, allowing you to focus on your priorities.",
    contactSupport: "Contact Support",
    contactSupportDescription: "If you need additional help or have questions about the PMO Domains Application Tool, please contact our support team.",
    supportContact: "Support Contact",
    supportContactEmail: "Email: support@pmobuilder.ai",
    supportContactPhone: "Phone: (555) 123-4567",
    supportContactHours: "Hours: Monday-Friday, 9am-5pm EST",
    startBySettingUpYourOrganizationProfile: "Start by setting up your organization profile in the Profile section",
    navigateToEachDomainUsingTheSidebarMenu: "Navigate to each domain using the sidebar menu",
    completeTasksInTheRecommendedOrder: "Complete tasks in the recommended order: Input → Processing → Output",
    markTasksAsCompleteAsYouProgress: "Mark tasks as complete as you progress",
    useTheDashboardToTrackYourOverallProgress: "Use the dashboard to track your overall progress",
    referToTheBestPracticesLibraryForGuidance: "Refer to the Best Practices Library for guidance",
    organizationalDevelopmentAndAlignment: "1. Organizational Development and Alignment",
    organizationalDevelopmentAndAlignmentDescription: "This domain focuses on aligning the PMO with organizational strategy and culture to ensure effective project management practices. It includes organizational assessment, stakeholder analysis, and developing alignment strategies.",
    strategicElementsOfThePmo: "2. Strategic Elements of the PMO",
    strategicElementsOfThePmoDescription: "This domain involves developing and implementing strategic frameworks, roadmaps, and governance structures. It includes strategic objectives review, portfolio analysis, and governance structure design.",
    pMODesignAndStructuring: "3. PMO Design and Structuring",
    pMODesignAndStructuringDescription: "This domain focuses on creating the optimal PMO structure, roles, and responsibilities to meet organizational needs. It includes requirements gathering, resource assessment, and service catalog development.",
    pMOOperationAndPerformance: "4. PMO Operation and Performance",
    pMOOperationAndPerformanceDescription: "This domain establishes operational processes, KPIs, and performance metrics for the PMO. It includes process assessment, performance metrics identification, and performance measurement systems.",
    pMOEnhancementAndEffectiveness: "5. PMO Enhancement and Effectiveness",
    pMOEnhancementAndEffectivenessDescription: "This domain focuses on continuously improving PMO services, capabilities, and value delivery. It includes maturity assessment, value delivery analysis, and continuous improvement planning.",
    frequentlyAskedQuestions: "Frequently Asked Questions",
    frequentlyAskedQuestionsDescription: "The PMO Domains Application Tool is a web-based application that helps organizations implement and improve their PMO capabilities across all domains.",
    howToAccessTemplates: "How do I access templates?",
    howToAccessTemplatesDescription: "Templates are available within specific tasks that have template resources. You can also find a collection of templates in the Best Practices Library",
    understandingTheFiveDomains: "Understanding the Five Domains",
  },
    
  subscription: {
    title: "Subscription Management",
    currentPlan: "Current Plan",
    trial: "Trial",
    cancelsAtPeriodEnd: "Cancels at period end",
    upgradePlan: "Upgrade Plan",
    manageSubscription: "Manage Subscription",
    processing: "Processing...",
    billingPeriod: "Billing Period",
    nextBillingDate: "Next Billing Date",
    paymentMethod: "Payment Method",
    projects: "Projects",
    aiAnalysis: "AI Analysis",
    storage: "Storage",
    freePlanLimitations: "Free plan limitations",
    freePlanLimitationsDescription: "You're currently on the Free plan, which has limitations on projects, AI analyses, and storage. Upgrade to Premium or Enterprise for increased limits and additional features.",
    upgradeNow: "Upgrade Now",
    upgradeToGetMore: "Upgrade to Get More",
    premiumPlanBenefits: "Premium Plan Benefits",
    upTo20Projects: "Up to 20 projects (vs. 3 on Free)",
    upTo100AiAnalyses: "100 AI analyses per month (vs. 3 on Free)",
    teamCollaboration: "Team collaboration with up to 5 users",
    prioritySupport: "Priority support",
    enterprisePlanBenefits: "Enterprise Plan Benefits",
    unlimitedProjectsAndAiAnalyses: "Unlimited projects and AI analyses",
    unlimitedTeamMembers: "Unlimited team members",
    whiteLabelingOptions: "White-labeling options",
    dedicatedSupport: "Dedicated support",
    upgradeToEnterprise: "Upgrade to Enterprise",
    unlimited: "Unlimited",
    unknown: "Unknown",
    free: "Free",
    premium: "Premium",
    enterprise: "Enterprise",
    usageAndLimits: "Usage & Limits",
    perMonth: "per month",
    mb: "MB",
    none: "None",
    creditCard: "Credit Card",
    paypal: "PayPal",
    notAvailable: "Not available",
  },
  
  //notifications
  notifications: {
    '1': {
      title: "PMO Maturity Assessment Due",
      description: "Complete your quarterly PMO maturity assessment by Friday.",
      time: "2 days ago",
    },
    '2': {
      title: "Strategic Elements Domain Updated",
      description: "New templates and resources have been added to the Strategic Elements domain.",
      time: "3 days ago",
    },
    '3': {
      title: "Team Meeting: PMO Enhancement",
      description: "Upcoming team meeting to discuss PMO Enhancement strategies.",
      time: "Tomorrow, 10:00 AM",
    },
    '4': {
      title: "New Message from Admin",
      description: "You have a new message regarding your Organization Development domain progress.",
      time: "1 week ago",
    },
    '5': {
      title: "Data Backup Complete",
      description: "Your PMO data has been successfully backed up to cloud storage.",
      time: "2 weeks ago",
    },
    title: "Notifications",
    description: "Stay updated with your PMO activities and important alerts",
    markAllAsRead: "Mark all as read",
    clearAll: "Clear all",
    markAllAsReadDescription: "Mark all notifications as read",
    clearAllDescription: "Clear all notifications",
    markAllAsReadButton: "Mark all as read",
    clearAllButton: "Clear all",
    unread: "Unread",
    all: "All",
    recentNotifications: "Recent Notifications",
    markAsUnread: "Mark as unread",
    markAsRead: "Mark as read",
    viewDetails: "View details",
    loadMore: "Load more notifications",
    customizeNotifications: "Customize how and when you receive notifications about your PMO activities",
    notificationPreferences: "Notification Preferences",
    managePreferences: "Manage Preferences",
    

  },
  // Domain names
  domains: {
    "1": {
      name: "Organizational Development and Alignment",
      description: "Aligning the PMO with organizational strategy and culture to ensure effective project management practices.",
      tasks: {
        "1-input-1": {
          stage: "input",
          title: "Assess Current Competencies",
          description: "Gather data on existing competencies through surveys, interviews, and documentation review.",
          bestPractices: [
            "Use standardized assessment tools to evaluate current competencies",
            "Collect input from multiple organizational levels",
            "Document both technical and soft skill competencies",
            "Identify competency gaps through structured assessment"
          ]
        },
        "1-input-2": {
          stage: "input",
          title: "Assess Organizational Culture",
          description: "Collect data on current organizational culture through surveys, focus groups, and stakeholder interviews.",
          bestPractices: [
            "Conduct culture assessment surveys",
            "Gather feedback from diverse organizational levels",
            "Document cultural enablers and barriers to project management",
            "Collect historical data on cultural change initiatives"
          ]
        },
        "1-input-3": {
          stage: "input",
          title: "Benchmark Against Industry Standards",
          description: "Collect industry benchmarking data and best practices for organizational alignment.",
          bestPractices: [
            "Select relevant industry benchmarks and standards",
            "Gather data from industry reports and publications",
            "Document peer organization practices",
            "Collect metrics for comparative analysis"
          ]
        },
        "1-processing-1": {
          stage: "processing",
          title: "Apply Strategic Analysis Techniques",
          description: "Use strategic analysis tools to develop an integrated strategy with risk management and implementation roadmap.",
          bestPractices: [
            "Apply SWOT analysis to identify strengths and weaknesses",
            "Use gap analysis to identify improvement areas",
            "Apply risk assessment methodologies",
            "Use roadmapping techniques for implementation planning"
          ]
        },
        "1-processing-2": {
          stage: "processing",
          title: "Apply Communication Planning Methodologies",
          description: "Use communication planning techniques to develop stakeholder-specific messaging and feedback mechanisms.",
          bestPractices: [
            "Apply stakeholder analysis techniques",
            "Use communication matrix development methods",
            "Apply message tailoring methodologies",
            "Use KPI development frameworks for communication effectiveness"
          ]
        },
        "1-processing-3": {
          stage: "processing",
          title: "Apply Charter Development Techniques",
          description: "Use charter development methodologies to define PMO scope, authority, and governance structure.",
          bestPractices: [
            "Apply scope definition techniques",
            "Use RACI matrix development methods",
            "Apply governance framework design methodologies",
            "Use authority mapping techniques"
          ],
          templates: ["PMO Charter Template", "RACI Matrix"]
        },
        "1-output-1": {
          stage: "output",
          title: "Deliver Integrated Strategy and Roadmap",
          description: "Produce and implement the integrated strategy with risk management plan and phased implementation roadmap.",
          bestPractices: [
            "Document comprehensive strategy with clear objectives",
            "Create detailed implementation roadmap with milestones",
            "Develop risk management plan with mitigation strategies",
            "Establish strategy review and update mechanisms"
          ]
        },
        "1-output-2": {
          stage: "output",
          title: "Establish PMO Vision, Values and Culture",
          description: "Implement vision statement, core values, and cultural change program with leadership engagement.",
          bestPractices: [
            "Create compelling vision statement aligned with organization",
            "Document core values with behavioral examples",
            "Implement leadership engagement activities",
            "Establish cultural reinforcement mechanisms"
          ],
          templates: ["PMO Vision Statement Template", "Cultural Change Roadmap"]
        },
        "1-output-3": {
          stage: "output",
          title: "Implement PMO Charter and Governance",
          description: "Establish and operationalize PMO charter with defined scope, authority, and governance structure.",
          bestPractices: [
            "Formalize PMO charter with executive approval",
            "Implement governance structure with clear roles",
            "Establish decision-making authorities and processes",
            "Create charter review and update mechanisms"
          ],
          templates: ["PMO Charter Document", "Governance Structure Diagram"]
        },
      },
    },
    "2": {
      name: "Strategic Framework & Governance",
      description: "Creating the optimal PMO structure, roles, and responsibilities to meet organizational needs.",
      tasks: {
        "2-input-1": {
          stage: "input",
          title: "Gather Current State Data",
          description: "Collect data on current project management operations, processes, and performance.",
          bestPractices: [
            "Conduct process documentation review",
            "Gather performance metrics and historical data",
            "Collect stakeholder feedback on current operations",
            "Document existing governance structures"
          ]
        },
        "2-input-2": {
          stage: "input",
          title: "Collect Strategic Alignment Information",
          description: "Gather organizational strategic objectives, priorities, and success criteria.",
          bestPractices: [
            "Review organizational strategic plans",
            "Collect executive leadership priorities",
            "Document business unit objectives",
            "Gather information on strategic initiatives"
          ]
        },
        "2-input-3": {
          stage: "input",
          title: "Identify Capability Requirements",
          description: "Collect data on required capabilities through stakeholder interviews and organizational needs assessment.",
          bestPractices: [
            "Conduct capability needs interviews",
            "Gather industry capability standards",
            "Document capability prioritization criteria",
            "Collect capability maturity benchmarks"
          ]
        },
        "2-processing-1": {
          stage: "processing",
          title: "Apply Mandate Development Methodology",
          description: "Use mandate development techniques to define PMO purpose, authority, and responsibilities.",
          bestPractices: [
            "Apply purpose statement development methods",
            "Use authority mapping techniques",
            "Apply responsibility definition methodologies",
            "Use stakeholder validation approaches"
          ],
          templates: ["PMO Mandate Template", "Executive Sponsorship Agreement"]
        },
        "2-processing-2": {
          stage: "processing",
          title: "Apply Charter Development Framework",
          description: "Use charter development framework to create comprehensive PMO charter with roles and governance structure.",
          bestPractices: [
            "Apply vision and mission statement techniques",
            "Use organizational structure design methods",
            "Apply role definition methodologies",
            "Use governance framework design techniques"
          ],
          templates: ["PMO Charter Template", "Governance Structure Diagram"]
        },
        "2-processing-3": {
          stage: "processing",
          title: "Apply Governance Design Methodology",
          description: "Use governance design techniques to develop decision-making processes and oversight mechanisms.",
          bestPractices: [
            "Apply decision rights mapping techniques",
            "Use escalation path design methods",
            "Apply governance body design methodologies",
            "Use governance communication planning techniques"
          ],
          templates: ["Governance Framework Template", "Decision Rights Matrix"]
        },
        "2-output-1": {
          stage: "output",
          title: "Establish PMO Mandate and Charter",
          description: "Formalize and implement PMO mandate and charter with defined purpose, authority, and responsibilities.",
          bestPractices: [
            "Obtain executive approval for mandate and charter",
            "Communicate mandate to all stakeholders",
            "Implement authority structures defined in charter",
            "Establish charter review and update process"
          ],
          templates: ["Approved PMO Mandate", "Finalized PMO Charter"]
        },
        "2-output-2": {
          stage: "output",
          title: "Implement Governance Framework",
          description: "Establish and operationalize governance framework with decision-making bodies, processes, and oversight mechanisms.",
          bestPractices: [
            "Form governance committees with clear charters",
            "Implement decision-making processes and authorities",
            "Establish governance meeting cadence and agendas",
            "Create governance documentation and reporting system"
          ],
          templates: ["Governance Committee Charter", "Decision Authority Matrix"]
        },
        "2-output-3": {
          stage: "output",
          title: "Develop Strategic Communication Plan",
          description: "Implement comprehensive communication strategy with stakeholder-specific messaging and feedback mechanisms.",
          bestPractices: [
            "Create stakeholder-specific communication materials",
            "Establish regular communication cadence",
            "Implement feedback collection mechanisms",
            "Develop communication effectiveness metrics"
          ],
          templates: ["Strategic Communication Plan", "Stakeholder Messaging Matrix"]
        },      
      }
    },
    "3": {
      name: "PMO Structure & Design",
      description: "Establishing operational processes, KPIs, and performance metrics for the PMO.",
      tasks: {
        "3-input-1": {
          stage: "input",
          title: "Gather Customer Data",
          description: "Collect data on potential PMO customers, their needs, and expectations through surveys and interviews.",
          bestPractices: [
            "Conduct customer needs assessment surveys",
            "Gather stakeholder interview data",
            "Document customer pain points and expectations",
            "Collect service prioritization information"
          ]
        },
        "3-input-2": {
          stage: "input",
          title: "Collect Service Requirement Data",
          description: "Gather detailed requirements for potential PMO services through workshops and requirements sessions.",
          bestPractices: [
            "Conduct service requirements workshops",
            "Document service level expectations",
            "Collect service prioritization criteria",
            "Gather benchmark data on similar services"
          ],
          templates: ["Service Requirements Template", "Customer Needs Assessment"]
        },
        "3-input-3": {
          stage: "input",
          title: "Assess Capability Gaps",
          description: "Collect data on current capabilities and gaps through assessment tools and stakeholder feedback.",
          bestPractices: [
            "Use capability maturity assessment tools",
            "Gather capability benchmark data",
            "Document capability prioritization criteria",
            "Collect resource availability information"
          ]
        },
        "3-processing-1": {
          stage: "processing",
          title: "Apply Persona Development Techniques",
          description: "Use persona development methodologies to create detailed customer personas with needs and expectations.",
          bestPractices: [
            "Apply customer segmentation techniques",
            "Use persona development frameworks",
            "Apply needs analysis methodologies",
            "Use journey mapping techniques"
          ]
        },
        "3-processing-2": {
          stage: "processing",
          title: "Apply Prioritization Frameworks",
          description: "Use prioritization techniques to develop framework for addressing customer needs systematically.",
          bestPractices: [
            "Apply value vs. effort prioritization matrix",
            "Use MoSCoW prioritization technique",
            "Apply weighted scoring methodologies",
            "Use impact mapping techniques"
          ]
        },
        "3-processing-3": {
          stage: "processing",
          title: "Apply Service Catalog Design Methodology",
          description: "Use service catalog design techniques to develop comprehensive service offerings with benefits and advantages.",
          bestPractices: [
            "Apply service definition frameworks",
            "Use service level definition techniques",
            "Apply value proposition development methodologies",
            "Use service categorization techniques"
          ],
          templates: ["Service Catalog Template", "Service Level Agreement Template"]
        },
        "3-output-1": {
          stage: "output",
          title: "Deliver Customer Personas and Journey Maps",
          description: "Create and distribute detailed customer personas and journey maps to guide service design and delivery.",
          bestPractices: [
            "Document comprehensive personas with needs and pain points",
            "Create visual journey maps for key customer interactions",
            "Distribute personas to all service delivery teams",
            "Establish persona update and refinement process"
          ],
          templates: ["Customer Persona Template", "Journey Map Template"]
        },
        "3-output-2": {
          stage: "output",
          title: "Implement Service Catalog and SLAs",
          description: "Launch comprehensive service catalog with service level agreements, processes, and quality standards.",
          bestPractices: [
            "Create detailed service descriptions with value propositions",
            "Establish service level metrics and targets",
            "Implement service request and delivery processes",
            "Create service catalog review and update mechanism"
          ],
          templates: ["Service Catalog Document", "SLA Documentation"]
        },
        "3-output-3": {
          stage: "output",
          title: "Establish Service Prioritization Framework",
          description: "Implement systematic approach for prioritizing and addressing customer needs and service requests.",
          bestPractices: [
            "Create prioritization criteria and scoring system",
            "Implement request intake and evaluation process",
            "Establish resource allocation based on priorities",
            "Develop priority review and adjustment mechanisms"
          ],
          templates: ["Prioritization Matrix", "Service Request Form"]
        },      
      }
    },
// Translation keys organized by component/page
// English translations
const en = {
  // Common components
  common: {
    pleaseWait: "Please wait while we prepare your content.",
    Complete : "Complete",
    search: "Search",
    save: "Save",
    saveAssessment: "Save Assessment",
    saved: "Saved!",
    showLess: "Show less",
    showMore: "Show more",
    cancel: "Cancel",
    edit: "Edit",
    delete: "Delete",
    close: "Close",
    loading: "Loading...",
    submit: "Submit",
    active: "Active",
    back: "Back",
    spent: "Spent",
    used: "Used",
    onTrack: "On Track",
    viewDetails: "View Details",
    tasks: "Tasks",
    domains: "Domains",
    budget: "Budget",
    daysLeft: "days left",
    next: "Next",
    progress: "Progress",
    notifications: "Notifications",
    help: "Help",
    settings: "Settings",
    profile: "Profile",
    signOut: "Sign Out",
    dashboard: "Dashboard",
    export: "Export",
    import: "Import",
    share: "Share",
    days: "days",
    darkMode: "Dark Mode",
    lightMode: "Light Mode",
    confirm: "Confirm",
    remainingTokens: "Remaining Tokens"
  },
  
  // Header component
  header: {
    search: "Search...",
    myTeams: "My Teams",
    invitations: "Invitations",
    setupProfile: "Setup Profile",
    subscription: "Subscription",
    settings: "Settings",
    adminPanel: "Admin Panel",
    signOut: "Sign out",
    profile: "Profile",
  },
  
  // Dashboard page
  dashboard: {
    title: "Dashboard",
    subtitle: "Build and track your PMO across all essential domains",
    budget: "Budget",
    editDetails: "Edit Details",
    exportReport: "Export Report",
    access: "Access",
    timelineProgress: "Timeline Progress",
    budgetUtilization: "Budget Utilization",
    projectStatus: "Project Status",
    maturityAssessment: "Maturity Assessment",
    keyObjectives: "Key Objectives",
    stakeholders: "Stakeholders",
    overallProgress: "Overall Progress",
    completedTasks: "Completed Tasks",
    domainProcessComparison:"Domain Progress Comparison",
    organization: "Organization",
    industry: "Industry",
    dashboardCustomization: "Dashboard Customization",
    displayLayout: "Display Layout",
    gridView: "Grid View",
    listView: "List View",
    widgetSelection: "Widget Selection",
    assessMaturityLevel: "Assess Your Maturity Level",
    maturityLevel: "Maturity Level",
    progressOverview: "Progress Overview",
    tasksStatus: "Tasks Status",
    domains: "Domains",
    chartsAnalytics: "Charts & Analytics",
    pmoMaturityLevel: "PMO Maturity Level",
    pmoDomains: "PMO Domains",
    aiAnalysis: "Accelerate with AI",
    aiDescription: "Let our advanced AI analyze your PMO data and generate comprehensive recommendations tailored to your organization's unique needs.",
    tryAiAnalysis: "Try AI Analysis",
    viewAll: "View all",
    of: "of",
    tasksCompleted: "tasks completed",
    notSet: "Not set",
    updateProfile: "Update profile",
    viewAllTasks: "View all tasks",
    nextSteps: "Next Steps",
    uploadDocuments: "Upload documents",
    analysisDocuments: "Upload supporting documents for AI analysis",
    analysisDocumentsDesc: "Enhance AI recommendations with your organization's context",
    completePmoMaturityAssessment: "Complete a PMO Maturity Assessment",
    getInsightsAboutPmoMaturityLevel: "Get insights about your PMO's current maturity level",
    reviewPractices: "Review best practices",
    explorePractices: "Explore the best practices library for guidance",
    viewResources: "View resources",
    goToAssessment: "Go to assessment",
    objective1: "Establish PMO governance framework",
    objective2: "Develop standard methodologies",
    objective3: "Implement performance metrics",
    sampleProject: "Sample PMO Implementation",
    sampleDescription: "A sample project with pre-populated data for demonstration",
    createFirstProject: "Create Your First PMO Project",
    firstProjectDesc: "Get started by creating your first PMO implementation project. You can set up project details, track progress across domains, and generate AI-powered recommendations.",
    createSample: "Create Sample Project",
    aiFeature1: "Custom templates based on your current maturity level",
    aiFeature2: "Detailed implementation roadmaps for each domain",
    aiFeature3: "Best practices tailored to your industry and context",
    maturityRadarChart: "Maturity Radar Chart",
    higherValuesIndicateGreaterMaturity: "Higher values indicate greater maturity",
    pmoMaturityAssessment: "PMO Maturity Assessment",
    assessPmoMaturity: "Assess your PMO's maturity level across all domains to identify strengths and improvement opportunities",
    selfAssessment: "Self-Assessment",
    aiGeneratedAssessment: "AI-Generated Assessment",
    notSpecified: "Not specified",
    currentMaturityProfile: "Current Maturity Profile",
    organizationDetails: "Organization Details",
    assessmentType: "Assessment Type",
    currentMaturityProfileDescription: "Your organization's PMO is currently at the",
    currentMaturityProfileDescription2: "level. This assessment will help you identify areas for improvement and create a roadmap for advancing your PMO capabilities.",
    assessmentDate: "Assessment Date",
    selfAssessmentQuestionnaire: "Self-Assessment Questionnaire",
    selfAssessmentDescription: "Rate your PMO's maturity level for each domain. Consider your processes, documentation, measurement capabilities, and continuous improvement efforts when making your assessment.",
    documentation: "Documentation",
    metrics: "Metrics",
    minimalToNone: "Minimal to none",
    basicDocumentation: "Basic documentation",
    comprehensiveDocumentation: "Comprehensive",
    regularlyUpdated: "Regularly updated",
    leadingPractice: "Leading practice",
    adHocOrNone: "Ad-hoc or none",
    basicTracking: "Basic tracking",
    notes: "Notes (Optional)",
    notesPlaceholder: "Add any notes or context about your assessment...",
    createNew: "Create New Project",
    generateAIAssessment: "Generate an AI Assessment",
    aiAssessmentDescription: "Our AI will analyze your domain inputs, project data, and uploaded documents to provide an objective assessment of your PMO's maturity across all domains.",
    aiAssessmentSummary: "AI Assessment Summary",
    aiAssessmentSummaryDescription: "Based on our analysis, your PMO is currently at the",
    keyStrengths: "Key Strengths",
    areasForImprovement: "Areas for Improvement",
    domainSpecificAssessment: "Domain-Specific Assessment",
    maturityProgression: "Maturity Progression",
    recommendations: "Recommendations",
    generatingReport: "Generating Report...",
    exportAssessmentReport: "Export Assessment Report",
    detailedMaturityGuide: "Detailed Maturity Guide",
    maturityModelReference: "Maturity Model Reference",
    generateAssessment: "Generate Assessment",
    generatingAssessment: "Generating Assessment...",
    generatingAssessmentDescription: "Our AI is analyzing your PMO data across all domains. This may take a few moments.",
    
  },
  
  // Domain detail page
  domain: {
    BestPractices: "Best Practices",
    backToDashboard: "Back to Dashboard",
    prevDomain: "Previous Domain",
    nextDomain: "Next Domain",
    viewDomain: "View Domain",
    progress: "Progress",
    tasks: "Tasks & Progress",
    input: "Domain Input & Analysis",
    analyzing: "Analyzing Domain Input",
    processingData: "Our AI is processing your input data...",
    inputStage: "Input",
    inputDesc: "Collect data, assess current state, and gather requirements for this domain.",
    processingStage: "Processing",
    processingDesc: "Analyze data, develop frameworks, and design solutions for this domain.",
    outputStage: "Output",
    outputDesc: "Create deliverables, implement solutions, and establish frameworks for this domain.",
    loading: "Loading domain data...",
    notFound: "Domain not found",
    provideInputFirst: "Please provide domain input data before analyzing",
    aiGeneratedAnalysis: "AI-Generated Analysis for",
    generated: "Generated",
    analysis: "Analysis",
    domainProgress: "Domain Progress (%)",
    templates: "Templates",
    downloadMarkdown: "Download Markdown",
    downloadPdf: "Download PDF",
    generatingPdf: "Generating PDF...",
    generating: "Generating...",
    allTemplates: "All Available Templates",
    markdownFormat: "Markdown",
    words: "words",
    usingTemplates: "Using These Templates",
    templateDescription: "These templates are available in Markdown and PDF formats. Markdown can be imported into document editors, project management tools, or converted to other formats. PDF files are ready for printing or sharing with stakeholders.",
    noTemplates: "No templates available for this domain",
    aiConfigTitle: "AI Analysis Configuration",
    selectDomainPrompt: "Select a domain to analyze with our advanced AI. The analysis will generate comprehensive recommendations and templates based on your organization's specific context.",
    selectDomain: "Select Domain",
    analysisDepth: "Analysis Depth",
    basic: "Basic",
    quickOverview: "Quick overview",
    standard: "Standard",
    balancedAnalysis: "Balanced analysis",
    detailed: "Detailed",
    inDepthReview: "In-depth review",
    comprehensive: "Comprehensive",
    maximumDetail: "Maximum detail",
    geminiPowered: "Gemini AI Powered Analysis",
    advancedAiDesc: "Advanced AI will analyze your inputs and generate tailored recommendations",
    startAnalysis: "Start Analysis"
  },
  
  // Project management
  project: {
    projectName: "Project Name",
    projectNamePlaceholder: "Enterprise PMO Implementation",
    description: "Description",
    descriptionPlaceholder: "Brief description of your PMO implementation project",
    budget: "Budget",
    yourProjects: "Your Projects",
    createProject: "Create Project"
  },
  
  // Sidebar
  sidebar: {
    dashboard: "Dashboard",
    pmoDomains: "PMO Domains",
    tools: "Tools & Assessment",
    resources: "Resources",
    tasks: "Tasks",
    bestPractices: "Best Practices",
    maturityAssessment: "Maturity Assessment",
    assessment: "Assessment",
  },
  
  // Auth pages
  auth: {
    copyright: "© 2025 PMO Builder using AI by Dr. Ahmed Alsenosy"
  },
  
  // Maturity levels
  maturityLevels: {
    initial: {
      label: 'Initial',
      description: 'Processes are ad hoc and chaotic.'
    },
    defined: {
      label: 'Defined',
      description: 'Processes are documented and standardized.'
    },
    managed: {
      label: 'Managed',
      description: 'Processes are measured and controlled.'
    },
    optimized: {
      label: 'Optimized',
      description: 'Focus on continuous improvement.'
    },
    innovative: {
      label: 'Innovative',
      description: 'Driving industry innovation and adaptation.'
    }
  },

  //profile page
  profile: {
    title: "Organization Profile",
    description: "Set up your organization details to personalize your PMO journey",
    organizationName: "Organization Name",
    organizationNamePlaceholder: "Enter your organization name",
    industry: "Industry",
    industryPlaceholder: "Enter your industry",
    pmoMaturityLevel: "PMO Maturity Level",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "Select the maturity level that best describes your current PMO",
    saveProfile: "Save Profile",
    cancel: "Cancel",
    initial: "Initial - Ad hoc processes",
    defined: "Defined - Basic processes established",
    managed: "Managed - Standardized processes",
    optimized: "Optimized - Continuously improving",
    notEstablished: "Not Established - No formal PMO",
  },
  
  //settings page
  settings: {
    title: "Settings",
    description: "Manage your account settings and preferences",
    personal: "Personal",
    subscription: "Subscription",
    notifications: "Notifications",
    security: "Security",
    data: "Data",
    saveProfile: "Save Profile",
    cancel: "Cancel",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "Select the maturity level that best describes your current PMO",
    organizationName: "Organization Name",
    organizationNamePlaceholder: "Enter your organization name",
    industry: "Industry",
    industryPlaceholder: "Enter your industry",
    pmoMaturityLevel: "PMO Maturity Level",
    notEstablished: "Not Established - No formal PMO",
    initial: "Initial - Ad hoc processes",
    defined: "Defined - Basic processes established",
    managed: "Managed - Standardized processes",
    optimized: "Optimized - Continuously improving",
  },

  // Resources page
  resources: {
    title: "Resources",
    noDocuments: "No documents available",
    errorLoading: "Error loading documents",
    downloadError: "Error downloading document",
    uploadNew: "Upload New Document",
    filter: "Filter Documents",
    sortBy: "Sort By",
    search: "Search Documents",
    lastModified: "Last Modified",
    fileName: "File Name",
    fileSize: "File Size",
    taskName: "Task Name",
    projectId: "Project ID"
  },
 // Help page
  help: {
    title: "Help & Support",
    description: "Learn how to use the PMO Domains Application Tool effectively",
    gettingStarted: "Getting Started",
    whatIsPmoDomainsTool: "What is the PMO Domains Tool?",
    whatIsPmoDomainsToolDescription: `The PMO Domains Application Tool helps PMO professionals apply and monitor the five key PMO domains using a structured "Inputs – Processing – Outputs" framework. The tool guides you through each domain's tasks, ensuring best practices and benchmarking against industry standards.`, 
    howToUseThisTool: "How to Use This Tool",
    howToUseThisToolDescription: "The PMO Domains Application Tool is a web-based application that helps organizations implement and improve their PMO capabilities across all domains.",
    canIExportMyData: "Can I export my data?",
    canIExportMyDataDescription: "Yes, you can export your data from the Settings page. This allows you to back up your progress or transfer it to another system.",
    canICustomizeTheToolForMyOrganization: "Can I customize the tool for my organization?",
    canICustomizeTheToolForMyOrganizationDescription: "The tool is designed to be applicable across different organizations and industries. You can add custom notes to each task to tailor it to your specific organizational context.",
    whatIfINotReadyToCompleteAllDomains: "What if I'm not ready to complete all domains?",
    whatIfINotReadyToCompleteAllDomainsDescription: "You can work on domains in any order that makes sense for your organization. The tool will track your progress across all domains, allowing you to focus on your priorities.",
    contactSupport: "Contact Support",
    contactSupportDescription: "If you need additional help or have questions about the PMO Domains Application Tool, please contact our support team.",
    supportContact: "Support Contact",
    supportContactEmail: "Email: support@pmobuilder.ai",
    supportContactPhone: "Phone: (555) 123-4567",
    supportContactHours: "Hours: Monday-Friday, 9am-5pm EST",
    startBySettingUpYourOrganizationProfile: "Start by setting up your organization profile in the Profile section",
    navigateToEachDomainUsingTheSidebarMenu: "Navigate to each domain using the sidebar menu",
    completeTasksInTheRecommendedOrder: "Complete tasks in the recommended order: Input → Processing → Output",
    markTasksAsCompleteAsYouProgress: "Mark tasks as complete as you progress",
    useTheDashboardToTrackYourOverallProgress: "Use the dashboard to track your overall progress",
    referToTheBestPracticesLibraryForGuidance: "Refer to the Best Practices Library for guidance",
    organizationalDevelopmentAndAlignment: "1. Organizational Development and Alignment",
    organizationalDevelopmentAndAlignmentDescription: "This domain focuses on aligning the PMO with organizational strategy and culture to ensure effective project management practices. It includes organizational assessment, stakeholder analysis, and developing alignment strategies.",
    strategicElementsOfThePmo: "2. Strategic Elements of the PMO",
    strategicElementsOfThePmoDescription: "This domain involves developing and implementing strategic frameworks, roadmaps, and governance structures. It includes strategic objectives review, portfolio analysis, and governance structure design.",
    pMODesignAndStructuring: "3. PMO Design and Structuring",
    pMODesignAndStructuringDescription: "This domain focuses on creating the optimal PMO structure, roles, and responsibilities to meet organizational needs. It includes requirements gathering, resource assessment, and service catalog development.",
    pMOOperationAndPerformance: "4. PMO Operation and Performance",
    pMOOperationAndPerformanceDescription: "This domain establishes operational processes, KPIs, and performance metrics for the PMO. It includes process assessment, performance metrics identification, and performance measurement systems.",
    pMOEnhancementAndEffectiveness: "5. PMO Enhancement and Effectiveness",
    pMOEnhancementAndEffectivenessDescription: "This domain focuses on continuously improving PMO services, capabilities, and value delivery. It includes maturity assessment, value delivery analysis, and continuous improvement planning.",
    frequentlyAskedQuestions: "Frequently Asked Questions",
    frequentlyAskedQuestionsDescription: "The PMO Domains Application Tool is a web-based application that helps organizations implement and improve their PMO capabilities across all domains.",
    howToAccessTemplates: "How do I access templates?",
    howToAccessTemplatesDescription: "Templates are available within specific tasks that have template resources. You can also find a collection of templates in the Best Practices Library",
    understandingTheFiveDomains: "Understanding the Five Domains",
  },
    
  subscription: {
    title: "Subscription Management",
    currentPlan: "Current Plan",
    trial: "Trial",
    cancelsAtPeriodEnd: "Cancels at period end",
    upgradePlan: "Upgrade Plan",
    manageSubscription: "Manage Subscription",
    processing: "Processing...",
    billingPeriod: "Billing Period",
    nextBillingDate: "Next Billing Date",
    paymentMethod: "Payment Method",
    projects: "Projects",
    aiAnalysis: "AI Analysis",
    storage: "Storage",
    freePlanLimitations: "Free plan limitations",
    freePlanLimitationsDescription: "You're currently on the Free plan, which has limitations on projects, AI analyses, and storage. Upgrade to Premium or Enterprise for increased limits and additional features.",
    upgradeNow: "Upgrade Now",
    upgradeToGetMore: "Upgrade to Get More",
    premiumPlanBenefits: "Premium Plan Benefits",
    upTo20Projects: "Up to 20 projects (vs. 3 on Free)",
    upTo100AiAnalyses: "100 AI analyses per month (vs. 3 on Free)",
    teamCollaboration: "Team collaboration with up to 5 users",
    prioritySupport: "Priority support",
    enterprisePlanBenefits: "Enterprise Plan Benefits",
    unlimitedProjectsAndAiAnalyses: "Unlimited projects and AI analyses",
    unlimitedTeamMembers: "Unlimited team members",
    whiteLabelingOptions: "White-labeling options",
    dedicatedSupport: "Dedicated support",
    upgradeToEnterprise: "Upgrade to Enterprise",
    unlimited: "Unlimited",
    unknown: "Unknown",
    free: "Free",
    premium: "Premium",
    enterprise: "Enterprise",
    usageAndLimits: "Usage & Limits",
    perMonth: "per month",
    mb: "MB",
    none: "None",
    creditCard: "Credit Card",
    paypal: "PayPal",
    notAvailable: "Not available",
  },
  
  //notifications
  notifications: {
    '1': {
      title: "PMO Maturity Assessment Due",
      description: "Complete your quarterly PMO maturity assessment by Friday.",
      time: "2 days ago",
    },
    '2': {
      title: "Strategic Elements Domain Updated",
      description: "New templates and resources have been added to the Strategic Elements domain.",
      time: "3 days ago",
    },
    '3': {
      title: "Team Meeting: PMO Enhancement",
      description: "Upcoming team meeting to discuss PMO Enhancement strategies.",
      time: "Tomorrow, 10:00 AM",
    },
    '4': {
      title: "New Message from Admin",
      description: "You have a new message regarding your Organization Development domain progress.",
      time: "1 week ago",
    },
    '5': {
      title: "Data Backup Complete",
      description: "Your PMO data has been successfully backed up to cloud storage.",
      time: "2 weeks ago",
    },
    title: "Notifications",
    description: "Stay updated with your PMO activities and important alerts",
    markAllAsRead: "Mark all as read",
    clearAll: "Clear all",
    markAllAsReadDescription: "Mark all notifications as read",
    clearAllDescription: "Clear all notifications",
    markAllAsReadButton: "Mark all as read",
    clearAllButton: "Clear all",
    unread: "Unread",
    all: "All",
    recentNotifications: "Recent Notifications",
    markAsUnread: "Mark as unread",
    markAsRead: "Mark as read",
    viewDetails: "View details",
    loadMore: "Load more notifications",
    customizeNotifications: "Customize how and when you receive notifications about your PMO activities",
    notificationPreferences: "Notification Preferences",
    managePreferences: "Manage Preferences",
    

  },
  // Domain names
  domains: {
    "1": {
      name: "Organizational Development and Alignment",
      description: "Aligning the PMO with organizational strategy and culture to ensure effective project management practices.",
      tasks: {
        "1-input-1": {
          stage: "input",
          title: "Assess Current Competencies",
          description: "Gather data on existing competencies through surveys, interviews, and documentation review.",
          bestPractices: [
            "Use standardized assessment tools to evaluate current competencies",
            "Collect input from multiple organizational levels",
            "Document both technical and soft skill competencies",
            "Identify competency gaps through structured assessment"
          ]
        },
        "1-input-2": {
          stage: "input",
          title: "Assess Organizational Culture",
          description: "Collect data on current organizational culture through surveys, focus groups, and stakeholder interviews.",
          bestPractices: [
            "Conduct culture assessment surveys",
            "Gather feedback from diverse organizational levels",
            "Document cultural enablers and barriers to project management",
            "Collect historical data on cultural change initiatives"
          ]
        },
        "1-input-3": {
          stage: "input",
          title: "Benchmark Against Industry Standards",
          description: "Collect industry benchmarking data and best practices for organizational alignment.",
          bestPractices: [
            "Select relevant industry benchmarks and standards",
            "Gather data from industry reports and publications",
            "Document peer organization practices",
            "Collect metrics for comparative analysis"
          ]
        },
        "1-processing-1": {
          stage: "processing",
          title: "Apply Strategic Analysis Techniques",
          description: "Use strategic analysis tools to develop an integrated strategy with risk management and implementation roadmap.",
          bestPractices: [
            "Apply SWOT analysis to identify strengths and weaknesses",
            "Use gap analysis to identify improvement areas",
            "Apply risk assessment methodologies",
            "Use roadmapping techniques for implementation planning"
          ]
        },
        "1-processing-2": {
          stage: "processing",
          title: "Apply Communication Planning Methodologies",
          description: "Use communication planning techniques to develop stakeholder-specific messaging and feedback mechanisms.",
          bestPractices: [
            "Apply stakeholder analysis techniques",
            "Use communication matrix development methods",
            "Apply message tailoring methodologies",
            "Use KPI development frameworks for communication effectiveness"
          ]
        },
        "1-processing-3": {
          stage: "processing",
          title: "Apply Charter Development Techniques",
          description: "Use charter development methodologies to define PMO scope, authority, and governance structure.",
          bestPractices: [
            "Apply scope definition techniques",
            "Use RACI matrix development methods",
            "Apply governance framework design methodologies",
            "Use authority mapping techniques"
          ],
          templates: ["PMO Charter Template", "RACI Matrix"]
        },
        "1-output-1": {
          stage: "output",
          title: "Deliver Integrated Strategy and Roadmap",
          description: "Produce and implement the integrated strategy with risk management plan and phased implementation roadmap.",
          bestPractices: [
            "Document comprehensive strategy with clear objectives",
            "Create detailed implementation roadmap with milestones",
            "Develop risk management plan with mitigation strategies",
            "Establish strategy review and update mechanisms"
          ]
        },
        "1-output-2": {
          stage: "output",
          title: "Establish PMO Vision, Values and Culture",
          description: "Implement vision statement, core values, and cultural change program with leadership engagement.",
          bestPractices: [
            "Create compelling vision statement aligned with organization",
            "Document core values with behavioral examples",
            "Implement leadership engagement activities",
            "Establish cultural reinforcement mechanisms"
          ],
          templates: ["PMO Vision Statement Template", "Cultural Change Roadmap"]
        },
        "1-output-3": {
          stage: "output",
          title: "Implement PMO Charter and Governance",
          description: "Establish and operationalize PMO charter with defined scope, authority, and governance structure.",
          bestPractices: [
            "Formalize PMO charter with executive approval",
            "Implement governance structure with clear roles",
            "Establish decision-making authorities and processes",
            "Create charter review and update mechanisms"
          ],
          templates: ["PMO Charter Document", "Governance Structure Diagram"]
        },
      },
    },
    "2": {
      name: "Strategic Framework & Governance",
      description: "Creating the optimal PMO structure, roles, and responsibilities to meet organizational needs.",
      tasks: {
        "2-input-1": {
          stage: "input",
          title: "Gather Current State Data",
          description: "Collect data on current project management operations, processes, and performance.",
          bestPractices: [
            "Conduct process documentation review",
            "Gather performance metrics and historical data",
            "Collect stakeholder feedback on current operations",
            "Document existing governance structures"
          ]
        },
        "2-input-2": {
          stage: "input",
          title: "Collect Strategic Alignment Information",
          description: "Gather organizational strategic objectives, priorities, and success criteria.",
          bestPractices: [
            "Review organizational strategic plans",
            "Collect executive leadership priorities",
            "Document business unit objectives",
            "Gather information on strategic initiatives"
          ]
        },
        "2-input-3": {
          stage: "input",
          title: "Identify Capability Requirements",
          description: "Collect data on required capabilities through stakeholder interviews and organizational needs assessment.",
          bestPractices: [
            "Conduct capability needs interviews",
            "Gather industry capability standards",
            "Document capability prioritization criteria",
            "Collect capability maturity benchmarks"
          ]
        },
        "2-processing-1": {
          stage: "processing",
          title: "Apply Mandate Development Methodology",
          description: "Use mandate development techniques to define PMO purpose, authority, and responsibilities.",
          bestPractices: [
            "Apply purpose statement development methods",
            "Use authority mapping techniques",
            "Apply responsibility definition methodologies",
            "Use stakeholder validation approaches"
          ],
          templates: ["PMO Mandate Template", "Executive Sponsorship Agreement"]
        },
        "2-processing-2": {
          stage: "processing",
          title: "Apply Charter Development Framework",
          description: "Use charter development framework to create comprehensive PMO charter with roles and governance structure.",
          bestPractices: [
            "Apply vision and mission statement techniques",
            "Use organizational structure design methods",
            "Apply role definition methodologies",
            "Use governance framework design techniques"
          ],
          templates: ["PMO Charter Template", "Governance Structure Diagram"]
        },
        "2-processing-3": {
          stage: "processing",
          title: "Apply Governance Design Methodology",
          description: "Use governance design techniques to develop decision-making processes and oversight mechanisms.",
          bestPractices: [
            "Apply decision rights mapping techniques",
            "Use escalation path design methods",
            "Apply governance body design methodologies",
            "Use governance communication planning techniques"
          ],
          templates: ["Governance Framework Template", "Decision Rights Matrix"]
        },
        "2-output-1": {
          stage: "output",
          title: "Establish PMO Mandate and Charter",
          description: "Formalize and implement PMO mandate and charter with defined purpose, authority, and responsibilities.",
          bestPractices: [
            "Obtain executive approval for mandate and charter",
            "Communicate mandate to all stakeholders",
            "Implement authority structures defined in charter",
            "Establish charter review and update process"
          ],
          templates: ["Approved PMO Mandate", "Finalized PMO Charter"]
        },
        "2-output-2": {
          stage: "output",
          title: "Implement Governance Framework",
          description: "Establish and operationalize governance framework with decision-making bodies, processes, and oversight mechanisms.",
          bestPractices: [
            "Form governance committees with clear charters",
            "Implement decision-making processes and authorities",
            "Establish governance meeting cadence and agendas",
            "Create governance documentation and reporting system"
          ],
          templates: ["Governance Committee Charter", "Decision Authority Matrix"]
        },
        "2-output-3": {
          stage: "output",
          title: "Develop Strategic Communication Plan",
          description: "Implement comprehensive communication strategy with stakeholder-specific messaging and feedback mechanisms.",
          bestPractices: [
            "Create stakeholder-specific communication materials",
            "Establish regular communication cadence",
            "Implement feedback collection mechanisms",
            "Develop communication effectiveness metrics"
          ],
          templates: ["Strategic Communication Plan", "Stakeholder Messaging Matrix"]
        },      
      }
    },
    "3": {
      name: "PMO Structure & Design",
      description: "Establishing operational processes, KPIs, and performance metrics for the PMO.",
      tasks: {
        "3-input-1": {
          stage: "input",
          title: "Gather Customer Data",
          description: "Collect data on potential PMO customers, their needs, and expectations through surveys and interviews.",
          bestPractices: [
            "Conduct customer needs assessment surveys",
            "Gather stakeholder interview data",
            "Document customer pain points and expectations",
            "Collect service prioritization information"
          ]
        },
        "3-input-2": {
          stage: "input",
          title: "Collect Service Requirement Data",
          description: "Gather detailed requirements for potential PMO services through workshops and requirements sessions.",
          bestPractices: [
            "Conduct service requirements workshops",
            "Document service level expectations",
            "Collect service prioritization criteria",
            "Gather benchmark data on similar services"
          ],
          templates: ["Service Requirements Template", "Customer Needs Assessment"]
        },
        "3-input-3": {
          stage: "input",
          title: "Assess Capability Gaps",
          description: "Collect data on current capabilities and gaps through assessment tools and stakeholder feedback.",
          bestPractices: [
            "Use capability maturity assessment tools",
            "Gather capability benchmark data",
            "Document capability prioritization criteria",
            "Collect resource availability information"
          ]
        },
        "3-processing-1": {
          stage: "processing",
          title: "Apply Persona Development Techniques",
          description: "Use persona development methodologies to create detailed customer personas with needs and expectations.",
          bestPractices: [
            "Apply customer segmentation techniques",
            "Use persona development frameworks",
            "Apply needs analysis methodologies",
            "Use journey mapping techniques"
          ]
        },
        "3-processing-2": {
          stage: "processing",
          title: "Apply Prioritization Frameworks",
          description: "Use prioritization techniques to develop framework for addressing customer needs systematically.",
          bestPractices: [
            "Apply value vs. effort prioritization matrix",
            "Use MoSCoW prioritization technique",
            "Apply weighted scoring methodologies",
            "Use impact mapping techniques"
          ]
        },
        "3-processing-3": {
          stage: "processing",
          title: "Apply Service Catalog Design Methodology",
          description: "Use service catalog design techniques to develop comprehensive service offerings with benefits and advantages.",
          bestPractices: [
            "Apply service definition frameworks",
            "Use service level definition techniques",
            "Apply value proposition development methodologies",
            "Use service categorization techniques"
          ],
          templates: ["Service Catalog Template", "Service Level Agreement Template"]
        },
        "3-output-1": {
          stage: "output",
          title: "Deliver Customer Personas and Journey Maps",
          description: "Create and distribute detailed customer personas and journey maps to guide service design and delivery.",
          bestPractices: [
            "Document comprehensive personas with needs and pain points",
            "Create visual journey maps for key customer interactions",
            "Distribute personas to all service delivery teams",
            "Establish persona update and refinement process"
          ],
          templates: ["Customer Persona Template", "Journey Map Template"]
        },
        "3-output-2": {
          stage: "output",
          title: "Implement Service Catalog and SLAs",
          description: "Launch comprehensive service catalog with service level agreements, processes, and quality standards.",
          bestPractices: [
            "Create detailed service descriptions with value propositions",
            "Establish service level metrics and targets",
            "Implement service request and delivery processes",
            "Create service catalog review and update mechanism"
          ],
          templates: ["Service Catalog Document", "SLA Documentation"]
        },
        "3-output-3": {
          stage: "output",
          title: "Establish Service Prioritization Framework",
          description: "Implement systematic approach for prioritizing and addressing customer needs and service requests.",
          bestPractices: [
            "Create prioritization criteria and scoring system",
            "Implement request intake and evaluation process",
            "Establish resource allocation based on priorities",
            "Develop priority review and adjustment mechanisms"
          ],
          templates: ["Prioritization Matrix", "Service Request Form"]
        },      
      }
// Translation keys organized by component/page
// English translations
const en = {
  // Common components
  common: {
    pleaseWait: "Please wait while we prepare your content.",
    Complete : "Complete",
    search: "Search",
    save: "Save",
    saveAssessment: "Save Assessment",
    saved: "Saved!",
    showLess: "Show less",
    showMore: "Show more",
    cancel: "Cancel",
    edit: "Edit",
    delete: "Delete",
    close: "Close",
    loading: "Loading...",
    submit: "Submit",
    active: "Active",
    back: "Back",
    spent: "Spent",
    used: "Used",
    onTrack: "On Track",
    viewDetails: "View Details",
    tasks: "Tasks",
    domains: "Domains",
    budget: "Budget",
    daysLeft: "days left",
    next: "Next",
    progress: "Progress",
    notifications: "Notifications",
    help: "Help",
    settings: "Settings",
    profile: "Profile",
    signOut: "Sign Out",
    dashboard: "Dashboard",
    export: "Export",
    import: "Import",
    share: "Share",
    days: "days",
    darkMode: "Dark Mode",
    lightMode: "Light Mode",
    confirm: "Confirm",
    remainingTokens: "Remaining Tokens"
  },
  
  // Header component
  header: {
    search: "Search...",
    myTeams: "My Teams",
    invitations: "Invitations",
    setupProfile: "Setup Profile",
    subscription: "Subscription",
    settings: "Settings",
    adminPanel: "Admin Panel",
    signOut: "Sign out",
    profile: "Profile",
  },
  
  // Dashboard page
  dashboard: {
    title: "Dashboard",
    subtitle: "Build and track your PMO across all essential domains",
    budget: "Budget",
    editDetails: "Edit Details",
    exportReport: "Export Report",
    access: "Access",
    timelineProgress: "Timeline Progress",
    budgetUtilization: "Budget Utilization",
    projectStatus: "Project Status",
    maturityAssessment: "Maturity Assessment",
    keyObjectives: "Key Objectives",
    stakeholders: "Stakeholders",
    overallProgress: "Overall Progress",
    completedTasks: "Completed Tasks",
    domainProcessComparison:"Domain Progress Comparison",
    organization: "Organization",
    industry: "Industry",
    dashboardCustomization: "Dashboard Customization",
    displayLayout: "Display Layout",
    gridView: "Grid View",
    listView: "List View",
    widgetSelection: "Widget Selection",
    assessMaturityLevel: "Assess Your Maturity Level",
    maturityLevel: "Maturity Level",
    progressOverview: "Progress Overview",
    tasksStatus: "Tasks Status",
    domains: "Domains",
    chartsAnalytics: "Charts & Analytics",
    pmoMaturityLevel: "PMO Maturity Level",
    pmoDomains: "PMO Domains",
    aiAnalysis: "Accelerate with AI",
    aiDescription: "Let our advanced AI analyze your PMO data and generate comprehensive recommendations tailored to your organization's unique needs.",
    tryAiAnalysis: "Try AI Analysis",
    viewAll: "View all",
    of: "of",
    tasksCompleted: "tasks completed",
    notSet: "Not set",
    updateProfile: "Update profile",
    viewAllTasks: "View all tasks",
    nextSteps: "Next Steps",
    uploadDocuments: "Upload documents",
    analysisDocuments: "Upload supporting documents for AI analysis",
    analysisDocumentsDesc: "Enhance AI recommendations with your organization's context",
    completePmoMaturityAssessment: "Complete a PMO Maturity Assessment",
    getInsightsAboutPmoMaturityLevel: "Get insights about your PMO's current maturity level",
    reviewPractices: "Review best practices",
    explorePractices: "Explore the best practices library for guidance",
    viewResources: "View resources",
    goToAssessment: "Go to assessment",
    objective1: "Establish PMO governance framework",
    objective2: "Develop standard methodologies",
    objective3: "Implement performance metrics",
    sampleProject: "Sample PMO Implementation",
    sampleDescription: "A sample project with pre-populated data for demonstration",
    createFirstProject: "Create Your First PMO Project",
    firstProjectDesc: "Get started by creating your first PMO implementation project. You can set up project details, track progress across domains, and generate AI-powered recommendations.",
    createSample: "Create Sample Project",
    aiFeature1: "Custom templates based on your current maturity level",
    aiFeature2: "Detailed implementation roadmaps for each domain",
    aiFeature3: "Best practices tailored to your industry and context",
    maturityRadarChart: "Maturity Radar Chart",
    higherValuesIndicateGreaterMaturity: "Higher values indicate greater maturity",
    pmoMaturityAssessment: "PMO Maturity Assessment",
    assessPmoMaturity: "Assess your PMO's maturity level across all domains to identify strengths and improvement opportunities",
    selfAssessment: "Self-Assessment",
    aiGeneratedAssessment: "AI-Generated Assessment",
    notSpecified: "Not specified",
    currentMaturityProfile: "Current Maturity Profile",
    organizationDetails: "Organization Details",
    assessmentType: "Assessment Type",
    currentMaturityProfileDescription: "Your organization's PMO is currently at the",
    currentMaturityProfileDescription2: "level. This assessment will help you identify areas for improvement and create a roadmap for advancing your PMO capabilities.",
    assessmentDate: "Assessment Date",
    selfAssessmentQuestionnaire: "Self-Assessment Questionnaire",
    selfAssessmentDescription: "Rate your PMO's maturity level for each domain. Consider your processes, documentation, measurement capabilities, and continuous improvement efforts when making your assessment.",
    documentation: "Documentation",
    metrics: "Metrics",
    minimalToNone: "Minimal to none",
    basicDocumentation: "Basic documentation",
    comprehensiveDocumentation: "Comprehensive",
    regularlyUpdated: "Regularly updated",
    leadingPractice: "Leading practice",
    adHocOrNone: "Ad-hoc or none",
    basicTracking: "Basic tracking",
    notes: "Notes (Optional)",
    notesPlaceholder: "Add any notes or context about your assessment...",
    createNew: "Create New Project",
    generateAIAssessment: "Generate an AI Assessment",
    aiAssessmentDescription: "Our AI will analyze your domain inputs, project data, and uploaded documents to provide an objective assessment of your PMO's maturity across all domains.",
    aiAssessmentSummary: "AI Assessment Summary",
    aiAssessmentSummaryDescription: "Based on our analysis, your PMO is currently at the",
    keyStrengths: "Key Strengths",
    areasForImprovement: "Areas for Improvement",
    domainSpecificAssessment: "Domain-Specific Assessment",
    maturityProgression: "Maturity Progression",
    recommendations: "Recommendations",
    generatingReport: "Generating Report...",
    exportAssessmentReport: "Export Assessment Report",
    detailedMaturityGuide: "Detailed Maturity Guide",
    maturityModelReference: "Maturity Model Reference",
    generateAssessment: "Generate Assessment",
    generatingAssessment: "Generating Assessment...",
    generatingAssessmentDescription: "Our AI is analyzing your PMO data across all domains. This may take a few moments.",
    
  },
  
  // Domain detail page
  domain: {
    BestPractices: "Best Practices",
    backToDashboard: "Back to Dashboard",
    prevDomain: "Previous Domain",
    nextDomain: "Next Domain",
    viewDomain: "View Domain",
    progress: "Progress",
    tasks: "Tasks & Progress",
    input: "Domain Input & Analysis",
    analyzing: "Analyzing Domain Input",
    processingData: "Our AI is processing your input data...",
    inputStage: "Input",
    inputDesc: "Collect data, assess current state, and gather requirements for this domain.",
    processingStage: "Processing",
    processingDesc: "Analyze data, develop frameworks, and design solutions for this domain.",
    outputStage: "Output",
    outputDesc: "Create deliverables, implement solutions, and establish frameworks for this domain.",
    loading: "Loading domain data...",
    notFound: "Domain not found",
    provideInputFirst: "Please provide domain input data before analyzing",
    aiGeneratedAnalysis: "AI-Generated Analysis for",
    generated: "Generated",
    analysis: "Analysis",
    domainProgress: "Domain Progress (%)",
    templates: "Templates",
    downloadMarkdown: "Download Markdown",
    downloadPdf: "Download PDF",
    generatingPdf: "Generating PDF...",
    generating: "Generating...",
    allTemplates: "All Available Templates",
    markdownFormat: "Markdown",
    words: "words",
    usingTemplates: "Using These Templates",
    templateDescription: "These templates are available in Markdown and PDF formats. Markdown can be imported into document editors, project management tools, or converted to other formats. PDF files are ready for printing or sharing with stakeholders.",
    noTemplates: "No templates available for this domain",
    aiConfigTitle: "AI Analysis Configuration",
    selectDomainPrompt: "Select a domain to analyze with our advanced AI. The analysis will generate comprehensive recommendations and templates based on your organization's specific context.",
    selectDomain: "Select Domain",
    analysisDepth: "Analysis Depth",
    basic: "Basic",
    quickOverview: "Quick overview",
    standard: "Standard",
    balancedAnalysis: "Balanced analysis",
    detailed: "Detailed",
    inDepthReview: "In-depth review",
    comprehensive: "Comprehensive",
    maximumDetail: "Maximum detail",
    geminiPowered: "Gemini AI Powered Analysis",
    advancedAiDesc: "Advanced AI will analyze your inputs and generate tailored recommendations",
    startAnalysis: "Start Analysis"
  },
  
  // Project management
  project: {
    projectName: "Project Name",
    projectNamePlaceholder: "Enterprise PMO Implementation",
    description: "Description",
    descriptionPlaceholder: "Brief description of your PMO implementation project",
    budget: "Budget",
    yourProjects: "Your Projects",
    createProject: "Create Project"
  },
  
  // Sidebar
  sidebar: {
    dashboard: "Dashboard",
    pmoDomains: "PMO Domains",
    tools: "Tools & Assessment",
    resources: "Resources",
    tasks: "Tasks",
    bestPractices: "Best Practices",
    maturityAssessment: "Maturity Assessment",
    assessment: "Assessment",
  },
  
  // Auth pages
  auth: {
    copyright: "© 2025 PMO Builder using AI by Dr. Ahmed Alsenosy"
  },
  
  // Maturity levels
  maturityLevels: {
    initial: {
      label: 'Initial',
      description: 'Processes are ad hoc and chaotic.'
    },
    defined: {
      label: 'Defined',
      description: 'Processes are documented and standardized.'
    },
    managed: {
      label: 'Managed',
      description: 'Processes are measured and controlled.'
    },
    optimized: {
      label: 'Optimized',
      description: 'Focus on continuous improvement.'
    },
    innovative: {
      label: 'Innovative',
      description: 'Driving industry innovation and adaptation.'
    }
  },

  //profile page
  profile: {
    title: "Organization Profile",
    description: "Set up your organization details to personalize your PMO journey",
    organizationName: "Organization Name",
    organizationNamePlaceholder: "Enter your organization name",
    industry: "Industry",
    industryPlaceholder: "Enter your industry",
    pmoMaturityLevel: "PMO Maturity Level",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "Select the maturity level that best describes your current PMO",
    saveProfile: "Save Profile",
    cancel: "Cancel",
    initial: "Initial - Ad hoc processes",
    defined: "Defined - Basic processes established",
    managed: "Managed - Standardized processes",
    optimized: "Optimized - Continuously improving",
    notEstablished: "Not Established - No formal PMO",
  },
  
  //settings page
  settings: {
    title: "Settings",
    description: "Manage your account settings and preferences",
    personal: "Personal",
    subscription: "Subscription",
    notifications: "Notifications",
    security: "Security",
    data: "Data",
    saveProfile: "Save Profile",
    cancel: "Cancel",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "Select the maturity level that best describes your current PMO",
    organizationName: "Organization Name",
    organizationNamePlaceholder: "Enter your organization name",
    industry: "Industry",
    industryPlaceholder: "Enter your industry",
    pmoMaturityLevel: "PMO Maturity Level",
    notEstablished: "Not Established - No formal PMO",
    initial: "Initial - Ad hoc processes",
    defined: "Defined - Basic processes established",
    managed: "Managed - Standardized processes",
    optimized: "Optimized - Continuously improving",
  },

  // Resources page
  resources: {
    title: "Resources",
    noDocuments: "No documents available",
    errorLoading: "Error loading documents",
    downloadError: "Error downloading document",
    uploadNew: "Upload New Document",
    filter: "Filter Documents",
    sortBy: "Sort By",
    search: "Search Documents",
    lastModified: "Last Modified",
    fileName: "File Name",
    fileSize: "File Size",
    taskName: "Task Name",
    projectId: "Project ID"
  },
 // Help page
  help: {
    title: "Help & Support",
    description: "Learn how to use the PMO Domains Application Tool effectively",
    gettingStarted: "Getting Started",
    whatIsPmoDomainsTool: "What is the PMO Domains Tool?",
    whatIsPmoDomainsToolDescription: `The PMO Domains Application Tool helps PMO professionals apply and monitor the five key PMO domains using a structured "Inputs – Processing – Outputs" framework. The tool guides you through each domain's tasks, ensuring best practices and benchmarking against industry standards.`, 
    howToUseThisTool: "How to Use This Tool",
    howToUseThisToolDescription: "The PMO Domains Application Tool is a web-based application that helps organizations implement and improve their PMO capabilities across all domains.",
    canIExportMyData: "Can I export my data?",
    canIExportMyDataDescription: "Yes, you can export your data from the Settings page. This allows you to back up your progress or transfer it to another system.",
    canICustomizeTheToolForMyOrganization: "Can I customize the tool for my organization?",
    canICustomizeTheToolForMyOrganizationDescription: "The tool is designed to be applicable across different organizations and industries. You can add custom notes to each task to tailor it to your specific organizational context.",
    whatIfINotReadyToCompleteAllDomains: "What if I'm not ready to complete all domains?",
    whatIfINotReadyToCompleteAllDomainsDescription: "You can work on domains in any order that makes sense for your organization. The tool will track your progress across all domains, allowing you to focus on your priorities.",
    contactSupport: "Contact Support",
    contactSupportDescription: "If you need additional help or have questions about the PMO Domains Application Tool, please contact our support team.",
    supportContact: "Support Contact",
    supportContactEmail: "Email: support@pmobuilder.ai",
    supportContactPhone: "Phone: (555) 123-4567",
    supportContactHours: "Hours: Monday-Friday, 9am-5pm EST",
    startBySettingUpYourOrganizationProfile: "Start by setting up your organization profile in the Profile section",
    navigateToEachDomainUsingTheSidebarMenu: "Navigate to each domain using the sidebar menu",
    completeTasksInTheRecommendedOrder: "Complete tasks in the recommended order: Input → Processing → Output",
    markTasksAsCompleteAsYouProgress: "Mark tasks as complete as you progress",
    useTheDashboardToTrackYourOverallProgress: "Use the dashboard to track your overall progress",
    referToTheBestPracticesLibraryForGuidance: "Refer to the Best Practices Library for guidance",
    organizationalDevelopmentAndAlignment: "1. Organizational Development and Alignment",
    organizationalDevelopmentAndAlignmentDescription: "This domain focuses on aligning the PMO with organizational strategy and culture to ensure effective project management practices. It includes organizational assessment, stakeholder analysis, and developing alignment strategies.",
    strategicElementsOfThePmo: "2. Strategic Elements of the PMO",
    strategicElementsOfThePmoDescription: "This domain involves developing and implementing strategic frameworks, roadmaps, and governance structures. It includes strategic objectives review, portfolio analysis, and governance structure design.",
    pMODesignAndStructuring: "3. PMO Design and Structuring",
    pMODesignAndStructuringDescription: "This domain focuses on creating the optimal PMO structure, roles, and responsibilities to meet organizational needs. It includes requirements gathering, resource assessment, and service catalog development.",
    pMOOperationAndPerformance: "4. PMO Operation and Performance",
    pMOOperationAndPerformanceDescription: "This domain establishes operational processes, KPIs, and performance metrics for the PMO. It includes process assessment, performance metrics identification, and performance measurement systems.",
    pMOEnhancementAndEffectiveness: "5. PMO Enhancement and Effectiveness",
    pMOEnhancementAndEffectivenessDescription: "This domain focuses on continuously improving PMO services, capabilities, and value delivery. It includes maturity assessment, value delivery analysis, and continuous improvement planning.",
    frequentlyAskedQuestions: "Frequently Asked Questions",
    frequentlyAskedQuestionsDescription: "The PMO Domains Application Tool is a web-based application that helps organizations implement and improve their PMO capabilities across all domains.",
    howToAccessTemplates: "How do I access templates?",
    howToAccessTemplatesDescription: "Templates are available within specific tasks that have template resources. You can also find a collection of templates in the Best Practices Library",
    understandingTheFiveDomains: "Understanding the Five Domains",
  },
    
  subscription: {
    title: "Subscription Management",
    currentPlan: "Current Plan",
    trial: "Trial",
    cancelsAtPeriodEnd: "Cancels at period end",
    upgradePlan: "Upgrade Plan",
    manageSubscription: "Manage Subscription",
    processing: "Processing...",
    billingPeriod: "Billing Period",
    nextBillingDate: "Next Billing Date",
    paymentMethod: "Payment Method",
    projects: "Projects",
    aiAnalysis: "AI Analysis",
    storage: "Storage",
    freePlanLimitations: "Free plan limitations",
    freePlanLimitationsDescription: "You're currently on the Free plan, which has limitations on projects, AI analyses, and storage. Upgrade to Premium or Enterprise for increased limits and additional features.",
    upgradeNow: "Upgrade Now",
    upgradeToGetMore: "Upgrade to Get More",
    premiumPlanBenefits: "Premium Plan Benefits",
    upTo20Projects: "Up to 20 projects (vs. 3 on Free)",
    upTo100AiAnalyses: "100 AI analyses per month (vs. 3 on Free)",
    teamCollaboration: "Team collaboration with up to 5 users",
    prioritySupport: "Priority support",
    enterprisePlanBenefits: "Enterprise Plan Benefits",
    unlimitedProjectsAndAiAnalyses: "Unlimited projects and AI analyses",
    unlimitedTeamMembers: "Unlimited team members",
    whiteLabelingOptions: "White-labeling options",
    dedicatedSupport: "Dedicated support",
    upgradeToEnterprise: "Upgrade to Enterprise",
    unlimited: "Unlimited",
    unknown: "Unknown",
    free: "Free",
    premium: "Premium",
    enterprise: "Enterprise",
    usageAndLimits: "Usage & Limits",
    perMonth: "per month",
    mb: "MB",
    none: "None",
    creditCard: "Credit Card",
    paypal: "PayPal",
    notAvailable: "Not available",
  },
  
  //notifications
  notifications: {
    '1': {
      title: "PMO Maturity Assessment Due",
      description: "Complete your quarterly PMO maturity assessment by Friday.",
      time: "2 days ago",
    },
    '2': {
      title: "Strategic Elements Domain Updated",
      description: "New templates and resources have been added to the Strategic Elements domain.",
      time: "3 days ago",
    },
    '3': {
      title: "Team Meeting: PMO Enhancement",
      description: "Upcoming team meeting to discuss PMO Enhancement strategies.",
      time: "Tomorrow, 10:00 AM",
    },
    '4': {
      title: "New Message from Admin",
      description: "You have a new message regarding your Organization Development domain progress.",
      time: "1 week ago",
    },
    '5': {
      title: "Data Backup Complete",
      description: "Your PMO data has been successfully backed up to cloud storage.",
      time: "2 weeks ago",
    },
    title: "Notifications",
    description: "Stay updated with your PMO activities and important alerts",
    markAllAsRead: "Mark all as read",
    clearAll: "Clear all",
    markAllAsReadDescription: "Mark all notifications as read",
    clearAllDescription: "Clear all notifications",
    markAllAsReadButton: "Mark all as read",
    clearAllButton: "Clear all",
    unread: "Unread",
    all: "All",
    recentNotifications: "Recent Notifications",
    markAsUnread: "Mark as unread",
    markAsRead: "Mark as read",
    viewDetails: "View details",
    loadMore: "Load more notifications",
    customizeNotifications: "Customize how and when you receive notifications about your PMO activities",
    notificationPreferences: "Notification Preferences",
    managePreferences: "Manage Preferences",
    

  },
  // Domain names
  domains: {
    "1": {
      name: "Organizational Development and Alignment",
      description: "Aligning the PMO with organizational strategy and culture to ensure effective project management practices.",
      tasks: {
        "1-input-1": {
          stage: "input",
          title: "Assess Current Competencies",
          description: "Gather data on existing competencies through surveys, interviews, and documentation review.",
          bestPractices: [
            "Use standardized assessment tools to evaluate current competencies",
            "Collect input from multiple organizational levels",
            "Document both technical and soft skill competencies",
            "Identify competency gaps through structured assessment"
          ]
        },
        "1-input-2": {
          stage: "input",
          title: "Assess Organizational Culture",
          description: "Collect data on current organizational culture through surveys, focus groups, and stakeholder interviews.",
          bestPractices: [
            "Conduct culture assessment surveys",
            "Gather feedback from diverse organizational levels",
            "Document cultural enablers and barriers to project management",
            "Collect historical data on cultural change initiatives"
          ]
        },
        "1-input-3": {
          stage: "input",
          title: "Benchmark Against Industry Standards",
          description: "Collect industry benchmarking data and best practices for organizational alignment.",
          bestPractices: [
            "Select relevant industry benchmarks and standards",
            "Gather data from industry reports and publications",
            "Document peer organization practices",
            "Collect metrics for comparative analysis"
          ]
        },
        "1-processing-1": {
          stage: "processing",
          title: "Apply Strategic Analysis Techniques",
          description: "Use strategic analysis tools to develop an integrated strategy with risk management and implementation roadmap.",
          bestPractices: [
            "Apply SWOT analysis to identify strengths and weaknesses",
            "Use gap analysis to identify improvement areas",
            "Apply risk assessment methodologies",
            "Use roadmapping techniques for implementation planning"
          ]
        },
        "1-processing-2": {
          stage: "processing",
          title: "Apply Communication Planning Methodologies",
          description: "Use communication planning techniques to develop stakeholder-specific messaging and feedback mechanisms.",
          bestPractices: [
            "Apply stakeholder analysis techniques",
            "Use communication matrix development methods",
            "Apply message tailoring methodologies",
            "Use KPI development frameworks for communication effectiveness"
          ]
        },
        "1-processing-3": {
          stage: "processing",
          title: "Apply Charter Development Techniques",
          description: "Use charter development methodologies to define PMO scope, authority, and governance structure.",
          bestPractices: [
            "Apply scope definition techniques",
            "Use RACI matrix development methods",
            "Apply governance framework design methodologies",
            "Use authority mapping techniques"
          ],
          templates: ["PMO Charter Template", "RACI Matrix"]
        },
        "1-output-1": {
          stage: "output",
          title: "Deliver Integrated Strategy and Roadmap",
          description: "Produce and implement the integrated strategy with risk management plan and phased implementation roadmap.",
          bestPractices: [
            "Document comprehensive strategy with clear objectives",
            "Create detailed implementation roadmap with milestones",
            "Develop risk management plan with mitigation strategies",
            "Establish strategy review and update mechanisms"
          ]
        },
        "1-output-2": {
          stage: "output",
          title: "Establish PMO Vision, Values and Culture",
          description: "Implement vision statement, core values, and cultural change program with leadership engagement.",
          bestPractices: [
            "Create compelling vision statement aligned with organization",
            "Document core values with behavioral examples",
            "Implement leadership engagement activities",
            "Establish cultural reinforcement mechanisms"
          ],
          templates: ["PMO Vision Statement Template", "Cultural Change Roadmap"]
        },
        "1-output-3": {
          stage: "output",
          title: "Implement PMO Charter and Governance",
          description: "Establish and operationalize PMO charter with defined scope, authority, and governance structure.",
          bestPractices: [
            "Formalize PMO charter with executive approval",
            "Implement governance structure with clear roles",
            "Establish decision-making authorities and processes",
            "Create charter review and update mechanisms"
          ],
          templates: ["PMO Charter Document", "Governance Structure Diagram"]
        },
      },
    },
    "2": {
      name: "Strategic Framework & Governance",
      description: "Creating the optimal PMO structure, roles, and responsibilities to meet organizational needs.",
      tasks: {
        "2-input-1": {
          stage: "input",
          title: "Gather Current State Data",
          description: "Collect data on current project management operations, processes, and performance.",
          bestPractices: [
            "Conduct process documentation review",
            "Gather performance metrics and historical data",
            "Collect stakeholder feedback on current operations",
            "Document existing governance structures"
          ]
        },
        "2-input-2": {
          stage: "input",
          title: "Collect Strategic Alignment Information",
          description: "Gather organizational strategic objectives, priorities, and success criteria.",
          bestPractices: [
            "Review organizational strategic plans",
            "Collect executive leadership priorities",
            "Document business unit objectives",
            "Gather information on strategic initiatives"
          ]
        },
        "2-input-3": {
          stage: "input",
          title: "Identify Capability Requirements",
          description: "Collect data on required capabilities through stakeholder interviews and organizational needs assessment.",
          bestPractices: [
            "Conduct capability needs interviews",
            "Gather industry capability standards",
            "Document capability prioritization criteria",
            "Collect capability maturity benchmarks"
          ]
        },
        "2-processing-1": {
          stage: "processing",
          title: "Apply Mandate Development Methodology",
          description: "Use mandate development techniques to define PMO purpose, authority, and responsibilities.",
          bestPractices: [
            "Apply purpose statement development methods",
            "Use authority mapping techniques",
            "Apply responsibility definition methodologies",
            "Use stakeholder validation approaches"
          ],
          templates: ["PMO Mandate Template", "Executive Sponsorship Agreement"]
        },
        "2-processing-2": {
          stage: "processing",
          title: "Apply Charter Development Framework",
          description: "Use charter development framework to create comprehensive PMO charter with roles and governance structure.",
          bestPractices: [
            "Apply vision and mission statement techniques",
            "Use organizational structure design methods",
            "Apply role definition methodologies",
            "Use governance framework design techniques"
          ],
          templates: ["PMO Charter Template", "Governance Structure Diagram"]
        },
        "2-processing-3": {
          stage: "processing",
          title: "Apply Governance Design Methodology",
          description: "Use governance design techniques to develop decision-making processes and oversight mechanisms.",
          bestPractices: [
            "Apply decision rights mapping techniques",
            "Use escalation path design methods",
            "Apply governance body design methodologies",
            "Use governance communication planning techniques"
          ],
          templates: ["Governance Framework Template", "Decision Rights Matrix"]
        },
        "2-output-1": {
          stage: "output",
          title: "Establish PMO Mandate and Charter",
          description: "Formalize and implement PMO mandate and charter with defined purpose, authority, and responsibilities.",
          bestPractices: [
            "Obtain executive approval for mandate and charter",
            "Communicate mandate to all stakeholders",
            "Implement authority structures defined in charter",
            "Establish charter review and update process"
          ],
          templates: ["Approved PMO Mandate", "Finalized PMO Charter"]
        },
        "2-output-2": {
          stage: "output",
          title: "Implement Governance Framework",
          description: "Establish and operationalize governance framework with decision-making bodies, processes, and oversight mechanisms.",
          bestPractices: [
            "Form governance committees with clear charters",
            "Implement decision-making processes and authorities",
            "Establish governance meeting cadence and agendas",
            "Create governance documentation and reporting system"
          ],
          templates: ["Governance Committee Charter", "Decision Authority Matrix"]
        },
        "2-output-3": {
          stage: "output",
          title: "Develop Strategic Communication Plan",
          description: "Implement comprehensive communication strategy with stakeholder-specific messaging and feedback mechanisms.",
          bestPractices: [
            "Create stakeholder-specific communication materials",
            "Establish regular communication cadence",
            "Implement feedback collection mechanisms",
            "Develop communication effectiveness metrics"
          ],
          templates: ["Strategic Communication Plan", "Stakeholder Messaging Matrix"]
        },      
      }
    },
    "3": {
      name: "PMO Structure & Design",
      description: "Establishing operational processes, KPIs, and performance metrics for the PMO.",
      tasks: {
        "3-input-1": {
          stage: "input",
          title: "Gather Customer Data",
          description: "Collect data on potential PMO customers, their needs, and expectations through surveys and interviews.",
          bestPractices: [
            "Conduct customer needs assessment surveys",
            "Gather stakeholder interview data",
            "Document customer pain points and expectations",
            "Collect service prioritization information"
          ]
        },
        "3-input-2": {
          stage: "input",
          title: "Collect Service Requirement Data",
          description: "Gather detailed requirements for potential PMO services through workshops and requirements sessions.",
          bestPractices: [
            "Conduct service requirements workshops",
            "Document service level expectations",
            "Collect service prioritization criteria",
            "Gather benchmark data on similar services"
          ],
          templates: ["Service Requirements Template", "Customer Needs Assessment"]
        },
        "3-input-3": {
          stage: "input",
          title: "Assess Capability Gaps",
          description: "Collect data on current capabilities and gaps through assessment tools and stakeholder feedback.",
          bestPractices: [
            "Use capability maturity assessment tools",
            "Gather capability benchmark data",
            "Document capability prioritization criteria",
            "Collect resource availability information"
          ]
        },
        "3-processing-1": {
          stage: "processing",
          title: "Apply Persona Development Techniques",
          description: "Use persona development methodologies to create detailed customer personas with needs and expectations.",
          bestPractices: [
            "Apply customer segmentation techniques",
            "Use persona development frameworks",
            "Apply needs analysis methodologies",
            "Use journey mapping techniques"
          ]
        },
        "3-processing-2": {
          stage: "processing",
          title: "Apply Prioritization Frameworks",
          description: "Use prioritization techniques to develop framework for addressing customer needs systematically.",
          bestPractices: [
            "Apply value vs. effort prioritization matrix",
            "Use MoSCoW prioritization technique",
            "Apply weighted scoring methodologies",
            "Use impact mapping techniques"
          ]
        },
        "3-processing-3": {
          stage: "processing",
          title: "Apply Service Catalog Design Methodology",
          description: "Use service catalog design techniques to develop comprehensive service offerings with benefits and advantages.",
          bestPractices: [
            "Apply service definition frameworks",
            "Use service level definition techniques",
            "Apply value proposition development methodologies",
            "Use service categorization techniques"
          ],
          templates: ["Service Catalog Template", "Service Level Agreement Template"]
        },
        "3-output-1": {
          stage: "output",
          title: "Deliver Customer Personas and Journey Maps",
          description: "Create and distribute detailed customer personas and journey maps to guide service design and delivery.",
          bestPractices: [
            "Document comprehensive personas with needs and pain points",
            "Create visual journey maps for key customer interactions",
            "Distribute personas to all service delivery teams",
            "Establish persona update and refinement process"
          ],
          templates: ["Customer Persona Template", "Journey Map Template"]
        },
        "3-output-2": {
          stage: "output",
          title: "Implement Service Catalog and SLAs",
          description: "Launch comprehensive service catalog with service level agreements, processes, and quality standards.",
          bestPractices: [
            "Create detailed service descriptions with value propositions",
            "Establish service level metrics and targets",
            "Implement service request and delivery processes",
            "Create service catalog review and update mechanism"
          ],
          templates: ["Service Catalog Document", "SLA Documentation"]
        },
        "3-output-3": {
          stage: "output",
          title: "Establish Service Prioritization Framework",
          description: "Implement systematic approach for prioritizing and addressing customer needs and service requests.",
          bestPractices: [
            "Create prioritization criteria and scoring system",
            "Implement request intake and evaluation process",
            "Establish resource allocation based on priorities",
            "Develop priority review and adjustment mechanisms"
          ],
          templates: ["Prioritization Matrix", "Service Request Form"]
        },      
      }
    },
    "4": {
      name: "Operational Excellence",
      description: "Ensuring efficient and effective project management processes and tools.",
      tasks: {
        "4-input-1": {
          stage: "input",
          title: "Gather Onboarding Requirements",
          description: "Collect requirements and expectations for customer onboarding process through stakeholder input.",
          bestPractices: [
            "Conduct onboarding needs assessment",
            "Gather stakeholder expectations for onboarding",
            "Document current onboarding challenges",
            "Collect onboarding best practices"
          ]
        },
        "4-input-2": {
          stage: "input",
          title: "Collect Documentation Requirements",
          description: "Gather requirements for process documentation, user guides, and training materials.",
          bestPractices: [
            "Conduct documentation needs assessment",
            "Gather user preferences for documentation formats",
            "Document current documentation gaps",
            "Collect documentation best practices"
          ],
          templates: ["Documentation Requirements Template", "User Guide Outline"]
        },
        "4-input-3": {
          stage: "input",
          title: "Assess Training Needs",
          description: "Collect data on training needs, preferences, and delivery methods through surveys and interviews.",
          bestPractices: [
            "Conduct training needs assessment",
            "Gather learning style preferences",
            "Document knowledge and skill gaps",
            "Collect training effectiveness criteria"
          ]
        },
        "4-processing-1": {
          stage: "processing",
          title: "Apply Quality Management Techniques",
          description: "Use quality management methodologies to develop quality control measures and improvement processes.",
          bestPractices: [
            "Apply quality standards development techniques",
            "Use quality control checkpoint design methods",
            "Apply quality metrics development frameworks",
            "Use continuous improvement methodologies"
          ]
        },
        "4-processing-2": {
          stage: "processing",
          title: "Apply Resource Management Methodologies",
          description: "Use resource management techniques to develop allocation systems and capacity planning processes.",
          bestPractices: [
            "Apply resource capacity planning techniques",
            "Use resource allocation prioritization methods",
            "Apply resource forecasting methodologies",
            "Use resource utilization optimization techniques"
          ],
          templates: ["Resource Management Plan", "Capacity Planning Template"]
        },
        "4-processing-3": {
          stage: "processing",
          title: "Apply Issue Management Framework",
          description: "Use issue management methodologies to develop escalation procedures and resolution processes.",
          bestPractices: [
            "Apply escalation threshold definition techniques",
            "Use escalation path design methods",
            "Apply issue categorization frameworks",
            "Use resolution time standard development techniques"
          ],
          templates: ["Escalation Procedure Template", "Issue Management Framework"]
        },
        "4-output-1": {
          stage: "output",
          title: "Implement Quality Management System",
          description: "Establish comprehensive quality management system with standards, control processes, and improvement mechanisms.",
          bestPractices: [
            "Document quality standards for all services",
            "Implement quality control checkpoints and reviews",
            "Establish quality metrics collection and reporting",
            "Create continuous quality improvement process"
          ],
          templates: ["Quality Standards Document", "Quality Review Checklist"]
        },
        "4-output-2": {
          stage: "output",
          title: "Establish Resource Management System",
          description: "Implement resource management system with capacity planning, allocation processes, and utilization tracking.",
          bestPractices: [
            "Create resource inventory and skills matrix",
            "Implement capacity planning and forecasting process",
            "Establish resource allocation and assignment procedures",
            "Develop resource utilization tracking and reporting"
          ],
          templates: ["Resource Allocation Matrix", "Capacity Planning Dashboard"]
        },
        "4-output-3": {
          stage: "output",
          title: "Deploy Issue Management System",
          description: "Implement comprehensive issue management system with escalation procedures, tracking, and resolution processes.",
          bestPractices: [
            "Establish issue intake and categorization process",
            "Implement escalation paths and notification system",
            "Create issue tracking and status reporting",
            "Develop resolution verification and closure procedures"
          ],
          templates: ["Issue Management Playbook", "Escalation Matrix"]
        },      
      }
    },
    "5": {
      name: "Performance & Improvement",
      description: "Continuously improving PMO services, capabilities, and value delivery.",
      tasks: {
        "5-input-1": {
          stage: "input",
          title: "Gather Maturity Assessment Data",
          description: "Collect data on current PMO maturity through assessment tools, surveys, and stakeholder feedback.",
          bestPractices: [
            "Select appropriate maturity assessment tool",
            "Gather comprehensive assessment data",
            "Document maturity baseline across dimensions",
            "Collect maturity target information"
          ]
        },
        "5-input-2": {
          stage: "input",
          title: "Collect Performance Data",
          description: "Gather current performance metrics, historical trends, and performance targets.",
          bestPractices: [
            "Collect current performance metrics",
            "Gather historical performance data",
            "Document performance targets and thresholds",
            "Collect performance benchmark information"
          ]
        },
        "5-input-3": {
          stage: "input",
          title: "Assess Value Measurement Approaches",
          description: "Collect data on potential value metrics, measurement approaches, and value demonstration methods.",
          bestPractices: [
            "Gather value metric options",
            "Collect value measurement methodologies",
            "Document value perception from stakeholders",
            "Assess current value demonstration approaches"
          ]
        },
        "5-processing-1": {
          stage: "processing",
          title: "Apply Maturity Roadmapping Techniques",
          description: "Use maturity roadmapping methodologies to develop enhancement plan with milestones and metrics.",
          bestPractices: [
            "Apply maturity gap analysis techniques",
            "Use capability prioritization methods",
            "Apply milestone development frameworks",
            "Use metric definition techniques"
          ]
        },
        "5-processing-2": {
          stage: "processing",
          title: "Apply Change Management Methodologies",
          description: "Use change management techniques to develop implementation approach for maturity initiatives.",
          bestPractices: [
            "Apply stakeholder impact analysis techniques",
            "Use resistance management methods",
            "Apply communication planning frameworks",
            "Use adoption measurement techniques"
          ],
          templates: ["Change Management Plan", "Stakeholder Engagement Plan"]
        },
        "5-processing-3": {
          stage: "processing",
          title: "Apply Continuous Improvement Frameworks",
          description: "Use continuous improvement methodologies to develop systematic improvement processes.",
          bestPractices: [
            "Apply improvement opportunity identification techniques",
            "Use improvement prioritization methods",
            "Apply implementation planning frameworks",
            "Use effectiveness measurement techniques"
          ]
        },
        "5-output-1": {
          stage: "output",
          title: "Implement Maturity Enhancement Roadmap",
          description: "Establish and execute comprehensive maturity enhancement roadmap with milestones, metrics, and review processes.",
          bestPractices: [
            "Document detailed maturity enhancement plan",
            "Implement milestone tracking and reporting",
            "Establish maturity metric collection and analysis",
            "Create regular maturity review and adjustment process"
          ],
          templates: ["Maturity Enhancement Roadmap", "Maturity Metrics Dashboard"]
        },
        "5-output-2": {
          stage: "output",
          title: "Establish Value Measurement System",
          description: "Implement comprehensive value measurement system with metrics, reporting, and demonstration mechanisms.",
          bestPractices: [
            "Define and implement value metrics and KPIs",
            "Create value data collection and analysis process",
            "Establish value reporting and visualization",
            "Develop value demonstration case studies"
          ],
          templates: ["Value Measurement Framework", "Value Dashboard"]
        },
        "5-output-3": {
          stage: "output",
          title: "Deploy Continuous Improvement Program",
          description: "Implement systematic continuous improvement program with identification, prioritization, and implementation processes.",
          bestPractices: [
            "Establish improvement opportunity identification process",
            "Create improvement prioritization and selection system",
            "Implement improvement tracking and reporting",
            "Develop improvement effectiveness measurement"
          ],
          templates: ["Continuous Improvement Playbook", "Improvement Tracking System"]
        },      
      }
    },
    "6": {
      name: "Capability Development",
      description: "Developing and managing the human aspects of the PMO including competency, training, and leadership.",
      tasks: {
        "6-input-1": {
          stage: "input",
          title: "Gather Decision-Making Data",
          description: "Collect data on current decision-making processes, data utilization, and improvement opportunities.",
          bestPractices: [
            "Document current decision-making processes",
            "Assess data utilization in decisions",
            "Identify decision-making bottlenecks",
            "Gather decision quality metrics"
          ]
        },
        "6-input-2": {
          stage: "input",
          title: "Assess Competency Requirements",
          description: "Collect data on required competencies, current capabilities, and development needs.",
          bestPractices: [
            "Document role-specific competency requirements",
            "Assess current competency levels",
            "Identify critical competency gaps",
            "Gather development preference information"
          ],
          templates: ["Competency Assessment Template", "Development Needs Analysis"]
        },
        "6-input-3": {
          stage: "input",
          title: "Collect Skills Assessment Data",
          description: "Gather comprehensive skills data through assessments, self-evaluations, and manager feedback.",
          bestPractices: [
            "Use standardized skills assessment tools",
            "Gather self-assessment data",
            "Collect manager assessment input",
            "Document skills prioritization criteria"
          ]
        },
        "6-processing-1": {
          stage: "processing",
          title: "Apply Training Program Design Methodology",
          description: "Use training design techniques to develop comprehensive training and certification programs.",
          bestPractices: [
            "Apply learning objective development techniques",
            "Use curriculum design methodologies",
            "Apply learning modality selection frameworks",
            "Use training effectiveness measurement design"
          ]
        },
        "6-processing-2": {
          stage: "processing",
          title: "Apply Innovation Framework Development",
          description: "Use innovation framework techniques to develop processes for fostering innovation and problem-solving.",
          bestPractices: [
            "Apply innovation process design methodologies",
            "Use idea generation technique selection",
            "Apply idea evaluation framework development",
            "Use innovation incentive system design"
          ]
        },
        "6-processing-3": {
          stage: "processing",
          title: "Apply Knowledge Management Techniques",
          description: "Use knowledge management methodologies to design knowledge-sharing platform and communities of practice.",
          bestPractices: [
            "Apply knowledge repository design techniques",
            "Use knowledge categorization frameworks",
            "Apply community of practice design methodologies",
            "Use knowledge contribution incentive design"
          ]
        },
        "6-output-1": {
          stage: "output",
          title: "Implement Competency Development Framework",
          description: "Establish comprehensive competency framework with assessment, development paths, and certification programs.",
          bestPractices: [
            "Document role-specific competency requirements",
            "Create competency assessment and tracking system",
            "Implement development paths for each competency area",
            "Establish certification and recognition program"
          ],
          templates: ["Competency Framework Document", "Development Path Guide"]
        },
        "6-output-2": {
          stage: "output",
          title: "Deploy Innovation and Problem-Solving System",
          description: "Implement structured innovation program with idea generation, evaluation, and implementation processes.",
          bestPractices: [
            "Establish idea generation and collection system",
            "Create idea evaluation and selection process",
            "Implement innovation implementation support",
            "Develop innovation recognition and incentives"
          ],
          templates: ["Innovation Process Playbook", "Idea Evaluation Matrix"]
        },
        "6-output-3": {
          stage: "output",
          title: "Establish Knowledge Management System",
          description: "Implement comprehensive knowledge management system with repository, sharing mechanisms, and communities of practice.",
          bestPractices: [
            "Create knowledge repository with categorization system",
            "Establish knowledge contribution processes",
            "Form communities of practice with clear charters",
            "Implement knowledge sharing events and activities"
          ],
          templates: ["Knowledge Management Guide", "Community of Practice Charter"]
        }
      }
    }
  },

  // Tasks
  tasks: {
    tasks: "Tasks",
    manageAndTrackYourPmoImplementationTasks: "Manage and track your PMO implementation tasks",
    allTasks: "All Tasks",
    completed: "Completed",
    incomplete: "Incomplete",
    progress: "Progress",
    total: "Total",
    rate: "Rate",
    addCustomTask: "Add Custom Task",
    searchTasks: "Search tasks...",
    filters: "Filters",
    clear: "Clear",
    allDomains: "All Domains",
    allStages: "All Stages",
    input: "Input",
    processing: "Processing",
    output: "Output",
    domain: "Domain",
    stage: "Stage",
    status: "Status",
    clearFilters: "Clear Filters",
    noTasksFound: "No tasks found",
    noTasksMatchFilters: "No tasks match your current filters. Try adjusting or clearing your filters.",
    noTasksAvailable: "No tasks available. Start by creating a new task.",
    taskManagementTips: "Task Management Tips",
    taskManagementTipsDescription: "Prioritize tasks based on your PMO maturity level and organizational goals. Complete the Input stage tasks first before moving to Processing and Output stages for the best results.",
    viewBestPractices: "View Best Practices",
    relatedDocuments: "Related Documents",
    viewFullContent: "View Full Content",
    generateTaskOutput: "Generate Task Output",
    templates: "Templates",
    templateForStandardizedImplementation: "Template for standardized implementation",
    viewTemplate: "View Template",
    bestPractices: "Best Practices",
    priority: "Priority",
    targetCompletionDate: "Target Completion Date",
    assignedTo: "Assigned To",
    estimatedHours: "Estimated Hours",
    attachments: "Attachments",
    notes: "Notes",
    availableTemplates: "Available Templates",
    purpose: "Purpose",
    templateForStandardized: "This template provides a structured framework for implementing and managing",
    withinYourPMO: "processes within your PMO",
    overview: "Overview",
    download: "Download",
    useTemplate: "Use Template",
    close: "Close",
    save:"Save",
    template: `
## Template Sections

### 1. Introduction
- Purpose and objectives
- Scope and applicability
- Key stakeholders

### 2. Process Framework
- Methodology overview
- Key activities and deliverables
- Roles and responsibilities

### 3. Implementation Guide
- Step-by-step instructions
- Best practices and guidelines
- Common challenges and solutions

### 4. Monitoring and Control
- Key performance indicators
- Quality assurance measures
- Reporting requirements

### 5. Continuous Improvement
- Feedback mechanisms
- Review process
- Update procedures

## Appendices
- Related templates and tools
- Reference materials
- Glossary of terms

---

*This template is part of the PMO Builder library. Customize it to fit your organization's specific needs.*`,
  }
};

// Translation keys organized by component/page
// English translations
const en = {
  // Common components
  common: {
    pleaseWait: "Please wait while we prepare your content.",
    Complete : "Complete",
    search: "Search",
    save: "Save",
    saveAssessment: "Save Assessment",
    saved: "Saved!",
    showLess: "Show less",
    showMore: "Show more",
    cancel: "Cancel",
    edit: "Edit",
    delete: "Delete",
    close: "Close",
    loading: "Loading...",
    submit: "Submit",
    active: "Active",
    back: "Back",
    spent: "Spent",
    used: "Used",
    onTrack: "On Track",
    viewDetails: "View Details",
    tasks: "Tasks",
    domains: "Domains",
    budget: "Budget",
    daysLeft: "days left",
    next: "Next",
    progress: "Progress",
    notifications: "Notifications",
    help: "Help",
    settings: "Settings",
    profile: "Profile",
    signOut: "Sign Out",
    dashboard: "Dashboard",
    export: "Export",
    import: "Import",
    share: "Share",
    days: "days",
    darkMode: "Dark Mode",
    lightMode: "Light Mode",
    confirm: "Confirm",
    remainingTokens: "Remaining Tokens"
  },
  
  // Header component
  header: {
    search: "Search...",
    myTeams: "My Teams",
    invitations: "Invitations",
    setupProfile: "Setup Profile",
    subscription: "Subscription",
    settings: "Settings",
    adminPanel: "Admin Panel",
    signOut: "Sign out",
    profile: "Profile",
  },
  
  // Dashboard page
  dashboard: {
    title: "Dashboard",
    subtitle: "Build and track your PMO across all essential domains",
    budget: "Budget",
    editDetails: "Edit Details",
    exportReport: "Export Report",
    access: "Access",
    timelineProgress: "Timeline Progress",
    budgetUtilization: "Budget Utilization",
    projectStatus: "Project Status",
    maturityAssessment: "Maturity Assessment",
    keyObjectives: "Key Objectives",
    stakeholders: "Stakeholders",
    overallProgress: "Overall Progress",
    completedTasks: "Completed Tasks",
    domainProcessComparison:"Domain Progress Comparison",
    organization: "Organization",
    industry: "Industry",
    dashboardCustomization: "Dashboard Customization",
    displayLayout: "Display Layout",
    gridView: "Grid View",
    listView: "List View",
    widgetSelection: "Widget Selection",
    assessMaturityLevel: "Assess Your Maturity Level",
    maturityLevel: "Maturity Level",
    progressOverview: "Progress Overview",
    tasksStatus: "Tasks Status",
    domains: "Domains",
    chartsAnalytics: "Charts & Analytics",
    pmoMaturityLevel: "PMO Maturity Level",
    pmoDomains: "PMO Domains",
    aiAnalysis: "Accelerate with AI",
    aiDescription: "Let our advanced AI analyze your PMO data and generate comprehensive recommendations tailored to your organization's unique needs.",
    tryAiAnalysis: "Try AI Analysis",
    viewAll: "View all",
    of: "of",
    tasksCompleted: "tasks completed",
    notSet: "Not set",
    updateProfile: "Update profile",
    viewAllTasks: "View all tasks",
    nextSteps: "Next Steps",
    uploadDocuments: "Upload documents",
    analysisDocuments: "Upload supporting documents for AI analysis",
    analysisDocumentsDesc: "Enhance AI recommendations with your organization's context",
    completePmoMaturityAssessment: "Complete a PMO Maturity Assessment",
    getInsightsAboutPmoMaturityLevel: "Get insights about your PMO's current maturity level",
    reviewPractices: "Review best practices",
    explorePractices: "Explore the best practices library for guidance",
    viewResources: "View resources",
    goToAssessment: "Go to assessment",
    objective1: "Establish PMO governance framework",
    objective2: "Develop standard methodologies",
    objective3: "Implement performance metrics",
    sampleProject: "Sample PMO Implementation",
    sampleDescription: "A sample project with pre-populated data for demonstration",
    createFirstProject: "Create Your First PMO Project",
    firstProjectDesc: "Get started by creating your first PMO implementation project. You can set up project details, track progress across domains, and generate AI-powered recommendations.",
    createSample: "Create Sample Project",
    aiFeature1: "Custom templates based on your current maturity level",
    aiFeature2: "Detailed implementation roadmaps for each domain",
    aiFeature3: "Best practices tailored to your industry and context",
    maturityRadarChart: "Maturity Radar Chart",
    higherValuesIndicateGreaterMaturity: "Higher values indicate greater maturity",
    pmoMaturityAssessment: "PMO Maturity Assessment",
    assessPmoMaturity: "Assess your PMO's maturity level across all domains to identify strengths and improvement opportunities",
    selfAssessment: "Self-Assessment",
    aiGeneratedAssessment: "AI-Generated Assessment",
    notSpecified: "Not specified",
    currentMaturityProfile: "Current Maturity Profile",
    organizationDetails: "Organization Details",
    assessmentType: "Assessment Type",
    currentMaturityProfileDescription: "Your organization's PMO is currently at the",
    currentMaturityProfileDescription2: "level. This assessment will help you identify areas for improvement and create a roadmap for advancing your PMO capabilities.",
    assessmentDate: "Assessment Date",
    selfAssessmentQuestionnaire: "Self-Assessment Questionnaire",
    selfAssessmentDescription: "Rate your PMO's maturity level for each domain. Consider your processes, documentation, measurement capabilities, and continuous improvement efforts when making your assessment.",
    documentation: "Documentation",
    metrics: "Metrics",
    minimalToNone: "Minimal to none",
    basicDocumentation: "Basic documentation",
    comprehensiveDocumentation: "Comprehensive",
    regularlyUpdated: "Regularly updated",
    leadingPractice: "Leading practice",
    adHocOrNone: "Ad-hoc or none",
    basicTracking: "Basic tracking",
    notes: "Notes (Optional)",
    notesPlaceholder: "Add any notes or context about your assessment...",
    createNew: "Create New Project",
    generateAIAssessment: "Generate an AI Assessment",
    aiAssessmentDescription: "Our AI will analyze your domain inputs, project data, and uploaded documents to provide an objective assessment of your PMO's maturity across all domains.",
    aiAssessmentSummary: "AI Assessment Summary",
    aiAssessmentSummaryDescription: "Based on our analysis, your PMO is currently at the",
    keyStrengths: "Key Strengths",
    areasForImprovement: "Areas for Improvement",
    domainSpecificAssessment: "Domain-Specific Assessment",
    maturityProgression: "Maturity Progression",
    recommendations: "Recommendations",
    generatingReport: "Generating Report...",
    exportAssessmentReport: "Export Assessment Report",
    detailedMaturityGuide: "Detailed Maturity Guide",
    maturityModelReference: "Maturity Model Reference",
    generateAssessment: "Generate Assessment",
    generatingAssessment: "Generating Assessment...",
    generatingAssessmentDescription: "Our AI is analyzing your PMO data across all domains. This may take a few moments.",
    
  },
  
  // Domain detail page
  domain: {
    BestPractices: "Best Practices",
    backToDashboard: "Back to Dashboard",
    prevDomain: "Previous Domain",
    nextDomain: "Next Domain",
    viewDomain: "View Domain",
    progress: "Progress",
    tasks: "Tasks & Progress",
    input: "Domain Input & Analysis",
    analyzing: "Analyzing Domain Input",
    processingData: "Our AI is processing your input data...",
    inputStage: "Input",
    inputDesc: "Collect data, assess current state, and gather requirements for this domain.",
    processingStage: "Processing",
    processingDesc: "Analyze data, develop frameworks, and design solutions for this domain.",
    outputStage: "Output",
    outputDesc: "Create deliverables, implement solutions, and establish frameworks for this domain.",
    loading: "Loading domain data...",
    notFound: "Domain not found",
    provideInputFirst: "Please provide domain input data before analyzing",
    aiGeneratedAnalysis: "AI-Generated Analysis for",
    generated: "Generated",
    analysis: "Analysis",
    domainProgress: "Domain Progress (%)",
    templates: "Templates",
    downloadMarkdown: "Download Markdown",
    downloadPdf: "Download PDF",
    generatingPdf: "Generating PDF...",
    generating: "Generating...",
    allTemplates: "All Available Templates",
    markdownFormat: "Markdown",
    words: "words",
    usingTemplates: "Using These Templates",
    templateDescription: "These templates are available in Markdown and PDF formats. Markdown can be imported into document editors, project management tools, or converted to other formats. PDF files are ready for printing or sharing with stakeholders.",
    noTemplates: "No templates available for this domain",
    aiConfigTitle: "AI Analysis Configuration",
    selectDomainPrompt: "Select a domain to analyze with our advanced AI. The analysis will generate comprehensive recommendations and templates based on your organization's specific context.",
    selectDomain: "Select Domain",
    analysisDepth: "Analysis Depth",
    basic: "Basic",
    quickOverview: "Quick overview",
    standard: "Standard",
    balancedAnalysis: "Balanced analysis",
    detailed: "Detailed",
    inDepthReview: "In-depth review",
    comprehensive: "Comprehensive",
    maximumDetail: "Maximum detail",
    geminiPowered: "Gemini AI Powered Analysis",
    advancedAiDesc: "Advanced AI will analyze your inputs and generate tailored recommendations",
    startAnalysis: "Start Analysis"
  },
  
  // Project management
  project: {
    projectName: "Project Name",
    projectNamePlaceholder: "Enterprise PMO Implementation",
    description: "Description",
    descriptionPlaceholder: "Brief description of your PMO implementation project",
    budget: "Budget",
    yourProjects: "Your Projects",
    createProject: "Create Project"
  },
  
  // Sidebar
  sidebar: {
    dashboard: "Dashboard",
    pmoDomains: "PMO Domains",
    tools: "Tools & Assessment",
    resources: "Resources",
    tasks: "Tasks",
    bestPractices: "Best Practices",
    maturityAssessment: "Maturity Assessment",
    assessment: "Assessment",
  },
  
  // Auth pages
  auth: {
    copyright: "© 2025 PMO Builder using AI by Dr. Ahmed Alsenosy"
  },
  
  // Maturity levels
  maturityLevels: {
    initial: {
      label: 'Initial',
      description: 'Processes are ad hoc and chaotic.'
    },
    defined: {
      label: 'Defined',
      description: 'Processes are documented and standardized.'
    },
    managed: {
      label: 'Managed',
      description: 'Processes are measured and controlled.'
    },
    optimized: {
      label: 'Optimized',
      description: 'Focus on continuous improvement.'
    },
    innovative: {
      label: 'Innovative',
      description: 'Driving industry innovation and adaptation.'
    }
  },

  //profile page
  profile: {
    title: "Organization Profile",
    description: "Set up your organization details to personalize your PMO journey",
    organizationName: "Organization Name",
    organizationNamePlaceholder: "Enter your organization name",
    industry: "Industry",
    industryPlaceholder: "Enter your industry",
    pmoMaturityLevel: "PMO Maturity Level",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "Select the maturity level that best describes your current PMO",
    saveProfile: "Save Profile",
    cancel: "Cancel",
    initial: "Initial - Ad hoc processes",
    defined: "Defined - Basic processes established",
    managed: "Managed - Standardized processes",
    optimized: "Optimized - Continuously improving",
    notEstablished: "Not Established - No formal PMO",
  },
  
  //settings page
  settings: {
    title: "Settings",
    description: "Manage your account settings and preferences",
    personal: "Personal",
    subscription: "Subscription",
    notifications: "Notifications",
    security: "Security",
    data: "Data",
    saveProfile: "Save Profile",
    cancel: "Cancel",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "Select the maturity level that best describes your current PMO",
    organizationName: "Organization Name",
    organizationNamePlaceholder: "Enter your organization name",
    industry: "Industry",
    industryPlaceholder: "Enter your industry",
    pmoMaturityLevel: "PMO Maturity Level",
    notEstablished: "Not Established - No formal PMO",
    initial: "Initial - Ad hoc processes",
    defined: "Defined - Basic processes established",
    managed: "Managed - Standardized processes",
    optimized: "Optimized - Continuously improving",
  },

  // Resources page
  resources: {
    title: "Resources",
    noDocuments: "No documents available",
    errorLoading: "Error loading documents",
    downloadError: "Error downloading document",
    uploadNew: "Upload New Document",
    filter: "Filter Documents",
    sortBy: "Sort By",
    search: "Search Documents",
    lastModified: "Last Modified",
    fileName: "File Name",
    fileSize: "File Size",
    taskName: "Task Name",
    projectId: "Project ID"
  },
 // Help page
  help: {
    title: "Help & Support",
    description: "Learn how to use the PMO Domains Application Tool effectively",
    gettingStarted: "Getting Started",
    whatIsPmoDomainsTool: "What is the PMO Domains Tool?",
    whatIsPmoDomainsToolDescription: `The PMO Domains Application Tool helps PMO professionals apply and monitor the five key PMO domains using a structured "Inputs – Processing – Outputs" framework. The tool guides you through each domain's tasks, ensuring best practices and benchmarking against industry standards.`, 
    howToUseThisTool: "How to Use This Tool",
    howToUseThisToolDescription: "The PMO Domains Application Tool is a web-based application that helps organizations implement and improve their PMO capabilities across all domains.",
    canIExportMyData: "Can I export my data?",
    canIExportMyDataDescription: "Yes, you can export your data from the Settings page. This allows you to back up your progress or transfer it to another system.",
    canICustomizeTheToolForMyOrganization: "Can I customize the tool for my organization?",
    canICustomizeTheToolForMyOrganizationDescription: "The tool is designed to be applicable across different organizations and industries. You can add custom notes to each task to tailor it to your specific organizational context.",
    whatIfINotReadyToCompleteAllDomains: "What if I'm not ready to complete all domains?",
    whatIfINotReadyToCompleteAllDomainsDescription: "You can work on domains in any order that makes sense for your organization. The tool will track your progress across all domains, allowing you to focus on your priorities.",
    contactSupport: "Contact Support",
    contactSupportDescription: "If you need additional help or have questions about the PMO Domains Application Tool, please contact our support team.",
    supportContact: "Support Contact",
    supportContactEmail: "Email: support@pmobuilder.ai",
    supportContactPhone: "Phone: (555) 123-4567",
    supportContactHours: "Hours: Monday-Friday, 9am-5pm EST",
    startBySettingUpYourOrganizationProfile: "Start by setting up your organization profile in the Profile section",
    navigateToEachDomainUsingTheSidebarMenu: "Navigate to each domain using the sidebar menu",
    completeTasksInTheRecommendedOrder: "Complete tasks in the recommended order: Input → Processing → Output",
    markTasksAsCompleteAsYouProgress: "Mark tasks as complete as you progress",
    useTheDashboardToTrackYourOverallProgress: "Use the dashboard to track your overall progress",
    referToTheBestPracticesLibraryForGuidance: "Refer to the Best Practices Library for guidance",
    organizationalDevelopmentAndAlignment: "1. Organizational Development and Alignment",
    organizationalDevelopmentAndAlignmentDescription: "This domain focuses on aligning the PMO with organizational strategy and culture to ensure effective project management practices. It includes organizational assessment, stakeholder analysis, and developing alignment strategies.",
    strategicElementsOfThePmo: "2. Strategic Elements of the PMO",
    strategicElementsOfThePmoDescription: "This domain involves developing and implementing strategic frameworks, roadmaps, and governance structures. It includes strategic objectives review, portfolio analysis, and governance structure design.",
    pMODesignAndStructuring: "3. PMO Design and Structuring",
    pMODesignAndStructuringDescription: "This domain focuses on creating the optimal PMO structure, roles, and responsibilities to meet organizational needs. It includes requirements gathering, resource assessment, and service catalog development.",
    pMOOperationAndPerformance: "4. PMO Operation and Performance",
    pMOOperationAndPerformanceDescription: "This domain establishes operational processes, KPIs, and performance metrics for the PMO. It includes process assessment, performance metrics identification, and performance measurement systems.",
    pMOEnhancementAndEffectiveness: "5. PMO Enhancement and Effectiveness",
    pMOEnhancementAndEffectivenessDescription: "This domain focuses on continuously improving PMO services, capabilities, and value delivery. It includes maturity assessment, value delivery analysis, and continuous improvement planning.",
    frequentlyAskedQuestions: "Frequently Asked Questions",
    frequentlyAskedQuestionsDescription: "The PMO Domains Application Tool is a web-based application that helps organizations implement and improve their PMO capabilities across all domains.",
    howToAccessTemplates: "How do I access templates?",
    howToAccessTemplatesDescription: "Templates are available within specific tasks that have template resources. You can also find a collection of templates in the Best Practices Library",
    understandingTheFiveDomains: "Understanding the Five Domains",
  },
    
  subscription: {
    title: "Subscription Management",
    currentPlan: "Current Plan",
    trial: "Trial",
    cancelsAtPeriodEnd: "Cancels at period end",
    upgradePlan: "Upgrade Plan",
    manageSubscription: "Manage Subscription",
    processing: "Processing...",
    billingPeriod: "Billing Period",
    nextBillingDate: "Next Billing Date",
    paymentMethod: "Payment Method",
    projects: "Projects",
    aiAnalysis: "AI Analysis",
    storage: "Storage",
    freePlanLimitations: "Free plan limitations",
    freePlanLimitationsDescription: "You're currently on the Free plan, which has limitations on projects, AI analyses, and storage. Upgrade to Premium or Enterprise for increased limits and additional features.",
    upgradeNow: "Upgrade Now",
    upgradeToGetMore: "Upgrade to Get More",
    premiumPlanBenefits: "Premium Plan Benefits",
    upTo20Projects: "Up to 20 projects (vs. 3 on Free)",
    upTo100AiAnalyses: "100 AI analyses per month (vs. 3 on Free)",
    teamCollaboration: "Team collaboration with up to 5 users",
    prioritySupport: "Priority support",
    enterprisePlanBenefits: "Enterprise Plan Benefits",
    unlimitedProjectsAndAiAnalyses: "Unlimited projects and AI analyses",
    unlimitedTeamMembers: "Unlimited team members",
    whiteLabelingOptions: "White-labeling options",
    dedicatedSupport: "Dedicated support",
    upgradeToEnterprise: "Upgrade to Enterprise",
    unlimited: "Unlimited",
    unknown: "Unknown",
    free: "Free",
    premium: "Premium",
    enterprise: "Enterprise",
    usageAndLimits: "Usage & Limits",
    perMonth: "per month",
    mb: "MB",
    none: "None",
    creditCard: "Credit Card",
    paypal: "PayPal",
    notAvailable: "Not available",
  },
  
  //notifications
  notifications: {
    '1': {
      title: "PMO Maturity Assessment Due",
      description: "Complete your quarterly PMO maturity assessment by Friday.",
      time: "2 days ago",
    },
    '2': {
      title: "Strategic Elements Domain Updated",
      description: "New templates and resources have been added to the Strategic Elements domain.",
      time: "3 days ago",
    },
    '3': {
      title: "Team Meeting: PMO Enhancement",
      description: "Upcoming team meeting to discuss PMO Enhancement strategies.",
      time: "Tomorrow, 10:00 AM",
    },
    '4': {
      title: "New Message from Admin",
      description: "You have a new message regarding your Organization Development domain progress.",
      time: "1 week ago",
    },
    '5': {
      title: "Data Backup Complete",
      description: "Your PMO data has been successfully backed up to cloud storage.",
      time: "2 weeks ago",
    },
    title: "Notifications",
    description: "Stay updated with your PMO activities and important alerts",
    markAllAsRead: "Mark all as read",
    clearAll: "Clear all",
    markAllAsReadDescription: "Mark all notifications as read",
    clearAllDescription: "Clear all notifications",
    markAllAsReadButton: "Mark all as read",
    clearAllButton: "Clear all",
    unread: "Unread",
    all: "All",
    recentNotifications: "Recent Notifications",
    markAsUnread: "Mark as unread",
    markAsRead: "Mark as read",
    viewDetails: "View details",
    loadMore: "Load more notifications",
    customizeNotifications: "Customize how and when you receive notifications about your PMO activities",
    notificationPreferences: "Notification Preferences",
    managePreferences: "Manage Preferences",
    

  },
  // Domain names
  domains: {
    "1": {
      name: "Organizational Development and Alignment",
      description: "Aligning the PMO with organizational strategy and culture to ensure effective project management practices.",
      tasks: {
        "1-input-1": {
          stage: "input",
          title: "Assess Current Competencies",
          description: "Gather data on existing competencies through surveys, interviews, and documentation review.",
          bestPractices: [
            "Use standardized assessment tools to evaluate current competencies",
            "Collect input from multiple organizational levels",
            "Document both technical and soft skill competencies",
            "Identify competency gaps through structured assessment"
          ]
        },
        "1-input-2": {
          stage: "input",
          title: "Assess Organizational Culture",
          description: "Collect data on current organizational culture through surveys, focus groups, and stakeholder interviews.",
          bestPractices: [
            "Conduct culture assessment surveys",
            "Gather feedback from diverse organizational levels",
            "Document cultural enablers and barriers to project management",
            "Collect historical data on cultural change initiatives"
          ]
        },
        "1-input-3": {
          stage: "input",
          title: "Benchmark Against Industry Standards",
          description: "Collect industry benchmarking data and best practices for organizational alignment.",
          bestPractices: [
            "Select relevant industry benchmarks and standards",
            "Gather data from industry reports and publications",
            "Document peer organization practices",
            "Collect metrics for comparative analysis"
          ]
        },
        "1-processing-1": {
          stage: "processing",
          title: "Apply Strategic Analysis Techniques",
          description: "Use strategic analysis tools to develop an integrated strategy with risk management and implementation roadmap.",
          bestPractices: [
            "Apply SWOT analysis to identify strengths and weaknesses",
            "Use gap analysis to identify improvement areas",
            "Apply risk assessment methodologies",
            "Use roadmapping techniques for implementation planning"
          ]
        },
        "1-processing-2": {
          stage: "processing",
          title: "Apply Communication Planning Methodologies",
          description: "Use communication planning techniques to develop stakeholder-specific messaging and feedback mechanisms.",
          bestPractices: [
            "Apply stakeholder analysis techniques",
            "Use communication matrix development methods",
            "Apply message tailoring methodologies",
            "Use KPI development frameworks for communication effectiveness"
          ]
        },
        "1-processing-3": {
          stage: "processing",
          title: "Apply Charter Development Techniques",
          description: "Use charter development methodologies to define PMO scope, authority, and governance structure.",
          bestPractices: [
            "Apply scope definition techniques",
            "Use RACI matrix development methods",
            "Apply governance framework design methodologies",
            "Use authority mapping techniques"
          ],
          templates: ["PMO Charter Template", "RACI Matrix"]
        },
        "1-output-1": {
          stage: "output",
          title: "Deliver Integrated Strategy and Roadmap",
          description: "Produce and implement the integrated strategy with risk management plan and phased implementation roadmap.",
          bestPractices: [
            "Document comprehensive strategy with clear objectives",
            "Create detailed implementation roadmap with milestones",
            "Develop risk management plan with mitigation strategies",
            "Establish strategy review and update mechanisms"
          ]
        },
        "1-output-2": {
          stage: "output",
          title: "Establish PMO Vision, Values and Culture",
          description: "Implement vision statement, core values, and cultural change program with leadership engagement.",
          bestPractices: [
            "Create compelling vision statement aligned with organization",
            "Document core values with behavioral examples",
            "Implement leadership engagement activities",
            "Establish cultural reinforcement mechanisms"
          ],
          templates: ["PMO Vision Statement Template", "Cultural Change Roadmap"]
        },
        "1-output-3": {
          stage: "output",
          title: "Implement PMO Charter and Governance",
          description: "Establish and operationalize PMO charter with defined scope, authority, and governance structure.",
          bestPractices: [
            "Formalize PMO charter with executive approval",
            "Implement governance structure with clear roles",
            "Establish decision-making authorities and processes",
            "Create charter review and update mechanisms"
          ],
          templates: ["PMO Charter Document", "Governance Structure Diagram"]
        },
      },
    },
    "2": {
      name: "Strategic Framework & Governance",
      description: "Creating the optimal PMO structure, roles, and responsibilities to meet organizational needs.",
      tasks: {
        "2-input-1": {
          stage: "input",
          title: "Gather Current State Data",
          description: "Collect data on current project management operations, processes, and performance.",
          bestPractices: [
            "Conduct process documentation review",
            "Gather performance metrics and historical data",
            "Collect stakeholder feedback on current operations",
            "Document existing governance structures"
          ]
        },
        "2-input-2": {
          stage: "input",
          title: "Collect Strategic Alignment Information",
          description: "Gather organizational strategic objectives, priorities, and success criteria.",
          bestPractices: [
            "Review organizational strategic plans",
            "Collect executive leadership priorities",
            "Document business unit objectives",
            "Gather information on strategic initiatives"
          ]
        },
        "2-input-3": {
          stage: "input",
          title: "Identify Capability Requirements",
          description: "Collect data on required capabilities through stakeholder interviews and organizational needs assessment.",
          bestPractices: [
            "Conduct capability needs interviews",
            "Gather industry capability standards",
            "Document capability prioritization criteria",
            "Collect capability maturity benchmarks"
          ]
        },
        "2-processing-1": {
          stage: "processing",
          title: "Apply Mandate Development Methodology",
          description: "Use mandate development techniques to define PMO purpose, authority, and responsibilities.",
          bestPractices: [
            "Apply purpose statement development methods",
            "Use authority mapping techniques",
            "Apply responsibility definition methodologies",
            "Use stakeholder validation approaches"
          ],
          templates: ["PMO Mandate Template", "Executive Sponsorship Agreement"]
        },
        "2-processing-2": {
          stage: "processing",
          title: "Apply Charter Development Framework",
          description: "Use charter development framework to create comprehensive PMO charter with roles and governance structure.",
          bestPractices: [
            "Apply vision and mission statement techniques",
            "Use organizational structure design methods",
            "Apply role definition methodologies",
            "Use governance framework design techniques"
          ],
          templates: ["PMO Charter Template", "Governance Structure Diagram"]
        },
        "2-processing-3": {
          stage: "processing",
          title: "Apply Governance Design Methodology",
          description: "Use governance design techniques to develop decision-making processes and oversight mechanisms.",
          bestPractices: [
            "Apply decision rights mapping techniques",
            "Use escalation path design methods",
            "Apply governance body design methodologies",
            "Use governance communication planning techniques"
          ],
          templates: ["Governance Framework Template", "Decision Rights Matrix"]
        },
        "2-output-1": {
          stage: "output",
          title: "Establish PMO Mandate and Charter",
          description: "Formalize and implement PMO mandate and charter with defined purpose, authority, and responsibilities.",
          bestPractices: [
            "Obtain executive approval for mandate and charter",
            "Communicate mandate to all stakeholders",
            "Implement authority structures defined in charter",
            "Establish charter review and update process"
          ],
          templates: ["Approved PMO Mandate", "Finalized PMO Charter"]
        },
        "2-output-2": {
          stage: "output",
          title: "Implement Governance Framework",
          description: "Establish and operationalize governance framework with decision-making bodies, processes, and oversight mechanisms.",
          bestPractices: [
            "Form governance committees with clear charters",
            "Implement decision-making processes and authorities",
            "Establish governance meeting cadence and agendas",
            "Create governance documentation and reporting system"
          ],
          templates: ["Governance Committee Charter", "Decision Authority Matrix"]
        },
        "2-output-3": {
          stage: "output",
          title: "Develop Strategic Communication Plan",
          description: "Implement comprehensive communication strategy with stakeholder-specific messaging and feedback mechanisms.",
          bestPractices: [
            "Create stakeholder-specific communication materials",
            "Establish regular communication cadence",
            "Implement feedback collection mechanisms",
            "Develop communication effectiveness metrics"
          ],
          templates: ["Strategic Communication Plan", "Stakeholder Messaging Matrix"]
        },      
      }
    },
    "3": {
      name: "PMO Structure & Design",
      description: "Establishing operational processes, KPIs, and performance metrics for the PMO.",
      tasks: {
        "3-input-1": {
          stage: "input",
          title: "Gather Customer Data",
          description: "Collect data on potential PMO customers, their needs, and expectations through surveys and interviews.",
          bestPractices: [
            "Conduct customer needs assessment surveys",
            "Gather stakeholder interview data",
            "Document customer pain points and expectations",
            "Collect service prioritization information"
          ]
        },
        "3-input-2": {
          stage: "input",
          title: "Collect Service Requirement Data",
          description: "Gather detailed requirements for potential PMO services through workshops and requirements sessions.",
          bestPractices: [
            "Conduct service requirements workshops",
            "Document service level expectations",
            "Collect service prioritization criteria",
            "Gather benchmark data on similar services"
          ],
          templates: ["Service Requirements Template", "Customer Needs Assessment"]
        },
        "3-input-3": {
          stage: "input",
          title: "Assess Capability Gaps",
          description: "Collect data on current capabilities and gaps through assessment tools and stakeholder feedback.",
          bestPractices: [
            "Use capability maturity assessment tools",
            "Gather capability benchmark data",
            "Document capability prioritization criteria",
            "Collect resource availability information"
          ]
        },
        "3-processing-1": {
          stage: "processing",
          title: "Apply Persona Development Techniques",
          description: "Use persona development methodologies to create detailed customer personas with needs and expectations.",
          bestPractices: [
            "Apply customer segmentation techniques",
            "Use persona development frameworks",
            "Apply needs analysis methodologies",
            "Use journey mapping techniques"
          ]
        },
        "3-processing-2": {
          stage: "processing",
          title: "Apply Prioritization Frameworks",
          description: "Use prioritization techniques to develop framework for addressing customer needs systematically.",
          bestPractices: [
            "Apply value vs. effort prioritization matrix",
            "Use MoSCoW prioritization technique",
            "Apply weighted scoring methodologies",
            "Use impact mapping techniques"
          ]
        },
        "3-processing-3": {
          stage: "processing",
          title: "Apply Service Catalog Design Methodology",
          description: "Use service catalog design techniques to develop comprehensive service offerings with benefits and advantages.",
          bestPractices: [
            "Apply service definition frameworks",
            "Use service level definition techniques",
            "Apply value proposition development methodologies",
            "Use service categorization techniques"
          ],
          templates: ["Service Catalog Template", "Service Level Agreement Template"]
        },
        "3-output-1": {
          stage: "output",
          title: "Deliver Customer Personas and Journey Maps",
          description: "Create and distribute detailed customer personas and journey maps to guide service design and delivery.",
          bestPractices: [
            "Document comprehensive personas with needs and pain points",
            "Create visual journey maps for key customer interactions",
            "Distribute personas to all service delivery teams",
            "Establish persona update and refinement process"
          ],
          templates: ["Customer Persona Template", "Journey Map Template"]
        },
        "3-output-2": {
          stage: "output",
          title: "Implement Service Catalog and SLAs",
          description: "Launch comprehensive service catalog with service level agreements, processes, and quality standards.",
          bestPractices: [
            "Create detailed service descriptions with value propositions",
            "Establish service level metrics and targets",
            "Implement service request and delivery processes",
            "Create service catalog review and update mechanism"
          ],
          templates: ["Service Catalog Document", "SLA Documentation"]
        },
        "3-output-3": {
          stage: "output",
          title: "Establish Service Prioritization Framework",
          description: "Implement systematic approach for prioritizing and addressing customer needs and service requests.",
          bestPractices: [
            "Create prioritization criteria and scoring system",
            "Implement request intake and evaluation process",
            "Establish resource allocation based on priorities",
            "Develop priority review and adjustment mechanisms"
          ],
          templates: ["Prioritization Matrix", "Service Request Form"]
        },      
      }
// Translation keys organized by component/page
// English translations
const en = {
  // Common components
  common: {
    pleaseWait: "Please wait while we prepare your content.",
    Complete : "Complete",
    search: "Search",
    save: "Save",
    saveAssessment: "Save Assessment",
    saved: "Saved!",
    showLess: "Show less",
    showMore: "Show more",
    cancel: "Cancel",
    edit: "Edit",
    delete: "Delete",
    close: "Close",
    loading: "Loading...",
    submit: "Submit",
    active: "Active",
    back: "Back",
    spent: "Spent",
    used: "Used",
    onTrack: "On Track",
    viewDetails: "View Details",
    tasks: "Tasks",
    domains: "Domains",
    budget: "Budget",
    daysLeft: "days left",
    next: "Next",
    progress: "Progress",
    notifications: "Notifications",
    help: "Help",
    settings: "Settings",
    profile: "Profile",
    signOut: "Sign Out",
    dashboard: "Dashboard",
    export: "Export",
    import: "Import",
    share: "Share",
    days: "days",
    darkMode: "Dark Mode",
    lightMode: "Light Mode",
    confirm: "Confirm",
    remainingTokens: "Remaining Tokens"
  },
  
  // Header component
  header: {
    search: "Search...",
    myTeams: "My Teams",
    invitations: "Invitations",
    setupProfile: "Setup Profile",
    subscription: "Subscription",
    settings: "Settings",
    adminPanel: "Admin Panel",
    signOut: "Sign out",
    profile: "Profile",
  },
  
  // Dashboard page
  dashboard: {
    title: "Dashboard",
    subtitle: "Build and track your PMO across all essential domains",
    budget: "Budget",
    editDetails: "Edit Details",
    exportReport: "Export Report",
    access: "Access",
    timelineProgress: "Timeline Progress",
    budgetUtilization: "Budget Utilization",
    projectStatus: "Project Status",
    maturityAssessment: "Maturity Assessment",
    keyObjectives: "Key Objectives",
    stakeholders: "Stakeholders",
    overallProgress: "Overall Progress",
    completedTasks: "Completed Tasks",
    domainProcessComparison:"Domain Progress Comparison",
    organization: "Organization",
    industry: "Industry",
    dashboardCustomization: "Dashboard Customization",
    displayLayout: "Display Layout",
    gridView: "Grid View",
    listView: "List View",
    widgetSelection: "Widget Selection",
    assessMaturityLevel: "Assess Your Maturity Level",
    maturityLevel: "Maturity Level",
    progressOverview: "Progress Overview",
    tasksStatus: "Tasks Status",
    domains: "Domains",
    chartsAnalytics: "Charts & Analytics",
    pmoMaturityLevel: "PMO Maturity Level",
    pmoDomains: "PMO Domains",
    aiAnalysis: "Accelerate with AI",
    aiDescription: "Let our advanced AI analyze your PMO data and generate comprehensive recommendations tailored to your organization's unique needs.",
    tryAiAnalysis: "Try AI Analysis",
    viewAll: "View all",
    of: "of",
    tasksCompleted: "tasks completed",
    notSet: "Not set",
    updateProfile: "Update profile",
    viewAllTasks: "View all tasks",
    nextSteps: "Next Steps",
    uploadDocuments: "Upload documents",
    analysisDocuments: "Upload supporting documents for AI analysis",
    analysisDocumentsDesc: "Enhance AI recommendations with your organization's context",
    completePmoMaturityAssessment: "Complete a PMO Maturity Assessment",
    getInsightsAboutPmoMaturityLevel: "Get insights about your PMO's current maturity level",
    reviewPractices: "Review best practices",
    explorePractices: "Explore the best practices library for guidance",
    viewResources: "View resources",
    goToAssessment: "Go to assessment",
    objective1: "Establish PMO governance framework",
    objective2: "Develop standard methodologies",
    objective3: "Implement performance metrics",
    sampleProject: "Sample PMO Implementation",
    sampleDescription: "A sample project with pre-populated data for demonstration",
    createFirstProject: "Create Your First PMO Project",
    firstProjectDesc: "Get started by creating your first PMO implementation project. You can set up project details, track progress across domains, and generate AI-powered recommendations.",
    createSample: "Create Sample Project",
    aiFeature1: "Custom templates based on your current maturity level",
    aiFeature2: "Detailed implementation roadmaps for each domain",
    aiFeature3: "Best practices tailored to your industry and context",
    maturityRadarChart: "Maturity Radar Chart",
    higherValuesIndicateGreaterMaturity: "Higher values indicate greater maturity",
    pmoMaturityAssessment: "PMO Maturity Assessment",
    assessPmoMaturity: "Assess your PMO's maturity level across all domains to identify strengths and improvement opportunities",
    selfAssessment: "Self-Assessment",
    aiGeneratedAssessment: "AI-Generated Assessment",
    notSpecified: "Not specified",
    currentMaturityProfile: "Current Maturity Profile",
    organizationDetails: "Organization Details",
    assessmentType: "Assessment Type",
    currentMaturityProfileDescription: "Your organization's PMO is currently at the",
    currentMaturityProfileDescription2: "level. This assessment will help you identify areas for improvement and create a roadmap for advancing your PMO capabilities.",
    assessmentDate: "Assessment Date",
    selfAssessmentQuestionnaire: "Self-Assessment Questionnaire",
    selfAssessmentDescription: "Rate your PMO's maturity level for each domain. Consider your processes, documentation, measurement capabilities, and continuous improvement efforts when making your assessment.",
    documentation: "Documentation",
    metrics: "Metrics",
    minimalToNone: "Minimal to none",
    basicDocumentation: "Basic documentation",
    comprehensiveDocumentation: "Comprehensive",
    regularlyUpdated: "Regularly updated",
    leadingPractice: "Leading practice",
    adHocOrNone: "Ad-hoc or none",
    basicTracking: "Basic tracking",
    notes: "Notes (Optional)",
    notesPlaceholder: "Add any notes or context about your assessment...",
    createNew: "Create New Project",
    generateAIAssessment: "Generate an AI Assessment",
    aiAssessmentDescription: "Our AI will analyze your domain inputs, project data, and uploaded documents to provide an objective assessment of your PMO's maturity across all domains.",
    aiAssessmentSummary: "AI Assessment Summary",
    aiAssessmentSummaryDescription: "Based on our analysis, your PMO is currently at the",
    keyStrengths: "Key Strengths",
    areasForImprovement: "Areas for Improvement",
    domainSpecificAssessment: "Domain-Specific Assessment",
    maturityProgression: "Maturity Progression",
    recommendations: "Recommendations",
    generatingReport: "Generating Report...",
    exportAssessmentReport: "Export Assessment Report",
    detailedMaturityGuide: "Detailed Maturity Guide",
    maturityModelReference: "Maturity Model Reference",
    generateAssessment: "Generate Assessment",
    generatingAssessment: "Generating Assessment...",
    generatingAssessmentDescription: "Our AI is analyzing your PMO data across all domains. This may take a few moments.",
    
  },
  
  // Domain detail page
  domain: {
    BestPractices: "Best Practices",
    backToDashboard: "Back to Dashboard",
    prevDomain: "Previous Domain",
    nextDomain: "Next Domain",
    viewDomain: "View Domain",
    progress: "Progress",
    tasks: "Tasks & Progress",
    input: "Domain Input & Analysis",
    analyzing: "Analyzing Domain Input",
    processingData: "Our AI is processing your input data...",
    inputStage: "Input",
    inputDesc: "Collect data, assess current state, and gather requirements for this domain.",
    processingStage: "Processing",
    processingDesc: "Analyze data, develop frameworks, and design solutions for this domain.",
    outputStage: "Output",
    outputDesc: "Create deliverables, implement solutions, and establish frameworks for this domain.",
    loading: "Loading domain data...",
    notFound: "Domain not found",
    provideInputFirst: "Please provide domain input data before analyzing",
    aiGeneratedAnalysis: "AI-Generated Analysis for",
    generated: "Generated",
    analysis: "Analysis",
    domainProgress: "Domain Progress (%)",
    templates: "Templates",
    downloadMarkdown: "Download Markdown",
    downloadPdf: "Download PDF",
    generatingPdf: "Generating PDF...",
    generating: "Generating...",
    allTemplates: "All Available Templates",
    markdownFormat: "Markdown",
    words: "words",
    usingTemplates: "Using These Templates",
    templateDescription: "These templates are available in Markdown and PDF formats. Markdown can be imported into document editors, project management tools, or converted to other formats. PDF files are ready for printing or sharing with stakeholders.",
    noTemplates: "No templates available for this domain",
    aiConfigTitle: "AI Analysis Configuration",
    selectDomainPrompt: "Select a domain to analyze with our advanced AI. The analysis will generate comprehensive recommendations and templates based on your organization's specific context.",
    selectDomain: "Select Domain",
    analysisDepth: "Analysis Depth",
    basic: "Basic",
    quickOverview: "Quick overview",
    standard: "Standard",
    balancedAnalysis: "Balanced analysis",
    detailed: "Detailed",
    inDepthReview: "In-depth review",
    comprehensive: "Comprehensive",
    maximumDetail: "Maximum detail",
    geminiPowered: "Gemini AI Powered Analysis",
    advancedAiDesc: "Advanced AI will analyze your inputs and generate tailored recommendations",
    startAnalysis: "Start Analysis"
  },
  
  // Project management
  project: {
    projectName: "Project Name",
    projectNamePlaceholder: "Enterprise PMO Implementation",
    description: "Description",
    descriptionPlaceholder: "Brief description of your PMO implementation project",
    budget: "Budget",
    yourProjects: "Your Projects",
    createProject: "Create Project"
  },
  
  // Sidebar
  sidebar: {
    dashboard: "Dashboard",
    pmoDomains: "PMO Domains",
    tools: "Tools & Assessment",
    resources: "Resources",
    tasks: "Tasks",
    bestPractices: "Best Practices",
    maturityAssessment: "Maturity Assessment",
    assessment: "Assessment",
  },
  
  // Auth pages
  auth: {
    copyright: "© 2025 PMO Builder using AI by Dr. Ahmed Alsenosy"
  },
  
  // Maturity levels
  maturityLevels: {
    initial: {
      label: 'Initial',
      description: 'Processes are ad hoc and chaotic.'
    },
    defined: {
      label: 'Defined',
      description: 'Processes are documented and standardized.'
    },
    managed: {
      label: 'Managed',
      description: 'Processes are measured and controlled.'
    },
    optimized: {
      label: 'Optimized',
      description: 'Focus on continuous improvement.'
    },
    innovative: {
      label: 'Innovative',
      description: 'Driving industry innovation and adaptation.'
    }
  },

  //profile page
  profile: {
    title: "Organization Profile",
    description: "Set up your organization details to personalize your PMO journey",
    organizationName: "Organization Name",
    organizationNamePlaceholder: "Enter your organization name",
    industry: "Industry",
    industryPlaceholder: "Enter your industry",
    pmoMaturityLevel: "PMO Maturity Level",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "Select the maturity level that best describes your current PMO",
    saveProfile: "Save Profile",
    cancel: "Cancel",
    initial: "Initial - Ad hoc processes",
    defined: "Defined - Basic processes established",
    managed: "Managed - Standardized processes",
    optimized: "Optimized - Continuously improving",
    notEstablished: "Not Established - No formal PMO",
  },
  
  //settings page
  settings: {
    title: "Settings",
    description: "Manage your account settings and preferences",
    personal: "Personal",
    subscription: "Subscription",
    notifications: "Notifications",
    security: "Security",
    data: "Data",
    saveProfile: "Save Profile",
    cancel: "Cancel",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "Select the maturity level that best describes your current PMO",
    organizationName: "Organization Name",
    organizationNamePlaceholder: "Enter your organization name",
    industry: "Industry",
    industryPlaceholder: "Enter your industry",
    pmoMaturityLevel: "PMO Maturity Level",
    notEstablished: "Not Established - No formal PMO",
    initial: "Initial - Ad hoc processes",
    defined: "Defined - Basic processes established",
    managed: "Managed - Standardized processes",
    optimized: "Optimized - Continuously improving",
  },

  // Resources page
  resources: {
    title: "Resources",
    noDocuments: "No documents available",
    errorLoading: "Error loading documents",
    downloadError: "Error downloading document",
    uploadNew: "Upload New Document",
    filter: "Filter Documents",
    sortBy: "Sort By",
    search: "Search Documents",
    lastModified: "Last Modified",
    fileName: "File Name",
    fileSize: "File Size",
    taskName: "Task Name",
    projectId: "Project ID"
  },
 // Help page
  help: {
    title: "Help & Support",
    description: "Learn how to use the PMO Domains Application Tool effectively",
    gettingStarted: "Getting Started",
    whatIsPmoDomainsTool: "What is the PMO Domains Tool?",
    whatIsPmoDomainsToolDescription: `The PMO Domains Application Tool helps PMO professionals apply and monitor the five key PMO domains using a structured "Inputs – Processing – Outputs" framework. The tool guides you through each domain's tasks, ensuring best practices and benchmarking against industry standards.`, 
    howToUseThisTool: "How to Use This Tool",
    howToUseThisToolDescription: "The PMO Domains Application Tool is a web-based application that helps organizations implement and improve their PMO capabilities across all domains.",
    canIExportMyData: "Can I export my data?",
    canIExportMyDataDescription: "Yes, you can export your data from the Settings page. This allows you to back up your progress or transfer it to another system.",
    canICustomizeTheToolForMyOrganization: "Can I customize the tool for my organization?",
    canICustomizeTheToolForMyOrganizationDescription: "The tool is designed to be applicable across different organizations and industries. You can add custom notes to each task to tailor it to your specific organizational context.",
    whatIfINotReadyToCompleteAllDomains: "What if I'm not ready to complete all domains?",
    whatIfINotReadyToCompleteAllDomainsDescription: "You can work on domains in any order that makes sense for your organization. The tool will track your progress across all domains, allowing you to focus on your priorities.",
    contactSupport: "Contact Support",
    contactSupportDescription: "If you need additional help or have questions about the PMO Domains Application Tool, please contact our support team.",
    supportContact: "Support Contact",
    supportContactEmail: "Email: support@pmobuilder.ai",
    supportContactPhone: "Phone: (555) 123-4567",
    supportContactHours: "Hours: Monday-Friday, 9am-5pm EST",
    startBySettingUpYourOrganizationProfile: "Start by setting up your organization profile in the Profile section",
    navigateToEachDomainUsingTheSidebarMenu: "Navigate to each domain using the sidebar menu",
    completeTasksInTheRecommendedOrder: "Complete tasks in the recommended order: Input → Processing → Output",
    markTasksAsCompleteAsYouProgress: "Mark tasks as complete as you progress",
    useTheDashboardToTrackYourOverallProgress: "Use the dashboard to track your overall progress",
    referToTheBestPracticesLibraryForGuidance: "Refer to the Best Practices Library for guidance",
    organizationalDevelopmentAndAlignment: "1. Organizational Development and Alignment",
    organizationalDevelopmentAndAlignmentDescription: "This domain focuses on aligning the PMO with organizational strategy and culture to ensure effective project management practices. It includes organizational assessment, stakeholder analysis, and developing alignment strategies.",
    strategicElementsOfThePmo: "2. Strategic Elements of the PMO",
    strategicElementsOfThePmoDescription: "This domain involves developing and implementing strategic frameworks, roadmaps, and governance structures. It includes strategic objectives review, portfolio analysis, and governance structure design.",
    pMODesignAndStructuring: "3. PMO Design and Structuring",
    pMODesignAndStructuringDescription: "This domain focuses on creating the optimal PMO structure, roles, and responsibilities to meet organizational needs. It includes requirements gathering, resource assessment, and service catalog development.",
    pMOOperationAndPerformance: "4. PMO Operation and Performance",
    pMOOperationAndPerformanceDescription: "This domain establishes operational processes, KPIs, and performance metrics for the PMO. It includes process assessment, performance metrics identification, and performance measurement systems.",
    pMOEnhancementAndEffectiveness: "5. PMO Enhancement and Effectiveness",
    pMOEnhancementAndEffectivenessDescription: "This domain focuses on continuously improving PMO services, capabilities, and value delivery. It includes maturity assessment, value delivery analysis, and continuous improvement planning.",
    frequentlyAskedQuestions: "Frequently Asked Questions",
    frequentlyAskedQuestionsDescription: "The PMO Domains Application Tool is a web-based application that helps organizations implement and improve their PMO capabilities across all domains.",
    howToAccessTemplates: "How do I access templates?",
    howToAccessTemplatesDescription: "Templates are available within specific tasks that have template resources. You can also find a collection of templates in the Best Practices Library",
    understandingTheFiveDomains: "Understanding the Five Domains",
  },
    
  subscription: {
    title: "Subscription Management",
    currentPlan: "Current Plan",
    trial: "Trial",
    cancelsAtPeriodEnd: "Cancels at period end",
    upgradePlan: "Upgrade Plan",
    manageSubscription: "Manage Subscription",
    processing: "Processing...",
    billingPeriod: "Billing Period",
    nextBillingDate: "Next Billing Date",
    paymentMethod: "Payment Method",
    projects: "Projects",
    aiAnalysis: "AI Analysis",
    storage: "Storage",
    freePlanLimitations: "Free plan limitations",
    freePlanLimitationsDescription: "You're currently on the Free plan, which has limitations on projects, AI analyses, and storage. Upgrade to Premium or Enterprise for increased limits and additional features.",
    upgradeNow: "Upgrade Now",
    upgradeToGetMore: "Upgrade to Get More",
    premiumPlanBenefits: "Premium Plan Benefits",
    upTo20Projects: "Up to 20 projects (vs. 3 on Free)",
    upTo100AiAnalyses: "100 AI analyses per month (vs. 3 on Free)",
    teamCollaboration: "Team collaboration with up to 5 users",
    prioritySupport: "Priority support",
    enterprisePlanBenefits: "Enterprise Plan Benefits",
    unlimitedProjectsAndAiAnalyses: "Unlimited projects and AI analyses",
    unlimitedTeamMembers: "Unlimited team members",
    whiteLabelingOptions: "White-labeling options",
    dedicatedSupport: "Dedicated support",
    upgradeToEnterprise: "Upgrade to Enterprise",
    unlimited: "Unlimited",
    unknown: "Unknown",
    free: "Free",
    premium: "Premium",
    enterprise: "Enterprise",
    usageAndLimits: "Usage & Limits",
    perMonth: "per month",
    mb: "MB",
    none: "None",
    creditCard: "Credit Card",
    paypal: "PayPal",
    notAvailable: "Not available",
  },
  
  //notifications
  notifications: {
    '1': {
      title: "PMO Maturity Assessment Due",
      description: "Complete your quarterly PMO maturity assessment by Friday.",
      time: "2 days ago",
    },
    '2': {
      title: "Strategic Elements Domain Updated",
      description: "New templates and resources have been added to the Strategic Elements domain.",
      time: "3 days ago",
    },
    '3': {
      title: "Team Meeting: PMO Enhancement",
      description: "Upcoming team meeting to discuss PMO Enhancement strategies.",
      time: "Tomorrow, 10:00 AM",
    },
    '4': {
      title: "New Message from Admin",
      description: "You have a new message regarding your Organization Development domain progress.",
      time: "1 week ago",
    },
    '5': {
      title: "Data Backup Complete",
      description: "Your PMO data has been successfully backed up to cloud storage.",
      time: "2 weeks ago",
    },
    title: "Notifications",
    description: "Stay updated with your PMO activities and important alerts",
    markAllAsRead: "Mark all as read",
    clearAll: "Clear all",
    markAllAsReadDescription: "Mark all notifications as read",
    clearAllDescription: "Clear all notifications",
    markAllAsReadButton: "Mark all as read",
    clearAllButton: "Clear all",
    unread: "Unread",
    all: "All",
    recentNotifications: "Recent Notifications",
    markAsUnread: "Mark as unread",
    markAsRead: "Mark as read",
    viewDetails: "View details",
    loadMore: "Load more notifications",
    customizeNotifications: "Customize how and when you receive notifications about your PMO activities",
    notificationPreferences: "Notification Preferences",
    managePreferences: "Manage Preferences",
    

  },
  // Domain names
  domains: {
    "1": {
      name: "Organizational Development and Alignment",
      description: "Aligning the PMO with organizational strategy and culture to ensure effective project management practices.",
      tasks: {
        "1-input-1": {
          stage: "input",
          title: "Assess Current Competencies",
          description: "Gather data on existing competencies through surveys, interviews, and documentation review.",
          bestPractices: [
            "Use standardized assessment tools to evaluate current competencies",
            "Collect input from multiple organizational levels",
            "Document both technical and soft skill competencies",
            "Identify competency gaps through structured assessment"
          ]
        },
        "1-input-2": {
          stage: "input",
          title: "Assess Organizational Culture",
          description: "Collect data on current organizational culture through surveys, focus groups, and stakeholder interviews.",
          bestPractices: [
            "Conduct culture assessment surveys",
            "Gather feedback from diverse organizational levels",
            "Document cultural enablers and barriers to project management",
            "Collect historical data on cultural change initiatives"
          ]
        },
        "1-input-3": {
          stage: "input",
          title: "Benchmark Against Industry Standards",
          description: "Collect industry benchmarking data and best practices for organizational alignment.",
          bestPractices: [
            "Select relevant industry benchmarks and standards",
            "Gather data from industry reports and publications",
            "Document peer organization practices",
            "Collect metrics for comparative analysis"
          ]
        },
        "1-processing-1": {
          stage: "processing",
          title: "Apply Strategic Analysis Techniques",
          description: "Use strategic analysis tools to develop an integrated strategy with risk management and implementation roadmap.",
          bestPractices: [
            "Apply SWOT analysis to identify strengths and weaknesses",
            "Use gap analysis to identify improvement areas",
            "Apply risk assessment methodologies",
            "Use roadmapping techniques for implementation planning"
          ]
        },
        "1-processing-2": {
          stage: "processing",
          title: "Apply Communication Planning Methodologies",
          description: "Use communication planning techniques to develop stakeholder-specific messaging and feedback mechanisms.",
          bestPractices: [
            "Apply stakeholder analysis techniques",
            "Use communication matrix development methods",
            "Apply message tailoring methodologies",
            "Use KPI development frameworks for communication effectiveness"
          ]
        },
        "1-processing-3": {
          stage: "processing",
          title: "Apply Charter Development Techniques",
          description: "Use charter development methodologies to define PMO scope, authority, and governance structure.",
          bestPractices: [
            "Apply scope definition techniques",
            "Use RACI matrix development methods",
            "Apply governance framework design methodologies",
            "Use authority mapping techniques"
          ],
          templates: ["PMO Charter Template", "RACI Matrix"]
        },
        "1-output-1": {
          stage: "output",
          title: "Deliver Integrated Strategy and Roadmap",
          description: "Produce and implement the integrated strategy with risk management plan and phased implementation roadmap.",
          bestPractices: [
            "Document comprehensive strategy with clear objectives",
            "Create detailed implementation roadmap with milestones",
            "Develop risk management plan with mitigation strategies",
            "Establish strategy review and update mechanisms"
          ]
        },
        "1-output-2": {
          stage: "output",
          title: "Establish PMO Vision, Values and Culture",
          description: "Implement vision statement, core values, and cultural change program with leadership engagement.",
          bestPractices: [
            "Create compelling vision statement aligned with organization",
            "Document core values with behavioral examples",
            "Implement leadership engagement activities",
            "Establish cultural reinforcement mechanisms"
          ],
          templates: ["PMO Vision Statement Template", "Cultural Change Roadmap"]
        },
        "1-output-3": {
          stage: "output",
          title: "Implement PMO Charter and Governance",
          description: "Establish and operationalize PMO charter with defined scope, authority, and governance structure.",
          bestPractices: [
            "Formalize PMO charter with executive approval",
            "Implement governance structure with clear roles",
            "Establish decision-making authorities and processes",
            "Create charter review and update mechanisms"
          ],
          templates: ["PMO Charter Document", "Governance Structure Diagram"]
        },
      },
    },
    "2": {
      name: "Strategic Framework & Governance",
      description: "Creating the optimal PMO structure, roles, and responsibilities to meet organizational needs.",
      tasks: {
        "2-input-1": {
          stage: "input",
          title: "Gather Current State Data",
          description: "Collect data on current project management operations, processes, and performance.",
          bestPractices: [
            "Conduct process documentation review",
            "Gather performance metrics and historical data",
            "Collect stakeholder feedback on current operations",
            "Document existing governance structures"
          ]
        },
        "2-input-2": {
          stage: "input",
          title: "Collect Strategic Alignment Information",
          description: "Gather organizational strategic objectives, priorities, and success criteria.",
          bestPractices: [
            "Review organizational strategic plans",
            "Collect executive leadership priorities",
            "Document business unit objectives",
            "Gather information on strategic initiatives"
          ]
        },
        "2-input-3": {
          stage: "input",
          title: "Identify Capability Requirements",
          description: "Collect data on required capabilities through stakeholder interviews and organizational needs assessment.",
          bestPractices: [
            "Conduct capability needs interviews",
            "Gather industry capability standards",
            "Document capability prioritization criteria",
            "Collect capability maturity benchmarks"
          ]
        },
        "2-processing-1": {
          stage: "processing",
          title: "Apply Mandate Development Methodology",
          description: "Use mandate development techniques to define PMO purpose, authority, and responsibilities.",
          bestPractices: [
            "Apply purpose statement development methods",
            "Use authority mapping techniques",
            "Apply responsibility definition methodologies",
            "Use stakeholder validation approaches"
          ],
          templates: ["PMO Mandate Template", "Executive Sponsorship Agreement"]
        },
        "2-processing-2": {
          stage: "processing",
          title: "Apply Charter Development Framework",
          description: "Use charter development framework to create comprehensive PMO charter with roles and governance structure.",
          bestPractices: [
            "Apply vision and mission statement techniques",
            "Use organizational structure design methods",
            "Apply role definition methodologies",
            "Use governance framework design techniques"
          ],
          templates: ["PMO Charter Template", "Governance Structure Diagram"]
        },
        "2-processing-3": {
          stage: "processing",
          title: "Apply Governance Design Methodology",
          description: "Use governance design techniques to develop decision-making processes and oversight mechanisms.",
          bestPractices: [
            "Apply decision rights mapping techniques",
            "Use escalation path design methods",
            "Apply governance body design methodologies",
            "Use governance communication planning techniques"
          ],
          templates: ["Governance Framework Template", "Decision Rights Matrix"]
        },
        "2-output-1": {
          stage: "output",
          title: "Establish PMO Mandate and Charter",
          description: "Formalize and implement PMO mandate and charter with defined purpose, authority, and responsibilities.",
          bestPractices: [
            "Obtain executive approval for mandate and charter",
            "Communicate mandate to all stakeholders",
            "Implement authority structures defined in charter",
            "Establish charter review and update process"
          ],
          templates: ["Approved PMO Mandate", "Finalized PMO Charter"]
        },
        "2-output-2": {
          stage: "output",
          title: "Implement Governance Framework",
          description: "Establish and operationalize governance framework with decision-making bodies, processes, and oversight mechanisms.",
          bestPractices: [
            "Form governance committees with clear charters",
            "Implement decision-making processes and authorities",
            "Establish governance meeting cadence and agendas",
            "Create governance documentation and reporting system"
          ],
          templates: ["Governance Committee Charter", "Decision Authority Matrix"]
        },
        "2-output-3": {
          stage: "output",
          title: "Develop Strategic Communication Plan",
          description: "Implement comprehensive communication strategy with stakeholder-specific messaging and feedback mechanisms.",
          bestPractices: [
            "Create stakeholder-specific communication materials",
            "Establish regular communication cadence",
            "Implement feedback collection mechanisms",
            "Develop communication effectiveness metrics"
          ],
          templates: ["Strategic Communication Plan", "Stakeholder Messaging Matrix"]
        },      
      }
    },
    "3": {
      name: "PMO Structure & Design",
      description: "Establishing operational processes, KPIs, and performance metrics for the PMO.",
      tasks: {
        "3-input-1": {
          stage: "input",
          title: "Gather Customer Data",
          description: "Collect data on potential PMO customers, their needs, and expectations through surveys and interviews.",
          bestPractices: [
            "Conduct customer needs assessment surveys",
            "Gather stakeholder interview data",
            "Document customer pain points and expectations",
            "Collect service prioritization information"
          ]
        },
        "3-input-2": {
          stage: "input",
          title: "Collect Service Requirement Data",
          description: "Gather detailed requirements for potential PMO services through workshops and requirements sessions.",
          bestPractices: [
            "Conduct service requirements workshops",
            "Document service level expectations",
            "Collect service prioritization criteria",
            "Gather benchmark data on similar services"
          ],
          templates: ["Service Requirements Template", "Customer Needs Assessment"]
        },
        "3-input-3": {
          stage: "input",
          title: "Assess Capability Gaps",
          description: "Collect data on current capabilities and gaps through assessment tools and stakeholder feedback.",
          bestPractices: [
            "Use capability maturity assessment tools",
            "Gather capability benchmark data",
            "Document capability prioritization criteria",
            "Collect resource availability information"
          ]
        },
        "3-processing-1": {
          stage: "processing",
          title: "Apply Persona Development Techniques",
          description: "Use persona development methodologies to create detailed customer personas with needs and expectations.",
          bestPractices: [
            "Apply customer segmentation techniques",
            "Use persona development frameworks",
            "Apply needs analysis methodologies",
            "Use journey mapping techniques"
          ]
        },
        "3-processing-2": {
          stage: "processing",
          title: "Apply Prioritization Frameworks",
          description: "Use prioritization techniques to develop framework for addressing customer needs systematically.",
          bestPractices: [
            "Apply value vs. effort prioritization matrix",
            "Use MoSCoW prioritization technique",
            "Apply weighted scoring methodologies",
            "Use impact mapping techniques"
          ]
        },
        "3-processing-3": {
          stage: "processing",
          title: "Apply Service Catalog Design Methodology",
          description: "Use service catalog design techniques to develop comprehensive service offerings with benefits and advantages.",
          bestPractices: [
            "Apply service definition frameworks",
            "Use service level definition techniques",
            "Apply value proposition development methodologies",
            "Use service categorization techniques"
          ],
          templates: ["Service Catalog Template", "Service Level Agreement Template"]
        },
        "3-output-1": {
          stage: "output",
          title: "Deliver Customer Personas and Journey Maps",
          description: "Create and distribute detailed customer personas and journey maps to guide service design and delivery.",
          bestPractices: [
            "Document comprehensive personas with needs and pain points",
            "Create visual journey maps for key customer interactions",
            "Distribute personas to all service delivery teams",
            "Establish persona update and refinement process"
          ],
          templates: ["Customer Persona Template", "Journey Map Template"]
        },
        "3-output-2": {
          stage: "output",
          title: "Implement Service Catalog and SLAs",
          description: "Launch comprehensive service catalog with service level agreements, processes, and quality standards.",
          bestPractices: [
            "Create detailed service descriptions with value propositions",
            "Establish service level metrics and targets",
            "Implement service request and delivery processes",
            "Create service catalog review and update mechanism"
          ],
          templates: ["Service Catalog Document", "SLA Documentation"]
        },
        "3-output-3": {
          stage: "output",
          title: "Establish Service Prioritization Framework",
          description: "Implement systematic approach for prioritizing and addressing customer needs and service requests.",
          bestPractices: [
            "Create prioritization criteria and scoring system",
            "Implement request intake and evaluation process",
            "Establish resource allocation based on priorities",
            "Develop priority review and adjustment mechanisms"
          ],
          templates: ["Prioritization Matrix", "Service Request Form"]
        },      
      }
    },
    "4": {
      name: "Operational Excellence",
      description: "Ensuring efficient and effective project management processes and tools.",
      tasks: {
        "4-input-1": {
          stage: "input",
          title: "Gather Onboarding Requirements",
          description: "Collect requirements and expectations for customer onboarding process through stakeholder input.",
          bestPractices: [
            "Conduct onboarding needs assessment",
            "Gather stakeholder expectations for onboarding",
            "Document current onboarding challenges",
            "Collect onboarding best practices"
          ]
        },
        "4-input-2": {
          stage: "input",
          title: "Collect Documentation Requirements",
          description: "Gather requirements for process documentation, user guides, and training materials.",
          bestPractices: [
            "Conduct documentation needs assessment",
            "Gather user preferences for documentation formats",
            "Document current documentation gaps",
            "Collect documentation best practices"
          ],
          templates: ["Documentation Requirements Template", "User Guide Outline"]
        },
        "4-input-3": {
          stage: "input",
          title: "Assess Training Needs",
          description: "Collect data on training needs, preferences, and delivery methods through surveys and interviews.",
          bestPractices: [
            "Conduct training needs assessment",
            "Gather learning style preferences",
            "Document knowledge and skill gaps",
            "Collect training effectiveness criteria"
          ]
        },
        "4-processing-1": {
          stage: "processing",
          title: "Apply Quality Management Techniques",
          description: "Use quality management methodologies to develop quality control measures and improvement processes.",
          bestPractices: [
            "Apply quality standards development techniques",
            "Use quality control checkpoint design methods",
            "Apply quality metrics development frameworks",
            "Use continuous improvement methodologies"
          ]
        },
        "4-processing-2": {
          stage: "processing",
          title: "Apply Resource Management Methodologies",
          description: "Use resource management techniques to develop allocation systems and capacity planning processes.",
          bestPractices: [
            "Apply resource capacity planning techniques",
            "Use resource allocation prioritization methods",
            "Apply resource forecasting methodologies",
            "Use resource utilization optimization techniques"
          ],
          templates: ["Resource Management Plan", "Capacity Planning Template"]
        },
        "4-processing-3": {
          stage: "processing",
          title: "Apply Issue Management Framework",
          description: "Use issue management methodologies to develop escalation procedures and resolution processes.",
          bestPractices: [
            "Apply escalation threshold definition techniques",
            "Use escalation path design methods",
            "Apply issue categorization frameworks",
            "Use resolution time standard development techniques"
          ],
          templates: ["Escalation Procedure Template", "Issue Management Framework"]
        },
        "4-output-1": {
          stage: "output",
          title: "Implement Quality Management System",
          description: "Establish comprehensive quality management system with standards, control processes, and improvement mechanisms.",
          bestPractices: [
            "Document quality standards for all services",
            "Implement quality control checkpoints and reviews",
            "Establish quality metrics collection and reporting",
            "Create continuous quality improvement process"
          ],
          templates: ["Quality Standards Document", "Quality Review Checklist"]
        },
        "4-output-2": {
          stage: "output",
          title: "Establish Resource Management System",
          description: "Implement resource management system with capacity planning, allocation processes, and utilization tracking.",
          bestPractices: [
            "Create resource inventory and skills matrix",
            "Implement capacity planning and forecasting process",
            "Establish resource allocation and assignment procedures",
            "Develop resource utilization tracking and reporting"
          ],
          templates: ["Resource Allocation Matrix", "Capacity Planning Dashboard"]
        },
        "4-output-3": {
          stage: "output",
          title: "Deploy Issue Management System",
          description: "Implement comprehensive issue management system with escalation procedures, tracking, and resolution processes.",
          bestPractices: [
            "Establish issue intake and categorization process",
            "Implement escalation paths and notification system",
            "Create issue tracking and status reporting",
            "Develop resolution verification and closure procedures"
          ],
          templates: ["Issue Management Playbook", "Escalation Matrix"]
        },      
      }
    },
    "5": {
      name: "Performance & Improvement",
      description: "Continuously improving PMO services, capabilities, and value delivery.",
      tasks: {
        "5-input-1": {
          stage: "input",
          title: "Gather Maturity Assessment Data",
          description: "Collect data on current PMO maturity through assessment tools, surveys, and stakeholder feedback.",
          bestPractices: [
            "Select appropriate maturity assessment tool",
            "Gather comprehensive assessment data",
            "Document maturity baseline across dimensions",
            "Collect maturity target information"
          ]
        },
        "5-input-2": {
          stage: "input",
          title: "Collect Performance Data",
          description: "Gather current performance metrics, historical trends, and performance targets.",
          bestPractices: [
            "Collect current performance metrics",
            "Gather historical performance data",
            "Document performance targets and thresholds",
            "Collect performance benchmark information"
          ]
        },
        "5-input-3": {
          stage: "input",
          title: "Assess Value Measurement Approaches",
          description: "Collect data on potential value metrics, measurement approaches, and value demonstration methods.",
          bestPractices: [
            "Gather value metric options",
            "Collect value measurement methodologies",
            "Document value perception from stakeholders",
            "Assess current value demonstration approaches"
          ]
        },
        "5-processing-1": {
          stage: "processing",
          title: "Apply Maturity Roadmapping Techniques",
          description: "Use maturity roadmapping methodologies to develop enhancement plan with milestones and metrics.",
          bestPractices: [
            "Apply maturity gap analysis techniques",
            "Use capability prioritization methods",
            "Apply milestone development frameworks",
            "Use metric definition techniques"
          ]
        },
        "5-processing-2": {
          stage: "processing",
          title: "Apply Change Management Methodologies",
          description: "Use change management techniques to develop implementation approach for maturity initiatives.",
          bestPractices: [
            "Apply stakeholder impact analysis techniques",
            "Use resistance management methods",
            "Apply communication planning frameworks",
            "Use adoption measurement techniques"
          ],
          templates: ["Change Management Plan", "Stakeholder Engagement Plan"]
        },
        "5-processing-3": {
          stage: "processing",
          title: "Apply Continuous Improvement Frameworks",
          description: "Use continuous improvement methodologies to develop systematic improvement processes.",
          bestPractices: [
            "Apply improvement opportunity identification techniques",
            "Use improvement prioritization methods",
            "Apply implementation planning frameworks",
            "Use effectiveness measurement techniques"
          ]
        },
        "5-output-1": {
          stage: "output",
          title: "Implement Maturity Enhancement Roadmap",
          description: "Establish and execute comprehensive maturity enhancement roadmap with milestones, metrics, and review processes.",
          bestPractices: [
            "Document detailed maturity enhancement plan",
            "Implement milestone tracking and reporting",
            "Establish maturity metric collection and analysis",
            "Create regular maturity review and adjustment process"
          ],
          templates: ["Maturity Enhancement Roadmap", "Maturity Metrics Dashboard"]
        },
        "5-output-2": {
          stage: "output",
          title: "Establish Value Measurement System",
          description: "Implement comprehensive value measurement system with metrics, reporting, and demonstration mechanisms.",
          bestPractices: [
            "Define and implement value metrics and KPIs",
            "Create value data collection and analysis process",
            "Establish value reporting and visualization",
            "Develop value demonstration case studies"
          ],
          templates: ["Value Measurement Framework", "Value Dashboard"]
        },
        "5-output-3": {
          stage: "output",
          title: "Deploy Continuous Improvement Program",
          description: "Implement systematic continuous improvement program with identification, prioritization, and implementation processes.",
          bestPractices: [
            "Establish improvement opportunity identification process",
            "Create improvement prioritization and selection system",
            "Implement improvement tracking and reporting",
            "Develop improvement effectiveness measurement"
          ],
          templates: ["Continuous Improvement Playbook", "Improvement Tracking System"]
        },      
      }
    },
    "6": {
      name: "Capability Development",
      description: "Developing and managing the human aspects of the PMO including competency, training, and leadership.",
      tasks: {
        "6-input-1": {
          stage: "input",
          title: "Gather Decision-Making Data",
          description: "Collect data on current decision-making processes, data utilization, and improvement opportunities.",
          bestPractices: [
            "Document current decision-making processes",
            "Assess data utilization in decisions",
            "Identify decision-making bottlenecks",
            "Gather decision quality metrics"
          ]
        },
        "6-input-2": {
          stage: "input",
          title: "Assess Competency Requirements",
          description: "Collect data on required competencies, current capabilities, and development needs.",
          bestPractices: [
            "Document role-specific competency requirements",
            "Assess current competency levels",
            "Identify critical competency gaps",
            "Gather development preference information"
          ],
          templates: ["Competency Assessment Template", "Development Needs Analysis"]
        },
        "6-input-3": {
          stage: "input",
          title: "Collect Skills Assessment Data",
          description: "Gather comprehensive skills data through assessments, self-evaluations, and manager feedback.",
          bestPractices: [
            "Use standardized skills assessment tools",
            "Gather self-assessment data",
            "Collect manager assessment input",
            "Document skills prioritization criteria"
          ]
        },
        "6-processing-1": {
          stage: "processing",
          title: "Apply Training Program Design Methodology",
          description: "Use training design techniques to develop comprehensive training and certification programs.",
          bestPractices: [
            "Apply learning objective development techniques",
            "Use curriculum design methodologies",
            "Apply learning modality selection frameworks",
            "Use training effectiveness measurement design"
          ]
        },
        "6-processing-2": {
          stage: "processing",
          title: "Apply Innovation Framework Development",
          description: "Use innovation framework techniques to develop processes for fostering innovation and problem-solving.",
          bestPractices: [
            "Apply innovation process design methodologies",
            "Use idea generation technique selection",
            "Apply idea evaluation framework development",
            "Use innovation incentive system design"
          ]
        },
        "6-processing-3": {
          stage: "processing",
          title: "Apply Knowledge Management Techniques",
          description: "Use knowledge management methodologies to design knowledge-sharing platform and communities of practice.",
          bestPractices: [
            "Apply knowledge repository design techniques",
            "Use knowledge categorization frameworks",
            "Apply community of practice design methodologies",
            "Use knowledge contribution incentive design"
          ]
        },
        "6-output-1": {
          stage: "output",
          title: "Implement Competency Development Framework",
          description: "Establish comprehensive competency framework with assessment, development paths, and certification programs.",
          bestPractices: [
            "Document role-specific competency requirements",
            "Create competency assessment and tracking system",
            "Implement development paths for each competency area",
            "Establish certification and recognition program"
          ],
          templates: ["Competency Framework Document", "Development Path Guide"]
        },
        "6-output-2": {
          stage: "output",
          title: "Deploy Innovation and Problem-Solving System",
          description: "Implement structured innovation program with idea generation, evaluation, and implementation processes.",
          bestPractices: [
            "Establish idea generation and collection system",
            "Create idea evaluation and selection process",
            "Implement innovation implementation support",
            "Develop innovation recognition and incentives"
          ],
          templates: ["Innovation Process Playbook", "Idea Evaluation Matrix"]
        },
        "6-output-3": {
          stage: "output",
          title: "Establish Knowledge Management System",
          description: "Implement comprehensive knowledge management system with repository, sharing mechanisms, and communities of practice.",
          bestPractices: [
            "Create knowledge repository with categorization system",
            "Establish knowledge contribution processes",
            "Form communities of practice with clear charters",
            "Implement knowledge sharing events and activities"
          ],
          templates: ["Knowledge Management Guide", "Community of Practice Charter"]
        }
      }
    }
  },

  // Tasks
  tasks: {
    tasks: "Tasks",
    manageAndTrackYourPmoImplementationTasks: "Manage and track your PMO implementation tasks",
    allTasks: "All Tasks",
    completed: "Completed",
    incomplete: "Incomplete",
    progress: "Progress",
    total: "Total",
    rate: "Rate",
    addCustomTask: "Add Custom Task",
    searchTasks: "Search tasks...",
    filters: "Filters",
    clear: "Clear",
    allDomains: "All Domains",
    allStages: "All Stages",
    input: "Input",
    processing: "Processing",
    output: "Output",
    domain: "Domain",
    stage: "Stage",
    status: "Status",
    clearFilters: "Clear Filters",
    noTasksFound: "No tasks found",
    noTasksMatchFilters: "No tasks match your current filters. Try adjusting or clearing your filters.",
    noTasksAvailable: "No tasks available. Start by creating a new task.",
    taskManagementTips: "Task Management Tips",
    taskManagementTipsDescription: "Prioritize tasks based on your PMO maturity level and organizational goals. Complete the Input stage tasks first before moving to Processing and Output stages for the best results.",
    viewBestPractices: "View Best Practices",
    relatedDocuments: "Related Documents",
    viewFullContent: "View Full Content",
    generateTaskOutput: "Generate Task Output",
    templates: "Templates",
    templateForStandardizedImplementation: "Template for standardized implementation",
    viewTemplate: "View Template",
    bestPractices: "Best Practices",
    priority: "Priority",
    targetCompletionDate: "Target Completion Date",
    assignedTo: "Assigned To",
    estimatedHours: "Estimated Hours",
    attachments: "Attachments",
    notes: "Notes",
    availableTemplates: "Available Templates",
    purpose: "Purpose",
    templateForStandardized: "This template provides a structured framework for implementing and managing",
    withinYourPMO: "processes within your PMO",
    overview: "Overview",
    download: "Download",
    useTemplate: "Use Template",
    close: "Close",
    save:"Save",
    template: `
## Template Sections

### 1. Introduction
- Purpose and objectives
- Scope and applicability
- Key stakeholders

### 2. Process Framework
- Methodology overview
- Key activities and deliverables
- Roles and responsibilities

### 3. Implementation Guide
- Step-by-step instructions
- Best practices and guidelines
- Common challenges and solutions

### 4. Monitoring and Control
- Key performance indicators
- Quality assurance measures
- Reporting requirements

### 5. Continuous Improvement
- Feedback mechanisms
- Review process
- Update procedures

## Appendices
- Related templates and tools
- Reference materials
- Glossary of terms

---

*This template is part of the PMO Builder library. Customize it to fit your organization's specific needs.*`,
  }
};

// Arabic translations
const ar = {
  // Header component
  // Common components
  common: {
    pleaseWait: "يرجى الإنتظار حتى نكتمل إعداد محتواك.",
    Complete : "مكتمل",
    search: "بحث",
    save: "حفظ",
    saveAssessment: "حفظ التقييم",
    saved: "تم الحفظ",
    cancel: "إلغاء",
    showLess: "إخفاء",
    showMore: "إظهار المزيد",
    spent: "منفق",
    active: "فعال",
    used: "مستخدم",
    onTrack: "متبع",
    viewDetails: "عرض التفاصيل",
    tasks: "المهام",
    domains: "المجالات",
    budget: "الميزانية",
    daysLeft: "أيام متبقية",
    edit: "تعديل",
    delete: "حذف",
    close: "إغلاق",
    loading: "جاري التحميل...",
    submit: "إرسال",
    back: "رجوع",
    next: "التالي",
    progress: "التقدم",
    notifications: "الإشعارات",
    help: "المساعدة",
    settings: "الإعدادات",
    profile: "الملف الشخصي",
    signOut: "تسجيل الخروج",
    dashboard: "لوحة القيادة",
    export: "تصدير",
    import: "استيراد",
    share: "مشاركة",
    days: "يوم",
    darkMode: "الوضع الداكن",
    lightMode: "الوضع الفاتح",
    confirm: "تأكيد",
    free: "مجاني",
    upgrade: "الترقية",
    outputAccepted: "تم قبول الناتج",
    templates: "القوالب",
    loadingDocuments: "جاري تحميل المستندات",
    user: "المستخدم",
    filterByProject: "تصفية حسب المشروع",
    allProjects: "جميع المشاريع",
    filterBySource: "تصفية حسب المصدر",
    allSources: "جميع المصادر",
    searchDocuments: "بحث في المستندات",
    remainingTokens: "عدد الرموز المتبقية"
  },
  
  // Header component
  header: {
    search: "بحث...",
    myTeams: "فرقي",
    invitations: "الدعوات",
    setupProfile: "إعداد الملف الشخصي",
    subscription: "الاشتراك",
    remainingTokens: "عدد الرموز المتبقية",
    settings: "الإعدادات",
    adminPanel: "لوحة الإدارة",
    signOut: "تسجيل الخروج",
    profile: "الملف الشخصي",  
  },
  
  // Dashboard page
  dashboard: {
    title: "لوحة القيادة",
    subtitle: "بناء وتتبع مكتب إدارة المشاريع عبر جميع المجالات الأساسية",
    budget: "الميزانية",
    timelineProgress: "التقدم في الخط الزمني",
    budgetUtilization: "استخدام الميزانية",
    projectStatus: "حالة المشروع",
    access: "الوصول",
    editDetails: "تعديل التفاصيل",
    exportReport: "تصدير التقرير",
    maturityAssessment: "تقييم النضج",
    keyObjectives: "الأهداف الرئيسية",
    stakeholders: "المستفيدين",
    overallProgress: "التقدم الإجمالي",
    completedTasks: "المهام المكتملة",
    domainProcessComparison:"مقارنة التقدم في المجالات",
    organization: "المؤسسة",
    industry: "الصناعة",
    dashboardCustomization: "تخصيص لوحة القيادة",
    displayLayout: "عرض التخطيط",
    gridView: "عرض الشبكة",
    listView: "عرض القائمة",
    widgetSelection: "اختيار الوحدات",
    assessMaturityLevel: "تقييم مستوى نضجك",
    maturityLevel: "مستوى نضج",
    progressOverview: "عرض التقدم",
    tasksStatus: "حالة المهام",
    domains: "المجالات",
    chartsAnalytics: "الرسوم البيانية والتحليلات",
    pmoMaturityLevel: "مستوى نضج مكتب إدارة المشاريع",
    pmoDomains: "مجالات مكتب إدارة المشاريع",
    aiAnalysis: "التسريع بالذكاء الاصطناعي",
    aiDescription: "دع الذكاء الاصطناعي المتقدم لدينا يحلل بيانات مكتب إدارة المشاريع الخاص بك وينشئ توصيات شاملة مصممة وفقًا لاحتياجات مؤسستك الفريدة.",
    tryAiAnalysis: "جرب تحليل الذكاء الاصطناعي",
    viewAll: "عرض الكل",
    of: "من",
    tasksCompleted: "المهام المكتملة",
    notSet: "غير محدد",
    updateProfile: "تحديث الملف الشخصي",
    viewAllTasks: "عرض جميع المهام",
    nextSteps: "الخطوات التالية",
    completePmoMaturityAssessment: "إكمال تقييم نضج مكتب إدارة المشاريع",
    getInsightsAboutPmoMaturityLevel: "الحصول على المعلومات حول نضج مكتب إدارة المشاريع الحالي",
    uploadDocuments: "رفع المستندات",
    analysisDocuments: "رفع المستندات الدعمية لتحليل الذكاء الاصطناعي",
    analysisDocumentsDesc: "تعزيز توصيات الذكاء الاصطناعي بسياق مؤسستك",
    reviewPractices: "مراجعة أفضل الممارسات",
    explorePractices: "استكشاف مكتبة أفضل الممارسات للتوجيه",
    viewResources: "عرض الموارد",
    goToAssessment: "الذهاب إلى التقييم",
    objective1: "إنشاء إطار حوكمة مكتب إدارة المشاريع",
    objective2: "تطوير منهجيات قياسية",
    objective3: "تنفيذ مقاييس الأداء",
    sampleProject: "تنفيذ مكتب إدارة المشاريع النموذجي",
    sampleDescription: "مشروع نموذجي مع بيانات معدة مسبقًا للعرض التوضيحي",
    createFirstProject: "إنشاء مشروع مكتب إدارة المشاريع الأول",
    firstProjectDesc: "ابدأ بإنشاء مشروع تنفيذ مكتب إدارة المشاريع الأول. يمكنك إعداد تفاصيل المشروع وتتبع التقدم عبر المجالات وإنشاء توصيات مدعومة بالذكاء الاصطناعي.",
    createSample: "إنشاء مشروع نموذجي",
    aiFeature1: "قوالب مخصصة بناءً على مستوى نضجك الحالي",
    aiFeature2: "خرائط طريق تنفيذ مفصلة لكل مجال",
    aiFeature3: "أفضل الممارسات المصممة خصيصًا لصناعتك وسياقك",
    maturityRadarChart: "مخطط النضج المتجه",
    higherValuesIndicateGreaterMaturity: "القيم الأعلى تشير إلى نضج أعلى",
    createNew: "إنشاء مشروع جديد",
    pmoMaturityAssessment: "تقييم نضج مكتب إدارة المشاريع",
    assessPmoMaturity: "تقييم نضج مكتب إدارة المشاريع",
    selfAssessment: "تقييم ذاتي",
    aiGeneratedAssessment: "تقييم مولد بالذكاء الاصطناعي",
    notSpecified: "غير محدد",
    currentMaturityProfile: "النضج الحالي لمكتب إدارة المشاريع",
    organizationDetails: "تفاصيل المؤسسة",
    assessmentType: "نوع التقييم",
    assessmentDate: "تاريخ التقييم",
    selfAssessmentQuestionnaire: "استبيان تقييم نضج مكتب إدارة المشاريع",
    selfAssessmentDescription: "قيم نضج مكتب إدارة المشاريع لكل مجال. يرجى النظر في عملياتك والوثائق وقدرات القياس وجهود التحسين المستمرة عند إجراء تقييمك.",
    documentation: "الوثائق",
    metrics: "المقاييس",
    minimalToNone: "أقل من الصفر",
    basicDocumentation: "الوثائق الأساسية",
    comprehensiveDocumentation: "الوثائق الشاملة",
    regularlyUpdated: "محدث بشكل منتظم",
    leadingPractice: "ممارسة مبتكرة",
    adHocOrNone: "عشوائي أو لا شيء",
    basicTracking: "تتبع أساسي",
    dataDrivenDecisions: "قرارات مقاسة بالبيانات",
    predictiveAnalytics: "تحليلات منطقية",
    advancedAnalytics: "تحليلات متقدمة",
    
    currentMaturityProfileDescription: "مكتب إدارة المشاريع الخاص بك يوجد حاليا في",
    currentMaturityProfileDescription2: "مستوى. سيساعدك هذا التقييم في تحديد المناطق التي يمكن تحسينها وإنشاء خارطة طريق لتطوير قدرات مكتب إدارة المشاريع الخاص بك.",
    notes: "ملاحظات (اختياري)",
    notesPlaceholder: "أضف أي ملاحظات أو سياق حول تقييمك...",
    generateAIAssessment: "إنشاء تقييم بالذكاء الاصطناعي",
    aiAssessmentDescription: "سيقوم الذكاء الاصطناعي المتقدم بتحليل مدخلاتك وإنشاء توصيات مخصصة",
    aiAssessmentSummary: "ملخص تقييم الذكاء الاصطناعي",
    aiAssessmentSummaryDescription: "بناءً على تحليلنا ، يوجد مكتب إدارة المشاريع الخاص بك حاليا في",
    keyStrengths: "القوى الرئيسية",
    areasForImprovement: "المناطق التي يمكن تحسينها",
    domainSpecificAssessment: "تقييم مجالي",
    maturityProgression: "تقدم نضج مكتب إدارة المشاريع",
    recommendations: "التوصيات",
    generatingReport: "جاري إنشاء التقرير...",
    exportAssessmentReport: "تصدير تقرير التقييم",
    detailedMaturityGuide: "دليل النضج المفصل",
    maturityModelReference: "مرجع نضج النموذج",
    generateAssessment: "إنشاء تقييم",
    generatingAssessment: "جاري إنشاء تقييم...",
    generatingAssessmentDescription: "يتم تحليل بيانات مكتب إدارة المشاريع الخاص بك عبر جميع المجالات. قد يستغرق هذا بضع ثوانٍ.",
    barCharts: "الرسوم البيانية",
    ganttTimeline: "الخط الزمني المنحدر",
    
  },
  ganttChart: {
    cancel: "إلغاء",
    addTask: "إضافة مهمة",
    legend: "العلامات",
    taskName: "اسم المهمة",
    domain: "المجال",
    dependencies: "التبعيات",
    startDate: "بدء المهمة",
    endDate: "نهاية المهمة",
    progress: "التقدم",
    color: "اللون",
    addNewTask: "إضافة مهمة جديدة",
    save: "حفظ",
    projectTimeline: "الخط الزمني للمشروع",
    day: "يوم",
    week: "أسبوع",
    month: "شهر",
    editTask: "تعديل المهمة",
    timeline: "الخط الزمني",
    selectDomain: "اختر المجال",
    unknownDomain: "مجال غير معروف",
    delete: "حذف",
    add: "إضافة",
    edit: "تعديل",
    close: "إغلاق",
    deleteTask: "حذف المهمة",
    deleteTaskConfirmation: "هل أنت متأكد ؟",
    
  },
  // Domain detail page
  domain: {
    BestPractices: "أفضل الممارسات",
    Organizational: "التطوير التنظيمي والمواءمة",
    Strategic: "الإطار الاستراتيجي والحوكمة",
    PMO: "هيكل وتصميم مكتب إدارة المشاريع",
    Operational: "التميز التشغيلي",
    Performance: "الأداء والتحسين",
    Capability: "تطوير القدرات",
    backToDashboard: "العودة إلى لوحة القيادة",
    prevDomain: "المجال السابق",
    nextDomain: "المجال التالي",
    viewDomain: "عرض المجال",
    progress: "التقدم",
    tasks: "المهام والتقدم",
    input: "إدخال المجال والتحليل",
    analyzing: "تحليل إدخال المجال",
    processingData: "الذكاء الاصطناعي لدينا يعالج بياناتك...",
    inputStage: "الإدخال",
    inputDesc: "جمع البيانات وتقييم الحالة الحالية وجمع المتطلبات لهذا المجال.",
    processingStage: "المعالجة",
    processingDesc: "تحليل البيانات وتطوير الأطر وتصميم الحلول لهذا المجال.",
    outputStage: "الإخراج",
    outputDesc: "إنشاء المخرجات وتنفيذ الحلول وإنشاء الأطر لهذا المجال.",
    loading: "جاري تحميل بيانات المجال...",
    notFound: "المجال غير موجود",
    provideInputFirst: "يرجى تقديم بيانات إدخال المجال قبل التحليل",
    aiGeneratedAnalysis: "تحليل مولد بالذكاء الاصطناعي لـ",
    generated: "تم إنشاؤه",
    analysis: "التحليل",
    domainProgress: "التقدم في المجال (%)",
    templates: "القوالب",
    downloadMarkdown: "تنزيل ماركداون",
    downloadPdf: "تنزيل PDF",
    generatingPdf: "جاري إنشاء PDF...",
    generating: "جاري الإنشاء...",
    allTemplates: "جميع القوالب المتاحة",
    markdownFormat: "ماركداون",
    words: "كلمات",
    usingTemplates: "استخدام هذه القوالب",
    templateDescription: "هذه القوالب متاحة بتنسيقات ماركداون و PDF. يمكن استيراد ماركداون إلى محرري المستندات وأدوات إدارة المشاريع أو تحويلها إلى تنسيقات أخرى. ملفات PDF جاهزة للطباعة أو المشاركة مع أصحاب المصلحة.",
    noTemplates: "لا توجد قوالب متاحة لهذا المجال",
    aiConfigTitle: "تكوين تحليل الذكاء الاصطناعي",
    selectDomainPrompt: "اختر مجالًا لتحليله باستخدام الذكاء الاصطناعي المتقدم. سيولد التحليل توصيات وقوالب شاملة بناءً على سياق مؤسستك المحدد.",
    selectDomain: "اختر المجال",
    analysisDepth: "عمق التحليل",
    basic: "أساسي",
    quickOverview: "نظرة عامة سريعة",
    standard: "قياسي",
    balancedAnalysis: "تحليل متوازن",
    detailed: "مفصل",
    inDepthReview: "مراجعة متعمقة",
    comprehensive: "شامل",
    maximumDetail: "تفاصيل قصوى",
    geminiPowered: "تحليل مدعوم بـ Gemini AI",
    advancedAiDesc: "سيقوم الذكاء الاصطناعي المتقدم بتحليل مدخلاتك وإنشاء توصيات مخصصة",
    startAnalysis: "بدء التحليل",
    uploadSupportingDocuments: "رفع المستندات الدعمية",
    documentsEnhanceAIAnalysisAccuracy: "تعزيز دقة التحليل الذكي",
    supportedFormats: "التنسيقات المدعومة: .txt, .md, .html, .docx, .pdf",
    browseFiles: "تصفح الملفات",
    change: "تغيير",
    processing: "جاري المعالجة...",
    processDocument: "معالجة المستند",
    documentProcessedSuccessfully: "تم معالجة المستند بنجاح",
    documentSplitIntoChunksForOptimalAnalysis: "تم تقسيم المستند إلى {processedDoc.totalChunks} منطقة للتحليل الأمثل",
    provideInformationAboutYourOrganizationApproachToDomainName: "أعطاء معلومات عن طريقة المؤسسة في",
    thisDataWillBeAnalyzedToGenerateComprehensiveRecommendationsAndCompletedTemplates: "سيتم تحليل هذه البيانات لإنشاء توصيات شاملة وقوالب مكتملة",
    workingInOfflineMode: "العمل في وضع عدم الاتصال",
    youAppearToBeWorkingOfflineOrHaveConnectionIssuesWithTheDatabase: "يبدو أنك تعمل عديم الاتصال أو لديك مشاكل مع الاتصال بقاعدة البيانات",
    youCanContinueWorkingAndChangesWillBeSavedLocally: "يمكنك الاستمرار في العمل وسيتم حفظ التغييرات المحليا",
    longInputDetected: "تم اكتشاف مدخلات طويلة",
    yourInputIsQuiteLong: "مدخلاتك طويلة جدا ({inputLength.toLocaleString()} حرف). للتحليل الأسرع، يرجى التركيز على المعلومات المهمة وإزالة التفاصيل الأقل أهمية.",
    useSampleData: "استخدام البيانات العينية",
    showSampleData: "إظهار البيانات العينية",
    hideSampleData: "إخفاء البيانات العينية",
    sampleInputData: "بيانات المدخلات العينية",
    showPreviousDomainOutput: "إظهار إخراج المجال السابق",
    hidePreviousDomainOutput: "إخفاء إخراج المجال السابق",
    enterInformationAboutYourOrganizationPractices: "أدخل معلومات عن طريقة المؤسسة في",
    practices: "الممارسات",
    sampleData: "بيانات العينة",
    characters: "حرف",
    saving: "يتم حفظ...",
    saved: "تم حفظ!",
    saveDraft: "حفظ المسودة",
    offlineMode: "وضع عدم الاتصال",
    analysisLimited: "تقييد التحليل",
    aiAnalysis: "تحليل الذكاء الاصطناعي",
    quickAnalysisWithOpenAI: "تحليل سريع باستخدام OpenAI",
    analysisTypicallyTakes2040SecondsToCompleteDependingOnInputLength: "يأخذ التحليل عادةً 20-40 ثانية لإكماله بناءً على طول المدخلات.",
    loadingReferences: "يتم تحميل المراجع...",
    relevantInformationFromOtherDomainsThatCanEnhanceYourWorkInThisDomain: "المعلومات المتعلقة بالمجالات الأخرى التي يمكن أن تعزز عملك في هذا المجال:",
    noCrossDomainReferencesFound: "لم يتم العثور على مراجع متقاطعة. كلما أضفت المزيد من المستندات إلى المجالات الأخرى، سيظهر المعلومات المتعلقة تلقائيًا هنا.",
    crossDomainReferences: "مراجع متقاطعة",
    aiEnhanced: "محسنة بالذكاء الاصطناعي",
  },

  // Project management
  project: {
    projectName: "اسم المشروع",
    projectNamePlaceholder: "تنفيذ مكتب إدارة المشاريع المؤسسية",
    description: "الوصف",
    descriptionPlaceholder: "وصف موجز لمشروع تنفيذ مكتب إدارة المشاريع",
    budget: "الميزانية",
    yourProjects: "مشاريعك",
    createProject: "إنشاء مشروع"
  },
  
  // Sidebar
  sidebar: {
    dashboard: "لوحة القيادة",
    pmoDomains: "مجالات مكتب إدارة المشاريع",
    tools: "الأدوات والتقييم",
    resources: "الموارد",
    tasks: "المهام",
    bestPractices: "أفضل الممارسات",
    maturityAssessment: "تقييم النضج",
    settings: "الإعدادات",
    assessment: "التقييم"
  },
  
  // Auth pages
  auth: {
    copyright: "© 2025 بناء مكتب إدارة المشاريع بواسطة د. أحمد السنوسي"
  },

  // Maturity levels
  maturityLevels:{
    initial: {
      label: 'البدء',
      description: 'العمليات عشوائية ومشوهة.'
    },
    defined: {
      label: 'معرف',
      description: 'العمليات مدونة ومعيارية.'
    },
    managed: {
      label: 'اداره',
      description: 'العمليات مقاسة ومنضبطة.'
    },
    optimized: {
      label: 'مثالي',
      description: 'التركيز على التحسين المستمر.'
    },
    innovative: {
      label: 'مبتكر',
      description: 'يقود التطوير الصناعي والتكيف.'
    }
  },



  profile: {
    title: 'الملف الشخصي',
    description: 'إعداد تفاصيل المؤسستك لتخصيص رحلتك مكتب إدارة المشاريع',
    organizationName: 'اسم المؤسسة',
    organizationNamePlaceholder: 'أدخل اسم مؤسستك',
    industry: 'الصناعة',
    industryPlaceholder: 'أدخل الصناعة الخاصة بك',
    pmoMaturityLevel: 'مستوى نضج مكتب إدارة المشاريع',
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: 'حدد المستوى الذي يناسب أفضل الوصف لنضج مكتب إدارة المشاريع الحالي',
    initial: 'البدء - عمليات عشوائية ومشوهة',
    defined: 'معرف - عمليات مدونة ومعيارية',
    managed: 'اداره - عمليات مقاسة ومنضبطة',
    optimized: 'مثالي - التركيز على التحسين المستمر',
    notEstablished: 'لم يتم التأسيس - لا يوجد مكتب إدارة منضبط',
    saveProfile: 'حفظ الملف الشخصي',
    cancel: 'إلغاء',
  },
  //settings page
  settings: {
    title: "الإعدادات",
    description: "إدارة الإعدادات الشخصية والأهداف",
    personal: "الشخصي",
    subscription: "الاشتراك",
    notifications: "الإشعارات",
    security: "الأمان",
    data: "البيانات",
    saveProfile: "حفظ الإعدادات",
    cancel: "إلغاء",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "حدد المستوى الذي يناسب أفضل الوصف لنضج مكتب إدارة المشاريع الحالي",
    organizationName: "اسم المؤسسة",
    organizationNamePlaceholder: "أدخل اسم مؤسستك",
    industry: "الصناعة",
    industryPlaceholder: "أدخل الصناعة الخاصة بك",
    pmoMaturityLevel: "مستوى نضج مكتب إدارة المشاريع",
    notEstablished: "لم يتم التأسيس - لا يوجد مكتب إدارة منضبط",
    initial: "البدء - عمليات عشوائية ومشوهة",
    defined: "معرف - عمليات مدونة ومعيارية",
    managed: "اداره - عمليات مقاسة ومنضبطة",
    optimized: "مثالي - التركيز على التحسين المستمر",
    
  },
// صفحة المساعدة
help: {
  title: "المساعدة والدعم",
  description: "تعلم كيفية استخدام أداة تطبيق مجالات مكتب إدارة المشاريع  بفعالية",
  gettingStarted: "البدء",
  whatIsPmoDomainsTool: "ما هي أداة مجالات مكتب إدارة المشاريع?",
  whatIsPmoDomainsToolDescription: `تساعد أداة تطبيق مجالات مكتب إدارة المشاريع المتخصصين في مكاتب إدارة المشاريع على تطبيق ومتابعة المجالات الخمسة الرئيسية باستخدام إطار عمل منظم "المدخلات - المعالجة - المخرجات". توجهك الأداة خلال مهام كل مجال لضمان تطبيق أفضل الممارسات والمقارنة بالمعايير الصناعية.`,
  howToUseThisTool: "كيفية استخدام هذه الأداة",
  howToUseThisToolDescription: "أداة تطبيق مجالات مكتب إدارة المشاريع هي تطبيق ويب يساعد المؤسسات على تنفيذ وتحسين قدرات مكتب إدارة المشاريع عبر جميع المجالات.",
  canIExportMyData: "هل يمكنني تصدير بياناتي؟",
  canIExportMyDataDescription: "نعم، يمكنك تصدير بياناتك من صفحة الإعدادات. يتيح لك ذلك الاحتفاظ بنسخة احتياطية من تقدمك أو نقلها إلى نظام آخر.",
  canICustomizeTheToolForMyOrganization: "هل يمكنني تخصيص الأداة لمؤسستي؟",
  canICustomizeTheToolForMyOrganizationDescription: "تم تصميم الأداة لتكون قابلة للتطبيق عبر مؤسسات وصناعات مختلفة. يمكنك إضافة ملاحظات مخصصة لكل مهمة لتناسب سياق مؤسستك.",
  whatIfINotReadyToCompleteAllDomains: "ماذا لو لم أكن مستعدًا لإكمال جميع المجالات؟",
  whatIfINotReadyToCompleteAllDomainsDescription: "يمكنك العمل على المجالات بأي ترتيب يناسب مؤسستك. ستقوم الأداة بتتبع تقدمك في جميع المجالات، مما يتيح لك التركيز على أولوياتك.",
  contactSupport: "الاتصال بالدعم",
  contactSupportDescription: "إذا كنت بحاجة إلى مساعدة إضافية أو لديك أسئلة حول أداة تطبيق مجالات مكتب إدارة المشاريع، يرجى الاتصال بفريق الدعم الخاص بنا.",
  supportContact: "معلومات الاتصال بالدعم",
  supportContactEmail: "البريد الإلكتروني: support@pmodomains.com",
  supportContactPhone: "الهاتف: (555) 123-4567",
  supportContactHours: "ساعات العمل: من الاثنين إلى الجمعة، 9 صباحًا - 5 مساءً بتوقيت شرق الولايات المتحدة",
  startBySettingUpYourOrganizationProfile: "ابدأ بإعداد ملف مؤسستك في قسم الملف الشخصي",
  navigateToEachDomainUsingTheSidebarMenu: "تنقل إلى كل مجال باستخدام قائمة الشريط الجانبي",
  completeTasksInTheRecommendedOrder: "أكمل المهام بالترتيب الموصى به: المدخلات → المعالجة → المخرجات",
  markTasksAsCompleteAsYouProgress: "حدد المهام كمكتملة أثناء تقدمك",
  useTheDashboardToTrackYourOverallProgress: "استخدم لوحة التحكم لتتبع تقدمك العام",
  referToTheBestPracticesLibraryForGuidance: "ارجع إلى مكتبة أفضل الممارسات للحصول على إرشادات",
  organizationalDevelopmentAndAlignment: "1. تطوير المؤسسة والمواءمة",
  organizationalDevelopmentAndAlignmentDescription: "يركز هذا المجال على مواءمة مكتب إدارة المشاريع مع استراتيجية المؤسسة وثقافتها لضمان ممارسات إدارة مشاريع فعالة. يتضمن التقييم التنظيمي، وتحليل أصحاب المصلحة، وتطوير استراتيجيات المواءمة.",
  strategicElementsOfThePmo: "2. العناصر الاستراتيجية لمكتب إدارة المشاريع",
  strategicElementsOfThePmoDescription: "يتضمن هذا المجال تطوير وتنفيذ الأطر الاستراتيجية، وخطط الطريق، وهياكل الحوكمة. يشمل مراجعة الأهداف الاستراتيجية، وتحليل المحافظ، وتصميم هيكل الحوكمة.",
  pMODesignAndStructuring: "3. تصميم وهيكلة مكتب إدارة المشاريع",
  pMODesignAndStructuringDescription: "يركز هذا المجال على إنشاء الهيكل الأمثل لمكتب إدارة المشاريع، والأدوار، والمسؤوليات لتلبية احتياجات المؤسسة. يتضمن جمع المتطلبات، وتقييم الموارد، وتطوير كتالوج الخدمات.",
  pMOOperationAndPerformance: "4. تشغيل وأداء مكتب إدارة المشاريع",
  pMOOperationAndPerformanceDescription: "يضع هذا المجال العمليات التشغيلية، ومؤشرات الأداء الرئيسية، ومقاييس الأداء لمكتب إدارة المشاريع. يتضمن تقييم العمليات، وتحديد مؤشرات الأداء، وأنظمة قياس الأداء.",
  pMOEnhancementAndEffectiveness: "5. تعزيز وفعالية مكتب إدارة المشاريع",
  pMOEnhancementAndEffectivenessDescription: "يركز هذا المجال على تحسين خدمات مكتب إدارة المشاريع، والقدرات، وتقديم القيمة باستمرار. يتضمن تقييم النضج، وتحليل تقديم القيمة، وخطط التحسين المستمر.",
  frequentlyAskedQuestions: "الأسئلة الشائعة",
  frequentlyAskedQuestionsDescription: "أداة تطبيق مجالات مكتب إدارة المشاريع هي تطبيق ويب يساعد المؤسسات على تنفيذ وتحسين قدرات مكتب إدارة المشاريع عبر جميع المجالات.",
  howToAccessTemplates: "كيف يمكنني الوصول إلى القوالب؟",
  howToAccessTemplatesDescription: "تتوفر القوالب ضمن المهام المحددة التي تحتوي على موارد القوالب. يمكنك أيضًا العثور على مجموعة من القوالب في مكتبة أفضل الممارسات.",
  understandingTheFiveDomains: "فهم المجالات الخمسة",
},


subscription: {
  title: "الاشتراكات",
  currentPlan: "المستوى الحالي",
  trial: "المحادة",
  cancelsAtPeriodEnd: "يلغي في نهاية الفترة",
  upgradePlan: "ترقية المستوى",
  manageSubscription: "إدارة الاشتراك",
  processing: "يتم المعالجة...",
  billingPeriod: "الفترة المدفوعة",
  nextBillingDate: "تاريخ الفوتر القادم",
  paymentMethod: "طريقة الدفع",
  projects: "المشاريع",
  aiAnalysis: "التحليل الآلي",
  storage: "التخزين",
  freePlanLimitations: "المحدودات المجانية",
  freePlanLimitationsDescription: "لقد تم تحديدك على المستوى المجاني الذي يحدد عدد المشاريع والتحليلات الآلية والتخزين المتاحين.",
  upgradeNow: "ترقية الآن",
  upgradeToGetMore: "ترقية للحصول على المزيد",
  premiumPlanBenefits: "فوائد المستوى الممتاز",
  upTo20Projects: "20 مشروع (بدلاً من 3 في المجانية)",
  upTo100AiAnalyses: "100 تحليل آلي في الشهر (بدلاً من 3 في المجانية)",
  teamCollaboration: "التعاون في الفريق مع حتى 5 مستخدمين",
  prioritySupport: "الدعم الأولوية",
  upgradeToPremium: "ترقية إلى الممتاز",
  enterprisePlanBenefits: "فوائد المستوى المنتج",
  unlimitedProjectsAndAiAnalyses: "أي عدد من المشاريع والتحليلات الآلية",
  unlimitedTeamMembers: "أي عدد من الأعضاء في الفريق",
  whiteLabelingOptions: "خيارات التسمية البيضاء",
  dedicatedSupport: "الدعم المخصص",
  upgradeToEnterprise: "ترقية إلى المنتج",
  unlimited: "غير محدود",
  unknown: "غير معروف",
  free: "مجاني",
  premium: "ممتاز",
  enterprise: "منتج",
  usageAndLimits: "الاستخدام والمحدودات",
  perMonth: "في الشهر",
  mb: "ميجابايت",
  none: "لا شيء",
  creditCard: "بطاقة الائتمان",
  paypal: "بايبال",
  notAvailable: "غير متاح",
  
  
},
  notifications: {
    '1': {
      title: "التقديم المستحق لتقييم النضج",
      description: "قم بإكمال تقييم النضج الربعي الخاص بك بحلول الجمعة القادمة.",
      time: "2 أيام مضت",
    },
    '2': {
      title: "تحديث المجال الاستراتيجي",
      description: "تم إضافة قوالب جديدة وموارد إلى المجال الاستراتيجي.",
      time: "3 أيام مضت",
    },
    '3': {
      title: "اجتماع الفريق: تعزيز مكتب إدارة المشاريع",
      description: "اجتماع قادم لمناقشة تعزيز مكتب إدارة المشاريع.",
      time: "الغد, 10:00 ص",
    },
    '4': {
      title: "رسالة جديدة من الإدارة",
      description: "لديك رسالة جديدة متعلقة بتقدم المجال التنظيمي الخاص بك.",
      time: "أسبوع مضت",
    },
    '5': {
      title: "إكمال إعادة النسخ",
      description: "تم إكمال إعادة النسخ الخاصة بك إلى التخزين السحابي.",
      time: "2 أسابيع مضت",
    },
    title: "الإشعارات",
    description: "ابقى على اطلاع بأنشطة مكتب إدارة المشاريع الخاص بك والإشعارات المهمة",
    markAllAsRead: "تحديد الكل كمقروء",
    clearAll: "مسح الكل",
    markAllAsReadDescription: "تحديد جميع الإشعارات المقروءة",
    clearAllDescription: "مسح جميع الإشعارات",
    markAllAsReadButton: "تحديد الكل كمقروء",
    clearAllButton: "مسح الكل",
    unread: "غير مقروء",
    all: "الكل",
    recentNotifications: "آخر الإشعارات",
    markAsUnread: "تحديد كغير مقروء",
    markAsRead: "تحديد كمقروء",
    viewDetails: "عرض التفاصيل",
    loadMore: "تحميل المزيد",
    customizeNotifications: "تخصيص كيفية وأوقات الاستلام الإشعارات حول أنشطة مكتب إدارة المشاريع الخاص بك",
    notificationPreferences: "إعدادات الإشعارات",
    managePreferences: "إدارة الإعدادات",
    
    
    
    
  },
  // Domain names
  domains: {
    "1": {
      name: "التطوير التنظيمي والمواءمة",
      description: "محاذاة مكتب إدارة المشاريع مع الاستراتيجية التنظيمية والثقافة لضمان الممارسات الفعالة لإدارة المشاريع.",
      tasks: {
        "1-input-1": {
          stage: "الإدخال",
          title: "تقييم الكفاءات الحالية",
          description: "جمع البيانات حول الكفاءات الحالية من خلال الاستبيانات والمقابلات ومراجعة الوثائق.",
          bestPractices: [
            "استخدام أدوات تقييم موحدة لتقييم الكفاءات الحالية",
            "جمع آراء من مستويات تنظيمية متعددة",
            "توثيق الكفاءات الفنية والمهارية",
            "تحديد فجوات الكفاءة من خلال تقييم منظم"
          ]
        },
        "1-input-2": {
          stage: "الإدخال",
          title: "تقييم الثقافة التنظيمية",
          description: "جمع بيانات حول الثقافة التنظيمية الحالية من خلال الاستبيانات، ومجموعات النقاش، ومقابلات أصحاب المصلحة.",
          bestPractices: [
            "إجراء استبيانات تقييم الثقافة",
            "جمع ملاحظات من مستويات تنظيمية متنوعة",
            "توثيق العوامل المساعدة والمعيقة للثقافة في إدارة المشاريع",
            "جمع بيانات تاريخية حول مبادرات التغيير الثقافي"
          ]
        },
        "1-input-3": {
          stage: "الإدخال",
          title: "القياس مقابل المعايير الصناعية",
          description: "جمع بيانات المقارنة الصناعية وأفضل الممارسات لتحقيق التوافق التنظيمي.",
          bestPractices: [
            "اختيار معايير ومقاييس صناعية مناسبة",
            "جمع البيانات من تقارير ومنشورات الصناعة",
            "توثيق ممارسات المؤسسات النظيرة",
            "جمع مؤشرات للتحليل المقارن"
          ]
        },
        "1-processing-1": {
          stage: "المعالجة",
          title: "تطبيق تقنيات التحليل الاستراتيجي",
          description: "استخدام أدوات التحليل الاستراتيجي لتطوير استراتيجية متكاملة مع إدارة المخاطر وخارطة طريق للتنفيذ.",
          bestPractices: [
            "تطبيق تحليل SWOT لتحديد نقاط القوة والضعف",
            "استخدام تحليل الفجوة لتحديد مجالات التحسين",
            "تطبيق منهجيات تقييم المخاطر",
            "استخدام تقنيات إعداد خارطة الطريق للتنفيذ"
          ]
        },
        "1-processing-2": {
          stage: "المعالجة",
          title: "تطبيق منهجيات تخطيط الاتصال",
          description: "استخدام تقنيات تخطيط الاتصال لتطوير رسائل مخصصة لأصحاب المصلحة وآليات التغذية الراجعة.",
          bestPractices: [
            "تطبيق تقنيات تحليل أصحاب المصلحة",
            "استخدام طرق تطوير مصفوفة الاتصال",
            "تطبيق منهجيات تخصيص الرسائل",
            "استخدام أطر مؤشرات الأداء لقياس فعالية الاتصال"
          ]
        },
        "1-processing-3": {
          stage: "المعالجة",
          title: "تطبيق تقنيات إعداد الميثاق",
          description: "استخدام منهجيات إعداد الميثاق لتعريف نطاق مكتب إدارة المشاريع، والسلطة، وهيكل الحوكمة.",
          bestPractices: [
            "تطبيق تقنيات تحديد النطاق",
            "استخدام طرق تطوير مصفوفة RACI",
            "تطبيق منهجيات تصميم إطار الحوكمة",
            "استخدام تقنيات رسم خرائط الصلاحيات"
          ],
          templates: ["نموذج ميثاق مكتب إدارة المشاريع", "مصفوفة RACI"]
        },
        "1-output-1": {
          stage: "الإخراج",
          title: "تقديم استراتيجية متكاملة وخارطة طريق",
          description: "إنتاج وتنفيذ الاستراتيجية المتكاملة مع خطة إدارة المخاطر وخارطة طريق تنفيذية مرحلية.",
          bestPractices: [
            "توثيق استراتيجية شاملة بأهداف واضحة",
            "إنشاء خارطة طريق تفصيلية مع مراحل تنفيذ",
            "تطوير خطة إدارة المخاطر باستراتيجيات تخفيف",
            "وضع آليات لمراجعة وتحديث الاستراتيجية"
          ]
        },
        "1-output-2": {
          stage: "الإخراج",
          title: "تأسيس رؤية وقيم وثقافة مكتب إدارة المشاريع",
          description: "تنفيذ بيان الرؤية والقيم الأساسية وبرنامج التغيير الثقافي بمشاركة القيادة.",
          bestPractices: [
            "إنشاء بيان رؤية ملهم يتماشى مع أهداف المنظمة",
            "توثيق القيم الأساسية مع أمثلة سلوكية",
            "تنفيذ أنشطة تفاعل مع القيادة",
            "إرساء آليات دعم ثقافي مستمرة"
          ],
          templates: ["نموذج بيان رؤية مكتب إدارة المشاريع", "خارطة طريق التغيير الثقافي"]
        },
        "1-output-3": {
          stage: "الإخراج",
          title: "تنفيذ ميثاق وهيكل حوكمة مكتب إدارة المشاريع",
          description: "تأسيس وتفعيل ميثاق مكتب إدارة المشاريع مع تحديد النطاق والصلاحيات وهيكل الحوكمة.",
          bestPractices: [
            "إقرار رسمي لميثاق مكتب إدارة المشاريع بموافقة الإدارة العليا",
            "تطبيق هيكل حوكمة واضح المهام والمسؤوليات",
            "تحديد الصلاحيات وآليات اتخاذ القرار",
            "إنشاء آلية مراجعة وتحديث للميثاق"
          ],
          templates: ["وثيقة ميثاق مكتب إدارة المشاريع", "مخطط هيكل الحوكمة"]
        },
      },
    },
    "2": {
      name: "الإطار الاستراتيجي والحوكمة",
      description: "إنشاء الإطار الاستراتيجي والهيكل الحوكمي الأمثل لتلبية احتياجات المؤسسة.",
      tasks: {
        "2-input-1": {
          stage: "الإدخال",
          title: "جمع بيانات الحالة الحالية",
          description: "جمع بيانات حول عمليات وإجراءات وأداء إدارة المشاريع الحالي.",
          bestPractices: [
            "مراجعة توثيق العمليات",
            "جمع مقاييس الأداء والبيانات التاريخية",
            "جمع ملاحظات أصحاب المصلحة حول العمليات الحالية",
            "توثيق هياكل الحوكمة الحالية"
          ]
        },
        "2-input-2": {
          stage: "الإدخال",
          title: "جمع معلومات التوافق الاستراتيجي",
          description: "جمع الأهداف الاستراتيجية للمنظمة والأولويات ومعايير النجاح.",
          bestPractices: [
            "مراجعة الخطط الاستراتيجية للمنظمة",
            "جمع أولويات القيادة التنفيذية",
            "توثيق أهداف وحدات الأعمال",
            "جمع معلومات عن المبادرات الاستراتيجية"
          ]
        },
        "2-input-3": {
          stage: "الإدخال",
          title: "تحديد متطلبات القدرات",
          description: "جمع بيانات حول القدرات المطلوبة من خلال مقابلات مع أصحاب المصلحة وتقييم احتياجات المنظمة.",
          bestPractices: [
            "إجراء مقابلات لتحديد احتياجات القدرات",
            "جمع معايير القدرات في الصناعة",
            "توثيق معايير ترتيب أولوية القدرات",
            "جمع مقاييس نضج القدرات"
          ]
        },
        "2-processing-1": {
          stage: "المعالجة",
          title: "تطبيق منهجية تطوير التفويض",
          description: "استخدام تقنيات تطوير التفويض لتعريف غرض وصلاحيات ومسؤوليات مكتب إدارة المشاريع.",
          bestPractices: [
            "تطبيق طرق تطوير بيان الغرض",
            "استخدام تقنيات رسم خرائط الصلاحيات",
            "تطبيق منهجيات تحديد المسؤوليات",
            "استخدام أساليب التحقق من أصحاب المصلحة"
          ],
          templates: ["نموذج تفويض مكتب إدارة المشاريع", "اتفاقية الرعاية التنفيذية"]
        },
        "2-processing-2": {
          stage: "المعالجة",
          title: "تطبيق إطار تطوير الميثاق",
          description: "استخدام إطار تطوير الميثاق لإنشاء ميثاق شامل لمكتب إدارة المشاريع يشمل الأدوار وهيكل الحوكمة.",
          bestPractices: [
            "تطبيق تقنيات صياغة الرؤية والرسالة",
            "استخدام طرق تصميم الهيكل التنظيمي",
            "تطبيق منهجيات تحديد الأدوار",
            "استخدام تقنيات تصميم إطار الحوكمة"
          ],
          templates: ["نموذج ميثاق مكتب إدارة المشاريع", "مخطط هيكل الحوكمة"]
        },
        "2-processing-3": {
          stage: "المعالجة",
          title: "تطبيق منهجية تصميم الحوكمة",
          description: "استخدام تقنيات تصميم الحوكمة لتطوير عمليات اتخاذ القرار وآليات الإشراف.",
          bestPractices: [
            "تطبيق تقنيات رسم خرائط حقوق اتخاذ القرار",
            "استخدام طرق تصميم مسارات التصعيد",
            "تطبيق منهجيات تصميم هيئات الحوكمة",
            "استخدام تقنيات تخطيط الاتصال للحوكمة"
          ],
          templates: ["نموذج إطار الحوكمة", "مصفوفة حقوق اتخاذ القرار"]
        },
        "2-output-1": {
          stage: "الإخراج",
          title: "إقرار تفويض وميثاق مكتب إدارة المشاريع",
          description: "إضفاء الطابع الرسمي وتنفيذ تفويض وميثاق مكتب إدارة المشاريع مع تحديد الغرض والصلاحيات والمسؤوليات.",
          bestPractices: [
            "الحصول على موافقة الإدارة العليا على التفويض والميثاق",
            "إبلاغ جميع أصحاب المصلحة بالتفويض",
            "تنفيذ هياكل الصلاحيات المحددة في الميثاق",
            "وضع عملية لمراجعة وتحديث الميثاق"
          ],
          templates: ["تفويض مكتب إدارة المشاريع المعتمد", "ميثاق مكتب إدارة المشاريع النهائي"]
        },
        "2-output-2": {
          stage: "الإخراج",
          title: "تنفيذ إطار الحوكمة",
          description: "تأسيس وتفعيل إطار الحوكمة مع هيئات اتخاذ القرار والعمليات وآليات الإشراف.",
          bestPractices: [
            "تشكيل لجان الحوكمة مع مواثيق واضحة",
            "تنفيذ عمليات وسلطات اتخاذ القرار",
            "تحديد وتيرة اجتماعات الحوكمة وجدول الأعمال",
            "إنشاء نظام لتوثيق الحوكمة والتقارير"
          ],
          templates: ["ميثاق لجنة الحوكمة", "مصفوفة سلطات اتخاذ القرار"]
        },
        "2-output-3": {
          stage: "الإخراج",
          title: "تطوير خطة الاتصال الاستراتيجية",
          description: "تنفيذ استراتيجية اتصال شاملة برسائل مخصصة لأصحاب المصلحة وآليات للتغذية الراجعة.",
          bestPractices: [
            "إنشاء مواد اتصال مخصصة لكل فئة من أصحاب المصلحة",
            "تحديد وتيرة اتصال منتظمة",
            "تنفيذ آليات لجمع التغذية الراجعة",
            "تطوير مؤشرات لقياس فعالية الاتصال"
          ],
          templates: ["خطة الاتصال الاستراتيجية", "مصفوفة رسائل أصحاب المصلحة"]
        }
      }
    },
    "3": {
      name: "هيكل وتصميم مكتب إدارة المشاريع",
      description: "إنشاء الهيكل الأمثل لمكتب إدارة المشاريع لتلبية احتياجات المؤسسة.",
      tasks: {
        "3-input-1": {
          stage: "الإدخال",
          title: "جمع بيانات العملاء",
          description: "جمع بيانات عن العملاء المحتملين لمكتب إدارة المشاريع، واحتياجاتهم وتوقعاتهم من خلال الاستبيانات والمقابلات.",
          bestPractices: [
            "إجراء استبيانات تقييم احتياجات العملاء",
            "جمع بيانات مقابلات أصحاب المصلحة",
            "توثيق نقاط الألم وتوقعات العملاء",
            "جمع معلومات حول أولويات الخدمات"
          ]
        },
        "3-input-2": {
          stage: "الإدخال",
          title: "جمع بيانات متطلبات الخدمة",
          description: "جمع متطلبات مفصلة للخدمات المحتملة لمكتب إدارة المشاريع من خلال ورش العمل وجلسات تحديد المتطلبات.",
          bestPractices: [
            "تنظيم ورش عمل لتحديد متطلبات الخدمات",
            "توثيق توقعات مستويات الخدمة",
            "جمع معايير ترتيب أولويات الخدمة",
            "جمع بيانات مرجعية عن خدمات مماثلة"
          ],
          templates: ["نموذج متطلبات الخدمة", "تقييم احتياجات العملاء"]
        },
        "3-input-3": {
          stage: "الإدخال",
          title: "تقييم فجوات القدرات",
          description: "جمع بيانات عن القدرات الحالية والفجوات من خلال أدوات التقييم وملاحظات أصحاب المصلحة.",
          bestPractices: [
            "استخدام أدوات تقييم نضج القدرات",
            "جمع بيانات مرجعية عن القدرات",
            "توثيق معايير ترتيب أولويات القدرات",
            "جمع معلومات عن توفر الموارد"
          ]
        },
        "3-processing-1": {
          stage: "المعالجة",
          title: "تطبيق تقنيات تطوير الشخصيات (Personas)",
          description: "استخدام منهجيات تطوير الشخصيات لإنشاء شخصيات عملاء مفصلة تشمل الاحتياجات والتوقعات.",
          bestPractices: [
            "تطبيق تقنيات تقسيم العملاء إلى شرائح",
            "استخدام أطر تطوير الشخصيات",
            "تطبيق منهجيات تحليل الاحتياجات",
            "استخدام تقنيات رسم خرائط رحلات العميل"
          ]
        },
        "3-processing-2": {
          stage: "المعالجة",
          title: "تطبيق أطر تحديد الأولويات",
          description: "استخدام تقنيات تحديد الأولويات لتطوير إطار يعالج احتياجات العملاء بشكل منهجي.",
          bestPractices: [
            "تطبيق مصفوفة القيمة مقابل الجهد",
            "استخدام تقنية MoSCoW لتحديد الأولويات",
            "تطبيق منهجيات التقييم بالنقاط المرجحة",
            "استخدام تقنيات رسم خرائط التأثير"
          ]
        },
        "3-processing-3": {
          stage: "المعالجة",
          title: "تطبيق منهجية تصميم كتالوج الخدمة",
          description: "استخدام تقنيات تصميم كتالوج الخدمة لتطوير عروض شاملة تشمل المزايا والقيم المضافة.",
          bestPractices: [
            "تطبيق أطر تعريف الخدمة",
            "استخدام تقنيات تحديد مستويات الخدمة",
            "تطبيق منهجيات تطوير القيمة المقترحة",
            "استخدام تقنيات تصنيف الخدمات"
          ],
          templates: ["نموذج كتالوج الخدمة", "نموذج اتفاقية مستوى الخدمة"]
        },
        "3-output-1": {
          stage: "الإخراج",
          title: "تسليم شخصيات العملاء ورحلاتهم",
          description: "إنشاء وتوزيع شخصيات العملاء التفصيلية ورحلاتهم لتوجيه تصميم وتقديم الخدمات.",
          bestPractices: [
            "توثيق شخصيات شاملة مع الاحتياجات ونقاط الألم",
            "إنشاء خرائط مرئية لرحلات العميل في التفاعلات الرئيسية",
            "توزيع الشخصيات على جميع فرق تقديم الخدمة",
            "إرساء عملية لتحديث وتحسين الشخصيات"
          ],
          templates: ["نموذج شخصية العميل", "نموذج خريطة الرحلة"]
        },
        "3-output-2": {
          stage: "الإخراج",
          title: "تنفيذ كتالوج الخدمة واتفاقيات مستويات الخدمة",
          description: "إطلاق كتالوج شامل للخدمة يتضمن اتفاقيات مستوى الخدمة والعمليات والمعايير.",
          bestPractices: [
            "إنشاء أوصاف تفصيلية للخدمة مع قيم مقترحة",
            "تحديد مؤشرات وأهداف مستويات الخدمة",
            "تنفيذ عمليات تقديم وطلب الخدمة",
            "إنشاء آلية لمراجعة وتحديث كتالوج الخدمة"
          ],
          templates: ["وثيقة كتالوج الخدمة", "توثيق SLA"]
        },
        "3-output-3": {
          stage: "الإخراج",
          title: "إرساء إطار تحديد أولويات الخدمة",
          description: "تنفيذ نهج منهجي لتحديد أولويات ومعالجة احتياجات العملاء وطلبات الخدمة.",
          bestPractices: [
            "إنشاء معايير ونظام تقييم لتحديد الأولويات",
            "تنفيذ عملية استقبال وتقييم الطلبات",
            "تحديد توزيع الموارد بناءً على الأولويات",
            "تطوير آليات لمراجعة وتعديل الأولويات"
          ],
          templates: ["مصفوفة تحديد الأولويات", "نموذج طلب الخدمة"]
        }
      }
    },
    "4": {
      name: "التميز التشغيلي",
      description: "ضمان عمليات وأدوات إدارة المشاريع الفعالة والناجحة.",
      tasks: {
        "4-input-1": {
          stage: "الإدخال",
          title: "جمع متطلبات التأهيل (Onboarding)",
          description: "جمع المتطلبات والتوقعات الخاصة بعملية تأهيل العملاء من خلال مدخلات أصحاب المصلحة.",
          bestPractices: [
            "إجراء تقييم لاحتياجات التأهيل",
            "جمع توقعات أصحاب المصلحة لعملية التأهيل",
            "توثيق التحديات الحالية في التأهيل",
            "جمع أفضل الممارسات في مجال التأهيل"
          ]
        },
        "4-input-2": {
          stage: "الإدخال",
          title: "جمع متطلبات التوثيق",
          description: "جمع متطلبات توثيق العمليات وأدلة المستخدم ومواد التدريب.",
          bestPractices: [
            "إجراء تقييم لاحتياجات التوثيق",
            "جمع تفضيلات المستخدمين لصيغ التوثيق",
            "توثيق الفجوات الحالية في التوثيق",
            "جمع أفضل ممارسات التوثيق"
          ],
          templates: ["نموذج متطلبات التوثيق", "مخطط دليل المستخدم"]
        },
        "4-input-3": {
          stage: "الإدخال",
          title: "تقييم احتياجات التدريب",
          description: "جمع بيانات حول احتياجات التدريب وتفضيلات طرق تقديمه من خلال الاستبيانات والمقابلات.",
          bestPractices: [
            "إجراء تقييم لاحتياجات التدريب",
            "جمع تفضيلات أساليب التعلم",
            "توثيق فجوات المعرفة والمهارات",
            "جمع معايير فعالية التدريب"
          ]
        },
        "4-processing-1": {
          stage: "المعالجة",
          title: "تطبيق تقنيات إدارة الجودة",
          description: "استخدام منهجيات إدارة الجودة لتطوير إجراءات الرقابة والتحسين المستمر.",
          bestPractices: [
            "تطبيق تقنيات تطوير معايير الجودة",
            "استخدام أساليب تصميم نقاط الرقابة",
            "تطبيق أطر تطوير مؤشرات الجودة",
            "استخدام منهجيات التحسين المستمر"
          ]
        },
        "4-processing-2": {
          stage: "المعالجة",
          title: "تطبيق منهجيات إدارة الموارد",
          description: "استخدام تقنيات إدارة الموارد لتطوير أنظمة التخصيص وخطط القدرة الاستيعابية.",
          bestPractices: [
            "تطبيق تقنيات تخطيط سعة الموارد",
            "استخدام أساليب تحديد أولويات تخصيص الموارد",
            "تطبيق منهجيات التنبؤ بالموارد",
            "استخدام تقنيات تحسين استخدام الموارد"
          ],
          templates: ["خطة إدارة الموارد", "نموذج تخطيط السعة"]
        },
        "4-processing-3": {
          stage: "المعالجة",
          title: "تطبيق إطار إدارة المشكلات",
          description: "استخدام منهجيات إدارة المشكلات لتطوير إجراءات التصعيد وآليات الحل.",
          bestPractices: [
            "تطبيق تقنيات تعريف حدود التصعيد",
            "استخدام أساليب تصميم مسارات التصعيد",
            "تطبيق أطر تصنيف المشكلات",
            "استخدام تقنيات تحديد معايير أوقات الحل"
          ],
          templates: ["نموذج إجراء التصعيد", "إطار إدارة المشكلات"]
        },
        "4-output-1": {
          stage: "الإخراج",
          title: "تنفيذ نظام إدارة الجودة",
          description: "إنشاء نظام شامل لإدارة الجودة يتضمن المعايير، عمليات الرقابة، وآليات التحسين.",
          bestPractices: [
            "توثيق معايير الجودة لجميع الخدمات",
            "تنفيذ نقاط رقابة ومراجعة الجودة",
            "إنشاء نظام لجمع وتقديم تقارير مؤشرات الجودة",
            "إنشاء عملية تحسين جودة مستمرة"
          ],
          templates: ["وثيقة معايير الجودة", "قائمة مراجعة الجودة"]
        },
        "4-output-2": {
          stage: "الإخراج",
          title: "إنشاء نظام إدارة الموارد",
          description: "تنفيذ نظام لإدارة الموارد يشمل تخطيط السعة، عمليات التخصيص، وتتبع الاستخدام.",
          bestPractices: [
            "إنشاء جرد الموارد ومصفوفة المهارات",
            "تنفيذ عمليات تخطيط وتوقع السعة",
            "إرساء إجراءات تخصيص وتوزيع الموارد",
            "تطوير نظام تتبع وتقرير استخدام الموارد"
          ],
          templates: ["مصفوفة تخصيص الموارد", "لوحة تخطيط السعة"]
        },
        "4-output-3": {
          stage: "الإخراج",
          title: "نشر نظام إدارة المشكلات",
          description: "تنفيذ نظام شامل لإدارة المشكلات يشمل إجراءات التصعيد، التتبع، وآليات الحل.",
          bestPractices: [
            "إنشاء عملية استقبال وتصنيف المشكلات",
            "تنفيذ مسارات التصعيد ونظام الإشعارات",
            "إنشاء نظام تتبع المشكلات وتقرير الحالة",
            "تطوير إجراءات التحقق من الحل والإغلاق"
          ],
          templates: ["دليل إدارة المشكلات", "مصفوفة التصعيد"]
        }
      }
    },
    "5": {
      name: "الأداء والتحسين",
      description: "تحسين خدمات مكتب إدارة المشاريع وقدراته وتقديم القيمة بشكل مستمر.",
      tasks: {
        "5-input-1": {
          stage: "الإدخال",
          title: "جمع بيانات تقييم النضج",
          description: "جمع بيانات حول نضج مكتب إدارة المشاريع الحالي باستخدام أدوات التقييم، الاستبيانات، ومدخلات أصحاب المصلحة.",
          bestPractices: [
            "اختيار أداة تقييم النضج المناسبة",
            "جمع بيانات تقييم شاملة",
            "توثيق خط الأساس للنضج عبر الأبعاد المختلفة",
            "جمع معلومات حول أهداف النضج المستقبلية"
          ]
        },
        "5-input-2": {
          stage: "الإدخال",
          title: "جمع بيانات الأداء",
          description: "جمع مؤشرات الأداء الحالية، الاتجاهات التاريخية، والأهداف الخاصة بالأداء.",
          bestPractices: [
            "جمع مؤشرات الأداء الحالية",
            "جمع بيانات الأداء التاريخية",
            "توثيق الأهداف والحدود الخاصة بالأداء",
            "جمع معلومات معيارية حول الأداء"
          ]
        },
        "5-input-3": {
          stage: "الإدخال",
          title: "تقييم أساليب قياس القيمة",
          description: "جمع بيانات حول مؤشرات القيمة المحتملة، أساليب القياس، وطرق توضيح القيمة.",
          bestPractices: [
            "جمع خيارات مؤشرات القيمة",
            "جمع منهجيات قياس القيمة",
            "توثيق تصور أصحاب المصلحة للقيمة",
            "تقييم الأساليب الحالية لتوضيح القيمة"
          ]
        },
        "5-processing-1": {
          stage: "المعالجة",
          title: "تطبيق تقنيات تخطيط خارطة طريق النضج",
          description: "استخدام منهجيات تخطيط خارطة طريق النضج لتطوير خطة تحسين تحتوي على مراحل ومعايير قياس.",
          bestPractices: [
            "تطبيق تقنيات تحليل فجوات النضج",
            "استخدام طرق تحديد أولويات القدرات",
            "تطبيق أطر تطوير مراحل التحسين",
            "استخدام تقنيات تحديد المقاييس والمعايير"
          ]
        },
        "5-processing-2": {
          stage: "المعالجة",
          title: "تطبيق منهجيات إدارة التغيير",
          description: "استخدام تقنيات إدارة التغيير لتطوير نهج تنفيذ لمبادرات النضج.",
          bestPractices: [
            "تطبيق تقنيات تحليل تأثير أصحاب المصلحة",
            "استخدام أساليب إدارة المقاومة",
            "تطبيق أطر تخطيط الاتصال",
            "استخدام تقنيات قياس التبني"
          ],
          templates: ["خطة إدارة التغيير", "خطة إشراك أصحاب المصلحة"]
        },
        "5-processing-3": {
          stage: "المعالجة",
          title: "تطبيق أطر التحسين المستمر",
          description: "استخدام منهجيات التحسين المستمر لتطوير عمليات تحسين منظمة ومنهجية.",
          bestPractices: [
            "تطبيق تقنيات تحديد فرص التحسين",
            "استخدام أساليب تحديد أولويات التحسين",
            "تطبيق أطر تخطيط التنفيذ",
            "استخدام تقنيات قياس فعالية التحسين"
          ]
        },
        "5-output-1": {
          stage: "الإخراج",
          title: "تنفيذ خارطة طريق تحسين النضج",
          description: "إنشاء وتنفيذ خارطة طريق شاملة لتحسين النضج تتضمن مراحل ومعايير مراجعة ومتابعة.",
          bestPractices: [
            "توثيق خطة تحسين النضج بشكل مفصل",
            "تنفيذ تتبع ومراقبة مراحل التحسين",
            "إرساء عملية جمع وتحليل مؤشرات النضج",
            "إنشاء عملية مراجعة وتعديل دوري للنضج"
          ],
          templates: ["خارطة طريق تحسين النضج", "لوحة مؤشرات النضج"]
        },
        "5-output-2": {
          stage: "الإخراج",
          title: "إنشاء نظام قياس القيمة",
          description: "تنفيذ نظام شامل لقياس القيمة يتضمن مؤشرات، تقارير، وآليات لتوضيح القيمة.",
          bestPractices: [
            "تحديد وتنفيذ مؤشرات القيمة ومؤشرات الأداء الرئيسية",
            "إنشاء عملية جمع وتحليل بيانات القيمة",
            "إرساء آلية إعداد تقارير القيمة وتصورها",
            "تطوير دراسات حالة لتوضيح القيمة"
          ],
          templates: ["إطار قياس القيمة", "لوحة عرض القيمة"]
        },
        "5-output-3": {
          stage: "الإخراج",
          title: "تطبيق برنامج التحسين المستمر",
          description: "تنفيذ برنامج تحسيني منهجي يتضمن تحديد، وتقييم، وتنفيذ فرص التحسين.",
          bestPractices: [
            "إنشاء عملية تحديد فرص التحسين",
            "إنشاء نظام لتحديد واختيار أولويات التحسين",
            "تنفيذ نظام تتبع وتحليل تحسينات الأداء",
            "تطوير عملية قياس فعالية التحسين"
          ],
          templates: ["دليل التحسين المستمر", "نظام تتبع التحسين"]
        }
      }
    },
    "6": {
      name: "تطوير القدرات",
      description: "تطوير وإدارة الجوانب البشرية لمكتب إدارة المشاريع بما في ذلك الكفاءة والتدريب والقيادة.",
      tasks: {
        "6-input-1": {
          stage: "الإدخال",
          title: "جمع بيانات اتخاذ القرار",
          description: "جمع بيانات حول عمليات اتخاذ القرار الحالية، استخدام البيانات، وفرص التحسين.",
          bestPractices: [
            "توثيق عمليات اتخاذ القرار الحالية",
            "تقييم استخدام البيانات في اتخاذ القرار",
            "تحديد اختناقات اتخاذ القرار",
            "جمع مقاييس جودة القرارات"
          ]
        },
        "6-input-2": {
          stage: "الإدخال",
          title: "تقييم متطلبات الكفاءات",
          description: "جمع بيانات حول الكفاءات المطلوبة، القدرات الحالية، واحتياجات التطوير.",
          bestPractices: [
            "توثيق متطلبات الكفاءات الخاصة بكل دور",
            "تقييم مستويات الكفاءة الحالية",
            "تحديد الفجوات الحرجة في الكفاءات",
            "جمع معلومات تفضيلات التطوير"
          ],
          templates: ["نموذج تقييم الكفاءات", "تحليل احتياجات التطوير"]
        },
        "6-input-3": {
          stage: "الإدخال",
          title: "جمع بيانات تقييم المهارات",
          description: "جمع بيانات شاملة عن المهارات من خلال التقييمات، التقييمات الذاتية، وتعليقات المديرين.",
          bestPractices: [
            "استخدام أدوات تقييم المهارات المعيارية",
            "جمع بيانات التقييم الذاتي",
            "جمع مدخلات تقييم المديرين",
            "توثيق معايير تحديد أولويات المهارات"
          ]
        },
        "6-processing-1": {
          stage: "المعالجة",
          title: "تطبيق منهجية تصميم برامج التدريب",
          description: "استخدام تقنيات تصميم التدريب لتطوير برامج تدريب وشهادات شاملة.",
          bestPractices: [
            "تطبيق تقنيات تطوير الأهداف التعليمية",
            "استخدام منهجيات تصميم المناهج",
            "تطبيق أطر اختيار أساليب التعلم",
            "استخدام تصميم قياس فعالية التدريب"
          ]
        },
        "6-processing-2": {
          stage: "المعالجة",
          title: "تطبيق تطوير أطر الابتكار",
          description: "استخدام تقنيات أطر الابتكار لتطوير عمليات لتعزيز الابتكار وحل المشكلات.",
          bestPractices: [
            "تطبيق منهجيات تصميم عمليات الابتكار",
            "استخدام تقنيات اختيار توليد الأفكار",
            "تطبيق أطر تقييم الأفكار",
            "تصميم نظام حوافز للابتكار"
          ]
        },
        "6-processing-3": {
          stage: "المعالجة",
          title: "تطبيق تقنيات إدارة المعرفة",
          description: "استخدام منهجيات إدارة المعرفة لتصميم منصة مشاركة المعرفة ومجتمعات الممارسة.",
          bestPractices: [
            "تطبيق تقنيات تصميم مستودع المعرفة",
            "استخدام أطر تصنيف المعرفة",
            "تطبيق منهجيات تصميم مجتمعات الممارسة",
            "تصميم نظام حوافز للمساهمة بالمعرفة"
          ]
        },
        "6-output-1": {
          stage: "الإخراج",
          title: "تنفيذ إطار تطوير الكفاءات",
          description: "إرساء إطار شامل للكفاءات يتضمن التقييم، مسارات التطوير، وبرامج الشهادات.",
          bestPractices: [
            "توثيق متطلبات الكفاءات الخاصة بالأدوار",
            "إنشاء نظام تقييم وتتبع الكفاءات",
            "تنفيذ مسارات تطوير لكل مجال كفاءة",
            "إرساء برنامج شهادات وتقدير"
          ],
          templates: ["وثيقة إطار الكفاءات", "دليل مسارات التطوير"]
        },
        "6-output-2": {
          stage: "الإخراج",
          title: "نشر نظام الابتكار وحل المشكلات",
          description: "تنفيذ برنامج ابتكار منظم يشمل توليد الأفكار، التقييم، والتنفيذ.",
          bestPractices: [
            "إنشاء نظام لجمع وتوليد الأفكار",
            "إنشاء عملية تقييم واختيار الأفكار",
            "تنفيذ دعم لتنفيذ الابتكارات",
            "تطوير نظام حوافز وتقدير للابتكار"
          ],
          templates: ["دليل عملية الابتكار", "مصفوفة تقييم الأفكار"]
        },
        "6-output-3": {
          stage: "الإخراج",
          title: "إنشاء نظام إدارة المعرفة",
          description: "تنفيذ نظام شامل لإدارة المعرفة يشمل مستودع، آليات مشاركة، ومجتمعات ممارسة.",
          bestPractices: [
            "إنشاء مستودع معرفة بنظام تصنيف",
            "إرساء عمليات المساهمة بالمعرفة",
            "تشكيل مجتمعات ممارسة بمواثيق واضحة",
            "تنفيذ فعاليات وأنشطة لمشاركة المعرفة"
          ],
          templates: ["دليل إدارة المعرفة", "ميثاق مجتمع الممارسة"]
        }
      }
    }
  },

  // Resources page
  resources: {
    search: "بحث",
    title: "مكتبة أفضل الممارسات",
    subtitle: "تصفح الموارد والقوالب وأفضل الممارسات لتنفيذ مكتب إدارة المشاريع الخاص بك",
    searchPlaceholder: "البحث عن أفضل الممارسات والقوالب والأدلة...",
    noDocumentsFound: "لا توجد مستندات",
    noDocumentsMessage: "لا توجد مستندات لديك حتى الآن. قم بإكمال المهام لإنشاء المستندات.",
    noDocumentsDescription: "لا توجد مستندات تطابق معايير البحث الحالية. حاول تعديل معايير البحث.",
    clearFilters: "مسح الفلاتر",
    categories: "الفئات",
    documentTypes: "أنواع المستندات",
    tags: "العلامات",
    allResources: "جميع الموارد",
    featured: "مميز",
    templates: "القوالب",
    recentlyAdded: "أضيف مؤخرًا",
    document: "مستند",
    documentDocx: "مستند.docx",
    documents: "مستندات",
    page: "صفحة",
    preview: "معاينة",
    hidePreview: "إخفاء المعاينة",
    viewFullDocument: "عرض المستند كاملاً",
    exportPdf: "تصدير PDF",
    updated: "تم التحديث",
    views: "مشاهدات",
    relatedResources: "موارد ذات صلة",
    viewDocument: "عرض المستند",
    featuredResources: "موارد مميزة",
    viewAll: "عرض الكل",
    externalResources: "موارد خارجية لمكتب إدارة المشاريع",
    externalResourcesDesc: "الوصول إلى موارد إضافية من مصادر موثوقة في الصناعة لتكملة رحلة تنفيذ مكتب إدارة المشاريع الخاص بك.",
    browseExternalResources: "تصفح الموارد الخارجية",
    previous: "السابق",
    next: "التالي",
    backToResources: "العودة إلى الموارد",
    downloadAsPdf: "تنزيل كـ PDF",
    generatingPdf: "جاري إنشاء PDF...",
    manageResources: "إدارة الموارد",
    resourcesLibrary: "مكتبة الموارد",
    browseBestPractices: "تصفح أفضل الممارسات",
    relatedDocuments: "مستندات ذات صلة",
    relatedDocument: "مستند ذات صلة",
    sampleRelatedDocumentDescription: "وصف مستند ذات صلة عيني",
    loadingResources: "جاري تحميل الموارد...",    
    errorLoadingDocuments: "خطأ في تحميل المستندات",
    tryAgain: "حاول مرة أخرى",
    searchDocuments: "البحث في المستندات...",
    filters: "المرشحات",
    noMatchingDocuments: "لا توجد مستندات مطابقة",
    tryAdjustingFilters: "لا توجد مستندات تطابق المرشحات الحالية. حاول تعديل البحث أو المرشحات.",
    download: "تنزيل",
    source: "المصدر",
    created: "تم الإنشاء",
    domainOutput: "مخرجات المجال",
    taskAttachment: "مرفق المهمة",
    unknownSource: "مصدر غير معروف",
    unknown: "غير معروف",
    unknownTask: "مهمة غير معروفة",
    unknownDate: "تاريخ غير معروف",
    invalidDate: "تاريخ غير صالح",
    docxExtension: ".docx",
    downloadInitiated: "بدأ التنزيل",
    failedToLoadDocuments: "فشل في تحميل المستندات. الرجاء المحاولة مرة أخرى.",
    failedToDownloadDocument: "فشل في تنزيل المستند",
    errorFetchingDocuments: "خطأ في جلب المستندات:",
    errorDownloadingDocument: "خطأ في تنزيل المستند:",
    filteredInvalidDocuments: "تمت تصفية {count} من إدخالات المستندات غير الصالحة",
  },

  // Export PDF
  export: {
    generatedOn: "تم الإنشاء في",
    page: "صفحة",
    tableOfContents: "جدول المحتويات",
    copyright: "© بناء مكتب إدارة المشاريع باستخدام الذكاء الاصطناعي"
  },

  // Tasks
  tasks: {
    tasks: "المهام",
    manageAndTrackYourPmoImplementationTasks: "إدارة وتتبع مهام تنفيذ مكتب إدارة المشاريع",
    allTasks: "جميع المهام",
    completed: "مكتملة",
    incomplete: "غير مكتملة",
    total: "المجموع",
    progress: "التقدم",
    rate: "التقييم",
    addCustomTask: "إضافة مهمة خاصة",
    searchTasks: "بحث عن مهام...",
    filters: "الفلاتر",
    clear: "مسح",
    allDomains: "جميع المجالات",
    allStages: "جميع المراحل",
    input: "إدخال",
    processing: "المعالجة",
    output: "الإخراج",
    domain: "المجال",
    stage: "المرحلة",
    status: "الحالة",
    clearFilters: "مسح الفلاتر",
    noTasksFound: "لا توجد مهام",
    noTasksMatchFilters: "لا توجد مهام تطابق المعايير الحالية. حاول إعادة الفلاتر أو مسحها.",
    noTasksAvailable: "لا توجد مهام متاحة. أضف مهمة جديدة.",
    taskManagementTips: "نصائح في إدارة المهام",
    taskManagementTipsDescription: "قم بترتيب المهام بناءً على مستوى نضج مكتب إدارة المشاريع الخاص بك والأهداف التنظيمية. قم بإكمال مهام المرحلة الأولى (الإدخال) أولاً قبل الانتقال إلى المرحلة الثانية (المعالجة) والمرحلة الثالثة (الإخراج) للحصول على أفضل النتائج.",
    viewBestPractices: "عرض أفضل الممارسات",
    relatedDocuments: "مستندات ذات صلة",
    viewFullContent: "عرض المحتوى كاملاً",
    generateTaskOutput: "إنشاء إخراج المهام",
    templates: "القوالب",
    templateForStandardizedImplementation: "قالب لتنفيذ معياري",
    viewTemplate: "عرض القالب",
    bestPractices: "أفضل الممارسات",
    priority: "الأولوية",
    targetCompletionDate: "تاريخ الانتهاء المستهدف",
    assignedTo: "معين إلى",
    estimatedHours: "ساعات مقدرة",
    attachments: "الملفات المرفقة",
    notes: "ملاحظات",
    saving: "جاري الحفظ...",
    saveChanges: "حفظ التغييرات",
    completion: "الانتهاء",
    completionToggle: "تحويل الانتهاء",
    completionToggleDescription: "تحويل المهام المكتملة إلى غير مكتملة",
    addNotes: "إضافة ملاحظات حول هذه المهمة...",
    addTask: "إضافة مهمة",
    taskName: "اسم المهمة",
    taskNamePlaceholder: "أدخل اسم المهمة",
    taskDescription: "وصف المهمة",
    taskDescriptionPlaceholder: "أدخل وصف المهمة",
    low: "منخفض",
    medium: "متوسط",
    high: "عالي",
    addAttachment: "إضافة ملف مرفق",
    addAttachmentDescription: "أضف ملفات مرفقة لتسهيل التعامل مع المهمة",
    addAttachmentPlaceholder: "اختر ملفًا مرفقًا",
    enterNameOrEmail: "أدخل الاسم أو البريد الإلكتروني",
    enterEstimatedHours: "أدخل ساعات مقدرة",
    enterTargetCompletionDate: "أدخل تاريخ الانتهاء المستهدف",
    enterAssignedTo: "أدخل المعين إلى",
    enterTaskDescription: "أدخل وصف المهمة",
    enterTaskName: "أدخل اسم المهمة",
    markAsCompleted: "تحديد المهمة كمكتملة",
    attachmentsDescription: "أضف ملفات مرفقة لتسهيل التعامل مع المهمة",
    attachmentsPlaceholder: "اختر ملفًا مرفقًا",
    dragAndDropFilesHere: "قم بإسقاط الملفات هنا أو انقر لتحديد الملفات",
    supportedFormats: "التنسيقات المدعومة: الصور والمستندات والجداول والمزيد (الحد الأقصى 10MB)",
    uploading: "جاري الرفع...",
    workingInOfflineMode: "العمل في وضع عدم الاتصال",
    filesWillBeStoredLocallyUntilYourConnectionIsRestored: "سيتم تخزين الملفات بشكل محلي حتى يتم استرجاع الاتصال",
    noAttachmentsAddedYet: "لا يوجد ملفات مرفقة بعد",
    close: "إغلاق",
    taskOutputGenerator: "مولد إخراج المهام",
    generateComprehensiveOutputDeliverableForThisTaskBasedOnBestPracticesDomainContextAndYourOrganizationDocuments: "إنشاء إخراج مكتمل لهذه المهمة بناءً على أفضل الممارسات والسياق المجالي والمستندات الخاصة بك",
    ourAIWillAnalyzeYourTaskRequirementsAndContextToCreateAPersonalizedComprehensiveDeliverableForThisSpecificTask: "ستقوم الذكاء الاصطناعي بتحليل متطلبات المهمة والسياق وإنشاء إخراج مكتمل ومخصص لهذه المهمة",
    creatingPersonalizedPromptForThisTask: "إنشاء تحفيز مخصص لهذه المهمة...",
    creatingPrompt: "إنشاء تحفيز...",
    viewTaskPrompt: "عرض تحفيز المهمة",
    savedTaskOutput: "إخراج المهمة المحفوظ",
    regenerate: "إعادة إنشاء",
    exportPDF: "تصدير PDF",
    visualizingProcessMap: "عرض الخريطة العملية",
    generatedTaskOutput: "إخراج المهمة المولد",
    saved: "محفوظ",
    save: "حفظ",
    exporting: "جاري التصدير...",
    aboutTaskSpecificGeneration: "حول إنشاء إخراج مهمة خاصة", 
    thisFeatureCreatesPersonalizedContentTailoredToThisSpecificTaskUsing: "ينشئ هذا الميزة تحت المحتوى المخصص لهذه المهمة باستخدام:",
    aiGeneratedTaskSpecificPrompts: "تحفيزات مولدة من الذكاء الاصطناعي لهذه المهمة",
    externalKnowledgeSourcesForValidationAndEnrichment: "مصادر المعرفة الخارجية للتحقق والتعزيز",
    domainContextAndRelatedDocuments: "السياق المجالي والمستندات المتعلقة",
    taskDetailsAndBestPractices: "تفاصيل المهمة وأفضل الممارسات",    
    generatePersonalizedOutput: "إنشاء إخراج مخصص",
    generating: "جاري الإنشاء...",
    generatingPersonalizedOutput: "جاري إنشاء إخراج مخصص...",
    generatingPersonalizedOutputDescription: "ستقوم الذكاء الاصطناعي بتحليل متطلبات المهمة والسياق وإنشاء إخراج مكتمل ومخصص لهذه المهمة",
    editTask: "تعديل المهمة",
    inProgress: "قيد التنفيذ",
    availableTemplates: "القوالب المتاحة",
    purpose: "الغرض",
    templateForStandardized: "يوفر هذا القالب إطارًا منظمًا لتنفيذ وإدارة",
    withinYourPMO: "العمليات داخل مكتب إدارة المشاريع الخاص بك",
    overview: "الملخص",
    download: "تحميل",
    useTemplate: "استخدام القالب",
    template: `
    ## أقسام النموذج

### 1. المقدمة
- الغرض والأهداف
- النطاق وإمكانية التطبيق
- أصحاب المصلحة الرئيسيون

### 2. إطار العمل
- نظرة عامة على المنهجية
- الأنشطة الرئيسية والمخرجات
- الأدوار والمسؤوليات

### 3. دليل التنفيذ
- تعليمات خطوة بخطوة
- أفضل الممارسات والإرشادات
- التحديات والحلول الشائعة

### 4. المراقبة والتحكم
- مؤشرات الأداء الرئيسية
- تدابير ضمان الجودة
- متطلبات إعداد التقارير

### 5. التحسين المستمر
- آليات التغذية الراجعة
- عملية المراجعة
- إجراءات التحديث

## الملاحق
- النماذج والأدوات ذات الصلة
- المواد المرجعية
- مسرد المصطلحات

---

*هذا النموذج جزء من مكتبة مكتب إدارة المشاريع. خصّصه ليناسب احتياجات مؤسستك الخاصة.*
    `
  },

  // Document Processor
  documentProcessor: {
    title: "معالجة المستندات",
    supportedFormats: "التنسيقات المدعومة: .txt, .md, .html, .docx, .pdf",
    browseFiles: "تصفح الملفات",
    change: "تغيير",
    processing: "جاري المعالجة...",
    processDocument: "معالجة المستند",
    documentProcessedSuccessfully: "تم معالجة المستند بنجاح",
    documentSplitIntoChunksForOptimalAnalysis: "تم تقسيم المستند إلى {processedDoc.totalChunks} منطقة للتحليل الأمثل",
    documentAutomaticallyAddedToAnalysis: "تم إضافة المستند تلقائيًا إلى التحليل",
    itWillBeUsedToEnhanceAIResponsesInThisDomain: "سيتم استخدامه لتعزيز الاستجابات الذكية في هذا المجال",
    limitedFunctionalityInOfflineMode: "الوظيفة مقتصرة على الاتصال",
    documentProcessingMayBeLimitedWhileWorkingOffline: "قد يتم تقييد المعالجة المستندات أثناء العمل عديم الاتصال",
    dragAndDropYourDocumentHereOrClickToBrowse: "قم بإسقاط المستند هنا أو انقر لتحديد المستند",
    availableInAnalysis: "متاح في التحليل",
    recentlyProcessedDocuments: "المستندات المعالجة مؤخراً",
    recentlyProcessedDocumentsDescription: "المستندات التي تم معالجتها بنجاح مؤخراً والتي سيتم استخدامها في التحليل",
    whyProcessDocuments: "لماذا يجب معالجة المستندات؟",
    breakingDownLargeDocumentsAllowsAIToAnalyzeThemMoreEffectivelyAndReferenceSpecificSections: "تقسيم المستندات الكبيرة إلى أجزاء أصغر يساعد الذكاء الاصطناعي في تحليلها بشكل أكثر فعالية والرجوع إلى الأجزاء المعينة.",
    processedDocumentsAppearAutomaticallyInTheAnalysisTabAndEnhanceAIResponsesWithYourDomainSpecificContext: "يظهر المستندات المعالجة تلقائيًا في علامة التحليل ويعزز الاستجابات الذكية بالسياق المجالي الخاص بك.",
    useSampleData: "استخدام البيانات العينية",
    showSampleData: "إظهار البيانات العينية",
    hideSampleData: "إخفاء البيانات العينية",
    sampleInputData: "بيانات المدخلات العينية",
    showPreviousDomainOutput: "إظهار إخراج المجال السابق",
    hidePreviousDomainOutput: "إخفاء إخراج المجال السابق",
  }
  
};

export const translations: Record<string, any> = { en, ar };
// Translation keys organized by component/page
// English translations
const en = {
  // Common components
  common: {
    pleaseWait: "Please wait while we prepare your content.",
    Complete : "Complete",
    search: "Search",
    save: "Save",
    saveAssessment: "Save Assessment",
    saved: "Saved!",
    showLess: "Show less",
    showMore: "Show more",
    cancel: "Cancel",
    edit: "Edit",
    delete: "Delete",
    close: "Close",
    loading: "Loading...",
    submit: "Submit",
    active: "Active",
    back: "Back",
    spent: "Spent",
    used: "Used",
    onTrack: "On Track",
    viewDetails: "View Details",
    tasks: "Tasks",
    domains: "Domains",
    budget: "Budget",
    daysLeft: "days left",
    next: "Next",
    progress: "Progress",
    notifications: "Notifications",
    help: "Help",
    settings: "Settings",
    profile: "Profile",
    signOut: "Sign Out",
    dashboard: "Dashboard",
    export: "Export",
    import: "Import",
    share: "Share",
    days: "days",
    darkMode: "Dark Mode",
    lightMode: "Light Mode",
    confirm: "Confirm",
    remainingTokens: "عدد الرموز المتبقية"
  },
  
  // Header component
  header: {
    search: "Search...",
    myTeams: "My Teams",
    invitations: "Invitations",
    setupProfile: "Setup Profile",
    subscription: "Subscription",
    settings: "Settings",
    adminPanel: "Admin Panel",
    signOut: "Sign out",
    profile: "Profile",
  },
  
  // Dashboard page
  dashboard: {
    title: "Dashboard",
    subtitle: "Build and track your PMO across all essential domains",
    budget: "Budget",
    editDetails: "Edit Details",
    exportReport: "Export Report",
    access: "Access",
    timelineProgress: "Timeline Progress",
    budgetUtilization: "Budget Utilization",
    projectStatus: "Project Status",
    maturityAssessment: "Maturity Assessment",
    keyObjectives: "Key Objectives",
    stakeholders: "Stakeholders",
    overallProgress: "Overall Progress",
    completedTasks: "Completed Tasks",
    domainProcessComparison:"Domain Progress Comparison",
    organization: "Organization",
    industry: "Industry",
    dashboardCustomization: "Dashboard Customization",
    displayLayout: "Display Layout",
    gridView: "Grid View",
    listView: "List View",
    widgetSelection: "Widget Selection",
    assessMaturityLevel: "Assess Your Maturity Level",
    maturityLevel: "Maturity Level",
    progressOverview: "Progress Overview",
    tasksStatus: "Tasks Status",
    domains: "Domains",
    chartsAnalytics: "Charts & Analytics",
    pmoMaturityLevel: "PMO Maturity Level",
    pmoDomains: "PMO Domains",
    aiAnalysis: "Accelerate with AI",
    aiDescription: "Let our advanced AI analyze your PMO data and generate comprehensive recommendations tailored to your organization's unique needs.",
    tryAiAnalysis: "Try AI Analysis",
    viewAll: "View all",
    of: "of",
    tasksCompleted: "tasks completed",
    notSet: "Not set",
    updateProfile: "Update profile",
    viewAllTasks: "View all tasks",
    nextSteps: "Next Steps",
    uploadDocuments: "Upload documents",
    analysisDocuments: "Upload supporting documents for AI analysis",
    analysisDocumentsDesc: "Enhance AI recommendations with your organization's context",
    completePmoMaturityAssessment: "Complete a PMO Maturity Assessment",
    getInsightsAboutPmoMaturityLevel: "Get insights about your PMO's current maturity level",
    reviewPractices: "Review best practices",
    explorePractices: "Explore the best practices library for guidance",
    viewResources: "View resources",
    goToAssessment: "Go to assessment",
    objective1: "Establish PMO governance framework",
    objective2: "Develop standard methodologies",
    objective3: "Implement performance metrics",
    sampleProject: "Sample PMO Implementation",
    sampleDescription: "A sample project with pre-populated data for demonstration",
    createFirstProject: "Create Your First PMO Project",
    firstProjectDesc: "Get started by creating your first PMO implementation project. You can set up project details, track progress across domains, and generate AI-powered recommendations.",
    createSample: "Create Sample Project",
    aiFeature1: "Custom templates based on your current maturity level",
    aiFeature2: "Detailed implementation roadmaps for each domain",
    aiFeature3: "Best practices tailored to your industry and context",
    maturityRadarChart: "Maturity Radar Chart",
    higherValuesIndicateGreaterMaturity: "Higher values indicate greater maturity",
    pmoMaturityAssessment: "PMO Maturity Assessment",
    assessPmoMaturity: "Assess your PMO's maturity level across all domains to identify strengths and improvement opportunities",
    selfAssessment: "Self-Assessment",
    aiGeneratedAssessment: "AI-Generated Assessment",
    notSpecified: "Not specified",
    currentMaturityProfile: "Current Maturity Profile",
    organizationDetails: "Organization Details",
    assessmentType: "Assessment Type",
    currentMaturityProfileDescription: "Your organization's PMO is currently at the",
    currentMaturityProfileDescription2: "level. This assessment will help you identify areas for improvement and create a roadmap for advancing your PMO capabilities.",
    assessmentDate: "Assessment Date",
    selfAssessmentQuestionnaire: "Self-Assessment Questionnaire",
    selfAssessmentDescription: "Rate your PMO's maturity level for each domain. Consider your processes, documentation, measurement capabilities, and continuous improvement efforts when making your assessment.",
    documentation: "Documentation",
    metrics: "Metrics",
    minimalToNone: "Minimal to none",
    basicDocumentation: "Basic documentation",
    comprehensiveDocumentation: "Comprehensive",
    regularlyUpdated: "Regularly updated",
    leadingPractice: "Leading practice",
    adHocOrNone: "Ad-hoc or none",
    basicTracking: "Basic tracking",
    notes: "Notes (Optional)",
    notesPlaceholder: "Add any notes or context about your assessment...",
    createNew: "Create New Project",
    generateAIAssessment: "Generate an AI Assessment",
    aiAssessmentDescription: "Our AI will analyze your domain inputs, project data, and uploaded documents to provide an objective assessment of your PMO's maturity across all domains.",
    aiAssessmentSummary: "AI Assessment Summary",
    aiAssessmentSummaryDescription: "Based on our analysis, your PMO is currently at the",
    keyStrengths: "Key Strengths",
    areasForImprovement: "Areas for Improvement",
    domainSpecificAssessment: "Domain-Specific Assessment",
    maturityProgression: "Maturity Progression",
    recommendations: "Recommendations",
    generatingReport: "Generating Report...",
    exportAssessmentReport: "Export Assessment Report",
    detailedMaturityGuide: "Detailed Maturity Guide",
    maturityModelReference: "Maturity Model Reference",
    generateAssessment: "Generate Assessment",
    generatingAssessment: "Generating Assessment...",
    generatingAssessmentDescription: "Our AI is analyzing your PMO data across all domains. This may take a few moments.",
    
  },
  
  // Domain detail page
  domain: {
    BestPractices: "Best Practices",
    backToDashboard: "Back to Dashboard",
    prevDomain: "Previous Domain",
    nextDomain: "Next Domain",
    viewDomain: "View Domain",
    progress: "Progress",
    tasks: "Tasks & Progress",
    input: "Domain Input & Analysis",
    analyzing: "Analyzing Domain Input",
    processingData: "Our AI is processing your input data...",
    inputStage: "Input",
    inputDesc: "Collect data, assess current state, and gather requirements for this domain.",
    processingStage: "Processing",
    processingDesc: "Analyze data, develop frameworks, and design solutions for this domain.",
    outputStage: "Output",
    outputDesc: "Create deliverables, implement solutions, and establish frameworks for this domain.",
    loading: "Loading domain data...",
    notFound: "Domain not found",
    provideInputFirst: "Please provide domain input data before analyzing",
    aiGeneratedAnalysis: "AI-Generated Analysis for",
    generated: "Generated",
    analysis: "Analysis",
    domainProgress: "Domain Progress (%)",
    templates: "Templates",
    downloadMarkdown: "Download Markdown",
    downloadPdf: "Download PDF",
    generatingPdf: "Generating PDF...",
    generating: "Generating...",
    allTemplates: "All Available Templates",
    markdownFormat: "Markdown",
    words: "words",
    usingTemplates: "Using These Templates",
    templateDescription: "These templates are available in Markdown and PDF formats. Markdown can be imported into document editors, project management tools, or converted to other formats. PDF files are ready for printing or sharing with stakeholders.",
    noTemplates: "No templates available for this domain",
    aiConfigTitle: "AI Analysis Configuration",
    selectDomainPrompt: "Select a domain to analyze with our advanced AI. The analysis will generate comprehensive recommendations and templates based on your organization's specific context.",
    selectDomain: "Select Domain",
    analysisDepth: "Analysis Depth",
    basic: "Basic",
    quickOverview: "Quick overview",
    standard: "Standard",
    balancedAnalysis: "Balanced analysis",
    detailed: "Detailed",
    inDepthReview: "In-depth review",
    comprehensive: "Comprehensive",
    maximumDetail: "Maximum detail",
    geminiPowered: "Gemini AI Powered Analysis",
    advancedAiDesc: "Advanced AI will analyze your inputs and generate tailored recommendations",
    startAnalysis: "Start Analysis"
  },
  
  // Project management
  project: {
    projectName: "Project Name",
    projectNamePlaceholder: "Enterprise PMO Implementation",
    description: "Description",
    descriptionPlaceholder: "Brief description of your PMO implementation project",
    budget: "Budget",
    yourProjects: "Your Projects",
    createProject: "Create Project"
  },
  
  // Sidebar
  sidebar: {
    dashboard: "Dashboard",
    pmoDomains: "PMO Domains",
    tools: "Tools & Assessment",
    resources: "Resources",
    tasks: "Tasks",
    bestPractices: "Best Practices",
    maturityAssessment: "Maturity Assessment",
    assessment: "Assessment",
  },
  
  // Auth pages
  auth: {
    copyright: "© 2025 PMO Builder using AI by Dr. Ahmed Alsenosy"
  },
  
  // Maturity levels
  maturityLevels: {
    initial: {
      label: 'Initial',
      description: 'Processes are ad hoc and chaotic.'
    },
    defined: {
      label: 'Defined',
      description: 'Processes are documented and standardized.'
    },
    managed: {
      label: 'Managed',
      description: 'Processes are measured and controlled.'
    },
    optimized: {
      label: 'Optimized',
      description: 'Focus on continuous improvement.'
    },
    innovative: {
      label: 'Innovative',
      description: 'Driving industry innovation and adaptation.'
    }
  },

  //profile page
  profile: {
    title: "Organization Profile",
    description: "Set up your organization details to personalize your PMO journey",
    organizationName: "Organization Name",
    organizationNamePlaceholder: "Enter your organization name",
    industry: "Industry",
    industryPlaceholder: "Enter your industry",
    pmoMaturityLevel: "PMO Maturity Level",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "Select the maturity level that best describes your current PMO",
    saveProfile: "Save Profile",
    cancel: "Cancel",
    initial: "Initial - Ad hoc processes",
    defined: "Defined - Basic processes established",
    managed: "Managed - Standardized processes",
    optimized: "Optimized - Continuously improving",
    notEstablished: "Not Established - No formal PMO",
  },
  
  //settings page
  settings: {
    title: "Settings",
    description: "Manage your account settings and preferences",
    personal: "Personal",
    subscription: "Subscription",
    notifications: "Notifications",
    security: "Security",
    data: "Data",
    saveProfile: "Save Profile",
    cancel: "Cancel",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "Select the maturity level that best describes your current PMO",
    organizationName: "Organization Name",
    organizationNamePlaceholder: "Enter your organization name",
    industry: "Industry",
    industryPlaceholder: "Enter your industry",
    pmoMaturityLevel: "PMO Maturity Level",
    notEstablished: "Not Established - No formal PMO",
    initial: "Initial - Ad hoc processes",
    defined: "Defined - Basic processes established",
    managed: "Managed - Standardized processes",
    optimized: "Optimized - Continuously improving",
  },

  // Resources page
  resources: {
    title: "Resources",
    noDocuments: "No documents available",
    errorLoading: "Error loading documents",
    downloadError: "Error downloading document",
    uploadNew: "Upload New Document",
    filter: "Filter Documents",
    sortBy: "Sort By",
    search: "Search Documents",
    lastModified: "Last Modified",
    fileName: "File Name",
    fileSize: "File Size",
    taskName: "Task Name",
    projectId: "Project ID"
  },
 // Help page
  help: {
    title: "Help & Support",
    description: "Learn how to use the PMO Domains Application Tool effectively",
    gettingStarted: "Getting Started",
    whatIsPmoDomainsTool: "What is the PMO Domains Tool?",
    whatIsPmoDomainsToolDescription: `The PMO Domains Application Tool helps PMO professionals apply and monitor the five key PMO domains using a structured "Inputs – Processing – Outputs" framework. The tool guides you through each domain's tasks, ensuring best practices and benchmarking against industry standards.`, 
    howToUseThisTool: "How to Use This Tool",
    howToUseThisToolDescription: "The PMO Domains Application Tool is a web-based application that helps organizations implement and improve their PMO capabilities across all domains.",
    canIExportMyData: "Can I export my data?",
    canIExportMyDataDescription: "Yes, you can export your data from the Settings page. This allows you to back up your progress or transfer it to another system.",
    canICustomizeTheToolForMyOrganization: "Can I customize the tool for my organization?",
    canICustomizeTheToolForMyOrganizationDescription: "The tool is designed to be applicable across different organizations and industries. You can add custom notes to each task to tailor it to your specific organizational context.",
    whatIfINotReadyToCompleteAllDomains: "What if I'm not ready to complete all domains?",
    whatIfINotReadyToCompleteAllDomainsDescription: "You can work on domains in any order that makes sense for your organization. The tool will track your progress across all domains, allowing you to focus on your priorities.",
    contactSupport: "Contact Support",
    contactSupportDescription: "If you need additional help or have questions about the PMO Domains Application Tool, please contact our support team.",
    supportContact: "Support Contact",
    supportContactEmail: "Email: support@pmobuilder.ai",
    supportContactPhone: "Phone: (555) 123-4567",
    supportContactHours: "Hours: Monday-Friday, 9am-5pm EST",
    startBySettingUpYourOrganizationProfile: "Start by setting up your organization profile in the Profile section",
    navigateToEachDomainUsingTheSidebarMenu: "Navigate to each domain using the sidebar menu",
    completeTasksInTheRecommendedOrder: "Complete tasks in the recommended order: Input → Processing → Output",
    markTasksAsCompleteAsYouProgress: "Mark tasks as complete as you progress",
    useTheDashboardToTrackYourOverallProgress: "Use the dashboard to track your overall progress",
    referToTheBestPracticesLibraryForGuidance: "Refer to the Best Practices Library for guidance",
    organizationalDevelopmentAndAlignment: "1. Organizational Development and Alignment",
    organizationalDevelopmentAndAlignmentDescription: "This domain focuses on aligning the PMO with organizational strategy and culture to ensure effective project management practices. It includes organizational assessment, stakeholder analysis, and developing alignment strategies.",
    strategicElementsOfThePmo: "2. Strategic Elements of the PMO",
    strategicElementsOfThePmoDescription: "This domain involves developing and implementing strategic frameworks, roadmaps, and governance structures. It includes strategic objectives review, portfolio analysis, and governance structure design.",
    pMODesignAndStructuring: "3. PMO Design and Structuring",
    pMODesignAndStructuringDescription: "This domain focuses on creating the optimal PMO structure, roles, and responsibilities to meet organizational needs. It includes requirements gathering, resource assessment, and service catalog development.",
    pMOOperationAndPerformance: "4. PMO Operation and Performance",
    pMOOperationAndPerformanceDescription: "This domain establishes operational processes, KPIs, and performance metrics for the PMO. It includes process assessment, performance metrics identification, and performance measurement systems.",
    pMOEnhancementAndEffectiveness: "5. PMO Enhancement and Effectiveness",
    pMOEnhancementAndEffectivenessDescription: "This domain focuses on continuously improving PMO services, capabilities, and value delivery. It includes maturity assessment, value delivery analysis, and continuous improvement planning.",
    frequentlyAskedQuestions: "Frequently Asked Questions",
    frequentlyAskedQuestionsDescription: "The PMO Domains Application Tool is a web-based application that helps organizations implement and improve their PMO capabilities across all domains.",
    howToAccessTemplates: "How do I access templates?",
    howToAccessTemplatesDescription: "Templates are available within specific tasks that have template resources. You can also find a collection of templates in the Best Practices Library",
    understandingTheFiveDomains: "Understanding the Five Domains",
  },
    
  subscription: {
    title: "Subscription Management",
    currentPlan: "Current Plan",
    trial: "Trial",
    cancelsAtPeriodEnd: "Cancels at period end",
    upgradePlan: "Upgrade Plan",
    manageSubscription: "Manage Subscription",
    processing: "Processing...",
    billingPeriod: "Billing Period",
    nextBillingDate: "Next Billing Date",
    paymentMethod: "Payment Method",
    projects: "Projects",
    aiAnalysis: "AI Analysis",
    storage: "Storage",
    freePlanLimitations: "Free plan limitations",
    freePlanLimitationsDescription: "You're currently on the Free plan, which has limitations on projects, AI analyses, and storage. Upgrade to Premium or Enterprise for increased limits and additional features.",
    upgradeNow: "Upgrade Now",
    upgradeToGetMore: "Upgrade to Get More",
    premiumPlanBenefits: "Premium Plan Benefits",
    upTo20Projects: "Up to 20 projects (vs. 3 on Free)",
    upTo100AiAnalyses: "100 AI analyses per month (vs. 3 on Free)",
    teamCollaboration: "Team collaboration with up to 5 users",
    prioritySupport: "Priority support",
    enterprisePlanBenefits: "Enterprise Plan Benefits",
    unlimitedProjectsAndAiAnalyses: "Unlimited projects and AI analyses",
    unlimitedTeamMembers: "Unlimited team members",
    whiteLabelingOptions: "White-labeling options",
    dedicatedSupport: "Dedicated support",
    upgradeToEnterprise: "Upgrade to Enterprise",
    unlimited: "Unlimited",
    unknown: "Unknown",
    free: "Free",
    premium: "Premium",
    enterprise: "Enterprise",
    usageAndLimits: "Usage & Limits",
    perMonth: "per month",
    mb: "MB",
    none: "None",
    creditCard: "Credit Card",
    paypal: "PayPal",
    notAvailable: "Not available",
  },
  
  //notifications
  notifications: {
    '1': {
      title: "PMO Maturity Assessment Due",
      description: "Complete your quarterly PMO maturity assessment by Friday.",
      time: "2 days ago",
    },
    '2': {
      title: "Strategic Elements Domain Updated",
      description: "New templates and resources have been added to the Strategic Elements domain.",
      time: "3 days ago",
    },
    '3': {
      title: "Team Meeting: PMO Enhancement",
      description: "Upcoming team meeting to discuss PMO Enhancement strategies.",
      time: "Tomorrow, 10:00 AM",
    },
    '4': {
      title: "New Message from Admin",
      description: "You have a new message regarding your Organization Development domain progress.",
      time: "1 week ago",
    },
    '5': {
      title: "Data Backup Complete",
      description: "Your PMO data has been successfully backed up to cloud storage.",
      time: "2 weeks ago",
    },
    title: "Notifications",
    description: "Stay updated with your PMO activities and important alerts",
    markAllAsRead: "Mark all as read",
    clearAll: "Clear all",
    markAllAsReadDescription: "Mark all notifications as read",
    clearAllDescription: "Clear all notifications",
    markAllAsReadButton: "Mark all as read",
    clearAllButton: "Clear all",
    unread: "Unread",
    all: "All",
    recentNotifications: "Recent Notifications",
    markAsUnread: "Mark as unread",
    markAsRead: "Mark as read",
    viewDetails: "View details",
    loadMore: "Load more notifications",
    customizeNotifications: "Customize how and when you receive notifications about your PMO activities",
    notificationPreferences: "Notification Preferences",
    managePreferences: "Manage Preferences",
    

  },
  // Domain names
  domains: {
    "1": {
      name: "Organizational Development and Alignment",
      description: "Aligning the PMO with organizational strategy and culture to ensure effective project management practices.",
      tasks: {
        "1-input-1": {
          stage: "input",
          title: "Assess Current Competencies",
          description: "Gather data on existing competencies through surveys, interviews, and documentation review.",
          bestPractices: [
            "Use standardized assessment tools to evaluate current competencies",
            "Collect input from multiple organizational levels",
            "Document both technical and soft skill competencies",
            "Identify competency gaps through structured assessment"
          ]
        },
        "1-input-2": {
          stage: "input",
          title: "Assess Organizational Culture",
          description: "Collect data on current organizational culture through surveys, focus groups, and stakeholder interviews.",
          bestPractices: [
            "Conduct culture assessment surveys",
            "Gather feedback from diverse organizational levels",
            "Document cultural enablers and barriers to project management",
            "Collect historical data on cultural change initiatives"
          ]
        },
        "1-input-3": {
          stage: "input",
          title: "Benchmark Against Industry Standards",
          description: "Collect industry benchmarking data and best practices for organizational alignment.",
          bestPractices: [
            "Select relevant industry benchmarks and standards",
            "Gather data from industry reports and publications",
            "Document peer organization practices",
            "Collect metrics for comparative analysis"
          ]
        },
        "1-processing-1": {
          stage: "processing",
          title: "Apply Strategic Analysis Techniques",
          description: "Use strategic analysis tools to develop an integrated strategy with risk management and implementation roadmap.",
          bestPractices: [
            "Apply SWOT analysis to identify strengths and weaknesses",
            "Use gap analysis to identify improvement areas",
            "Apply risk assessment methodologies",
            "Use roadmapping techniques for implementation planning"
          ]
        },
        "1-processing-2": {
          stage: "processing",
          title: "Apply Communication Planning Methodologies",
          description: "Use communication planning techniques to develop stakeholder-specific messaging and feedback mechanisms.",
          bestPractices: [
            "Apply stakeholder analysis techniques",
            "Use communication matrix development methods",
            "Apply message tailoring methodologies",
            "Use KPI development frameworks for communication effectiveness"
          ]
        },
        "1-processing-3": {
          stage: "processing",
          title: "Apply Charter Development Techniques",
          description: "Use charter development methodologies to define PMO scope, authority, and governance structure.",
          bestPractices: [
            "Apply scope definition techniques",
            "Use RACI matrix development methods",
            "Apply governance framework design methodologies",
            "Use authority mapping techniques"
          ],
          templates: ["PMO Charter Template", "RACI Matrix"]
        },
        "1-output-1": {
          stage: "output",
          title: "Deliver Integrated Strategy and Roadmap",
          description: "Produce and implement the integrated strategy with risk management plan and phased implementation roadmap.",
          bestPractices: [
            "Document comprehensive strategy with clear objectives",
            "Create detailed implementation roadmap with milestones",
            "Develop risk management plan with mitigation strategies",
            "Establish strategy review and update mechanisms"
          ]
        },
        "1-output-2": {
          stage: "output",
          title: "Establish PMO Vision, Values and Culture",
          description: "Implement vision statement, core values, and cultural change program with leadership engagement.",
          bestPractices: [
            "Create compelling vision statement aligned with organization",
            "Document core values with behavioral examples",
            "Implement leadership engagement activities",
            "Establish cultural reinforcement mechanisms"
          ],
          templates: ["PMO Vision Statement Template", "Cultural Change Roadmap"]
        },
        "1-output-3": {
          stage: "output",
          title: "Implement PMO Charter and Governance",
          description: "Establish and operationalize PMO charter with defined scope, authority, and governance structure.",
          bestPractices: [
            "Formalize PMO charter with executive approval",
            "Implement governance structure with clear roles",
            "Establish decision-making authorities and processes",
            "Create charter review and update mechanisms"
          ],
          templates: ["PMO Charter Document", "Governance Structure Diagram"]
        },
      },
    },
    "2": {
      name: "Strategic Framework & Governance",
      description: "Creating the optimal PMO structure, roles, and responsibilities to meet organizational needs.",
      tasks: {
        "2-input-1": {
          stage: "input",
          title: "Gather Current State Data",
          description: "Collect data on current project management operations, processes, and performance.",
          bestPractices: [
            "Conduct process documentation review",
            "Gather performance metrics and historical data",
            "Collect stakeholder feedback on current operations",
            "Document existing governance structures"
          ]
        },
        "2-input-2": {
          stage: "input",
          title: "Collect Strategic Alignment Information",
          description: "Gather organizational strategic objectives, priorities, and success criteria.",
          bestPractices: [
            "Review organizational strategic plans",
            "Collect executive leadership priorities",
            "Document business unit objectives",
            "Gather information on strategic initiatives"
          ]
        },
        "2-input-3": {
          stage: "input",
          title: "Identify Capability Requirements",
          description: "Collect data on required capabilities through stakeholder interviews and organizational needs assessment.",
          bestPractices: [
            "Conduct capability needs interviews",
            "Gather industry capability standards",
            "Document capability prioritization criteria",
            "Collect capability maturity benchmarks"
          ]
        },
        "2-processing-1": {
          stage: "processing",
          title: "Apply Mandate Development Methodology",
          description: "Use mandate development techniques to define PMO purpose, authority, and responsibilities.",
          bestPractices: [
            "Apply purpose statement development methods",
            "Use authority mapping techniques",
            "Apply responsibility definition methodologies",
            "Use stakeholder validation approaches"
          ],
          templates: ["PMO Mandate Template", "Executive Sponsorship Agreement"]
        },
        "2-processing-2": {
          stage: "processing",
          title: "Apply Charter Development Framework",
          description: "Use charter development framework to create comprehensive PMO charter with roles and governance structure.",
          bestPractices: [
            "Apply vision and mission statement techniques",
            "Use organizational structure design methods",
            "Apply role definition methodologies",
            "Use governance framework design techniques"
          ],
          templates: ["PMO Charter Template", "Governance Structure Diagram"]
        },
        "2-processing-3": {
          stage: "processing",
          title: "Apply Governance Design Methodology",
          description: "Use governance design techniques to develop decision-making processes and oversight mechanisms.",
          bestPractices: [
            "Apply decision rights mapping techniques",
            "Use escalation path design methods",
            "Apply governance body design methodologies",
            "Use governance communication planning techniques"
          ],
          templates: ["Governance Framework Template", "Decision Rights Matrix"]
        },
        "2-output-1": {
          stage: "output",
          title: "Establish PMO Mandate and Charter",
          description: "Formalize and implement PMO mandate and charter with defined purpose, authority, and responsibilities.",
          bestPractices: [
            "Obtain executive approval for mandate and charter",
            "Communicate mandate to all stakeholders",
            "Implement authority structures defined in charter",
            "Establish charter review and update process"
          ],
          templates: ["Approved PMO Mandate", "Finalized PMO Charter"]
        },
        "2-output-2": {
          stage: "output",
          title: "Implement Governance Framework",
          description: "Establish and operationalize governance framework with decision-making bodies, processes, and oversight mechanisms.",
          bestPractices: [
            "Form governance committees with clear charters",
            "Implement decision-making processes and authorities",
            "Establish governance meeting cadence and agendas",
            "Create governance documentation and reporting system"
          ],
          templates: ["Governance Committee Charter", "Decision Authority Matrix"]
        },
        "2-output-3": {
          stage: "output",
          title: "Develop Strategic Communication Plan",
          description: "Implement comprehensive communication strategy with stakeholder-specific messaging and feedback mechanisms.",
          bestPractices: [
            "Create stakeholder-specific communication materials",
            "Establish regular communication cadence",
            "Implement feedback collection mechanisms",
            "Develop communication effectiveness metrics"
          ],
          templates: ["Strategic Communication Plan", "Stakeholder Messaging Matrix"]
        },      
      }
    },
    "3": {
      name: "PMO Structure & Design",
      description: "Establishing operational processes, KPIs, and performance metrics for the PMO.",
      tasks: {
        "3-input-1": {
          stage: "input",
          title: "Gather Customer Data",
          description: "Collect data on potential PMO customers, their needs, and expectations through surveys and interviews.",
          bestPractices: [
            "Conduct customer needs assessment surveys",
            "Gather stakeholder interview data",
            "Document customer pain points and expectations",
            "Collect service prioritization information"
          ]
        },
        "3-input-2": {
          stage: "input",
          title: "Collect Service Requirement Data",
          description: "Gather detailed requirements for potential PMO services through workshops and requirements sessions.",
          bestPractices: [
            "Conduct service requirements workshops",
            "Document service level expectations",
            "Collect service prioritization criteria",
            "Gather benchmark data on similar services"
          ],
          templates: ["Service Requirements Template", "Customer Needs Assessment"]
        },
        "3-input-3": {
          stage: "input",
          title: "Assess Capability Gaps",
          description: "Collect data on current capabilities and gaps through assessment tools and stakeholder feedback.",
          bestPractices: [
            "Use capability maturity assessment tools",
            "Gather capability benchmark data",
            "Document capability prioritization criteria",
            "Collect resource availability information"
          ]
        },
        "3-processing-1": {
          stage: "processing",
          title: "Apply Persona Development Techniques",
          description: "Use persona development methodologies to create detailed customer personas with needs and expectations.",
          bestPractices: [
            "Apply customer segmentation techniques",
            "Use persona development frameworks",
            "Apply needs analysis methodologies",
            "Use journey mapping techniques"
          ]
        },
        "3-processing-2": {
          stage: "processing",
          title: "Apply Prioritization Frameworks",
          description: "Use prioritization techniques to develop framework for addressing customer needs systematically.",
          bestPractices: [
            "Apply value vs. effort prioritization matrix",
            "Use MoSCoW prioritization technique",
            "Apply weighted scoring methodologies",
            "Use impact mapping techniques"
          ]
        },
        "3-processing-3": {
          stage: "processing",
          title: "Apply Service Catalog Design Methodology",
          description: "Use service catalog design techniques to develop comprehensive service offerings with benefits and advantages.",
          bestPractices: [
            "Apply service definition frameworks",
            "Use service level definition techniques",
            "Apply value proposition development methodologies",
            "Use service categorization techniques"
          ],
          templates: ["Service Catalog Template", "Service Level Agreement Template"]
        },
        "3-output-1": {
          stage: "output",
          title: "Deliver Customer Personas and Journey Maps",
          description: "Create and distribute detailed customer personas and journey maps to guide service design and delivery.",
          bestPractices: [
            "Document comprehensive personas with needs and pain points",
            "Create visual journey maps for key customer interactions",
            "Distribute personas to all service delivery teams",
            "Establish persona update and refinement process"
          ],
          templates: ["Customer Persona Template", "Journey Map Template"]
        },
        "3-output-2": {
          stage: "output",
          title: "Implement Service Catalog and SLAs",
          description: "Launch comprehensive service catalog with service level agreements, processes, and quality standards.",
          bestPractices: [
            "Create detailed service descriptions with value propositions",
            "Establish service level metrics and targets",
            "Implement service request and delivery processes",
            "Create service catalog review and update mechanism"
          ],
          templates: ["Service Catalog Document", "SLA Documentation"]
        },
        "3-output-3": {
          stage: "output",
          title: "Establish Service Prioritization Framework",
          description: "Implement systematic approach for prioritizing and addressing customer needs and service requests.",
          bestPractices: [
            "Create prioritization criteria and scoring system",
            "Implement request intake and evaluation process",
            "Establish resource allocation based on priorities",
            "Develop priority review and adjustment mechanisms"
          ],
          templates: ["Prioritization Matrix", "Service Request Form"]
        },      
      }
    },
    "4": {
      name: "Operational Excellence",
      description: "Ensuring efficient and effective project management processes and tools.",
      tasks: {
        "4-input-1": {
          stage: "input",
          title: "Gather Onboarding Requirements",
          description: "Collect requirements and expectations for customer onboarding process through stakeholder input.",
          bestPractices: [
            "Conduct onboarding needs assessment",
            "Gather stakeholder expectations for onboarding",
            "Document current onboarding challenges",
            "Collect onboarding best practices"
          ]
        },
        "4-input-2": {
          stage: "input",
          title: "Collect Documentation Requirements",
          description: "Gather requirements for process documentation, user guides, and training materials.",
          bestPractices: [
            "Conduct documentation needs assessment",
            "Gather user preferences for documentation formats",
            "Document current documentation gaps",
            "Collect documentation best practices"
          ],
          templates: ["Documentation Requirements Template", "User Guide Outline"]
        },
        "4-input-3": {
          stage: "input",
          title: "Assess Training Needs",
          description: "Collect data on training needs, preferences, and delivery methods through surveys and interviews.",
          bestPractices: [
            "Conduct training needs assessment",
            "Gather learning style preferences",
            "Document knowledge and skill gaps",
            "Collect training effectiveness criteria"
          ]
        },
        "4-processing-1": {
          stage: "processing",
          title: "Apply Quality Management Techniques",
          description: "Use quality management methodologies to develop quality control measures and improvement processes.",
          bestPractices: [
            "Apply quality standards development techniques",
            "Use quality control checkpoint design methods",
            "Apply quality metrics development frameworks",
            "Use continuous improvement methodologies"
          ]
        },
        "4-processing-2": {
          stage: "processing",
          title: "Apply Resource Management Methodologies",
          description: "Use resource management techniques to develop allocation systems and capacity planning processes.",
          bestPractices: [
            "Apply resource capacity planning techniques",
            "Use resource allocation prioritization methods",
            "Apply resource forecasting methodologies",
            "Use resource utilization optimization techniques"
          ],
          templates: ["Resource Management Plan", "Capacity Planning Template"]
        },
        "4-processing-3": {
          stage: "processing",
          title: "Apply Issue Management Framework",
          description: "Use issue management methodologies to develop escalation procedures and resolution processes.",
          bestPractices: [
            "Apply escalation threshold definition techniques",
            "Use escalation path design methods",
            "Apply issue categorization frameworks",
            "Use resolution time standard development techniques"
          ],
          templates: ["Escalation Procedure Template", "Issue Management Framework"]
        },
        "4-output-1": {
          stage: "output",
          title: "Implement Quality Management System",
          description: "Establish comprehensive quality management system with standards, control processes, and improvement mechanisms.",
          bestPractices: [
            "Document quality standards for all services",
            "Implement quality control checkpoints and reviews",
            "Establish quality metrics collection and reporting",
            "Create continuous quality improvement process"
          ],
          templates: ["Quality Standards Document", "Quality Review Checklist"]
        },
        "4-output-2": {
          stage: "output",
          title: "Establish Resource Management System",
          description: "Implement resource management system with capacity planning, allocation processes, and utilization tracking.",
          bestPractices: [
            "Create resource inventory and skills matrix",
            "Implement capacity planning and forecasting process",
            "Establish resource allocation and assignment procedures",
            "Develop resource utilization tracking and reporting"
          ],
          templates: ["Resource Allocation Matrix", "Capacity Planning Dashboard"]
        },
        "4-output-3": {
          stage: "output",
          title: "Deploy Issue Management System",
          description: "Implement comprehensive issue management system with escalation procedures, tracking, and resolution processes.",
          bestPractices: [
            "Establish issue intake and categorization process",
            "Implement escalation paths and notification system",
            "Create issue tracking and status reporting",
            "Develop resolution verification and closure procedures"
          ],
          templates: ["Issue Management Playbook", "Escalation Matrix"]
        },      
      }
    },
    "5": {
      name: "Performance & Improvement",
      description: "Continuously improving PMO services, capabilities, and value delivery.",
      tasks: {
        "5-input-1": {
          stage: "input",
          title: "Gather Maturity Assessment Data",
          description: "Collect data on current PMO maturity through assessment tools, surveys, and stakeholder feedback.",
          bestPractices: [
            "Select appropriate maturity assessment tool",
            "Gather comprehensive assessment data",
            "Document maturity baseline across dimensions",
            "Collect maturity target information"
          ]
        },
        "5-input-2": {
          stage: "input",
          title: "Collect Performance Data",
          description: "Gather current performance metrics, historical trends, and performance targets.",
          bestPractices: [
            "Collect current performance metrics",
            "Gather historical performance data",
            "Document performance targets and thresholds",
            "Collect performance benchmark information"
          ]
        },
        "5-input-3": {
          stage: "input",
          title: "Assess Value Measurement Approaches",
          description: "Collect data on potential value metrics, measurement approaches, and value demonstration methods.",
          bestPractices: [
            "Gather value metric options",
            "Collect value measurement methodologies",
            "Document value perception from stakeholders",
            "Assess current value demonstration approaches"
          ]
        },
        "5-processing-1": {
          stage: "processing",
          title: "Apply Maturity Roadmapping Techniques",
          description: "Use maturity roadmapping methodologies to develop enhancement plan with milestones and metrics.",
          bestPractices: [
            "Apply maturity gap analysis techniques",
            "Use capability prioritization methods",
            "Apply milestone development frameworks",
            "Use metric definition techniques"
          ]
        },
        "5-processing-2": {
          stage: "processing",
          title: "Apply Change Management Methodologies",
          description: "Use change management techniques to develop implementation approach for maturity initiatives.",
          bestPractices: [
            "Apply stakeholder impact analysis techniques",
            "Use resistance management methods",
            "Apply communication planning frameworks",
            "Use adoption measurement techniques"
          ],
          templates: ["Change Management Plan", "Stakeholder Engagement Plan"]
        },
        "5-processing-3": {
          stage: "processing",
          title: "Apply Continuous Improvement Frameworks",
          description: "Use continuous improvement methodologies to develop systematic improvement processes.",
          bestPractices: [
            "Apply improvement opportunity identification techniques",
            "Use improvement prioritization methods",
            "Apply implementation planning frameworks",
            "Use effectiveness measurement techniques"
          ]
        },
        "5-output-1": {
          stage: "output",
          title: "Implement Maturity Enhancement Roadmap",
          description: "Establish and execute comprehensive maturity enhancement roadmap with milestones, metrics, and review processes.",
          bestPractices: [
            "Document detailed maturity enhancement plan",
            "Implement milestone tracking and reporting",
            "Establish maturity metric collection and analysis",
            "Create regular maturity review and adjustment process"
          ],
          templates: ["Maturity Enhancement Roadmap", "Maturity Metrics Dashboard"]
        },
        "5-output-2": {
          stage: "output",
          title: "Establish Value Measurement System",
          description: "Implement comprehensive value measurement system with metrics, reporting, and demonstration mechanisms.",
          bestPractices: [
            "Define and implement value metrics and KPIs",
            "Create value data collection and analysis process",
            "Establish value reporting and visualization",
            "Develop value demonstration case studies"
          ],
          templates: ["Value Measurement Framework", "Value Dashboard"]
        },
        "5-output-3": {
          stage: "output",
          title: "Deploy Continuous Improvement Program",
          description: "Implement systematic continuous improvement program with identification, prioritization, and implementation processes.",
          bestPractices: [
            "Establish improvement opportunity identification process",
            "Create improvement prioritization and selection system",
            "Implement improvement tracking and reporting",
            "Develop improvement effectiveness measurement"
          ],
          templates: ["Continuous Improvement Playbook", "Improvement Tracking System"]
        },      
      }
    },
    "6": {
      name: "Capability Development",
      description: "Developing and managing the human aspects of the PMO including competency, training, and leadership.",
      tasks: {
        "6-input-1": {
          stage: "input",
          title: "Gather Decision-Making Data",
          description: "Collect data on current decision-making processes, data utilization, and improvement opportunities.",
          bestPractices: [
            "Document current decision-making processes",
            "Assess data utilization in decisions",
            "Identify decision-making bottlenecks",
            "Gather decision quality metrics"
          ]
        },
        "6-input-2": {
          stage: "input",
          title: "Assess Competency Requirements",
          description: "Collect data on required competencies, current capabilities, and development needs.",
          bestPractices: [
            "Document role-specific competency requirements",
            "Assess current competency levels",
            "Identify critical competency gaps",
            "Gather development preference information"
          ],
          templates: ["Competency Assessment Template", "Development Needs Analysis"]
        },
        "6-input-3": {
          stage: "input",
          title: "Collect Skills Assessment Data",
          description: "Gather comprehensive skills data through assessments, self-evaluations, and manager feedback.",
          bestPractices: [
            "Use standardized skills assessment tools",
            "Gather self-assessment data",
            "Collect manager assessment input",
            "Document skills prioritization criteria"
          ]
        },
        "6-processing-1": {
          stage: "processing",
          title: "Apply Training Program Design Methodology",
          description: "Use training design techniques to develop comprehensive training and certification programs.",
          bestPractices: [
            "Apply learning objective development techniques",
            "Use curriculum design methodologies",
            "Apply learning modality selection frameworks",
            "Use training effectiveness measurement design"
          ]
        },
        "6-processing-2": {
          stage: "processing",
          title: "Apply Innovation Framework Development",
          description: "Use innovation framework techniques to develop processes for fostering innovation and problem-solving.",
          bestPractices: [
            "Apply innovation process design methodologies",
            "Use idea generation technique selection",
            "Apply idea evaluation framework development",
            "Use innovation incentive system design"
          ]
        },
        "6-processing-3": {
          stage: "processing",
          title: "Apply Knowledge Management Techniques",
          description: "Use knowledge management methodologies to design knowledge-sharing platform and communities of practice.",
          bestPractices: [
            "Apply knowledge repository design techniques",
            "Use knowledge categorization frameworks",
            "Apply community of practice design methodologies",
            "Use knowledge contribution incentive design"
          ]
        },
        "6-output-1": {
          stage: "output",
          title: "Implement Competency Development Framework",
          description: "Establish comprehensive competency framework with assessment, development paths, and certification programs.",
          bestPractices: [
            "Document role-specific competency requirements",
            "Create competency assessment and tracking system",
            "Implement development paths for each competency area",
            "Establish certification and recognition program"
          ],
          templates: ["Competency Framework Document", "Development Path Guide"]
        },
        "6-output-2": {
          stage: "output",
          title: "Deploy Innovation and Problem-Solving System",
          description: "Implement structured innovation program with idea generation, evaluation, and implementation processes.",
          bestPractices: [
            "Establish idea generation and collection system",
            "Create idea evaluation and selection process",
            "Implement innovation implementation support",
            "Develop innovation recognition and incentives"
          ],
          templates: ["Innovation Process Playbook", "Idea Evaluation Matrix"]
        },
        "6-output-3": {
          stage: "output",
          title: "Establish Knowledge Management System",
          description: "Implement comprehensive knowledge management system with repository, sharing mechanisms, and communities of practice.",
          bestPractices: [
            "Create knowledge repository with categorization system",
            "Establish knowledge contribution processes",
            "Form communities of practice with clear charters",
            "Implement knowledge sharing events and activities"
          ],
          templates: ["Knowledge Management Guide", "Community of Practice Charter"]
        }
      }
    }
  },

  // Tasks
  tasks: {
    tasks: "Tasks",
    manageAndTrackYourPmoImplementationTasks: "Manage and track your PMO implementation tasks",
    allTasks: "All Tasks",
    completed: "Completed",
    incomplete: "Incomplete",
    progress: "Progress",
    total: "Total",
    rate: "Rate",
    addCustomTask: "Add Custom Task",
    searchTasks: "Search tasks...",
    filters: "Filters",
    clear: "Clear",
    allDomains: "All Domains",
    allStages: "All Stages",
    input: "Input",
    processing: "Processing",
    output: "Output",
    domain: "Domain",
    stage: "Stage",
    status: "Status",
    clearFilters: "Clear Filters",
    noTasksFound: "No tasks found",
    noTasksMatchFilters: "No tasks match your current filters. Try adjusting or clearing your filters.",
    noTasksAvailable: "No tasks available. Start by creating a new task.",
    taskManagementTips: "Task Management Tips",
    taskManagementTipsDescription: "Prioritize tasks based on your PMO maturity level and organizational goals. Complete the Input stage tasks first before moving to Processing and Output stages for the best results.",
    viewBestPractices: "View Best Practices",
    relatedDocuments: "Related Documents",
    viewFullContent: "View Full Content",
    generateTaskOutput: "Generate Task Output",
    templates: "Templates",
    templateForStandardizedImplementation: "Template for standardized implementation",
    viewTemplate: "View Template",
    bestPractices: "Best Practices",
    priority: "Priority",
    targetCompletionDate: "Target Completion Date",
    assignedTo: "Assigned To",
    estimatedHours: "Estimated Hours",
    attachments: "Attachments",
    notes: "Notes",
    availableTemplates: "Available Templates",
    purpose: "Purpose",
    templateForStandardized: "This template provides a structured framework for implementing and managing",
    withinYourPMO: "processes within your PMO",
    overview: "Overview",
    download: "Download",
    useTemplate: "Use Template",
    close: "Close",
    save:"Save",
    template: `
## Template Sections

### 1. Introduction
- Purpose and objectives
- Scope and applicability
- Key stakeholders

### 2. Process Framework
- Methodology overview
- Key activities and deliverables
- Roles and responsibilities

### 3. Implementation Guide
- Step-by-step instructions
- Best practices and guidelines
- Common challenges and solutions

### 4. Monitoring and Control
- Key performance indicators
- Quality assurance measures
- Reporting requirements

### 5. Continuous Improvement
- Feedback mechanisms
- Review process
- Update procedures

## Appendices
- Related templates and tools
- Reference materials
- Glossary of terms

---

*This template is part of the PMO Builder library. Customize it to fit your organization's specific needs.*`,
  }
};

// Arabic translations
const ar = {
  // Header component
  // Common components
  common: {
    pleaseWait: "يرجى الإنتظار حتى نكتمل إعداد محتواك.",
    Complete : "مكتمل",
    search: "بحث",
    save: "حفظ",
    saveAssessment: "حفظ التقييم",
    saved: "تم الحفظ",
    cancel: "إلغاء",
    showLess: "إخفاء",
    showMore: "إظهار المزيد",
    spent: "منفق",
    active: "فعال",
    used: "مستخدم",
    onTrack: "متبع",
    viewDetails: "عرض التفاصيل",
    tasks: "المهام",
    domains: "المجالات",
    budget: "الميزانية",
    daysLeft: "أيام متبقية",
    edit: "تعديل",
    delete: "حذف",
    close: "إغلاق",
    loading: "جاري التحميل...",
    submit: "إرسال",
    back: "رجوع",
    next: "التالي",
    progress: "التقدم",
    notifications: "الإشعارات",
    help: "المساعدة",
    settings: "الإعدادات",
    profile: "الملف الشخصي",
    signOut: "تسجيل الخروج",
    dashboard: "لوحة القيادة",
    export: "تصدير",
    import: "استيراد",
    share: "مشاركة",
    days: "يوم",
    darkMode: "الوضع الداكن",
    lightMode: "الوضع الفاتح",
    confirm: "تأكيد",
    free: "مجاني",
    upgrade: "الترقية",
    outputAccepted: "تم قبول الناتج",
    templates: "القوالب",
    loadingDocuments: "جاري تحميل المستندات",
    user: "المستخدم",
    filterByProject: "تصفية حسب المشروع",
    allProjects: "جميع المشاريع",
    filterBySource: "تصفية حسب المصدر",
    allSources: "جميع المصادر",
    searchDocuments: "بحث في المستندات",
    remainingTokens: "عدد الرموز المتبقية"
  },
  
  // Header component
  header: {
    search: "بحث...",
    myTeams: "فرقي",
    invitations: "الدعوات",
    setupProfile: "إعداد الملف الشخصي",
    subscription: "الاشتراك",
    remainingTokens: "عدد الرموز المتبقية",
    settings: "الإعدادات",
    adminPanel: "لوحة الإدارة",
    signOut: "تسجيل الخروج",
    profile: "الملف الشخصي",  
  },
  
  // Dashboard page
  dashboard: {
    title: "لوحة القيادة",
    subtitle: "بناء وتتبع مكتب إدارة المشاريع عبر جميع المجالات الأساسية",
    budget: "الميزانية",
    timelineProgress: "التقدم في الخط الزمني",
    budgetUtilization: "استخدام الميزانية",
    projectStatus: "حالة المشروع",
    access: "الوصول",
    editDetails: "تعديل التفاصيل",
    exportReport: "تصدير التقرير",
    maturityAssessment: "تقييم النضج",
    keyObjectives: "الأهداف الرئيسية",
    stakeholders: "المستفيدين",
    overallProgress: "التقدم الإجمالي",
    completedTasks: "المهام المكتملة",
    domainProcessComparison:"مقارنة التقدم في المجالات",
    organization: "المؤسسة",
    industry: "الصناعة",
    dashboardCustomization: "تخصيص لوحة القيادة",
    displayLayout: "عرض التخطيط",
    gridView: "عرض الشبكة",
    listView: "عرض القائمة",
    widgetSelection: "اختيار الوحدات",
    assessMaturityLevel: "تقييم مستوى نضجك",
    maturityLevel: "مستوى نضج",
    progressOverview: "عرض التقدم",
    tasksStatus: "حالة المهام",
    domains: "المجالات",
    chartsAnalytics: "الرسوم البيانية والتحليلات",
    pmoMaturityLevel: "مستوى نضج مكتب إدارة المشاريع",
    pmoDomains: "مجالات مكتب إدارة المشاريع",
    aiAnalysis: "التسريع بالذكاء الاصطناعي",
    aiDescription: "دع الذكاء الاصطناعي المتقدم لدينا يحلل بيانات مكتب إدارة المشاريع الخاص بك وينشئ توصيات شاملة مصممة وفقًا لاحتياجات مؤسستك الفريدة.",
    tryAiAnalysis: "جرب تحليل الذكاء الاصطناعي",
    viewAll: "عرض الكل",
    of: "من",
    tasksCompleted: "المهام المكتملة",
    notSet: "غير محدد",
    updateProfile: "تحديث الملف الشخصي",
    viewAllTasks: "عرض جميع المهام",
    nextSteps: "الخطوات التالية",
    completePmoMaturityAssessment: "إكمال تقييم نضج مكتب إدارة المشاريع",
    getInsightsAboutPmoMaturityLevel: "الحصول على المعلومات حول نضج مكتب إدارة المشاريع الحالي",
    uploadDocuments: "رفع المستندات",
    analysisDocuments: "رفع المستندات الدعمية لتحليل الذكاء الاصطناعي",
    analysisDocumentsDesc: "تعزيز توصيات الذكاء الاصطناعي بسياق مؤسستك",
    reviewPractices: "مراجعة أفضل الممارسات",
    explorePractices: "استكشاف مكتبة أفضل الممارسات للتوجيه",
    viewResources: "عرض الموارد",
    goToAssessment: "الذهاب إلى التقييم",
    objective1: "إنشاء إطار حوكمة مكتب إدارة المشاريع",
    objective2: "تطوير منهجيات قياسية",
    objective3: "تنفيذ مقاييس الأداء",
    sampleProject: "تنفيذ مكتب إدارة المشاريع النموذجي",
    sampleDescription: "مشروع نموذجي مع بيانات معدة مسبقًا للعرض التوضيحي",
    createFirstProject: "إنشاء مشروع مكتب إدارة المشاريع الأول",
    firstProjectDesc: "ابدأ بإنشاء مشروع تنفيذ مكتب إدارة المشاريع الأول. يمكنك إعداد تفاصيل المشروع وتتبع التقدم عبر المجالات وإنشاء توصيات مدعومة بالذكاء الاصطناعي.",
    createSample: "إنشاء مشروع نموذجي",
    aiFeature1: "قوالب مخصصة بناءً على مستوى نضجك الحالي",
    aiFeature2: "خرائط طريق تنفيذ مفصلة لكل مجال",
    aiFeature3: "أفضل الممارسات المصممة خصيصًا لصناعتك وسياقك",
    maturityRadarChart: "مخطط النضج المتجه",
    higherValuesIndicateGreaterMaturity: "القيم الأعلى تشير إلى نضج أعلى",
    createNew: "إنشاء مشروع جديد",
    pmoMaturityAssessment: "تقييم نضج مكتب إدارة المشاريع",
    assessPmoMaturity: "تقييم نضج مكتب إدارة المشاريع",
    selfAssessment: "تقييم ذاتي",
    aiGeneratedAssessment: "تقييم مولد بالذكاء الاصطناعي",
    notSpecified: "غير محدد",
    currentMaturityProfile: "النضج الحالي لمكتب إدارة المشاريع",
    organizationDetails: "تفاصيل المؤسسة",
    assessmentType: "نوع التقييم",
    assessmentDate: "تاريخ التقييم",
    selfAssessmentQuestionnaire: "استبيان تقييم نضج مكتب إدارة المشاريع",
    selfAssessmentDescription: "قيم نضج مكتب إدارة المشاريع لكل مجال. يرجى النظر في عملياتك والوثائق وقدرات القياس وجهود التحسين المستمرة عند إجراء تقييمك.",
    documentation: "الوثائق",
    metrics: "المقاييس",
    minimalToNone: "أقل من الصفر",
    basicDocumentation: "الوثائق الأساسية",
    comprehensiveDocumentation: "الوثائق الشاملة",
    regularlyUpdated: "محدث بشكل منتظم",
    leadingPractice: "ممارسة مبتكرة",
    adHocOrNone: "عشوائي أو لا شيء",
    basicTracking: "تتبع أساسي",
    dataDrivenDecisions: "قرارات مقاسة بالبيانات",
    predictiveAnalytics: "تحليلات منطقية",
    advancedAnalytics: "تحليلات متقدمة",
    
    currentMaturityProfileDescription: "مكتب إدارة المشاريع الخاص بك يوجد حاليا في",
    currentMaturityProfileDescription2: "مستوى. سيساعدك هذا التقييم في تحديد المناطق التي يمكن تحسينها وإنشاء خارطة طريق لتطوير قدرات مكتب إدارة المشاريع الخاص بك.",
    notes: "ملاحظات (اختياري)",
    notesPlaceholder: "أضف أي ملاحظات أو سياق حول تقييمك...",
    generateAIAssessment: "إنشاء تقييم بالذكاء الاصطناعي",
    aiAssessmentDescription: "سيقوم الذكاء الاصطناعي المتقدم بتحليل مدخلاتك وإنشاء توصيات مخصصة",
    aiAssessmentSummary: "ملخص تقييم الذكاء الاصطناعي",
    aiAssessmentSummaryDescription: "بناءً على تحليلنا ، يوجد مكتب إدارة المشاريع الخاص بك حاليا في",
    keyStrengths: "القوى الرئيسية",
    areasForImprovement: "المناطق التي يمكن تحسينها",
    domainSpecificAssessment: "تقييم مجالي",
    maturityProgression: "تقدم نضج مكتب إدارة المشاريع",
    recommendations: "التوصيات",
    generatingReport: "جاري إنشاء التقرير...",
    exportAssessmentReport: "تصدير تقرير التقييم",
    detailedMaturityGuide: "دليل النضج المفصل",
    maturityModelReference: "مرجع نضج النموذج",
    generateAssessment: "إنشاء تقييم",
    generatingAssessment: "جاري إنشاء تقييم...",
    generatingAssessmentDescription: "يتم تحليل بيانات مكتب إدارة المشاريع الخاص بك عبر جميع المجالات. قد يستغرق هذا بضع ثوانٍ.",
    barCharts: "الرسوم البيانية",
    ganttTimeline: "الخط الزمني المنحدر",
    
  },
  ganttChart: {
    cancel: "إلغاء",
    addTask: "إضافة مهمة",
    legend: "العلامات",
    taskName: "اسم المهمة",
    domain: "المجال",
    dependencies: "التبعيات",
    startDate: "بدء المهمة",
    endDate: "نهاية المهمة",
    progress: "التقدم",
    color: "اللون",
    addNewTask: "إضافة مهمة جديدة",
    save: "حفظ",
    projectTimeline: "الخط الزمني للمشروع",
    day: "يوم",
    week: "أسبوع",
    month: "شهر",
    editTask: "تعديل المهمة",
    timeline: "الخط الزمني",
    selectDomain: "اختر المجال",
    unknownDomain: "مجال غير معروف",
    delete: "حذف",
    add: "إضافة",
    edit: "تعديل",
    close: "إغلاق",
    deleteTask: "حذف المهمة",
    deleteTaskConfirmation: "هل أنت متأكد ؟",
    
  },
  // Domain detail page
  domain: {
    BestPractices: "أفضل الممارسات",
    Organizational: "التطوير التنظيمي والمواءمة",
    Strategic: "الإطار الاستراتيجي والحوكمة",
    PMO: "هيكل وتصميم مكتب إدارة المشاريع",
    Operational: "التميز التشغيلي",
    Performance: "الأداء والتحسين",
    Capability: "تطوير القدرات",
    backToDashboard: "العودة إلى لوحة القيادة",
    prevDomain: "المجال السابق",
    nextDomain: "المجال التالي",
    viewDomain: "عرض المجال",
    progress: "التقدم",
    tasks: "المهام والتقدم",
    input: "إدخال المجال والتحليل",
    analyzing: "تحليل إدخال المجال",
    processingData: "الذكاء الاصطناعي لدينا يعالج بياناتك...",
    inputStage: "الإدخال",
    inputDesc: "جمع البيانات وتقييم الحالة الحالية وجمع المتطلبات لهذا المجال.",
    processingStage: "المعالجة",
    processingDesc: "تحليل البيانات وتطوير الأطر وتصميم الحلول لهذا المجال.",
    outputStage: "الإخراج",
    outputDesc: "إنشاء المخرجات وتنفيذ الحلول وإنشاء الأطر لهذا المجال.",
    loading: "جاري تحميل بيانات المجال...",
    notFound: "المجال غير موجود",
    provideInputFirst: "يرجى تقديم بيانات إدخال المجال قبل التحليل",
    aiGeneratedAnalysis: "تحليل مولد بالذكاء الاصطناعي لـ",
    generated: "تم إنشاؤه",
    analysis: "التحليل",
    domainProgress: "التقدم في المجال (%)",
    templates: "القوالب",
    downloadMarkdown: "تنزيل ماركداون",
    downloadPdf: "تنزيل PDF",
    generatingPdf: "جاري إنشاء PDF...",
    generating: "جاري الإنشاء...",
    allTemplates: "جميع القوالب المتاحة",
    markdownFormat: "ماركداون",
    words: "كلمات",
    usingTemplates: "استخدام هذه القوالب",
    templateDescription: "هذه القوالب متاحة بتنسيقات ماركداون و PDF. يمكن استيراد ماركداون إلى محرري المستندات وأدوات إدارة المشاريع أو تحويلها إلى تنسيقات أخرى. ملفات PDF جاهزة للطباعة أو المشاركة مع أصحاب المصلحة.",
    noTemplates: "لا توجد قوالب متاحة لهذا المجال",
    aiConfigTitle: "تكوين تحليل الذكاء الاصطناعي",
    selectDomainPrompt: "اختر مجالًا لتحليله باستخدام الذكاء الاصطناعي المتقدم. سيولد التحليل توصيات وقوالب شاملة بناءً على سياق مؤسستك المحدد.",
    selectDomain: "اختر المجال",
    analysisDepth: "عمق التحليل",
    basic: "أساسي",
    quickOverview: "نظرة عامة سريعة",
    standard: "قياسي",
    balancedAnalysis: "تحليل متوازن",
    detailed: "مفصل",
    inDepthReview: "مراجعة متعمقة",
    comprehensive: "شامل",
    maximumDetail: "تفاصيل قصوى",
    geminiPowered: "تحليل مدعوم بـ Gemini AI",
    advancedAiDesc: "سيقوم الذكاء الاصطناعي المتقدم بتحليل مدخلاتك وإنشاء توصيات مخصصة",
    startAnalysis: "بدء التحليل",
    uploadSupportingDocuments: "رفع المستندات الدعمية",
    documentsEnhanceAIAnalysisAccuracy: "تعزيز دقة التحليل الذكي",
    supportedFormats: "التنسيقات المدعومة: .txt, .md, .html, .docx, .pdf",
    browseFiles: "تصفح الملفات",
    change: "تغيير",
    processing: "جاري المعالجة...",
    processDocument: "معالجة المستند",
    documentProcessedSuccessfully: "تم معالجة المستند بنجاح",
    documentSplitIntoChunksForOptimalAnalysis: "تم تقسيم المستند إلى {processedDoc.totalChunks} منطقة للتحليل الأمثل",
    provideInformationAboutYourOrganizationApproachToDomainName: "أعطاء معلومات عن طريقة المؤسسة في",
    thisDataWillBeAnalyzedToGenerateComprehensiveRecommendationsAndCompletedTemplates: "سيتم تحليل هذه البيانات لإنشاء توصيات شاملة وقوالب مكتملة",
    workingInOfflineMode: "العمل في وضع عدم الاتصال",
    youAppearToBeWorkingOfflineOrHaveConnectionIssuesWithTheDatabase: "يبدو أنك تعمل عديم الاتصال أو لديك مشاكل مع الاتصال بقاعدة البيانات",
    youCanContinueWorkingAndChangesWillBeSavedLocally: "يمكنك الاستمرار في العمل وسيتم حفظ التغييرات المحليا",
    longInputDetected: "تم اكتشاف مدخلات طويلة",
    yourInputIsQuiteLong: "مدخلاتك طويلة جدا ({inputLength.toLocaleString()} حرف). للتحليل الأسرع، يرجى التركيز على المعلومات المهمة وإزالة التفاصيل الأقل أهمية.",
    useSampleData: "استخدام البيانات العينية",
    showSampleData: "إظهار البيانات العينية",
    hideSampleData: "إخفاء البيانات العينية",
    sampleInputData: "بيانات المدخلات العينية",
    showPreviousDomainOutput: "إظهار إخراج المجال السابق",
    hidePreviousDomainOutput: "إخفاء إخراج المجال السابق",
    enterInformationAboutYourOrganizationPractices: "أدخل معلومات عن طريقة المؤسسة في",
    practices: "الممارسات",
    sampleData: "بيانات العينة",
    characters: "حرف",
    saving: "يتم حفظ...",
    saved: "تم حفظ!",
    saveDraft: "حفظ المسودة",
    offlineMode: "وضع عدم الاتصال",
    analysisLimited: "تقييد التحليل",
    aiAnalysis: "تحليل الذكاء الاصطناعي",
    quickAnalysisWithOpenAI: "تحليل سريع باستخدام OpenAI",
    analysisTypicallyTakes2040SecondsToCompleteDependingOnInputLength: "يأخذ التحليل عادةً 20-40 ثانية لإكماله بناءً على طول المدخلات.",
    loadingReferences: "يتم تحميل المراجع...",
    relevantInformationFromOtherDomainsThatCanEnhanceYourWorkInThisDomain: "المعلومات المتعلقة بالمجالات الأخرى التي يمكن أن تعزز عملك في هذا المجال:",
    noCrossDomainReferencesFound: "لم يتم العثور على مراجع متقاطعة. كلما أضفت المزيد من المستندات إلى المجالات الأخرى، سيظهر المعلومات المتعلقة تلقائيًا هنا.",
    crossDomainReferences: "مراجع متقاطعة",
    aiEnhanced: "محسنة بالذكاء الاصطناعي",
  },

  // Project management
  project: {
    projectName: "اسم المشروع",
    projectNamePlaceholder: "تنفيذ مكتب إدارة المشاريع المؤسسية",
    description: "الوصف",
    descriptionPlaceholder: "وصف موجز لمشروع تنفيذ مكتب إدارة المشاريع",
    budget: "الميزانية",
    yourProjects: "مشاريعك",
    createProject: "إنشاء مشروع"
  },
  
  // Sidebar
  sidebar: {
    dashboard: "لوحة القيادة",
    pmoDomains: "مجالات مكتب إدارة المشاريع",
    tools: "الأدوات والتقييم",
    resources: "الموارد",
    tasks: "المهام",
    bestPractices: "أفضل الممارسات",
    maturityAssessment: "تقييم النضج",
    settings: "الإعدادات",
    assessment: "التقييم"
  },
  
  // Auth pages
  auth: {
    copyright: "© 2025 بناء مكتب إدارة المشاريع بواسطة د. أحمد السنوسي"
  },

  // Maturity levels
  maturityLevels:{
    initial: {
      label: 'البدء',
      description: 'العمليات عشوائية ومشوهة.'
    },
    defined: {
      label: 'معرف',
      description: 'العمليات مدونة ومعيارية.'
    },
    managed: {
      label: 'اداره',
      description: 'العمليات مقاسة ومنضبطة.'
    },
    optimized: {
      label: 'مثالي',
      description: 'التركيز على التحسين المستمر.'
    },
    innovative: {
      label: 'مبتكر',
      description: 'يقود التطوير الصناعي والتكيف.'
    }
  },



  profile: {
    title: 'الملف الشخصي',
    description: 'إعداد تفاصيل المؤسستك لتخصيص رحلتك مكتب إدارة المشاريع',
    organizationName: 'اسم المؤسسة',
    organizationNamePlaceholder: 'أدخل اسم مؤسستك',
    industry: 'الصناعة',
    industryPlaceholder: 'أدخل الصناعة الخاصة بك',
    pmoMaturityLevel: 'مستوى نضج مكتب إدارة المشاريع',
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: 'حدد المستوى الذي يناسب أفضل الوصف لنضج مكتب إدارة المشاريع الحالي',
    initial: 'البدء - عمليات عشوائية ومشوهة',
    defined: 'معرف - عمليات مدونة ومعيارية',
    managed: 'اداره - عمليات مقاسة ومنضبطة',
    optimized: 'مثالي - التركيز على التحسين المستمر',
    notEstablished: 'لم يتم التأسيس - لا يوجد مكتب إدارة منضبط',
    saveProfile: 'حفظ الملف الشخصي',
    cancel: 'إلغاء',
  },
  //settings page
  settings: {
    title: "الإعدادات",
    description: "إدارة الإعدادات الشخصية والأهداف",
    personal: "الشخصي",
    subscription: "الاشتراك",
    notifications: "الإشعارات",
    security: "الأمان",
    data: "البيانات",
    saveProfile: "حفظ الإعدادات",
    cancel: "إلغاء",
    selectTheMaturityLevelThatBestDescribesYourCurrentPMO: "حدد المستوى الذي يناسب أفضل الوصف لنضج مكتب إدارة المشاريع الحالي",
    organizationName: "اسم المؤسسة",
    organizationNamePlaceholder: "أدخل اسم مؤسستك",
    industry: "الصناعة",
    industryPlaceholder: "أدخل الصناعة الخاصة بك",
    pmoMaturityLevel: "مستوى نضج مكتب إدارة المشاريع",
    notEstablished: "لم يتم التأسيس - لا يوجد مكتب إدارة منضبط",
    initial: "البدء - عمليات عشوائية ومشوهة",
    defined: "معرف - عمليات مدونة ومعيارية",
    managed: "اداره - عمليات مقاسة ومنضبطة",
    optimized: "مثالي - التركيز على التحسين المستمر",
    
  },
// صفحة المساعدة
help: {
  title: "المساعدة والدعم",
  description: "تعلم كيفية استخدام أداة تطبيق مجالات مكتب إدارة المشاريع  بفعالية",
  gettingStarted: "البدء",
  whatIsPmoDomainsTool: "ما هي أداة مجالات مكتب إدارة المشاريع?",
  whatIsPmoDomainsToolDescription: `تساعد أداة تطبيق مجالات مكتب إدارة المشاريع المتخصصين في مكاتب إدارة المشاريع على تطبيق ومتابعة المجالات الخمسة الرئيسية باستخدام إطار عمل منظم "المدخلات - المعالجة - المخرجات". توجهك الأداة خلال مهام كل مجال لضمان تطبيق أفضل الممارسات والمقارنة بالمعايير الصناعية.`,
  howToUseThisTool: "كيفية استخدام هذه الأداة",
  howToUseThisToolDescription: "أداة تطبيق مجالات مكتب إدارة المشاريع هي تطبيق ويب يساعد المؤسسات على تنفيذ وتحسين قدرات مكتب إدارة المشاريع عبر جميع المجالات.",
  canIExportMyData: "هل يمكنني تصدير بياناتي؟",
  canIExportMyDataDescription: "نعم، يمكنك تصدير بياناتك من صفحة الإعدادات. يتيح لك ذلك الاحتفاظ بنسخة احتياطية من تقدمك أو نقلها إلى نظام آخر.",
  canICustomizeTheToolForMyOrganization: "هل يمكنني تخصيص الأداة لمؤسستي؟",
  canICustomizeTheToolForMyOrganizationDescription: "تم تصميم الأداة لتكون قابلة للتطبيق عبر مؤسسات وصناعات مختلفة. يمكنك إضافة ملاحظات مخصصة لكل مهمة لتناسب سياق مؤسستك.",
  whatIfINotReadyToCompleteAllDomains: "ماذا لو لم أكن مستعدًا لإكمال جميع المجالات؟",
  whatIfINotReadyToCompleteAllDomainsDescription: "يمكنك العمل على المجالات بأي ترتيب يناسب مؤسستك. ستقوم الأداة بتتبع تقدمك في جميع المجالات، مما يتيح لك التركيز على أولوياتك.",
  contactSupport: "الاتصال بالدعم",
  contactSupportDescription: "إذا كنت بحاجة إلى مساعدة إضافية أو لديك أسئلة حول أداة تطبيق مجالات مكتب إدارة المشاريع، يرجى الاتصال بفريق الدعم الخاص بنا.",
  supportContact: "معلومات الاتصال بالدعم",
  supportContactEmail: "البريد الإلكتروني: support@pmodomains.com",
  supportContactPhone: "الهاتف: (555) 123-4567",
  supportContactHours: "ساعات العمل: من الاثنين إلى الجمعة، 9 صباحًا - 5 مساءً بتوقيت شرق الولايات المتحدة",
  startBySettingUpYourOrganizationProfile: "ابدأ بإعداد ملف مؤسستك في قسم الملف الشخصي",
  navigateToEachDomainUsingTheSidebarMenu: "تنقل إلى كل مجال باستخدام قائمة الشريط الجانبي",
  completeTasksInTheRecommendedOrder: "أكمل المهام بالترتيب الموصى به: المدخلات → المعالجة → المخرجات",
  markTasksAsCompleteAsYouProgress: "حدد المهام كمكتملة أثناء تقدمك",
  useTheDashboardToTrackYourOverallProgress: "استخدم لوحة التحكم لتتبع تقدمك العام",
  referToTheBestPracticesLibraryForGuidance: "ارجع إلى مكتبة أفضل الممارسات للحصول على إرشادات",
  organizationalDevelopmentAndAlignment: "1. تطوير المؤسسة والمواءمة",
  organizationalDevelopmentAndAlignmentDescription: "يركز هذا المجال على مواءمة مكتب إدارة المشاريع مع استراتيجية المؤسسة وثقافتها لضمان ممارسات إدارة مشاريع فعالة. يتضمن التقييم التنظيمي، وتحليل أصحاب المصلحة، وتطوير استراتيجيات المواءمة.",
  strategicElementsOfThePmo: "2. العناصر الاستراتيجية لمكتب إدارة المشاريع",
  strategicElementsOfThePmoDescription: "يتضمن هذا المجال تطوير وتنفيذ الأطر الاستراتيجية، وخطط الطريق، وهياكل الحوكمة. يشمل مراجعة الأهداف الاستراتيجية، وتحليل المحافظ، وتصميم هيكل الحوكمة.",
  pMODesignAndStructuring: "3. تصميم وهيكلة مكتب إدارة المشاريع",
  pMODesignAndStructuringDescription: "يركز هذا المجال على إنشاء الهيكل الأمثل لمكتب إدارة المشاريع، والأدوار، والمسؤوليات لتلبية احتياجات المؤسسة. يتضمن جمع المتطلبات، وتقييم الموارد، وتطوير كتالوج الخدمات.",
  pMOOperationAndPerformance: "4. تشغيل وأداء مكتب إدارة المشاريع",
  pMOOperationAndPerformanceDescription: "يضع هذا المجال العمليات التشغيلية، ومؤشرات الأداء الرئيسية، ومقاييس الأداء لمكتب إدارة المشاريع. يتضمن تقييم العمليات، وتحديد مؤشرات الأداء، وأنظمة قياس الأداء.",
  pMOEnhancementAndEffectiveness: "5. تعزيز وفعالية مكتب إدارة المشاريع",
  pMOEnhancementAndEffectivenessDescription: "يركز هذا المجال على تحسين خدمات مكتب إدارة المشاريع، والقدرات، وتقديم القيمة باستمرار. يتضمن تقييم النضج، وتحليل تقديم القيمة، وخطط التحسين المستمر.",
  frequentlyAskedQuestions: "الأسئلة الشائعة",
  frequentlyAskedQuestionsDescription: "أداة تطبيق مجالات مكتب إدارة المشاريع هي تطبيق ويب يساعد المؤسسات على تنفيذ وتحسين قدرات مكتب إدارة المشاريع عبر جميع المجالات.",
  howToAccessTemplates: "كيف يمكنني الوصول إلى القوالب؟",
  howToAccessTemplatesDescription: "تتوفر القوالب ضمن المهام المحددة التي تحتوي على موارد القوالب. يمكنك أيضًا العثور على مجموعة من القوالب في مكتبة أفضل الممارسات.",
  understandingTheFiveDomains: "فهم المجالات الخمسة",
},


subscription: {
  title: "الاشتراكات",
  currentPlan: "المستوى الحالي",
  trial: "المحادة",
  cancelsAtPeriodEnd: "يلغي في نهاية الفترة",
  upgradePlan: "ترقية المستوى",
  manageSubscription: "إدارة الاشتراك",
  processing: "يتم المعالجة...",
  billingPeriod: "الفترة المدفوعة",
  nextBillingDate: "تاريخ الفوتر القادم",
  paymentMethod: "طريقة الدفع",
  projects: "المشاريع",
  aiAnalysis: "التحليل الآلي",
  storage: "التخزين",
  freePlanLimitations: "المحدودات المجانية",
  freePlanLimitationsDescription: "لقد تم تحديدك على المستوى المجاني الذي يحدد عدد المشاريع والتحليلات الآلية والتخزين المتاحين.",
  upgradeNow: "ترقية الآن",
  upgradeToGetMore: "ترقية للحصول على المزيد",
  premiumPlanBenefits: "فوائد المستوى الممتاز",
  upTo20Projects: "20 مشروع (بدلاً من 3 في المجانية)",
  upTo100AiAnalyses: "100 تحليل آلي في الشهر (بدلاً من 3 في المجانية)",
  teamCollaboration: "التعاون في الفريق مع حتى 5 مستخدمين",
  prioritySupport: "الدعم الأولوية",
  upgradeToPremium: "ترقية إلى الممتاز",
  enterprisePlanBenefits: "فوائد المستوى المنتج",
  unlimitedProjectsAndAiAnalyses: "أي عدد من المشاريع والتحليلات الآلية",
  unlimitedTeamMembers: "أي عدد من الأعضاء في الفريق",
  whiteLabelingOptions: "خيارات التسمية البيضاء",
  dedicatedSupport: "الدعم المخصص",
  upgradeToEnterprise: "ترقية إلى المنتج",
  unlimited: "غير محدود",
  unknown: "غير معروف",
  free: "مجاني",
  premium: "ممتاز",
  enterprise: "منتج",
  usageAndLimits: "الاستخدام والمحدودات",
  perMonth: "في الشهر",
  mb: "ميجابايت",
  none: "لا شيء",
  creditCard: "بطاقة الائتمان",
  paypal: "بايبال",
  notAvailable: "غير متاح",
  
  
},
  notifications: {
    '1': {
      title: "التقديم المستحق لتقييم النضج",
      description: "قم بإكمال تقييم النضج الربعي الخاص بك بحلول الجمعة القادمة.",
      time: "2 أيام مضت",
    },
    '2': {
      title: "تحديث المجال الاستراتيجي",
      description: "تم إضافة قوالب جديدة وموارد إلى المجال الاستراتيجي.",
      time: "3 أيام مضت",
    },
    '3': {
      title: "اجتماع الفريق: تعزيز مكتب إدارة المشاريع",
      description: "اجتماع قادم لمناقشة تعزيز مكتب إدارة المشاريع.",
      time: "الغد, 10:00 ص",
    },
    '4': {
      title: "رسالة جديدة من الإدارة",
      description: "لديك رسالة جديدة متعلقة بتقدم المجال التنظيمي الخاص بك.",
      time: "أسبوع مضت",
    },
    '5': {
      title: "إكمال إعادة النسخ",
      description: "تم إكمال إعادة النسخ الخاصة بك إلى التخزين السحابي.",
      time: "2 أسابيع مضت",
    },
    title: "الإشعارات",
    description: "ابقى على اطلاع بأنشطة مكتب إدارة المشاريع الخاص بك والإشعارات المهمة",
    markAllAsRead: "تحديد الكل كمقروء",
    clearAll: "مسح الكل",
    markAllAsReadDescription: "تحديد جميع الإشعارات المقروءة",
    clearAllDescription: "مسح جميع الإشعارات",
    markAllAsReadButton: "تحديد الكل كمقروء",
    clearAllButton: "مسح الكل",
    unread: "غير مقروء",
    all: "الكل",
    recentNotifications: "آخر الإشعارات",
    markAsUnread: "تحديد كغير مقروء",
    markAsRead: "تحديد كمقروء",
    viewDetails: "عرض التفاصيل",
    loadMore: "تحميل المزيد",
    customizeNotifications: "تخصيص كيفية وأوقات الاستلام الإشعارات حول أنشطة مكتب إدارة المشاريع الخاص بك",
    notificationPreferences: "إعدادات الإشعارات",
    managePreferences: "إدارة الإعدادات",
    
    
    
    
  },
  // Domain names
  domains: {
    "1": {
      name: "التطوير التنظيمي والمواءمة",
      description: "محاذاة مكتب إدارة المشاريع مع الاستراتيجية التنظيمية والثقافة لضمان الممارسات الفعالة لإدارة المشاريع.",
      tasks: {
        "1-input-1": {
          stage: "الإدخال",
          title: "تقييم الكفاءات الحالية",
          description: "جمع البيانات حول الكفاءات الحالية من خلال الاستبيانات والمقابلات ومراجعة الوثائق.",
          bestPractices: [
            "استخدام أدوات تقييم موحدة لتقييم الكفاءات الحالية",
            "جمع آراء من مستويات تنظيمية متعددة",
            "توثيق الكفاءات الفنية والمهارية",
            "تحديد فجوات الكفاءة من خلال تقييم منظم"
          ]
        },
        "1-input-2": {
          stage: "الإدخال",
          title: "تقييم الثقافة التنظيمية",
          description: "جمع بيانات حول الثقافة التنظيمية الحالية من خلال الاستبيانات، ومجموعات النقاش، ومقابلات أصحاب المصلحة.",
          bestPractices: [
            "إجراء استبيانات تقييم الثقافة",
            "جمع ملاحظات من مستويات تنظيمية متنوعة",
            "توثيق العوامل المساعدة والمعيقة للثقافة في إدارة المشاريع",
            "جمع بيانات تاريخية حول مبادرات التغيير الثقافي"
          ]
        },
        "1-input-3": {
          stage: "الإدخال",
          title: "القياس مقابل المعايير الصناعية",
          description: "جمع بيانات المقارنة الصناعية وأفضل الممارسات لتحقيق التوافق التنظيمي.",
          bestPractices: [
            "اختيار معايير ومقاييس صناعية مناسبة",
            "جمع البيانات من تقارير ومنشورات الصناعة",
            "توثيق ممارسات المؤسسات النظيرة",
            "جمع مؤشرات للتحليل المقارن"
          ]
        },
        "1-processing-1": {
          stage: "المعالجة",
          title: "تطبيق تقنيات التحليل الاستراتيجي",
          description: "استخدام أدوات التحليل الاستراتيجي لتطوير استراتيجية متكاملة مع إدارة المخاطر وخارطة طريق للتنفيذ.",
          bestPractices: [
            "تطبيق تحليل SWOT لتحديد نقاط القوة والضعف",
            "استخدام تحليل الفجوة لتحديد مجالات التحسين",
            "تطبيق منهجيات تقييم المخاطر",
            "استخدام تقنيات إعداد خارطة الطريق للتنفيذ"
          ]
        },
        "1-processing-2": {
          stage: "المعالجة",
          title: "تطبيق منهجيات تخطيط الاتصال",
          description: "استخدام تقنيات تخطيط الاتصال لتطوير رسائل مخصصة لأصحاب المصلحة وآليات التغذية الراجعة.",
          bestPractices: [
            "تطبيق تقنيات تحليل أصحاب المصلحة",
            "استخدام طرق تطوير مصفوفة الاتصال",
            "تطبيق منهجيات تخصيص الرسائل",
            "استخدام أطر مؤشرات الأداء لقياس فعالية الاتصال"
          ]
        },
        "1-processing-3": {
          stage: "المعالجة",
          title: "تطبيق تقنيات إعداد الميثاق",
          description: "استخدام منهجيات إعداد الميثاق لتعريف نطاق مكتب إدارة المشاريع، والسلطة، وهيكل الحوكمة.",
          bestPractices: [
            "تطبيق تقنيات تحديد النطاق",
            "استخدام طرق تطوير مصفوفة RACI",
            "تطبيق منهجيات تصميم إطار الحوكمة",
            "استخدام تقنيات رسم خرائط الصلاحيات"
          ],
          templates: ["نموذج ميثاق مكتب إدارة المشاريع", "مصفوفة RACI"]
        },
        "1-output-1": {
          stage: "الإخراج",
          title: "تقديم استراتيجية متكاملة وخارطة طريق",
          description: "إنتاج وتنفيذ الاستراتيجية المتكاملة مع خطة إدارة المخاطر وخارطة طريق تنفيذية مرحلية.",
          bestPractices: [
            "توثيق استراتيجية شاملة بأهداف واضحة",
            "إنشاء خارطة طريق تفصيلية مع مراحل تنفيذ",
            "تطوير خطة إدارة المخاطر باستراتيجيات تخفيف",
            "وضع آليات لمراجعة وتحديث الاستراتيجية"
          ]
        },
        "1-output-2": {
          stage: "الإخراج",
          title: "تأسيس رؤية وقيم وثقافة مكتب إدارة المشاريع",
          description: "تنفيذ بيان الرؤية والقيم الأساسية وبرنامج التغيير الثقافي بمشاركة القيادة.",
          bestPractices: [
            "إنشاء بيان رؤية ملهم يتماشى مع أهداف المنظمة",
            "توثيق القيم الأساسية مع أمثلة سلوكية",
            "تنفيذ أنشطة تفاعل مع القيادة",
            "إرساء آليات دعم ثقافي مستمرة"
          ],
          templates: ["نموذج بيان رؤية مكتب إدارة المشاريع", "خارطة طريق التغيير الثقافي"]
        },
        "1-output-3": {
          stage: "الإخراج",
          title: "تنفيذ ميثاق وهيكل حوكمة مكتب إدارة المشاريع",
          description: "تأسيس وتفعيل ميثاق مكتب إدارة المشاريع مع تحديد النطاق والصلاحيات وهيكل الحوكمة.",
          bestPractices: [
            "إقرار رسمي لميثاق مكتب إدارة المشاريع بموافقة الإدارة العليا",
            "تطبيق هيكل حوكمة واضح المهام والمسؤوليات",
            "تحديد الصلاحيات وآليات اتخاذ القرار",
            "إنشاء آلية مراجعة وتحديث للميثاق"
          ],
          templates: ["وثيقة ميثاق مكتب إدارة المشاريع", "مخطط هيكل الحوكمة"]
        },
      },
    },
    "2": {
      name: "الإطار الاستراتيجي والحوكمة",
      description: "إنشاء الإطار الاستراتيجي والهيكل الحوكمي الأمثل لتلبية احتياجات المؤسسة.",
      tasks: {
        "2-input-1": {
          stage: "الإدخال",
          title: "جمع بيانات الحالة الحالية",
          description: "جمع بيانات حول عمليات وإجراءات وأداء إدارة المشاريع الحالي.",
          bestPractices: [
            "مراجعة توثيق العمليات",
            "جمع مقاييس الأداء والبيانات التاريخية",
            "جمع ملاحظات أصحاب المصلحة حول العمليات الحالية",
            "توثيق هياكل الحوكمة الحالية"
          ]
        },
        "2-input-2": {
          stage: "الإدخال",
          title: "جمع معلومات التوافق الاستراتيجي",
          description: "جمع الأهداف الاستراتيجية للمنظمة والأولويات ومعايير النجاح.",
          bestPractices: [
            "مراجعة الخطط الاستراتيجية للمنظمة",
            "جمع أولويات القيادة التنفيذية",
            "توثيق أهداف وحدات الأعمال",
            "جمع معلومات عن المبادرات الاستراتيجية"
          ]
        },
        "2-input-3": {
          stage: "الإدخال",
          title: "تحديد متطلبات القدرات",
          description: "جمع بيانات حول القدرات المطلوبة من خلال مقابلات مع أصحاب المصلحة وتقييم احتياجات المنظمة.",
          bestPractices: [
            "إجراء مقابلات لتحديد احتياجات القدرات",
            "جمع معايير القدرات في الصناعة",
            "توثيق معايير ترتيب أولوية القدرات",
            "جمع مقاييس نضج القدرات"
          ]
        },
        "2-processing-1": {
          stage: "المعالجة",
          title: "تطبيق منهجية تطوير التفويض",
          description: "استخدام تقنيات تطوير التفويض لتعريف غرض وصلاحيات ومسؤوليات مكتب إدارة المشاريع.",
          bestPractices: [
            "تطبيق طرق تطوير بيان الغرض",
            "استخدام تقنيات رسم خرائط الصلاحيات",
            "تطبيق منهجيات تحديد المسؤوليات",
            "استخدام أساليب التحقق من أصحاب المصلحة"
          ],
          templates: ["نموذج تفويض مكتب إدارة المشاريع", "اتفاقية الرعاية التنفيذية"]
        },
        "2-processing-2": {
          stage: "المعالجة",
          title: "تطبيق إطار تطوير الميثاق",
          description: "استخدام إطار تطوير الميثاق لإنشاء ميثاق شامل لمكتب إدارة المشاريع يشمل الأدوار وهيكل الحوكمة.",
          bestPractices: [
            "تطبيق تقنيات صياغة الرؤية والرسالة",
            "استخدام طرق تصميم الهيكل التنظيمي",
            "تطبيق منهجيات تحديد الأدوار",
            "استخدام تقنيات تصميم إطار الحوكمة"
          ],
          templates: ["نموذج ميثاق مكتب إدارة المشاريع", "مخطط هيكل الحوكمة"]
        },
        "2-processing-3": {
          stage: "المعالجة",
          title: "تطبيق منهجية تصميم الحوكمة",
          description: "استخدام تقنيات تصميم الحوكمة لتطوير عمليات اتخاذ القرار وآليات الإشراف.",
          bestPractices: [
            "تطبيق تقنيات رسم خرائط حقوق اتخاذ القرار",
            "استخدام طرق تصميم مسارات التصعيد",
            "تطبيق منهجيات تصميم هيئات الحوكمة",
            "استخدام تقنيات تخطيط الاتصال للحوكمة"
          ],
          templates: ["نموذج إطار الحوكمة", "مصفوفة حقوق اتخاذ القرار"]
        },
        "2-output-1": {
          stage: "الإخراج",
          title: "إقرار تفويض وميثاق مكتب إدارة المشاريع",
          description: "إضفاء الطابع الرسمي وتنفيذ تفويض وميثاق مكتب إدارة المشاريع مع تحديد الغرض والصلاحيات والمسؤوليات.",
          bestPractices: [
            "الحصول على موافقة الإدارة العليا على التفويض والميثاق",
            "إبلاغ جميع أصحاب المصلحة بالتفويض",
            "تنفيذ هياكل الصلاحيات المحددة في الميثاق",
            "وضع عملية لمراجعة وتحديث الميثاق"
          ],
          templates: ["تفويض مكتب إدارة المشاريع المعتمد", "ميثاق مكتب إدارة المشاريع النهائي"]
        },
        "2-output-2": {
          stage: "الإخراج",
          title: "تنفيذ إطار الحوكمة",
          description: "تأسيس وتفعيل إطار الحوكمة مع هيئات اتخاذ القرار والعمليات وآليات الإشراف.",
          bestPractices: [
            "تشكيل لجان الحوكمة مع مواثيق واضحة",
            "تنفيذ عمليات وسلطات اتخاذ القرار",
            "تحديد وتيرة اجتماعات الحوكمة وجدول الأعمال",
            "إنشاء نظام لتوثيق الحوكمة والتقارير"
          ],
          templates: ["ميثاق لجنة الحوكمة", "مصفوفة سلطات اتخاذ القرار"]
        },
        "2-output-3": {
          stage: "الإخراج",
          title: "تطوير خطة الاتصال الاستراتيجية",
          description: "تنفيذ استراتيجية اتصال شاملة برسائل مخصصة لأصحاب المصلحة وآليات للتغذية الراجعة.",
          bestPractices: [
            "إنشاء مواد اتصال مخصصة لكل فئة من أصحاب المصلحة",
            "تحديد وتيرة اتصال منتظمة",
            "تنفيذ آليات لجمع التغذية الراجعة",
            "تطوير مؤشرات لقياس فعالية الاتصال"
          ],
          templates: ["خطة الاتصال الاستراتيجية", "مصفوفة رسائل أصحاب المصلحة"]
        }
      }
    },
    "3": {
      name: "هيكل وتصميم مكتب إدارة المشاريع",
      description: "إنشاء الهيكل الأمثل لمكتب إدارة المشاريع لتلبية احتياجات المؤسسة.",
      tasks: {
        "3-input-1": {
          stage: "الإدخال",
          title: "جمع بيانات العملاء",
          description: "جمع بيانات عن العملاء المحتملين لمكتب إدارة المشاريع، واحتياجاتهم وتوقعاتهم من خلال الاستبيانات والمقابلات.",
          bestPractices: [
            "إجراء استبيانات تقييم احتياجات العملاء",
            "جمع بيانات مقابلات أصحاب المصلحة",
            "توثيق نقاط الألم وتوقعات العملاء",
            "جمع معلومات حول أولويات الخدمات"
          ]
        },
        "3-input-2": {
          stage: "الإدخال",
          title: "جمع بيانات متطلبات الخدمة",
          description: "جمع متطلبات مفصلة للخدمات المحتملة لمكتب إدارة المشاريع من خلال ورش العمل وجلسات تحديد المتطلبات.",
          bestPractices: [
            "تنظيم ورش عمل لتحديد متطلبات الخدمات",
            "توثيق توقعات مستويات الخدمة",
            "جمع معايير ترتيب أولويات الخدمة",
            "جمع بيانات مرجعية عن خدمات مماثلة"
          ],
          templates: ["نموذج متطلبات الخدمة", "تقييم احتياجات العملاء"]
        },
        "3-input-3": {
          stage: "الإدخال",
          title: "تقييم فجوات القدرات",
          description: "جمع بيانات عن القدرات الحالية والفجوات من خلال أدوات التقييم وملاحظات أصحاب المصلحة.",
          bestPractices: [
            "استخدام أدوات تقييم نضج القدرات",
            "جمع بيانات مرجعية عن القدرات",
            "توثيق معايير ترتيب أولويات القدرات",
            "جمع معلومات عن توفر الموارد"
          ]
        },
        "3-processing-1": {
          stage: "المعالجة",
          title: "تطبيق تقنيات تطوير الشخصيات (Personas)",
          description: "استخدام منهجيات تطوير الشخصيات لإنشاء شخصيات عملاء مفصلة تشمل الاحتياجات والتوقعات.",
          bestPractices: [
            "تطبيق تقنيات تقسيم العملاء إلى شرائح",
            "استخدام أطر تطوير الشخصيات",
            "تطبيق منهجيات تحليل الاحتياجات",
            "استخدام تقنيات رسم خرائط رحلات العميل"
          ]
        },
        "3-processing-2": {
          stage: "المعالجة",
          title: "تطبيق أطر تحديد الأولويات",
          description: "استخدام تقنيات تحديد الأولويات لتطوير إطار يعالج احتياجات العملاء بشكل منهجي.",
          bestPractices: [
            "تطبيق مصفوفة القيمة مقابل الجهد",
            "استخدام تقنية MoSCoW لتحديد الأولويات",
            "تطبيق منهجيات التقييم بالنقاط المرجحة",
            "استخدام تقنيات رسم خرائط التأثير"
          ]
        },
        "3-processing-3": {
          stage: "المعالجة",
          title: "تطبيق منهجية تصميم كتالوج الخدمة",
          description: "استخدام تقنيات تصميم كتالوج الخدمة لتطوير عروض شاملة تشمل المزايا والقيم المضافة.",
          bestPractices: [
            "تطبيق أطر تعريف الخدمة",
            "استخدام تقنيات تحديد مستويات الخدمة",
            "تطبيق منهجيات تطوير القيمة المقترحة",
            "استخدام تقنيات تصنيف الخدمات"
          ],
          templates: ["نموذج كتالوج الخدمة", "نموذج اتفاقية مستوى الخدمة"]
        },
        "3-output-1": {
          stage: "الإخراج",
          title: "تسليم شخصيات العملاء ورحلاتهم",
          description: "إنشاء وتوزيع شخصيات العملاء التفصيلية ورحلاتهم لتوجيه تصميم وتقديم الخدمات.",
          bestPractices: [
            "توثيق شخصيات شاملة مع الاحتياجات ونقاط الألم",
            "إنشاء خرائط مرئية لرحلات العميل في التفاعلات الرئيسية",
            "توزيع الشخصيات على جميع فرق تقديم الخدمة",
            "إرساء عملية لتحديث وتحسين الشخصيات"
          ],
          templates: ["نموذج شخصية العميل", "نموذج خريطة الرحلة"]
        },
        "3-output-2": {
          stage: "الإخراج",
          title: "تنفيذ كتالوج الخدمة واتفاقيات مستويات الخدمة",
          description: "إطلاق كتالوج شامل للخدمة يتضمن اتفاقيات مستوى الخدمة والعمليات والمعايير.",
          bestPractices: [
            "إنشاء أوصاف تفصيلية للخدمة مع قيم مقترحة",
            "تحديد مؤشرات وأهداف مستويات الخدمة",
            "تنفيذ عمليات تقديم وطلب الخدمة",
            "إنشاء آلية لمراجعة وتحديث كتالوج الخدمة"
          ],
          templates: ["وثيقة كتالوج الخدمة", "توثيق SLA"]
        },
        "3-output-3": {
          stage: "الإخراج",
          title: "إرساء إطار تحديد أولويات الخدمة",
          description: "تنفيذ نهج منهجي لتحديد أولويات ومعالجة احتياجات العملاء وطلبات الخدمة.",
          bestPractices: [
            "إنشاء معايير ونظام تقييم لتحديد الأولويات",
            "تنفيذ عملية استقبال وتقييم الطلبات",
            "تحديد توزيع الموارد بناءً على الأولويات",
            "تطوير آليات لمراجعة وتعديل الأولويات"
          ],
          templates: ["مصفوفة تحديد الأولويات", "نموذج طلب الخدمة"]
        }
      }
    },
    "4": {
      name: "التميز التشغيلي",
      description: "ضمان عمليات وأدوات إدارة المشاريع الفعالة والناجحة.",
      tasks: {
        "4-input-1": {
          stage: "الإدخال",
          title: "جمع متطلبات التأهيل (Onboarding)",
          description: "جمع المتطلبات والتوقعات الخاصة بعملية تأهيل العملاء من خلال مدخلات أصحاب المصلحة.",
          bestPractices: [
            "إجراء تقييم لاحتياجات التأهيل",
            "جمع توقعات أصحاب المصلحة لعملية التأهيل",
            "توثيق التحديات الحالية في التأهيل",
            "جمع أفضل الممارسات في مجال التأهيل"
          ]
        },
        "4-input-2": {
          stage: "الإدخال",
          title: "جمع متطلبات التوثيق",
          description: "جمع متطلبات توثيق العمليات وأدلة المستخدم ومواد التدريب.",
          bestPractices: [
            "إجراء تقييم لاحتياجات التوثيق",
            "جمع تفضيلات المستخدمين لصيغ التوثيق",
            "توثيق الفجوات الحالية في التوثيق",
            "جمع أفضل ممارسات التوثيق"
          ],
          templates: ["نموذج متطلبات التوثيق", "مخطط دليل المستخدم"]
        },
        "4-input-3": {
          stage: "الإدخال",
          title: "تقييم احتياجات التدريب",
          description: "جمع بيانات حول احتياجات التدريب وتفضيلات طرق تقديمه من خلال الاستبيانات والمقابلات.",
          bestPractices: [
            "إجراء تقييم لاحتياجات التدريب",
            "جمع تفضيلات أساليب التعلم",
            "توثيق فجوات المعرفة والمهارات",
            "جمع معايير فعالية التدريب"
          ]
        },
        "4-processing-1": {
          stage: "المعالجة",
          title: "تطبيق تقنيات إدارة الجودة",
          description: "استخدام منهجيات إدارة الجودة لتطوير إجراءات الرقابة والتحسين المستمر.",
          bestPractices: [
            "تطبيق تقنيات تطوير معايير الجودة",
            "استخدام أساليب تصميم نقاط الرقابة",
            "تطبيق أطر تطوير مؤشرات الجودة",
            "استخدام منهجيات التحسين المستمر"
          ]
        },
        "4-processing-2": {
          stage: "المعالجة",
          title: "تطبيق منهجيات إدارة الموارد",
          description: "استخدام تقنيات إدارة الموارد لتطوير أنظمة التخصيص وخطط القدرة الاستيعابية.",
          bestPractices: [
            "تطبيق تقنيات تخطيط سعة الموارد",
            "استخدام أساليب تحديد أولويات تخصيص الموارد",
            "تطبيق منهجيات التنبؤ بالموارد",
            "استخدام تقنيات تحسين استخدام الموارد"
          ],
          templates: ["خطة إدارة الموارد", "نموذج تخطيط السعة"]
        },
        "4-processing-3": {
          stage: "المعالجة",
          title: "تطبيق إطار إدارة المشكلات",
          description: "استخدام منهجيات إدارة المشكلات لتطوير إجراءات التصعيد وآليات الحل.",
          bestPractices: [
            "تطبيق تقنيات تعريف حدود التصعيد",
            "استخدام أساليب تصميم مسارات التصعيد",
            "تطبيق أطر تصنيف المشكلات",
            "استخدام تقنيات تحديد معايير أوقات الحل"
          ],
          templates: ["نموذج إجراء التصعيد", "إطار إدارة المشكلات"]
        },
        "4-output-1": {
          stage: "الإخراج",
          title: "تنفيذ نظام إدارة الجودة",
          description: "إنشاء نظام شامل لإدارة الجودة يتضمن المعايير، عمليات الرقابة، وآليات التحسين.",
          bestPractices: [
            "توثيق معايير الجودة لجميع الخدمات",
            "تنفيذ نقاط رقابة ومراجعة الجودة",
            "إنشاء نظام لجمع وتقديم تقارير مؤشرات الجودة",
            "إنشاء عملية تحسين جودة مستمرة"
          ],
          templates: ["وثيقة معايير الجودة", "قائمة مراجعة الجودة"]
        },
        "4-output-2": {
          stage: "الإخراج",
          title: "إنشاء نظام إدارة الموارد",
          description: "تنفيذ نظام لإدارة الموارد يشمل تخطيط السعة، عمليات التخصيص، وتتبع الاستخدام.",
          bestPractices: [
            "إنشاء جرد الموارد ومصفوفة المهارات",
            "تنفيذ عمليات تخطيط وتوقع السعة",
            "إرساء إجراءات تخصيص وتوزيع الموارد",
            "تطوير نظام تتبع وتقرير استخدام الموارد"
          ],
          templates: ["مصفوفة تخصيص الموارد", "لوحة تخطيط السعة"]
        },
        "4-output-3": {
          stage: "الإخراج",
          title: "نشر نظام إدارة المشكلات",
          description: "تنفيذ نظام شامل لإدارة المشكلات يشمل إجراءات التصعيد، التتبع، وآليات الحل.",
          bestPractices: [
            "إنشاء عملية استقبال وتصنيف المشكلات",
            "تنفيذ مسارات التصعيد ونظام الإشعارات",
            "إنشاء نظام تتبع المشكلات وتقرير الحالة",
            "تطوير إجراءات التحقق من الحل والإغلاق"
          ],
          templates: ["دليل إدارة المشكلات", "مصفوفة التصعيد"]
        }
      }
    },
    "5": {
      name: "الأداء والتحسين",
      description: "تحسين خدمات مكتب إدارة المشاريع وقدراته وتقديم القيمة بشكل مستمر.",
      tasks: {
        "5-input-1": {
          stage: "الإدخال",
          title: "جمع بيانات تقييم النضج",
          description: "جمع بيانات حول نضج مكتب إدارة المشاريع الحالي باستخدام أدوات التقييم، الاستبيانات، ومدخلات أصحاب المصلحة.",
          bestPractices: [
            "اختيار أداة تقييم النضج المناسبة",
            "جمع بيانات تقييم شاملة",
            "توثيق خط الأساس للنضج عبر الأبعاد المختلفة",
            "جمع معلومات حول أهداف النضج المستقبلية"
          ]
        },
        "5-input-2": {
          stage: "الإدخال",
          title: "جمع بيانات الأداء",
          description: "جمع مؤشرات الأداء الحالية، الاتجاهات التاريخية، والأهداف الخاصة بالأداء.",
          bestPractices: [
            "جمع مؤشرات الأداء الحالية",
            "جمع بيانات الأداء التاريخية",
            "توثيق الأهداف والحدود الخاصة بالأداء",
            "جمع معلومات معيارية حول الأداء"
          ]
        },
        "5-input-3": {
          stage: "الإدخال",
          title: "تقييم أساليب قياس القيمة",
          description: "جمع بيانات حول مؤشرات القيمة المحتملة، أساليب القياس، وطرق توضيح القيمة.",
          bestPractices: [
            "جمع خيارات مؤشرات القيمة",
            "جمع منهجيات قياس القيمة",
            "توثيق تصور أصحاب المصلحة للقيمة",
            "تقييم الأساليب الحالية لتوضيح القيمة"
          ]
        },
        "5-processing-1": {
          stage: "المعالجة",
          title: "تطبيق تقنيات تخطيط خارطة طريق النضج",
          description: "استخدام منهجيات تخطيط خارطة طريق النضج لتطوير خطة تحسين تحتوي على مراحل ومعايير قياس.",
          bestPractices: [
            "تطبيق تقنيات تحليل فجوات النضج",
            "استخدام طرق تحديد أولويات القدرات",
            "تطبيق أطر تطوير مراحل التحسين",
            "استخدام تقنيات تحديد المقاييس والمعايير"
          ]
        },
        "5-processing-2": {
          stage: "المعالجة",
          title: "تطبيق منهجيات إدارة التغيير",
          description: "استخدام تقنيات إدارة التغيير لتطوير نهج تنفيذ لمبادرات النضج.",
          bestPractices: [
            "تطبيق تقنيات تحليل تأثير أصحاب المصلحة",
            "استخدام أساليب إدارة المقاومة",
            "تطبيق أطر تخطيط الاتصال",
            "استخدام تقنيات قياس التبني"
          ],
          templates: ["خطة إدارة التغيير", "خطة إشراك أصحاب المصلحة"]
        },
        "5-processing-3": {
          stage: "المعالجة",
          title: "تطبيق أطر التحسين المستمر",
          description: "استخدام منهجيات التحسين المستمر لتطوير عمليات تحسين منظمة ومنهجية.",
          bestPractices: [
            "تطبيق تقنيات تحديد فرص التحسين",
            "استخدام أساليب تحديد أولويات التحسين",
            "تطبيق أطر تخطيط التنفيذ",
            "استخدام تقنيات قياس فعالية التحسين"
          ]
        },
        "5-output-1": {
          stage: "الإخراج",
          title: "تنفيذ خارطة طريق تحسين النضج",
          description: "إنشاء وتنفيذ خارطة طريق شاملة لتحسين النضج تتضمن مراحل ومعايير مراجعة ومتابعة.",
          bestPractices: [
            "توثيق خطة تحسين النضج بشكل مفصل",
            "تنفيذ تتبع ومراقبة مراحل التحسين",
            "إرساء عملية جمع وتحليل مؤشرات النضج",
            "إنشاء عملية مراجعة وتعديل دوري للنضج"
          ],
          templates: ["خارطة طريق تحسين النضج", "لوحة مؤشرات النضج"]
        },
        "5-output-2": {
          stage: "الإخراج",
          title: "إنشاء نظام قياس القيمة",
          description: "تنفيذ نظام شامل لقياس القيمة يتضمن مؤشرات، تقارير، وآليات لتوضيح القيمة.",
          bestPractices: [
            "تحديد وتنفيذ مؤشرات القيمة ومؤشرات الأداء الرئيسية",
            "إنشاء عملية جمع وتحليل بيانات القيمة",
            "إرساء آلية إعداد تقارير القيمة وتصورها",
            "تطوير دراسات حالة لتوضيح القيمة"
          ],
          templates: ["إطار قياس القيمة", "لوحة عرض القيمة"]
        },
        "5-output-3": {
          stage: "الإخراج",
          title: "تطبيق برنامج التحسين المستمر",
          description: "تنفيذ برنامج تحسيني منهجي يتضمن تحديد، وتقييم، وتنفيذ فرص التحسين.",
          bestPractices: [
            "إنشاء عملية تحديد فرص التحسين",
            "إنشاء نظام لتحديد واختيار أولويات التحسين",
            "تنفيذ نظام تتبع وتحليل تحسينات الأداء",
            "تطوير عملية قياس فعالية التحسين"
          ],
          templates: ["دليل التحسين المستمر", "نظام تتبع التحسين"]
        }
      }
    },
    "6": {
      name: "تطوير القدرات",
      description: "تطوير وإدارة الجوانب البشرية لمكتب إدارة المشاريع بما في ذلك الكفاءة والتدريب والقيادة.",
      tasks: {
        "6-input-1": {
          stage: "الإدخال",
          title: "جمع بيانات اتخاذ القرار",
          description: "جمع بيانات حول عمليات اتخاذ القرار الحالية، استخدام البيانات، وفرص التحسين.",
          bestPractices: [
            "توثيق عمليات اتخاذ القرار الحالية",
            "تقييم استخدام البيانات في اتخاذ القرار",
            "تحديد اختناقات اتخاذ القرار",
            "جمع مقاييس جودة القرارات"
          ]
        },
        "6-input-2": {
          stage: "الإدخال",
          title: "تقييم متطلبات الكفاءات",
          description: "جمع بيانات حول الكفاءات المطلوبة، القدرات الحالية، واحتياجات التطوير.",
          bestPractices: [
            "توثيق متطلبات الكفاءات الخاصة بكل دور",
            "تقييم مستويات الكفاءة الحالية",
            "تحديد الفجوات الحرجة في الكفاءات",
            "جمع معلومات تفضيلات التطوير"
          ],
          templates: ["نموذج تقييم الكفاءات", "تحليل احتياجات التطوير"]
        },
        "6-input-3": {
          stage: "الإدخال",
          title: "جمع بيانات تقييم المهارات",
          description: "جمع بيانات شاملة عن المهارات من خلال التقييمات، التقييمات الذاتية، وتعليقات المديرين.",
          bestPractices: [
            "استخدام أدوات تقييم المهارات المعيارية",
            "جمع بيانات التقييم الذاتي",
            "جمع مدخلات تقييم المديرين",
            "توثيق معايير تحديد أولويات المهارات"
          ]
        },
        "6-processing-1": {
          stage: "المعالجة",
          title: "تطبيق منهجية تصميم برامج التدريب",
          description: "استخدام تقنيات تصميم التدريب لتطوير برامج تدريب وشهادات شاملة.",
          bestPractices: [
            "تطبيق تقنيات تطوير الأهداف التعليمية",
            "استخدام منهجيات تصميم المناهج",
            "تطبيق أطر اختيار أساليب التعلم",
            "استخدام تصميم قياس فعالية التدريب"
          ]
        },
        "6-processing-2": {
          stage: "المعالجة",
          title: "تطبيق تطوير أطر الابتكار",
          description: "استخدام تقنيات أطر الابتكار لتطوير عمليات لتعزيز الابتكار وحل المشكلات.",
          bestPractices: [
            "تطبيق منهجيات تصميم عمليات الابتكار",
            "استخدام تقنيات اختيار توليد الأفكار",
            "تطبيق أطر تقييم الأفكار",
            "تصميم نظام حوافز للابتكار"
          ]
        },
        "6-processing-3": {
          stage: "المعالجة",
          title: "تطبيق تقنيات إدارة المعرفة",
          description: "استخدام منهجيات إدارة المعرفة لتصميم منصة مشاركة المعرفة ومجتمعات الممارسة.",
          bestPractices: [
            "تطبيق تقنيات تصميم مستودع المعرفة",
            "استخدام أطر تصنيف المعرفة",
            "تطبيق منهجيات تصميم مجتمعات الممارسة",
            "تصميم نظام حوافز للمساهمة بالمعرفة"
          ]
        },
        "6-output-1": {
          stage: "الإخراج",
          title: "تنفيذ إطار تطوير الكفاءات",
          description: "إرساء إطار شامل للكفاءات يتضمن التقييم، مسارات التطوير، وبرامج الشهادات.",
          bestPractices: [
            "توثيق متطلبات الكفاءات الخاصة بالأدوار",
            "إنشاء نظام تقييم وتتبع الكفاءات",
            "تنفيذ مسارات تطوير لكل مجال كفاءة",
            "إرساء برنامج شهادات وتقدير"
          ],
          templates: ["وثيقة إطار الكفاءات", "دليل مسارات التطوير"]
        },
        "6-output-2": {
          stage: "الإخراج",
          title: "نشر نظام الابتكار وحل المشكلات",
          description: "تنفيذ برنامج ابتكار منظم يشمل توليد الأفكار، التقييم، والتنفيذ.",
          bestPractices: [
            "إنشاء نظام لجمع وتوليد الأفكار",
            "إنشاء عملية تقييم واختيار الأفكار",
            "تنفيذ دعم لتنفيذ الابتكارات",
            "تطوير نظام حوافز وتقدير للابتكار"
          ],
          templates: ["دليل عملية الابتكار", "مصفوفة تقييم الأفكار"]
        },
        "6-output-3": {
          stage: "الإخراج",
          title: "إنشاء نظام إدارة المعرفة",
          description: "تنفيذ نظام شامل لإدارة المعرفة يشمل مستودع، آليات مشاركة، ومجتمعات ممارسة.",
          bestPractices: [
            "إنشاء مستودع معرفة بنظام تصنيف",
            "إرساء عمليات المساهمة بالمعرفة",
            "تشكيل مجتمعات ممارسة بمواثيق واضحة",
            "تنفيذ فعاليات وأنشطة لمشاركة المعرفة"
          ],
          templates: ["دليل إدارة المعرفة", "ميثاق مجتمع الممارسة"]
        }
      }
    }
  },

  // Resources page
  resources: {
    search: "بحث",
    title: "مكتبة أفضل الممارسات",
    subtitle: "تصفح الموارد والقوالب وأفضل الممارسات لتنفيذ مكتب إدارة المشاريع الخاص بك",
    searchPlaceholder: "البحث عن أفضل الممارسات والقوالب والأدلة...",
    noDocumentsFound: "لا توجد مستندات",
    noDocumentsMessage: "لا توجد مستندات لديك حتى الآن. قم بإكمال المهام لإنشاء المستندات.",
    noDocumentsDescription: "لا توجد مستندات تطابق معايير البحث الحالية. حاول تعديل معايير البحث.",
    clearFilters: "مسح الفلاتر",
    categories: "الفئات",
    documentTypes: "أنواع المستندات",
    tags: "العلامات",
    allResources: "جميع الموارد",
    featured: "مميز",
    templates: "القوالب",
    recentlyAdded: "أضيف مؤخرًا",
    document: "مستند",
    documentDocx: "مستند.docx",
    documents: "مستندات",
    page: "صفحة",
    preview: "معاينة",
    hidePreview: "إخفاء المعاينة",
    viewFullDocument: "عرض المستند كاملاً",
    exportPdf: "تصدير PDF",
    updated: "تم التحديث",
    views: "مشاهدات",
    relatedResources: "موارد ذات صلة",
    viewDocument: "عرض المستند",
    featuredResources: "موارد مميزة",
    viewAll: "عرض الكل",
    externalResources: "موارد خارجية لمكتب إدارة المشاريع",
    externalResourcesDesc: "الوصول إلى موارد إضافية من مصادر موثوقة في الصناعة لتكملة رحلة تنفيذ مكتب إدارة المشاريع الخاص بك.",
    browseExternalResources: "تصفح الموارد الخارجية",
    previous: "السابق",
    next: "التالي",
    backToResources: "العودة إلى الموارد",
    downloadAsPdf: "تنزيل كـ PDF",
    generatingPdf: "جاري إنشاء PDF...",
    manageResources: "إدارة الموارد",
    resourcesLibrary: "مكتبة الموارد",
    browseBestPractices: "تصفح أفضل الممارسات",
    relatedDocuments: "مستندات ذات صلة",
    relatedDocument: "مستند ذات صلة",
    sampleRelatedDocumentDescription: "وصف مستند ذات صلة عيني",
    loadingResources: "جاري تحميل الموارد...",    
    errorLoadingDocuments: "خطأ في تحميل المستندات",
    tryAgain: "حاول مرة أخرى",
    searchDocuments: "البحث في المستندات...",
    filters: "المرشحات",
    noMatchingDocuments: "لا توجد مستندات مطابقة",
    tryAdjustingFilters: "لا توجد مستندات تطابق المرشحات الحالية. حاول تعديل البحث أو المرشحات.",
    download: "تنزيل",
    source: "المصدر",
    created: "تم الإنشاء",
    domainOutput: "مخرجات المجال",
    taskAttachment: "مرفق المهمة",
    unknownSource: "مصدر غير معروف",
    unknown: "غير معروف",
    unknownTask: "مهمة غير معروفة",
    unknownDate: "تاريخ غير معروف",
    invalidDate: "تاريخ غير صالح",
    docxExtension: ".docx",
    downloadInitiated: "بدأ التنزيل",
    failedToLoadDocuments: "فشل في تحميل المستندات. الرجاء المحاولة مرة أخرى.",
    failedToDownloadDocument: "فشل في تنزيل المستند",
    errorFetchingDocuments: "خطأ في جلب المستندات:",
    errorDownloadingDocument: "خطأ في تنزيل المستند:",
    filteredInvalidDocuments: "تمت تصفية {count} من إدخالات المستندات غير الصالحة",
  },

  // Export PDF
  export: {
    generatedOn: "تم الإنشاء في",
    page: "صفحة",
    tableOfContents: "جدول المحتويات",
    copyright: "© بناء مكتب إدارة المشاريع باستخدام الذكاء الاصطناعي"
  },

  // Tasks
  tasks: {
    tasks: "المهام",
    manageAndTrackYourPmoImplementationTasks: "إدارة وتتبع مهام تنفيذ مكتب إدارة المشاريع",
    allTasks: "جميع المهام",
    completed: "مكتملة",
    incomplete: "غير مكتملة",
    total: "المجموع",
    progress: "التقدم",
    rate: "التقييم",
    addCustomTask: "إضافة مهمة خاصة",
    searchTasks: "بحث عن مهام...",
    filters: "الفلاتر",
    clear: "مسح",
    allDomains: "جميع المجالات",
    allStages: "جميع المراحل",
    input: "إدخال",
    processing: "المعالجة",
    output: "الإخراج",
    domain: "المجال",
    stage: "المرحلة",
    status: "الحالة",
    clearFilters: "مسح الفلاتر",
    noTasksFound: "لا توجد مهام",
    noTasksMatchFilters: "لا توجد مهام تطابق المعايير الحالية. حاول إعادة الفلاتر أو مسحها.",
    noTasksAvailable: "لا توجد مهام متاحة. أضف مهمة جديدة.",
    taskManagementTips: "نصائح في إدارة المهام",
    taskManagementTipsDescription: "قم بترتيب المهام بناءً على مستوى نضج مكتب إدارة المشاريع الخاص بك والأهداف التنظيمية. قم بإكمال مهام المرحلة الأولى (الإدخال) أولاً قبل الانتقال إلى المرحلة الثانية (المعالجة) والمرحلة الثالثة (الإخراج) للحصول على أفضل النتائج.",
    viewBestPractices: "عرض أفضل الممارسات",
    relatedDocuments: "مستندات ذات صلة",
    viewFullContent: "عرض المحتوى كاملاً",
    generateTaskOutput: "إنشاء إخراج المهام",
    templates: "القوالب",
    templateForStandardizedImplementation: "قالب لتنفيذ معياري",
    viewTemplate: "عرض القالب",
    bestPractices: "أفضل الممارسات",
    priority: "الأولوية",
    targetCompletionDate: "تاريخ الانتهاء المستهدف",
    assignedTo: "معين إلى",
    estimatedHours: "ساعات مقدرة",
    attachments: "الملفات المرفقة",
    notes: "ملاحظات",
    saving: "جاري الحفظ...",
    saveChanges: "حفظ التغييرات",
    completion: "الانتهاء",
    completionToggle: "تحويل الانتهاء",
    completionToggleDescription: "تحويل المهام المكتملة إلى غير مكتملة",
    addNotes: "إضافة ملاحظات حول هذه المهمة...",
    addTask: "إضافة مهمة",
    taskName: "اسم المهمة",
    taskNamePlaceholder: "أدخل اسم المهمة",
    taskDescription: "وصف المهمة",
    taskDescriptionPlaceholder: "أدخل وصف المهمة",
    low: "منخفض",
    medium: "متوسط",
    high: "عالي",
    addAttachment: "إضافة ملف مرفق",
    addAttachmentDescription: "أضف ملفات مرفقة لتسهيل التعامل مع المهمة",
    addAttachmentPlaceholder: "اختر ملفًا مرفقًا",
    enterNameOrEmail: "أدخل الاسم أو البريد الإلكتروني",
    enterEstimatedHours: "أدخل ساعات مقدرة",
    enterTargetCompletionDate: "أدخل تاريخ الانتهاء المستهدف",
    enterAssignedTo: "أدخل المعين إلى",
    enterTaskDescription: "أدخل وصف المهمة",
    enterTaskName: "أدخل اسم المهمة",
    markAsCompleted: "تحديد المهمة كمكتملة",
    attachmentsDescription: "أضف ملفات مرفقة لتسهيل التعامل مع المهمة",
    attachmentsPlaceholder: "اختر ملفًا مرفقًا",
    dragAndDropFilesHere: "قم بإسقاط الملفات هنا أو انقر لتحديد الملفات",
    supportedFormats: "التنسيقات المدعومة: الصور والمستندات والجداول والمزيد (الحد الأقصى 10MB)",
    uploading: "جاري الرفع...",
    workingInOfflineMode: "العمل في وضع عدم الاتصال",
    filesWillBeStoredLocallyUntilYourConnectionIsRestored: "سيتم تخزين الملفات بشكل محلي حتى يتم استرجاع الاتصال",
    noAttachmentsAddedYet: "لا يوجد ملفات مرفقة بعد",
    close: "إغلاق",
    taskOutputGenerator: "مولد إخراج المهام",
    generateComprehensiveOutputDeliverableForThisTaskBasedOnBestPracticesDomainContextAndYourOrganizationDocuments: "إنشاء إخراج مكتمل لهذه المهمة بناءً على أفضل الممارسات والسياق المجالي والمستندات الخاصة بك",
    ourAIWillAnalyzeYourTaskRequirementsAndContextToCreateAPersonalizedComprehensiveDeliverableForThisSpecificTask: "ستقوم الذكاء الاصطناعي بتحليل متطلبات المهمة والسياق وإنشاء إخراج مكتمل ومخصص لهذه المهمة",
    creatingPersonalizedPromptForThisTask: "إنشاء تحفيز مخصص لهذه المهمة...",
    creatingPrompt: "إنشاء تحفيز...",
    viewTaskPrompt: "عرض تحفيز المهمة",
    savedTaskOutput: "إخراج المهمة المحفوظ",
    regenerate: "إعادة إنشاء",
    exportPDF: "تصدير PDF",
    visualizingProcessMap: "عرض الخريطة العملية",
    generatedTaskOutput: "إخراج المهمة المولد",
    saved: "محفوظ",
    save: "حفظ",
    exporting: "جاري التصدير...",
    aboutTaskSpecificGeneration: "حول إنشاء إخراج مهمة خاصة", 
    thisFeatureCreatesPersonalizedContentTailoredToThisSpecificTaskUsing: "ينشئ هذا الميزة تحت المحتوى المخصص لهذه المهمة باستخدام:",
    aiGeneratedTaskSpecificPrompts: "تحفيزات مولدة من الذكاء الاصطناعي لهذه المهمة",
    externalKnowledgeSourcesForValidationAndEnrichment: "مصادر المعرفة الخارجية للتحقق والتعزيز",
    domainContextAndRelatedDocuments: "السياق المجالي والمستندات المتعلقة",
    taskDetailsAndBestPractices: "تفاصيل المهمة وأفضل الممارسات",    
    generatePersonalizedOutput: "إنشاء إخراج مخصص",
    generating: "جاري الإنشاء...",
    generatingPersonalizedOutput: "جاري إنشاء إخراج مخصص...",
    generatingPersonalizedOutputDescription: "ستقوم الذكاء الاصطناعي بتحليل متطلبات المهمة والسياق وإنشاء إخراج مكتمل ومخصص لهذه المهمة",
    editTask: "تعديل المهمة",
    inProgress: "قيد التنفيذ",
    availableTemplates: "القوالب المتاحة",
    purpose: "الغرض",
    templateForStandardized: "يوفر هذا القالب إطارًا منظمًا لتنفيذ وإدارة",
    withinYourPMO: "العمليات داخل مكتب إدارة المشاريع الخاص بك",
    overview: "الملخص",
    download: "تحميل",
    useTemplate: "استخدام القالب",
    template: `
    ## أقسام النموذج

### 1. المقدمة
- الغرض والأهداف
- النطاق وإمكانية التطبيق
- أصحاب المصلحة الرئيسيون

### 2. إطار العمل
- نظرة عامة على المنهجية
- الأنشطة الرئيسية والمخرجات
- الأدوار والمسؤوليات

### 3. دليل التنفيذ
- تعليمات خطوة بخطوة
- أفضل الممارسات والإرشادات
- التحديات والحلول الشائعة

### 4. المراقبة والتحكم
- مؤشرات الأداء الرئيسية
- تدابير ضمان الجودة
- متطلبات إعداد التقارير

### 5. التحسين المستمر
- آليات التغذية الراجعة
- عملية المراجعة
- إجراءات التحديث

## الملاحق
- النماذج والأدوات ذات الصلة
- المواد المرجعية
- مسرد المصطلحات

---

*هذا النموذج جزء من مكتبة مكتب إدارة المشاريع. خصّصه ليناسب احتياجات مؤسستك الخاصة.*
    `
  },

  // Document Processor
  documentProcessor: {
    title: "معالجة المستندات",
    supportedFormats: "التنسيقات المدعومة: .txt, .md, .html, .docx, .pdf",
    browseFiles: "تصفح الملفات",
    change: "تغيير",
    processing: "جاري المعالجة...",
    processDocument: "معالجة المستند",
    documentProcessedSuccessfully: "تم معالجة المستند بنجاح",
    documentSplitIntoChunksForOptimalAnalysis: "تم تقسيم المستند إلى {processedDoc.totalChunks} منطقة للتحليل الأمثل",
    documentAutomaticallyAddedToAnalysis: "تم إضافة المستند تلقائيًا إلى التحليل",
    itWillBeUsedToEnhanceAIResponsesInThisDomain: "سيتم استخدامه لتعزيز الاستجابات الذكية في هذا المجال",
    limitedFunctionalityInOfflineMode: "الوظيفة مقتصرة على الاتصال",
    documentProcessingMayBeLimitedWhileWorkingOffline: "قد يتم تقييد المعالجة المستندات أثناء العمل عديم الاتصال",
    dragAndDropYourDocumentHereOrClickToBrowse: "قم بإسقاط المستند هنا أو انقر لتحديد المستند",
    availableInAnalysis: "متاح في التحليل",
    recentlyProcessedDocuments: "المستندات المعالجة مؤخراً",
    recentlyProcessedDocumentsDescription: "المستندات التي تم معالجتها بنجاح مؤخراً والتي سيتم استخدامها في التحليل",
    whyProcessDocuments: "لماذا يجب معالجة المستندات؟",
    breakingDownLargeDocumentsAllowsAIToAnalyzeThemMoreEffectivelyAndReferenceSpecificSections: "تقسيم المستندات الكبيرة إلى أجزاء أصغر يساعد الذكاء الاصطناعي في تحليلها بشكل أكثر فعالية والرجوع إلى الأجزاء المعينة.",
    processedDocumentsAppearAutomaticallyInTheAnalysisTabAndEnhanceAIResponsesWithYourDomainSpecificContext: "يظهر المستندات المعالجة تلقائيًا في علامة التحليل ويعزز الاستجابات الذكية بالسياق المجالي الخاص بك.",
    useSampleData: "استخدام البيانات العينية",
    showSampleData: "إظهار البيانات العينية",
    hideSampleData: "إخفاء البيانات العينية",
    sampleInputData: "بيانات المدخلات العينية",
    showPreviousDomainOutput: "إظهار إخراج المجال السابق",
    hidePreviousDomainOutput: "إخفاء إخراج المجال السابق",
  }
  
};

export const translations: Record<string, any> = { en, ar };