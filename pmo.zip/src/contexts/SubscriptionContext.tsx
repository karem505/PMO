import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from '../components/auth/AuthContext';
import { SubscriptionTier, TIER_LIMITS } from '../services/subscriptionService';
import { subscriptionApi } from '../api/subscriptionApi';

type SubscriptionContextType = {
  tier: SubscriptionTier;
  isActive: boolean;
  isLoading: boolean;
  isFeatureAvailable: (feature: string) => boolean;
  isUsageLimitReached: (feature: string) => boolean;
  getUsage: (feature: string) => number;
  getLimitForFeature: (feature: string) => number | string;
  incrementUsage: (feature: string) => Promise<boolean>;
  shouldShowUpgradePrompt: (feature: string) => Promise<{show: boolean; reason?: string}>;
  upgradeUrl: (source: string, feature?: string) => string;
};

const SubscriptionContext = createContext<SubscriptionContextType | undefined>(undefined);

export const useSubscription = () => {
  const context = useContext(SubscriptionContext);
  if (context === undefined) {
    throw new Error('useSubscription must be used within a SubscriptionProvider');
  }
  return context;
};

export const SubscriptionProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useAuth();
  const [tier, setTier] = useState<SubscriptionTier>(SubscriptionTier.FREE);
  const [isActive, setIsActive] = useState<boolean>(true);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [subscription, setSubscription] = useState<any | null>(null);
  const [usage, setUsage] = useState<Record<string, number>>({});
  const [error, setError] = useState<string | null>(null);
  const [retryCount, setRetryCount] = useState<number>(0);
  const [MAX_RETRIES, setMAX_RETRIES] = useState<number>(3);
  const [RETRY_DELAY, setRETRY_DELAY] = useState<number>(5000);
  
  // Load subscription data
  const loadSubscription = async () => {
    if (!currentUser || isLoading) return;
    
    try {
      setIsLoading(true);
      setError(null);
      
      console.log('DEBUG: Loading subscription for user:', currentUser.id);
      
      // Try to get existing subscription
      const subscriptionData = await subscriptionApi.getUserSubscription(currentUser.id);
      
      console.log('DEBUG: Received subscription data:', subscriptionData);
        
      if (subscriptionData) {
        console.log('DEBUG: Setting subscription tier to:', subscriptionData.tier);
        setSubscription(subscriptionData);
        setTier(subscriptionData.tier);
        setIsActive(subscriptionData.status === 'active' || subscriptionData.status === 'trial');
        setRetryCount(0); // Reset retry count since we found a subscription
        return;
      }
      
      // Only try to initialize if:
      // 1. We don't have a subscription
      // 2. We haven't tried too many times
      // 3. We haven't already initialized one
      if (retryCount < MAX_RETRIES && !subscription) {
        try {
          console.log('DEBUG: Initializing new subscription');
          const newSubscription = await subscriptionApi.initializeUserSubscription(currentUser.id);
          if (newSubscription) {
            console.log('DEBUG: Setting new subscription tier to:', newSubscription.tier);
            setSubscription(newSubscription);
            setTier(newSubscription.tier);
            setIsActive(newSubscription.status === 'active' || newSubscription.status === 'trial');
            setRetryCount(0); // Reset retry count on success
          }
        } catch (initError) {
          console.error('Error initializing user subscription:', initError);
          setRetryCount(prev => prev + 1);
          setError('Failed to initialize subscription. Please try again later.');
        }
      } else if (!subscription) {
        setError('Unable to load subscription. Please try again later.');
      }
    } catch (error) {
      console.error('Error getting user subscription:', error);
      setError('Failed to load subscription. Please try again later.');
    } finally {
      setIsLoading(false);
    }
  };
  
  // Effect to load subscription when user changes
  useEffect(() => {
    if (currentUser && !isLoading && !subscription && retryCount < MAX_RETRIES) {
      loadSubscription();
    }
  }, [currentUser, isLoading, subscription, retryCount]);

  // Add a retry mechanism
  useEffect(() => {
    let retryTimeout: NodeJS.Timeout;
    
    if (error && retryCount < MAX_RETRIES) {
      retryTimeout = setTimeout(() => {
        setRetryCount(prev => prev + 1);
        loadSubscription();
      }, RETRY_DELAY);
    }
    
    return () => {
      if (retryTimeout) {
        clearTimeout(retryTimeout);
      }
    };
  }, [error, retryCount]);
  
  // Get usage for key features through API - only if we have a subscription
  useEffect(() => {
    if (subscription && currentUser) {
      const loadUsage = async () => {
        try {
          const [projectsUsage, aiAnalysisUsage, storageUsage] = await Promise.all([
            subscriptionApi.getFeatureUsage(currentUser.id, 'projects'),
            subscriptionApi.getFeatureUsage(currentUser.id, 'ai_analysis'),
            subscriptionApi.getFeatureUsage(currentUser.id, 'storage')
          ]);
          
          setUsage({
            projects: typeof projectsUsage === 'number' ? projectsUsage : 0,
            aiAnalysis: typeof aiAnalysisUsage === 'number' ? aiAnalysisUsage : 0,
            storage: typeof storageUsage === 'number' ? storageUsage : 0
          });
        } catch (error) {
          console.error('Error loading usage data:', error);
        }
      };
      
      loadUsage();
    }
  }, [currentUser, subscription]);
  
  // Check if a feature is available for the current subscription
  const isFeatureAvailable = (feature: string): boolean => {
    if (!isActive) return false;
    
    switch (feature) {
      case 'aiAnalysis':
      case 'projects':
      case 'templates':
      case 'users':
      case 'storage':
        // These features have usage limits rather than being simply available or not
        return true;
      case 'customDomains':
        return tier === SubscriptionTier.PREMIUM || tier === SubscriptionTier.ENTERPRISE;
      case 'prioritySupport':
        return tier === SubscriptionTier.PREMIUM || tier === SubscriptionTier.ENTERPRISE;
      case 'whiteLabeling':
        return tier === SubscriptionTier.ENTERPRISE;
      case 'apiAccess':
        return tier === SubscriptionTier.PREMIUM || tier === SubscriptionTier.ENTERPRISE;
      case 'teamCollaboration':
        return tier === SubscriptionTier.PREMIUM || tier === SubscriptionTier.ENTERPRISE;
      case 'advancedAnalytics':
        return tier === SubscriptionTier.ENTERPRISE;
      case 'sso':
        return tier === SubscriptionTier.ENTERPRISE;
      default:
        // Default to available
        return true;
    }
  };
  
  // Check if usage limit is reached for a specific feature
  const isUsageLimitReached = (feature: string): boolean => {
    if (!isActive) return true;
    
    const limit = TIER_LIMITS[tier][feature as keyof typeof TIER_LIMITS[typeof tier]];
    if (limit === 'unlimited') return false;
    
    const currentUsage = usage[feature] || 0;
    return currentUsage >= (limit as number);
  };
  
  // Get current usage for a feature
  const getUsage = (feature: string): number => {
    return usage[feature] || 0;
  };
  
  // Get limit for a feature
  const getLimitForFeature = (feature: string): number | string => {
    const limit = TIER_LIMITS[tier][feature as keyof typeof TIER_LIMITS[typeof tier]];
    return limit;
  };
  
  // Increment usage for a feature
  const incrementUsage = async (feature: string): Promise<boolean> => {
    if (!currentUser) return false;
    
    // Check if usage limit is reached
    if (isUsageLimitReached(feature)) return false;
    
    // Increment usage via API
    const success = await subscriptionApi.incrementUsage(currentUser.id, feature);
    
    // Update local usage state if successful
    if (success) {
      setUsage(prev => ({
        ...prev,
        [feature]: (prev[feature] || 0) + 1
      }));
    }
    
    return success;
  };
  
  // Check if upgrade prompt should be shown for a feature
  const shouldShowUpgradePrompt = async (feature: string): Promise<{show: boolean; reason?: string}> => {
    if (!currentUser) return { show: false };
    
    // Only show prompts for free/basic tiers
    if (tier !== SubscriptionTier.FREE && tier !== SubscriptionTier.PREMIUM) {
      return { show: false };
    }
    
    // Check if usage limit is reached
    if (isUsageLimitReached(feature)) {
      const reason = `You've reached the limit of ${getLimitForFeature(feature)} ${feature} on your current plan.`;
      return { show: true, reason };
    }
    
    // Check if close to limit (80%)
    const limit = getLimitForFeature(feature);
    if (typeof limit === 'number') {
      const currentUsage = usage[feature] || 0;
      if (currentUsage >= limit * 0.8) {
        const remaining = limit - currentUsage;
        const reason = `You're approaching your ${feature} limit. Only ${remaining} remaining on your current plan.`;
        return { show: true, reason };
      }
    }
    
    // Check for feature availability
    if (!isFeatureAvailable(feature)) {
      return { 
        show: true, 
        reason: `This feature is not available on your current plan. Upgrade to access ${feature}.`
      };
    }
    
    return { show: false };
  };
  
  // Generate upgrade URL with UTM parameters
  const upgradeUrl = (source: string, feature?: string): string => {
    let url = '/pricing?utm_source=app&utm_medium=upgrade_prompt';
    
    if (source) {
      url += `&utm_campaign=${encodeURIComponent(source)}`;
    }
    
    if (feature) {
      url += `&feature=${encodeURIComponent(feature)}`;
    }
    
    return url;
  };
  
  const value = {
    tier,
    isActive,
    isLoading,
    isFeatureAvailable,
    isUsageLimitReached,
    getUsage,
    getLimitForFeature,
    incrementUsage,
    shouldShowUpgradePrompt,
    upgradeUrl
  };
  
  return (
    <SubscriptionContext.Provider value={value}>
      {children}
    </SubscriptionContext.Provider>
  );
};