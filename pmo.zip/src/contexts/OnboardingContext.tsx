import React, { createContext, useState, useEffect, useContext } from 'react';
import { useAuth } from '../components/auth/AuthContext';

interface OnboardingContextType {
  isFirstLogin: boolean;
  setIsFirstLogin: React.Dispatch<React.SetStateAction<boolean>>;
  shouldShowTour: boolean;
  completeTour: () => void;
}

const defaultContext: OnboardingContextType = {
  isFirstLogin: false,
  setIsFirstLogin: () => {},
  shouldShowTour: false,
  completeTour: () => {},
};

const OnboardingContext = createContext<OnboardingContextType>(defaultContext);

export const useOnboarding = () => useContext(OnboardingContext);

export const OnboardingProvider: React.FC<{children: React.ReactNode}> = ({ children }) => {
  const { currentUser } = useAuth();
  const [isFirstLogin, setIsFirstLogin] = useState<boolean>(false);
  const [shouldShowTour, setShouldShowTour] = useState<boolean>(false);
  
  useEffect(() => {
    if (currentUser && currentUser.email) {
      // Check if user has completed the tour before
      const tourCompleted = localStorage.getItem(`onboardingTourCompleted_${currentUser.email}`);
      
      if (!tourCompleted) {
        // This is considered a first login (or first login after new tour feature)
        setIsFirstLogin(true);
        setShouldShowTour(true);
      }
    }
  }, [currentUser]);
  
  const completeTour = () => {
    if (currentUser && currentUser.email) {
      localStorage.setItem(`onboardingTourCompleted_${currentUser.email}`, 'true');
    }
    setShouldShowTour(false);
    setIsFirstLogin(false);
  };
  
  return (
    <OnboardingContext.Provider value={{
      isFirstLogin,
      setIsFirstLogin,
      shouldShowTour,
      completeTour,
    }}>
      {children}
    </OnboardingContext.Provider>
  );
};

export default OnboardingContext; 