import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';

// Add cookie support detection
const checkCookieSupport = () => {
  try {
    // Test if cookies are enabled
    document.cookie = 'testCookie=1';
    const cookiesEnabled = document.cookie.indexOf('testCookie=') !== -1;
    document.cookie = 'testCookie=1; expires=Thu, 01 Jan 1970 00:00:00 GMT';
    
    // Check if third-party cookies are blocked
    const isEdge = navigator.userAgent.includes('Edg/');
    const isThirdPartyBlocked = isEdge && !cookiesEnabled;
    
    if (isThirdPartyBlocked) {
      console.warn('Microsoft Edge is blocking third-party cookies. This may affect authentication.');
      return false;
    }
    
    return cookiesEnabled;
  } catch (error) {
    console.warn('Error checking cookie support:', error);
    return false;
  }
};

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  // ... existing code ...

  // Check for auth on mount
  useEffect(() => {
    const initializeAuth = async () => {
      try {
        // Check cookie support first
        const hasCookieSupport = checkCookieSupport();
        if (!hasCookieSupport) {
          setAuthError('Your browser is blocking cookies. Please enable cookies to use this application.');
          setIsLoading(false);
          return;
        }

        const { data: { session }, error } = await supabase.auth.getSession();
        
        if (error) {
          console.error('Error getting session:', error);
          clearAllAuthData();
          setAuthError(error.message);
          setIsLoading(false);
          return;
        }
        
        // ... rest of the existing code ...
      } catch (error) {
        console.error('Error initializing auth:', error);
        clearAllAuthData();
        setIsLoading(false);
        setAuthInitialized(true);
      }
    };
    
    initializeAuth();
  }, []);

  // ... rest of the existing code ...
}; 