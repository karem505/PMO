#!/usr/bin/env python
"""
Reset Cache Script for PMO-MVP

This script clears all cache files used by the PMO-MVP application,
with special handling for both development and deployment environments.
"""

import os
import json
import shutil
import tempfile
import sys
from datetime import datetime

def reset_cache():
    """Reset all cache files and return them to default state."""
    # Get backend directory path
    script_dir = os.path.dirname(os.path.abspath(__file__))
    backend_dir = os.path.join(script_dir, 'backend')
    
    # Standard cache locations
    cache_locations = [
        os.path.join(backend_dir, 'cache'),
        os.path.join(tempfile.gettempdir(), 'pmo_cache'),
        '/tmp/pmo_cache'  # Render and other cloud environments
    ]
    
    # Specific cache files to create as empty
    cache_files = [
        "rag_cache.json",
        "prompt_cache.json",
        "web_search_cache.json"
    ]
    
    print(f"=== PMO-MVP Cache Reset Tool ({datetime.now().strftime('%Y-%m-%d %H:%M:%S')}) ===")
    
    # Check if we're in a Render environment
    in_render = os.environ.get('RENDER') == 'true' or '/opt/render' in os.path.abspath(__file__)
    if in_render:
        print("Detected Render deployment environment")
        # Add Render-specific paths
        render_tmp = os.environ.get('TMPDIR', '/tmp')
        cache_locations.append(os.path.join(render_tmp, 'pmo_cache'))
        cache_locations.append('/opt/render/project/src/backend/cache')
    
    # Process each cache location
    for location in cache_locations:
        if os.path.exists(location):
            print(f"Found cache directory: {location}")
            try:
                # Option 1: Rename the directory (safest)
                backup_dir = f"{location}_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
                os.rename(location, backup_dir)
                print(f"Backed up cache directory to: {backup_dir}")
            except Exception as e:
                print(f"Could not rename directory: {e}")
                
                # Option 2: Try to delete all files inside
                try:
                    for file in os.listdir(location):
                        file_path = os.path.join(location, file)
                        if os.path.isfile(file_path):
                            os.remove(file_path)
                            print(f"Deleted: {file_path}")
                except Exception as e2:
                    print(f"Error deleting files: {e2}")
        
        # Create or recreate the cache directory
        try:
            os.makedirs(location, exist_ok=True)
            print(f"Created/ensured cache directory: {location}")
            
            # Create empty cache files
            for cache_file in cache_files:
                file_path = os.path.join(location, cache_file)
                try:
                    with open(file_path, 'w') as f:
                        json.dump({}, f)
                    print(f"Created empty cache file: {file_path}")
                except Exception as e:
                    print(f"Error creating {cache_file}: {e}")
        except Exception as e:
            print(f"Could not create cache directory {location}: {e}")
    
    print("\nCache reset complete. Please restart the application.")

if __name__ == "__main__":
    reset_cache() 