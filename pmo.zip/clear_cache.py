import os
import json

# Clear the cache file that's causing JSON decode errors
cache_dir = os.path.join('backend', 'cache')
cache_file = os.path.join(cache_dir, 'prompt_cache.json')

if os.path.exists(cache_file):
    # Backup the existing file
    backup_file = cache_file + '.bak'
    try:
        os.rename(cache_file, backup_file)
        print(f"Backed up corrupted cache file to {backup_file}")
    except:
        # If rename fails, try to delete
        try:
            os.remove(cache_file)
            print(f"Deleted corrupted cache file")
        except:
            print(f"Could not delete or backup {cache_file}")

# Create an empty cache file
try:
    os.makedirs(cache_dir, exist_ok=True)
    with open(cache_file, 'w') as f:
        json.dump({}, f)
    print(f"Created new empty cache file at {cache_file}")
except Exception as e:
    print(f"Error creating new cache file: {e}")

print("Cache has been reset. Please restart the application.") 