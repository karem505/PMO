import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

// Types for validation request parameters
interface ValidationRequest {
  content: string;
  domain: string;
  options: {
    strictness: 'low' | 'medium' | 'high';
    includeCorrections: boolean;
  };
}

// Response structure
interface ValidationResult {
  isValid: boolean;
  confidence: number;
  sourcesUsed: {
    name: string;
    url: string;
    relevance: number;
    snippet?: string;
  }[];
  validationDate: string;
  suggestedCorrections?: {
    original: string;
    correction: string;
    explanation: string;
  }[];
}

// CORS Headers for cross-origin requests
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    // Parse request
    const { content, domain, options } = await req.json() as ValidationRequest;

    if (!content) {
      throw new Error("Missing required parameter: content");
    }

    // Extract key phrases for validation (simplified)
    const keyPhrases = extractKeyPhrases(content);
    
    console.log(`Validating content for domain: ${domain} with strictness: ${options.strictness}`);
    console.log(`Extracted ${keyPhrases.length} key phrases for validation`);
    
    // Get trusted sources for validation
    const sources = getTrustedSources(domain);
    
    // Validate key phrases against trusted sources
    const validationResult = await validateAgainstSources(
      keyPhrases, 
      sources, 
      options.strictness
    );
    
    // Include corrections if requested
    if (options.includeCorrections && !validationResult.isValid) {
      validationResult.suggestedCorrections = generateCorrections(
        keyPhrases,
        options.strictness
      );
    }
    
    return new Response(
      JSON.stringify(validationResult),
      { 
        headers: { 
          ...corsHeaders,
          "Content-Type": "application/json" 
        }
      }
    );

  } catch (error) {
    console.error("Error in validate-content function:", error);
    
    return new Response(
      JSON.stringify({ 
        isValid: true, // Default to true to not block user
        confidence: 0.5,
        sourcesUsed: [],
        validationDate: new Date().toISOString(),
        error: error instanceof Error ? error.message : "Unknown error occurred" 
      }),
      { 
        status: 400,
        headers: { 
          ...corsHeaders,
          "Content-Type": "application/json" 
        }
      }
    );
  }
});

/**
 * Extract key phrases from content for validation
 */
function extractKeyPhrases(content: string): string[] {
  // In a real implementation, this would use NLP to extract important statements
  // For this demo, we'll use a simplified approach
  
  // Split into sentences and filter for meaningful ones
  const sentences = content.split(/[.!?]+/)
    .map(s => s.trim())
    .filter(s => s.length > 30 && s.length < 200); // Only reasonable length sentences
  
  // Select a sample of sentences (to limit processing)
  const sampledSentences: string[] = [];
  
  // Take sentences with key terms more likely to need validation
  const keyTerms = ['must', 'should', 'always', 'never', 'best practice', 'recommend', 
                    'research', 'study', 'evidence', 'data', 'statistics', 'proven'];
  
  // First pass: get sentences with key terms
  for (const sentence of sentences) {
    const sentenceLower = sentence.toLowerCase();
    if (keyTerms.some(term => sentenceLower.includes(term))) {
      sampledSentences.push(sentence);
      
      // Limit to reasonable number
      if (sampledSentences.length >= 10) break;
    }
  }
  
  // Second pass: if we don't have enough, add some random ones
  if (sampledSentences.length < 3 && sentences.length > 0) {
    // Fisher-Yates shuffle for random selection
    const remaining = [...sentences];
    for (let i = remaining.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [remaining[i], remaining[j]] = [remaining[j], remaining[i]];
    }
    
    // Add up to 3 random sentences
    for (let i = 0; i < Math.min(3, remaining.length); i++) {
      if (!sampledSentences.includes(remaining[i])) {
        sampledSentences.push(remaining[i]);
      }
      
      if (sampledSentences.length >= 5) break;
    }
  }
  
  return sampledSentences;
}

/**
 * Get trusted sources for a specific domain
 */
function getTrustedSources(domain: string): { name: string; url: string }[] {
  // In a real implementation, this would query a database of trusted sources
  // Return different sources based on domain
  
  const commonSources = [
    {
      name: 'Project Management Institute (PMI)',
      url: 'https://www.pmi.org'
    },
    {
      name: 'Harvard Business Review',
      url: 'https://hbr.org/topic/project-management'
    },
    {
      name: 'McKinsey & Company',
      url: 'https://www.mckinsey.com/capabilities/operations/our-insights'
    }
  ];
  
  // Add domain-specific sources
  if (domain.toLowerCase().includes('governance')) {
    commonSources.push({
      name: 'PMI Governance Framework',
      url: 'https://www.pmi.org/learning/library/effective-governance-framework-9945'
    });
  } else if (domain.toLowerCase().includes('capabilities')) {
    commonSources.push({
      name: 'Gartner PPM Capabilities',
      url: 'https://www.gartner.com/en/project-portfolio-management'
    });
  }
  
  return commonSources;
}

/**
 * Validate extracted phrases against trusted sources
 */
async function validateAgainstSources(
  phrases: string[],
  sources: { name: string; url: string }[],
  strictness: 'low' | 'medium' | 'high'
): Promise<ValidationResult> {
  // In a production system, this would search trusted knowledge bases
  // For this demo, we'll simulate validation with mock responses
  
  // Adjust thresholds based on strictness
  const confidenceThresholds = {
    low: 0.6,
    medium: 0.7, 
    high: 0.8
  };
  
  // Simulate validation process
  const confidenceThreshold = confidenceThresholds[strictness];
  const randomConfidence = 0.65 + (Math.random() * 0.25); // Between 0.65 and 0.9
  const isValid = randomConfidence >= confidenceThreshold;
  
  // For demo purposes, show 1-2 sources as supporting evidence
  const sourcesCount = 1 + Math.floor(Math.random() * 2);
  const selectedSources = sources
    .slice()
    .sort(() => 0.5 - Math.random()) // Shuffle
    .slice(0, sourcesCount)
    .map(source => {
      // For each source, generate a random relevance score
      const relevance = 0.7 + (Math.random() * 0.3); // Between 0.7 and 1.0
      
      // Add a snippet for context (mock data)
      return {
        ...source,
        relevance,
        snippet: phrases.length > 0
          ? phrases[Math.floor(Math.random() * phrases.length)].substring(0, 100) + '...'
          : undefined
      };
    });
  
  return {
    isValid,
    confidence: randomConfidence,
    sourcesUsed: selectedSources,
    validationDate: new Date().toISOString()
  };
}

/**
 * Generate mock corrections for validation issues
 */
function generateCorrections(
  phrases: string[],
  strictness: 'low' | 'medium' | 'high'
): { original: string; correction: string; explanation: string }[] {
  // Skip corrections for low strictness
  if (strictness === 'low') {
    return [];
  }
  
  // Randomly select phrases to correct
  const corrections: { original: string; correction: string; explanation: string }[] = [];
  
  // Determine number of corrections based on strictness
  const correctionCount = strictness === 'high' ? 2 : 1;
  
  // Ensure we have enough phrases
  if (phrases.length === 0) return [];
  
  // Generate corrections
  for (let i = 0; i < Math.min(correctionCount, phrases.length); i++) {
    const randomPhrase = phrases[Math.floor(Math.random() * phrases.length)];
    
    // Simple replacement patterns for demo purposes
    const patterns = [
      {
        find: /\balways\b/i,
        replace: 'typically',
        explanation: 'Research indicates this is common but not universal'
      },
      {
        find: /\bmust\b/i,
        replace: 'should consider',
        explanation: 'Best practices suggest flexibility based on context'
      },
      {
        find: /\bnever\b/i,
        replace: 'rarely',
        explanation: 'There are exceptions in specific circumstances'
      },
      {
        find: /\ball\b/i,
        replace: 'most',
        explanation: 'Current data indicates this applies to the majority but not all cases'
      }
    ];
    
    // Try to apply patterns
    for (const pattern of patterns) {
      if (pattern.find.test(randomPhrase)) {
        const original = randomPhrase;
        const correction = randomPhrase.replace(pattern.find, pattern.replace);
        
        corrections.push({
          original,
          correction,
          explanation: pattern.explanation
        });
        
        // Break after first match
        break;
      }
    }
    
    // If no pattern matched, create a general correction
    if (corrections.length <= i) {
      corrections.push({
        original: randomPhrase,
        correction: randomPhrase + " (according to recent industry standards)",
        explanation: "Adding reference to current industry standards improves accuracy"
      });
    }
  }
  
  return corrections;
}