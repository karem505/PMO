import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import Stripe from 'npm:stripe@12.5.0'

serve(async (req) => {
  const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', {
    apiVersion: '2023-10-16',
  })

  const signature = req.headers.get('stripe-signature')
  const webhookSecret = Deno.env.get('STRIPE_WEBHOOK_SIGNING_SECRET')

  if (!signature || !webhookSecret) {
    return new Response('Missing stripe-signature or webhook secret', { status: 400 })
  }

  try {
    // Get request body
    const body = await req.text()

    // Verify webhook signature
    const event = stripe.webhooks.constructEvent(body, signature, webhookSecret)

    // Handle the event based on type
    switch (event.type) {
      case 'customer.subscription.created':
      case 'customer.subscription.updated':
        await handleSubscriptionChange(event.data.object)
        break
      case 'customer.subscription.deleted':
        await handleSubscriptionDeleted(event.data.object)
        break
      case 'invoice.paid':
        await handleInvoicePaid(event.data.object)
        break
      case 'invoice.payment_failed':
        await handlePaymentFailed(event.data.object)
        break
      case 'checkout.session.completed':
        await handleCheckoutSessionCompleted(event.data.object)
        break
      default:
        console.log(`Unhandled event type: ${event.type}`)
    }

    return new Response(JSON.stringify({ received: true }), {
      headers: { 'Content-Type': 'application/json' },
      status: 200
    })
  } catch (err) {
    console.error('Error processing webhook:', err)
    return new Response(`Webhook Error: ${err.message}`, { status: 400 })
  }
})

// Handle subscription change events
async function handleSubscriptionChange(subscription: any) {
  // Extract customer ID
  const customerId = subscription.customer
  
  // Get Supabase user ID for this customer
  const { data, error } = await supabaseClient
    .from('subscriptions')
    .select('user_id')
    .eq('payment_id', customerId)
    .single()
    
  if (error) {
    console.error('Error finding user for subscription:', error)
    return
  }
  
  const userId = data.user_id
  
  // Determine subscription tier based on Stripe product
  let tier = 'free'
  if (subscription.items?.data?.length > 0) {
    const productId = subscription.items.data[0].price.product
    
    // Get product details
    const product = await stripe.products.retrieve(productId)
    
    // Extract tier from product metadata
    tier = product.metadata.tier || 'premium'
  }
  
  // Determine subscription status
  const status = subscription.status === 'active' || subscription.status === 'trialing' 
    ? subscription.status === 'trialing' ? 'trial' : 'active'
    : subscription.status
  
  // Update subscription in database
  const { error: updateError } = await supabaseClient
    .from('subscriptions')
    .update({
      tier,
      status,
      current_period_start: new Date(subscription.current_period_start * 1000).toISOString(),
      current_period_end: new Date(subscription.current_period_end * 1000).toISOString(),
      cancel_at_period_end: subscription.cancel_at_period_end,
      trial_start: subscription.trial_start ? new Date(subscription.trial_start * 1000).toISOString() : null,
      trial_end: subscription.trial_end ? new Date(subscription.trial_end * 1000).toISOString() : null,
      updated_at: new Date().toISOString()
    })
    .eq('user_id', userId)
    
  if (updateError) {
    console.error('Error updating subscription in database:', updateError)
  }
}

// Handle subscription deleted events
async function handleSubscriptionDeleted(subscription: any) {
  // Extract customer ID
  const customerId = subscription.customer
  
  // Get Supabase user ID for this customer
  const { data, error } = await supabaseClient
    .from('subscriptions')
    .select('user_id')
    .eq('payment_id', customerId)
    .single()
    
  if (error) {
    console.error('Error finding user for subscription:', error)
    return
  }
  
  const userId = data.user_id
  
  // Update subscription to free tier and inactive status
  const { error: updateError } = await supabaseClient
    .from('subscriptions')
    .update({
      tier: 'free',
      status: 'canceled',
      current_period_end: new Date(subscription.current_period_end * 1000).toISOString(),
      updated_at: new Date().toISOString()
    })
    .eq('user_id', userId)
    
  if (updateError) {
    console.error('Error updating subscription in database:', updateError)
  }
}

// Handle invoice paid events
async function handleInvoicePaid(invoice: any) {
  // Extract customer ID
  const customerId = invoice.customer
  
  // Get Supabase user ID for this customer
  const { data, error } = await supabaseClient
    .from('subscriptions')
    .select('user_id')
    .eq('payment_id', customerId)
    .single()
    
  if (error) {
    console.error('Error finding user for invoice:', error)
    return
  }
  
  const userId = data.user_id
  
  // Add payment to history
  const { error: paymentError } = await supabaseClient
    .from('payment_history')
    .insert({
      user_id: userId,
      amount: invoice.amount_paid / 100, // Convert from cents
      currency: invoice.currency.toUpperCase(),
      status: 'paid',
      payment_method: invoice.payment_method_types?.[0] || 'card',
      payment_id: invoice.id,
      description: `Payment for ${invoice.lines.data?.[0]?.description || 'subscription'}`
    })
    
  if (paymentError) {
    console.error('Error adding payment to history:', paymentError)
  }
}

// Handle payment failed events
async function handlePaymentFailed(invoice: any) {
  // Extract customer ID
  const customerId = invoice.customer
  
  // Get Supabase user ID for this customer
  const { data, error } = await supabaseClient
    .from('subscriptions')
    .select('user_id')
    .eq('payment_id', customerId)
    .single()
    
  if (error) {
    console.error('Error finding user for invoice:', error)
    return
  }
  
  const userId = data.user_id
  
  // Update subscription status to past_due
  const { error: updateError } = await supabaseClient
    .from('subscriptions')
    .update({
      status: 'past_due',
      updated_at: new Date().toISOString()
    })
    .eq('user_id', userId)
    
  if (updateError) {
    console.error('Error updating subscription status:', updateError)
  }
  
  // Add failed payment to history
  const { error: paymentError } = await supabaseClient
    .from('payment_history')
    .insert({
      user_id: userId,
      amount: invoice.amount_due / 100, // Convert from cents
      currency: invoice.currency.toUpperCase(),
      status: 'failed',
      payment_method: invoice.payment_method_types?.[0] || 'card',
      payment_id: invoice.id,
      description: `Failed payment for ${invoice.lines.data?.[0]?.description || 'subscription'}`
    })
    
  if (paymentError) {
    console.error('Error adding failed payment to history:', paymentError)
  }
}

// Handle checkout session completed events
async function handleCheckoutSessionCompleted(session: any) {
  // Get user ID from client_reference_id or metadata
  const userId = session.client_reference_id || session.metadata?.userId
  
  if (!userId) {
    console.error('No user ID found in checkout session')
    return
  }
  
  // For new subscriptions, update the subscription record
  if (session.subscription) {
    // Get subscription details from Stripe
    const subscription = await stripe.subscriptions.retrieve(session.subscription)
    
    // Determine subscription tier based on Stripe product
    let tier = 'free'
    if (subscription.items?.data?.length > 0) {
      const productId = subscription.items.data[0].price.product
      
      // Get product details
      const product = await stripe.products.retrieve(productId)
      
      // Extract tier from product metadata
      tier = product.metadata.tier || 'premium'
    }
    
    // Update subscription in database
    const { error } = await supabaseClient
      .from('subscriptions')
      .update({
        tier,
        status: subscription.status === 'trialing' ? 'trial' : 'active',
        payment_provider: 'stripe',
        payment_id: subscription.customer as string,
        current_period_start: new Date(subscription.current_period_start * 1000).toISOString(),
        current_period_end: new Date(subscription.current_period_end * 1000).toISOString(),
        trial_start: subscription.trial_start ? new Date(subscription.trial_start * 1000).toISOString() : null,
        trial_end: subscription.trial_end ? new Date(subscription.trial_end * 1000).toISOString() : null,
        updated_at: new Date().toISOString()
      })
      .eq('user_id', userId)
      
    if (error) {
      console.error('Error updating subscription in database:', error)
    }
  }
}

// Initialize Stripe (needed for verification)
const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', {
  apiVersion: '2023-10-16',
})

// Helper to get Supabase client with admin privileges
const supabaseClient = createClient(
  Deno.env.get('SUPABASE_URL') || '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '',
)

// Create a Supabase client
function createClient(supabaseUrl: string, supabaseKey: string) {
  return createSupabaseClient(supabaseUrl, supabaseKey, {
    db: { schema: 'public' },
    auth: { persistSession: false },
  })
}

// Import for Supabase client
import { createClient as createSupabaseClient } from 'npm:@supabase/supabase-js@2.38.4'