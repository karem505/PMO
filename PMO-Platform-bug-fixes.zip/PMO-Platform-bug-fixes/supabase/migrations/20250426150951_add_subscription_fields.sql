-- Add subscription-related fields to profiles table
ALTER TABLE profiles
ADD COLUMN IF NOT EXISTS subscription_plan TEXT DEFAULT 'free',
ADD COLUMN IF NOT EXISTS token_limit INTEGER DEFAULT 81250,
ADD COLUMN IF NOT EXISTS remaining_tokens INTEGER DEFAULT 81250,
ADD COLUMN IF NOT EXISTS storage_limit_mb INTEGER DEFAULT 100,
ADD COLUMN IF NOT EXISTS used_storage_mb INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS next_billing_date TIMESTAMPTZ,
ADD COLUMN IF NOT EXISTS is_trial BOOLEAN DEFAULT false;

-- Create index for subscription plan lookups
CREATE INDEX IF NOT EXISTS profiles_subscription_plan_idx ON profiles(subscription_plan);

-- Update RLS policies to allow subscription status checks
CREATE POLICY "Anyone can check subscription status"
ON profiles FOR SELECT
USING (true); 