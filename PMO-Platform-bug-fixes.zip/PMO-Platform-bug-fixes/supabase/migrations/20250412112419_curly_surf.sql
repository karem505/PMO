/*
  # PMO Maturity Assessment Tables

  1. New Tables
    - `maturity_assessments` - Stores assessment data
    - `maturity_assessment_responses` - Stores domain-specific assessment responses
    - `maturity_improvement_plans` - Stores improvement plans
  
  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to access their own assessment data
*/

-- Maturity assessments table
CREATE TABLE IF NOT EXISTS maturity_assessments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id),
  project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
  overall_maturity TEXT NOT NULL,
  domain_maturity JSONB DEFAULT '{}'::JSONB,
  strengths JSONB DEFAULT '[]'::JSONB,
  weaknesses JSONB DEFAULT '[]'::JSONB,
  recommendations JSONB DEFAULT '[]'::JSONB,
  report TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  assessment_type TEXT NOT NULL
);

-- Maturity assessment responses table
CREATE TABLE IF NOT EXISTS maturity_assessment_responses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assessment_id UUID REFERENCES maturity_assessments(id) ON DELETE CASCADE,
  domain_id INTEGER NOT NULL,
  maturity_level TEXT NOT NULL,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Maturity improvement plans table
CREATE TABLE IF NOT EXISTS maturity_improvement_plans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assessment_id UUID REFERENCES maturity_assessments(id) ON DELETE CASCADE,
  user_id UUID REFERENCES auth.users(id),
  title TEXT NOT NULL,
  description TEXT,
  status TEXT DEFAULT 'planned',
  target_maturity_level TEXT NOT NULL,
  target_date TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  actions JSONB DEFAULT '[]'::JSONB
);

-- Enable Row Level Security
ALTER TABLE maturity_assessments ENABLE ROW LEVEL SECURITY;
ALTER TABLE maturity_assessment_responses ENABLE ROW LEVEL SECURITY;
ALTER TABLE maturity_improvement_plans ENABLE ROW LEVEL SECURITY;

-- Create security policies

-- Maturity assessments policies
CREATE POLICY "Users can view own assessments" 
  ON maturity_assessments FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own assessments" 
  ON maturity_assessments FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own assessments" 
  ON maturity_assessments FOR UPDATE 
  USING (auth.uid() = user_id);

-- Responses policies
CREATE POLICY "Users can view own assessment responses" 
  ON maturity_assessment_responses FOR SELECT 
  USING (EXISTS (
    SELECT 1 FROM maturity_assessments 
    WHERE maturity_assessments.id = maturity_assessment_responses.assessment_id 
    AND maturity_assessments.user_id = auth.uid()
  ));

CREATE POLICY "Users can create own assessment responses" 
  ON maturity_assessment_responses FOR INSERT 
  WITH CHECK (EXISTS (
    SELECT 1 FROM maturity_assessments 
    WHERE maturity_assessments.id = maturity_assessment_responses.assessment_id 
    AND maturity_assessments.user_id = auth.uid()
  ));

-- Improvement plans policies  
CREATE POLICY "Users can view own improvement plans" 
  ON maturity_improvement_plans FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own improvement plans" 
  ON maturity_improvement_plans FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own improvement plans" 
  ON maturity_improvement_plans FOR UPDATE 
  USING (auth.uid() = user_id);

-- Indexes for better query performance
CREATE INDEX IF NOT EXISTS maturity_assessments_user_id_idx ON maturity_assessments(user_id);
CREATE INDEX IF NOT EXISTS maturity_assessments_project_id_idx ON maturity_assessments(project_id);
CREATE INDEX IF NOT EXISTS maturity_assessment_responses_assessment_id_idx ON maturity_assessment_responses(assessment_id);
CREATE INDEX IF NOT EXISTS maturity_improvement_plans_user_id_idx ON maturity_improvement_plans(user_id);
CREATE INDEX IF NOT EXISTS maturity_improvement_plans_assessment_id_idx ON maturity_improvement_plans(assessment_id);