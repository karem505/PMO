/*
  # Admin Best Practice Documents Schema

  1. New Tables
    - `best_practice_categories` - Categories for best practice documents
    - `best_practice_documents` - Stores the actual documents with metadata
    - `best_practice_tags` - Tags for documents to improve searchability
    - `best_practice_document_tags` - Junction table linking documents to tags
  
  2. Security
    - Enable RLS on all tables
    - Add policies for admin management and public viewing
*/

-- Best practice categories table
CREATE TABLE IF NOT EXISTS best_practice_categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  icon TEXT, -- Icon identifier (e.g., 'file-text', 'book', etc.)
  color TEXT, -- Color code for UI display
  display_order INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(name)
);

-- Best practice documents table
CREATE TABLE IF NOT EXISTS best_practice_documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  summary TEXT,
  category_id UUID REFERENCES best_practice_categories(id),
  document_type TEXT NOT NULL, -- 'template', 'guide', 'checklist', 'whitepaper', etc.
  format TEXT DEFAULT 'markdown', -- 'markdown', 'html', 'pdf', etc.
  status TEXT DEFAULT 'published', -- 'draft', 'published', 'archived'
  featured BOOLEAN DEFAULT false,
  view_count INTEGER DEFAULT 0,
  storage_path TEXT, -- Path to stored document if not inline content
  external_url TEXT, -- External URL if document is hosted elsewhere
  download_available BOOLEAN DEFAULT true,
  version TEXT DEFAULT '1.0',
  is_public BOOLEAN DEFAULT true,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Best practice tags table
CREATE TABLE IF NOT EXISTS best_practice_tags (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(name)
);

-- Junction table for document tags
CREATE TABLE IF NOT EXISTS best_practice_document_tags (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id UUID REFERENCES best_practice_documents(id) ON DELETE CASCADE,
  tag_id UUID REFERENCES best_practice_tags(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(document_id, tag_id)
);

-- Enable Row Level Security
ALTER TABLE best_practice_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE best_practice_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE best_practice_tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE best_practice_document_tags ENABLE ROW LEVEL SECURITY;

-- Create security policies

-- Categories policies
CREATE POLICY "Anyone can view active best practice categories" 
  ON best_practice_categories FOR SELECT 
  USING (is_active = true);

CREATE POLICY "Admins can manage best practice categories" 
  ON best_practice_categories FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM user_roles ur
      JOIN roles r ON ur.role_id = r.id
      WHERE ur.user_id = auth.uid() AND r.name = 'admin'
    )
  );

-- Documents policies
CREATE POLICY "Anyone can view public best practice documents" 
  ON best_practice_documents FOR SELECT 
  USING (is_public = true AND status = 'published');

CREATE POLICY "Admins can manage best practice documents" 
  ON best_practice_documents FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM user_roles ur
      JOIN roles r ON ur.role_id = r.id
      WHERE ur.user_id = auth.uid() AND r.name = 'admin'
    )
  );

-- Tags policies
CREATE POLICY "Anyone can view best practice tags" 
  ON best_practice_tags FOR SELECT 
  USING (true);

CREATE POLICY "Admins can manage best practice tags" 
  ON best_practice_tags FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM user_roles ur
      JOIN roles r ON ur.role_id = r.id
      WHERE ur.user_id = auth.uid() AND r.name = 'admin'
    )
  );

-- Document tags junction policies
CREATE POLICY "Anyone can view best practice document tags" 
  ON best_practice_document_tags FOR SELECT 
  USING (
    EXISTS (
      SELECT 1 FROM best_practice_documents
      WHERE best_practice_documents.id = best_practice_document_tags.document_id
      AND best_practice_documents.is_public = true
      AND best_practice_documents.status = 'published'
    )
  );

CREATE POLICY "Admins can manage best practice document tags" 
  ON best_practice_document_tags FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM user_roles ur
      JOIN roles r ON ur.role_id = r.id
      WHERE ur.user_id = auth.uid() AND r.name = 'admin'
    )
  );

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS best_practice_documents_category_id_idx 
  ON best_practice_documents(category_id);
CREATE INDEX IF NOT EXISTS best_practice_documents_status_idx 
  ON best_practice_documents(status);
CREATE INDEX IF NOT EXISTS best_practice_document_tags_document_id_idx 
  ON best_practice_document_tags(document_id);
CREATE INDEX IF NOT EXISTS best_practice_document_tags_tag_id_idx 
  ON best_practice_document_tags(tag_id);

-- Insert default categories
INSERT INTO best_practice_categories (name, description, icon, color, display_order, is_active) VALUES
  ('Methodologies & Frameworks', 'Best practices related to PMO methodologies and frameworks', 'layout', 'blue', 1, true),
  ('Governance & Oversight', 'Best practices for PMO governance structures and oversight mechanisms', 'shield', 'purple', 2, true),
  ('Templates & Tools', 'Templates, checklists, and tools for PMO implementation', 'file-text', 'green', 3, true),
  ('Process Documentation', 'Documentation of standard PMO processes and procedures', 'file-text', 'amber', 4, true),
  ('Capability Development', 'Best practices for developing PMO capabilities and skills', 'users', 'red', 5, true),
  ('Performance Metrics', 'KPIs and metrics for measuring PMO performance and success', 'bar-chart', 'indigo', 6, true),
  ('Implementation Guides', 'Step-by-step guides for implementing PMO components', 'book-open', 'teal', 7, true)
ON CONFLICT (name) DO UPDATE SET 
  description = EXCLUDED.description,
  icon = EXCLUDED.icon,
  color = EXCLUDED.color,
  display_order = EXCLUDED.display_order,
  updated_at = now();

-- Default tags
INSERT INTO best_practice_tags (name, description) VALUES
  ('Beginner', 'Content suitable for beginners or organizations new to PMO'),
  ('Intermediate', 'Content requiring some level of PMO experience'),
  ('Advanced', 'Content for mature PMOs and advanced practitioners'),
  ('Template', 'Reusable templates and forms'),
  ('Guide', 'Step-by-step implementation guides'),
  ('Checklist', 'Verification and validation checklists'),
  ('Strategic', 'Best practices focused on strategic aspects'),
  ('Tactical', 'Best practices focused on tactical implementation'),
  ('Enterprise', 'Enterprise-level PMO practices'),
  ('Departmental', 'Department-level PMO practices')
ON CONFLICT (name) DO NOTHING;