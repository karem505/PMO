/*
  # Cross-Domain Document Intelligence and Task Outputs

  1. Updates to Tables
    - Add domain_id column for domain-specific documents
    - Enhanced document search capabilities
    - Functions for cross-domain document intelligence
  
  2. Security
    - Update policies for cross-domain document access
*/

-- Add domain_id to processed_documents if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'processed_documents' AND column_name = 'domain_id'
  ) THEN
    ALTER TABLE processed_documents ADD COLUMN domain_id INTEGER;
  END IF;
END
$$;

-- Create index on domain_id
CREATE INDEX IF NOT EXISTS processed_documents_domain_id_idx ON processed_documents(domain_id);

-- Create document content search index if it doesn't exist
CREATE INDEX IF NOT EXISTS document_chunks_content_idx ON document_chunks USING gin(to_tsvector('english', content));

-- Create or replace function to search across domains
CREATE OR REPLACE FUNCTION search_cross_domain_documents(
  search_query TEXT,
  project_id UUID,
  current_domain_id INTEGER,
  max_results INTEGER DEFAULT 5
) 
RETURNS TABLE (
  chunk_id UUID,
  document_id UUID,
  content TEXT,
  domain_id INTEGER,
  relevance FLOAT
) AS $$
BEGIN
  RETURN QUERY
  WITH search_terms AS (
    SELECT plainto_tsquery('english', search_query) AS query
  ),
  matching_chunks AS (
    SELECT 
      dc.id AS chunk_id,
      dc.document_id,
      dc.content,
      pd.domain_id,
      ts_rank(to_tsvector('english', dc.content), (SELECT query FROM search_terms)) AS relevance
    FROM 
      document_chunks dc
      JOIN processed_documents pd ON dc.document_id = pd.id
    WHERE 
      pd.project_id = search_cross_domain_documents.project_id
      AND pd.domain_id <> search_cross_domain_documents.current_domain_id
      AND to_tsvector('english', dc.content) @@ (SELECT query FROM search_terms)
    ORDER BY 
      relevance DESC
    LIMIT 
      search_cross_domain_documents.max_results
  )
  SELECT * FROM matching_chunks;
END;
$$ LANGUAGE plpgsql;

-- Update task-related functions to enhance AI-generated outputs

-- Create or replace function to get relevant document chunks for a task
-- Fix: Renamed the parameter to task_domain_id to avoid name conflict
CREATE OR REPLACE FUNCTION get_task_relevant_documents(
  task_id TEXT,
  project_id UUID,
  task_domain_id INTEGER,
  max_results INTEGER DEFAULT 10
) 
RETURNS TABLE (
  chunk_id UUID,
  document_id UUID,
  content TEXT,
  source TEXT,
  domain_id INTEGER,
  relevance FLOAT
) AS $$
BEGIN
  -- This function finds relevant document chunks for a specific task
  -- across all domains, prioritizing the task's own domain
  
  -- First get task information (assuming task_id and other task info is in tasks table)
  RETURN QUERY
  WITH task_info AS (
    SELECT 
      t.task_id,
      t.notes
    FROM 
      tasks t
    WHERE 
      t.task_id = get_task_relevant_documents.task_id
      AND t.project_id = get_task_relevant_documents.project_id
    LIMIT 1
  ),
  search_terms AS (
    SELECT plainto_tsquery('english', (SELECT notes FROM task_info)) AS query
  ),
  matching_chunks AS (
    -- Priority 1: Chunks from the same domain
    (SELECT 
      dc.id AS chunk_id,
      dc.document_id,
      dc.content,
      dc.source,
      pd.domain_id,
      1.5 * ts_rank(to_tsvector('english', dc.content), (SELECT query FROM search_terms)) AS relevance
    FROM 
      document_chunks dc
      JOIN processed_documents pd ON dc.document_id = pd.id
    WHERE 
      pd.project_id = get_task_relevant_documents.project_id
      AND pd.domain_id = get_task_relevant_documents.task_domain_id
      AND to_tsvector('english', dc.content) @@ (SELECT query FROM search_terms)
    ORDER BY 
      relevance DESC
    LIMIT max_results/2)
    
    UNION ALL
    
    -- Priority 2: Chunks from other domains
    (SELECT 
      dc.id AS chunk_id,
      dc.document_id,
      dc.content,
      dc.source,
      pd.domain_id,
      ts_rank(to_tsvector('english', dc.content), (SELECT query FROM search_terms)) AS relevance
    FROM 
      document_chunks dc
      JOIN processed_documents pd ON dc.document_id = pd.id
    WHERE 
      pd.project_id = get_task_relevant_documents.project_id
      AND pd.domain_id <> get_task_relevant_documents.task_domain_id
      AND to_tsvector('english', dc.content) @@ (SELECT query FROM search_terms)
    ORDER BY 
      relevance DESC
    LIMIT max_results/2)
  )
  SELECT * FROM matching_chunks
  ORDER BY relevance DESC
  LIMIT max_results;
END;
$$ LANGUAGE plpgsql;

-- Ensure RLS policies allow for cross-domain document access
-- Users should be able to access any document in their project, regardless of domain
DO $$
BEGIN
  -- Drop existing policies if they'd conflict
  DROP POLICY IF EXISTS "Users can view their own documents" ON processed_documents;
  
  -- Create new policy with broader access
  CREATE POLICY "Users can access documents in their projects" 
    ON processed_documents FOR SELECT 
    USING (
      auth.uid() = created_by OR 
      EXISTS (
        SELECT 1 FROM projects 
        WHERE projects.id = processed_documents.project_id 
        AND projects.owner_id = auth.uid()
      )
    );
    
  -- Update chunks policy for cross-domain access
  DROP POLICY IF EXISTS "Users can view chunks for their documents" ON document_chunks;
  
  CREATE POLICY "Users can access document chunks in their projects" 
    ON document_chunks FOR SELECT 
    USING (
      EXISTS (
        SELECT 1 FROM processed_documents 
        WHERE processed_documents.id = document_chunks.document_id 
        AND (
          processed_documents.created_by = auth.uid() OR 
          EXISTS (
            SELECT 1 FROM projects 
            WHERE projects.id = processed_documents.project_id 
            AND projects.owner_id = auth.uid()
          )
        )
      )
    );
END
$$;