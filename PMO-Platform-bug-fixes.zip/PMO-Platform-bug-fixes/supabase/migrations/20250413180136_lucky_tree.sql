/*
  # Subscription System Implementation

  1. New Tables
    - `subscriptions` - Stores user subscription information
    - `subscription_tiers` - Available subscription tiers
    - `subscription_usage` - Tracks usage of limited features
    - `subscription_features` - Features available in each tier
  
  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to access their own subscription data
*/

-- Subscription tiers table (reference table)
CREATE TABLE IF NOT EXISTS subscription_tiers (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  is_active BOOLEAN DEFAULT true
);

-- Insert default subscription tiers
INSERT INTO subscription_tiers (name, description) 
VALUES 
  ('free', 'Free tier with limited features'),
  ('premium', 'Premium tier with more features and capacity'),
  ('enterprise', 'Enterprise tier with unlimited features and dedicated support')
ON CONFLICT (id) DO NOTHING;

-- Subscriptions table
CREATE TABLE IF NOT EXISTS subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  tier TEXT NOT NULL DEFAULT 'free',
  status TEXT NOT NULL CHECK (status IN ('active', 'inactive', 'past_due', 'canceled', 'trial')),
  payment_provider TEXT CHECK (payment_provider IN ('stripe', 'paypal', 'manual', 'none')),
  payment_id TEXT,
  current_period_start TIMESTAMPTZ,
  current_period_end TIMESTAMPTZ,
  cancel_at_period_end BOOLEAN DEFAULT false,
  trial_start TIMESTAMPTZ,
  trial_end TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_id)
);

-- Subscription features table (reference table)
CREATE TABLE IF NOT EXISTS subscription_features (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  tier TEXT NOT NULL,
  limit_type TEXT CHECK (limit_type IN ('count', 'boolean', 'storage')),
  limit_value TEXT NOT NULL, -- 'unlimited' or a number
  is_available BOOLEAN DEFAULT true
);

-- Insert default subscription features
INSERT INTO subscription_features (name, description, tier, limit_type, limit_value) 
VALUES 
  -- Free tier features
  ('projects', 'Number of projects allowed', 'free', 'count', '3'),
  ('aiAnalysis', 'Number of AI analyses per month', 'free', 'count', '3'),
  ('templates', 'Number of templates allowed', 'free', 'count', '5'),
  ('users', 'Number of users allowed', 'free', 'count', '1'),
  ('storage', 'Storage space in MB', 'free', 'storage', '250'),
  ('customDomains', 'Custom domain support', 'free', 'boolean', 'false'),
  ('prioritySupport', 'Priority support', 'free', 'boolean', 'false'),
  ('whiteLabeling', 'White-labeling options', 'free', 'boolean', 'false'),

  -- Premium tier features
  ('projects', 'Number of projects allowed', 'premium', 'count', '20'),
  ('aiAnalysis', 'Number of AI analyses per month', 'premium', 'count', '100'),
  ('templates', 'Number of templates allowed', 'premium', 'count', '50'),
  ('users', 'Number of users allowed', 'premium', 'count', '5'),
  ('storage', 'Storage space in MB', 'premium', 'storage', '5000'),
  ('customDomains', 'Custom domain support', 'premium', 'boolean', 'true'),
  ('prioritySupport', 'Priority support', 'premium', 'boolean', 'true'),
  ('whiteLabeling', 'White-labeling options', 'premium', 'boolean', 'false'),

  -- Enterprise tier features
  ('projects', 'Number of projects allowed', 'enterprise', 'count', 'unlimited'),
  ('aiAnalysis', 'Number of AI analyses per month', 'enterprise', 'count', 'unlimited'),
  ('templates', 'Number of templates allowed', 'enterprise', 'count', 'unlimited'),
  ('users', 'Number of users allowed', 'enterprise', 'count', 'unlimited'),
  ('storage', 'Storage space in MB', 'enterprise', 'storage', '50000'),
  ('customDomains', 'Custom domain support', 'enterprise', 'boolean', 'true'),
  ('prioritySupport', 'Priority support', 'enterprise', 'boolean', 'true'),
  ('whiteLabeling', 'White-labeling options', 'enterprise', 'boolean', 'true')
ON CONFLICT (id) DO NOTHING;

-- Subscription usage table
CREATE TABLE IF NOT EXISTS subscription_usage (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  feature TEXT NOT NULL,
  count INTEGER DEFAULT 0,
  period_start TIMESTAMPTZ NOT NULL,
  period_end TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_id, feature, period_start)
);

-- AI configuration table (to track usage of AI features)
CREATE TABLE IF NOT EXISTS ai_configurations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  domain_id INTEGER NOT NULL,
  analysis_depth TEXT DEFAULT 'standard',
  focus_areas JSONB DEFAULT '{}'::jsonb,
  template_types JSONB DEFAULT '{}'::jsonb,
  use_openai BOOLEAN DEFAULT true,
  quick_mode BOOLEAN DEFAULT true,
  last_updated TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_id, domain_id)
);

-- Payment history table
CREATE TABLE IF NOT EXISTS payment_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  amount NUMERIC NOT NULL,
  currency TEXT DEFAULT 'USD',
  status TEXT NOT NULL,
  payment_method TEXT,
  payment_id TEXT,
  description TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscription_usage ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_configurations ENABLE ROW LEVEL SECURITY;
ALTER TABLE payment_history ENABLE ROW LEVEL SECURITY;

-- Create security policies

-- Users can view their own subscription
CREATE POLICY "Users can view own subscription" 
  ON subscriptions FOR SELECT 
  USING (auth.uid() = user_id);

-- Users can update their own subscription
CREATE POLICY "Users can update own subscription" 
  ON subscriptions FOR UPDATE 
  USING (auth.uid() = user_id);

-- Admins can manage all subscriptions
CREATE POLICY "Admins can manage all subscriptions" 
  ON subscriptions FOR ALL 
  USING (
    EXISTS (
      SELECT 1 
      FROM user_roles ur
      JOIN roles r ON ur.role_id = r.id
      WHERE ur.user_id = auth.uid() AND r.name = 'admin'
    )
  );

-- Users can view their own usage
CREATE POLICY "Users can view own usage" 
  ON subscription_usage FOR SELECT 
  USING (auth.uid() = user_id);

-- Users can insert their own usage
CREATE POLICY "Users can insert own usage" 
  ON subscription_usage FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

-- Users can update their own usage
CREATE POLICY "Users can update own usage" 
  ON subscription_usage FOR UPDATE 
  USING (auth.uid() = user_id);

-- Admins can manage all usage
CREATE POLICY "Admins can manage all usage" 
  ON subscription_usage FOR ALL 
  USING (
    EXISTS (
      SELECT 1 
      FROM user_roles ur
      JOIN roles r ON ur.role_id = r.id
      WHERE ur.user_id = auth.uid() AND r.name = 'admin'
    )
  );

-- Users can view their own AI configurations
CREATE POLICY "Users can view own AI configurations" 
  ON ai_configurations FOR SELECT 
  USING (auth.uid() = user_id);

-- Users can insert their own AI configurations
CREATE POLICY "Users can insert own AI configurations" 
  ON ai_configurations FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

-- Users can update their own AI configurations
CREATE POLICY "Users can update own AI configurations" 
  ON ai_configurations FOR UPDATE 
  USING (auth.uid() = user_id);

-- Users can view their own payment history
CREATE POLICY "Users can view own payment history" 
  ON payment_history FOR SELECT 
  USING (auth.uid() = user_id);

-- Anyone can view subscription tiers
CREATE POLICY "Anyone can view subscription tiers" 
  ON subscription_tiers FOR SELECT 
  USING (true);

-- Anyone can view subscription features
CREATE POLICY "Anyone can view subscription features" 
  ON subscription_features FOR SELECT 
  USING (true);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS subscriptions_user_id_idx ON subscriptions(user_id);
CREATE INDEX IF NOT EXISTS subscription_usage_user_id_feature_idx ON subscription_usage(user_id, feature);
CREATE INDEX IF NOT EXISTS subscription_usage_period_idx ON subscription_usage(period_start, period_end);
CREATE INDEX IF NOT EXISTS ai_configurations_user_id_idx ON ai_configurations(user_id);
CREATE INDEX IF NOT EXISTS payment_history_user_id_idx ON payment_history(user_id);