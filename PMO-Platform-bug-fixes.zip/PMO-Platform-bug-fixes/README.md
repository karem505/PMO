# PMO-MVP

A FastAPI-based backend service for document processing and analysis.

## Features

- Document upload and processing
- Support for PDF, Excel, and CSV files
- RESTful API endpoints
- CORS enabled for frontend integration

## Setup

1. Create a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

2. Install dependencies:
```bash
pip install -r backend/requirements.txt
```

3. Create a `.env` file in the backend directory with your configuration:
```env
OPENAI_API_KEY=your_api_key
```

## Running the Application

1. Start the FastAPI server:
```bash
cd backend
uvicorn main:app --reload
```

2. The API will be available at `https://pmo-mvp-fe.onrender.com`

## API Endpoints

### Document Processing
- POST `/api/documents/read`
  - Accepts file uploads (PDF, Excel, CSV)
  - Returns processed document data

## Development

- The project uses FastAPI for the backend
- Document processing is handled by the `DocumentReaderService`
- CORS is configured to allow all origins (adjust in production)

## License

MIT 