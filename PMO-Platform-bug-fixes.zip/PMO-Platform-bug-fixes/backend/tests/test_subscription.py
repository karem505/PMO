import os
import sys
from pathlib import Path
from dotenv import load_dotenv

# Add the backend directory to the Python path
backend_dir = str(Path(__file__).parent.parent)
sys.path.insert(0, backend_dir)

import pytest
from fastapi.testclient import TestClient
from main import app
from services.subscription import SubscriptionService, SubscriptionPlan
from unittest.mock import Mock, patch

# Load environment variables from test file
env_path = Path(__file__).parent / '.env.test'
load_dotenv(env_path)

# Get Supabase credentials
supabase_url = os.getenv("SUPABASE_URL")
supabase_key = os.getenv("SUPABASE_ANON_KEY")

if not supabase_url or not supabase_key:
    raise ValueError("Supabase credentials not found in .env.test file")

# Initialize test client
client = TestClient(app)

# Test data
TEST_USER_EMAIL = "test@example.com"
TEST_USER_DATA = {
    "email": TEST_USER_EMAIL,
    "subscription_plan": SubscriptionPlan.FREE,
    "token_limit": 81250,
    "remaining_tokens": 81250,
    "storage_limit_mb": 100,
    "used_storage_mb": 0
}

@pytest.fixture(autouse=True)
def setup_test_user():
    """Setup and teardown test user before and after each test."""
    # Create test user
    app.state.supabase.table("profiles").upsert(TEST_USER_DATA).execute()
    yield
    # Cleanup test user
    app.state.supabase.table("profiles").delete().eq("email", TEST_USER_EMAIL).execute()

def test_get_subscription_plans():
    """Test getting available subscription plans."""
    response = client.get("/subscription/plans")
    assert response.status_code == 200
    plans = response.json()
    assert "free" in plans
    assert "premium" in plans
    assert "enterprise" in plans
    assert plans["free"]["token_limit"] == 81250
    assert plans["premium"]["token_limit"] == 406250
    assert plans["enterprise"]["token_limit"] == 2031250

def test_get_subscription_status():
    """Test getting user's subscription status."""
    response = client.get(
        "/subscription/status",
        headers={"X-User-Email": TEST_USER_EMAIL}
    )
    assert response.status_code == 200
    status = response.json()
    assert status["subscription_plan"] == "free"
    assert status["remaining_tokens"] == 81250
    assert status["token_limit"] == 81250
    assert status["used_storage_mb"] == 0
    assert status["storage_limit_mb"] == 100

def test_upgrade_subscription():
    """Test upgrading user's subscription plan."""
    # Mock the update response
    app.state.supabase.table().update().eq().execute.return_value = {
        "data": [{
            **TEST_USER_DATA,
            "subscription_plan": SubscriptionPlan.PREMIUM,
            "token_limit": 406250,
            "remaining_tokens": 406250,
            "storage_limit_mb": 500
        }]
    }
    
    response = client.post(
        "/subscription/upgrade",
        json={"plan": "premium"},
        headers={"X-User-Email": TEST_USER_EMAIL}
    )
    assert response.status_code == 200
    assert response.json()["message"] == "Successfully upgraded to premium plan"
    
    # Verify the upgrade
    status = client.get(
        "/subscription/status",
        headers={"X-User-Email": TEST_USER_EMAIL}
    ).json()
    assert status["subscription_plan"] == "premium"
    assert status["remaining_tokens"] == 406250
    assert status["token_limit"] == 406250
    assert status["storage_limit_mb"] == 500

def test_token_usage_check():
    """Test token usage check in middleware."""
    # First, verify user has enough tokens
    response = client.post(
        "/pmo/recommendations",
        json={
            "title": "Test Task",
            "description": "Test Description",
            "domain": "Test Domain",
            "stage": "input",
            "user_input": "Test input"
        },
        headers={"X-User-Email": TEST_USER_EMAIL}
    )
    assert response.status_code == 200
    assert "usage" in response.json()
    
    # Update user to have insufficient tokens
    app.state.supabase.table().update().eq().execute.return_value = {
        "data": [{
            **TEST_USER_DATA,
            "remaining_tokens": 1000
        }]
    }
    
    # Verify request is rejected
    response = client.post(
        "/pmo/recommendations",
        json={
            "title": "Test Task",
            "description": "Test Description",
            "domain": "Test Domain",
            "stage": "input",
            "user_input": "Test input"
        },
        headers={"X-User-Email": TEST_USER_EMAIL}
    )
    assert response.status_code == 403
    assert "Insufficient tokens" in response.json()["detail"]

def test_storage_usage_check():
    """Test storage usage check in middleware."""
    # Update user to have insufficient storage
    app.state.supabase.table().update().eq().execute.return_value = {
        "data": [{
            **TEST_USER_DATA,
            "used_storage_mb": 99
        }]
    }
    
    # Verify request is rejected
    response = client.post(
        "/pmo/recommendations",
        json={
            "title": "Test Task",
            "description": "Test Description",
            "domain": "Test Domain",
            "stage": "input",
            "user_input": "Test input"
        },
        headers={"X-User-Email": TEST_USER_EMAIL}
    )
    assert response.status_code == 403
    assert "Storage limit exceeded" in response.json()["detail"]

def test_token_usage_update():
    """Test token usage update after request."""
    # Make a request
    response = client.post(
        "/pmo/recommendations",
        json={
            "title": "Test Task",
            "description": "Test Description",
            "domain": "Test Domain",
            "stage": "input",
            "user_input": "Test input"
        },
        headers={"X-User-Email": TEST_USER_EMAIL}
    )
    assert response.status_code == 200
    
    # Get token usage from response
    usage = response.json()["usage"]
    tokens_used = usage["total_tokens"]
    
    # Verify tokens were deducted
    status = client.get(
        "/subscription/status",
        headers={"X-User-Email": TEST_USER_EMAIL}
    ).json()
    assert status["remaining_tokens"] == 81250 - tokens_used

def test_invalid_subscription_plan():
    """Test handling of invalid subscription plan."""
    response = client.post(
        "/subscription/upgrade",
        json={"plan": "invalid_plan"},
        headers={"X-User-Email": TEST_USER_EMAIL}
    )
    assert response.status_code == 422  # Validation error

def test_missing_user_email():
    """Test handling of missing user email header."""
    response = client.get("/subscription/status")
    assert response.status_code == 422  # Validation error

def test_nonexistent_user():
    """Test handling of nonexistent user."""
    # Mock empty response for nonexistent user
    app.state.supabase.table().select().eq().execute.return_value = {"data": []}
    
    response = client.get(
        "/subscription/status",
        headers={"X-User-Email": "nonexistent@example.com"}
    )
    assert response.status_code == 404
    assert "User not found" in response.json()["detail"] 