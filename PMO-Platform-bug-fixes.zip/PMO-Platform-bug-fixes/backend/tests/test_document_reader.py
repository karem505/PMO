import pytest
from fastapi.testclient import TestClient
from main import app
import os
import tempfile

client = TestClient(app)

def test_read_document():
    # Create a temporary test file
    with tempfile.NamedTemporaryFile(suffix=".txt", delete=False) as temp_file:
        temp_file.write(b"Test document content")
        temp_file_path = temp_file.name

    try:
        # Test file upload
        with open(temp_file_path, "rb") as file:
            response = client.post(
                "/api/documents/read",
                files={"file": ("test.txt", file, "text/plain")}
            )
        
        assert response.status_code == 200
        data = response.json()
        assert "filename" in data
        assert "data" in data
        assert data["filename"] == "test.txt"
        
    finally:
        # Clean up
        os.unlink(temp_file_path)

def test_read_document_no_file():
    response = client.post("/api/documents/read")
    assert response.status_code == 422  # Validation error

def test_read_document_invalid_file():
    with tempfile.NamedTemporaryFile(suffix=".exe", delete=False) as temp_file:
        temp_file.write(b"Invalid content")
        temp_file_path = temp_file.name

    try:
        with open(temp_file_path, "rb") as file:
            response = client.post(
                "/api/documents/read",
                files={"file": ("test.exe", file, "application/x-msdownload")}
            )
        
        assert response.status_code == 400  # Bad request
        
    finally:
        os.unlink(temp_file_path) 