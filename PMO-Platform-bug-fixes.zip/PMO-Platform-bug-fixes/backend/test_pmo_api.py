"""
Test script for the PMO recommendations API.
Run this script to test the API endpoint with the test email.
"""
import requests
import json
import os

BASE_URL = "http://127.0.0.1:3001"
TEST_EMAIL = ""

def get_token():
    """Get a test token for the test email."""
    response = requests.post(f"{BASE_URL}/api/v1/test-login")
    response.raise_for_status()
    data = response.json()
    return data["access_token"]

def test_token_auth():
    """Test the token authorization."""
    token = get_token()
    headers = {"Authorization": f"Bearer {token}"}
    response = requests.get(f"{BASE_URL}/debug/current-user", headers=headers)
    print("\n=== Token Authorization Test ===")
    print(f"Status: {response.status_code}")
    if response.status_code == 200:
        print(f"Response: {json.dumps(response.json(), indent=2)}")
    else:
        print(f"Error: {response.text}")
    return token

def test_header_auth():
    """Test the X-User-Email header authorization."""
    headers = {"X-User-Email": TEST_EMAIL}
    sample_data = {
        "title": "Test Task",
        "description": "Test description",
        "domain": "Testing",
        "stage": "input",
        "user_input": "This is a test user input for the PMO recommendations API."
    }
    response = requests.post(f"{BASE_URL}/pmo/recommendations", 
                            headers=headers,
                            json=sample_data)
    print("\n=== Header Authorization Test ===")
    print(f"Status: {response.status_code}")
    if response.status_code == 200:
        data = response.json()
        print("Success! Recommendations received.")
        print(f"Token usage: {data['usage']['total_tokens']} tokens")
        print(f"Task hash: {data['task_hash']}")
        print(f"First 100 chars of recommendations:\n{data['recommendations'][:100]}...")
    else:
        print(f"Error: {response.text}")

def test_token_based_auth():
    """Test the token-based authorization."""
    token = get_token()
    headers = {"Authorization": f"Bearer {token}"}
    sample_data = {
        "title": "Test Task with Token Auth",
        "description": "Test description",
        "domain": "Testing",
        "stage": "input",
        "user_input": "This is a test user input with token auth for the PMO recommendations API."
    }
    response = requests.post(f"{BASE_URL}/pmo/recommendations", 
                            headers=headers,
                            json=sample_data)
    print("\n=== Token-Based Authorization Test ===")
    print(f"Status: {response.status_code}")
    if response.status_code == 200:
        data = response.json()
        print("Success! Recommendations received.")
        print(f"Token usage: {data['usage']['total_tokens']} tokens")
        print(f"Task hash: {data['task_hash']}")
        print(f"First 100 chars of recommendations:\n{data['recommendations'][:100]}...")
    else:
        print(f"Error: {response.text}")

def check_token_usage():
    """Check the token usage for the test email."""
    response = requests.get(f"{BASE_URL}/subscription/status?user_email={TEST_EMAIL}")
    print("\n=== Token Usage Check ===")
    print(f"Status: {response.status_code}")
    if response.status_code == 200:
        data = response.json()
        print(f"Remaining tokens: {data['remaining_tokens']}")
        print(f"Has sufficient tokens: {data['has_sufficient_tokens']}")
    else:
        print(f"Error: {response.text}")

def main():
    """Run all tests."""
    print("Starting PMO API Tests...")
    
    # Check token usage before tests
    print("\n==== BEFORE TESTS ====")
    check_token_usage()
    
    # Test token authorization
    token = test_token_auth()
    
    # Run tests one by one with input
    while True:
        print("\n=== Available Tests ===")
        print("1. Test Header Auth")
        print("2. Test Token-Based Auth")
        print("3. Check Token Usage")
        print("4. Exit")
        
        choice = input("\nEnter your choice (1-4): ")
        
        if choice == "1":
            test_header_auth()
        elif choice == "2":
            test_token_based_auth()
        elif choice == "3":
            check_token_usage()
        elif choice == "4":
            break
        else:
            print("Invalid choice. Please try again.")
    
    print("\nTests completed.")

if __name__ == "__main__":
    main() 