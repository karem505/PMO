from pydantic import BaseModel
from typing import Dict, List, Optional

class DocumentRequest(BaseModel):
    extract_tables: bool = True
    extract_metadata: bool = True
    max_content_length: Optional[int] = None

class DocumentResponse(BaseModel):
    filename: str
    file_type: str
    content: str
    tables: List[Dict]
    metadata: Dict[str, str]

class DocumentError(BaseModel):
    detail: str 