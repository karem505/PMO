import sys
import os
import traceback
from services.pmo_rag_system import (
    do_web_search,
    synthesize_final_response, 
    Task, 
    CacheManager, 
    DebugLogger,
    TokenManager
)
from rich.console import Console

console = Console()

def test_web_search_and_synthesis():
    """Test the fixed web search and final synthesis functions together"""
    console.print("[bold green]Testing improved do_web_search and synthesize_final_response functions...[/bold green]")
    
    # Setup
    debug_logger = DebugLogger()
    cache_manager = CacheManager("cache")
    token_manager = TokenManager()
    
    # Create a simple task
    task = Task(
        title="Test Project Implementation",
        description="Implementing a new project management system",
        domain="Information Technology",
        stage="Planning",
        bestPractices=["Define clear objectives", "Establish communication plan"]
    )
    
    try:
        # Test web search first
        console.print("[bold blue]Running web search test...[/bold blue]")
        
        search_query = "project management best practices for IT projects"
        web_results = do_web_search(search_query, cache_manager, token_manager, debug_logger, k=3)
        
        if web_results and len(web_results) > 0:
            console.print(f"[bold green]Web search success! Found {len(web_results)} results[/bold green]")
            console.print(f"[blue]First result sample:[/blue] {web_results[0][:150]}...")
        else:
            console.print("[bold red]Error: Web search returned no results[/bold red]")
            return False
        
        # Now test synthesis with the web search results
        console.print("\n[bold blue]Running synthesis with web search results...[/bold blue]")
        
        # Create mock previous results including web search results
        previous_results = {
            "situation_analysis": f"The organization needs to implement a new project management system. Based on web search: {web_results[0][:300]}",
            "best_practices": f"Best practices include defining clear objectives and establishing a communication plan. Additional insights from web: {web_results[1][:300]}",
            "recommendations": "We recommend implementing the XYZ system with proper training for all staff.",
            "implementation_plan": "Phase 1: Setup and configuration. Phase 2: Training. Phase 3: Deployment."
        }
        
        # Run the synthesis function
        result = synthesize_final_response(previous_results, task)
        
        # Check if result was produced
        if result and len(result) > 100:
            console.print(f"[bold green]Synthesis success! Generated document with {len(result)} characters[/bold green]")
            console.print(f"[blue]First 200 characters:[/blue] {result[:200]}...")
            return True
        else:
            console.print("[bold red]Error: Generated document is too short or empty[/bold red]")
            return False
            
    except Exception as e:
        console.print(f"[bold red]Error in test: {str(e)}[/bold red]")
        traceback.print_exc()
        return False

if __name__ == "__main__":
    test_web_search_and_synthesis() 