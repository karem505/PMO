"""
Test script to check server configuration and ensure it can start properly.
This performs basic initialization without actually starting the full server.
"""

import os
import sys
import importlib.util

# Add current directory to path for imports
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.append(current_dir)
    print(f"Added {current_dir} to sys.path")

def check_module_exists(module_name):
    """Check if a module exists and can be imported."""
    try:
        importlib.import_module(module_name)
        return True
    except ImportError:
        return False

def check_file_exists(file_path):
    """Check if a file exists."""
    return os.path.exists(file_path)

def run_tests():
    """Run tests to verify server configuration."""
    print("=== Testing Server Configuration ===")
    
    # Check essential modules
    modules_to_check = [
        'fastapi', 
        'uvicorn', 
        'pydantic', 
        'jwt',
        'dotenv',
        'services.debug_logger'
    ]
    
    print("\nChecking modules:")
    for module in modules_to_check:
        exists = check_module_exists(module)
        status = "✅ Found" if exists else "❌ Missing"
        print(f"  {module}: {status}")
    
    # Check essential files
    files_to_check = [
        'main.py',
        'firebase_admin_setup.py',
        '.env'
    ]
    
    print("\nChecking files:")
    for file in files_to_check:
        exists = check_file_exists(file)
        status = "✅ Found" if exists else "❌ Missing"
        print(f"  {file}: {status}")
    
    # Try importing the app from main
    print("\nTrying to import FastAPI app from main:")
    try:
        from main import app
        print("  ✅ Successfully imported FastAPI app")
    except Exception as e:
        print(f"  ❌ Failed to import FastAPI app: {str(e)}")
        
    print("\n=== Testing complete ===")

if __name__ == "__main__":
    run_tests() 