import os
import re
import pickle
import sys

# Set environment variable to disable GPU FAISS
os.environ["FAISS_NO_GPU"] = "1"
from langchain_chroma import Chroma
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain.prompts import ChatPromptTemplate
from langchain.schema import StrOutputParser
from langchain_core.runnables import RunnablePassthrough
from langchain.text_splitter import RecursiveCharacterTextSplitter
from rich.console import Console
from rich.panel import Panel
from datetime import datetime
from typing import List, Optional, Dict
import json
from functools import lru_cache
import tiktoken
from .document_utils import (
    load_and_process_pdfs,
    split_by_paragraphs,
    save_to_supabase,
    deduplicate_and_consolidate_results,
)
from .web_crawling_agentic_workflow import RAGSystem
from .debug_logger import DebugLogger
import chromadb
import time
import requests
from urllib.parse import urlparse
import tempfile
from langchain.schema import Document

# Get the absolute path to the backend directory
BACKEND_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
DOCUMENTS_DIRECTORY = os.path.join(BACKEND_DIR, "documents")
CHROMA_PERSIST_DIRECTORY = os.path.join(BACKEND_DIR, "chroma_db")
OUTPUT_DIRECTORY = os.path.join(BACKEND_DIR, "outputs")

# Check if we're in a Render deployment environment
IN_RENDER = os.environ.get('RENDER') == 'true' or '/opt/render' in os.path.abspath(__file__)
if IN_RENDER:
    # Use a deployment-friendly path in /tmp which is typically writable
    RENDER_TMP = os.environ.get('TMPDIR', '/tmp')
    CACHE_DIRECTORY = os.path.join(RENDER_TMP, 'pmo_cache')
    print(f"Detected Render environment, using cache directory: {CACHE_DIRECTORY}")
else:
    CACHE_DIRECTORY = os.path.join(BACKEND_DIR, "cache")
    
# Create necessary directories
try:
    os.makedirs(CACHE_DIRECTORY, exist_ok=True)
    os.makedirs(DOCUMENTS_DIRECTORY, exist_ok=True)
    os.makedirs(CHROMA_PERSIST_DIRECTORY, exist_ok=True)
    os.makedirs(OUTPUT_DIRECTORY, exist_ok=True)
except Exception as dir_error:
    print(f"Warning: Could not create one or more directories: {dir_error}")
    # Fallback to /tmp for any directories that couldn't be created
    if not os.path.exists(CACHE_DIRECTORY):
        CACHE_DIRECTORY = os.path.join('/tmp', 'pmo_cache')
        os.makedirs(CACHE_DIRECTORY, exist_ok=True)

console = Console()


class TokenManager:
    def __init__(self):
        self.encoding = tiktoken.encoding_for_model("gpt-4o")
        self._cache = {}  # Simple token counting cache
        self._cache_max_size = 1000  # Maximum cache size

    def count_tokens(self, text: str) -> int:
        """Count tokens with caching to improve performance."""
        if not text:
            return 0

        # For very short texts, don't bother caching
        if len(text) < 50:
            return len(self.encoding.encode(text))

        # Check cache using a hash of the text
        text_hash = hash(text)
        if text_hash in self._cache:
            return self._cache[text_hash]

        # Count tokens for new text
        token_count = len(self.encoding.encode(text))

        # Clean cache if it's getting too large
        if len(self._cache) > self._cache_max_size:
            # Simple strategy: clear half the cache
            keys_to_keep = list(self._cache.keys())[-self._cache_max_size // 2 :]
            self._cache = {k: self._cache[k] for k in keys_to_keep}

        # Cache the result
        self._cache[text_hash] = token_count
        return token_count

    def chunk_text(self, text: str, max_tokens: int = 8000) -> List[str]:
        """Split text into chunks of maximum token size."""
        if not text:
            return []

        tokens = self.encoding.encode(text)
        chunks = []
        current_chunk = []
        current_length = 0

        for token in tokens:
            if current_length + 1 <= max_tokens:
                current_chunk.append(token)
                current_length += 1
            else:
                chunks.append(self.encoding.decode(current_chunk))
                current_chunk = [token]
                current_length = 1

        if current_chunk:
            chunks.append(self.encoding.decode(current_chunk))

        return chunks


class CacheManager:
    def __init__(self, cache_dir: str):
        self.cache_dir = cache_dir
        # Determine if we're in a deployment environment (like Render)
        self.in_deployment = os.environ.get('RENDER') == 'true' or '/opt/render' in self.cache_dir
        
        if self.in_deployment:
            # Use a deployment-friendly path in /tmp which is typically writable
            deployment_tmp = os.environ.get('TMPDIR', '/tmp')
            self.cache_dir = os.path.join(deployment_tmp, 'pmo_cache')
            print(f"Running in deployment environment, using cache directory: {self.cache_dir}")
        
        # Ensure cache directory exists
        try:
            os.makedirs(self.cache_dir, exist_ok=True)
        except Exception as dir_error:
            print(f"Warning: Failed to create cache directory: {dir_error}")
            # Fallback to /tmp in case of permission issues
            self.cache_dir = os.path.join('/tmp', 'pmo_cache')
            os.makedirs(self.cache_dir, exist_ok=True)
            
        self.cache_file = os.path.join(self.cache_dir, "rag_cache.json")
        self.cache = self._load_cache()
        self.modified = False
        self.last_save_time = time.time()
        self.save_interval = 30  # Save at most once every 30 seconds

    def _load_cache(self):
        """Load the cache from disk."""
        try:
            with open(self.cache_file, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError) as e:
            print(f"Error loading cache: {e}. Creating a new cache file.")
            # If there's a JSON decode error, back up the corrupted file
            if isinstance(e, json.JSONDecodeError) and os.path.exists(self.cache_file):
                backup_file = f"{self.cache_file}.corrupted_{int(time.time())}"
                try:
                    import shutil
                    shutil.copy2(self.cache_file, backup_file)
                    print(f"Backed up corrupted cache file to {backup_file}")
                except Exception as backup_error:
                    print(f"Failed to back up corrupted cache: {backup_error}")
            
            # Create a new empty cache file
            try:
                with open(self.cache_file, "w") as f:
                    json.dump({}, f)
                print(f"Created new cache file at {self.cache_file}")
            except Exception as create_error:
                print(f"Failed to create new cache file: {create_error}")
                
            # Return an empty cache regardless
            return {}
        except Exception as e:
            print(f"Unexpected error loading cache: {e}. Creating a new cache file.")
            return {}

    def _save_cache(self, force=False):
        """Safely save the cache to disk with error handling and throttling to reduce disk activity."""
        current_time = time.time()

        # Only save if the cache was modified and either forced or enough time has passed
        if self.modified and (
            force or (current_time - self.last_save_time) > self.save_interval
        ):
            try:
                # First save to a temporary file
                temp_file = f"{self.cache_file}.tmp"
                with open(temp_file, "w") as f:
                    json.dump(self.cache, f)

                # If successful, replace the original file
                import os
                if os.path.exists(temp_file):
                    import shutil
                    shutil.move(temp_file, self.cache_file)

                # Reset the modified flag and update last save time
                self.modified = False
                self.last_save_time = current_time

            except Exception as e:
                print(f"Error saving cache: {e}")
                # If there was an error, try a direct save as fallback
                try:
                    with open(self.cache_file, "w") as f:
                        json.dump(self.cache, f)
                    self.modified = False
                    self.last_save_time = current_time
                except Exception as direct_save_error:
                    print(f"Failed to save cache directly: {direct_save_error}")
                    # Don't raise exceptions for cache failures - just log them

    def get(self, key: str) -> Optional[str]:
        return self.cache.get(key)

    def set(self, key: str, value: str):
        try:
            # Only update cache and mark as modified if the value is different
            if key not in self.cache or self.cache[key] != value:
                self.cache[key] = value
                self.modified = True
                self._save_cache()
        except Exception as e:
            print(f"Error setting cache value: {e}")
            # Fail gracefully for cache operations

    def __del__(self):
        # Ensure cache is saved when object is destroyed
        if self.modified:
            self._save_cache(force=True)


class Task:
    def __init__(
        self,
        title: str,
        description: str,
        domain: str,
        stage: str,
        bestPractices: Optional[List[str]] = None,
    ):
        self.title = title
        self.description = description
        self.domain = domain
        self.stage = stage
        self.bestPractices = bestPractices if bestPractices else []


class QueryAnalyzer:
    def __init__(self, cache_manager: CacheManager):
        self.llm = ChatOpenAI(model="gpt-4o")
        self.cache_manager = cache_manager
        self.prompt = ChatPromptTemplate.from_template(
            """
        Analyze the following query and provide search terms:
        {user_input}
        """
        )

    @lru_cache(maxsize=100)
    def analyze(self, user_input: str, task: Task) -> dict:
        cache_key = f"analysis_{hash(user_input + task.title)}"
        cached_result = self.cache_manager.get(cache_key)
        if cached_result:
            return json.loads(cached_result)

        chain = self.prompt | self.llm | StrOutputParser()
        response = chain.invoke({"user_input": user_input})

        result = {
            "summary": response,
            "document_search_terms": [
                word for word in response.split() if len(word) > 3
            ],
            "web_search_queries": [
                f"{task.domain} {word}" for word in response.split() if len(word) > 3
            ],
            "special_attention": [],
        }

        self.cache_manager.set(cache_key, json.dumps(result))
        return result


def remove_special_characters(text: str) -> str:
    """
    Removes special characters, preserves original bullet points, and handles text formatting.
    Preserves Markdown formatting including headers and line breaks.
    """
    if not text:
        return text

    # First, split text by lines to preserve proper line breaks and handle each line separately
    lines = text.split('\n')
    processed_lines = []
    
    for line in lines:
        # Skip processing for Markdown header lines (starting with #)
        if re.match(r'^\s*#', line):
            processed_lines.append(line)
            continue
            
        # Step 1: Handle text formatting for this line
        # Convert *text* to bold
        line = re.sub(r"\*([^*\n]+)\*", r"**\1**", line)
        # Ensure consistent bold formatting (no extra asterisks)
        line = re.sub(r"\*\*+", "**", line)

        # Step 2: Remove dashes after bullet points while preserving the original bullet
        # This handles cases like "· - Text" or "* - Text" or "• - Text"
        line = re.sub(r"^([\s]*[·•*])[\s-]+", r"\1 ", line)

        # Step 3: Remove standalone special characters, but be careful with bullets
        # Only if they're not part of bullet points or markdown syntax
        
        # Only remove standalone asterisks if they're not part of a bullet list
        if not re.match(r'^\s*\*', line):  # If line doesn't start with a bullet
            line = re.sub(r" \* ", r" ", line)
            line = re.sub(r" \*$", r" ", line)
            line = re.sub(r"^\* ", r" ", line)
        
        # Remove standalone hyphens that aren't bullet points
        if not re.match(r'^\s*-', line):  # If line doesn't start with a hyphen bullet
            line = re.sub(r" - ", r" ", line)
            line = re.sub(r" -$", r" ", line)
            line = re.sub(r"^- ", r" ", line)

        # Step 4: Clean up extra whitespace within the line only
        line = re.sub(r"\s+", " ", line)
        line = re.sub(r"^\s+", "", line)
        line = re.sub(r"\s+$", "", line)
        
        processed_lines.append(line)
    
    # Join lines back with proper line breaks
    return '\n'.join(processed_lines)


def check_token_limits(
    user_input: str,
    task: Task,
    token_manager: TokenManager,
    max_tokens: int = 16384,  # Doubled the token limit
    prompt_buffer: int = 1750,
) -> tuple:

    # Count tokens in user input
    user_input_tokens = token_manager.count_tokens(user_input)

    # Count tokens in task data
    task_tokens = token_manager.count_tokens(
        f"{task.title} {task.description} {task.domain} {task.stage} {' '.join(task.bestPractices)}"
    )

    # Calculate estimated total with buffer
    estimated_total = user_input_tokens + task_tokens + prompt_buffer
    tokens_available = max_tokens - prompt_buffer - task_tokens

    # Check if we exceed the limit
    exceeds_limit = estimated_total > max_tokens

    return (exceeds_limit, user_input_tokens, tokens_available)


def process_input_with_token_check(
    domain_name: str, user_input: str, task: Task
) -> str:
    token_manager = TokenManager()
    exceeds_limit, tokens_used, tokens_available = check_token_limits(
        user_input, task, token_manager
    )

    if exceeds_limit:
        return f"""
        # Input Length Error
        
        Your input exceeds the maximum token limit.
        
        * Tokens used in your input: {tokens_used}
        * Maximum tokens available: {tokens_available}
        
        Please shorten your message by approximately {tokens_used - tokens_available} tokens and try again.
        
        Tips for shortening:
        * Focus on key information only
        * Remove redundant examples or details
        * Summarize lengthy descriptions
        * Split your request into multiple smaller requests
        """

    # If within limits, proceed with normal processing
    return get_pm_recommendations_multi_call(domain_name, user_input, task)


def get_stage_content(stage: str) -> dict:
    stage_info = {
        "input": {
            "template": """
This should include:
1. Assessment frameworks and methodologies
2. Data collection techniques and templates
3. Information gathering best practices
4. Stakeholder interview structures
5. Documentation formats for current state analysis
""",
            "guidance": """
        INPUT STAGE GUIDANCE:
        Focus on gathering comprehensive data about the current state.
        Use multiple data collection methods for triangulation.
        Ensure stakeholder representation across all relevant groups.
        Document all findings systematically for further analysis.
        """,
        },
        "processing": {
            "template": """
This should include:
1. Analysis methodologies and frameworks
2. Tools and techniques for processing information
3. Development approaches for creating frameworks
4. Methods for synthesizing gathered information
5. Techniques for identifying patterns and insights
""",
            "guidance": """
        PROCESSING STAGE GUIDANCE:
        Apply appropriate analytical frameworks to interpret gathered data.
        Identify patterns, trends, and relationships in the information.
        Develop preliminary recommendations based on analysis.
        Validate findings with key stakeholders before finalizing.
        """,
        },
        "output": {
            "template": """
This should include:
1. Implementation roadmap and approach
2. Deliverable templates and examples
3. Framework documentation standards
4. Monitoring and control mechanisms
5. Success metrics and evaluation criteria
""",
            "guidance": """
        OUTPUT STAGE GUIDANCE:
        Create clear implementation plans with specific action items.
        Define metrics and KPIs to measure success.
        Develop documentation that supports ongoing execution.
        Include change management approaches to facilitate adoption.
        """,
        },
        "default": {
            "template": """
This should include:
1. Practical implementation guidelines
2. Best practices and standards
3. Measurement and evaluation approaches
4. Continuous improvement mechanisms
5. Templates and examples where appropriate
""",
            "guidance": """
        GENERAL GUIDANCE:
        Ensure alignment with organizational strategy and objectives.
        Apply relevant best practices and standards.
        Consider implementation constraints and requirements.
        Include approaches for continuous improvement and iteration.
        """,
        },
    }

    return stage_info.get(stage, stage_info["default"])


def setup_embeddings():
    """Initialize and return OpenAI embeddings."""
    try:
        return OpenAIEmbeddings(api_key=OPENAI_API_KEY)
    except Exception as e:
        console.print(f"[bold red]Error initializing embeddings: {e}[/bold red]")
        exit(1)


def load_existing_vector_db():
    """Load existing vector database if it exists."""
    if not os.path.exists(CHROMA_PERSIST_DIRECTORY):
        console.print(
            "[bold yellow]No existing vector database found. Setting up new database...[/bold yellow]"
        )
        return setup_vector_db()

    console.print(
        f"Loading existing vector database from [bold blue]{CHROMA_PERSIST_DIRECTORY}[/bold blue]"
    )

    try:
        embeddings = setup_embeddings()
        console.print("[bold green]Loading vector database...[/bold green]")
        # Use client settings to optimize for concurrent access
        client_settings = chromadb.config.Settings(
            anonymized_telemetry=False,  # Disable telemetry
            persist_directory=CHROMA_PERSIST_DIRECTORY,
        )

        # Vacuum the database to optimize performance if needed
        if os.path.exists(os.path.join(CHROMA_PERSIST_DIRECTORY, "chroma.sqlite3")):
            vacuum_database()

        vectordb = Chroma(
            persist_directory=CHROMA_PERSIST_DIRECTORY,
            embedding_function=embeddings,
            client_settings=client_settings,
        )
        console.print("[bold green]Successfully loaded vector database.[/bold green]")
        return vectordb
    except Exception as e:
        console.print(f"[bold red]Error loading vector database: {e}[/bold red]")
        console.print("[bold yellow]Setting up new database...[/bold yellow]")
        return setup_vector_db()


def vacuum_database():
    """Vacuum the SQLite database to optimize performance."""
    import sqlite3

    try:
        db_path = os.path.join(CHROMA_PERSIST_DIRECTORY, "chroma.sqlite3")
        console.print(
            "[bold blue]Vacuuming database to optimize performance...[/bold blue]"
        )

        # Connect to the database and vacuum
        conn = sqlite3.connect(db_path)
        conn.execute("VACUUM")
        conn.close()

        console.print("[bold green]Database vacuumed successfully.[/bold green]")
    except Exception as e:
        console.print(
            f"[bold yellow]Warning: Failed to vacuum database: {e}[/bold yellow]"
        )
        # Continue even if vacuum fails - this is just an optimization


def setup_vector_db():
    """Set up the vector database with documents."""
    embeddings = setup_embeddings()

    console.print("[bold green]Loading documents...[/bold green]")
    documents = load_and_process_pdfs(DOCUMENTS_DIRECTORY)
    if not documents:
        console.print(
            "[bold red]No documents were loaded. Please add documents to the documents directory.[/bold red]"
        )
        exit(1)

    console.print(
        f"Loaded [bold green]{len(documents)}[/bold green] document pages in total."
    )

    console.print("[bold green]Processing documents...[/bold green]")
    paragraph_chunks = split_by_paragraphs(documents)

    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=4000,
        chunk_overlap=400,
        separators=["\n\n", "\n", " ", ""],
        length_function=len,
    )
    refined_chunks = text_splitter.split_documents(paragraph_chunks)

    console.print(
        f"After refinement: [bold green]{len(refined_chunks)}[/bold green] chunks."
    )

    console.print("[bold green]Creating vector store...[/bold green]")
    vectordb = Chroma.from_documents(
        documents=refined_chunks,
        embedding=embeddings,
        persist_directory=CHROMA_PERSIST_DIRECTORY,
    )

    # Save the database
    vectordb.persist()

    console.print(
        f"Vector database stored in [bold blue]{CHROMA_PERSIST_DIRECTORY}[/bold blue]"
    )
    console.print("[bold green]Vector database created successfully.[/bold green]")

    return vectordb


def get_rag_output(domain_name: str, vectordb, cache_manager: CacheManager) -> str:
    """Retrieve RAG output with caching."""
    cache_key = f"rag_{domain_name}"
    cached_result = cache_manager.get(cache_key)
    if cached_result:
        return cached_result

    try:
        query = f"Best practices for {domain_name} in Project Management"
        docs = vectordb.similarity_search(query, k=5)

        # Check if docs exists and has content before processing
        if not docs:
            return "No documents found for this domain."

        # Handle documents safely
        valid_docs = [doc for doc in docs if hasattr(doc, "page_content")]

        if not valid_docs:
            return "No valid documents found for this domain."

        # Simple consolidation of document contents
        consolidated_content = "\n\n".join([doc.page_content for doc in valid_docs])

        cache_manager.set(cache_key, consolidated_content)
        return consolidated_content
    except Exception as e:
        debug_logger.log_error(e, f"Error in RAG output for domain: {domain_name}")
        return f"Error retrieving documents for {domain_name}: {str(e)}"


def create_fallback_response(
    user_input: str, task: Task, cache_manager: CacheManager
) -> str:
    """Create fallback response when normal processing fails."""
    console.print(
        Panel(
            "Creating fallback response",
            title="Fallback Processing",
            style="bold yellow",
        )
    )

    llm = ChatOpenAI(model="gpt-4o")

    # Create a simplified but structured prompt for fallback
    fallback_prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                """You are a senior PMO consultant providing recommendations based on best practices.
        
        Structure your response as follows:
        
        # Executive Summary
        [Brief summary of recommendations]
        
        # Situation Analysis
        [Analysis based on available information]
        
        # Best Practices Implementation
        [Application of provided best practices]
        
        # Key Recommendations
        [Core actionable recommendations]
        
        # Implementation Steps
        [High-level implementation plan]
        
        Keep the response focused and practical.""",
            ),
            (
                "human",
                """Task: {task_description}
        Domain: {domain}
        Stage: {stage}
        Best Practices:
        {best_practices}
        
        User Input:
        {user_input}
        
        Please provide recommendations based on this information.""",
            ),
        ]
    )

    # Create the chain
    chain = fallback_prompt | llm | StrOutputParser()

    # Prepare input
    chain_input = {
        "task_description": task.description,
        "domain": task.domain,
        "stage": task.stage,
        "best_practices": "\n".join(f"- {bp}" for bp in task.bestPractices),
        "user_input": user_input,
    }

    try:
        response = chain.invoke(chain_input)
        response = remove_special_characters(response)
        response = remove_special_characters(response)
        return response
    except Exception as e:
        console.print(f"[bold red]Error in fallback response: {e}[/bold red]")
        return """# Error in Processing
        
        We apologize, but an error occurred while processing your request. Please try again with the following adjustments:
        
        1. Provide more specific information about your needs
        2. Break down complex queries into smaller parts
        3. Ensure all required information is included
        
        If the problem persists, please contact support."""


# New modular API call functions


def gather_input_data(
    domain_name: str, user_input: str, task: Task, related_documents: list = None
):
    """First API call: Gather all necessary data from various sources."""
    debug_logger = DebugLogger()
    cache_manager = CacheManager(CACHE_DIRECTORY)

    try:
        debug_logger.add_step(
            "Initialization", f"Starting data gathering for domain: {domain_name}"
        )

        # First check cache - if we have this exact input before, use cached results
        cache_key = f"gather_input_{hash(user_input)}_{domain_name}_{task.stage}"
        cached_result = cache_manager.get(cache_key)
        if cached_result:
            print("Using cached input data")
            return json.loads(cached_result)

        # Process related documents if provided
        extracted_documents = []
        document_texts = []
        if related_documents and len(related_documents) > 0:
            # Filter out empty or invalid URLs
            valid_documents = [doc for doc in related_documents if doc and isinstance(doc, str) and doc.strip() and doc != "[]"]
            
            if valid_documents:
                console.print(
                    Panel(
                        f"Processing {len(valid_documents)} related documents",
                        title="Related Documents",
                        style="bold blue",
                    )
                )
                debug_logger.add_section("Document Processing")

                # OPTIMIZATION: Process documents in batches to reduce memory usage
                max_batch_size = 3  # Process at most 3 documents at a time
                for batch_start in range(0, len(valid_documents), max_batch_size):
                    batch_end = min(batch_start + max_batch_size, len(valid_documents))
                    batch = valid_documents[batch_start:batch_end]

                    # Create a temp directory for downloaded files
                    with tempfile.TemporaryDirectory() as temp_dir:
                        for i, doc_url in enumerate(batch):
                            try:
                                print(
                                    f"Processing document {batch_start + i + 1}/{len(valid_documents)}: {doc_url}"
                                )

                                # Handle different URL formats and clean up
                                url_to_process = doc_url
                                if (
                                    isinstance(url_to_process, list)
                                    and len(url_to_process) > 0
                                ):
                                    url_to_process = url_to_process[0]
                                if isinstance(url_to_process, str):
                                    url_to_process = url_to_process.strip("[]\"' ")
                                    
                                if not url_to_process or not isinstance(url_to_process, str) or not url_to_process.startswith("http"):
                                    print(f"Skipping invalid URL: {url_to_process}")
                                    continue

                                # Download and process the file
                                parsed_url = urlparse(url_to_process)
                                filename = (
                                    os.path.basename(parsed_url.path)
                                    or f"document_{batch_start + i}.pdf"
                                )
                                local_path = os.path.join(temp_dir, filename)

                                # Set a timeout for document downloads
                                timeout = (10, 30)  # (connect timeout, read timeout)
                                try:
                                    response = requests.get(url_to_process, stream=True, timeout=timeout)
                                    response.raise_for_status()
                                except requests.exceptions.HTTPError as http_err:
                                    print(f"HTTP error occurred while downloading document: {http_err}")
                                    debug_logger.log_error(http_err, f"HTTP error for URL: {url_to_process}")
                                    continue
                                except requests.exceptions.ConnectionError as conn_err:
                                    print(f"Connection error occurred while downloading document: {conn_err}")
                                    debug_logger.log_error(conn_err, f"Connection error for URL: {url_to_process}")
                                    continue
                                except requests.exceptions.Timeout as timeout_err:
                                    print(f"Timeout occurred while downloading document: {timeout_err}")
                                    debug_logger.log_error(timeout_err, f"Timeout error for URL: {url_to_process}")
                                    continue
                                except requests.exceptions.RequestException as req_err:
                                    print(f"Request exception occurred while downloading document: {req_err}")
                                    debug_logger.log_error(req_err, f"Request error for URL: {url_to_process}")
                                    continue

                                with open(local_path, "wb") as f:
                                    # Download in chunks to reduce memory usage
                                    for chunk in response.iter_content(chunk_size=8192):
                                        f.write(chunk)

                                # Process based on file type
                                file_ext = os.path.splitext(filename)[1].lower()
                                batch_docs = []
                                batch_text = ""

                                if file_ext == ".pdf":
                                    from langchain_community.document_loaders import (
                                        PyPDFLoader,
                                    )

                                    loader = PyPDFLoader(local_path)
                                    pages = loader.load()
                                    batch_docs.extend(pages)
                                    for page in pages:
                                        batch_text += page.page_content + "\n\n"
                                elif file_ext in [".docx", ".doc"]:
                                    from langchain_community.document_loaders import (
                                        Docx2txtLoader,
                                    )

                                    loader = Docx2txtLoader(local_path)
                                    pages = loader.load()
                                    batch_docs.extend(pages)
                                    for page in pages:
                                        batch_text += page.page_content + "\n\n"
                                elif file_ext == ".txt":
                                    with open(local_path, "r", encoding="utf-8") as f:
                                        doc_text = f.read()
                                    doc = Document(
                                        page_content=doc_text,
                                        metadata={"source": doc_url, "file_type": "txt"},
                                    )
                                    batch_docs.append(doc)
                                    batch_text += doc_text + "\n\n"

                                # Add batch results to main lists
                                extracted_documents.extend(batch_docs)
                                document_texts.append(batch_text)

                                # Clean up temp files immediately after processing
                                try:
                                    os.remove(local_path)
                                except:
                                    pass

                            except requests.exceptions.HTTPError as http_err:
                                print(f"HTTP error occurred while downloading document: {http_err}")
                                debug_logger.log_error(http_err, f"HTTP error for URL: {url_to_process}")
                                continue
                            except requests.exceptions.ConnectionError as conn_err:
                                print(f"Connection error occurred while downloading document: {conn_err}")
                                debug_logger.log_error(conn_err, f"Connection error for URL: {url_to_process}")
                                continue
                            except requests.exceptions.Timeout as timeout_err:
                                print(f"Timeout occurred while downloading document: {timeout_err}")
                                debug_logger.log_error(timeout_err, f"Timeout error for URL: {url_to_process}")
                                continue
                            except requests.exceptions.RequestException as req_err:
                                print(f"Request exception occurred while downloading document: {req_err}")
                                debug_logger.log_error(req_err, f"Request error for URL: {url_to_process}")
                                continue
                            except Exception as e:
                                debug_logger.log_error(e, f"Error processing document: {doc_url}")
                                print(f"Unexpected error processing document: {e}")
                                continue

        # Get RAG output with combined documents
        vectordb = load_existing_vector_db()
        if extracted_documents:
            # Add extracted documents to temporary vector database
            text_splitter = RecursiveCharacterTextSplitter(
                chunk_size=4000,
                chunk_overlap=400,
                separators=["\n\n", "\n", " ", ""],
                length_function=len,
            )
            refined_chunks = text_splitter.split_documents(extracted_documents)

            # Create temporary combined vector database
            embeddings = OpenAIEmbeddings(api_key=OPENAI_API_KEY)
            try:
                base_docs = vectordb.similarity_search(
                    f"Project management best practices for {domain_name} {task.stage}",
                    k=20,
                )
                all_documents = base_docs + refined_chunks
                vectordb = Chroma.from_documents(
                    documents=all_documents,
                    embedding=embeddings,
                    collection_name="temp_collection",
                )
            except Exception as e:
                debug_logger.log_error(
                    e, "Error combining documents, using base vector database"
                )

        rag_output = get_rag_output(domain_name, vectordb, cache_manager)

        # Add document texts to RAG output if available
        if document_texts:
            combined_doc_text = (
                "\n\n=== RELATED DOCUMENT CONTENT ===\n\n"
                + "\n\n---\n\n".join(document_texts)
            )
            rag_output = rag_output + "\n\n" + combined_doc_text

        # Get web search results
        query_analyzer = QueryAnalyzer(cache_manager)
        analysis = query_analyzer.analyze(user_input, task)

        web_results = []
        for query in analysis["web_search_queries"][:3]:
            cache_key = f"web_{hash(query)}"
            cached_result = cache_manager.get(cache_key)
            if cached_result:
                web_results.append(cached_result)
            else:
                try:
                    web_rag = RAGSystem(save_to_file=True)
                    result = web_rag.search(query)
                    web_results.append(result)
                    cache_manager.set(cache_key, result)
                except Exception as e:
                    debug_logger.log_error(e, f"Error in web search for query: {query}")
                    web_results.append(f"Error retrieving web results for {query}.")

        # Combine and return results
        gathered_data = {
            "rag_output": rag_output,
            "web_results": web_results,
            "analysis": analysis,
        }

        # Cache the results
        try:
            cache_manager.set(cache_key, json.dumps(gathered_data))
        except Exception as cache_error:
            print(f"Warning: Failed to cache gathered data: {cache_error}")

        return gathered_data
    except Exception as e:
        debug_logger.log_error(e, "Error in gather_input_data")
        console.print(f"[bold red]Error gathering input data: {e}[/bold red]")
        return {
            "rag_output": "Error retrieving documents: " + str(e),
            "web_results": ["Error retrieving web results."],
            "analysis": {"summary": "Error analyzing query."},
        }


def process_situation_analysis(gathered_data: dict, user_input: str, task: Task):
    """Second API call: Generate situation analysis based on gathered data."""
    debug_logger = DebugLogger()
    cache_manager = CacheManager(CACHE_DIRECTORY)

    try:
        # Check cache first
        cache_key = f"situation_{hash(user_input)}_{task.domain}_{task.stage}"
        cached_result = cache_manager.get(cache_key)
        if cached_result:
            return {"situation_analysis": cached_result}

        # Prepare task context
        task_context = f"""
        Domain: {task.domain}
        Stage: {task.stage}
        Title: {task.title}
        Description: {task.description}
        Best Practices: {', '.join(task.bestPractices)}
        """

        # Process situation analysis
        situation_content = f"""
        User Input: {user_input}
        RAG Analysis: {gathered_data['rag_output']}
        Web Research: {' '.join(gathered_data['web_results'])}
        """

        # Create prompt for situation analysis
        prompt = ChatPromptTemplate.from_template(
            f"""
        {task_context}
        
        Analyze the current situation based on the following information:
        {situation_content}
        
        Focus on identifying key challenges, opportunities, and context.
        Provide a comprehensive analysis of 500-1000 words.
        """
        )

        # Run the LLM chain
        chain = prompt | ChatOpenAI(model="gpt-4o", max_tokens=8192) | StrOutputParser()
        situation_analysis = chain.invoke({})
        situation_analysis = remove_special_characters(situation_analysis)
        situation_analysis = remove_special_characters(situation_analysis)

        # Cache the result
        cache_manager.set(cache_key, situation_analysis)

        return {"situation_analysis": situation_analysis}
    except Exception as e:
        debug_logger.log_error(e, "Error in process_situation_analysis")
        console.print(f"[bold red]Error processing situation analysis: {e}[/bold red]")
        return {"situation_analysis": "Error generating situation analysis."}


def process_best_practices(previous_results: dict, task: Task):
    """Third API call: Analyze best practices application based on situation."""
    debug_logger = DebugLogger()
    cache_manager = CacheManager(CACHE_DIRECTORY)

    try:
        # Extract situation analysis from previous results
        situation_analysis = previous_results.get(
            "situation_analysis", "No situation analysis available."
        )

        # Check cache first
        cache_key = (
            f"best_practices_{hash(situation_analysis)}_{task.domain}_{task.stage}"
        )
        cached_result = cache_manager.get(cache_key)
        if cached_result:
            previous_results["best_practices_analysis"] = cached_result
            return previous_results

        # Prepare task context
        task_context = f"""
        Domain: {task.domain}
        Stage: {task.stage}
        Title: {task.title}
        Description: {task.description}
        """

        # Create implementation plans for each best practice separately
        best_practices_implementations = []

        for practice in task.bestPractices:
            # Create prompt for best practice implementation
            practice_prompt = ChatPromptTemplate.from_template(
                f"""
            {task_context}
            
            Best Practice to Implement: {practice}
            
            Current Situation Summary:
            {situation_analysis}
            
            Implement what is there in the best practices (e.g: if SWOT analysis is required in the best practices, go ahead and conduct a swot analysis based on the user input):
            1. Concrete implementation steps
            2. Required resources and tools
            3. Timeline and milestones
            4. Responsible roles and accountability
            5. Success metrics and measurement approach
            
            Do not explain what the best practice is - focus entirely on implementing it.
            Provide detailed implementation of the best practices.
            Do NOT use numbered list, use bullet points.
            """
            )

            # Run the LLM chain for each practice
            practice_chain = (
                practice_prompt | ChatOpenAI(model="gpt-4o", max_tokens=8192) | StrOutputParser()
            )
            implementation = practice_chain.invoke({})
            implementation = remove_special_characters(implementation)
            implementation = remove_special_characters(implementation)

            # Add to the list with the practice title
            best_practices_implementations.append(f"### {practice}\n\n{implementation}")

        # Combine all implementations
        best_practices_analysis = "\n\n".join(best_practices_implementations)

        # Cache the result
        cache_manager.set(cache_key, best_practices_analysis)

        # Update results dictionary
        previous_results["best_practices_analysis"] = best_practices_analysis

        return previous_results
    except Exception as e:
        debug_logger.log_error(e, "Error in process_best_practices")
        console.print(f"[bold red]Error processing best practices: {e}[/bold red]")
        previous_results["best_practices_analysis"] = (
            "Error analyzing best practices application."
        )
        return previous_results


def generate_recommendations(previous_results: dict, task: Task):
    """Fourth API call: Generate recommendations based on analyses."""
    debug_logger = DebugLogger()
    cache_manager = CacheManager(CACHE_DIRECTORY)

    try:
        # Extract analyses from previous results
        situation_analysis = previous_results.get(
            "situation_analysis", "No situation analysis available."
        )
        best_practices_analysis = previous_results.get(
            "best_practices_analysis", "No best practices analysis available."
        )

        # Check cache first
        cache_key = f"recommendations_{hash(situation_analysis + best_practices_analysis)}_{task.domain}"
        cached_result = cache_manager.get(cache_key)
        if cached_result:
            previous_results["recommendations"] = cached_result
            return previous_results

        # Prepare task context
        task_context = f"""
        Domain: {task.domain}
        Stage: {task.stage}
        Title: {task.title}
        Description: {task.description}
        """

        # Create recommendations content
        recommendations_content = f"""
        Situation Analysis Summary:
        {situation_analysis}  # Use part of situation analysis
        
        Best Practices Analysis Summary:
        {best_practices_analysis}  # Use part of best practices analysis
        """

        # Create prompt for recommendations
        prompt = ChatPromptTemplate.from_template(
            f"""
        {task_context}
        
        Based on the previous analyses, generate specific recommendations:
        {recommendations_content}
        
        For each recommendation:
        1. Provide a clear title and description
        2. Explain the rationale behind it
        3. Identify expected benefits
        4. Discuss potential risks and mitigation strategies
        
        Generate at least 5 high-impact recommendations.
        Do NOT use numbered list, use bullet points.

        """
        )

        # Run the LLM chain
        chain = prompt | ChatOpenAI(model="gpt-4o", max_tokens=8192) | StrOutputParser()
        recommendations = chain.invoke({})
        recommendations = remove_special_characters(recommendations)
        recommendations = remove_special_characters(recommendations)
        # Cache the result
        cache_manager.set(cache_key, recommendations)

        # Update results dictionary
        previous_results["recommendations"] = recommendations

        return previous_results
    except Exception as e:
        debug_logger.log_error(e, "Error in generate_recommendations")
        console.print(f"[bold red]Error generating recommendations: {e}[/bold red]")
        previous_results["recommendations"] = "Error generating recommendations."
        return previous_results


def create_implementation_plan(previous_results: dict, task: Task):
    """Fifth API call: Create implementation plan for recommendations."""
    debug_logger = DebugLogger()
    cache_manager = CacheManager(CACHE_DIRECTORY)

    try:
        # Extract recommendations from previous results
        recommendations = previous_results.get(
            "recommendations", "No recommendations available."
        )

        # Check cache first
        cache_key = f"implementation_{hash(recommendations)}_{task.domain}_{task.stage}"
        cached_result = cache_manager.get(cache_key)
        if cached_result:
            previous_results["implementation_plan"] = cached_result
            return previous_results

        # Prepare task context
        task_context = f"""
        Domain: {task.domain}
        Stage: {task.stage}
        Title: {task.title}
        Description: {task.description}
        """

        # Create implementation content
        implementation_content = f"""
        Key Recommendations:
        {recommendations}
        
        Context:
        {task_context}
        """

        # Create prompt for implementation plan
        prompt = ChatPromptTemplate.from_template(
            f"""
        {task_context}
        
        Create an implementation plan for the recommendations:
        {implementation_content}
        
        Include:
        1. Detailed timeline with specific milestones
        2. Resource requirements (personnel, tools, budget)
        3. Success metrics and evaluation criteria
        4. Governance structure and reporting mechanisms
        5. Risk management approach

        Do NOT use numbered list, use bullet points.

        """
        )

        # Run the LLM chain
        chain = prompt | ChatOpenAI(model="gpt-4o", max_tokens=8192) | StrOutputParser()
        implementation_plan = chain.invoke({})
        implementation_plan = remove_special_characters(implementation_plan)

        implementation_plan = remove_special_characters(implementation_plan)

        # Cache the result
        cache_manager.set(cache_key, implementation_plan)

        # Update results dictionary
        previous_results["implementation_plan"] = implementation_plan

        return previous_results
    except Exception as e:
        debug_logger.log_error(e, "Error in create_implementation_plan")
        console.print(f"[bold red]Error creating implementation plan: {e}[/bold red]")
        previous_results["implementation_plan"] = "Error creating implementation plan."
        return previous_results


def synthesize_final_response(previous_results: dict, task: Task):
    """Sixth API call: Synthesize all sections into final response with detailed best practices implementation."""
    debug_logger = DebugLogger()
    cache_manager = CacheManager(CACHE_DIRECTORY)
    token_manager = TokenManager()

    try:
        # Prepare all sections - don't truncate these
        situation_analysis = previous_results.get(
            "situation_analysis", "No situation analysis available."
        )
        best_practices_analysis = previous_results.get(
            "best_practices_analysis", "No best practices analysis available."
        )
        recommendations = previous_results.get(
            "recommendations", "No recommendations available."
        )
        implementation_plan = previous_results.get(
            "implementation_plan", "No implementation plan available."
        )

        # Check cache first
        cache_key = f"synthesis_{hash(situation_analysis + best_practices_analysis + recommendations + implementation_plan)}"
        cached_result = cache_manager.get(cache_key)
        if cached_result:
            return cached_result

        # Process each section with separate LLM calls to ensure comprehensive output
        llm = ChatOpenAI(model="gpt-4o", max_tokens=8192)

        # Executive Summary
        exec_summary_prompt = ChatPromptTemplate.from_template(
            f"""
        Create a comprehensive executive summary for a PMO consultation document and do not add the section title in your response and do not add the section title in your response.
        
        Task: {task.title}
        Domain: {task.domain}
        Stage: {task.stage}
        
        Use the following input to create your executive summary and do not add the section title in your response:
        
        Situation Analysis: {situation_analysis}
        Best Practices Implementation: {best_practices_analysis}
        Recommendations: {recommendations}
        Implementation: {implementation_plan}
        
        The executive summary should be comprehensive, highlighting all key findings and the specific 
        implementation approaches for each best practice. Focus on concrete actions and outcomes.
        
        IMPORTANT: Use bullet points instead of numbered lists for any lists you create.
        """
        )

        # Situation Analysis
        situation_prompt = ChatPromptTemplate.from_template(
            f"""
        Create an extremely detailed and comprehensive situation analysis section and do not add the section title in your response.
        
        Task: {task.title}
        Domain: {task.domain}
        Stage: {task.stage}
        
        Expand upon this situation analysis with additional insights, context, and implications:
        {situation_analysis}
        
        Make sure to explore all aspects of the current situation in great detail, providing context, 
        background, and specific observations. Use proper markdown formatting with headers (## for main headers, ### for subheaders) 
        and subheaders.
        
        Include all relevant data points from user input and research.
        
        IMPORTANT: Use bullet points instead of numbered lists for any lists you create.
        """
        )

        # Recommendations section
        recommendations_prompt = ChatPromptTemplate.from_template(
            f"""
        Create a detailed recommendations section that builds upon the best practices implementation and do not add the section title in your response.
        
        Task: {task.title}
        Domain: {task.domain}
        Stage: {task.stage}
        
        Use these recommendations as your foundation:
        {recommendations}
        
        For each recommendation:
        * Provide specific implementation guidance
        * Connect to the best practices being implemented
        * Include concrete examples and use cases
        * Specify measurable outcomes
        
        Focus on practical implementation rather than theoretical explanation.
        
        IMPORTANT: Use bullet points instead of numbered lists for any lists you create. Use proper markdown formatting with headers 
        (## for main headers, ### for subheaders).
        """
        )

        # Implementation Timeline section
        implementation_prompt = ChatPromptTemplate.from_template(
            f"""
        Create an extremely detailed implementation timeline section (minimum 3000 words) and do not add the section title in your response.
        
        Task: {task.title}
        Domain: {task.domain}
        Stage: {task.stage}
        
        Use this implementation plan as your foundation:
        {implementation_plan}
        
        Create a comprehensive timeline that includes:
        * Phased implementation approach with specific dates
        * Detailed resource allocation plan
        * Dependencies between activities
        * Milestones and checkpoints
        * Governance and oversight mechanisms
        
        Focus on practical timelines, resources, and governance - not theoretical explanations.
        
        IMPORTANT: Use bullet points instead of numbered lists for any lists you create. Use proper markdown formatting with headers 
        (## for main headers, ### for subheaders).
        """
        )

        # Risk Management section
        risk_prompt = ChatPromptTemplate.from_template(
            f"""
        Create a detailed risk management section and do not add the section title in your response.
        
        Task: {task.title}
        Domain: {task.domain}
        Stage: {task.stage}
        
        Based on the situation analysis and implementation plan:
        {situation_analysis}
        {implementation_plan}
        
        Identify potential risks and develop mitigation strategies:
        * Create a comprehensive risk register with likelihood and impact
        * Develop specific mitigation strategies for each high-priority risk
        * Establish monitoring mechanisms and contingency plans
        * Define risk ownership and escalation paths
        
        Focus on practical risk management approaches - not theoretical explanations.
        
        IMPORTANT: Use bullet points instead of numbered lists for any lists you create. Use proper markdown formatting with headers 
        (## for main headers, ### for subheaders).
        """
        )

        # Conclusion with Next Steps
        conclusion_prompt = ChatPromptTemplate.from_template(
            f"""
        Create a detailed conclusion section with extensive next steps and do not add the section title in your response.
        
        Task: {task.title}
        Domain: {task.domain}
        Stage: {task.stage}
        
        Based on all sections, create a conclusion that:
        * Summarizes the key implementation approaches
        * Provides immediate next steps (first 30 days)
        * Establishes success criteria and measurement approach
        * Outlines ongoing governance and review process
        
        Focus on actionable next steps rather than theoretical summaries.
        
        IMPORTANT: Use bullet points instead of numbered lists for any lists you create. Use proper markdown formatting with headers 
        (## for main headers, ### for subheaders).
        """
        )

        # Execute LLM calls in sequence
        exec_summary = exec_summary_prompt | llm | StrOutputParser()
        situation_section = situation_prompt | llm | StrOutputParser()
        recommendations_section = recommendations_prompt | llm | StrOutputParser()
        implementation_section = implementation_prompt | llm | StrOutputParser()
        risk_section = risk_prompt | llm | StrOutputParser()
        conclusion_section = conclusion_prompt | llm | StrOutputParser()

        # Generate each section
        exec_summary_content = exec_summary.invoke({})
        situation_content = situation_section.invoke({})
        recommendations_content = recommendations_section.invoke({})
        implementation_content = implementation_section.invoke({})
        risk_content = risk_section.invoke({})
        conclusion_content = conclusion_section.invoke({})

        # Keep the best practices implementation as is - don't reprocess it
        best_practices_content = best_practices_analysis

        # Combine into the final document with proper structure
        final_document = f"""
        # {task.title}: Comprehensive PMO Consultation Document
        
        ## Executive Summary
        
        {exec_summary_content}
        
        ## Table of Contents
        
        * Situation Analysis
        * Best Practices Implementation
        * Recommendations
        * Implementation Timeline
        * Risk Management
        * Conclusion and Next Steps
        
        ## Situation Analysis
        
        {situation_content}
        
        ## Best Practices Implementation
        
        {best_practices_content}
        
        ## Recommendations
        
        {recommendations_content}
        
        ## Implementation Timeline
        
        {implementation_content}
        
        ## Risk Management
        
        {risk_content}
        
        ## Conclusion and Next Steps
        
        {conclusion_content}

        """

        # Cache the result
        cache_manager.set(cache_key, final_document)

        return final_document
    except Exception as e:
        debug_logger.log_error(e, "Error in synthesize_final_response")
        console.print(f"[bold red]Error synthesizing final response: {e}[/bold red]")
        return """# Error in Final Synthesis

We apologize, but there was an error synthesizing the final response. However, here's what we've gathered so far:

## Situation Analysis
{situation_analysis}

## Best Practices Implementation
{best_practices_analysis}

## Recommendations
{recommendations}

## Implementation Plan
{implementation_plan}
""".format(
            situation_analysis=previous_results.get(
                "situation_analysis", "No situation analysis available."
            ),
            best_practices_analysis=previous_results.get(
                "best_practices_analysis", "No best practices analysis available."
            ),
            recommendations=previous_results.get(
                "recommendations", "No recommendations available."
            ),
            implementation_plan=previous_results.get(
                "implementation_plan", "No implementation plan available."
            ),
        )


def is_arabic_text(text: str) -> bool:
    """
    Check if the provided text contains Arabic characters.
    Returns True if a significant portion of the text is in Arabic.
    """
    try:
        # Handle None or non-string inputs
        if not text or not isinstance(text, str):
            return False
            
        # Arabic Unicode ranges
        # Basic Arabic: \u0600-\u06FF
        # Arabic Supplement: \u0750-\u077F
        # Arabic Extended-A: \u08A0-\u08FF
        # Arabic Presentation Forms-A: \uFB50-\uFDFF
        # Arabic Presentation Forms-B: \uFE70-\uFEFF
        arabic_pattern = re.compile(r'[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]')

        # Count Arabic characters
        arabic_chars = arabic_pattern.findall(text)

        # If more than 5% of non-space characters are Arabic, consider it Arabic text
        # This is a lower threshold to be more sensitive to Arabic content
        non_space_chars = len([c for c in text if not c.isspace()])
        if non_space_chars == 0:
            return False

        arabic_ratio = len(arabic_chars) / non_space_chars
        return arabic_ratio > 0.05
    except Exception as e:
        console.print(f"[bold yellow]Error detecting Arabic text: {e}. Assuming not Arabic.[/bold yellow]")
        return False


def translate_text(text: str, source_lang: str, target_lang: str, max_retries: int = 3) -> str:
    """
    Translate text between languages using LLM with direct API calls to avoid recursion.
    
    Args:
        text: The text to translate
        source_lang: Source language (e.g., 'Arabic', 'English')
        target_lang: Target language (e.g., 'Arabic', 'English')
        max_retries: Maximum number of retries for API calls
        
    Returns:
        Translated text
    """
    if not text:
        return text
        
    # Skip translation if source and target are the same
    if source_lang == target_lang:
        return text
        
    # Initialize retry counter
    retries = 0
    
    while retries <= max_retries:
        try:
            # Use a direct API call to avoid recursion issues
            from openai import OpenAI
            client = OpenAI(api_key=OPENAI_API_KEY)
            
            # Create a simple system and user message for translation
            messages = [
                {"role": "system", "content": f"You are a professional translator from {source_lang} to {target_lang}. Translate the text exactly as provided, maintaining all formatting including markdown."},
                {"role": "user", "content": f"Translate this text from {source_lang} to {target_lang}:\n\n{text}"}
            ]
            
            # Make the API call with a timeout
            response = client.chat.completions.create(
                model="gpt-4o",
                messages=messages,
                temperature=0.3,  # Lower temperature for more consistent translations
                timeout=60  # 60 second timeout
            )
            
            # Extract the translated text from the response
            if response and hasattr(response, 'choices') and len(response.choices) > 0:
                translated_text = response.choices[0].message.content
                return translated_text
            else:
                raise Exception("Empty or invalid response from translation API")
                
        except Exception as e:
            retries += 1
            if retries > max_retries:
                console.print(f"[bold red]Translation failed after {max_retries} attempts: {e}[/bold red]")
                return text  # Return original text after all retries fail
                
            # Exponential backoff
            wait_time = 2 ** retries
            console.print(f"[yellow]Translation attempt {retries} failed: {e}. Retrying in {wait_time} seconds...[/yellow]")
            time.sleep(wait_time)
    
    # This should never be reached due to the return in the exception handler
    return text


def process_arabic_task(task: Task) -> tuple:
    """
    Check if task details are in Arabic and translate them to English if needed.
    Returns translated task and a flag indicating if the original was in Arabic.
    """
    # Check if task title or description is in Arabic
    title_is_arabic = is_arabic_text(task.title)
    desc_is_arabic = is_arabic_text(task.description)

    is_arabic = title_is_arabic or desc_is_arabic
    original_task = None

    if is_arabic:
        # Make a copy of the original task for later reference
        original_task = Task(
            title=task.title,
            description=task.description,
            domain=task.domain,
            stage=task.stage,
            bestPractices=task.bestPractices.copy() if task.bestPractices else None,
        )

        # Translate task details from Arabic to English
        if title_is_arabic:
            task.title = translate_text(task.title, "Arabic", "English")

        if desc_is_arabic:
            task.description = translate_text(task.description, "Arabic", "English")

        # Check if domain or stage are in Arabic
        if is_arabic_text(task.domain):
            task.domain = translate_text(task.domain, "Arabic", "English")

        if is_arabic_text(task.stage):
            task.stage = translate_text(task.stage, "Arabic", "English")

        # Translate best practices if needed
        if task.bestPractices:
            translated_practices = []
            for practice in task.bestPractices:
                if is_arabic_text(practice):
                    translated_practice = translate_text(practice, "Arabic", "English")
                    translated_practices.append(translated_practice)
                else:
                    translated_practices.append(practice)
            task.bestPractices = translated_practices

    return task, original_task, is_arabic


def process_input_with_language_handling(
    domain_name: str, user_input: str, task: Task, related_documents: list = None, force_arabic: bool = False
) -> tuple:
    """
    Modified version that handles Arabic language by translating at beginning and end.

    Args:
        domain_name: The domain name for recommendations
        user_input: User input text
        task: Task object with details
        related_documents: Optional list of related document URLs to include in RAG
        force_arabic: Force translation to Arabic even if no Arabic is detected
    
    Returns:
        A tuple of (content, is_arabic) where content is the final text content 
        and is_arabic indicates if Arabic was detected or forced
    """
    token_manager = TokenManager()

    # Check if user input is in Arabic
    input_is_arabic = is_arabic_text(user_input)

    # Translate user input if it's in Arabic
    original_input = user_input
    if input_is_arabic:
        print("Arabic input detected, translating to English")
        user_input = translate_text(user_input, "Arabic", "English")

    # Process task details (translate if needed)
    task, original_task, task_is_arabic = process_arabic_task(task)

    # Any language is Arabic? Also consider force_arabic parameter
    any_arabic = input_is_arabic or task_is_arabic or force_arabic

    # Check token limits on the translated content
    exceeds_limit, tokens_used, tokens_available = check_token_limits(
        user_input, task, token_manager
    )

    if exceeds_limit:
        error_message = f"""
        # Input Length Error
        
        Your input exceeds the maximum token limit.
        
        * Tokens used in your input: {tokens_used}
        * Maximum tokens available: {tokens_available}
        
        Please shorten your message by approximately {tokens_used - tokens_available} tokens and try again.
        
        Tips for shortening:
        * Focus on key information only
        * Remove redundant examples or details
        * Summarize lengthy descriptions
        * Split your request into multiple smaller requests
        """

        # Translate error message back to Arabic if needed
        if input_is_arabic or force_arabic:
            error_message = translate_text(error_message, "English", "Arabic")

        return error_message, any_arabic

    try:
        # Process everything in English - IMPORTANT: We're passing force_arabic=False to avoid recursion
        content, token_usage = get_pm_recommendations_multi_call(
            domain_name, user_input, task, related_documents, force_arabic=False
        )

        # If original was Arabic or force_arabic is True, translate the result back to Arabic
        if any_arabic:
            print("Translating result back to Arabic")
            content = translate_large_document(content, "English", "Arabic")

        return content, any_arabic
    except Exception as e:
        console.print(f"[bold red]Error in language handling: {e}[/bold red]")
        # Generate a simple fallback response
        fallback = create_simplified_response(domain_name, task)
        
        # Translate fallback if needed
        if any_arabic and isinstance(fallback, tuple) and len(fallback) > 0:
            fallback_content = fallback[0]
            fallback_content = translate_large_document(fallback_content, "English", "Arabic")
            return fallback_content, any_arabic
        elif isinstance(fallback, tuple) and len(fallback) > 0:
            return fallback[0], any_arabic
        else:
            return str(fallback), any_arabic


def translate_large_document(
    text: str, source_lang: str, target_lang: str, chunk_size: int = 4000
) -> str:
    """
    Translate a large document by breaking it into manageable chunks while respecting
    markdown structure.

    Args:
        text: Document to translate
        source_lang: Source language
        target_lang: Target language
        chunk_size: Maximum chunk size in characters

    Returns:
        Complete translated document
    """
    if not text or source_lang == target_lang:
        return text

    console.print(
        f"Translating large document ({len(text)} chars) from {source_lang} to {target_lang}..."
    )

    # For very small documents, use the regular translate_text function directly
    if len(text) < chunk_size:
        return translate_text(text, source_lang, target_lang)

    # Split document respecting markdown headers
    def split_by_headers(content):
        # Split by markdown headers but keep the header with the content
        # This regex matches markdown headers (# Header)
        header_pattern = re.compile(r"^(#+\s+.+)$", re.MULTILINE)

        # Find all header positions
        headers = list(header_pattern.finditer(content))

        if not headers:
            # If no headers, return the whole content as one chunk
            return [content]

        chunks = []
        for i in range(len(headers)):
            start_pos = headers[i].start()
            # If it's the last header, the end is the end of the content
            end_pos = headers[i + 1].start() if i < len(headers) - 1 else len(content)
            chunks.append(content[start_pos:end_pos])

        return chunks

    # First try to split by major sections (## headers)
    sections = split_by_headers(text)

    # Further split any large sections
    final_chunks = []
    for section in sections:
        if len(section) > chunk_size:
            # Split large sections by paragraphs
            paragraphs = section.split("\n\n")
            current_chunk = ""

            for paragraph in paragraphs:
                if len(current_chunk) + len(paragraph) + 2 <= chunk_size:
                    if current_chunk:
                        current_chunk += "\n\n" + paragraph
                    else:
                        current_chunk = paragraph
                else:
                    if current_chunk:
                        final_chunks.append(current_chunk)
                    current_chunk = paragraph

            if current_chunk:
                final_chunks.append(current_chunk)
        else:
            final_chunks.append(section)

    # Now translate each chunk using our improved translate_text function
    translated_chunks = []
    total_chunks = len(final_chunks)

    for i, chunk in enumerate(final_chunks):
        console.print(f"Translating chunk {i+1}/{total_chunks} ({len(chunk)} chars)...")
        try:
            # Use translate_text directly
            translated_chunk = translate_text(chunk, source_lang, target_lang)
            translated_chunks.append(translated_chunk)
            # Add a small delay between API calls to avoid rate limiting
            time.sleep(0.5)
        except Exception as e:
            console.print(f"[bold red]Error translating chunk {i+1}: {e}[/bold red]")
            # Keep original chunk if translation fails
            translated_chunks.append(chunk)

    console.print(
        f"Translation completed. Combining {len(translated_chunks)} chunks..."
    )

    # Combine translated chunks
    full_translation = "\n".join(translated_chunks)

    # Save intermediate translation for debugging
    try:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        debug_file = os.path.join(OUTPUT_DIRECTORY, f"translation_debug_{timestamp}.md")
        with open(debug_file, "w", encoding="utf-8") as f:
            f.write(full_translation)
    except Exception as e:
        console.print(f"[bold yellow]Warning: Could not save debug file: {e}[/bold yellow]")

    return full_translation


def get_pm_recommendations_multi_call(
    domain_name: str, user_input: str, task: Task, related_documents: list = None, force_arabic: bool = False
) -> tuple:
    """
    Generate PM recommendations without handling translation.
    Returns a tuple of (recommendations, token_usage)
    
    Args:
        domain_name: The domain name for recommendations
        user_input: User input text
        task: Task object with details
        related_documents: Optional list of related document URLs to include in RAG
        force_arabic: Force Arabic output even if input isn't in Arabic
    """
    token_manager = TokenManager()
    cache_manager = CacheManager(CACHE_DIRECTORY)

    # Check if task or user input is in Arabic, or if Arabic output is forced
    is_arabic = is_arabic_text(user_input) or is_arabic_text(task.title) or is_arabic_text(task.description) or force_arabic
    
    # If Arabic, use the language handling version instead
    if is_arabic:
        print("Arabic processing needed, using Arabic language processing flow")
        
        # IMPORTANT: We're calling process_input_with_language_handling with force_arabic=False
        # to prevent potential circular references
        content, is_arabic_detected = process_input_with_language_handling(
            domain_name, user_input, task, related_documents, force_arabic=False
        )
        
        # Estimate token usage since we don't have exact counts from the translation process
        token_usage = {
            "input_tokens": token_manager.count_tokens(user_input + task.title + task.description) + 500,
            "output_tokens": token_manager.count_tokens(content) + 500,
            "total_tokens": 0  # Will be calculated below
        }
        token_usage["total_tokens"] = token_usage["input_tokens"] + token_usage["output_tokens"]
        
        # If force_arabic is True, we need to translate the content back to Arabic
        # This is done here instead of in process_input_with_language_handling to avoid recursion
        if force_arabic and not is_arabic_detected:
            print("Forcing Arabic translation of the final output")
            content = translate_large_document(content, "English", "Arabic")
        
        return content, token_usage
        
    # Initialize token usage tracking
    token_usage = {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}

    # Count input tokens
    input_text = f"{user_input} {task.title} {task.description} {task.domain} {task.stage} {' '.join(task.bestPractices)}"
    token_usage["input_tokens"] = token_manager.count_tokens(input_text)

    try:
        # Gather input data
        gathered_data = gather_input_data(
            domain_name, user_input, task, related_documents
        )

        # Process situation analysis
        analysis_results = process_situation_analysis(gathered_data, user_input, task)

        # Process best practices
        best_practices = process_best_practices(analysis_results, task)

        # Generate recommendations
        recommendations = generate_recommendations(best_practices, task)

        # Create implementation plan
        implementation_plan = create_implementation_plan(recommendations, task)

        # Synthesize final response
        final_response = synthesize_final_response(implementation_plan, task)

        # Count output tokens
        token_usage["output_tokens"] = token_manager.count_tokens(final_response)
        token_usage["total_tokens"] = (
            token_usage["input_tokens"] + token_usage["output_tokens"]
        )

        return final_response, token_usage

    except Exception as e:
        console.print(
            f"[red]Error in get_pm_recommendations_multi_call: {str(e)}[/red]"
        )
        raise e


def get_pm_recommendations_single_call(
    domain_name: str, user_input: str, task: Task, simplified: bool = False, force_arabic: bool = False
) -> tuple:
    """
    Generate PM recommendations with a single LLM call.
    When simplified=True, generates a condensed (2-4 page) document for cases
    where both attachments and task notes are missing.
    
    Args:
        domain_name: The domain name for the task
        user_input: The user's input text
        task: The Task object containing task details
        simplified: Whether to generate a simplified (2-4 page) response
        force_arabic: Force Arabic output even if input isn't in Arabic
    
    Returns a tuple of (recommendations, token_usage)
    """
    token_manager = TokenManager()
    cache_manager = CacheManager(CACHE_DIRECTORY)
    debug_logger = DebugLogger()

    # Check if task or user input is in Arabic, or if Arabic output is forced
    is_arabic = is_arabic_text(user_input) or is_arabic_text(task.title) or is_arabic_text(task.description) or force_arabic
    
    # If Arabic, use the language handling version instead
    if is_arabic:
        print("Arabic processing needed, using Arabic language processing flow")
        
        # IMPORTANT: We're calling process_input_with_language_handling with force_arabic=False
        # to prevent potential circular references
        content, is_arabic_detected = process_input_with_language_handling(
            domain_name, user_input, task, None, force_arabic=False
        )
        
        # Estimate token usage since we don't have exact counts from the translation process
        token_usage = {
            "input_tokens": token_manager.count_tokens(user_input + task.title + task.description) + 500,
            "output_tokens": token_manager.count_tokens(content) + 500,
            "total_tokens": 0  # Will be calculated below
        }
        token_usage["total_tokens"] = token_usage["input_tokens"] + token_usage["output_tokens"]
        
        # If force_arabic is True, we need to translate the content back to Arabic
        # This is done here instead of in process_input_with_language_handling to avoid recursion
        if force_arabic and not is_arabic_detected:
            print("Forcing Arabic translation of the final output")
            content = translate_large_document(content, "English", "Arabic")
        
        return content, token_usage

    # We now only support simplified mode
    if not simplified:
        # If simplified mode is not requested, use the comprehensive mode instead
        print("Warning: Non-simplified mode requested but only simplified mode is supported.")
        print("Using simplified mode instead.")
    
    return create_simplified_response(domain_name, task)


def create_simplified_response(domain_name: str, task: Task) -> tuple:
    """
    Create a comprehensive and well-formatted response for cases where both attachments and task notes are missing.
    This produces a detailed document with unlimited length that maintains all standard sections and 
    professional formatting with extensive content in each section.
    
    Returns a tuple of (recommendations, token_usage)
    """
    token_manager = TokenManager()
    debug_logger = DebugLogger()
    cache_manager = CacheManager(CACHE_DIRECTORY)

    # Initialize token usage tracking
    token_usage = {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}

    # Count input tokens
    input_text = f"{task.title} {task.description} {task.domain} {task.stage} {' '.join(task.bestPractices)}"
    token_usage["input_tokens"] = token_manager.count_tokens(input_text)

    try:
        # Create cache key
        cache_key = f"simplified_{hash(input_text)}_{task.domain}_{task.stage}"
        cached_result = cache_manager.get(cache_key)
        if cached_result:
            print("Using cached result for simplified response")
            content = cached_result
            token_usage["output_tokens"] = token_manager.count_tokens(content)
            token_usage["total_tokens"] = token_usage["input_tokens"] + token_usage["output_tokens"]
            return content, token_usage

        # Get stage guidance for inclusion in the document
        stage_guidance = get_stage_content(task.stage)["guidance"]
        
        # Format best practices list
        best_practices_text = ""
        if task.bestPractices and len(task.bestPractices) > 0:
            for practice in task.bestPractices:
                best_practices_text += f"\n* {practice}"
        else:
            best_practices_text = "\n* No specific best practices were selected."
            
        # Create prompt for comprehensive document
        prompt = ChatPromptTemplate.from_template(
            f"""
        You are a Project Management Office (PMO) consultant tasked with creating a comprehensive and detailed document for a project manager.
        
        TASK CONTEXT:
        Domain: {task.domain}
        Stage: {task.stage}
        Title: {task.title}
        Description: {task.description}
        Best Practices: {best_practices_text}
        
        Create a detailed and comprehensive PMO consultation document that includes all 
        standard sections with maximum depth and thoroughness.
        
        Include the following sections, using exact formatting as shown:
        
        # Executive Summary
        (concise overview with key points)
        
        # Situation Analysis
        (concise analysis of the domain and stage)
        
        # Best Practices Implementation
        (focused guidance on implementing the selected best practices)
        
        # Recommendations
        (3-5 high-impact, actionable recommendations)
        
        # Implementation Plan
        (simplified timeline and resource plan)
        
        FORMATTING REQUIREMENTS:
        - IMPORTANT: Each main section MUST begin with "# " followed by the section title exactly as shown above (with the # symbol)
        - For subsections use "## " followed by the subsection name
        - Use bullet points (starting with *) instead of numbered lists
        - Create an exhaustive and comprehensive document with unlimited length
        - Provide both actionable guidance and in-depth theoretical explanations
        - Use professional business language and formatting
        
        IMPORTANT GUIDELINES:
        - Structure the document with these exact section headers in this order, properly formatted with # symbols
        - Make each section as comprehensive and detailed as possible
        - Include extensive, specific, actionable content in the recommendations
        - The implementation plan should include detailed phases with timeframes, resources, and dependencies
        
        Use this stage-specific guidance in your document:
        {stage_guidance}
        """
        )

        # Run the LLM chain with GPT-4
        chain = prompt | ChatOpenAI(model="gpt-4o", max_tokens=8192, temperature=0.7) | StrOutputParser()
        response = chain.invoke({})

        # Clean up the response
        content = remove_special_characters(response)
        
        # Cache the result
        cache_manager.set(cache_key, content)

        # Count output tokens
        token_usage["output_tokens"] = token_manager.count_tokens(content)
        token_usage["total_tokens"] = token_usage["input_tokens"] + token_usage["output_tokens"]

        return content, token_usage
        
    except Exception as e:
        debug_logger.log_error(e, "Error in create_simplified_response")
        console.print(f"[bold red]Error in simplified response generation: {e}[/bold red]")
        
        # Create a fallback content
        fallback_content = f"""
        # Project Management Recommendations for {task.domain}
        
        # Executive Summary
        
        This document provides targeted guidance for implementing {task.domain} best practices during the {task.stage} phase. 
        Following these recommendations will help establish effective project management frameworks and improve delivery capabilities.
        
        # Situation Analysis
        
        Organizations implementing {task.domain} typically face challenges related to process standardization, resource allocation, 
        and stakeholder alignment. The {task.stage} phase is critical for establishing proper foundations and governance.
        
        # Best Practices Implementation
        
        {stage_guidance}
        
        The selected best practices can be implemented through the following approaches:
        {best_practices_text}
        
        # Recommendations
        
        * Establish a clear governance framework with defined roles, responsibilities, and decision-making processes
        * Develop standardized templates and tools to ensure consistency 
        * Implement regular progress tracking and reporting mechanisms
        * Create knowledge management systems to capture lessons learned
        * Invest in training and development to build organizational capabilities
        
        # Implementation Plan
        
        * Phase 1: Assessment and Planning (2-4 weeks)
          * Conduct current state assessment
          * Identify improvement opportunities
          * Develop implementation roadmap
        
        * Phase 2: Framework Development (4-6 weeks)
          * Design governance structure
          * Develop templates and tools
          * Create process documentation
        
        * Phase 3: Pilot Implementation (4-8 weeks)
          * Select pilot projects
          * Implement new frameworks
          * Gather feedback and refine
        
        * Phase 4: Full Implementation (8-12 weeks)
          * Roll out to all projects
          * Provide training and support
          * Monitor adoption
        """
        
        token_usage["output_tokens"] = token_manager.count_tokens(fallback_content)
        token_usage["total_tokens"] = token_usage["input_tokens"] + token_usage["output_tokens"]
        
        return fallback_content, token_usage


if __name__ == "__main__":
    main()
