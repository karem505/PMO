#!/usr/bin/env python3

from supabase import create_client, Client
import os
from dotenv import load_dotenv
from pathlib import Path

load_dotenv()

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_SERVICE_ROLE_KEY")
BUCKET_NAME = os.getenv("SUPABASE_BUCKET")

if not all([SUPABASE_URL, SUPABASE_KEY, BUCKET_NAME]):
    raise ValueError("Missing required environment variables. Please check your .env file.")

supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

def list_files():
    try:
        response = supabase.storage.from_(BUCKET_NAME).list()
        print("Files in bucket:")
        for file in response:
            print(file['name'])
        return response
    except Exception as e:
        print(f"Error listing files: {e}")
        return []

def download_file(file_name, download_dir):
    try:
        Path(download_dir).mkdir(parents=True, exist_ok=True)
        file_data = supabase.storage.from_(BUCKET_NAME).download(file_name)
        file_path = Path(download_dir) / file_name
        with open(file_path, 'wb') as f:
            f.write(file_data)
        print(f"Downloaded: {file_name} to {download_dir}")
    except Exception as e:
        print(f"Error downloading file {file_name}: {e}")

def main():
    download_dir = "backend/services/documents"
    files = list_files()
    for file in files:
        download_file(file['name'], download_dir)

if __name__ == "__main__":
    main()