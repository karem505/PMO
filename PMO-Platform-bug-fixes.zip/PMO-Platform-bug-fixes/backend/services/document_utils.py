import os
import re
import io 
import tempfile
from docx.shared import Pt, Inches, Cm
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
from docx import Document as DocxDocument
from datetime import datetime
from rich.console import Console
from rich.panel import Panel
from langchain_community.document_loaders import PyPDFLoader, TextLoader, Docx2txtLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.schema import Document
from typing import List, Dict, Any
from supabase import create_client
from dotenv import load_dotenv
from .debug_logger import DebugLogger
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import RGBColor



load_dotenv()



# Initialize rich console for better output formatting
console = Console()
SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_SERVICE_ROLE_KEY")

def get_supabase_client():
    """Initialize and return Supabase client."""
    try:
        if not SUPABASE_URL or not SUPABASE_KEY:
            console.print("[bold red]Error: SUPABASE_URL or SUPABASE_KEY environment variables not set[/bold red]")
            return None

        return create_client(SUPABASE_URL, SUPABASE_KEY)
    except Exception as e:
        console.print(f"[bold red]Error initializing Supabase client: {e}[/bold red]")
        return None

def get_async_supabase_client():
    """
    Create and return an async wrapper for the Supabase client.
    Returns None if the client can't be initialized.
    """
    try:
        # Get the synchronous client first
        sync_client = get_supabase_client()
        if not sync_client:
            return None
            
        # Import the async wrapper and wrap the client
        from services.async_helpers import get_async_supabase_client as wrap_client
        return wrap_client(sync_client)
    except Exception as e:
        print(f"Error initializing async Supabase client: {e}")
        return None

def load_and_process_pdfs(doc_dir):
    """Load and process all documents in the specified directory."""
    all_docs = []
    supported_extensions = ['.pdf', '.txt', '.docx', '.doc']
    doc_files = [f for f in os.listdir(doc_dir) if any(f.lower().endswith(ext) for ext in supported_extensions)]

    if not doc_files:
        console.print(f"[bold yellow]No documents found in {doc_dir}[/bold yellow]")
        return []

    with console.status("[bold green]Processing documents...[/bold green]") as status:
        for doc_file in doc_files:
            file_path = os.path.join(doc_dir, doc_file)
            
            try:
                if doc_file.lower().endswith('.pdf'):
                    loader = PyPDFLoader(file_path)
                elif doc_file.lower().endswith(('.txt')):
                    loader = TextLoader(file_path)
                elif doc_file.lower().endswith(('.docx', '.doc')):
                    loader = Docx2txtLoader(file_path)
                else:
                    continue

                documents = loader.load()

                for doc in documents:
                    # Enhanced metadata
                    doc.metadata["source"] = doc_file
                    doc.metadata["processed_date"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    doc.metadata["file_size"] = os.path.getsize(file_path)

                all_docs.extend(documents)
            except Exception as e:
                console.print(f"  [bold red]Error processing {doc_file}: {e}[/bold red]")

    return all_docs

def split_by_paragraphs(documents):
    """Split loaded documents by paragraph using regex."""
    paragraph_docs = []
    total_paragraphs = 0
    
    with console.status("[bold green]Splitting documents into paragraphs...[/bold green]") as status:
        for doc in documents:
            content = doc.page_content
            metadata = doc.metadata

            # Improved paragraph splitting with handling for different formats
            paragraphs = re.split(r'\n\s*\n|\r\n\s*\r\n', content)
            
            # Clean and filter paragraphs
            for i, para in enumerate(paragraphs):
                para = para.strip()
                if para:  # Only keep non-empty paragraphs
                    para_metadata = metadata.copy()
                    para_metadata["paragraph"] = i
                    para_metadata["paragraph_length"] = len(para)
                    paragraph_docs.append(Document(page_content=para, metadata=para_metadata))
            
            total_paragraphs += len(paragraphs)

    return paragraph_docs

def deduplicate_and_consolidate_results(docs):
    """Consolidate similar documents into a single comprehensive result."""
    if not docs:
        return []
    
    # Use a set to track unique content
    seen_content = set()
    unique_docs = []
    
    for doc in docs:
        # Create a simplified version of content for comparison
        # (removing whitespace variations, etc.)
        simplified_content = re.sub(r'\s+', ' ', doc.page_content).strip().lower()
        
        if simplified_content not in seen_content:
            seen_content.add(simplified_content)
            unique_docs.append(doc)
    
    # If we have multiple unique documents, consolidate them
    if len(unique_docs) > 1:
        # Create a consolidated document with sources listed
        sources = [doc.metadata.get('source', 'Unknown') for doc in unique_docs]
        consolidated_content = '\n\n'.join([doc.page_content for doc in unique_docs])
        
        consolidated_metadata = {
            'source': f"Consolidated from {len(set(sources))} documents: {', '.join(set(sources))}",
            'page': ', '.join(set(str(doc.metadata.get('page', 'N/A')) for doc in unique_docs)),
        }
        
        return [Document(page_content=consolidated_content, metadata=consolidated_metadata)]
    
    return unique_docs

def save_to_supabase(supabase_client, response: str, task_name: str, bucket_name: str = "output", task_request = None, user_metadata=None):
    # Create a Word document in memory
    doc = DocxDocument()
    
    # Check if content is in Arabic by detecting Arabic characters
    is_arabic = bool(re.search(r'[\u0600-\u06FF]', response))
    
    # Set document properties
    doc.core_properties.title = f"PM Recommendations: {task_name}"
    doc.core_properties.author = "RAG-LLM Project Management System"
    doc.core_properties.created = datetime.now()
    
    # Set document margins
    sections = doc.sections
    for section in sections:
        section.left_margin = Inches(1)
        section.right_margin = Inches(1)
        section.top_margin = Inches(1)
        section.bottom_margin = Inches(1)
        
        # Set RTL direction for Arabic text
        if is_arabic:
            # Set right-to-left text direction for the entire document
            bidi_elements = section._sectPr.xpath('./w:bidi')
            if bidi_elements:
                bidi_elements[0].set('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val', '1')
            else:
                # Create and add the bidi element
                bidi_element = OxmlElement('w:bidi')
                bidi_element.set('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val', '1')
                section._sectPr.append(bidi_element)
    
    # Add logo from Supabase storage
    try:
        # First, download the logo from Supabase
        if supabase_client:
            with tempfile.NamedTemporaryFile(suffix='.jpeg', delete=False) as temp_logo_file:
                temp_logo_path = temp_logo_file.name
            
            try:
                logo_data = supabase_client.storage.from_(bucket_name).download('logo.jpeg')
                with open(temp_logo_path, 'wb') as f:
                    f.write(logo_data)                
                
                # Create a table for positioning (1x1 table with no borders)
                table = doc.add_table(rows=1, cols=1)
                table.autofit = False
                table.allow_autofit = False
                
                # Remove borders
                for cell in table.rows[0].cells:
                    cell.border = None
                
                # Make the table cell wide enough
                table.columns[0].width = Cm(19)  # Make it wide enough for positioning
                
                # Add a paragraph in the cell
                cell = table.cell(0, 0)
                paragraph = cell.paragraphs[0]
                paragraph.alignment = WD_PARAGRAPH_ALIGNMENT.RIGHT  # Align to the right
                
                # Add the logo
                run = paragraph.add_run()
                picture = run.add_picture(temp_logo_path, width=Cm(2.08), height=Cm(2.21))
                
                # Clean up the temporary file
                os.unlink(temp_logo_path)
                
                console.print("[bold green]Logo added to document[/bold green]")
            except Exception as e:
                console.print(f"[bold yellow]Warning: Could not download logo - {e}[/bold yellow]")
                if 'debug_logger' in globals():
                    debug_logger.log_error(e, "Error downloading logo from Supabase")
        else:
            console.print("[bold yellow]Warning: Could not add logo - Supabase client not provided[/bold yellow]")
    except Exception as e:
        console.print(f"[bold yellow]Warning: Could not add logo - {e}[/bold yellow]")
        if 'debug_logger' in globals():
            debug_logger.log_error(e, "Error adding logo to document")

    title = doc.add_paragraph()
    
    # Set title text based on language
    if is_arabic:
        title_text = "توصيات إدارة المشروع\n" + task_name
    else:
        title_text = f"Project Management Recommendations\n{task_name}"
        
    title_run = title.add_run(title_text)
    title_run.bold = True
    title_run.font.size = Pt(16)
    
    # Set the title color to RGB: 198, 78, 245 (#c64ef5)
    title_run.font.color.rgb = RGBColor(198, 78, 245)
    
    title.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
    
    # Set RTL for title if Arabic
    if is_arabic:
        try:
            # Get the paragraph properties
            p_props = title._element.get_or_add_pPr()
            # Add bidirectional property
            bidi = OxmlElement('w:bidi')
            p_props.append(bidi)
            # Set font for Arabic
            title_run.font.name = "Arial"  # Use a font that supports Arabic
        except Exception:
            pass  
    
    # Add date
    date_paragraph = doc.add_paragraph()
    
    # Set date text based on language
    date_text = f"Generated on: {datetime.now().strftime('%B %d, %Y')}"
        
    date_run = date_paragraph.add_run(date_text)
    date_run.italic = True
    
    date_run.font.color.rgb = RGBColor(97, 120, 242)
    
    date_paragraph.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
    
    # Set RTL for date if Arabic
    if is_arabic:
        try:
            # Get the paragraph properties
            p_props = date_paragraph._element.get_or_add_pPr()
            # Add bidirectional property
            bidi = OxmlElement('w:bidi')
            p_props.append(bidi)
            # Set font for Arabic
            date_run.font.name = "Arial"  
        except Exception:
            pass  
    
    doc.add_paragraph()  # Add spacing


    sections = re.split(r'(#+\s+.*)', response)
    
    if sections[0].strip() and not sections[0].startswith('#'):
        # Add any text before the first heading
        p = doc.add_paragraph(sections[0].strip())
        # Set text color to black for text before first heading
        for run in p.runs:
            run.font.color.rgb = RGBColor(0, 0, 0)
        # Set RTL for paragraph if Arabic
        if is_arabic:
            try:
                # Get the paragraph properties
                p_props = p._element.get_or_add_pPr()
                # Add bidirectional property
                bidi = OxmlElement('w:bidi')
                p_props.append(bidi)
                # Set the run's font for Arabic
                for run in p.runs:
                    run.font.name = "Arial"  # Use a font that supports Arabic
            except Exception:
                pass  # Gracefully handle if this attribute can't be set
    
    # Process sections with headings
    for i in range(1, len(sections), 2):
        if i + 1 < len(sections):
            heading = sections[i].strip()
            content = sections[i+1].strip()
            
            # Determine heading level
            heading_level = len(re.match(r'#+', heading).group())
            heading_text = re.sub(r'#+\s+', '', heading)
            
            # Add the heading with appropriate styling
            if heading_level == 1:
                h = doc.add_heading(heading_text, level=1)
                h.runs[0].font.size = Pt(14)
                h.runs[0].font.color.rgb = RGBColor(198, 78, 245) 
            elif heading_level == 2:
                h = doc.add_heading(heading_text, level=2)
                h.runs[0].font.size = Pt(13)
                h.runs[0].font.color.rgb = RGBColor(97, 120, 242)  
            else:
                h = doc.add_heading(heading_text, level=min(heading_level, 9))
                h.runs[0].font.size = Pt(12)
                h.runs[0].font.color.rgb = RGBColor(97, 120, 242) 
            
            # Set RTL for heading if Arabic
            if is_arabic:
                try:
                    # Get the paragraph properties
                    p_props = h._element.get_or_add_pPr()
                    # Add bidirectional property
                    bidi = OxmlElement('w:bidi')
                    p_props.append(bidi)
                    # Set font for Arabic
                    for run in h.runs:
                        run.font.name = "Arial"  # Use a font that supports Arabic
                except Exception:
                    pass  # Gracefully handle if this attribute can't be set
            
            # Process the content
            paragraphs = content.split('\n\n')
            for para in paragraphs:
                para = para.strip()
                if not para:
                    continue
                
                # Check if paragraph is a bullet point list
                if re.match(r'^[\s]*[-*]\s', para):
                    bullet_points = re.split(r'\n\s*[-*]\s+', para)
                    for point in bullet_points:
                        if point.strip():  # Skip empty points
                            p = doc.add_paragraph(point.strip(), style='List Bullet')
                            # Set text color to black for bullet points
                            for run in p.runs:
                                run.font.color.rgb = RGBColor(0, 0, 0)
                            # Set RTL for bullet if Arabic
                            if is_arabic:
                                try:
                                    # Get the paragraph properties
                                    p_props = p._element.get_or_add_pPr()
                                    # Add bidirectional property
                                    bidi = OxmlElement('w:bidi')
                                    p_props.append(bidi)
                                    # Set font for Arabic
                                    for run in p.runs:
                                        run.font.name = "Arial"  # Use a font that supports Arabic
                                except Exception:
                                    pass  # Gracefully handle if this attribute can't be set
                # Check if paragraph is a numbered list
                elif re.match(r'^[\s]*\d+\.\s', para):
                    numbered_points = re.split(r'\n\s*\d+\.\s+', para)
                    for point in numbered_points:
                        if point.strip():  # Skip empty points
                            p = doc.add_paragraph(point.strip(), style='List Number')
                            # Set text color to black for numbered points
                            for run in p.runs:
                                run.font.color.rgb = RGBColor(0, 0, 0)
                            # Set RTL for numbered list if Arabic
                            if is_arabic:
                                try:
                                    # Get the paragraph properties
                                    p_props = p._element.get_or_add_pPr()
                                    # Add bidirectional property
                                    bidi = OxmlElement('w:bidi')
                                    p_props.append(bidi)
                                    # Set font for Arabic
                                    for run in p.runs:
                                        run.font.name = "Arial"  # Use a font that supports Arabic
                                except Exception:
                                    pass  # Gracefully handle if this attribute can't be set
                else:
                    # Regular paragraph
                    p = doc.add_paragraph()
                    # Set RTL for paragraph if Arabic
                    if is_arabic:
                        try:
                            # Get the paragraph properties
                            p_props = p._element.get_or_add_pPr()
                            # Add bidirectional property
                            bidi = OxmlElement('w:bidi')
                            p_props.append(bidi)
                        except Exception:
                            pass

                    # Process bold text
                    text = para
                    current_pos = 0
                    bold_start = text.find('**')
                    
                    # Simple case: If no bold markers, add the whole text at once
                    if bold_start == -1:
                        run = p.add_run(text)
                        # Ensure text color is black
                        run.font.color.rgb = RGBColor(0, 0, 0)
                        if is_arabic:
                            run.font.name = "Arial"
                    else:
                        # Handle case with bold markers
                        while bold_start != -1:
                            # Add text before the bold marker
                            if bold_start > current_pos:
                                run = p.add_run(text[current_pos:bold_start])
                                # Set text color to black for normal text
                                run.font.color.rgb = RGBColor(0, 0, 0)
                                if is_arabic:
                                    run.font.name = "Arial"
                            
                            # Find the end of the bold section
                            bold_end = text.find('**', bold_start + 2)
                            if bold_end == -1:  # No closing marker found
                                # Add the rest of the text normally
                                run = p.add_run(text[bold_start:])
                                # Set text color to black for normal text
                                run.font.color.rgb = RGBColor(0, 0, 0)
                                if is_arabic:
                                    run.font.name = "Arial"
                                break
                            
                            # Add the bold text
                            bold_text = text[bold_start + 2:bold_end]
                            run = p.add_run(bold_text)
                            run.bold = True
                            # Set text color to black for bold text too
                            run.font.color.rgb = RGBColor(0, 0, 0)
                            if is_arabic:
                                run.font.name = "Arial"
                            
                            current_pos = bold_end + 2
                            bold_start = text.find('**', current_pos)
                        
                        # Add any remaining text after the last bold section
                        if current_pos < len(text):
                            run = p.add_run(text[current_pos:])
                            # Set text color to black for normal text
                            run.font.color.rgb = RGBColor(0, 0, 0)
                            if is_arabic:
                                run.font.name = "Arial"
    
    # Generate filename with email if provided
    email_part = ""
    if user_metadata and 'email' in user_metadata:
        email_username = user_metadata['email'].split('@')[0]
        email_part = f"{email_username}"
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{email_part}_{timestamp}.docx" if email_part else f"{timestamp}.docx"
    
    # Set document language and direction properties for Arabic
    if is_arabic:
        try:
            # Set Arabic language for spelling
            for style in doc.styles:
                if hasattr(style, 'element') and hasattr(style.element, 'get_or_add_rPr'):
                    lang_element = style.element.get_or_add_rPr().get_or_add_lang()
                    lang_element.set('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}bidi', 'ar-SA')
            
            # Add document-level right-to-left settings
            doc_props = doc.settings.element.get_or_add_documentProtection()
            rtl_element = OxmlElement('w:rtl')
            rtl_element.set('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val', '1')
            doc_props.append(rtl_element)
        except Exception:
            pass 
    
    with tempfile.NamedTemporaryFile(suffix='.docx', delete=False) as temp_file:
        temp_path = temp_file.name
        
    try:
        # Save the document to the temporary file
        doc.save(temp_path)
        
        # Upload to Supabase using the provided client
        if supabase_client:
            try:
                # Upload DOCX to Supabase from temporary file
                with open(temp_path, 'rb') as f:
                    docx_response = supabase_client.storage.from_(bucket_name).upload(
                        path=filename,
                        file=f,
                        file_options={"content-type": "application/vnd.openxmlformats-officedocument.wordprocessingml.document"}
                    )
                
                if docx_response and not isinstance(docx_response, Exception):
                    console.print(f"[bold green]Document uploaded to Supabase bucket '{bucket_name}' as {filename}[/bold green]")
                    public_url = supabase_client.storage.from_(bucket_name).get_public_url(filename)
                    
                    # Fix the public_url if it ends with a question mark
                    if public_url.endswith('?'):
                        public_url = public_url[:-1]
                    
                    console.print(f"Successfully got public URL: {public_url}")
                    
                    return {
                        "filename": filename,
                        "public_url": public_url
                    }
                else:
                    console.print(f"[bold yellow]Warning: Upload to Supabase may have failed: {docx_response}[/bold yellow]")
                    return None
                    
            except Exception as e:
                console.print(f"[bold red]Error uploading to Supabase: {e}[/bold red]")
                if 'debug_logger' in globals():
                    debug_logger.log_error(e, "Error uploading to Supabase")
                return None
        else:
            console.print("[bold red]Error: Supabase client not provided[/bold red]")
            return None
    finally:
        # Always clean up the temporary file, regardless of whether upload succeeded
        if os.path.exists(temp_path):
            os.unlink(temp_path)

def get_project_document(project_id: str, user_metadata = None):
    try:
        # Get Supabase client
        supabase = get_supabase_client()
        if not supabase:
            console.print("[bold red]Error: Unable to initialize Supabase client[/bold red]")
            return None
        
        # Fetch project data from Supabase
        console.print(f"[bold green]Fetching project data for ID: {project_id}[/bold green]")
        project_data = supabase.table("projects").select("*").eq("id", project_id).execute()
        
        # Check if data was retrieved
        if not project_data.data or len(project_data.data) == 0:
            console.print(f"[bold yellow]No project found with ID: {project_id}[/bold yellow]")
            return None
        
        # Extract project details
        project = project_data.data[0]  # Get the first (and should be only) result
        project_name = project.get("name", "Unnamed Project")
        
        # Create the document content
        console.print("[bold green]Generating project document...[/bold green]")
        document_content = format_project_document(project)
        
        # Save document to Supabase and return the result
        return save_project_to_supabase(document_content, project_name, user_metadata, supabase)
        
    except Exception as e:
        console.print(f"[bold red]Error generating project document: {e}[/bold red]")
        if 'debug_logger' in globals():
            debug_logger.log_error(e, "Error generating project document")
        return None

def format_project_document(project: Dict[str, Any]) -> str:

    project_name = project.get("name", "Unnamed Project")
    project_description = project.get("description", "No description provided")
    project_status = "Active"
    start_date = project.get("start_date", "Not specified")
    end_date = project.get("end_date", "Not specified")
    
    # Get manager info from profiles table
    manager_id = project.get("owner_id")
    manager_name = "Not assigned"
    
    if manager_id:
        try:
            supabase_client = get_supabase_client()
            if supabase_client:
                # Try to find by ID first
                profile_response = supabase_client.from_("profiles").select("display_name").eq("id", manager_id).execute()
                
                if not profile_response.data:
                    # If not found by ID, try email
                    profile_response = supabase_client.from_("profiles").select("display_name").eq("email", manager_id).execute()
                
                if profile_response.data and len(profile_response.data) > 0:
                    manager_name = profile_response.data[0].get("display_name", "Name not set")
        except Exception as e:
            print(f"Error looking up manager profile: {e}")
    
    budget = project.get("budget", "Not specified")
    
    tasks = project.get("tasks", [])
    task_section = ""
    if tasks:
        task_section = "# Project Tasks\n\n"
        for idx, task in enumerate(tasks, 1):
            task_name = task.get("name", f"Task {idx}")
            task_status = task.get("status", "Unknown")
            task_section += f"## {task_name}\n\n"
            task_section += f"**Status:** {task_status}\n"
            task_section += f"**Description:** {task.get('description', 'No description')}\n"
            task_section += f"**Assigned to:** {task.get('assigned_to', 'Unassigned')}\n"
            task_section += f"**Due date:** {task.get('due_date', 'Not specified')}\n\n"
    
    team = project.get("team_members", [])
    team_section = ""
    if team:
        team_section = "# Project Team\n\n"
        for member in team:
            name = member.get("name", "Unnamed")
            role = member.get("role", "Unspecified role")
            team_section += f"**{name}**: {role}\n"
        team_section += "\n"
    
    stakeholders = project.get("stakeholders", [])
    stakeholders_section = ""
    if stakeholders:
        stakeholders_section = "# Stakeholders\n\n"
        for stakeholder in stakeholders:
            name = stakeholder.get("name", "Unnamed")
            organization = stakeholder.get("organization", "")
            stakeholders_section += f"**{name}**"
            if organization:
                stakeholders_section += f" ({organization})"
            stakeholders_section += "\n"
        stakeholders_section += "\n"
    
    risks = project.get("risks", [])
    risks_section = ""
    if risks:
        risks_section = "# Risks and Issues\n\n"
        for risk in risks:
            description = risk.get("description", "No description")
            severity = risk.get("severity", "Unknown")
            mitigation = risk.get("mitigation", "Not specified")
            risks_section += f"## {description}\n\n"
            risks_section += f"**Severity:** {severity}\n"
            risks_section += f"**Mitigation plan:** {mitigation}\n\n"
    
    document = f"""# Project Overview: {project_name}

**Project status:** {project_status}

{project_description}

# Key Information

**Start Date:** {start_date}
**End Date:** {end_date}
**Project Manager:** {manager_name}
**Budget:** {budget}

{team_section}
{stakeholders_section}
{task_section}
{risks_section}

# Project Summary

This document provides an overview of the project "{project_name}". It includes essential information about the project's scope, timeline, team composition, and current status.

"""
    return document

def save_project_to_supabase(document_content: str, project_name: str, user_metadata=None, supabase_client=None):

    doc = DocxDocument()
    
    is_arabic = bool(re.search(r'[\u0600-\u06FF]', document_content))
    
    doc.core_properties.title = f"Project Overview: {project_name}"
    doc.core_properties.author = "Project Management System"
    doc.core_properties.created = datetime.now()
    
    sections = doc.sections
    for section in sections:
        section.left_margin = Inches(1)
        section.right_margin = Inches(1)
        section.top_margin = Inches(1)
        section.bottom_margin = Inches(1)
        
        if is_arabic:
            bidi_elements = section._sectPr.xpath('./w:bidi')
            if bidi_elements:
                bidi_elements[0].set('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val', '1')
            else:
                # Create and add the bidi element
                bidi_element = OxmlElement('w:bidi')
                bidi_element.set('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val', '1')
                section._sectPr.append(bidi_element)
    
    try:
        if supabase_client:
            with tempfile.NamedTemporaryFile(suffix='.jpeg', delete=False) as temp_logo_file:
                temp_logo_path = temp_logo_file.name
            
            try:
                logo_data = supabase_client.storage.from_('output').download('logo.jpeg')
                with open(temp_logo_path, 'wb') as f:
                    f.write(logo_data)                
                
                # Create a table for positioning (1x1 table with no borders)
                table = doc.add_table(rows=1, cols=1)
                table.autofit = False
                table.allow_autofit = False
                
                # Remove borders
                for cell in table.rows[0].cells:
                    cell.border = None
                
                # Make the table cell wide enough
                table.columns[0].width = Cm(19)  # Make it wide enough for positioning
                
                # Add a paragraph in the cell
                cell = table.cell(0, 0)
                paragraph = cell.paragraphs[0]
                paragraph.alignment = WD_PARAGRAPH_ALIGNMENT.RIGHT  # Align to the right
                
                # Add the logo
                run = paragraph.add_run()
                picture = run.add_picture(temp_logo_path, width=Cm(2.08), height=Cm(2.21))
                
                # Clean up the temporary file
                os.unlink(temp_logo_path)
                
                console.print("[bold green]Logo added to document[/bold green]")
            except Exception as e:
                console.print(f"[bold yellow]Warning: Could not download logo - {e}[/bold yellow]")
                if 'debug_logger' in globals():
                    debug_logger.log_error(e, "Error downloading logo from Supabase")
        else:
            console.print("[bold yellow]Warning: Could not add logo - Supabase client initialization failed[/bold yellow]")
    except Exception as e:
        console.print(f"[bold yellow]Warning: Could not add logo - {e}[/bold yellow]")
        if 'debug_logger' in globals():
            debug_logger.log_error(e, "Error adding logo to document")

    title = doc.add_paragraph()
    
    # Set title text based on language
    if is_arabic:
        title_text = "نظرة عامة على المشروع\n" + project_name
    else:
        title_text = f"Project Overview\n{project_name}"
        
    title_run = title.add_run(title_text)
    title_run.bold = True
    title_run.font.size = Pt(16)
    
    # Set the title color to RGB: 198, 78, 245 (#c64ef5)
    title_run.font.color.rgb = RGBColor(198, 78, 245)
    
    title.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
    
    # Set RTL for title if Arabic
    if is_arabic:
        try:
            # Get the paragraph properties
            p_props = title._element.get_or_add_pPr()
            # Add bidirectional property
            bidi = OxmlElement('w:bidi')
            p_props.append(bidi)
            # Set font for Arabic
            title_run.font.name = "Arial"  # Use a font that supports Arabic
        except Exception:
            pass  
    
    # Add date
    date_paragraph = doc.add_paragraph()
    
    # Set date text based on language
    date_text = f"Generated on: {datetime.now().strftime('%B %d, %Y')}"
        
    date_run = date_paragraph.add_run(date_text)
    date_run.italic = True
    
    date_run.font.color.rgb = RGBColor(97, 120, 242)
    
    date_paragraph.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
    
    # Set RTL for date if Arabic
    if is_arabic:
        try:
            # Get the paragraph properties
            p_props = date_paragraph._element.get_or_add_pPr()
            # Add bidirectional property
            bidi = OxmlElement('w:bidi')
            p_props.append(bidi)
            # Set font for Arabic
            date_run.font.name = "Arial"  
        except Exception:
            pass  
    
    doc.add_paragraph()  # Add spacing


    sections = re.split(r'(#+\s+.*)', document_content)
    
    if sections[0].strip() and not sections[0].startswith('#'):
        # Add any text before the first heading
        p = doc.add_paragraph(sections[0].strip())
        # Set text color to black for text before first heading
        for run in p.runs:
            run.font.color.rgb = RGBColor(0, 0, 0)
        # Set RTL for paragraph if Arabic
        if is_arabic:
            try:
                # Get the paragraph properties
                p_props = p._element.get_or_add_pPr()
                # Add bidirectional property
                bidi = OxmlElement('w:bidi')
                p_props.append(bidi)
                # Set the run's font for Arabic
                for run in p.runs:
                    run.font.name = "Arial"  # Use a font that supports Arabic
            except Exception:
                pass  # Gracefully handle if this attribute can't be set
    
    # Process sections with headings
    for i in range(1, len(sections), 2):
        if i + 1 < len(sections):
            heading = sections[i].strip()
            content = sections[i+1].strip()
            
            # Determine heading level
            heading_level = len(re.match(r'#+', heading).group())
            heading_text = re.sub(r'#+\s+', '', heading)
            
            # Add the heading with appropriate styling
            if heading_level == 1:
                h = doc.add_heading(heading_text, level=1)
                h.runs[0].font.size = Pt(14)
                h.runs[0].font.color.rgb = RGBColor(198, 78, 245) 
            elif heading_level == 2:
                h = doc.add_heading(heading_text, level=2)
                h.runs[0].font.size = Pt(13)
                h.runs[0].font.color.rgb = RGBColor(97, 120, 242)  
            else:
                h = doc.add_heading(heading_text, level=min(heading_level, 9))
                h.runs[0].font.size = Pt(12)
                h.runs[0].font.color.rgb = RGBColor(97, 120, 242) 
            
            # Set RTL for heading if Arabic
            if is_arabic:
                try:
                    # Get the paragraph properties
                    p_props = h._element.get_or_add_pPr()
                    # Add bidirectional property
                    bidi = OxmlElement('w:bidi')
                    p_props.append(bidi)
                    # Set font for Arabic
                    for run in h.runs:
                        run.font.name = "Arial"  # Use a font that supports Arabic
                except Exception:
                    pass  # Gracefully handle if this attribute can't be set
            
            # Process the content
            paragraphs = content.split('\n\n')
            for para in paragraphs:
                para = para.strip()
                if not para:
                    continue
                
                # Check if paragraph is a bullet point list
                if re.match(r'^[\s]*[-*]\s', para):
                    bullet_points = re.split(r'\n\s*[-*]\s+', para)
                    for point in bullet_points:
                        if point.strip():  # Skip empty points
                            p = doc.add_paragraph(point.strip(), style='List Bullet')
                            # Set text color to black for bullet points
                            for run in p.runs:
                                run.font.color.rgb = RGBColor(0, 0, 0)
                            # Set RTL for bullet if Arabic
                            if is_arabic:
                                try:
                                    # Get the paragraph properties
                                    p_props = p._element.get_or_add_pPr()
                                    # Add bidirectional property
                                    bidi = OxmlElement('w:bidi')
                                    p_props.append(bidi)
                                    # Set font for Arabic
                                    for run in p.runs:
                                        run.font.name = "Arial"  # Use a font that supports Arabic
                                except Exception:
                                    pass  # Gracefully handle if this attribute can't be set
                # Check if paragraph is a numbered list
                elif re.match(r'^[\s]*\d+\.\s', para):
                    numbered_points = re.split(r'\n\s*\d+\.\s+', para)
                    for point in numbered_points:
                        if point.strip():  # Skip empty points
                            p = doc.add_paragraph(point.strip(), style='List Number')
                            # Set text color to black for numbered points
                            for run in p.runs:
                                run.font.color.rgb = RGBColor(0, 0, 0)
                            # Set RTL for numbered list if Arabic
                            if is_arabic:
                                try:
                                    # Get the paragraph properties
                                    p_props = p._element.get_or_add_pPr()
                                    # Add bidirectional property
                                    bidi = OxmlElement('w:bidi')
                                    p_props.append(bidi)
                                    # Set font for Arabic
                                    for run in p.runs:
                                        run.font.name = "Arial"  # Use a font that supports Arabic
                                except Exception:
                                    pass  # Gracefully handle if this attribute can't be set
                else:
                    # Regular paragraph
                    p = doc.add_paragraph()
                    # Set RTL for paragraph if Arabic
                    if is_arabic:
                        try:
                            # Get the paragraph properties
                            p_props = p._element.get_or_add_pPr()
                            # Add bidirectional property
                            bidi = OxmlElement('w:bidi')
                            p_props.append(bidi)
                        except Exception:
                            pass

                    # Process bold text
                    text = para
                    current_pos = 0
                    bold_start = text.find('**')
                    
                    # Simple case: If no bold markers, add the whole text at once
                    if bold_start == -1:
                        run = p.add_run(text)
                        # Ensure text color is black
                        run.font.color.rgb = RGBColor(0, 0, 0)
                        if is_arabic:
                            run.font.name = "Arial"
                    else:
                        # Handle case with bold markers
                        while bold_start != -1:
                            # Add text before the bold marker
                            if bold_start > current_pos:
                                run = p.add_run(text[current_pos:bold_start])
                                # Set text color to black for normal text
                                run.font.color.rgb = RGBColor(0, 0, 0)
                                if is_arabic:
                                    run.font.name = "Arial"
                            
                            # Find the end of the bold section
                            bold_end = text.find('**', bold_start + 2)
                            if bold_end == -1:  # No closing marker found
                                # Add the rest of the text normally
                                run = p.add_run(text[bold_start:])
                                # Set text color to black for normal text
                                run.font.color.rgb = RGBColor(0, 0, 0)
                                if is_arabic:
                                    run.font.name = "Arial"
                                break
                            
                            # Add the bold text
                            bold_text = text[bold_start + 2:bold_end]
                            run = p.add_run(bold_text)
                            run.bold = True
                            # Set text color to black for bold text too
                            run.font.color.rgb = RGBColor(0, 0, 0)
                            if is_arabic:
                                run.font.name = "Arial"
                            
                            current_pos = bold_end + 2
                            bold_start = text.find('**', current_pos)
                        
                        # Add any remaining text after the last bold section
                        if current_pos < len(text):
                            run = p.add_run(text[current_pos:])
                            # Set text color to black for normal text
                            run.font.color.rgb = RGBColor(0, 0, 0)
                            if is_arabic:
                                run.font.name = "Arial"
    

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"projectoverview-{timestamp}.docx"
    
    # Set document language and direction properties for Arabic
    if is_arabic:
        try:
            # Set Arabic language for spelling
            for style in doc.styles:
                if hasattr(style, 'element') and hasattr(style.element, 'get_or_add_rPr'):
                    lang_element = style.element.get_or_add_rPr().get_or_add_lang()
                    lang_element.set('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}bidi', 'ar-SA')
            
            # Add document-level right-to-left settings
            doc_props = doc.settings.element.get_or_add_documentProtection()
            rtl_element = OxmlElement('w:rtl')
            rtl_element.set('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val', '1')
            doc_props.append(rtl_element)
        except Exception:
            pass 
    
    with tempfile.NamedTemporaryFile(suffix='.docx', delete=False) as temp_file:
        temp_path = temp_file.name
        
    try:
        # Save the document to the temporary file
        doc.save(temp_path)
        
        # Upload to Supabase using the provided client
        if supabase_client:
            try:
                # Upload DOCX to Supabase from temporary file
                with open(temp_path, 'rb') as f:
                    docx_response = supabase_client.storage.from_('output').upload(
                        path=filename,
                        file=f,
                        file_options={"content-type": "application/vnd.openxmlformats-officedocument.wordprocessingml.document"}
                    )
                
                if docx_response and not isinstance(docx_response, Exception):
                    console.print(f"[bold green]Project document uploaded to Supabase bucket 'output' as {filename}[/bold green]")
                    public_url = supabase_client.storage.from_('output').get_public_url(filename)
                    
                    # Fix the public_url if it ends with a question mark
                    if public_url.endswith('?'):
                        public_url = public_url[:-1]
                    
                    console.print(f"Successfully got public URL: {public_url}")
                    
                    return {
                        "filename": filename,
                        "public_url": public_url
                    }
                else:
                    console.print(f"[bold yellow]Warning: Upload to Supabase may have failed: {docx_response}[/bold yellow]")
                    return None
                    
            except Exception as e:
                console.print(f"[bold red]Error uploading to Supabase: {e}[/bold red]")
                if 'debug_logger' in globals():
                    debug_logger.log_error(e, "Error uploading to Supabase")
                return None
        else:
            console.print("[bold red]Error: Supabase client not provided[/bold red]")
            return None
    finally:
        # Always clean up the temporary file, regardless of whether upload succeeded
        if os.path.exists(temp_path):
            os.unlink(temp_path)