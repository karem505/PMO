from typing import List, Dict, Any
import tiktoken
from langchain_openai import ChatOpenAI
from langchain.prompts import ChatPromptTemplate
from langchain.schema import StrOutputParser
import time
from services.pmo_rag_system import Task, TokenManager
import json

class ChunkedProcessor:
    def __init__(self):
        self.token_manager = TokenManager()
        self.llm = ChatOpenAI(
            model="gpt-4",
            temperature=0,
            max_tokens=4000
        )
        self.max_chunk_tokens = 6000  # Leave room for response
        
    def _create_analysis_chunks(self, user_input: str, rag_output: str, web_output: str) -> List[Dict[str, str]]:
        """Split the input data into manageable chunks."""
        chunks = []
        
        # First, split each input into smaller pieces if needed
        user_input_chunks = self.token_manager.chunk_text(user_input, self.max_chunk_tokens)
        rag_chunks = self.token_manager.chunk_text(rag_output, self.max_chunk_tokens)
        web_chunks = self.token_manager.chunk_text(web_output, self.max_chunk_tokens)
        
        # Create combined chunks that don't exceed token limit
        for i in range(max(len(user_input_chunks), len(rag_chunks), len(web_chunks))):
            chunk = {
                "user_input": user_input_chunks[i] if i < len(user_input_chunks) else "",
                "rag_output": rag_chunks[i] if i < len(rag_chunks) else "",
                "web_output": web_chunks[i] if i < len(web_chunks) else ""
            }
            chunks.append(chunk)
        
        return chunks

    def _analyze_chunk(self, chunk: Dict[str, str], task: Task, chunk_index: int, total_chunks: int) -> str:
        """Analyze a single chunk of data."""
        analysis_prompt = ChatPromptTemplate.from_messages([
            ("system", """You are analyzing a chunk of information ({chunk_index} of {total_chunks}).
            Focus on extracting key insights and patterns from this specific portion of data.
            
            Task Context:
            Title: {title}
            Domain: {domain}
            Stage: {stage}
            
            Provide a focused analysis that will be combined with other chunk analyses later."""),
            ("human", """Analyze this chunk of information:
            
            User Input Chunk: {user_input}
            RAG Output Chunk: {rag_output}
            Web Research Chunk: {web_output}
            
            Extract key insights and patterns that will be useful for the final recommendations.""")
        ])
        
        chain = analysis_prompt | self.llm | StrOutputParser()
        
        return chain.invoke({
            "chunk_index": chunk_index + 1,
            "total_chunks": total_chunks,
            "title": task.title,
            "domain": task.domain,
            "stage": task.stage,
            "user_input": chunk["user_input"],
            "rag_output": chunk["rag_output"],
            "web_output": chunk["web_output"]
        })

    def _synthesize_analyses(self, analyses: List[str], task: Task) -> str:
        """Combine all chunk analyses into a final coherent response."""
        synthesis_prompt = ChatPromptTemplate.from_messages([
            ("system", """You are synthesizing multiple analyses into a final comprehensive recommendation.
            
            Task Context:
            Title: {title}
            Domain: {domain}
            Stage: {stage}
            Best Practices to incorporate:
            {best_practices}
            
            Create a well-structured, coherent response that incorporates insights from all analyses
            and addresses the task requirements while following the best practices."""),
            ("human", """Here are the analyses to synthesize:
            
            {analyses}
            
            Create a comprehensive final response that includes:
            1. Executive Summary
            2. Key Findings
            3. Detailed Recommendations
            4. Implementation Steps
            5. Success Metrics""")
        ])
        
        chain = synthesis_prompt | self.llm | StrOutputParser()
        
        return chain.invoke({
            "title": task.title,
            "domain": task.domain,
            "stage": task.stage,
            "best_practices": "\n".join(f"- {bp}" for bp in task.bestPractices),
            "analyses": "\n\n---\n\n".join(analyses)
        })

    def process_large_input(self, user_input: str, rag_output: str, web_output: str, task: Task) -> str:
        """Process large inputs by chunking and then synthesizing."""
        # Split inputs into chunks
        chunks = self._create_analysis_chunks(user_input, rag_output, web_output)
        
        # Analyze each chunk with rate limiting
        analyses = []
        for i, chunk in enumerate(chunks):
            # Add rate limiting delay
            if i > 0:
                time.sleep(20)  # Wait 20 seconds between chunks to respect rate limits
            
            analysis = self._analyze_chunk(chunk, task, i, len(chunks))
            analyses.append(analysis)
        
        # Wait before final synthesis to respect rate limits
        time.sleep(20)
        
        # Synthesize all analyses into final response
        return self._synthesize_analyses(analyses, task) 