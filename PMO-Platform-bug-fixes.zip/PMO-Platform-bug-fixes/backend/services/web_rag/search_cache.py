"""
Caching implementation for web search results with persistence and TTL support.
"""

import os
import json
import time
from typing import Optional, List, Dict, Any
from datetime import datetime, timedelta

class SearchCache:
    def __init__(self, cache_dir: str, ttl_hours: int = 24):
        """
        Initialize the search cache.
        
        Args:
            cache_dir: Directory to store cache files
            ttl_hours: Time-to-live in hours for cache entries
        """
        self.cache_dir = cache_dir
        self.ttl_hours = ttl_hours
        self.cache_file = os.path.join(cache_dir, "web_search_cache.json")
        self.cache = self._load_cache()
        
    def _load_cache(self) -> Dict[str, Any]:
        """Load the cache from disk."""
        if os.path.exists(self.cache_file):
            try:
                with open(self.cache_file, 'r', encoding='utf-8') as f:
                    cache_data = json.load(f)
                # Clean expired entries on load
                self._clean_expired_entries(cache_data)
                return cache_data
            except Exception:
                return {"queries": {}, "last_cleaned": time.time()}
        return {"queries": {}, "last_cleaned": time.time()}
    
    def _save_cache(self):
        """Save the cache to disk."""
        os.makedirs(self.cache_dir, exist_ok=True)
        with open(self.cache_file, 'w', encoding='utf-8') as f:
            json.dump(self.cache, f, ensure_ascii=False, indent=2)
    
    def _clean_expired_entries(self, cache_data: Dict[str, Any]):
        """Remove expired entries from the cache."""
        now = time.time()
        ttl_seconds = self.ttl_hours * 3600
        
        # Clean expired entries
        expired_keys = []
        for query, entry in cache_data["queries"].items():
            if now - entry["timestamp"] > ttl_seconds:
                expired_keys.append(query)
        
        for key in expired_keys:
            del cache_data["queries"][key]
        
        cache_data["last_cleaned"] = now
    
    def _get_cache_key(self, query: str, k: int) -> str:
        """Generate a cache key from the query and result count."""
        return f"{query}::{k}"
    
    def get(self, query: str, k: int) -> Optional[List[str]]:
        """
        Get results from cache if they exist and are not expired.
        
        Args:
            query: Search query
            k: Number of results requested
            
        Returns:
            List of results or None if not found/expired
        """
        cache_key = self._get_cache_key(query, k)
        entry = self.cache["queries"].get(cache_key)
        
        if not entry:
            return None
            
        # Check if expired
        now = time.time()
        ttl_seconds = self.ttl_hours * 3600
        if now - entry["timestamp"] > ttl_seconds:
            del self.cache["queries"][cache_key]
            self._save_cache()
            return None
            
        return entry["results"][:k]  # Return only requested number of results
    
    def set(self, query: str, k: int, results: List[str]):
        """
        Store results in cache.
        
        Args:
            query: Search query
            k: Number of results
            results: Search results to cache
        """
        cache_key = self._get_cache_key(query, k)
        self.cache["queries"][cache_key] = {
            "timestamp": time.time(),
            "results": results
        }
        self._save_cache()
    
    def clear_expired(self):
        """Clear expired entries from the cache."""
        self._clean_expired_entries(self.cache)
        self._save_cache() 