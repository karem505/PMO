import os
import time
from typing import List
from langchain_community.tools import DuckDuckGoSearchRun
from langchain_openai import ChatOpenAI
from langchain.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from rich.console import Console

console = Console()

class SimpleWebSearcher:
    def __init__(self):
        """Initialize the simple web searcher."""
        self.web_searcher = DuckDuckGoSearchRun()
        
        # Initialize LLM if API key is available
        try:
            self.llm = ChatOpenAI(model="gpt-3.5-turbo")
            self.has_llm = True
        except Exception as e:
            console.print("[yellow]Warning: Could not initialize LLM. Will use basic search queries.[/yellow]")
            self.has_llm = False
        
    def generate_search_queries(self, user_input: str) -> List[str]:
        """Generate 3-5 relevant search queries from user input."""
        if not self.has_llm:
            # Fallback to basic query generation
            return [
                f"{user_input} project management best practices",
                f"{user_input} methodology implementation",
                f"{user_input} team management approach"
            ]
            
        prompt = ChatPromptTemplate.from_template("""
        Generate 3-5 specific search queries based on this input:
        {user_input}
        
        The queries should:
        1. Be focused on project management best practices
        2. Include specific methodologies or frameworks if mentioned
        3. Be clear and concise
        
        Return only the queries, one per line.
        """)
        
        chain = prompt | self.llm | StrOutputParser()
        result = chain.invoke({"user_input": user_input})
        
        # Split into lines and clean up
        queries = [q.strip() for q in result.split('\n') if q.strip()]
        return queries[:5]  # Ensure we only return up to 5 queries
    
    def search(self, user_input: str) -> List[str]:
        """
        Perform web search using generated queries.
        
        Args:
            user_input: The user's input text
            
        Returns:
            List of search results
        """
        try:
            # Generate search queries
            queries = self.generate_search_queries(user_input)
            console.print(f"[green]Generated {len(queries)} search queries[/green]")
            
            all_results = []
            
            # Search for each query
            for query in queries:
                try:
                    console.print(f"[yellow]Searching for: {query}[/yellow]")
                    result = self.web_searcher.invoke(query)
                    
                    # Split into sentences and clean up
                    sentences = [s.strip() for s in result.split('.') if s.strip()]
                    valid_results = [s for s in sentences if len(s) > 30]  # Filter out very short results
                    
                    if valid_results:
                        all_results.extend(valid_results)
                        console.print(f"[green]Found {len(valid_results)} results[/green]")
                    
                    # Add a small delay between searches
                    time.sleep(1)
                    
                except Exception as e:
                    console.print(f"[red]Error searching for '{query}': {str(e)}[/red]")
                    continue
            
            # Remove duplicates while preserving order
            unique_results = []
            seen = set()
            for result in all_results:
                if result not in seen:
                    seen.add(result)
                    unique_results.append(result)
            
            return unique_results[:10]  # Return top 10 results
            
        except Exception as e:
            console.print(f"[red]Error in web search: {str(e)}[/red]")
            return [] 