"""
Configuration settings for web search functionality.
These settings can be adjusted to fine-tune the search behavior.
"""

# Retry configuration
MAX_RETRIES = 2
INITIAL_BACKOFF_SECONDS = 5
MAX_BACKOFF_SECONDS = 30

# Timeout settings
SEARCH_TIMEOUT_SECONDS = 30
GLOBAL_REQUEST_TIMEOUT = 30

# Rate limiting protection
MIN_DELAY_BETWEEN_SEARCHES = 2.0
MAX_DELAY_BETWEEN_SEARCHES = 4.0

# Search result settings
MIN_RESULTS_LENGTH = 30
DEFAULT_RESULTS_COUNT = 5

# Cache settings
CACHE_TTL_HOURS = 24
CACHE_DIRECTORY = "cache/web_search"

# DuckDuckGo primary search settings
PRIMARY_SEARCH_CONFIG = {
    "region": "wt-wt",
    "time": "a",
    "safesearch": "off",
    "max_results": 20
}

# DuckDuckGo backup search settings
BACKUP_SEARCH_CONFIG = {
    "region": "wt-wt",
    "time": "a",
    "safesearch": "off",
    "max_results": 10
}

# Query variation templates
# {query} will be replaced with the actual query
QUERY_VARIATIONS = [
    "{query}",
    "{query} best practices",
    "{query} methodology"
] 