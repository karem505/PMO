from typing import Dict, List, Any, Optional
from openai import OpenAI
from dotenv import load_dotenv
import os
import json

load_dotenv()

class AIValidationService:
    def __init__(self):
        self.client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        self.model = "gpt-4-turbo-preview"

    async def validate_code(self, code: str, language: str, rules: Optional[List[str]] = None) -> Dict[str, Any]:
        prompt = f"""
        Validate the following {language} code against best practices and standards.
        {f'Additional rules to check: {", ".join(rules)}' if rules else ''}
        
        Code:
        {code}
        
        Please provide:
        1. Code quality score (0-100)
        2. List of violations found
        3. Suggestions for improvement
        4. Security concerns
        """

        response = await self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": "You are a code validation expert."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.3
        )

        return {
            "code": code,
            "language": language,
            "validation_result": response.choices[0].message.content
        }

    async def validate_schema(self, schema: Dict[str, Any], database_type: str) -> Dict[str, Any]:
        prompt = f"""
        Validate the following {database_type} database schema:
        
        {json.dumps(schema, indent=2)}
        
        Please check for:
        1. Normalization violations
        2. Missing indexes
        3. Data type appropriateness
        4. Naming conventions
        5. Foreign key relationships
        """

        response = await self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": "You are a database schema validation expert."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.3
        )

        return {
            "schema": schema,
            "database_type": database_type,
            "validation_result": response.choices[0].message.content
        }

    async def validate_best_practices(self, content: str, content_type: str) -> Dict[str, Any]:
        prompt = f"""
        Validate the following {content_type} against industry best practices:
        
        {content}
        
        Please provide:
        1. Compliance score (0-100)
        2. Areas of improvement
        3. Specific recommendations
        4. Risk assessment
        """

        response = await self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": "You are a best practices validation expert."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.3
        )

        return {
            "content": content,
            "content_type": content_type,
            "validation_result": response.choices[0].message.content
        } 