import asyncio
import functools
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Callable, TypeVar, Coroutine

# Type variable for return values
T = TypeVar('T')

# Thread pool for running sync functions in a non-blocking way
thread_pool = ThreadPoolExecutor(max_workers=10)

def to_async(func: Callable[..., T]) -> Callable[..., Coroutine[Any, Any, T]]:
    """
    Convert a synchronous function to an asynchronous one by running it in a thread pool.
    This is useful for making non-async Supabase operations non-blocking.
    
    Args:
        func: The synchronous function to convert
        
    Returns:
        An async function that runs the original function in a thread pool
    """
    @functools.wraps(func)
    async def wrapper(*args, **kwargs):
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            thread_pool, 
            lambda: func(*args, **kwargs)
        )
    return wrapper

class AsyncSupabaseWrapper:
    """
    A wrapper around the Supabase client that provides async versions of common operations.
    Since the Supabase Python client doesn't support native async/await, this wrapper
    runs operations in a thread pool to make them non-blocking.
    """
    
    def __init__(self, supabase_client):
        self.client = supabase_client
        
    @to_async
    def select(self, table: str, columns: str = "*"):
        """Async version of supabase.from_(table).select(columns)"""
        return self.client.from_(table).select(columns)
    
    @to_async
    def insert(self, table: str, data: dict):
        """Async version of supabase.from_(table).insert(data)"""
        return self.client.from_(table).insert(data)
    
    @to_async
    def update(self, table: str, data: dict):
        """Async version of supabase.from_(table).update(data)"""
        return self.client.from_(table).update(data)
    
    @to_async
    def delete(self, table: str):
        """Async version of supabase.from_(table).delete()"""
        return self.client.from_(table).delete()
    
    @to_async
    def execute(self, query):
        """Execute a query that has already been prepared"""
        return query.execute()
    
    @to_async
    def storage_upload(self, bucket: str, path: str, file):
        """Async version of supabase.storage.from_(bucket).upload(path, file)"""
        return self.client.storage.from_(bucket).upload(path, file)
    
    @to_async
    def storage_get_public_url(self, bucket: str, path: str):
        """Async version of supabase.storage.from_(bucket).get_public_url(path)"""
        return self.client.storage.from_(bucket).get_public_url(path)

# Helper function to get an async Supabase client
def get_async_supabase_client(supabase_client):
    """
    Get an async wrapper for a Supabase client.
    
    Args:
        supabase_client: The synchronous Supabase client
        
    Returns:
        An AsyncSupabaseWrapper instance
    """
    return AsyncSupabaseWrapper(supabase_client) 