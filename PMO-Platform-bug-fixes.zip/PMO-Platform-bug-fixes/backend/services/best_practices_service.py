from typing import Dict, List, Any, Optional
from openai import OpenAI
from dotenv import load_dotenv
import os
import json

load_dotenv()

class BestPracticesService:
    def __init__(self):
        self.client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        self.model = "gpt-4-turbo-preview"

    async def analyze_code_best_practices(self, code: str, language: str) -> Dict[str, Any]:
        prompt = f"""
        Analyze the following {language} code for best practices:
        
        {code}
        
        Please provide:
        1. Code structure assessment
        2. Performance considerations
        3. Security best practices
        4. Maintainability score
        5. Specific recommendations
        """

        response = await self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": "You are a code best practices expert."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.3
        )

        return {
            "code": code,
            "language": language,
            "analysis": response.choices[0].message.content
        }

    async def get_best_practices_guidelines(self, category: str) -> Dict[str, Any]:
        prompt = f"""
        Provide comprehensive best practices guidelines for {category}.
        Include:
        1. Key principles
        2. Common pitfalls to avoid
        3. Implementation examples
        4. Performance considerations
        5. Security recommendations
        """

        response = await self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": "You are a best practices guidelines expert."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.3
        )

        return {
            "category": category,
            "guidelines": response.choices[0].message.content
        }

    async def compare_with_best_practices(self, content: str, content_type: str) -> Dict[str, Any]:
        prompt = f"""
        Compare the following {content_type} with industry best practices:
        
        {content}
        
        Please provide:
        1. Compliance score (0-100)
        2. Areas of non-compliance
        3. Specific improvements needed
        4. Risk assessment
        5. Implementation recommendations
        """

        response = await self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": "You are a best practices comparison expert."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.3
        )

        return {
            "content": content,
            "content_type": content_type,
            "comparison": response.choices[0].message.content
        }

    async def generate_best_practices_template(self, template_type: str) -> Dict[str, Any]:
        prompt = f"""
        Generate a best practices template for {template_type}.
        Include:
        1. Structure and format
        2. Required sections
        3. Example content
        4. Implementation guidelines
        5. Quality checkpoints
        """

        response = await self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": "You are a best practices template expert."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.3
        )

        return {
            "template_type": template_type,
            "template": response.choices[0].message.content
        } 