from fastapi import APIRouter, UploadFile, File, HTTPException, Depends
from fastapi.responses import JSONResponse
from typing import Dict, Any
from services.document_reader_service import DocumentReaderService
from models.document import DocumentResponse, DocumentError
from auth import get_current_user

router = APIRouter()
document_reader_service = DocumentReaderService()

@router.post("/read-document", response_model=DocumentResponse, responses={400: {"model": DocumentError}, 500: {"model": DocumentError}})
async def read_document(
    file: UploadFile = File(...),
    current_user: Dict[str, Any] = Depends(get_current_user)
):
    """
    Read and extract content from various document formats
    """
    try:
        # Read file content
        content = await file.read()
        
        # Process the document
        result = await document_reader_service.read_document(content, file.filename)
        
        # Print the output for testing
        print("\n=== Document Reading Results ===")
        print(f"Filename: {result['filename']}")
        print(f"File Type: {result['file_type']}")
        print("\nContent Preview (first 500 chars):")
        print(result['content'][:500] + "..." if len(result['content']) > 500 else result['content'])
        print("\nTables Found:", len(result['tables']))
        print("Metadata:", result['metadata'])
        print("================================\n")
        
        return DocumentResponse(**result)
    except ValueError as ve:
        raise HTTPException(status_code=400, detail=str(ve))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)) 