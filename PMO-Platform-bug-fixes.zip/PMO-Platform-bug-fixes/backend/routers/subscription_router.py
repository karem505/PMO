from fastapi import APIRouter, HTTPException, Depends
from typing import Dict, Any, Optional
from services.subscription import SubscriptionService
from config.supabase import supabase
from datetime import datetime
from pydantic import BaseModel
import os
from dotenv import load_dotenv
from services.document_utils import get_supabase_client


load_dotenv()

router = APIRouter(
    tags=["subscription"],
    responses={
        404: {"description": "Not found"},
        500: {"description": "Internal server error"}
    }
)

# Initialize subscription service
subscription_service = SubscriptionService(supabase)

# Initialize Supabase client
supabase_client = get_supabase_client()
if not supabase_client:
    raise HTTPException(
                status_code=500,
                detail="Failed to initialize Supabase client"
            )
class UserEmailRequest(BaseModel):
    user_email: str

@router.get("/status", 
    response_model=Dict[str, Any],
    summary="Get user's subscription status",
    description="Retrieves user's token subscription status including remaining tokens and whether they have sufficient tokens.",
    responses={
        200: {
            "description": "Successful response",
            "content": {
                "application/json": {
                    "example": {
                        "user_id": "f8f65065-8c0d-4b42-b88d-b19071d718f2",
                        "email": "user@example.com",
                        "tier": "pro",
                        "remaining_tokens": 50000,
                        "has_sufficient_tokens": True
                    }
                }
            }
        },
        404: {"description": "User or subscription not found"}
    }
)
async def get_subscription_status(user_email: str) -> Dict[str, Any]:
    """Get user's token subscription status."""
    try:
        # Get user
        user = subscription_service.get_user_by_email(user_email)
        if not user:
            raise HTTPException(
                status_code=404,
                detail=f"User not found with email: {user_email}"
            )
        
        user_id = user.get("id")
        
        # Get subscription details
        subscription = subscription_service.supabase.table("subscriptions")\
            .select("*")\
            .eq("user_id", user_id)\
            .single()\
            .execute()
            
        if not subscription.data:
            # Return default free tier if no subscription found
            return {
                "user_id": user_id,
                "email": user_email,
                "tier": "free",
                "remaining_tokens": 81250,  # Default free tier tokens
                "has_sufficient_tokens": True
            }
        
        # Get token usage
        usage = subscription_service.supabase.table("subscription_usage")\
            .select("count")\
            .eq("user_id", user_id)\
            .single()\
            .execute()
        
        token_count = usage.data.get("count", 0) if usage.data else 81250  # Default to free tier tokens
        
        return {
            "user_id": user_id,
            "email": user_email,
            "tier": subscription.data.get("tier", "free"),
            "remaining_tokens": token_count,
            "has_sufficient_tokens": token_count >= 13000
        }
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        print(f"Error getting subscription status: {str(e)}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/debug")
async def debug_subscriptions(user_email: Optional[str] = None) -> Dict[str, Any]:
    """Debug endpoint to display subscription information."""
    try:
        # If specific email provided, debug that user
        if user_email:
            print(f"DEBUG: Looking up specific user: {user_email}")
            
            # Get user profile
            user = subscription_service.get_user_by_email(user_email)
            
            # Get subscription usage
            subscription = None
            if user:
                subscription = subscription_service.get_subscription_usage(user.get("id"))
            
            return {
                "user": user,
                "subscription": subscription,
                "timestamp": str(datetime.now())
            }
        
        # Otherwise show summary counts
        profiles_count = 0
        subscriptions_count = 0
        
        try:
            profiles_response = subscription_service.supabase.table("profiles").select("count").execute()
            profiles_count = profiles_response.count if hasattr(profiles_response, 'count') else 0
            
            subscriptions_response = subscription_service.supabase.table("subscription_usage").select("count").execute()
            subscriptions_count = subscriptions_response.count if hasattr(subscriptions_response, 'count') else 0
        except Exception as e:
            print(f"Error counting records: {str(e)}")
        
        return {
            "message": "To see specific user info, add ?user_email=example@email.com",
            "profiles_count": profiles_count,
            "subscriptions_count": subscriptions_count,
            "timestamp": str(datetime.now())
        }
    except Exception as e:
        print(f"Error in debug endpoint: {str(e)}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e)) 

@router.post("/set",
    response_model=Dict[str, Any],
    summary="Set user subscription data",
    description="Sets user subscription data and updates subscription usage based on tier",
    responses={
        200: {
            "description": "Subscription successfully set",
            "content": {
                "application/json": {
                    "example": {
                        "user_id": "f8f65065-8c0d-4b42-b88d-b19071d718f2",
                        "tier": "pro",
                        "status": "active",
                        "tokens": 406250
                    }
                }
            }
        },
        400: {"description": "Invalid tier provided"},
        404: {"description": "User not found"}
    }
)
async def set_subscription(
    user_email: str,
    tier: str,
    payment_provider: Optional[str] = None,
    payment_id: Optional[str] = None
) -> Dict[str, Any]:
    """Set user subscription data and update token count based on tier."""
    try:
        # Validate tier
        valid_tiers = {'free', 'pro', 'enterprise'}
        if tier not in valid_tiers:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid tier. Must be one of: {', '.join(valid_tiers)}"
            )
        
        # Get user
        user = subscription_service.get_user_by_email(user_email)
        if not user:
            raise HTTPException(
                status_code=404,
                detail=f"User not found with email: {user_email}"
            )
        
        user_id = user.get("id")
        
        # Set subscription data
        subscription_data = {
            "user_id": user_id,
            "tier": tier,
            "status": "active",  
            "payment_provider": payment_provider,
            "payment_id": payment_id
        }
        
        # Update or insert subscription
        result = subscription_service.supabase.table("subscriptions").upsert(
            subscription_data
        ).execute()
        
        # Set token count based on tier
        token_counts = {
            "free": 81250,
            "pro": 406250,
            "enterprise": 2031250
        }
        
        usage_data = {
            "user_id": user_id,
            "count": token_counts[tier],
            "feature": tier
        }
        
        # Update or insert subscription usage
        usage_result = subscription_service.supabase.table("subscription_usage").upsert(
            usage_data
        ).execute()
        
        return {
            "user_id": user_id,
            "tier": tier,
            "status": "active",
            "tokens": token_counts[tier]
        }
        
    except Exception as e:
        print(f"Error setting subscription: {str(e)}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e)) 

@router.get("/check-premium",
    response_model=Dict[str, bool],
    summary="Check if user has premium subscription with sufficient tokens",
    description="Returns true if user has enterprise/pro subscription with more than 5000 tokens",
    responses={
        200: {
            "description": "Successfully checked premium status",
            "content": {
                "application/json": {
                    "example": {
                        "is_premium": True
                    }
                }
            }
        },
        404: {"description": "User not found"}
    }
)
async def check_premium_subscription(user_email: str) -> Dict[str, bool]:
    """Check if user has a premium subscription with sufficient tokens."""
    try:
        # Get user
        user = subscription_service.get_user_by_email(user_email)
        if not user:
            raise HTTPException(
                status_code=404,
                detail=f"User not found with email: {user_email}"
            )
        
        user_id = user.get("id")
        
        # Get subscription details
        subscription = subscription_service.supabase.table("subscriptions")\
            .select("tier")\
            .eq("user_id", user_id)\
            .single()\
            .execute()
        
        if not subscription.data:
            return {"is_premium": False}
        
        tier = subscription.data.get("tier")
        
        # Check if tier is premium (enterprise or pro)
        if tier not in ['enterprise', 'pro']:
            return {"is_premium": False}
        
        # Get token count
        usage = subscription_service.supabase.table("subscription_usage")\
            .select("count")\
            .eq("user_id", user_id)\
            .single()\
            .execute()
        
        if not usage.data:
            return {"is_premium": False}
        
        token_count = usage.data.get("count", 0)
        
        # Return true if premium tier and has more than 5000 tokens
        return {
            "is_premium": token_count > 5000
        }
        
    except Exception as e:
        print(f"Error checking premium subscription: {str(e)}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/setup-free")
async def setup_free_subscription(request: UserEmailRequest) -> Dict[str, Any]:
    """Set up a free subscription for a new user."""
    try:
        user_email = request.user_email
        print(f"Setting up free subscription for user: {user_email}")
        
        # Check if user exists
        user_data = None
        try:
            # Try to find the user by email
            user_response = supabase_client.from_("profiles").select("*").eq("email", user_email).execute()
            if user_response.data and len(user_response.data) > 0:
                user_data = user_response.data[0]
        except Exception as e:
            print(f"Error checking for existing user: {e}")
            # User not found, continue with creation
        
        if not user_data:
            print(f"User with email {user_email} not found in profiles")
            # We need to get the user ID from auth
            try:
                auth_user = None
                # First try to get from auth admin API
                try:
                    # Use the auth admin API to list users and find by email
                    auth_users = supabase_client.auth.admin.list_users()
                    if auth_users and hasattr(auth_users, 'users'):
                        for user in auth_users.users:
                            if hasattr(user, 'email') and user.email == user_email:
                                auth_user = user
                                break
                except Exception as admin_error:
                    print(f"Error using auth admin API: {admin_error}")
                
                # If not found via admin API, try RPC
                if not auth_user:
                    try:
                        auth_response = supabase_client.rpc("get_user_by_email", {"email_param": user_email}).execute()
                        if auth_response.data:
                            auth_user = {"id": auth_response.data.get("id")}
                    except Exception as rpc_error:
                        print(f"Error using RPC get_user_by_email: {rpc_error}")
                
                if not auth_user:
                    raise HTTPException(status_code=404, detail=f"User with email {user_email} not found")
                
                user_id = auth_user.id if hasattr(auth_user, 'id') else auth_user["id"]
            except Exception as auth_error:
                print(f"Error getting user from auth: {auth_error}")
                raise HTTPException(status_code=404, detail=f"User with email {user_email} not found")
        else:
            user_id = user_data["id"]
        
        # Check if user already has a subscription
        try:
            subscription_response = supabase_client.from_("subscriptions").select("*").eq("user_id", user_id).execute()
            
            # If user already has a subscription, return it
            if subscription_response.data and len(subscription_response.data) > 0:
                existing_subscription = subscription_response.data[0]
                
                # Get token count
                try:
                    usage_response = supabase_client.from_("subscription_usage").select("*").eq("user_id", user_id).execute()
                    token_count = 0
                    if usage_response.data and len(usage_response.data) > 0:
                        token_count = usage_response.data[0].get("count", 0)
                    
                    return {
                        "user_id": user_id,
                        "email": user_email,
                        "tier": existing_subscription.get("tier", "free"),
                        "tokens": token_count
                    }
                except Exception as usage_error:
                    print(f"Error getting token count: {usage_error}")
                    return {
                        "user_id": user_id,
                        "email": user_email,
                        "tier": existing_subscription.get("tier", "free"),
                        "tokens": 0
                    }
        except Exception as sub_error:
            print(f"Error checking existing subscription: {sub_error}")
        
        # Set subscription data for free tier
        subscription_data = {
            "user_id": user_id,
            "tier": "free",
            "status": "active",
            "payment_provider": None,
            "payment_id": None,
            "start_date": datetime.utcnow().isoformat()
        }
        
        # Insert subscription
        try:
            subscription_result = supabase_client.from_("subscriptions").insert(subscription_data).execute()
            print(f"Created subscription for user {user_id}")
        except Exception as sub_insert_error:
            print(f"Error inserting subscription: {sub_insert_error}")
        
        # Set token count for free tier
        token_count = 81250  # Default free tier token count
        
        usage_data = {
            "user_id": user_id,
            "count": token_count,
            "feature": "free"
        }
        
        # Insert subscription usage
        try:
            usage_result = supabase_client.from_("subscription_usage").insert(usage_data).execute()
            print(f"Created subscription usage for user {user_id} with {token_count} tokens")
        except Exception as usage_error:
            print(f"Error inserting subscription usage: {usage_error}")
        
        return {
            "user_id": user_id,
            "email": user_email,
            "tier": "free",
            "tokens": token_count
        }
        
    except HTTPException as http_ex:
        raise http_ex
    except Exception as e:
        print(f"Error setting up free subscription: {str(e)}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Subscription setup error: {str(e)}")