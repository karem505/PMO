from fastapi import APIRouter, HTTPException, Depends, Request, Body
import requests
import base64
import os
from dotenv import load_dotenv
import uuid
from pydantic import BaseModel
from typing import Optional

load_dotenv()

router = APIRouter()

API_URL = os.getenv("MPGS_API_URL", "https://banquemisr.gateway.mastercard.com/api/rest")
API_VERSION = os.getenv("MPGS_API_VERSION", "100")
MERCHANT_ID = os.getenv("MPGS_MERCHANT_ID", "PROFESSIONAL")
API_USERNAME = os.getenv("MPGS_API_USERNAME", f"merchant.{MERCHANT_ID}")
API_PASSWORD = os.getenv("MPGS_API_PASSWORD", "d94cebc375c015c067fa625dcdcb9dd1")

# تحديد نموذج بيانات الطلب
class PaymentRequest(BaseModel):
    amount: float
    currency: str = "EGP"
    description: str
    orderId: Optional[str] = None

@router.post("/mpgs/initiate")
async def initiate_checkout(request_data: PaymentRequest = Body(...)):
    try:
        # إنشاء بيانات الاعتماد
        credentials = f"{API_USERNAME}:{API_PASSWORD}"
        encoded_credentials = base64.b64encode(credentials.encode()).decode()
        
        # تحضير الرؤوس مع بيانات الاعتماد
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Basic {encoded_credentials}"
        }

        # 1. إنشاء جلسة جديدة
        session_response = requests.post(
            f"{API_URL}/version/{API_VERSION}/merchant/{MERCHANT_ID}/session",
            headers=headers
        )

        # فحص الاستجابة
        if session_response.status_code != 201:
            print(f"Session creation failed: {session_response.text}")
            raise HTTPException(
                status_code=session_response.status_code, 
                detail=f"Bank Masr API error: {session_response.text}"
            )

        # الحصول على معرف الجلسة
        session_id = session_response.json().get('session', {}).get('id')
        if not session_id:
            raise HTTPException(status_code=500, detail="No session ID returned from payment gateway")
            
        # استخدام معرف الطلب المقدم أو إنشاء واحد جديد
        order_id = request_data.orderId or f"order_{uuid.uuid4().hex[:8]}"
        
        # 2. تحديث الجلسة بمعلومات الطلب
        update_payload = {
            "apiOperation": "CREATE_CHECKOUT_SESSION",
            "order": {
                "amount": str(request_data.amount),
                "currency": request_data.currency,
                "id": order_id,
                "description": request_data.description
            },
            # "interaction": {
            #     "merchant": {
            #         "name": "Professional PMO",
            #     },
            #     # "returnUrl": "http://localhost:5137/payment/callback?orderId={order_id}",
            #     # "cancelUrl": "http://localhost:5137/pricing?subscription=canceled"
            # }
        }

        update_response = requests.put(
            f"{API_URL}/version/{API_VERSION}/merchant/{MERCHANT_ID}/session/{session_id}",
            headers=headers,
            json=update_payload
        )

        # فحص استجابة التحديث
        if update_response.status_code != 200:
            print(f"Session update failed: {update_response.text}")
            raise HTTPException(
                status_code=update_response.status_code, 
                detail=f"Failed to update session: {update_response.text}"
            )

        # 3. التحقق من نجاح الطلب
        verification_response = requests.get(
            f"{API_URL}/version/{API_VERSION}/merchant/{MERCHANT_ID}/session/{session_id}",
            headers=headers
        )
        
        if verification_response.status_code != 200:
            print(f"Session verification failed: {verification_response.text}")
        print(verification_response.json())
        # 4. إعادة البيانات إلى الواجهة الأمامية
        return verification_response.json()

    except Exception as e:
        print(f"Payment initiation error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))
