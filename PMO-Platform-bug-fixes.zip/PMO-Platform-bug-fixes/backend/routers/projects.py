from fastapi import APIRouter, HTTPException, Depends, Body
from typing import Optional, List, Dict, Any
from pydantic import BaseModel
from datetime import datetime
from supabase import create_client
import os
from dotenv import load_dotenv
import logging

load_dotenv()

router = APIRouter(
    tags=["projects"],
    responses={404: {"description": "Not found"}}
)

# Initialize Supabase client
supabase = create_client(
    os.getenv("SUPABASE_URL"),
    os.getenv("SUPABASE_SERVICE_ROLE_KEY")
)

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class StakeholderModel(BaseModel):
    name: str
    role: str

class RiskModel(BaseModel):
    description: str
    severity: str
    mitigation: str

class ProjectCreate(BaseModel):
    name: Optional[str] = None
    owner_id: Optional[str] = None
    description: Optional[str] = None
    budget: Optional[float] = None
    budget_spent: Optional[float] = 0
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    key_objectives: Optional[List[str]] = []
    stakeholders: Optional[List[StakeholderModel]] = []
    risks: Optional[List[RiskModel]] = []
    is_active: Optional[bool] = True
    email: Optional[str] = None  # Add email field for simplified creation
    is_default: Optional[bool] = False  # Add is_default flag for tracking default projects

@router.post("/")
async def create_project(project: ProjectCreate):
    try:
        # Always prioritize email if provided
        if project.email:
            # Get user ID from email
            result = supabase.from_("profiles").select("id").eq("email", project.email).execute()
            
            # If user not found in profiles, try auth.users
            if not result.data or len(result.data) == 0:
                result = supabase.auth.admin.list_users(query={"email": project.email})
                if result.users and len(result.users) > 0:
                    owner_id = result.users[0].id
                else:
                    raise HTTPException(status_code=404, detail="User not found with provided email")
            else:
                owner_id = result.data[0]["id"]
            
            # Before creating a default project, check if user already has one
            if project.is_default or (not project.name or project.name == "string" or project.owner_id == "string"):
                # Check for existing default project
                existing_default = supabase.from_("projects").select("id").eq("owner_id", owner_id).eq("is_default", True).execute()
                existing_by_name = supabase.from_("projects").select("id").eq("owner_id", owner_id).eq("name", "PMO Implementation Starter").execute()
                
                if (existing_default.data and len(existing_default.data) > 0) or \
                   (existing_by_name.data and len(existing_by_name.data) > 0):
                    logger.info(f"User {owner_id} already has a default project, returning existing")
                    
                    # Get the first existing default project
                    project_id = ""
                    if existing_default.data and len(existing_default.data) > 0:
                        project_id = existing_default.data[0]["id"]
                    else:
                        project_id = existing_by_name.data[0]["id"]
                        # Update the is_default flag for this project
                        supabase.from_("projects").update({"is_default": True}).eq("id", project_id).execute()
                    
                    # Get the full project details
                    existing_project = supabase.from_("projects").select("*").eq("id", project_id).execute()
                    if existing_project.data and len(existing_project.data) > 0:
                        return {"status": "success", "data": existing_project.data[0], "message": "Using existing default project"}
            
                # Create default project data
                data = {
                    "name": "PMO Implementation Starter",
                    "owner_id": owner_id,
                    "budget": 50000,
                    "description": """Welcome to your PMO Implementation Project! This starter project includes essential PMO setup activities.
                    
Key Objectives:
• Establish PMO governance framework
• Define project management methodology
• Set up project portfolio tracking
• Create templates and tools
• Plan team training and development""",
                    "is_active": True,
                    "is_default": True
                }
            else:
                # Create project with provided data but use the owner_id from email
                # Convert Pydantic models to dict for JSON serialization
                stakeholders = [s.dict() for s in project.stakeholders] if project.stakeholders else []
                risks = [r.dict() for r in project.risks] if project.risks else []
                
                data = {
                    "name": project.name,
                    "owner_id": owner_id,  # Use owner_id from email lookup
                    "description": project.description or "",
                    "budget": project.budget or 0,
                    "budget_spent": project.budget_spent or 0,
                    "start_date": project.start_date.isoformat() if project.start_date else datetime.now().isoformat(),
                    "end_date": project.end_date.isoformat() if project.end_date else (datetime.now().replace(month=datetime.now().month + 6)).isoformat(),
                    "key_objectives": project.key_objectives or [],
                    "stakeholders": stakeholders,
                    "risks": risks,
                    "is_active": project.is_active,
                    "is_default": project.is_default or False
                }
        # Case 2: Full project details provided without email
        else:
            if not project.name or not project.owner_id or project.name == "string" or project.owner_id == "string":
                raise HTTPException(status_code=400, detail="Valid name and owner_id are required fields")
            
            # If this is a default project, check if one already exists
            if project.is_default:
                existing_default = supabase.from_("projects").select("id").eq("owner_id", project.owner_id).eq("is_default", True).execute()
                existing_by_name = supabase.from_("projects").select("id").eq("owner_id", project.owner_id).eq("name", "PMO Implementation Starter").execute()
                
                if (existing_default.data and len(existing_default.data) > 0) or \
                   (existing_by_name.data and len(existing_by_name.data) > 0):
                    logger.info(f"User {project.owner_id} already has a default project, returning existing")
                    
                    # Get the first existing default project
                    project_id = ""
                    if existing_default.data and len(existing_default.data) > 0:
                        project_id = existing_default.data[0]["id"]
                    else:
                        project_id = existing_by_name.data[0]["id"]
                        # Update the is_default flag for this project
                        supabase.from_("projects").update({"is_default": True}).eq("id", project_id).execute()
                    
                    # Get the full project details
                    existing_project = supabase.from_("projects").select("*").eq("id", project_id).execute()
                    if existing_project.data and len(existing_project.data) > 0:
                        return {"status": "success", "data": existing_project.data[0], "message": "Using existing default project"}
            
            # Convert Pydantic models to dict for JSON serialization
            stakeholders = [s.dict() for s in project.stakeholders] if project.stakeholders else []
            risks = [r.dict() for r in project.risks] if project.risks else []
            
            data = {
                "name": project.name,
                "owner_id": project.owner_id,
                "description": project.description or "",
                "budget": project.budget or 0,
                "budget_spent": project.budget_spent or 0,
                "start_date": project.start_date.isoformat() if project.start_date else datetime.now().isoformat(),
                "end_date": project.end_date.isoformat() if project.end_date else (datetime.now().replace(month=datetime.now().month + 6)).isoformat(),
                "key_objectives": project.key_objectives or [],
                "stakeholders": stakeholders,
                "risks": risks,
                "is_active": project.is_active,
                "is_default": project.is_default or False
            }
        
        # Insert into Supabase
        result = supabase.from_('projects').insert(data).execute()
        
        if result.data:
            logger.info(f"Project created successfully with ID: {result.data[0]['id']}")
            return {"status": "success", "data": result.data[0]}
        else:
            raise HTTPException(status_code=400, detail="Failed to create project")
            
    except Exception as e:
        logger.error(f"Error creating project: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# Helper function to get user_id from email
@router.get("/user/{email}")
async def get_user_id_by_email(email: str):
    try:
        # Query the auth.users table to get the user_id
        result = supabase.from_("auth.users").select("id").eq("email", email).execute()
        
        if result.data and len(result.data) > 0:
            return {"user_id": result.data[0]["id"]}
        else:
            raise HTTPException(status_code=404, detail="User not found")
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/{project_id}")
async def get_project_by_id(project_id: str):
    try:
        logger.info(f"Fetching project with ID: {project_id}")
        
        # First verify and get the project
        project_result = supabase.from_('projects') \
            .select("*") \
            .eq("id", project_id) \
            .single() \
            .execute()
            
        if not project_result.data:
            logger.warning(f"Project not found with ID: {project_id}")
            raise HTTPException(status_code=404, detail="Project not found")

        project_data = project_result.data
            
        # Separately fetch domain data if it exists
        logger.info("Fetching domain data")
        try:
            domain_result = supabase.from_('project_domain_data') \
                .select("*") \
                .eq("project_id", project_id) \
                .execute()
                
            if domain_result.data:
                project_data['domain_data'] = domain_result.data
            else:
                project_data['domain_data'] = []
                
        except Exception as domain_error:
            logger.warning(f"Error fetching domain data: {str(domain_error)}")
            project_data['domain_data'] = []
            
        # Get tasks data for this project
        logger.info("Fetching project tasks")
        try:
            tasks_result = supabase.from_('project_tasks') \
                .select("*") \
                .eq("project_id", project_id) \
                .execute()
                
            project_data['tasks'] = tasks_result.data if tasks_result.data else []
                
        except Exception as tasks_error:
            logger.warning(f"Error fetching tasks: {str(tasks_error)}")
            project_data['tasks'] = []
        
        logger.info(f"Successfully fetched project data for ID: {project_id}")
        return project_data
            
    except Exception as e:
        logger.error(f"Error fetching project: {str(e)}")
        if "Invalid input syntax for type uuid" in str(e):
            raise HTTPException(status_code=400, detail="Invalid project ID format")
        raise HTTPException(
            status_code=500, 
            detail=f"Failed to fetch project: {str(e)}"
        )
    

