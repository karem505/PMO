from fastapi import APIRouter, UploadFile, File, HTTPException, Depends, Header, status, Form
from fastapi.responses import JSONResponse, FileResponse
import os
from pathlib import Path
import shutil
from typing import List, Optional, Dict, Any
from services.document_reader_service import DocumentReaderService
import hashlib
import time
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import jwt
from datetime import datetime, timedelta
from .auth import get_current_user
from pydantic import BaseModel
import json

router = APIRouter(
    tags=["documents"],
    responses={404: {"description": "Not found"}},
)
document_reader = DocumentReaderService()
security = HTTPBearer(auto_error=False)  # Make authentication optional

# Add a global flag to track if JWT warning was already shown
JWT_WARNING_SHOWN = False

# Ensure documents directory exists
DOCUMENTS_DIR = Path("documents")
DOCUMENTS_DIR.mkdir(exist_ok=True)

# Create completed tasks directory
COMPLETED_TASKS_DIR = DOCUMENTS_DIR / "completed-tasks"
COMPLETED_TASKS_DIR.mkdir(exist_ok=True)

# Rate limiting settings
RATE_LIMIT_WINDOW = 3600  # 1 hour in seconds
MAX_REQUESTS = 100  # Maximum requests per window
request_history = {}

class DocumentMetadata(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    tags: Optional[List[str]] = None
    project_id: Optional[str] = None
    task_id: Optional[str] = None

class BatchTaskRequest(BaseModel):
    project_id: str
    task_ids: List[str]

class PreflightRequest(BaseModel):
    project_id: str
    domain_id: Optional[int] = None
    operation: Optional[str] = "analyze"

def rate_limit(user_id: str):
    current_time = time.time()
    if user_id in request_history:
        # Clean old requests
        request_history[user_id] = [t for t in request_history[user_id] if current_time - t < RATE_LIMIT_WINDOW]
        if len(request_history[user_id]) >= MAX_REQUESTS:
            raise HTTPException(
                status_code=429,
                detail="Rate limit exceeded. Please try again later."
            )
    else:
        request_history[user_id] = []
    request_history[user_id].append(current_time)

def hash_endpoint(user_id: str, timestamp: str) -> str:
    """Generate a unique hash for the endpoint access"""
    data = f"{user_id}:{timestamp}"
    return hashlib.sha256(data.encode()).hexdigest()

async def verify_token(token: Optional[HTTPAuthorizationCredentials] = Depends(security)) -> Optional[dict]:
    """Verify JWT token with graceful error handling"""
    global JWT_WARNING_SHOWN
    
    try:
        if not token:
            return None
            
        jwt_secret = os.getenv("JWT_SECRET_KEY")
        if not jwt_secret:
            # Only show the warning once
            if not JWT_WARNING_SHOWN:
                print("Warning: JWT_SECRET_KEY not set")
                JWT_WARNING_SHOWN = True
            return None
            
        payload = jwt.decode(token.credentials, jwt_secret, algorithms=["HS256"])
        if not payload.get("email"):
            return None
            
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token has expired")
    except jwt.InvalidTokenError:
        return None
    except Exception as e:
        print(f"Token verification error: {str(e)}")
        return None

@router.post("/read")
async def upload_and_read_document(
    file: Optional[UploadFile] = File(None),
    metadata: Optional[DocumentMetadata] = None,
    current_user: Optional[dict] = Depends(verify_token)
):
    try:
        if not file:
            raise HTTPException(status_code=400, detail="No file provided")
            
        # Rate limiting only if we have a user
        if current_user:
            rate_limit(current_user.get("email", "anonymous"))
        
        # Generate access hash
        timestamp = datetime.utcnow().isoformat()
        access_hash = hash_endpoint(current_user.get("email", "anonymous"), timestamp)
        
        # Read the file content
        content = await file.read()
        
        # Process the document
        result = await document_reader.read_document(content, file.filename)
        
        # Add metadata and hash to response
        result.update({
            "access_hash": access_hash,
            "timestamp": timestamp,
            "metadata": metadata.dict() if metadata else {}
        })
        
        return JSONResponse(
            status_code=200,
            content=result
        )
    except Exception as e:
        print(f"Error in upload_and_read_document: {str(e)}")
        return JSONResponse(
            status_code=400,
            content={"error": str(e), "message": "Failed to process document"}
        )
    finally:
        if file:
            file.file.close()

@router.post("/upload/{project_id}/{task_id}")
async def upload_document(
    project_id: str,
    task_id: str,
    file: Optional[UploadFile] = File(None),
    notes: Optional[str] = Form(None),
    current_user: Optional[dict] = Depends(verify_token)
):
    """
    Upload a document and mark the task as completed in a single operation.
    This endpoint handles both file uploading and task completion status updates.
    """
    try:
        print(f"Uploading document for project: {project_id}, task: {task_id}")
        
        # Create output directory if it doesn't exist
        project_dir = DOCUMENTS_DIR / project_id / task_id
        project_dir.mkdir(parents=True, exist_ok=True)
        
        response_data = {
            "success": True,
            "message": "Document processed successfully",
            "file_saved": False,
            "task_completed": False
        }
        
        # Handle file upload if provided
        if file and file.filename:
            try:
                # Get file extension and create sanitized filename
                file_ext = Path(file.filename).suffix
                safe_filename = f"{task_id}{file_ext}"
                file_path = project_dir / safe_filename
                
                # Save the file
                with open(file_path, "wb") as f:
                    content = await file.read()
                    f.write(content)
                
                # Add file data to response
                response_data["file_saved"] = True
                response_data["file_path"] = str(file_path)
                response_data["filename"] = safe_filename
                print(f"File saved successfully at {file_path}")
            except Exception as file_error:
                print(f"Error saving file: {str(file_error)}")
                return JSONResponse(
                    status_code=500,
                    content={"error": str(file_error), "message": "Failed to save file"}
                )
        
        # Always mark the task as completed
        try:
            # Sanitize the task path
            safe_task_path = task_id.replace('/', '_').replace('\\', '_')
            task_file = COMPLETED_TASKS_DIR / f"{safe_task_path}.json"
            
            # Create directories if they don't exist
            COMPLETED_TASKS_DIR.mkdir(parents=True, exist_ok=True)
            
            # Prepare task data
            timestamp = datetime.now().isoformat()
            task_completion_data = {
                "project_id": project_id,
                "task_id": task_id,
                "completed": True,
                "notes": notes if notes else "",
                "completed_at": timestamp,
                "completed_by": current_user.get("email") if current_user else "unknown"
            }
            
            # If file was uploaded, include the file reference
            if file and file.filename and response_data.get("file_saved"):
                task_completion_data["attachments"] = [{
                    "name": file.filename,
                    "path": str(response_data.get("file_path")),
                    "type": file.content_type
                }]
            
            # Write task data to file
            with open(task_file, "w") as f:
                json.dump(task_completion_data, f, indent=2)
            
            response_data["task_completed"] = True
            response_data["task_file"] = str(task_file)
            print(f"Task completion data saved to {task_file}")
            
            # Also update the task in the Supabase database
            try:
                supabase_url = os.getenv("SUPABASE_URL")
                supabase_key = os.getenv("SUPABASE_KEY")
                
                if not supabase_url or not supabase_key:
                    print("WARNING: Supabase credentials not found. Skipping database update.")
                else:
                    # Initialize Supabase client
                    from supabase import create_client
                    supabase = create_client(supabase_url, supabase_key)
                    
                    # Check if task already exists for this project
                    response = supabase.table("tasks").select("id").eq("project_id", project_id).eq("task_id", task_id).execute()
                    existing_tasks = response.data
                    
                    # Prepare task data for Supabase
                    task_record = {
                        "project_id": project_id,
                        "task_id": task_id,
                        "completed": True,
                        "notes": notes if notes else "",
                        "updated_at": timestamp
                    }
                    
                    # If file was uploaded, include the file reference
                    if file and file.filename and response_data.get("file_saved"):
                        task_record["attachments"] = json.dumps([{
                            "name": file.filename,
                            "path": str(response_data.get("file_path")),
                            "type": file.content_type
                        }])
                    
                    if existing_tasks:
                        # Update existing task
                        task_db_id = existing_tasks[0]["id"]
                        supabase.table("tasks").update(task_record).eq("id", task_db_id).execute()
                        print(f"Updated existing task in Supabase: {task_db_id}")
                        response_data["supabase_task_id"] = task_db_id
                        response_data["supabase_updated"] = True
                    else:
                        # Insert new task
                        result = supabase.table("tasks").insert(task_record).execute()
                        print(f"Created new task in Supabase: {result.data}")
                        response_data["supabase_created"] = True
                        if result.data and len(result.data) > 0:
                            response_data["supabase_task_id"] = result.data[0].get("id")
                    
                    print("Successfully updated task in Supabase database")
                    response_data["supabase_updated"] = True
            except Exception as db_error:
                print(f"WARNING: Failed to update Supabase database: {str(db_error)}")
                response_data["supabase_error"] = str(db_error)
                # Continue execution to return the response with file and task data
        
        except Exception as task_error:
            print(f"Error saving task completion data: {str(task_error)}")
            response_data["task_error"] = str(task_error)
            # Only return error if no file was saved
            if not response_data.get("file_saved"):
                return JSONResponse(
                    status_code=500,
                    content={"error": str(task_error), "message": "Failed to save task completion data"}
                )
        
        return JSONResponse(
            status_code=200,
            content=response_data
        )
    except Exception as e:
        print(f"Error in upload_document: {str(e)}")
        return JSONResponse(
            status_code=500,
            content={"error": str(e), "message": "Failed to process document"}
        )

@router.get("/list")
async def list_documents(
    current_user: Optional[dict] = Depends(verify_token),
    project_id: Optional[str] = None
):
    try:
        # Rate limiting only if we have a user
        if current_user:
            rate_limit(current_user.get("email", "anonymous"))
        
        # Generate access hash
        timestamp = datetime.utcnow().isoformat()
        access_hash = hash_endpoint(current_user.get("email", "anonymous"), timestamp)
        
        files = []
        for file in DOCUMENTS_DIR.iterdir():
            if file.is_file() and not file.name.endswith('.meta.json'):
                # Try to load metadata if it exists
                metadata = {}
                metadata_path = file.with_suffix('.meta.json')
                if metadata_path.exists():
                    try:
                        with open(metadata_path, 'r') as f:
                            metadata = json.load(f)
                    except Exception as e:
                        print(f"Error reading metadata for {file.name}: {str(e)}")
                
                # Filter by project_id if specified
                if project_id and metadata.get('project_id') != project_id:
                    continue
                    
                files.append({
                    "name": file.name,
                    "size": file.stat().st_size,
                    "modified": datetime.fromtimestamp(file.stat().st_mtime).isoformat(),
                    "metadata": metadata
                })
                
        return JSONResponse(
            status_code=200,
            content={
                "files": files,
                "access_hash": access_hash,
                "timestamp": timestamp
            }
        )
    except Exception as e:
        print(f"Error in list_documents: {str(e)}")
        return JSONResponse(
            status_code=500,
            content={"error": str(e), "message": "Failed to list documents"}
        )

@router.get("/completed-tasks/{task_id}")
async def get_completed_task(
    task_id: str,
    current_user: Optional[dict] = Depends(verify_token)
):
    try:
        task_path = COMPLETED_TASKS_DIR / f"{task_id}.json"
        if not task_path.exists():
            return JSONResponse(
                status_code=404,
                content={"message": "Task not found"}
            )
            
        try:
            with open(task_path, 'r') as f:
                task_data = json.load(f)
        except Exception as e:
            print(f"Error reading task data: {str(e)}")
            return JSONResponse(
                status_code=500,
                content={"message": "Error reading task data"}
            )
            
        return JSONResponse(
            status_code=200,
            content=task_data
        )
    except Exception as e:
        print(f"Error in get_completed_task: {str(e)}")
        return JSONResponse(
            status_code=500,
            content={"error": str(e), "message": "Failed to get completed task"}
        )

@router.post("/completed-tasks/batch")
async def get_completed_tasks_batch(
    request: BatchTaskRequest,
    current_user: Optional[dict] = Depends(verify_token)
):
    """Get completion status for multiple tasks at once"""
    try:
        results = {}
        for task_id in request.task_ids:
            task_path = COMPLETED_TASKS_DIR / f"{task_id}.json"
            results[task_id] = {
                "exists": task_path.exists(),
                "completed": False
            }
            
            if task_path.exists():
                try:
                    with open(task_path, 'r') as f:
                        task_data = json.load(f)
                        results[task_id]["completed"] = True
                        results[task_id]["data"] = task_data
                except Exception as e:
                    print(f"Error reading task data for {task_id}: {str(e)}")
                    
        return JSONResponse(
            status_code=200,
            content={"tasks": results}
        )
    except Exception as e:
        print(f"Error in get_completed_tasks_batch: {str(e)}")
        return JSONResponse(
            status_code=500,
            content={"error": str(e), "message": "Failed to get completed tasks"}
        )

@router.get("/download/{filename}")
async def download_document(
    filename: str,
    current_user: Optional[dict] = Depends(verify_token)
):
    """
    Download a document by filename.
    Returns the file as a streaming response.
    """
    try:
        # Rate limiting only if we have a user
        if current_user:
            rate_limit(current_user.get("email", "anonymous"))
            
        # Check if file exists in project directory or root documents directory
        file_path = None
        for root, _, files in os.walk(DOCUMENTS_DIR):
            if filename in files:
                file_path = Path(root) / filename
                break
                
        if not file_path or not file_path.exists():
            return JSONResponse(
                status_code=404,
                content={"message": "File not found"}
            )
            
        # Return file as streaming response
        return FileResponse(
            path=file_path,
            filename=filename,
            media_type="application/octet-stream"
        )
    except Exception as e:
        print(f"Error in download_document: {str(e)}")
        return JSONResponse(
            status_code=500,
            content={"error": str(e), "message": "Failed to download document"}
        )

@router.post("/completed-tasks/{task_path}")
async def set_completed_task(
    task_path: str,
    task_data: dict,
    current_user: Optional[dict] = Depends(verify_token)
):
    """
    Explicitly set a task as completed and store its data.
    This ensures we have a single source of truth for task completion.
    
    Also updates the Supabase tasks table to reflect completion status.
    """
    try:
        # Sanitize the task path (remove any path traversal)
        safe_task_path = task_path.replace('/', '_').replace('\\', '_')
        task_file = COMPLETED_TASKS_DIR / f"{safe_task_path}.json"
        
        # Log the operation for debugging
        print(f"Setting task as completed: {safe_task_path}")
        print(f"Task data: {task_data}")
        
        # Extract required fields
        project_id = task_data.get("project_id")
        task_id = task_data.get("task_id")
        completed = task_data.get("completed", True)
        notes = task_data.get("notes", "")
        timestamp = task_data.get("timestamp")
        
        if not project_id or not task_id:
            return JSONResponse(
                status_code=400,
                content={"message": "Missing required fields: project_id and task_id"}
            )
            
        # Add metadata
        enriched_data = {
            **task_data,
            "completed_at": timestamp or datetime.now().isoformat(),
            "completed_by": current_user.get("email") if current_user else "unknown"
        }
        
        # Create directories if they don't exist
        COMPLETED_TASKS_DIR.mkdir(parents=True, exist_ok=True)
        
        # Write data to file
        with open(task_file, "w") as f:
            json.dump(enriched_data, f, indent=2)
            
        # Also update the task in the Supabase database
        try:
            supabase_url = os.getenv("SUPABASE_URL")
            supabase_key = os.getenv("SUPABASE_KEY")
            
            if not supabase_url or not supabase_key:
                # Log warning but don't fail if Supabase credentials are missing
                print("WARNING: Supabase credentials not found. Skipping database update.")
            else:
                # Initialize Supabase client
                from supabase import create_client
                supabase = create_client(supabase_url, supabase_key)
                
                # First check if task already exists for this project
                response = supabase.table("tasks").select("id").eq("project_id", project_id).eq("task_id", task_id).execute()
                existing_tasks = response.data
                
                # Prepare task data for Supabase
                task_record = {
                    "project_id": project_id,
                    "task_id": task_id,
                    "completed": completed,
                    "notes": notes,
                    "updated_at": datetime.now().isoformat(),
                    "custom_fields": task_data.get("custom_fields", {})
                }
                
                # If there are attachments, include them
                if "attachments" in task_data:
                    task_record["attachments"] = task_data["attachments"]
                
                if existing_tasks:
                    # Update existing task
                    task_db_id = existing_tasks[0]["id"]
                    supabase.table("tasks").update(task_record).eq("id", task_db_id).execute()
                    print(f"Updated existing task in Supabase: {task_db_id}")
                else:
                    # Insert new task
                    result = supabase.table("tasks").insert(task_record).execute()
                    print(f"Created new task in Supabase: {result.data}")
                
                print("Successfully updated task in Supabase database")
        except Exception as db_error:
            # Log database error but continue with file-based storage
            print(f"WARNING: Failed to update Supabase database: {str(db_error)}")
            # Continue execution to at least save to file
            
        return JSONResponse(
            status_code=200,
            content={
                "success": True, 
                "message": "Task completion status saved",
                "task_file": str(task_file.name)
            }
        )
    except Exception as e:
        print(f"Error in set_completed_task: {str(e)}")
        return JSONResponse(
            status_code=500,
            content={"error": str(e), "message": "Failed to save task completion status"}
        )

# Add a new preflight endpoint
@router.post("/preflight")
async def preflight_check(
    request: PreflightRequest,
    current_user: Optional[dict] = Depends(verify_token)
):
    """
    A simple endpoint to wake up the backend before starting an operation.
    This helps ensure the backend is responsive when the main operation is started.
    """
    try:
        # Log the preflight request
        user_id = current_user.get("email", "anonymous") if current_user else "anonymous"
        print(f"Preflight request received from {user_id}: Operation={request.operation}, Domain={request.domain_id}, Project={request.project_id}")
        
        # Return a simple response
        return JSONResponse(
            status_code=200,
            content={
                "status": "ready",
                "message": f"Backend is ready for {request.operation} operation",
                "timestamp": datetime.utcnow().isoformat()
            }
        )
    except Exception as e:
        print(f"Error in preflight check: {str(e)}")
        return JSONResponse(
            status_code=500,
            content={"error": str(e), "message": "Preflight check failed"}
        ) 