import os
import sys
import traceback
from datetime import datetime
from typing import Dict, Any

from fastapi import FastAPI, Request, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import RedirectResponse, JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from dotenv import load_dotenv

# Load .env variables
load_dotenv()
print("Environment variables loaded")

# Add current directory to sys.path
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.append(current_dir)
    print(f"Added {current_dir} to sys.path")

# Initialize app
app = FastAPI(
    title="PMO-MVP API",
    description="API for PMO-MVP project",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
    swagger_ui_parameters={
        "defaultModelsExpandDepth": -1,
        "deepLinking": True,
        "displayRequestDuration": True,
        "syntaxHighlight.theme": "obsidian"
    }
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global exception handler
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    print("Unhandled exception:", exc)
    traceback.print_exc()
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error"}
    )

# Try importing and registering routers
routers = {}
try:
    from routers.pmo_router import router as pmo_router
    routers['pmo'] = ('pmo', pmo_router)
except ImportError as e:
    print(f"Router load error (pmo): {e}")

try:
    from routers.document_upload_router import router as document_upload_router
    routers['document_upload'] = ('document-upload', document_upload_router)
except ImportError as e:
    print(f"Router load error (document_upload): {e}")

try:
    from routers.subscription_router import router as subscription_router
    routers['subscription'] = ('subscription', subscription_router)
except ImportError as e:
    print(f"Router load error (subscription): {e}")

try:
    from routers.projects import router as projects_router
    routers['projects'] = ('projects', projects_router)
except ImportError as e:
    print(f"Router load error (projects): {e}")

try:
    from routers.user_profile_router import router as user_profile_router
    routers['user_profile'] = ('user-profile', user_profile_router)
except ImportError as e:
    print(f"Router load error (user_profile): {e}")

try:
    from routers.auth import router as auth_router
    routers['auth'] = ('auth', auth_router)
except ImportError as e:
    print(f"Router load error (auth): {e}")

try:
    from routers.documents import router as documents_router
    routers['documents'] = ('documents', documents_router)
except ImportError as e:
    print(f"Router load error (documents): {e}")

try:
    from routers.payment_router import router as payment_router
    routers['payment'] = ('payment', payment_router)
    app.include_router(payment_router)
except ImportError as e:
    print(f"Router load error (payment): {e}")

try:
    from routers.document_reader_router import router as document_reader_router
    routers['document_reader'] = ('document-reader', document_reader_router)
except ImportError as e:
    print(f"Router load error (document_reader): {e}")

# Register routers
for router_name, (prefix, router) in routers.items():
    try:
        app.include_router(router, prefix=f"/{prefix}", tags=[router_name])
        print(f"Router registered: {router_name}")
    except Exception as e:
        print(f"Error registering router {router_name}: {e}")

# Healthcheck
@app.get("/healthcheck")
async def healthcheck() -> Dict[str, Any]:
    return {
        "status": "healthy",
        "environment": os.getenv("ENVIRONMENT", "development"),
        "available_routers": list(routers.keys())
    }

# Root route
@app.get("/")
async def root():
    return {
        "message": "Welcome to PMO-MVP API",
        "documentation": "/docs",
        "healthcheck": "/healthcheck",
        "available_endpoints": [f"/{prefix}" for name, (prefix, _) in routers.items()]
    }

# === Local development support ===
if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", "10000"))
    host = os.getenv("HOST", "0.0.0.0")
    
    # Optimize for concurrency in local development
    uvicorn.run(
        "main:app", 
        host=host, 
        port=port,
        workers=4,
        loop="asyncio"
    )
