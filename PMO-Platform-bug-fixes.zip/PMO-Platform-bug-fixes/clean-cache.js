const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// Define paths to clear
const cachePaths = [
  path.join(__dirname, 'node_modules', '.vite'),
  path.join(__dirname, 'node_modules', '.cache')
];

// Function to delete directory recursively
function deleteDirectory(dirPath) {
  try {
    if (fs.existsSync(dirPath)) {
      console.log(`Removing: ${dirPath}`);
      fs.rmSync(dirPath, { recursive: true, force: true });
      console.log(`Successfully removed: ${dirPath}`);
    } else {
      console.log(`Directory does not exist: ${dirPath}`);
    }
  } catch (err) {
    console.error(`Error removing directory ${dirPath}:`, err);
  }
}

// Clear all cache directories
console.log('Cleaning Vite cache...');
cachePaths.forEach(deleteDirectory);
console.log('Cache cleared!');

// Start the development server
console.log('Starting development server...');
try {
  // Using execSync to run the command synchronously
  execSync('npm run dev', { stdio: 'inherit' });
} catch (error) {
  console.error('Error starting development server:', error);
} 