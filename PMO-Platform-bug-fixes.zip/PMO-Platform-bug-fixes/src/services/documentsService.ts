import axios from 'axios';

const API_URL = import.meta.env.VITE_API_BASE_URL || 'https://pmo-mvp-fe.onrender.com';

export interface DocumentMetadata {
  project_id?: string;
  task_name?: string;
  notes?: string;
  upload_time?: string;
  uploader?: string;
}

export interface Document {
  name: string;
  size: number;
  modified: string;
  metadata: DocumentMetadata;
}

export const documentsService = {
  async listDocuments(projectId?: string): Promise<Document[]> {
    try {
      const response = await axios.get(`${API_URL}/documents/list`, {
        params: { project_id: projectId },
        headers: {
          Authorization: `Bearer ${localStorage.getItem('token')}`
        }
      });
      return response.data.files;
    } catch (error) {
      console.error('Error fetching documents:', error);
      throw error;
    }
  },

  async downloadDocument(filename: string): Promise<Blob> {
    try {
      const response = await axios.get(`${API_URL}/documents/download/${filename}`, {
        responseType: 'blob',
        headers: {
          Authorization: `Bearer ${localStorage.getItem('token')}`
        }
      });
      return response.data;
    } catch (error) {
      console.error('Error downloading document:', error);
      throw error;
    }
  }
}; 