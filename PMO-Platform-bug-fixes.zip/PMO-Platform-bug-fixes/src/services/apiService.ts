import axios from 'axios';
import { supabase } from './supabaseClient';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'https://pmo-mvp-fe.onrender.com';

const apiService = {
    async get(endpoint: string) {
        const { data: { session } } = await supabase.auth.getSession();
        return axios.get(`${API_BASE_URL}${endpoint}`, {
            headers: {
                Authorization: `Bearer ${session?.access_token}`
            }
        });
    },

    async post(endpoint: string, data: any) {
        const { data: { session } } = await supabase.auth.getSession();
        return axios.post(`${API_BASE_URL}${endpoint}`, data, {
            headers: {
                Authorization: `Bearer ${session?.access_token}`
            }
        });
    },

    async put(endpoint: string, data: any) {
        const { data: { session } } = await supabase.auth.getSession();
        return axios.put(`${API_BASE_URL}${endpoint}`, data, {
            headers: {
                Authorization: `Bearer ${session?.access_token}`
            }
        });
    },

    async delete(endpoint: string) {
        const { data: { session } } = await supabase.auth.getSession();
        return axios.delete(`${API_BASE_URL}${endpoint}`, {
            headers: {
                Authorization: `Bearer ${session?.access_token}`
            }
        });
    }
};

export default apiService; 