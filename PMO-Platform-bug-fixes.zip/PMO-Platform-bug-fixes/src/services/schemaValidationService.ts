import { z } from 'zod';
import { v4 as uuidv4 } from 'uuid';

/**
 * Schema validation service using Zod
 * Provides validation schemas and helpers for data integrity
 */

// Base schemas for common fields
const idSchema = z.string().uuid();
const dateSchema = z.string().datetime();
const contentSchema = z.string();
const objectSchema = z.record(z.any());

// Project schema
export const projectSchema = z.object({
  id: idSchema.optional().default(() => uuidv4()),
  name: z.string().min(1, "Project name is required"),
  description: z.string().optional(),
  owner_id: z.string().uuid(),
  created_at: dateSchema.optional().default(() => new Date().toISOString()),
  updated_at: dateSchema.optional().default(() => new Date().toISOString()),
  start_date: dateSchema.optional(),
  end_date: dateSchema.optional(),
  budget: z.number().optional().default(0),
  budget_spent: z.number().optional().default(0),
  key_objectives: z.array(z.string()).optional().default([]),
  stakeholders: z.array(
    z.object({
      name: z.string(),
      role: z.string()
    })
  ).optional().default([]),
  risks: z.array(
    z.object({
      description: z.string(),
      severity: z.string(),
      mitigation: z.string()
    })
  ).optional().default([]),
  is_active: z.boolean().optional().default(true)
});

// Domain input schema
export const domainInputSchema = z.object({
  project_id: idSchema,
  domain_id: z.number().int().positive(),
  content: contentSchema.optional(),
  last_updated: dateSchema.optional().default(() => new Date().toISOString()),
  created_by: idSchema.optional()
});

// Domain output schema
export const domainOutputSchema = z.object({
  project_id: idSchema,
  domain_id: z.number().int().positive(),
  content: contentSchema.optional(),
  generated_date: dateSchema.optional().default(() => new Date().toISOString()),
  created_by: idSchema.optional()
});

// Task schema
export const taskSchema = z.object({
  project_id: idSchema,
  task_id: z.string(),
  completed: z.boolean().optional().default(false),
  notes: contentSchema.optional(),
  attachments: z.array(z.string()).optional().default([]),
  custom_fields: objectSchema.optional().default({}),
  document_references: z.array(z.string()).optional().default([]),
  dependencies: z.array(z.string()).optional().default([]),
  updated_at: dateSchema.optional().default(() => new Date().toISOString()),
  updated_by: idSchema.optional()
});

// Document chunk schema
export const documentChunkSchema = z.object({
  document_id: idSchema,
  content: contentSchema,
  chunk_index: z.number().int(),
  char_start: z.number().int(),
  char_end: z.number().int(),
  token_count: z.number().int().optional(),
  page_number: z.number().int().optional(),
  source: z.string().optional()
});

// Processed document schema
export const documentSchema = z.object({
  id: idSchema.optional().default(() => uuidv4()),
  file_name: z.string(),
  file_type: z.string(),
  total_chunks: z.number().int(),
  created_by: idSchema.optional(),
  project_id: idSchema,
  domain_id: z.number().int().optional(),
  created_at: dateSchema.optional().default(() => new Date().toISOString()),
  updated_at: dateSchema.optional().default(() => new Date().toISOString()),
  metadata: objectSchema.optional().default({})
});

// Validation helper functions
/**
 * Validate data against a schema and return the result
 * @param schema Zod schema
 * @param data Data to validate
 * @returns Validation result with success flag and either validated data or error
 */
export const validateData = <T extends z.ZodType>(schema: T, data: unknown): { 
  success: boolean; 
  data?: z.infer<T>;
  error?: string;
} => {
  try {
    const validatedData = schema.parse(data);
    return {
      success: true,
      data: validatedData
    };
  } catch (error) {
    if (error instanceof z.ZodError) {
      return {
        success: false,
        error: formatZodError(error)
      };
    }
    return {
      success: false,
      error: 'Unknown validation error'
    };
  }
};

/**
 * Format Zod error for user-friendly display
 */
export const formatZodError = (error: z.ZodError): string => {
  return error.errors.map(err => {
    const path = err.path.join('.');
    return `${path ? `${path}: ` : ''}${err.message}`;
  }).join(', ');
};

/**
 * Validate multiple data items against a schema
 * @param schema Zod schema
 * @param dataArray Array of data to validate
 * @returns Array of validation results
 */
export const validateBatch = <T extends z.ZodType>(schema: T, dataArray: unknown[]): {
  valid: z.infer<T>[];
  invalid: { data: unknown; error: string }[];
} => {
  const valid: z.infer<T>[] = [];
  const invalid: { data: unknown; error: string }[] = [];

  for (const data of dataArray) {
    const result = validateData(schema, data);
    if (result.success && result.data) {
      valid.push(result.data);
    } else {
      invalid.push({ data, error: result.error || 'Unknown error' });
    }
  }

  return { valid, invalid };
};