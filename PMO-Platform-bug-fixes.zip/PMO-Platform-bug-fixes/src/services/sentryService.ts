import * as Sentry from '@sentry/react';

// Configuration options for Sentry
interface SentryConfig {
  dsn: string;
  environment: string;
  release?: string;
  debug?: boolean;
  tracesSampleRate: number;
  ignoreErrors?: Array<string | RegExp>;
  beforeSend?: (event: Sentry.Event, hint: Sentry.EventHint) => Sentry.Event | null;
}

// Helper function to safely access environment variables
const getEnvVar = (key: string, defaultValue: string = ''): string => {
  // For Vite, use import.meta.env
  if (typeof import.meta !== 'undefined' && import.meta.env) {
    return (import.meta.env[key] as string) || defaultValue;
  }
  // Fallback
  return defaultValue;
};

// Default configuration
const defaultConfig: SentryConfig = {
  dsn: getEnvVar('VITE_SENTRY_DSN', ''),
  environment: getEnvVar('MODE', 'development'),
  release: getEnvVar('VITE_APP_VERSION', '1.0.0'),
  debug: getEnvVar('MODE') !== 'production',
  tracesSampleRate: 0.5,
  ignoreErrors: [
    // Ignore very common errors that we handle specially
    /Cannot read properties of null/,
    /ResizeObserver loop limit exceeded/,
    /Network request failed/,
    /Failed to fetch/,
    /Load failed/,
    /AbortError/,
    // Ignore errors from third-party extensions or browser plugins
    /^chrome-extension:\/\//,
    /^moz-extension:\/\//,
    /^safari-extension:\/\//,
  ],
  beforeSend: (event, hint) => {
    // Special handling for nodeName errors
    const error = hint.originalException;
    if (error instanceof Error && error.message.includes("Cannot read properties of null (reading 'nodeName')")) {
      // Add special tags to help with debugging
      event.tags = {
        ...event.tags,
        nodeNameError: true,
        handled: true,
        priority: 'high'
      };
      
      // Add extra context that might help debug the issue
      event.extra = {
        ...event.extra,
        url: window.location.href,
        userAgent: navigator.userAgent,
        windowDimensions: `${window.innerWidth}x${window.innerHeight}`,
        timestamp: new Date().toISOString(),
        errorType: 'DOM Reference Error'
      };
      
      console.warn('Caught nodeName error - reporting to Sentry with enhanced context');
    }
    
    return event;
  }
};

/**
 * Initialize Sentry with the provided configuration
 * @param config Optional configuration to override defaults
 */
export const initSentry = (config?: Partial<SentryConfig>): void => {
  const finalConfig = { ...defaultConfig, ...config };
  
  // Only initialize if DSN is provided
  if (!finalConfig.dsn) {
    console.warn('Sentry DSN not provided, error tracking disabled');
    return;
  }
  
  try {
    Sentry.init({
      dsn: finalConfig.dsn,
      environment: finalConfig.environment,
      release: finalConfig.release,
      debug: finalConfig.debug,
      integrations: [
        // Use a simpler integration approach to avoid type errors
        { name: 'BrowserTracing', setupOnce: () => {} }
      ],
      tracesSampleRate: finalConfig.tracesSampleRate,
      ignoreErrors: finalConfig.ignoreErrors,
      // Cast the beforeSend function to match expected types
      beforeSend: finalConfig.beforeSend as any,
      
      // Additional configuration for better error grouping
      normalizeDepth: 10,
      maxBreadcrumbs: 50,
      
      // Add global error handlers - REMOVED onUnhandledRejection
      
      // Add context to all errors
      initialScope: {
        tags: {
          app: 'pmo-mvp'
        }
      }
    });
    
    console.log('Sentry initialized successfully');
  } catch (error) {
    console.error('Failed to initialize Sentry:', error);
  }
};

/**
 * Capture an exception and send it to Sentry
 * @param error The error to capture
 * @param context Additional context to include with the error
 */
export const captureException = (error: unknown, context?: Record<string, any>): void => {
  // Don't send to Sentry if not initialized
  try {
    // Check if Sentry is initialized without using getCurrentHub
    if (!Sentry || typeof Sentry.captureException !== 'function') {
      console.error('Error captured but Sentry not initialized:', error);
      return;
    }
    
    // Special handling for nodeName errors
    if (error instanceof Error && error.message.includes("Cannot read properties of null (reading 'nodeName')")) {
      console.warn('Capturing nodeName error with enhanced context');
      
      // Add extra DOM-related context that might help debug the issue
      const enhancedContext = {
        ...context,
        documentReady: document.readyState,
        url: window.location.href,
        userAgent: navigator.userAgent,
        windowDimensions: `${window.innerWidth}x${window.innerHeight}`,
        timestamp: new Date().toISOString(),
        errorType: 'DOM Reference Error',
        // Add information about DOM elements that might be relevant
        bodyChildCount: document.body?.childElementCount,
        rootElementExists: !!document.getElementById('root'),
      };
      
      Sentry.withScope((scope) => {
        // Use string literal instead of Sentry.Severity enum
        scope.setLevel('warning');
        scope.setTags({
          nodeNameError: 'true',
          handled: 'true',
          priority: 'high'
        });
        
        // Add all enhanced context
        if (enhancedContext) {
          Object.entries(enhancedContext).forEach(([key, value]) => {
            scope.setExtra(key, value);
          });
        }
        
        Sentry.captureException(error);
      });
      
      return;
    }
    
    // Standard error handling for other errors
    Sentry.withScope((scope) => {
      // Add all context
      if (context) {
        Object.entries(context).forEach(([key, value]) => {
          scope.setExtra(key, value);
        });
      }
      
      Sentry.captureException(error);
    });
  } catch (sentryError) {
    console.error('Failed to capture exception in Sentry:', sentryError);
    console.error('Original error:', error);
  }
};

/**
 * Set user information in Sentry
 * @param user User information
 */
export const setUser = (user: Sentry.User): void => {
  try {
    Sentry.setUser(user);
  } catch (error) {
    console.error('Failed to set user in Sentry:', error);
  }
};

/**
 * Add breadcrumb to Sentry
 * @param breadcrumb Breadcrumb information
 */
export const addBreadcrumb = (breadcrumb: Sentry.Breadcrumb): void => {
  try {
    Sentry.addBreadcrumb(breadcrumb);
  } catch (error) {
    console.error('Failed to add breadcrumb to Sentry:', error);
  }
};

/**
 * Set tag in Sentry
 * @param key Tag key
 * @param value Tag value
 */
export const setTag = (key: string, value: string): void => {
  try {
    Sentry.setTag(key, value);
  } catch (error) {
    console.error('Failed to set tag in Sentry:', error);
  }
};

/**
 * Create a global error handler to catch all unhandled errors
 * Especially useful for catching the nodeName errors
 */
export const setupGlobalErrorHandlers = (): void => {
  // Keep a reference to the original error handler
  const originalOnError = window.onerror;
  
  // Override the global error handler
  window.onerror = (message, source, lineno, colno, error) => {
    // Special handling for nodeName errors
    if (message && typeof message === 'string' && message.includes("Cannot read properties of null (reading 'nodeName')")) {
      console.warn('Global handler caught nodeName error');
      
      // Capture with enhanced context
      captureException(error || new Error(String(message)), {
        source,
        lineno,
        colno,
        caughtBy: 'globalErrorHandler',
        url: window.location.href
      });
      
      // Prevent the error from bubbling up and crashing the app
      return true;
    }
    
    // Call the original handler if it exists
    if (originalOnError) {
      return originalOnError(message, source, lineno, colno, error);
    }
    
    // Default behavior
    return false;
  };
  
  // Handle unhandled promise rejections
  window.addEventListener('unhandledrejection', (event) => {
    const error = event.reason;
    
    // Special handling for nodeName errors in promises
    if (error && error.message && error.message.includes("Cannot read properties of null (reading 'nodeName')")) {
      console.warn('Global handler caught nodeName error in promise');
      
      // Capture with enhanced context
      captureException(error, {
        caughtBy: 'unhandledRejection',
        url: window.location.href
      });
      
      // Prevent the error from bubbling up
      event.preventDefault();
    }
    
    // Added from the removed onUnhandledRejection handler
    console.error('Unhandled promise rejection:', error);
    
    // Special handling for nodeName errors in promises
    if (error instanceof Error && error.message.includes("Cannot read properties of null (reading 'nodeName')")) {
      console.warn('Caught nodeName error in promise - this is likely due to a React rendering issue');
    }
  });
  
  console.log('Global error handlers set up successfully');
};

/**
 * Create a custom error boundary component
 */
export const SentryErrorBoundary = Sentry.ErrorBoundary;

export default {
  initSentry,
  captureException,
  setUser,
  addBreadcrumb,
  setTag,
  setupGlobalErrorHandlers,
  SentryErrorBoundary
}; 