import { supabase } from './supabaseClient';
import { validateData } from './schemaValidationService';
import { z } from 'zod';
import { subscriptionApi } from '../api/subscriptionApi';

// Subscription tiers
export enum SubscriptionTier {
  FREE = 'free',
  PREMIUM = 'premium',
  ENTERPRISE = 'enterprise'
}

// Feature limits by tier
export const TIER_LIMITS = {
  [SubscriptionTier.FREE]: {
    projects: 3,
    templates: 5,
    aiAnalysis: 3,
    users: 1,
    storage: 250, // MB
    customDomains: false,
    prioritySupport: false,
    whiteLabeling: false
  },
  [SubscriptionTier.PREMIUM]: {
    projects: 20,
    templates: 50,
    aiAnalysis: 100,
    users: 5,
    storage: 5000, // MB
    customDomains: true,
    prioritySupport: true,
    whiteLabeling: false
  },
  [SubscriptionTier.ENTERPRISE]: {
    projects: 100,
    templates: 'unlimited',
    aiAnalysis: 'unlimited',
    users: 'unlimited',
    storage: 50000, // MB
    customDomains: true,
    prioritySupport: true,
    whiteLabeling: true
  }
};

// Pricing information
export const PRICING = {
  [SubscriptionTier.FREE]: {
    monthly: 0,
    annual: 0,
    currency: 'USD',
    savings: 0
  },
  [SubscriptionTier.PREMIUM]: {
    monthly: 40.00,
    annual: 239.76, // Annual price is calculated as discounted monthly ($19.90) × 12
    currency: 'USD',
    savings: 240.24 // $40.00 * 12 - $239.76
  },
  [SubscriptionTier.ENTERPRISE]: {
    monthly: 99.90,
    annual: 598.80, // Annual price is calculated as discounted monthly ($49.90) × 12
    currency: 'USD',
    savings: 600.00 // $99.90 * 12 - $598.80
  }
};

// Features available in each tier
export const TIER_FEATURES = {
  [SubscriptionTier.FREE]: [
    'Basic PMO templates',
    'Project management tools',
    'Task tracking',
    'Limited AI analysis',
    'Email support'
  ],
  [SubscriptionTier.PREMIUM]: [
    'All Free features',
    'Advanced PMO templates',
    'Advanced AI analysis',
    'Team collaboration',
    'Document processing',
    'Priority support',
    'API access',
    'Custom domains'
  ],
  [SubscriptionTier.ENTERPRISE]: [
    'All Premium features',
    'Unlimited projects',
    'Unlimited users',
    'Advanced analytics',
    'White-labeling',
    'Dedicated support',
    'SSO integration',
    'Custom integrations'
  ]
};

// Subscription schema using Zod for validation
export const subscriptionSchema = z.object({
  id: z.string().uuid().optional(),
  user_id: z.string().uuid(),
  tier: z.enum([SubscriptionTier.FREE, SubscriptionTier.PREMIUM, SubscriptionTier.ENTERPRISE]),
  status: z.enum(['active', 'inactive', 'past_due', 'canceled', 'trial']),
  payment_provider: z.enum(['stripe', 'paypal', 'manual', 'none']).optional(),
  payment_id: z.string().optional(),
  current_period_start: z.string().datetime().optional(),
  current_period_end: z.string().datetime().optional(),
  cancel_at_period_end: z.boolean().default(false),
  trial_start: z.string().datetime().optional(),
  trial_end: z.string().datetime().optional(),
  created_at: z.string().datetime().default(() => new Date().toISOString()),
  updated_at: z.string().datetime().default(() => new Date().toISOString())
});

// Usage schema for tracking feature usage
export const usageSchema = z.object({
  id: z.string().uuid().optional(),
  user_id: z.string().uuid(),
  feature: z.string(),
  count: z.number().int().default(0),
  limit: z.number().int().or(z.literal('unlimited')).optional(),
  period_start: z.string().datetime(),
  period_end: z.string().datetime(),
  created_at: z.string().datetime().default(() => new Date().toISOString()),
  updated_at: z.string().datetime().default(() => new Date().toISOString())
});

export type Subscription = z.infer<typeof subscriptionSchema>;
export type Usage = z.infer<typeof usageSchema>;

class SubscriptionService {
  // Initialize subscription for a new user
  async initializeUserSubscription(userId: string): Promise<Subscription | null> {
    return subscriptionApi.initializeUserSubscription(userId);
  }
  
  // Get user's subscription
  async getUserSubscription(userId: string): Promise<Subscription | null> {
    return subscriptionApi.getUserSubscription(userId);
  }
  
  // Update user's subscription tier
  async updateSubscriptionTier(
    userId: string, 
    tier: SubscriptionTier,
    paymentProvider?: string,
    paymentId?: string
  ): Promise<Subscription | null> {
    return subscriptionApi.updateSubscriptionTier(userId, tier, paymentProvider, paymentId);
  }
  
  // Cancel subscription (set to cancel at period end)
  async cancelSubscription(userId: string): Promise<boolean> {
    try {
      // This functionality is not yet implemented in the API
      // Will need to be added to the backend
        return false;
    } catch (error) {
      console.error('Error in cancelSubscription:', error);
      return false;
    }
  }
  
  // Check if a feature is available for a user's subscription
  async isFeatureAvailable(userId: string, feature: string): Promise<boolean> {
    try {
      // Get user's subscription
      const subscription = await this.getUserSubscription(userId);
      
      if (!subscription) {
        // Default to free tier if no subscription found
        return this.isFeatureAvailableForTier(SubscriptionTier.FREE, feature);
      }
      
      // Check if subscription is active
      if (subscription.status !== 'active' && subscription.status !== 'trial') {
        return false;
      }
      
      return this.isFeatureAvailableForTier(subscription.tier, feature);
    } catch (error) {
      console.error('Error checking feature availability:', error);
      return false;
    }
  }
  
  // Check if a feature is available for a specific tier
  isFeatureAvailableForTier(tier: SubscriptionTier, feature: string): boolean {
    switch (feature) {
      case 'aiAnalysis':
      case 'projects':
      case 'templates':
      case 'users':
      case 'storage':
        // These features have limits rather than being simply available or not
        return true;
      case 'customDomains':
        return tier === SubscriptionTier.PREMIUM || tier === SubscriptionTier.ENTERPRISE;
      case 'prioritySupport':
        return tier === SubscriptionTier.PREMIUM || tier === SubscriptionTier.ENTERPRISE;
      case 'whiteLabeling':
        return tier === SubscriptionTier.ENTERPRISE;
      case 'apiAccess':
        return tier === SubscriptionTier.PREMIUM || tier === SubscriptionTier.ENTERPRISE;
      case 'teamCollaboration':
        return tier === SubscriptionTier.PREMIUM || tier === SubscriptionTier.ENTERPRISE;
      case 'advancedAnalytics':
        return tier === SubscriptionTier.ENTERPRISE;
      case 'sso':
        return tier === SubscriptionTier.ENTERPRISE;
      default:
        return true; // Default to available if unknown feature
    }
  }
  
  // Check if a user has remaining usage for a specific feature
  async hasRemainingUsage(userId: string, feature: string): Promise<boolean> {
    try {
      // First get the user's subscription to determine their tier
      const subscription = await this.getUserSubscription(userId);
      
      if (!subscription) {
        // Default to free tier if no subscription found
        return await this.checkUsageLimit(userId, SubscriptionTier.FREE, feature);
      }
      
      // Check if subscription is active
      if (subscription.status !== 'active' && subscription.status !== 'trial') {
        return false;
      }
      
      return this.checkUsageLimit(userId, subscription.tier, feature);
    } catch (error) {
      console.error('Error checking remaining usage:', error);
      return false;
    }
  }
  
  // Check if a user has reached their usage limit for a specific feature
  private async checkUsageLimit(userId: string, tier: SubscriptionTier, feature: string): Promise<boolean> {
    // Get the limit for this feature in this tier
    const limit = TIER_LIMITS[tier][feature as keyof typeof TIER_LIMITS[typeof tier]];
    
    // If unlimited, return true
    if (limit === 'unlimited') {
      return true;
    }
    
    // Get current usage from API
    const currentUsage = await subscriptionApi.getFeatureUsage(userId, feature);
    
    // Compare current usage to limit (ensure both are numbers)
    return typeof limit === 'number' && currentUsage < limit;
  }
  
  // Increment usage count for a feature
  async incrementUsage(userId: string, feature: string): Promise<boolean> {
    return subscriptionApi.incrementUsage(userId, feature);
  }
  
  // Get current usage for a specific feature
  async getFeatureUsage(userId: string, feature: string): Promise<number> {
    return subscriptionApi.getFeatureUsage(userId, feature);
  }
  
  // Get feature limit for the user's current subscription tier
  async getFeatureLimit(userId: string, feature: string): Promise<number | string> {
    try {
      // Get user's subscription
      const subscription = await this.getUserSubscription(userId);
      
      if (!subscription) {
        // Default to free tier if no subscription found
        return TIER_LIMITS[SubscriptionTier.FREE][feature as keyof typeof TIER_LIMITS[SubscriptionTier.FREE]];
      }
      
      return TIER_LIMITS[subscription.tier][feature as keyof typeof TIER_LIMITS[typeof subscription.tier]];
    } catch (error) {
      console.error('Error getting feature limit:', error);
      return TIER_LIMITS[SubscriptionTier.FREE][feature as keyof typeof TIER_LIMITS[SubscriptionTier.FREE]];
    }
  }
  
  // Check if the user needs to upgrade their plan (reached limits)
  async shouldUpgrade(userId: string): Promise<{shouldUpgrade: boolean, reason?: string, feature?: string}> {
    try {
      // Get user's subscription
      const subscription = await this.getUserSubscription(userId);
      
      if (!subscription || subscription.tier === SubscriptionTier.FREE) {
        // Check if they've reached any limits on the free tier
        const projectsUsage = await this.getFeatureUsage(userId, 'projects');
        const projectsLimit = await this.getFeatureLimit(userId, 'projects');
        
        if (typeof projectsLimit === 'number' && projectsUsage >= projectsLimit) {
          return {
            shouldUpgrade: true,
            reason: `You've reached the limit of ${projectsLimit} projects on the free tier`,
            feature: 'projects'
          };
        }
        
        const aiAnalysisUsage = await this.getFeatureUsage(userId, 'aiAnalysis');
        const aiAnalysisLimit = await this.getFeatureLimit(userId, 'aiAnalysis');
        
        if (typeof aiAnalysisLimit === 'number' && aiAnalysisUsage >= aiAnalysisLimit) {
          return {
            shouldUpgrade: true,
            reason: `You've reached the limit of ${aiAnalysisLimit} AI analyses on the free tier`,
            feature: 'aiAnalysis'
          };
        }
      }
      
      // No upgrade needed
      return { shouldUpgrade: false };
    } catch (error) {
      console.error('Error checking if user should upgrade:', error);
      return { shouldUpgrade: false };
    }
  }
  
  // Generate a link to the pricing page with UTM parameters
  generatePricingLink(source: string, feature?: string): string {
    let url = '/pricing?utm_source=app&utm_medium=upgrade_prompt';
    
    if (source) {
      url += `&utm_campaign=${encodeURIComponent(source)}`;
    }
    
    if (feature) {
      url += `&feature=${encodeURIComponent(feature)}`;
    }
    
    return url;
  }
}

export const subscriptionService = new SubscriptionService();