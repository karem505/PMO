/**
 * Database Index Optimizer Service
 * 
 * This service helps diagnose and optimize database indexes
 * by analyzing query patterns and suggesting index improvements
 */
import { queryMonitorService } from './queryMonitorService';

class DbIndexOptimizerService {
  // Common query patterns that benefit from indexes
  private indexablePatterns: {[key: string]: string} = {
    'project_id': 'Consider adding an index on the project_id column for better query performance',
    'domain_id': 'Consider adding an index on the domain_id column for better query performance',
    'user_id': 'Consider adding an index on the user_id column for better query performance',
    'task_id': 'Consider adding an index on the task_id column for better query performance',
    'LIKE': 'Text search operations would benefit from a text search index using GIN',
    'ORDER BY': 'Sorting operations would benefit from an index on the sorted column',
    'content': 'Consider using a GIN index for full-text search on content columns'
  };
  
  // Optimization thresholds
  private readonly SLOW_QUERY_THRESHOLD = 500; // ms
  private readonly FREQUENT_QUERY_THRESHOLD = 10; // count
  
  /**
   * Generate index recommendations based on query patterns
   */
  getIndexRecommendations(): string[] {
    // Get query statistics
    const stats = queryMonitorService.getQueryStats();
    
    const recommendations: string[] = [];
    const recommendationSet = new Set<string>(); // To avoid duplicates
    
    // Analyze query patterns for index recommendations
    for (const stat of stats) {
      // Skip fast queries
      if (stat.avgTime < this.SLOW_QUERY_THRESHOLD || stat.count < this.FREQUENT_QUERY_THRESHOLD) {
        continue;
      }
      
      // Look for indexable patterns in the query name
      for (const [pattern, recommendation] of Object.entries(this.indexablePatterns)) {
        if (stat.queryName.includes(pattern) && !recommendationSet.has(recommendation)) {
          recommendations.push(`${recommendation} (found in slow query: ${stat.queryName})`);
          recommendationSet.add(recommendation);
        }
      }
    }
    
    // Add general recommendations if we have slow queries
    if (stats.some(s => s.avgTime > this.SLOW_QUERY_THRESHOLD)) {
      recommendations.push(
        'Run EXPLAIN ANALYZE on slow queries to identify missing indexes',
        'Consider adding composite indexes for queries with multiple conditions',
        'Use GIN indexes for JSON/JSONB columns that are frequently queried with containment operators',
        'Ensure appropriate indexes exist on foreign key columns'
      );
    }
    
    return recommendations;
  }
  
  /**
   * Generate SQL statements for creating recommended indexes
   */
  generateIndexCreationStatements(): string[] {
    const sqlStatements: string[] = [];
    
    // Get query statistics
    const stats = queryMonitorService.getQueryStats();
    
    // Tables and columns that appear in slow queries
    const slowQueryTables = new Map<string, Set<string>>();
    
    // Extract table and column info from query names
    for (const stat of stats) {
      if (stat.avgTime < this.SLOW_QUERY_THRESHOLD) continue;
      
      // Try to parse the query name for table and column info
      const queryParts = stat.queryName.split('_');
      if (queryParts.length >= 2) {
        const tableName = queryParts[0];
        const columns = queryParts.slice(1).filter(col => 
          !['select', 'insert', 'update', 'delete', 'by', 'and', 'or', 'where'].includes(col)
        );
        
        if (!slowQueryTables.has(tableName)) {
          slowQueryTables.set(tableName, new Set<string>());
        }
        
        columns.forEach(col => slowQueryTables.get(tableName)!.add(col));
      }
    }
    
    // Generate index statements
    for (const [table, columns] of slowQueryTables.entries()) {
      for (const column of columns) {
        sqlStatements.push(
          `CREATE INDEX IF NOT EXISTS ${table}_${column}_idx ON ${table}(${column});`
        );
      }
      
      // If we have multiple columns from the same table, suggest a composite index
      if (columns.size > 1) {
        const columnArray = Array.from(columns);
        sqlStatements.push(
          `-- Consider a composite index if these columns are frequently queried together:
CREATE INDEX IF NOT EXISTS ${table}_${columnArray.join('_')}_idx ON ${table}(${columnArray.join(', ')});`
        );
      }
    }
    
    return sqlStatements;
  }
  
  /**
   * Generate schema improvements based on query patterns
   */
  generateSchemaImprovements(): string[] {
    const improvements: string[] = [];
    
    // Suggest check constraints for common issues
    improvements.push(
      'Add CHECK constraints for date ranges (e.g., end_date >= start_date)',
      'Add NOT NULL constraints for required fields',
      'Add domain constraints for enumerated types'
    );
    
    // Suggest foreign key improvements
    improvements.push(
      'Ensure all foreign keys have corresponding indexes',
      'Consider ON DELETE CASCADE for child tables',
      'Ensure appropriate NOT NULL constraints on foreign key columns'
    );
    
    return improvements;
  }
}

// Export a singleton instance
export const dbIndexOptimizerService = new DbIndexOptimizerService();