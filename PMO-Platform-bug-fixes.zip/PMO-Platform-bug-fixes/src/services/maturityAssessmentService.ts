import { v4 as uuidv4 } from 'uuid';
import { Domain, DocumentChunk } from '../types';
import { supabase } from './supabaseClient';
import { geminiService } from './geminiService';

interface DomainInput {
  domain: Domain;
  input: string;
}

interface ProjectInfo {
  name: string;
  startDate: string;
  endDate: string;
  budget: number;
  keyObjectives: string[];
}

interface MaturityAssessmentRequest {
  organizationName: string;
  industry: string;
  currentMaturityLevel: string;
  domainInputs: DomainInput[];
  relevantDocuments?: DocumentChunk[];
  projectInfo: ProjectInfo;
}

interface MaturityAssessmentResult {
  overallMaturity: string;
  domainMaturity: Record<number, string>;
  strengths: string[];
  weaknesses: string[];
  recommendations: string[];
  report: string;
}

class MaturityAssessmentService {
  /**
   * Generate a comprehensive PMO maturity assessment based on available data
   */
  async generateMaturityAssessment(request: MaturityAssessmentRequest): Promise<MaturityAssessmentResult> {
    try {
      // In a production system, this would make a call to a more sophisticated AI endpoint
      // Here we'll use the Gemini service with a carefully crafted prompt
      
      // If Gemini API is available, use it
      if (geminiService.isInitialized()) {
        const promptContent = this.buildMaturityAssessmentPrompt(request);
        try {
          const result = await geminiService.model.generateContent({
            contents: [{ role: "user", parts: [{ text: promptContent }] }],
            generationConfig: {
              temperature: 0.4,
              topK: 40,
              topP: 0.8,
              maxOutputTokens: 8192,
            },
          });
          
          // Check if result and result.response exist
          if (!result || !result.response) {
            console.error('Null or undefined response from Gemini');
            return this.generateMockAssessment(request);
          }
          
          return this.parseGeminiResponse(result.response.text());
        } catch (geminiError) {
          console.error('Error calling Gemini API:', geminiError);
          return this.generateMockAssessment(request);
        }
      } else {
        // Fallback to mock assessment if Gemini API is not available
        return this.generateMockAssessment(request);
      }
    } catch (error) {
      console.error('Error generating maturity assessment:', error);
      // Fallback to mock assessment on error
      return this.generateMockAssessment(request);
    }
  }
  
  /**
   * Build a detailed prompt for the AI to generate a maturity assessment
   */
  private buildMaturityAssessmentPrompt(request: MaturityAssessmentRequest): string {
    // Format domain inputs for the prompt
    const domainInputsText = request.domainInputs
      .filter(di => di.input.trim().length > 0)
      .map(di => `## Domain: ${di.domain.name}\n${di.input.substring(0, 1000)}${di.input.length > 1000 ? '...' : ''}`)
      .join('\n\n');
    
    // Format document chunks for the prompt
    const documentChunksText = request.relevantDocuments && request.relevantDocuments.length > 0
      ? request.relevantDocuments
        .slice(0, 5) // Limit to 5 chunks to avoid token limit issues
        .map(chunk => `Document: ${chunk.metadata.source || 'Unknown'}\n${chunk.content.substring(0, 500)}`)
        .join('\n\n')
      : '';
    
    return `
You are an expert PMO (Project Management Office) maturity assessor. Your task is to analyze the provided information 
and generate a comprehensive assessment of the organization's PMO maturity across different domains.

ORGANIZATION INFORMATION:
- Name: ${request.organizationName || 'Unnamed Organization'}
- Industry: ${request.industry || 'Unknown'}
- Self-reported Maturity Level: ${request.currentMaturityLevel || 'Initial'}

PROJECT INFORMATION:
- Name: ${request.projectInfo.name}
- Start Date: ${request.projectInfo.startDate}
- End Date: ${request.projectInfo.endDate}
- Budget: ${request.projectInfo.budget}
- Key Objectives: ${request.projectInfo.keyObjectives.join(', ')}

DOMAIN INFORMATION:
${domainInputsText}

${documentChunksText ? `ADDITIONAL CONTEXT FROM DOCUMENTS:\n${documentChunksText}` : ''}

MATURITY LEVELS REFERENCE:
1. Initial - Processes are ad-hoc and chaotic
2. Defined - Processes are documented and standardized
3. Managed - Processes are measured and controlled
4. Optimized - Focus on continuous improvement
5. Innovative - Driving industry innovation and adaptation

ASSESSMENT TASK:
Please provide a comprehensive PMO maturity assessment with the following components:

1. Overall PMO maturity level (one of: initial, defined, managed, optimized, innovative)
2. Domain-specific maturity levels for each PMO domain
3. Key strengths (5 bullet points)
4. Key weaknesses/improvement areas (5 bullet points)
5. Specific recommendations for improvement (7 bullet points)
6. A detailed assessment report explaining your findings

Format your response as structured JSON with these sections:
{
  "overallMaturity": "level_name",
  "domainMaturity": {
    "1": "level_name",
    "2": "level_name",
    "3": "level_name",
    "4": "level_name",
    "5": "level_name",
    "6": "level_name"
  },
  "strengths": ["strength1", "strength2", "strength3", "strength4", "strength5"],
  "weaknesses": ["weakness1", "weakness2", "weakness3", "weakness4", "weakness5"],
  "recommendations": ["rec1", "rec2", "rec3", "rec4", "rec5", "rec6", "rec7"],
  "report": "detailed markdown report with assessment findings"
}

Ensure your assessment is evidence-based, realistic, and provides actionable insights. Use specific examples from the provided content when possible.
`;
  }
  
  /**
   * Parse the Gemini response into a structured MaturityAssessmentResult
   */
  private parseGeminiResponse(response: string): MaturityAssessmentResult {
    try {
      // Check if response is null or undefined
      if (!response) {
        console.error('Gemini returned empty response');
        return this.generateFallbackAssessment();
      }
      
      // Extract JSON from response (sometimes Gemini surrounds it with ```json and ```)
      const jsonMatch = response.match(/```json\n([\s\S]*?)\n```/) || 
                        response.match(/```\n([\s\S]*?)\n```/) ||
                        [null, response];
      
      const jsonContent = jsonMatch[1] || response;
      const parsedResponse = JSON.parse(jsonContent);
      
      // Validate that we have all required fields
      if (!parsedResponse.overallMaturity || !parsedResponse.domainMaturity || 
          !parsedResponse.strengths || !parsedResponse.weaknesses || 
          !parsedResponse.recommendations || !parsedResponse.report) {
        console.error('Gemini response missing required fields');
        return this.generateFallbackAssessment();
      }
      
      return {
        overallMaturity: parsedResponse.overallMaturity,
        domainMaturity: parsedResponse.domainMaturity,
        strengths: parsedResponse.strengths,
        weaknesses: parsedResponse.weaknesses,
        recommendations: parsedResponse.recommendations,
        report: parsedResponse.report
      };
      
    } catch (error) {
      console.error('Error parsing Gemini response:', error);
      console.error('Response was:', response);
      
      // Return a fallback assessment if parsing fails
      return this.generateFallbackAssessment();
    }
  }
  
  /**
   * Generate a fallback assessment if the AI call fails
   */
  private generateFallbackAssessment(): MaturityAssessmentResult {
    return {
      overallMaturity: 'defined',
      domainMaturity: {
        1: 'managed',
        2: 'defined',
        3: 'defined', 
        4: 'initial',
        5: 'initial',
        6: 'defined'
      },
      strengths: [
        'Strong strategic alignment with organizational objectives',
        'Well-defined governance structure and processes',
        'Standardized project management methodology',
        'Clear roles and responsibilities defined for PMO staff',
        'Regular stakeholder communication mechanisms in place'
      ],
      weaknesses: [
        'Limited performance measurement and metrics tracking',
        'Inconsistent resource capacity planning',
        'Reactive rather than proactive risk management',
        'Limited continuous improvement mechanisms',
        'Inadequate knowledge management and lessons learned processes'
      ],
      recommendations: [
        'Implement a formal PMO performance measurement framework with KPIs',
        'Develop a standardized resource capacity planning process',
        'Establish a proactive risk management approach with regular reviews',
        'Create a continuous improvement process with regular maturity assessments',
        'Implement a knowledge management system to capture and share lessons learned',
        'Enhance stakeholder engagement through more formalized feedback mechanisms',
        'Develop a PMO training and capability development program'
      ],
      report: `# PMO Maturity Assessment Report

## Executive Summary

Based on the analysis of the provided information, the organization's PMO is currently at the **Defined** maturity level overall. This indicates that the PMO has established basic processes and documentation, but lacks consistent measurement, control, and continuous improvement mechanisms across all domains.

## Domain-Specific Assessment

### Organizational Development and Alignment - Managed (Level 3)
The organization demonstrates good alignment between the PMO and organizational strategy. There's evidence of structured stakeholder engagement and strategic integration. However, there could be more emphasis on measuring the effectiveness of alignment strategies.

### Strategic Framework & Governance - Defined (Level 2)
Basic governance structures are in place with documented processes. However, decision-making frameworks appear inconsistent, and governance effectiveness is not systematically measured.

### PMO Structure & Design - Defined (Level 2)
The PMO structure is formally established with defined roles and responsibilities, but the service catalog and resource allocation appear to lack optimization and flexibility.

### Operational Excellence - Initial (Level 1)
Operational processes show signs of being ad hoc and reactive. Standardized methodologies exist but aren't consistently applied, and there's limited evidence of operational metrics tracking.

### Performance & Improvement - Initial (Level 1)
Performance measurement appears to be basic and inconsistent. Improvement initiatives are reactive rather than proactive, and there's limited evidence of systematic improvement planning.

### Capability Development - Defined (Level 2)
Some training and development processes are in place, but there's a lack of comprehensive competency frameworks and career development paths for PMO staff.

## Recommendations for Improvement

To advance the PMO's maturity, focus on these key areas:

1. Implement a standardized performance measurement framework across all PMO domains
2. Establish a continuous improvement process with regular maturity assessments
3. Develop more robust resource capacity planning procedures
4. Formalize knowledge management and lessons learned processes
5. Enhance governance effectiveness through clearer decision rights and authorities
6. Create comprehensive competency frameworks for PMO staff development
7. Implement more systematic stakeholder feedback mechanisms

## Next Steps

The organization should prioritize addressing the identified weaknesses, starting with establishing consistent measurement practices across all domains. A detailed improvement roadmap with specific objectives, timelines, and outcome metrics would help structure this effort and demonstrate PMO value to the organization.

Regular reassessment (quarterly or bi-annually) is recommended to track progress and adjust the improvement strategy as needed.`
    };
  }
  
  /**
   * Generate a mock assessment for demonstration purposes
   */
  private generateMockAssessment(request: MaturityAssessmentRequest): MaturityAssessmentResult {
    const domainInputsCount = request.domainInputs.filter(di => di.input.trim().length > 0).length;
    const maturityLevels = ['initial', 'defined', 'managed', 'optimized', 'innovative'];
    
    // Base the overall maturity on the current level with a slight improvement
    const currentLevelIndex = maturityLevels.indexOf(request.currentMaturityLevel.toLowerCase());
    const newLevelIndex = Math.min(currentLevelIndex + 1, maturityLevels.length - 1);
    
    // Generate domain-specific maturity levels based on domain inputs
    const domainMaturity: Record<number, string> = {};
    request.domainInputs.forEach(di => {
      const inputLength = di.input.length;
      let levelIndex: number;
      
      if (inputLength > 1500) levelIndex = Math.min(newLevelIndex + 1, maturityLevels.length - 1);
      else if (inputLength > 500) levelIndex = newLevelIndex;
      else if (inputLength > 100) levelIndex = Math.max(currentLevelIndex, 1);
      else levelIndex = Math.max(currentLevelIndex - 1, 0);
      
      domainMaturity[di.domain.id] = maturityLevels[levelIndex];
    });
    
    // Adjust based on domain count with inputs
    let overallMaturity = maturityLevels[Math.max(0, Math.min(newLevelIndex, domainInputsCount > 3 ? newLevelIndex : currentLevelIndex))];
    
    // Common strengths by maturity level
    const strengthsByLevel: Record<string, string[]> = {
      initial: [
        'Recognition of the need for standardized processes',
        'Executive support for PMO establishment',
        'Willingness to adopt best practices',
        'Some project documentation templates in place',
        'Basic project tracking mechanisms established'
      ],
      defined: [
        'Standardized project management methodology',
        'Documented PMO processes and procedures',
        'Clear roles and responsibilities',
        'Consistent project documentation',
        'Established governance structure'
      ],
      managed: [
        'Data-driven decision making',
        'Consistent performance metrics tracking',
        'Resource capacity planning process',
        'Proactive risk management',
        'Regular stakeholder engagement'
      ],
      optimized: [
        'Continuous improvement culture',
        'Advanced portfolio optimization techniques',
        'Predictive analytics for project outcomes',
        'Tailored methodologies for different project types',
        'High stakeholder satisfaction levels'
      ],
      innovative: [
        'Industry-leading PMO practices',
        'Adaptive organizational structures',
        'Cutting-edge project delivery techniques',
        'Advanced resource optimization algorithms',
        'Pioneering value measurement approaches'
      ]
    };
    
    // Common weaknesses by maturity level
    const weaknessesByLevel: Record<string, string[]> = {
      initial: [
        'Inconsistent project management approaches',
        'Limited process documentation',
        'Ad-hoc resource allocation',
        'Minimal performance measurement',
        'Reactive rather than proactive management'
      ],
      defined: [
        'Limited performance measurement and metrics',
        'Inconsistent process adherence',
        'Basic resource management capabilities',
        'Limited continuous improvement mechanisms',
        'Reactive risk management practices'
      ],
      managed: [
        'Limited predictive capabilities',
        'Some inconsistency in process optimization',
        'Room for improvement in resource utilization',
        'Opportunity for better strategic alignment',
        'Knowledge management processes not fully mature'
      ],
      optimized: [
        'Opportunity to pioneer new methodologies',
        'Limited cross-industry benchmarking',
        'Room for advanced analytics adoption',
        'Potential for more adaptive governance',
        'Opportunity for innovation in stakeholder engagement'
      ],
      innovative: [
        'Balancing innovation with standardization',
        'Managing the pace of change',
        'Maintaining agility with scale',
        'Knowledge transfer of advanced techniques',
        'Quantifying innovation benefits'
      ]
    };
    
    // Common recommendations by maturity level
    const recommendationsByLevel: Record<string, string[]> = {
      initial: [
        'Develop and document standardized project management processes',
        'Establish a basic PMO charter and governance structure',
        'Implement project portfolio tracking mechanisms',
        'Develop basic project management templates',
        'Institute regular project status reporting',
        'Provide basic project management training',
        'Establish project prioritization criteria'
      ],
      defined: [
        'Implement performance metrics tracking across projects',
        'Develop resource capacity planning process',
        'Establish continuous improvement mechanisms',
        'Formalize risk management processes',
        'Develop PMO competency framework',
        'Implement lessons learned process',
        'Establish regular maturity assessments'
      ],
      managed: [
        'Implement predictive analytics for project outcomes',
        'Optimize resource allocation across the portfolio',
        'Develop advanced stakeholder engagement strategies',
        'Implement value-based portfolio management',
        'Enhance knowledge management systems',
        'Develop specialized PMO career paths',
        'Implement advanced risk modeling techniques'
      ],
      optimized: [
        'Pioneer innovative project delivery methods',
        'Implement adaptive governance frameworks',
        'Develop cross-industry benchmarking',
        'Establish innovation incubation within PMO',
        'Implement advanced analytics and AI for project management',
        'Develop leading-edge resource optimization algorithms',
        'Create thought leadership content in project management'
      ],
      innovative: [
        'Lead industry forums on PMO innovation',
        'Develop next-generation PMO models',
        'Establish PMO research and development function',
        'Create advanced simulation capabilities for portfolio optimization',
        'Develop PMO certification and training programs for the industry',
        'Establish partnerships with academic institutions',
        'Pioneer new methods for measuring PMO contribution to organizational success'
      ]
    };
    
    // Select appropriate recommendations, strengths, and weaknesses based on maturity level
    const strengths = strengthsByLevel[overallMaturity] || strengthsByLevel.defined;
    const weaknesses = weaknessesByLevel[overallMaturity] || weaknessesByLevel.defined;
    const recommendations = recommendationsByLevel[overallMaturity] || recommendationsByLevel.defined;
    
    // Generate a detailed report
    const report = `# PMO Maturity Assessment Report

## Executive Summary

Based on the analysis of the provided information for ${request.organizationName || 'the organization'} in the ${request.industry || 'unspecified'} industry, the organization's PMO is currently at the **${overallMaturity.toUpperCase()}** maturity level overall. ${
  overallMaturity === 'initial' ? 'This indicates that the PMO practices are largely ad-hoc and reactive, with limited standardization.' : 
  overallMaturity === 'defined' ? 'This indicates that the PMO has established basic processes and documentation, but lacks consistent measurement and control mechanisms.' :
  overallMaturity === 'managed' ? 'This indicates that the PMO has well-established processes with consistent measurement and control mechanisms.' :
  overallMaturity === 'optimized' ? 'This indicates that the PMO has mature processes with a strong focus on continuous improvement and optimization.' :
  'This indicates that the PMO is at the forefront of industry innovation with cutting-edge practices and approaches.'
}

## Domain-Specific Assessment

${request.domainInputs.map(di => {
  const level = domainMaturity[di.domain.id];
  return `### ${di.domain.name} - ${level.charAt(0).toUpperCase() + level.slice(1)} (Level ${maturityLevels.indexOf(level) + 1})
  
${
  level === 'initial' ? `The ${di.domain.name.toLowerCase()} shows signs of ad-hoc and reactive processes. There's limited standardization and documentation.` : 
  level === 'defined' ? `The ${di.domain.name.toLowerCase()} demonstrates standardized processes with basic documentation. However, measurement and control mechanisms are not fully developed.` :
  level === 'managed' ? `The ${di.domain.name.toLowerCase()} shows strong process maturity with consistent measurement and control. Data-driven decision making is evident.` :
  level === 'optimized' ? `The ${di.domain.name.toLowerCase()} demonstrates advanced maturity with continuous improvement mechanisms and optimization of processes.` :
  `The ${di.domain.name.toLowerCase()} is at the forefront of industry innovation with pioneering approaches and techniques.`
}`;
}).join('\n\n')}

## Recommendations for Improvement

To advance the PMO's maturity, focus on these key areas:

${recommendations.map((rec, i) => `${i+1}. ${rec}`).join('\n')}

## Next Steps

${request.organizationName || 'The organization'} should prioritize addressing the identified weaknesses, starting with the highest impact areas. A detailed improvement roadmap with specific objectives, timelines, and outcome metrics would help structure this effort and demonstrate PMO value to the organization.

Regular reassessment (quarterly or bi-annually) is recommended to track progress and adjust the improvement strategy as needed.`;

    return {
      overallMaturity,
      domainMaturity,
      strengths,
      weaknesses,
      recommendations,
      report
    };
  }
  
  /**
   * Save maturity assessment results to Supabase (for future implementation)
   */
  async saveMaturityAssessment(
    result: MaturityAssessmentResult,
    userId: string,
    projectId: string
  ): Promise<string> {
    try {
      const assessmentId = uuidv4();
      
      const { error } = await supabase
        .from('maturity_assessments')
        .insert({
          id: assessmentId,
          user_id: userId,
          project_id: projectId,
          overall_maturity: result.overallMaturity,
          domain_maturity: result.domainMaturity,
          strengths: result.strengths,
          weaknesses: result.weaknesses,
          recommendations: result.recommendations,
          report: result.report,
          created_at: new Date().toISOString(),
          assessment_type: 'ai'
        });
        
      if (error) throw error;
      
      return assessmentId;
    } catch (error) {
      console.error('Error saving maturity assessment:', error);
      return '';
    }
  }
}

export const maturityAssessmentService = new MaturityAssessmentService();