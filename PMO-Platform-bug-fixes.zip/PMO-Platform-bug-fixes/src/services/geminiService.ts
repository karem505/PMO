import { GoogleGenerativeAI } from '@google/generative-ai';
import { templateService } from './templateService';
import { supabase } from './supabaseClient';
import { Domain, DocumentChunk } from '../types';
import { documentProcessingService } from './documentProcessingService';

// Create a wrapper service for Google's Generative AI
class GeminiService {
  model: any;
  private gemini: GoogleGenerativeAI;
  private initialized: boolean = false;
  private apiKey: string = '';
  private analysisStartTime: number | null = null;
  private analysisQueue: Map<string, Promise<any>> = new Map();
  private maxAnalysisTime: number = 2.5 * 60 * 1000; // 2.5 minutes max analysis time
  private useFallbackCache: boolean = true; // Default to using fallback to avoid quota issues
  private lastApiCallTime: number = 0;
  private minTimeBetweenCalls: number = 10000; // 10 seconds minimum between API calls

  constructor() {
    this.apiKey = import.meta.env.VITE_GEMINI_API_KEY;
    if (!this.apiKey) {
      console.warn('Gemini API key is missing. AI analysis will fall back to mock data.');
      return;
    }

    try {
      this.gemini = new GoogleGenerativeAI(this.apiKey);
      this.model = this.gemini.getGenerativeModel({ model: "gemini-1.5-pro" });
      this.initialized = true;
      console.log('Gemini AI service initialized successfully');
      
      // Don't immediately test connection to avoid quota issues
      // Instead use fallback by default until proven otherwise
    } catch (error) {
      console.error('Failed to initialize Gemini AI service:', error);
      this.useFallbackCache = true;
    }
  }

  /**
   * Test Gemini API connection with rate limiting
   * Only call this when absolutely necessary, not on initialization
   */
  private async testConnection(): Promise<boolean> {
    // Check if we've called the API too recently
    const now = Date.now();
    if (now - this.lastApiCallTime < this.minTimeBetweenCalls) {
      console.log('Skipping API connection test due to rate limiting');
      return false;
    }
    
    try {
      this.lastApiCallTime = now;
      const startTime = performance.now();
      const result = await this.model.generateContent({
        contents: [{ role: "user", parts: [{ text: "Hello, test connection. Respond with 'OK'." }] }],
        generationConfig: {
          maxOutputTokens: 5, // Reduced token count for test
        },
      });
      
      const responseTime = performance.now() - startTime;
      console.log(`Gemini API connection test succeeded in ${responseTime.toFixed(2)}ms`);
      
      // If response time is too slow (>2s), enable fallback strategy
      if (responseTime > 2000) {
        console.warn('Gemini API response is slow, enabling fallback strategy');
        this.useFallbackCache = true;
        return false;
      } else {
        this.useFallbackCache = false;
        return true;
      }
    } catch (error: any) {
      // Check for quota error (429)
      if (error.message && error.message.includes('429')) {
        console.error('Gemini API quota exceeded, using fallback until quota resets');
        // Set a longer time between calls for quota errors
        this.minTimeBetweenCalls = 60000; // 1 minute
      } else {
        console.error('Gemini API connection test failed:', error);
      }
      this.useFallbackCache = true;
      return false;
    }
  }

  /**
   * Check if the service is properly initialized
   */
  isInitialized(): boolean {
    return this.initialized;
  }

  /**
   * Safely check if we can use the API without hitting rate limits
   */
  private async canUseApi(): Promise<boolean> {
    if (!this.initialized) return false;
    if (this.useFallbackCache) return false;
    
    const now = Date.now();
    // If we've recently made an API call, don't test again
    if (now - this.lastApiCallTime < this.minTimeBetweenCalls) {
      return !this.useFallbackCache;
    }
    
    // Randomly skip connection tests most of the time to reduce API calls
    // Only test 10% of the time when we're not sure
    if (Math.random() > 0.1) {
      return !this.useFallbackCache;
    }
    
    return await this.testConnection();
  }

  /**
   * Analyze domain input to generate comprehensive analysis
   * Enhanced with caching, performance tracking, and optimizations
   */
  async analyzeDomainInput(
    domainName: string, 
    domainDescription: string, 
    inputContent: string,
    previousDomainOutput?: string | null,
    userOrganization?: string,
    userIndustry?: string,
    userMaturityLevel?: string,
    projectId?: string
  ): Promise<{content: string, templates: {name: string, content: string}[]}> {
    // Check for demo mode or initialization issues
    if (!this.initialized) {
      console.warn('Gemini AI service is not initialized, using fallback analysis');
      return this.getFallbackAnalysis(domainName, domainDescription);
    }

    // Generate a cache key based on inputs
    const cacheKey = `${domainName}-${inputContent.slice(0, 100)}-${userMaturityLevel || ''}`;
    const cacheKeyFull = `gemini-analysis-${cacheKey}`;
    
    // Always check for cached results first to avoid unnecessary API calls
    const cachedAnalysis = localStorage.getItem(cacheKeyFull);
    if (cachedAnalysis) {
      try {
        console.log('[Performance] Using cached analysis from localStorage');
        return JSON.parse(cachedAnalysis);
      } catch (err) {
        console.error('Error parsing cached analysis:', err);
        // Continue with normal flow if cache parsing fails
      }
    }
    
    // Check if this analysis is already in progress
    if (this.analysisQueue.has(cacheKey)) {
      console.log('[Performance] Reusing in-progress analysis for:', domainName);
      return this.analysisQueue.get(cacheKey)!;
    }

    // Start tracking analysis time
    this.analysisStartTime = performance.now();
    console.log('[Performance] Starting domain analysis for:', domainName);

    // Check if we can use the API without hitting rate limits
    const canUseApi = await this.canUseApi();
    if (!canUseApi) {
      console.log('Cannot use Gemini API due to rate limits, using fallback analysis');
      const fallbackResult = this.getFallbackAnalysis(domainName, domainDescription);
      
      // Cache the fallback result
      try {
        localStorage.setItem(cacheKeyFull, JSON.stringify(fallbackResult));
      } catch (err) {
        console.warn('Failed to cache fallback analysis:', err);
      }
      
      return fallbackResult;
    }

    // Create a promise for this analysis and add it to the queue
    const analysisPromise = this.createAnalysisPromise(
      domainName, 
      domainDescription, 
      inputContent,
      previousDomainOutput,
      userOrganization,
      userIndustry,
      userMaturityLevel,
      projectId,
      cacheKeyFull
    );

    // Add to the queue
    this.analysisQueue.set(cacheKey, analysisPromise);
    return analysisPromise;
  }
  
  /**
   * Create a promise for domain analysis with timeout handling
   */
  private async createAnalysisPromise(
    domainName: string,
    domainDescription: string,
    inputContent: string,
    previousDomainOutput?: string | null,
    userOrganization?: string,
    userIndustry?: string,
    userMaturityLevel?: string,
    projectId?: string,
    cacheKey?: string
  ): Promise<{content: string, templates: {name: string, content: string}[]}> {
    // Create an abort controller for the entire analysis process
    const controller = new AbortController();
    const signal = controller.signal;
    
    // Set a timeout to abort the analysis if it takes too long
    const timeoutId = setTimeout(() => {
      controller.abort();
      console.warn(`Analysis for ${domainName} aborted after ${this.maxAnalysisTime/1000} seconds`);
    }, this.maxAnalysisTime);

    try {
      // Limit document fetching to improve performance
      let relevantChunks: DocumentChunk[] = [];
      
      // Document fetching with timeout
      try {
        if (projectId) {
          const docFetchPromise = documentProcessingService.getRelevantChunks(
            `${domainName} ${domainDescription}`,
            projectId,
            2, // Further reduced for speed
            undefined
          ).then(chunks => {
            relevantChunks = chunks;
          });
          
          // Limited time for document fetching
          await Promise.race([
            docFetchPromise,
            new Promise(resolve => setTimeout(resolve, 1000)) // Only wait 1 second max
          ]);
        }
      } catch (error) {
        console.error('Error fetching document chunks (continuing without them):', error);
        // Continue without document chunks
      }

      // Optimize input size drastically for speed
      let processedInputContent = this.prepareInputContent(inputContent);

      // Construct a simplified prompt - removed previous domain context for speed
      const systemPrompt = this.constructSimplifiedPrompt(
        domainName, 
        domainDescription, 
        userOrganization,
        userIndustry,
        userMaturityLevel,
        relevantChunks
      );
      
      // Use for quick analysis first, more comprehensive versions later
      const quickAnalysisMaxTokens = 3000;
      
      // Update last API call time
      this.lastApiCallTime = Date.now();
      
      // Generate analysis with strict timeout and handle potential rate limit errors
      let result;
      try {
        result = await Promise.race([
          this.model.generateContent({
            contents: [
              {
                role: "user",
                parts: [
                  { text: systemPrompt },
                  { text: processedInputContent }
                ]
              }
            ],
            generationConfig: {
              temperature: 0.2, // Further reduced for speed and consistency
              topK: 40,
              topP: 0.9,
              maxOutputTokens: quickAnalysisMaxTokens,
            },
          }),
          
          // Add a timeout to prevent long-running requests
          new Promise((_, reject) => {
            signal.addEventListener('abort', () => {
              reject(new Error("Analysis timed out, using fallback"));
            });
          }),
        ]);
      } catch (error: any) {
        console.error('Error during Gemini API content generation:', error);
        if (error.message && error.message.includes('429')) {
          console.warn('Gemini API quota exceeded during analysis, switching to fallback');
          this.useFallbackCache = true;
          this.minTimeBetweenCalls = 60000; // Increase cooldown period
        }
        throw error; // Re-throw to be caught by outer catch
      }

      const analysisContent = result.response.text();
      
      // Generate just a single template for speed
      // Wait max 10 seconds for template generation
      const templatePromise = new Promise<{name: string, content: string}[]>(async (resolve) => {
        try {
          // Find domain object
          const domains = await this.fetchDomains();
          const domain = domains.find(d => d.name === domainName) || {
            id: 0,
            name: domainName,
            description: domainDescription,
            icon: 'Building2'
          };
          
          // Get just a single template for speed
          const templateType = this.getPrimaryTemplateForDomain(domain.name);
          
          // Generate template with reduced content
          const template = await templateService.generateTemplate(
            templateType,
            domain,
            processedInputContent.substring(0, 500),
            []
          );
          
          resolve([template]);
        } catch (error) {
          console.error('Template generation failed, using fallback:', error);
          // Return fallback template
          resolve([{
            name: `${domainName} Implementation Guide`,
            content: this.getFallbackTemplateContent(domainName, `${domainName} Implementation Guide`)
          }]);
        }
      });
      
      // Wait for template with timeout
      const templates = await Promise.race([
        templatePromise,
        new Promise<{name: string, content: string}[]>((resolve) => {
          setTimeout(() => {
            resolve([{
              name: `${domainName} Implementation Guide`,
              content: this.getFallbackTemplateContent(domainName, `${domainName} Implementation Guide`)
            }]);
          }, 10000); // 10 second timeout for template generation
        })
      ]);
      
      // Create result object
      const analysisResult = {
        content: analysisContent,
        templates
      };
      
      // Cache successful results
      if (cacheKey) {
        try {
          localStorage.setItem(cacheKey, JSON.stringify(analysisResult));
        } catch (err) {
          console.warn('Failed to cache analysis results:', err);
        }
      }
      
      // Finally remove this analysis from the queue
      if (cacheKey) {
        this.analysisQueue.delete(cacheKey.replace('gemini-analysis-', ''));
      }
      
      // Log total success time
      if (this.analysisStartTime) {
        const totalTime = performance.now() - this.analysisStartTime;
        console.log(`[Performance] Total analysis time: ${totalTime.toFixed(2)}ms (${(totalTime/1000).toFixed(2)} seconds)`);
        this.analysisStartTime = null;
      }

      return analysisResult;
    } catch (error) {
      console.error('Error analyzing domain input with Gemini AI:', error);
      
      // Log error time
      if (this.analysisStartTime) {
        const totalTime = performance.now() - this.analysisStartTime;
        console.error(`[Performance] Analysis failed after ${totalTime.toFixed(2)}ms (${(totalTime/1000).toFixed(2)} seconds)`);
        this.analysisStartTime = null;
      }
      
      // Remove from queue on error
      if (cacheKey) {
        this.analysisQueue.delete(cacheKey.replace('gemini-analysis-', ''));
      }

      // Add a dummy cached result to avoid repeated failures
      if (cacheKey) {
        const fallbackResult = this.getFallbackAnalysis(domainName, domainDescription);
        try {
          localStorage.setItem(cacheKey, JSON.stringify(fallbackResult));
        } catch (err) {
          console.warn('Failed to cache fallback analysis:', err);
        }
      }
      
      // Return fallback analysis
      return this.getFallbackAnalysis(domainName, domainDescription);
    } finally {
      clearTimeout(timeoutId);
    }
  }
  
  /**
   * Prepare input content for faster processing
   */
  private prepareInputContent(inputContent: string): string {
    // For extremely long inputs, be more aggressive with truncation
    const maxInputLength = inputContent.length > 5000 ? 1500 : 2000;
    
    if (inputContent.length <= maxInputLength) {
      return inputContent;
    }
    
    // Extract key sections to provide a more relevant summary
    // Look for headings and important paragraphs
    const lines = inputContent.split('\n');
    const headings: string[] = [];
    const importantParagraphs: string[] = [];
    
    for (const line of lines) {
      // Extract headings (markdown format)
      if (/^#{1,3}\s+.+/.test(line)) {
        headings.push(line);
      }
      
      // Get paragraphs with key terms like "challenge", "problem", "current", etc.
      const keyTerms = ['challenge', 'problem', 'current', 'issue', 'goal', 'objective', 'strategy', 'approach'];
      if (keyTerms.some(term => line.toLowerCase().includes(term)) && line.length > 50) {
        importantParagraphs.push(line);
      }
    }
    
    // Create an optimized input with structure preserved
    let optimizedInput = '';
    
    // Add first 500 chars
    optimizedInput += inputContent.substring(0, 500) + '\n\n';
    
    // Add headings
    if (headings.length > 0) {
      optimizedInput += '## Key Sections:\n' + headings.slice(0, 5).join('\n') + '\n\n';
    }
    
    // Add important paragraphs
    if (importantParagraphs.length > 0) {
      optimizedInput += '## Key Points:\n' + importantParagraphs.slice(0, 3).join('\n\n') + '\n\n';
    }
    
    // Add note about truncation
    optimizedInput += `\n\n[Note: Content was optimized from the original ${inputContent.length} characters for faster processing]`;
    
    return optimizedInput;
  }

  /**
   * Fetch domains from the data store
   */
  private async fetchDomains(): Promise<Domain[]> {
    try {
      // Import from data file
      const { domains } = await import('../data');
      return domains;
    } catch (error) {
      console.error('Error fetching domains:', error);
      return [];
    }
  }
  
  /**
   * Get the primary template type for a domain
   */
  private getPrimaryTemplateForDomain(domainName: string): string {
    // Just return the most valuable template for each domain
    switch (domainName) {
      case "Organizational Development and Alignment":
        return "Organizational Alignment Framework";
      case "Strategic Framework & Governance":
        return "PMO Strategic Plan Template";
      case "PMO Structure & Design":
        return "PMO Charter Template";
      case "Operational Excellence":
        return "PMO KPI Dashboard Template";
      case "Performance & Improvement":
        return "Continuous Improvement Plan";
      case "Capability Development":
        return "PMO Competency Framework";
      default:
        return `${domainName} Implementation Guide`;
    }
  }

  /**
   * Generate a fallback analysis if the AI fails
   */
  private getFallbackAnalysis(domainName: string, domainDescription: string): {content: string, templates: {name: string, content: string}[]} {
    console.log('Generating fallback analysis for:', domainName);
    
    // Create a basic analysis based on domain name
    const analysisContent = `# ${domainName} Analysis

## Executive Summary

This analysis provides an overview of the current state of your ${domainName.toLowerCase()} and recommendations for improvement. Due to processing constraints, this is a simplified analysis.

## Key Recommendations

1. **Document Current Processes**: Start by documenting all existing processes related to ${domainName.toLowerCase()}.
2. **Benchmark Against Industry Standards**: Compare your current practices with established industry standards.
3. **Develop Implementation Roadmap**: Create a phased implementation plan with clear milestones.
4. **Establish Governance Structure**: Define clear roles, responsibilities, and decision-making authorities.
5. **Implement Measurement Framework**: Develop KPIs to track the effectiveness of your ${domainName.toLowerCase()}.

## Implementation Approach

For successful implementation, consider the following approach:

1. **Assessment Phase** (Weeks 1-4): Evaluate current maturity and identify gaps
2. **Design Phase** (Weeks 5-8): Develop frameworks and processes based on assessment findings
3. **Implementation Phase** (Weeks 9-16): Roll out the frameworks with appropriate change management
4. **Evaluation Phase** (Ongoing): Measure effectiveness and identify improvement opportunities

## Key Focus Areas

${this.getDomainSpecificContent(domainName)}

## Next Steps

We recommend starting with a comprehensive assessment of your current ${domainName.toLowerCase()} practices to establish a baseline for improvement.`;

    // Generate fallback templates
    const templateType = this.getPrimaryTemplateForDomain(domainName);
    const templates = [{
      name: templateType,
      content: this.getFallbackTemplateContent(domainName, templateType)
    }];
    
    return {
      content: analysisContent,
      templates
    };
  }

  /**
   * Get domain-specific content for fallback analysis
   */
  private getDomainSpecificContent(domainName: string): string {
    switch (domainName) {
      case "Organizational Development and Alignment":
        return `
- Strategic alignment between PMO and organizational objectives
- Stakeholder engagement and communication strategies
- Cultural integration and change management
- Organizational structure and reporting relationships
- PMO mandate and charter development`;
      
      case "Strategic Framework & Governance":
        return `
- Governance bodies and decision-making frameworks
- Strategic planning and roadmap development
- Portfolio management and prioritization criteria
- Resource allocation and optimization
- Value delivery tracking and reporting`;
      
      case "PMO Structure & Design":
        return `
- PMO model selection (supportive, controlling, directive)
- Roles and responsibilities definition
- Service catalog and value proposition
- Scalability and flexibility considerations
- Integration with existing organizational structures`;
      
      case "Operational Excellence":
        return `
- Standardized methodology and processes
- Quality assurance and control mechanisms
- Performance metrics and reporting
- Risk and issue management
- Resource management and capacity planning`;
      
      case "Performance & Improvement":
        return `
- Maturity assessment and improvement planning
- Continuous improvement processes
- Benchmarking and best practice adoption
- Value measurement and demonstration
- Performance reporting and visualization`;
      
      case "Capability Development":
        return `
- Competency framework development
- Training and certification programs
- Knowledge management systems
- Communities of practice
- Career development pathways`;
      
      default:
        return `
- Process documentation and standardization
- Roles and responsibilities definition
- Performance measurement and metrics
- Continuous improvement mechanisms
- Training and skill development`;
    }
  }

  /**
   * Construct a simplified system prompt for domain analysis
   * Heavily optimized for better performance
   */
  private constructSimplifiedPrompt(
    domainName: string, 
    domainDescription: string, 
    userOrganization?: string,
    userIndustry?: string,
    userMaturityLevel?: string,
    relevantChunks: DocumentChunk[] = []
  ): string {
    // Only include organization context if available
    let organizationContext = '';
    if (userOrganization || userIndustry || userMaturityLevel) {
      organizationContext = `
ORGANIZATION: ${userOrganization || 'Not specified'} | INDUSTRY: ${userIndustry || 'Not specified'} | PMO MATURITY: ${userMaturityLevel || 'Initial'}
`;
    }

    // Only include document context if there are relevant chunks
    let documentContext = '';
    if (relevantChunks.length > 0) {
      documentContext = `
RELATED DOCUMENT CONTEXT:
${relevantChunks.slice(0, 2).map((chunk) => chunk.content.substring(0, 150) + '...').join('\n\n')}
`;
    }

    return `
You are an expert PMO consultant analyzing data for the "${domainName}" domain (${domainDescription}).

${organizationContext}
${documentContext}

Provide a concise yet comprehensive analysis with:
1. Executive Summary (brief overview)
2. Key Recommendations (actionable, specific)
3. Implementation Approach (phased, practical)
4. Key Focus Areas (domain-specific priorities)

FORMAT:
- Use markdown headings, lists, and structure
- Focus on actionable insights and practical guidance
- Keep recommendations specific and implementable
- Total length should be approximately 1500-2000 words

The user's input about their ${domainName.toLowerCase()} practices follows:
`;
  }

  /**
   * Determine appropriate template types based on the domain
   */
  private getTemplateTypesForDomain(domainName: string): string[] {
    const commonTemplates = [
      `${domainName} Maturity Assessment`,
      `${domainName} Implementation Guide`
    ];

    // Add domain-specific templates
    switch (domainName) {
      case "Organizational Development and Alignment":
        return [
          ...commonTemplates,
          "Organizational Alignment Framework",
          "Stakeholder Analysis Matrix",
        ];
      
      case "Strategic Framework & Governance":
        return [
          ...commonTemplates,
          "PMO Strategic Plan Template",
          "Governance Structure Document"
        ];
      
      case "PMO Structure & Design":
        return [
          ...commonTemplates,
          "PMO Charter Template",
          "Service Catalog Template"
        ];
      
      case "Operational Excellence":
        return [
          ...commonTemplates,
          "PMO KPI Dashboard Template",
          "Performance Measurement Framework"
        ];
      
      case "Performance & Improvement":
        return [
          ...commonTemplates,
          "Continuous Improvement Plan",
          "Value Delivery Framework"
        ];
      
      case "Capability Development":
        return [
          ...commonTemplates,
          "PMO Competency Framework",
          "Training and Development Plan"
        ];
      
      default:
        return [
          ...commonTemplates,
          `${domainName} Best Practices Guide`,
          `${domainName} Roadmap`
        ];
    }
  }

  /**
   * Get fallback template content for a specific template type
   */
  private getFallbackTemplateContent(domainName: string, templateType: string): string {
    // Create more specific content based on template type
    let specificContent = '';
    
    if (templateType.includes('Maturity Assessment')) {
      specificContent = `
### Maturity Levels Assessment

| Maturity Level | Description | Characteristics | Your Assessment |
|----------------|-------------|-----------------|-----------------|
| **Level 1: Initial** | Ad-hoc processes | Inconsistent approaches, undocumented processes | □ |
| **Level 2: Defined** | Basic standardization | Documented processes, inconsistent application | □ |
| **Level 3: Managed** | Consistent application | Standardized processes, regular monitoring | □ |
| **Level 4: Optimized** | Continuous improvement | Data-driven refinement, proactive enhancement | □ |
| **Level 5: Innovative** | Industry leadership | Setting best practices, driving innovation | □ |

### Key Focus Areas

- Strategic alignment with organizational objectives
- Process standardization and documentation
- Governance structures and decision-making
- Resource optimization and capability development
- Measurement frameworks and performance tracking
`;
    } else if (templateType.includes('Implementation Guide')) {
      specificContent = `
### Implementation Phases

#### Phase 1: Assessment and Planning (Weeks 1-4)
- [ ] Form implementation team and assign responsibilities
- [ ] Conduct current state assessment
- [ ] Define goals and success criteria
- [ ] Develop detailed implementation plan

#### Phase 2: Pilot Implementation (Weeks 5-8)
- [ ] Select pilot group/area
- [ ] Implement changes in limited scope
- [ ] Collect feedback and measure results
- [ ] Refine approach based on pilot outcomes

#### Phase 3: Full Implementation (Weeks 9-16)
- [ ] Roll out changes across organization
- [ ] Provide training and support
- [ ] Monitor adoption and address issues
- [ ] Document processes and procedures

#### Phase 4: Sustainability and Optimization (Ongoing)
- [ ] Establish continuous improvement mechanisms
- [ ] Conduct regular reviews and assessments
- [ ] Implement refinements based on feedback
- [ ] Share successes and lessons learned
`;
    } else if (templateType.includes('Framework') || templateType.includes('Structure')) {
      specificContent = `
### Framework Components

#### Strategic Level
- Vision and mission alignment
- Executive sponsorship and governance
- Strategic objectives and success metrics
- Portfolio management approach

#### Tactical Level
- Process standardization and methodology
- Resource allocation and capacity planning
- Quality management and controls
- Risk management approach

#### Operational Level
- Day-to-day execution guidelines
- Reporting and communication processes
- Issue and change management
- Knowledge management and documentation
`;
    } else if (templateType.includes('Charter') || templateType.includes('PMO Charter')) {
      specificContent = `
### PMO Charter Components

#### 1. PMO Purpose & Vision
- Mission statement
- Vision statement
- Strategic objectives and goals
- Success criteria

#### 2. PMO Structure and Organization
- Organizational placement
- Reporting relationships
- Roles and responsibilities
- Staffing plan

#### 3. PMO Services and Functions
- Core services offered
- Service levels and expectations
- Stakeholder support model
- Value proposition

#### 4. Governance Model
- Decision-making authorities
- Escalation procedures
- Oversight committees
- Change control process
`;
    } else if (templateType.includes('Dashboard') || templateType.includes('KPI')) {
      specificContent = `
### PMO Performance Dashboard

#### Delivery Metrics
- Projects on-time percentage
- Budget adherence percentage
- Scope adherence percentage
- Quality metrics (defect rates, acceptance rates)

#### Portfolio Metrics
- Strategic alignment score
- Resource utilization percentage
- Portfolio health index
- Benefit realization percentage

#### Service Metrics
- PMO service satisfaction rating
- Response time to requests
- Training effectiveness score
- Knowledge base utilization

#### Value Metrics
- Return on investment (ROI)
- Time-to-market improvement
- Cost savings/avoidance
- Business value delivered
`;
    } else {
      specificContent = `
### Key Components

1. **Strategic Alignment**
   - Alignment with organizational objectives
   - Integration with other business functions
   - Value demonstration and measurement

2. **Operational Excellence**
   - Process standardization and documentation
   - Quality management and assurance
   - Continuous improvement mechanisms

3. **Resource Optimization**
   - Capacity planning and management
   - Skills development and competency building
   - Knowledge management and transfer

4. **Governance and Oversight**
   - Decision-making frameworks and authorities
   - Reporting and communication structures
   - Risk management and mitigation strategies
`;
    }

    return `# ${templateType}

## Purpose and Scope
This template provides a structured framework for implementing and managing ${domainName.toLowerCase()} processes within your PMO. It is designed to align with industry best practices while allowing customization for your specific organizational context.

## Template Components
${specificContent}

## Implementation Guidelines
1. Begin by reviewing all sections of this template
2. Adapt each component to your specific organizational context
3. Involve key stakeholders in the customization process
4. Document modifications to maintain template integrity
5. Review and update periodically based on organizational learning

---

*Note: For best results, customize this template to fit your organization's specific needs and maturity level.*`;
  }

  /**
   * Truncate text to a specific length
   */
  private truncateText(text: string, maxLength: number): string {
    if (!text) return '';
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + '...';
  }
}

// Export a singleton instance
export const geminiService = new GeminiService();