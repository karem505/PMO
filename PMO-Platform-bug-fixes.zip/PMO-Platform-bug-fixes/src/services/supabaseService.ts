import { supabase } from './supabaseClient';
import { UserRole, Permission } from '../types';
import apiClient from '../api/client';

// Auth-related functions
export const signInWithEmail = async (email: string, password: string) => {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password
  });

  if (error) throw error;
  return data;
};

export const signUpWithEmail = async (email: string, password: string, fullName: string) => {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: {
        full_name: fullName
      }
    }
  });

  if (error) throw error;
  return data;
};

// export const signInWithGoogle = async () => {
//   const { data, error } = await supabase.auth.signInWithOAuth({
//     provider: 'google',
//     options: {
//       redirectTo: `${import.meta.env.VITE_API_BASE_URL || import.meta.env.VITE_SUPABASE_URL}/auth/v1/callback`,
//       queryParams: {
//         access_type: 'offline',
//         prompt: 'consent',
//       }
//     }
//   });
//   console.log({data, error});
//   if (error) throw error;
//   return data;
// };

export const resetPassword = async (email: string) => {
  const { error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: `${import.meta.env.VITE_API_BASE_URL || window.location.origin}/reset-password`
  });

  if (error) throw error;
  return true;
};

// Export sendPasswordReset as an alias to resetPassword for compatibility
export const sendPasswordReset = resetPassword;

export const getCurrentUser = async () => {
  // First check if we have a session to avoid unnecessary errors
  const { data: sessionData } = await supabase.auth.getSession();
  
  if (!sessionData.session) {
    return null;
  }
  
  const { data, error } = await supabase.auth.getUser();
  
  if (error) {
    console.error('Error getting current user:', error);
    return null;
  }
  
  return data.user;
};

export const getCurrentSession = async () => {
  console.log('getting current session');
  const { data, error } = await supabase.auth.getSession();
  console.log('data', data);
  if (error) {
    console.error('Error getting current session:', error);
    return null;
  }
  
  return data.session;
};

// Profile-related functions
export const getUserProfile = async (userId: string) => {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .single();

  if (error) {
    console.error('Error getting user profile:', error);
    return null;
  }
  
  return data;
};

export const createUserProfile = async (userId: string, profileData: any) => {
  const { data, error } = await supabase
    .from('profiles')
    .insert([{
      id: userId,
      email: profileData.email,
      display_name: profileData.displayName,
      photo_url: profileData.photoURL,
      organization_name: profileData.organizationName,
      industry: profileData.industry,
      pmo_maturity_level: profileData.pmoMaturityLevel
    }]);

  if (error) throw error;
  return data;
};

export const updateUserProfile = async (userId: string, profileData: any) => {
  const { data, error } = await supabase
    .from('profiles')
    .update(profileData)
    .eq('id', userId);

  if (error) throw error;
  return data;
};

// Project-related functions
export const getProjects = async (userId?: string) => {
  console.log('🔍 Fetching projects', userId ? `for user ${userId}` : 'for current user');
  
  try {
    let query = supabase.from('projects').select('*');
    
    if (userId) {
      console.log('🔍 Filtering by user ID:', userId);
      query = query.eq('owner_id', userId);
    }
    
    const { data, error } = await query;
    
    if (error) {
      console.error('❌ Error fetching projects:', error);
      throw error;
    }
    
    console.log(`✅ Retrieved ${data?.length || 0} projects`);
    return data || [];
  } catch (error) {
    console.error('❌ Error in getProjects function:', error);
    throw error;
  }
};

export const getProject = async (projectId: string) => {
  const { data, error } = await supabase
    .from('projects')
    .select('*')
    .eq('id', projectId)
    .single();

  if (error) {
    console.error('Error fetching project:', error);
    return null;
  }
  
  return data;
};

export const createProject = async (projectData: any) => {
  console.log('📊 Creating project with data:', {
    name: projectData.name,
    description: projectData.description?.substring(0, 20) + '...',
    is_default: projectData.is_default,
    has_owner: !!projectData.owner_id
  });
  
  try {
    // First check if a default project already exists for this user
    if (projectData.is_default) {
      console.log('🔍 Checking for existing default project');
      const { data: existingProjects, error: checkError } = await supabase
        .from('projects')
        .select('id')
        .eq('owner_id', projectData.owner_id)
        .eq('is_default', true);
        
      if (checkError) {
        console.error('❌ Error checking for existing default project:', checkError);
        throw checkError;
      }
        
      if (existingProjects && existingProjects.length > 0) {
        console.log('✅ Default project already exists, returning ID:', existingProjects[0].id);
        return existingProjects[0].id;
      }
    }
    
    // Create the project if no default exists or this is not a default project
    console.log('🆕 Creating new project in Supabase');
    const { data, error } = await supabase
      .from('projects')
      .insert(projectData)
      .select()
      .single();
      
    if (error) {
      console.error('❌ Error inserting project:', error);
      throw error;
    }
    
    console.log('✅ Project created successfully with ID:', data.id);
    return data.id;
  } catch (error) {
    console.error('❌ Error in createProject function:', error);
    throw error;
  }
};

export const updateProject = async (projectId: string, projectData: any) => {
  const { data, error } = await supabase
    .from('projects')
    .update(projectData)
    .eq('id', projectId)
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const deleteProject = async (projectId: string) => {
  const { data, error } = await supabase
    .from('projects')
    .update({ is_active: false })
    .eq('id', projectId);

  if (error) throw error;
  return data;
};

// Domain input/output functions
export const getDomainInputs = async (projectId: string) => {
  const { data, error } = await supabase
    .from('domain_inputs')
    .select('*')
    .eq('project_id', projectId);

  if (error) {
    console.error('Error fetching domain inputs:', error);
    return [];
  }
  
  return data;
};

export const getDomainInput = async (projectId: string, domainId: number) => {
  const { data, error } = await supabase
    .from('domain_inputs')
    .select('*')
    .eq('project_id', projectId)
    .eq('domain_id', domainId)
    .single();

  if (error && error.code !== 'PGRST116') { // Not found error
    console.error('Error fetching domain input:', error);
  }
  
  return data || null;
};

export const saveDomainInput = async (inputData: any) => {
  // Check if input already exists
  const { data: existingData } = await supabase
    .from('domain_inputs')
    .select('id')
    .eq('project_id', inputData.project_id)
    .eq('domain_id', inputData.domain_id)
    .maybeSingle();

  if (existingData) {
    // Update existing record
    const { data, error } = await supabase
      .from('domain_inputs')
      .update({
        content: inputData.content,
        last_updated: new Date().toISOString(),
        created_by: inputData.created_by
      })
      .eq('id', existingData.id)
      .select()
      .single();

    if (error) throw error;
    return data;
  } else {
    // Create new record
    const { data, error } = await supabase
      .from('domain_inputs')
      .insert([inputData])
      .select()
      .single();

    if (error) throw error;
    return data;
  }
};

export const getDomainOutputs = async (projectId: string) => {
  const { data, error } = await supabase
    .from('domain_outputs')
    .select('*')
    .eq('project_id', projectId);

  if (error) {
    console.error('Error fetching domain outputs:', error);
    return [];
  }
  
  return data;
};

export const getDomainOutput = async (projectId: string, domainId: number) => {
  const { data, error } = await supabase
    .from('domain_outputs')
    .select('*')
    .eq('project_id', projectId)
    .eq('domain_id', domainId)
    .single();

  if (error && error.code !== 'PGRST116') { // Not found error
    console.error('Error fetching domain output:', error);
  }
  
  return data || null;
};

export const saveDomainOutput = async (outputData: any, templates: any[] = []) => {
  // First, save the domain output
  const { data: outputResult, error: outputError } = await supabase
    .from('domain_outputs')
    .upsert([{
      project_id: outputData.project_id,
      domain_id: outputData.domain_id,
      content: outputData.content,
      generated_date: new Date().toISOString(),
      created_by: outputData.created_by
    }], {
      onConflict: 'project_id,domain_id',
      ignoreDuplicates: false
    })
    .select()
    .single();

  if (outputError) throw outputError;

  // If there are templates and we have a valid output, save them
  if (templates.length > 0 && outputResult) {
    const templatesWithOutputId = templates.map(template => ({
      domain_output_id: outputResult.id,
      name: template.name,
      content: template.content
    }));

    // First, remove any existing templates
    const { error: deleteError } = await supabase
      .from('templates')
      .delete()
      .eq('domain_output_id', outputResult.id);

    if (deleteError) throw deleteError;

    // Then insert the new templates
    const { error: templateError } = await supabase
      .from('templates')
      .insert(templatesWithOutputId);

    if (templateError) throw templateError;
  }

  return outputResult;
};

// Task-related functions
export const getTasks = async (projectId: string) => {
  const { data, error } = await supabase
    .from('tasks')
    .select('*')
    .eq('project_id', projectId);

  if (error) {
    console.error('Error fetching tasks:', error);
    return [];
  }
  
  return data;
};

export const getTask = async (projectId: string, taskId: string) => {
  const { data, error } = await supabase
    .from('tasks')
    .select('*')
    .eq('project_id', projectId)
    .eq('task_id', taskId)
    .single();

  if (error && error.code !== 'PGRST116') { // Not found error
    console.error('Error fetching task:', error);
  }
  
  return data || null;
};

export const saveTask = async (taskData: any) => {
  // Check if task already exists
  const { data: existingData } = await supabase
    .from('tasks')
    .select('id')
    .eq('project_id', taskData.project_id)
    .eq('task_id', taskData.task_id)
    .maybeSingle();

  if (existingData) {
    // Update existing record
    const { data, error } = await supabase
      .from('tasks')
      .update({
        completed: taskData.completed,
        notes: taskData.notes,
        attachments: taskData.attachments,
        custom_fields: taskData.custom_fields,
        updated_at: new Date().toISOString(),
        updated_by: taskData.updated_by
      })
      .eq('id', existingData.id)
      .select()
      .single();

    if (error) throw error;
    return data;
  } else {
    // Create new record
    const { data, error } = await supabase
      .from('tasks')
      .insert([taskData])
      .select()
      .single();

    if (error) throw error;
    return data;
  }
};

// Role and Permission functions
export const getUserRoles = async (userId: string): Promise<UserRole[]> => {
  const { data, error } = await supabase
    .from('user_roles')
    .select('*, role:roles(*)')
    .eq('user_id', userId);

  if (error) {
    console.error('Error fetching user roles:', error);
    return [];
  }

  return data?.map(item => ({
    id: item.role.id,
    name: item.role.name,
    description: item.role.description
  })) || [];
};

export const getUserPermissions = async (userId: string): Promise<Permission[]> => {
  const { data, error } = await supabase
    .from('user_permissions')
    .select('*, permission:permissions(*)')
    .eq('user_id', userId);

  if (error) {
    console.error('Error fetching user permissions:', error);
    return [];
  }

  return data?.map(item => ({
    id: item.permission.id,
    name: item.permission.name,
    description: item.permission.description,
    resourceType: item.resource_type,
    resourceId: item.resource_id
  })) || [];
};

export const assignRoleToUser = async (userId: string, roleId: string) => {
  const { error } = await supabase
    .from('user_roles')
    .insert([{
      user_id: userId,
      role_id: roleId
    }]);

  if (error) throw error;
  return true;
};

export const removeRoleFromUser = async (userId: string, roleId: string) => {
  const { error } = await supabase
    .from('user_roles')
    .delete()
    .match({
      user_id: userId,
      role_id: roleId
    });

  if (error) throw error;
  return true;
};

export const assignPermissionToUser = async (
  userId: string, 
  permissionId: string,
  resourceType?: string,
  resourceId?: string
) => {
  const { error } = await supabase
    .from('user_permissions')
    .insert([{
      user_id: userId,
      permission_id: permissionId,
      resource_type: resourceType,
      resource_id: resourceId
    }]);

  if (error) throw error;
  return true;
};

export const removePermissionFromUser = async (
  userId: string, 
  permissionId: string,
  resourceType?: string,
  resourceId?: string
) => {
  let query = supabase
    .from('user_permissions')
    .delete()
    .eq('user_id', userId)
    .eq('permission_id', permissionId);
    
  if (resourceType) {
    query = query.eq('resource_type', resourceType);
  }
  
  if (resourceId) {
    query = query.eq('resource_id', resourceId);
  }
  
  const { error } = await query;

  if (error) throw error;
  return true;
};

export const getAllRoles = async (): Promise<UserRole[]> => {
  const { data, error } = await supabase
    .from('roles')
    .select('*');

  if (error) {
    console.error('Error fetching roles:', error);
    return [];
  }

  return data?.map(role => ({
    id: role.id,
    name: role.name,
    description: role.description
  })) || [];
};

export const getAllPermissions = async (): Promise<Permission[]> => {
  const { data, error } = await supabase
    .from('permissions')
    .select('*');

  if (error) {
    console.error('Error fetching permissions:', error);
    return [];
  }

  return data?.map(permission => ({
    id: permission.id,
    name: permission.name,
    description: permission.description,
    resourceType: null,
    resourceId: null
  })) || [];
};

// Project permissions
export const getProjectPermissions = async (projectId: string) => {
  const { data, error } = await supabase
    .from('project_permissions')
    .select('*, user:profiles(id, email, display_name)')
    .eq('project_id', projectId);

  if (error) {
    console.error('Error fetching project permissions:', error);
    return [];
  }
  
  return data;
};

export const setProjectPermission = async (projectId: string, userId: string, role: string) => {
  // First check if permission already exists
  const { data: existingData } = await supabase
    .from('project_permissions')
    .select('id')
    .eq('project_id', projectId)
    .eq('user_id', userId)
    .maybeSingle();

  if (existingData) {
    // Update existing permission
    const { error } = await supabase
      .from('project_permissions')
      .update({
        role,
        updated_at: new Date().toISOString()
      })
      .eq('id', existingData.id);

    if (error) throw error;
  } else {
    // Create new permission
    const { error } = await supabase
      .from('project_permissions')
      .insert([{
        project_id: projectId,
        user_id: userId,
        role,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      }]);

    if (error) throw error;
  }
  
  return true;
};

export const removeProjectPermission = async (projectId: string, userId: string) => {
  const { error } = await supabase
    .from('project_permissions')
    .delete()
    .eq('project_id', projectId)
    .eq('user_id', userId);

  if (error) throw error;
  return true;
};

// Setup free subscription for new user
export const setupFreeSubscription = async (email: string): Promise<void> => {
  try {
    console.log('Setting up free subscription for:', email);
    
    // Get the current user
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      throw new Error('No authenticated user found');
    }
    
    // Check if subscription already exists to prevent duplicates
    const { data: existingSubscriptions } = await supabase
      .from('subscriptions')
      .select('*')
      .eq('user_id', currentUser.id);
      
    if (existingSubscriptions && existingSubscriptions.length > 0) {
      console.log('User already has a subscription, skipping setup');
      return;
    }
    
    // Continue with subscription setup since no existing subscription was found
    const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/subscription/setup-free`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({ user_email: email })
    });
    
    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }
    
    const data = await response.json();
    console.log('Subscription setup response:', data);
    
  } catch (error) {
    console.error('Error setting up free subscription via API:', error);
    
    // Try more extensive fallback logic
    try {
      console.log('Attempting fallback subscription setup for:', email);
      
      // First, ensure we have the current user
      const currentUser = await getCurrentUser();
      if (!currentUser || !currentUser.id) {
        console.warn('Current user not found in fallback, getting session');
        // Get the user from the session
        const { data: { session } } = await supabase.auth.getSession();
        if (!session?.user) {
          throw new Error('No authenticated user found');
        }
        
        // Verify profile exists
        const { data: existingProfile } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', session.user.id)
          .single();
        
        if (!existingProfile) {
          console.log('Creating profile for user:', session.user.id);
          // Create the user profile
          await supabase.from('profiles').insert({
            id: session.user.id,
            email: session.user.email,
            display_name: session.user.user_metadata?.full_name || (session.user.email || '').split('@')[0],
            photo_url: session.user.user_metadata?.avatar_url,
            created_at: new Date().toISOString(),
            organization_name: "",
            industry: "",
            pmo_maturity_level: "Initial"
          });
        }
        
        // Check for existing subscription before creating a new one
        const { data: existingSub } = await supabase
          .from('subscriptions')
          .select('*')
          .eq('user_id', session.user.id);
          
        if (!existingSub || existingSub.length === 0) {
          // Create subscription only if one doesn't exist
          await supabase.from('subscriptions').insert({
            user_id: session.user.id,
            tier: 'free',
            status: 'active',
          });
          console.log('Created subscription for user:', session.user.id);
        } else {
          console.log('Subscription already exists for user:', session.user.id);
        }
        
        // Check for existing usage before creating
        const { data: existingUsage } = await supabase
          .from('subscription_usage')
          .select('*')
          .eq('user_id', session.user.id)
          .eq('feature', 'tokens');
          
        if (!existingUsage || existingUsage.length === 0) {
          // Create subscription usage only if one doesn't exist
          await supabase.from('subscription_usage').insert({
            user_id: session.user.id,
            count: 81250,
            feature: 'tokens'
          });
          console.log('Created subscription usage for user:', session.user.id);
        } else {
          console.log('Subscription usage already exists for user:', session.user.id);
        }
      } else {
        // We have currentUser
        console.log('Using current user ID for fallback:', currentUser.id);
        
        // Check for existing subscription before creating
        const { data: existingSub } = await supabase
          .from('subscriptions')
          .select('*')
          .eq('user_id', currentUser.id);
          
        if (!existingSub || existingSub.length === 0) {
          // Create subscription only if one doesn't exist
          await supabase.from('subscriptions').insert({
            user_id: currentUser.id,
            tier: 'free',
            status: 'active',
          });
          console.log('Created subscription for user:', currentUser.id);
        } else {
          console.log('Subscription already exists for user:', currentUser.id);
        }
        
        // Check for existing usage before creating
        const { data: existingUsage } = await supabase
          .from('subscription_usage')
          .select('*')
          .eq('user_id', currentUser.id)
          .eq('feature', 'tokens');
          
        if (!existingUsage || existingUsage.length === 0) {
          // Create subscription usage only if one doesn't exist
          await supabase.from('subscription_usage').insert({
            user_id: currentUser.id,
            count: 81250,
            feature: 'tokens'
          });
          console.log('Created subscription usage for user:', currentUser.id);
        } else {
          console.log('Subscription usage already exists for user:', currentUser.id);
        }
      }
    } catch (fallbackError) {
      console.error('All subscription setup attempts failed:', fallbackError);
    }
  }
};

// Check and fix a user's setup status
export const checkAndFixUserSetup = async (userId: string): Promise<{ fixed: boolean, issues: string[] }> => {
  try {
  const issues: string[] = [];
  
    // 1. Check if profile exists
    const { data: profileData, error: profileError } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();
      
    if (profileError || !profileData) {
      console.error('Profile missing, attempting to create');
      issues.push('missing_profile');
      
      // Try to get user data from auth
      const { data: { user } } = await supabase.auth.getUser();
      
      if (user) {
        // Create profile
        try {
          const { error: createError } = await supabase
            .from('profiles')
            .insert({
              id: userId,
              email: user.email,
              display_name: user.user_metadata?.full_name || (user.email || '').split('@')[0],
              photo_url: user.user_metadata?.avatar_url,
              created_at: new Date().toISOString(),
              organization_name: "",
              industry: "",
              pmo_maturity_level: "Initial"
            });
            
          if (createError) {
            console.error('Failed to create profile:', createError);
            
            // Retry once after a short delay
            await new Promise(resolve => setTimeout(resolve, 1000));
            
            const { error: retryError } = await supabase
              .from('profiles')
              .insert({
                id: userId,
                email: user.email,
                display_name: user.user_metadata?.full_name || (user.email || '').split('@')[0],
                photo_url: user.user_metadata?.avatar_url,
                created_at: new Date().toISOString(),
                organization_name: "",
                industry: "",
                pmo_maturity_level: "Initial"
              });
              
            if (retryError) {
              console.error('Failed to create profile on retry:', retryError);
              // Report specific error for better debugging
              issues.push(`profile_creation_failed: ${retryError.message}`);
        } else {
              console.log('Successfully created profile on retry');
            }
          } else {
            console.log('Successfully created profile');
          }
        } catch (err) {
          console.error('Exception during profile creation:', err);
          issues.push('profile_exception');
        }
      }
    }
    
    // Note: We no longer handle subscription setup here as it's handled by the backend API
    
    // 4. Check if project exists
    const { data: projectData, error: projectError } = await supabase
      .from('projects')
      .select('*')
      .eq('owner_id', userId)
      .maybeSingle();
      
    if (projectError || !projectData) {
      console.error('Project missing, attempting to create');
      issues.push('missing_project');
      
      // This will be handled by the createProject function
      // called elsewhere in the application
    }
    
    return {
      fixed: issues.length > 0,
      issues
    };
  } catch (error) {
    console.error('Error checking user setup:', error);
    return {
      fixed: false,
      issues: ['check_failed', error instanceof Error ? error.message : String(error)]
    };
  }
};