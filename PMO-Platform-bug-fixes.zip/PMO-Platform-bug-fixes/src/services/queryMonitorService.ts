import { supabase } from './supabaseClient';
import { hashString } from '../utils/documentUtils';
import pLimit from 'p-limit';

/**
 * Service for monitoring, optimizing, and validating database queries
 * Provides statistics and recommendations for query performance
 */
class QueryMonitorService {
  private queryStats: Map<string, {
    count: number;
    totalTime: number;
    minTime: number;
    maxTime: number;
    lastRun: number;
    fails: number;
    succeeded: number;
  }> = new Map();
  
  private requestLimiter = pLimit(5); // Limit concurrent requests
  private isTelemetryEnabled = false;
  private isInitialized = false;
  
  // Query optimization suggestions based on patterns
  private optimizationSuggestions: Map<string, string> = new Map();
  
  // Basic schema information for tables
  private tableSchemas: Map<string, string[]> = new Map();
  
  constructor() {
    this.initialize();
  }
  
  /**
   * Initialize the service
   */
  async initialize() {
    if (this.isInitialized) return;
    
    console.log('[QueryMonitor] Initializing query monitoring service');
    
    try {
      // Load table schemas (lightweight operation - no actual DB calls for demonstration)
      this.loadTableSchemas();
      
      // Create interceptors for Supabase queries
      this.setupQueryInterceptors();
      
      // Set up periodic reporting
      if (this.isTelemetryEnabled) {
        setInterval(() => this.reportQueryStats(), 60000); // Every minute
      }
      
      this.isInitialized = true;
      console.log('[QueryMonitor] Query monitoring initialized successfully');
    } catch (error) {
      console.error('[QueryMonitor] Failed to initialize query monitoring:', error);
    }
  }
  
  /**
   * Load basic schema information for tables
   */
  private loadTableSchemas() {
    // This would normally fetch schemas from the database
    // Using hardcoded schemas for demonstration
    this.tableSchemas.set('projects', [
      'id', 'name', 'description', 'owner_id', 'created_at', 'updated_at', 'start_date', 
      'end_date', 'budget', 'budget_spent', 'key_objectives', 'stakeholders', 
      'risks', 'is_active'
    ]);
    
    this.tableSchemas.set('domain_inputs', [
      'id', 'project_id', 'domain_id', 'content', 'last_updated', 'created_by'
    ]);
    
    this.tableSchemas.set('domain_outputs', [
      'id', 'project_id', 'domain_id', 'content', 'generated_date', 'created_by'
    ]);
    
    this.tableSchemas.set('tasks', [
      'id', 'project_id', 'task_id', 'completed', 'notes', 'attachments',
      'custom_fields', 'document_references', 'dependencies', 'updated_at', 'updated_by'
    ]);
    
    this.tableSchemas.set('document_chunks', [
      'id', 'document_id', 'content', 'chunk_index', 'char_start', 'char_end',
      'token_count', 'page_number', 'source'
    ]);
    
    this.optimizationSuggestions.set(
      'document_chunks',
      'Consider adding a GIN index for content search: CREATE INDEX IF NOT EXISTS document_chunks_content_idx ON document_chunks USING gin(to_tsvector(\'english\', content));'
    );
    
    this.optimizationSuggestions.set(
      'tasks_project_id',
      'Consider adding an index for tasks by project: CREATE INDEX IF NOT EXISTS tasks_project_id_idx ON tasks(project_id);'
    );
  }
  
  /**
   * Set up interceptors to monitor Supabase queries
   */
  private setupQueryInterceptors() {
    // This is a simplified demonstration - in a real implementation
    // you would need to use Supabase's hooks or a proxy pattern
    
    // For demo purposes, we're just wrapping the monitor function
    console.log('[QueryMonitor] Query interceptors configured');
  }
  
  /**
   * Monitor a query execution and collect performance data
   * @param queryName Name or identifier for the query
   * @param fn The query function to execute
   * @returns The query result
   */
  async monitorQuery<T>(queryName: string, fn: () => Promise<T>): Promise<T> {
    return this.requestLimiter(async () => {
      const startTime = performance.now();
      let success = false;
      
      try {
        // Execute the query
        const result = await fn();
        success = true;
        return result;
      } finally {
        const endTime = performance.now();
        const executionTime = endTime - startTime;
        
        // Update stats for this query
        this.updateQueryStats(queryName, executionTime, success);
      }
    });
  }
  
  /**
   * Update statistics for a query
   */
  private updateQueryStats(queryName: string, executionTime: number, success: boolean) {
    const existingStats = this.queryStats.get(queryName) || {
      count: 0,
      totalTime: 0,
      minTime: Number.MAX_VALUE,
      maxTime: 0,
      lastRun: Date.now(),
      fails: 0,
      succeeded: 0
    };
    
    existingStats.count++;
    existingStats.totalTime += executionTime;
    existingStats.minTime = Math.min(existingStats.minTime, executionTime);
    existingStats.maxTime = Math.max(existingStats.maxTime, executionTime);
    existingStats.lastRun = Date.now();
    
    if (success) {
      existingStats.succeeded++;
    } else {
      existingStats.fails++;
    }
    
    this.queryStats.set(queryName, existingStats);
    
    // Log slow queries for immediate attention
    if (executionTime > 1000) { // Over 1 second
      console.warn(`[QueryMonitor] Slow query detected: ${queryName} took ${executionTime.toFixed(2)}ms`);
      
      // Check if we have optimization suggestions
      if (queryName.includes('_')) {
        const tableName = queryName.split('_')[0];
        if (this.optimizationSuggestions.has(tableName)) {
          console.warn(`[QueryMonitor] Optimization suggestion: ${this.optimizationSuggestions.get(tableName)}`);
        }
      }
    }
  }
  
  /**
   * Validate a query against the known schema
   * @param tableName Name of the table
   * @param fields Fields being queried or updated
   * @returns Validation result with warnings if issues are found
   */
  validateQuery(tableName: string, fields: string[]): {
    valid: boolean;
    warnings: string[];
  } {
    const warnings: string[] = [];
    
    // Check if table exists in our schema
    if (!this.tableSchemas.has(tableName)) {
      warnings.push(`Unknown table: ${tableName}`);
      return { valid: false, warnings };
    }
    
    // Check if fields exist in the table schema
    const tableFields = this.tableSchemas.get(tableName)!;
    
    for (const field of fields) {
      // Skip JSON property access
      if (field.includes('->')) continue;
      
      // Skip aliased fields
      if (field.includes(':')) continue;
      
      if (!tableFields.includes(field)) {
        warnings.push(`Unknown field in table ${tableName}: ${field}`);
      }
    }
    
    return {
      valid: warnings.length === 0,
      warnings
    };
  }
  
  /**
   * Generate a consistent cache key for a query
   */
  generateQueryCacheKey(tableName: string, query: Record<string, any>): string {
    // Normalize the query object
    const normalizedQuery = Object.entries(query)
      .sort(([keyA], [keyB]) => keyA.localeCompare(keyB))
      .map(([key, value]) => `${key}=${JSON.stringify(value)}`)
      .join('&');
      
    return `${tableName}:${hashString(normalizedQuery)}`;
  }
  
  /**
   * Report query statistics
   */
  private reportQueryStats() {
    console.log('\n[QueryMonitor] Query Performance Report:');
    console.log('----------------------------------------');
    
    const sortedQueries = [...this.queryStats.entries()]
      .sort((a, b) => b[1].totalTime - a[1].totalTime)
      .slice(0, 10); // Top 10 slowest queries
      
    if (sortedQueries.length === 0) {
      console.log('No queries monitored yet');
      return;
    }
    
    for (const [queryName, stats] of sortedQueries) {
      const avgTime = stats.totalTime / stats.count;
      const successRate = stats.count > 0 ? (stats.succeeded / stats.count * 100).toFixed(1) : '0.0';
      
      console.log(`Query: ${queryName}`);
      console.log(`  Count: ${stats.count}, Avg: ${avgTime.toFixed(2)}ms, Max: ${stats.maxTime.toFixed(2)}ms`);
      console.log(`  Success Rate: ${successRate}%, Last Run: ${new Date(stats.lastRun).toLocaleTimeString()}`);
      
      if (avgTime > 500) { // Slow query threshold
        console.log(`  ⚠️ This query is consistently slow. Consider optimization.`);
      }
    }
    
    console.log('----------------------------------------\n');
  }
  
  /**
   * Get query performance statistics
   */
  getQueryStats(): Array<{
    queryName: string;
    count: number;
    avgTime: number;
    maxTime: number;
    successRate: string;
    lastRun: string;
  }> {
    return [...this.queryStats.entries()].map(([queryName, stats]) => ({
      queryName,
      count: stats.count,
      avgTime: stats.totalTime / stats.count,
      maxTime: stats.maxTime,
      successRate: stats.count > 0 ? (stats.succeeded / stats.count * 100).toFixed(1) : '0.0',
      lastRun: new Date(stats.lastRun).toLocaleString()
    }));
  }
  
  /**
   * Get optimization recommendations based on query patterns
   */
  getOptimizationRecommendations(): string[] {
    const recommendations: string[] = [];
    
    // Analyze query patterns and suggest optimizations
    for (const [queryName, stats] of this.queryStats.entries()) {
      const avgTime = stats.totalTime / stats.count;
      
      if (avgTime > 500 && stats.count > 5) {
        if (queryName.includes('SELECT') && queryName.includes('WHERE')) {
          recommendations.push(`Consider adding an index for frequent query: ${queryName}`);
        }
        
        if (queryName.includes('JOIN')) {
          recommendations.push(`Review join operation for optimization: ${queryName}`);
        }
      }
    }
    
    // Add general recommendations
    recommendations.push("Consider using PostgreSQL EXPLAIN ANALYZE to identify slow queries");
    recommendations.push("Review indexes on frequently queried columns");
    recommendations.push("Consider adding caching for frequent read operations");
    
    return recommendations;
  }
}

// Export a singleton instance
export const queryMonitorService = new QueryMonitorService();

/**
 * Higher-order function to easily monitor queries
 * @param queryName Name to identify the query
 * @param fn The query function
 */
export const monitoredQuery = <T>(queryName: string, fn: () => Promise<T>): Promise<T> => {
  return queryMonitorService.monitorQuery(queryName, fn);
};