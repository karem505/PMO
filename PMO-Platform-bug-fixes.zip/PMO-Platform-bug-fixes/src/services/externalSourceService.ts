import { supabase } from './supabaseClient';
import pLimit from 'p-limit';
import pRetry from 'p-retry';

// Types for external sources and validation
export interface ExternalSource {
  id: string;
  name: string;
  url: string;
  description: string;
  category: string;
  trustScore: number;
  lastUpdated: string;
}

export interface SourceValidationResult {
  isValid: boolean;
  confidence: number;
  sourcesUsed: {
    name: string;
    url: string;
    relevance: number;
    snippet?: string;
  }[];
  validationDate: string;
  suggestedCorrections?: {
    original: string;
    correction: string;
    explanation: string;
  }[];
}

/**
 * Service for crawling external sources and validating AI outputs
 */
class ExternalSourceService {
  private sources: ExternalSource[] = [];
  private sourcesLoaded = false;
  private sourcesCache = new Map<string, any>();
  private validationCache = new Map<string, SourceValidationResult>();
  
  // Concurrency control
  private crawlLimiter = pLimit(2); // Max 2 concurrent crawls
  private requestLimiter = pLimit(5); // Max 5 concurrent requests
  
  // Edge function names
  private crawlFunction = 'crawl-external-source';
  private validateFunction = 'validate-content';
  
  constructor() {
    // Load trusted sources on init
    this.loadSources();
  }
  
  /**
   * Load trusted sources from Supabase or fallback to default sources
   */
  private async loadSources() {
    try {
      // Try to load from Supabase first
      const { data, error } = await supabase
        .from('external_sources')
        .select('*')
        .eq('is_active', true);
        
      if (error) throw error;
      
      if (data && data.length > 0) {
        this.sources = data.map(source => ({
          id: source.id,
          name: source.name,
          url: source.url,
          description: source.description,
          category: source.category,
          trustScore: source.trust_score,
          lastUpdated: source.last_updated
        }));
      } else {
        // Fallback to default sources
        this.loadDefaultSources();
      }
      
      this.sourcesLoaded = true;
      console.log(`Loaded ${this.sources.length} external sources`);
    } catch (error) {
      console.error('Error loading external sources:', error);
      // Fallback to default sources
      this.loadDefaultSources();
    }
  }
  
  /**
   * Load default trusted sources when Supabase is unavailable
   */
  private loadDefaultSources() {
    this.sources = [
      {
        id: '1',
        name: 'Project Management Institute (PMI)',
        url: 'https://www.pmi.org',
        description: 'Global authority on project management standards and practices',
        category: 'professional-organization',
        trustScore: 0.9,
        lastUpdated: new Date().toISOString()
      },
      {
        id: '2',
        name: 'Harvard Business Review',
        url: 'https://hbr.org/topic/project-management',
        description: 'Academic articles on project management and PMO practices',
        category: 'academic',
        trustScore: 0.85,
        lastUpdated: new Date().toISOString()
      },
      {
        id: '3',
        name: 'McKinsey & Company',
        url: 'https://www.mckinsey.com/capabilities/operations/our-insights',
        description: 'Industry insights on organizational effectiveness and PMOs',
        category: 'consulting',
        trustScore: 0.8,
        lastUpdated: new Date().toISOString()
      },
      {
        id: '4',
        name: 'Gartner',
        url: 'https://www.gartner.com/en/project-portfolio-management',
        description: 'Research and advisory on project and portfolio management',
        category: 'research',
        trustScore: 0.87,
        lastUpdated: new Date().toISOString()
      },
      {
        id: '5',
        name: 'ProjectManagement.com',
        url: 'https://www.projectmanagement.com/contentCategories/pmo--c-9',
        description: 'PMO resources, templates and articles from practitioners',
        category: 'practitioner',
        trustScore: 0.75,
        lastUpdated: new Date().toISOString()
      }
    ];
    
    this.sourcesLoaded = true;
  }
  
  /**
   * Get list of available trusted sources
   */
  async getSources(): Promise<ExternalSource[]> {
    if (!this.sourcesLoaded) {
      await this.loadSources();
    }
    return this.sources;
  }
  
  /**
   * Crawl external sources related to a specific domain/topic
   * Uses Edge Function to handle CORS and avoid browser limitations
   */
  async crawlExternalSources(
    topic: string, 
    options: {
      maxSources?: number;
      freshness?: 'any' | 'recent' | 'very-recent';
      minTrustScore?: number;
    } = {}
  ): Promise<{
    sources: {
      name: string;
      url: string;
      content: string;
      relevance: number;
    }[];
    error?: string;
  }> {
    // Default options
    const {
      maxSources = 3,
      freshness = 'any',
      minTrustScore = 0.7
    } = options;
    
    // Generate cache key
    const cacheKey = `crawl:${topic}:${maxSources}:${freshness}:${minTrustScore}`;
    
    // Check cache first
    if (this.sourcesCache.has(cacheKey)) {
      return this.sourcesCache.get(cacheKey);
    }
    
    try {
      // Ensure sources are loaded
      if (!this.sourcesLoaded) {
        await this.loadSources();
      }
      
      // Filter sources by trust score
      const filteredSources = this.sources
        .filter(source => source.trustScore >= minTrustScore)
        .sort((a, b) => b.trustScore - a.trustScore)
        .slice(0, maxSources);
      
      if (filteredSources.length === 0) {
        return { sources: [], error: 'No suitable sources found' };
      }
      
      // Crawl function available - use Supabase Edge Function
      try {
        console.log(`Crawling ${filteredSources.length} external sources for topic: ${topic}`);
        
        // Call the edge function to crawl external sources
        const { data, error } = await supabase.functions.invoke(this.crawlFunction, {
          body: {
            topic,
            sources: filteredSources.map(s => ({ name: s.name, url: s.url })),
            options: { freshness }
          }
        });
        
        if (error) throw error;
        
        // Cache the result
        this.sourcesCache.set(cacheKey, data);
        
        return data;
      } catch (error) {
        console.error('Error calling crawl edge function:', error);
        
        // Return mock data if in development mode
        if (import.meta.env.DEV) {
          return this.getMockCrawlResults(topic, filteredSources);
        }
        
        return { 
          sources: [], 
          error: 'Failed to crawl external sources'
        };
      }
    } catch (error) {
      console.error('Error in crawlExternalSources:', error);
      
      // Mock data for development and testing
      if (import.meta.env.DEV) {
        const mockResult = this.getMockCrawlResults(topic, this.sources.slice(0, maxSources));
        this.sourcesCache.set(cacheKey, mockResult);
        return mockResult;
      }
      
      return { 
        sources: [], 
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }
  
  /**
   * Validate AI-generated content against external sources
   * Returns validation results and confidence score
   */
  async validateContent(
    content: string,
    domain: string,
    options: {
      strictness?: 'low' | 'medium' | 'high';
      includeCorrections?: boolean;
    } = {}
  ): Promise<SourceValidationResult> {
    // Default options
    const {
      strictness = 'medium',
      includeCorrections = true
    } = options;
    
    // Generate cache key for this validation request
    const contentHash = this.hashString(content.substring(0, 500));
    const cacheKey = `validate:${contentHash}:${domain}:${strictness}`;
    
    // Check cache first
    if (this.validationCache.has(cacheKey)) {
      return this.validationCache.get(cacheKey)!;
    }
    
    try {
      // Call the validation edge function
      const { data, error } = await supabase.functions.invoke(this.validateFunction, {
        body: {
          content,
          domain,
          options: { strictness, includeCorrections }
        }
      });
      
      if (error) throw error;
      
      // Cache the result
      this.validationCache.set(cacheKey, data);
      
      return data;
    } catch (error) {
      console.error('Error validating content:', error);
      
      // Return mock validation in development mode
      if (import.meta.env.DEV) {
        const mockResult = this.getMockValidationResult(content, domain, strictness);
        this.validationCache.set(cacheKey, mockResult);
        return mockResult;
      }
      
      // Return a default "unable to validate" result
      return {
        isValid: true, // Default to true to avoid blocking the user
        confidence: 0.5,
        sourcesUsed: [],
        validationDate: new Date().toISOString(),
        suggestedCorrections: []
      };
    }
  }
  
  /**
   * Get information about a specific external source
   */
  async getSourceDetails(sourceId: string): Promise<ExternalSource | null> {
    if (!this.sourcesLoaded) {
      await this.loadSources();
    }
    
    return this.sources.find(s => s.id === sourceId) || null;
  }
  
  /**
   * Add a custom source for validation (admin feature)
   */
  async addCustomSource(source: Omit<ExternalSource, 'id' | 'lastUpdated'>): Promise<ExternalSource | null> {
    try {
      const newSource: ExternalSource = {
        ...source,
        id: crypto.randomUUID(),
        lastUpdated: new Date().toISOString()
      };
      
      // Add to Supabase if possible
      const { data, error } = await supabase
        .from('external_sources')
        .insert({
          name: newSource.name,
          url: newSource.url,
          description: newSource.description,
          category: newSource.category,
          trust_score: newSource.trustScore,
          is_active: true
        })
        .select()
        .single();
        
      if (error) throw error;
      
      // Update local sources
      if (data) {
        const formattedSource: ExternalSource = {
          id: data.id,
          name: data.name,
          url: data.url,
          description: data.description,
          category: data.category,
          trustScore: data.trust_score,
          lastUpdated: data.last_updated
        };
        
        this.sources.push(formattedSource);
        return formattedSource;
      }
      
      return null;
    } catch (error) {
      console.error('Error adding custom source:', error);
      return null;
    }
  }
  
  /**
   * Generate mock crawl results for development
   */
  private getMockCrawlResults(
    topic: string, 
    sources: ExternalSource[]
  ): { 
    sources: { name: string; url: string; content: string; relevance: number; }[]; 
  } {
    const results = sources.map((source, index) => {
      // Generate mock relevance score weighted by trust score
      const baseRelevance = 0.5 + (Math.random() * 0.4);
      const relevance = baseRelevance * source.trustScore;
      
      return {
        name: source.name,
        url: source.url,
        content: this.generateMockContent(topic, source.category),
        relevance: parseFloat(relevance.toFixed(2))
      };
    });
    
    // Sort by relevance
    return {
      sources: results.sort((a, b) => b.relevance - a.relevance)
    };
  }
  
  /**
   * Generate mock content for testing
   */
  private generateMockContent(topic: string, category: string): string {
    // Normalize topic to remove special chars
    const normalizedTopic = topic.toLowerCase().replace(/[^\w\s]/g, '');
    
    // Pick mock content based on category
    if (category === 'professional-organization') {
      return `According to PMI standards and best practices, establishing a PMO for ${normalizedTopic} requires careful consideration of organizational context and maturity level. The PMI PMBOK® Guide recommends starting with a clear charter and governance framework. Recent studies have shown that successful PMOs align closely with strategic objectives and demonstrate value through measurable KPIs.`;
    }
    
    if (category === 'academic') {
      return `Recent academic research on ${normalizedTopic} suggests that PMOs should focus on creating value rather than enforcing processes. A 2023 Harvard Business Review study found that adaptive PMO structures outperform rigid ones by 27%. Additionally, PMOs that foster knowledge sharing across the organization show higher success rates in project outcomes.`;
    }
    
    if (category === 'consulting') {
      return `Our analysis of industry trends related to ${normalizedTopic} indicates that leading organizations are transitioning to value-driven PMO models. The most successful implementations begin with stakeholder analysis and clear definition of success metrics. Furthermore, iterative implementation approaches yield better adoption rates compared to big-bang rollouts.`;
    }
    
    if (category === 'research') {
      return `Gartner research shows that by 2025, 80% of successful PMOs will shift from process enforcement to strategic enablement for ${normalizedTopic}. Organizations should consider a phased maturity roadmap and focus on building the right capabilities before scaling. Strategic alignment remains the number one success factor according to our latest survey.`;
    }
    
    // Default/practitioner content
    return `Practical experience with ${normalizedTopic} suggests that focus on quick wins is critical for initial PMO acceptance. Templates should be adapted to organizational culture rather than forced standardization. Consider starting with a small set of services and expand gradually based on demonstrated value. Communication strategy is often overlooked but crucial for successful implementation.`;
  }
  
  /**
   * Generate mock validation results for testing
   */
  private getMockValidationResult(
    content: string,
    domain: string,
    strictness: 'low' | 'medium' | 'high'
  ): SourceValidationResult {
    // Simulate different validation results based on strictness
    const confidenceByStrictness = {
      low: 0.85,
      medium: 0.75,
      high: 0.65
    };
    
    // Base confidence on strictness (stricter = lower confidence)
    const baseConfidence = confidenceByStrictness[strictness];
    
    // Randomize slightly for realistic variation
    const confidence = baseConfidence - 0.1 + (Math.random() * 0.2);
    
    // Mock sources used for validation
    const sourcesUsed = this.sources
      .slice(0, 2 + Math.floor(Math.random() * 2)) // Use 2-3 sources
      .map(source => ({
        name: source.name,
        url: source.url,
        relevance: 0.5 + (Math.random() * 0.4)
      }));
    
    // Less than 10% chance of validation issues for testing
    const hasIssues = Math.random() < 0.1;
    
    // Generate mock validation result
    return {
      isValid: !hasIssues,
      confidence: parseFloat(confidence.toFixed(2)),
      sourcesUsed,
      validationDate: new Date().toISOString(),
      suggestedCorrections: hasIssues ? [
        {
          original: `implementing a PMO for ${domain}`,
          correction: `implementing a structured PMO for ${domain} with clear governance`,
          explanation: 'Research suggests adding governance framework is essential for success'
        }
      ] : []
    };
  }
  
  /**
   * Simple string hashing function
   */
  private hashString(str: string): string {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32bit integer
    }
    return Math.abs(hash).toString(36);
  }
}

// Export singleton instance
export const externalSourceService = new ExternalSourceService();