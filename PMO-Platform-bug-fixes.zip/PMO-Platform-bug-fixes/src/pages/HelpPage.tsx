import React, { Suspense, useEffect } from 'react';
import { HelpCircle, BookOpen, MessageCircle, FileText } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import ErrorBoundary from '../components/common/ErrorBoundary';
import LoadingSpinner from '../components/common/LoadingSpinner';

const HelpPage: React.FC = () => {
  const { t } = useLanguage();

  // Add safety check for DOM operations
  useEffect(() => {
    // Fix for "Cannot read properties of null (reading 'nodeName')" error
    const originalGetElementById = document.getElementById;
    
    // Safely override getElementById to provide null checks
    document.getElementById = function(id) {
      const element = originalGetElementById.call(document, id);
      return element; // Simply return the element - null checks happen in component code
    };
    
    return () => {
      // Restore original method when component unmounts
      document.getElementById = originalGetElementById;
    };
  }, []);

  return (
    <ErrorBoundary>
      <Suspense fallback={<LoadingSpinner fullScreen text="Loading help content..." />}>
        <div className="max-w-3xl mx-auto">
          <div className="flex items-center mb-6">
            <div>
              <h1 className="text-2xl font-bold text-neutral-600 hover:text-neutral-800">
                {t('help.title')}
              </h1>
              <p className="text-gray-600 dark:text-gray-300 mt-1">
                {t('help.description')}
              </p>
            </div>
          </div>
          
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                <HelpCircle className="h-5 w-5 me-2 text-blue-600" />
                {t('help.gettingStarted')}
              </h2>
              
              <div className="space-y-4">
                <div>
                  <h3 className="font-medium text-gray-800">
                    {t('help.whatIsPmoDomainsTool')}
                  </h3>
                  <p className="text-sm text-gray-600 mt-1">
                    {t('help.whatIsPmoDomainsToolDescription')}
                  </p>
                </div>
                
                <div>
                  <h3 className="font-medium text-gray-800">
                    {t('help.howToUseThisTool')}
                  </h3>
                  <ol className="mt-1 space-y-2 text-sm text-gray-600 list-decimal list-inside">
                    <li>
                      {t('help.startBySettingUpYourOrganizationProfile')}
                    </li>
                    <li>
                      {t('help.navigateToEachDomainUsingTheSidebarMenu')}
                    </li>
                    <li>
                      {t('help.completeTasksInTheRecommendedOrder')}
                    </li>
                    <li>
                      {t('help.markTasksAsCompleteAsYouProgress')}
                    </li>
                    <li>
                      {t('help.useTheDashboardToTrackYourOverallProgress')}
                    </li>
                    <li>
                      {t('help.referToTheBestPracticesLibraryForGuidance')}
                    </li>
                  </ol>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                <BookOpen className="h-5 w-5 me-2 text-blue-600" />
                {t('help.understandingTheFiveDomains')}
              </h2>
              
              <div className="space-y-4">
                <div>
                  <h3 className="font-medium text-gray-800">
                    {t('help.organizationalDevelopmentAndAlignment')}
                  </h3>
                  <p className="text-sm text-gray-600 mt-1">
                    {t('help.organizationalDevelopmentAndAlignmentDescription')}
                  </p>
                </div>
                
                <div>
                  <h3 className="font-medium text-gray-800">
                    {t('help.strategicElementsOfThePmo')}
                  </h3>
                  <p className="text-sm text-gray-600 mt-1">
                    {t('help.strategicElementsOfThePmoDescription')}
                  </p>
                </div>
                
                <div>
                  <h3 className="font-medium text-gray-800">
                    {t('help.pMODesignAndStructuring')}
                  </h3>
                  <p className="text-sm text-gray-600 mt-1">
                    {t('help.pMODesignAndStructuringDescription')}
                  </p>
                </div>
                
                <div>
                  <h3 className="font-medium text-gray-800">
                    {t('help.pMOOperationAndPerformance')}
                  </h3>
                  <p className="text-sm text-gray-600 mt-1">
                    {t('help.pMOOperationAndPerformanceDescription')}
                  </p>
                </div>
                
                <div>
                  <h3 className="font-medium text-gray-800">
                    {t('help.pMOEnhancementAndEffectiveness')}
                  </h3>
                  <p className="text-sm text-gray-600 mt-1">
                    {t('help.pMOEnhancementAndEffectivenessDescription')}
                  </p>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                <FileText className="h-5 w-5 me-2 text-blue-600" />
                {t('help.frequentlyAskedQuestions')}
              </h2>
              
              <div className="space-y-4">
                <div>
                  <h3 className="font-medium text-gray-800">
                    {t('help.canIExportMyData')}
                  </h3>
                  <p className="text-sm text-gray-600 mt-1">
                    {t('help.canIExportMyDataDescription')}
                  </p>
                </div>
                
                <div>
                  <h3 className="font-medium text-gray-800">
                    {t('help.howToAccessTemplates')}
                  </h3>
                  <p className="text-sm text-gray-600 mt-1">
                    {t('help.howToAccessTemplatesDescription')}
                  </p>
                </div>
                
                <div>
                  <h3 className="font-medium text-gray-800">
                    {t('help.canICustomizeTheToolForMyOrganization')}
                  </h3>
                  <p className="text-sm text-gray-600 mt-1">
                    {t('help.canICustomizeTheToolForMyOrganizationDescription')}
                  </p>
                </div>
                
                <div>
                  <h3 className="font-medium text-gray-800">
                    {t('help.whatIfINotReadyToCompleteAllDomains')}
                  </h3>
                  <p className="text-sm text-gray-600 mt-1">
                    {t('help.whatIfINotReadyToCompleteAllDomainsDescription')}
                  </p>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                <MessageCircle className="h-5 w-5 me-2 text-blue-600" />
                {t('help.contactSupport')}
              </h2>
              
              <p className="text-sm text-gray-600">
                {t('help.contactSupportDescription')}
              </p>
              
              <div className="mt-4 p-4 bg-gray-50 rounded-md">
                <h3 className="font-medium text-gray-800">
                  {t('help.supportContact')}
                </h3>
                <p className="text-sm text-gray-600 mt-1">
                  {t('help.supportContactEmail')}
                </p>
                <p className="text-sm text-gray-600">
                  {t('help.supportContactPhone')}
                </p>
                <p className="text-sm text-gray-600">
                  {t('help.supportContactHours')}
                </p>
              </div>
            </div>
          </div>
        </div>
      </Suspense>
    </ErrorBoundary>
  );
};

export default HelpPage;