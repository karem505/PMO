import React from 'react';
import { ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import SupabaseConnectionTest from '../components/SupabaseConnectionTest';

const SupabaseTestPage: React.FC = () => {
  const navigate = useNavigate();
  
  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center mb-6">
        <button
          onClick={() => navigate('/')}
          className="mr-3 text-gray-600 hover:text-gray-800"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-2xl font-bold  text-gray-800">Supabase Connection Test</h1>
      </div>
      
      <SupabaseConnectionTest />
      
      <div className="mt-8 p-4 bg-blue-50 border border-blue-200 rounded-lg">
        <h2 className="font-medium text-blue-800 mb-2">About Supabase Connection Issues</h2>
        <p className="text-blue-700 text-sm mb-3">
          If you're experiencing "refused to connect" errors with Supabase, there are several potential causes:
        </p>
        <ul className="text-sm text-blue-700 space-y-2 list-disc list-inside">
          <li>The Supabase service might be temporarily unavailable</li>
          <li>Network connectivity issues or firewall restrictions</li>
          <li>CORS policy restrictions (if your app is running on a different domain)</li>
          <li>The Supabase project might be in a "paused" state if it's not been used recently</li>
          <li>The API keys or project URL might be incorrect</li>
        </ul>
      </div>
    </div>
  );
};

export default SupabaseTestPage;