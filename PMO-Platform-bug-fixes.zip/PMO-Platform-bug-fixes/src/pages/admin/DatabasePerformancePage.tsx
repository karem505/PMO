import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Database, Zap, Search, AlertCircle, Table2, ChevronsUpDown, Shield, CheckCircle, Loader2 } from 'lucide-react';
import { queryMonitorService } from '../../services/queryMonitorService';
import { dbIndexOptimizerService } from '../../services/dbIndexOptimizerService';
import { dbOptimizationService } from '../../services/databaseOptimizationService';
import { useAuth } from '../../components/auth/AuthContext';

const DatabasePerformancePage: React.FC = () => {
  const navigate = useNavigate();
  const { hasRole } = useAuth();
  
  const [queryStats, setQueryStats] = useState<any[]>([]);
  const [indexRecommendations, setIndexRecommendations] = useState<string[]>([]);
  const [schemaRecommendations, setSchemaRecommendations] = useState<string[]>([]);
  const [indexSqlStatements, setIndexSqlStatements] = useState<string[]>([]);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [sortedBy, setSortedBy] = useState<string>('avgTime');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  const [cacheStats, setCacheStats] = useState<any>(null);
  
  // Check if current user has admin role
  useEffect(() => {
    if (!hasRole('admin')) {
      navigate('/');
    }
  }, [hasRole, navigate]);
  
  // Load data on initial mount
  useEffect(() => {
    refreshData();
  }, []);
  
  const refreshData = () => {
    setIsRefreshing(true);
    
    try {
      // Get query statistics
      const stats = queryMonitorService.getQueryStats();
      setQueryStats(stats);
      
      // Get cache statistics
      const perfMetrics = dbOptimizationService.getPerformanceMetrics();
      setCacheStats(perfMetrics.cacheStats);
      
      // Get optimization recommendations
      setIndexRecommendations(dbIndexOptimizerService.getIndexRecommendations());
      setSchemaRecommendations(dbIndexOptimizerService.generateSchemaImprovements());
      setIndexSqlStatements(dbIndexOptimizerService.generateIndexCreationStatements());
    } catch (error) {
      console.error('Error refreshing database performance data:', error);
    } finally {
      setIsRefreshing(false);
    }
  };
  
  const handleSort = (column: string) => {
    if (sortedBy === column) {
      // Toggle direction if already sorting by this column
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      // Default to descending for new column
      setSortedBy(column);
      setSortDirection('desc');
    }
  };
  
  const sortedStats = [...queryStats].sort((a, b) => {
    const aValue = a[sortedBy];
    const bValue = b[sortedBy];
    
    // Handle string values
    if (typeof aValue === 'string' && typeof bValue === 'string') {
      return sortDirection === 'asc' 
        ? aValue.localeCompare(bValue)
        : bValue.localeCompare(aValue);
    }
    
    // Handle numeric values
    return sortDirection === 'asc' ? aValue - bValue : bValue - aValue;
  });

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <button
            onClick={() => navigate('/admin')}
            className="mr-3 text-gray-600 hover:text-gray-800"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold  text-neutral-800 flex items-center">
              <Database className="mr-2 text-primary-600 h-6 w-6" />
              Database Performance
            </h1>
            <p className="text-neutral-600 mt-1">
              Monitor and optimize database queries and schema
            </p>
          </div>
        </div>
        <button
          onClick={refreshData}
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center"
          disabled={isRefreshing}
        >
          {isRefreshing ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Refreshing...
            </>
          ) : (
            <>
              <Zap className="mr-2 h-4 w-4" />
              Refresh Stats
            </>
          )}
        </button>
      </div>
      
      {/* Query Performance Stats */}
      <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
        <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
          <Search className="mr-2 h-5 w-5 text-blue-600" />
          Query Performance Statistics
        </h2>
        
        {queryStats.length === 0 ? (
          <div className="text-center py-8 bg-gray-50 rounded-lg border border-gray-200">
            <AlertCircle className="mx-auto h-10 w-10 text-gray-400 mb-3" />
            <p className="text-gray-600">No query statistics available yet.</p>
            <p className="text-gray-500 text-sm mt-2">Statistics will appear as queries are executed.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('queryName')}
                  >
                    <div className="flex items-center">
                      Query
                      {sortedBy === 'queryName' && (
                        <ChevronsUpDown className="ml-1 h-4 w-4" />
                      )}
                    </div>
                  </th>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('count')}
                  >
                    <div className="flex items-center">
                      Count
                      {sortedBy === 'count' && (
                        <ChevronsUpDown className="ml-1 h-4 w-4" />
                      )}
                    </div>
                  </th>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('avgTime')}
                  >
                    <div className="flex items-center">
                      Avg Time (ms)
                      {sortedBy === 'avgTime' && (
                        <ChevronsUpDown className="ml-1 h-4 w-4" />
                      )}
                    </div>
                  </th>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('maxTime')}
                  >
                    <div className="flex items-center">
                      Max Time (ms)
                      {sortedBy === 'maxTime' && (
                        <ChevronsUpDown className="ml-1 h-4 w-4" />
                      )}
                    </div>
                  </th>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('successRate')}
                  >
                    <div className="flex items-center">
                      Success Rate
                      {sortedBy === 'successRate' && (
                        <ChevronsUpDown className="ml-1 h-4 w-4" />
                      )}
                    </div>
                  </th>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    Status
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {sortedStats.map((stat, index) => (
                  <tr key={index}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {stat.queryName}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {stat.count}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {stat.avgTime.toFixed(2)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {stat.maxTime.toFixed(2)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {stat.successRate}%
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">
                      {stat.avgTime > 1000 ? (
                        <span className="px-2 py-1 text-xs rounded-full bg-red-100 text-red-800">
                          Very Slow
                        </span>
                      ) : stat.avgTime > 500 ? (
                        <span className="px-2 py-1 text-xs rounded-full bg-yellow-100 text-yellow-800">
                          Slow
                        </span>
                      ) : (
                        <span className="px-2 py-1 text-xs rounded-full bg-green-100 text-green-800">
                          Good
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
      
      {/* Cache Statistics */}
      {cacheStats && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h3 className="font-medium text-gray-800 mb-2">Cache Hit Rate</h3>
            <p className="text-3xl font-bold text-primary-600">{cacheStats.hitRate}</p>
            <p className="text-sm text-gray-500 mt-1">Percentage of queries served from cache</p>
          </div>
          
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h3 className="font-medium text-gray-800 mb-2">Cache Size</h3>
            <p className="text-3xl font-bold text-primary-600">{cacheStats.cacheSize}</p>
            <p className="text-sm text-gray-500 mt-1">Number of items in cache</p>
          </div>
          
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h3 className="font-medium text-gray-800 mb-2">Cache Status</h3>
            <div className="flex items-center">
              <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div 
                  className="bg-primary-600 h-2.5 rounded-full" 
                  style={{ width: cacheStats.hitRate }}
                ></div>
              </div>
              <span className="ml-3 text-sm font-medium">
                {parseInt(cacheStats.hitRate) > 70 ? 'Excellent' : 
                 parseInt(cacheStats.hitRate) > 50 ? 'Good' : 
                 'Needs Improvement'}
              </span>
            </div>
            <div className="mt-4 flex items-center justify-between text-sm text-gray-500">
              <span>Hits: {cacheStats.hits}</span>
              <span>Misses: {cacheStats.misses}</span>
            </div>
          </div>
        </div>
      )}
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Optimization Recommendations */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
            <Zap className="mr-2 h-5 w-5 text-amber-600" />
            Optimization Recommendations
          </h2>
          
          {indexRecommendations.length > 0 ? (
            <div className="space-y-3">
              {indexRecommendations.map((recommendation, index) => (
                <div key={index} className="p-3 bg-amber-50 rounded-lg border border-amber-100">
                  <p className="text-sm text-amber-800">{recommendation}</p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-600">No specific recommendations at this time.</p>
          )}
          
          <h3 className="font-medium text-gray-800 mt-6 mb-3">Index Creation SQL</h3>
          {indexSqlStatements.length > 0 ? (
            <pre className="bg-gray-50 p-3 rounded-lg text-sm overflow-x-auto border border-gray-200">
              {indexSqlStatements.join('\n\n')}
            </pre>
          ) : (
            <p className="text-gray-600">No index SQL statements generated yet.</p>
          )}
        </div>
        
        {/* Schema Recommendations */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
            <Table2 className="mr-2 h-5 w-5 text-green-600" />
            Schema Improvements
          </h2>
          
          {schemaRecommendations.length > 0 ? (
            <div className="space-y-3">
              {schemaRecommendations.map((recommendation, index) => (
                <div key={index} className="p-3 bg-green-50 rounded-lg border border-green-100">
                  <p className="text-sm text-green-800">{recommendation}</p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-600">No schema improvements recommended at this time.</p>
          )}
          
          <div className="mt-6 p-4 bg-gray-50 rounded-lg border border-gray-200">
            <h3 className="font-medium text-gray-800 mb-2 flex items-center">
              <Shield className="mr-2 h-4 w-4 text-blue-600" />
              Schema Validation Status
            </h3>
            <div className="flex items-start">
              <CheckCircle className="text-green-500 h-5 w-5 mt-0.5 mr-2" />
              <div>
                <p className="text-sm font-medium text-gray-800">Schema validation is active</p>
                <p className="text-sm text-gray-600 mt-1">
                  All database operations are being validated against their schemas before execution.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DatabasePerformancePage;