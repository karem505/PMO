import React, { useState, useEffect, useCallback, Suspense } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppStore } from '../store';
import { domains } from '../data';
import { ArrowLeft, BarChart as ChartBar, Clipboard, Layers, Download, Save, Check, Clock, Sparkles, ExternalLink, ArrowRight, AlertTriangle } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { MaturityLevel, Domain } from '../types';
import MaturityRadarChart from '../components/MaturityRadarChart';
import MaturityLevelDescriptions from '../components/maturity/MaturityLevelDescriptions';
import RecommendationsList from '../components/maturity/RecommendationsList';
import { documentService } from '../services';
import { maturityAssessmentService } from '../services/maturityAssessmentService';
import MaturityProgressTracker from '../components/maturity/MaturityProgressTracker';
import { exportToPdf } from '../utils/exportUtils';
import ErrorBoundary from '../components/common/ErrorBoundary';
import LoadingSpinner from '../components/common/LoadingSpinner';
import { toast } from 'react-hot-toast';

// Define local interface for domain input
interface DomainInput {
  domain: Domain;
  input: string;
}

const maturityLevels: MaturityLevel[] = [
  { value: 'initial', label: 'Initial', description: 'Processes are ad hoc and chaotic.' },
  { value: 'defined', label: 'Defined', description: 'Processes are documented and standardized.' },
  { value: 'managed', label: 'Managed', description: 'Processes are measured and controlled.' },
  { value: 'optimized', label: 'Optimized', description: 'Focus on continuous improvement.' },
  { value: 'innovative', label: 'Innovative', description: 'Driving industry innovation and adaptation.' }
];

const MaturityAssessmentPage: React.FC = () => {
  const navigate = useNavigate();
  const { t, isRTL } = useLanguage();
  const { userData, getProjects, getActiveProject, updateUserProfile, processedDocuments } = useAppStore();
  
  const [assessmentType, setAssessmentType] = useState<'manual' | 'ai'>('manual');
  const [isGeneratingAssessment, setIsGeneratingAssessment] = useState(false);
  const [assessmentComplete, setAssessmentComplete] = useState(false);
  const [exportingReport, setExportingReport] = useState(false);
  const [generationError, setGenerationError] = useState<string | null>(null);
  
  // Self-assessment values
  const [selfAssessment, setSelfAssessment] = useState<Record<number, string>>({});
  const [notes, setNotes] = useState<Record<number, string>>({});
  
  // AI-generated assessment
  const [aiAssessment, setAiAssessment] = useState<{
    overallMaturity: string;
    domainMaturity: Record<number, string>;
    strengths: string[];
    weaknesses: string[];
    recommendations: string[];
    report: string;
  } | null>(null);
  
  // Historical snapshots (for progress tracking)
  const [maturityHistory, setMaturityHistory] = useState<{
    date: string;
    overall: string;
    domains: Record<number, string>;
  }[]>([]);
  
  const [refreshKey, setRefreshKey] = useState(0);
  
  const activeProject = getActiveProject();
  const allProjects = getProjects();
  
  useEffect(() => {
    // Fetch historical snapshots
    const fetchHistory = async () => {
      // This would typically come from the database
      // For demo purposes, we'll create some mock data
      setMaturityHistory([
        {
          date: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
          overall: 'initial',
          domains: {
            1: 'initial',
            2: 'initial',
            3: 'initial',
            4: 'initial',
            5: 'initial',
            6: 'initial'
          }
        },
        {
          date: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
          overall: 'defined',
          domains: {
            1: 'defined',
            2: 'initial',
            3: 'defined',
            4: 'initial',
            5: 'initial',
            6: 'initial'
          }
        },
        {
          date: new Date().toISOString().split('T')[0],
          overall: userData?.pmoMaturityLevel?.toLowerCase() || 'initial',
          domains: domains.reduce((acc, domain) => {
            acc[domain.id] = selfAssessment[domain.id] || userData?.pmoMaturityLevel?.toLowerCase() || 'initial';
            return acc;
          }, {} as Record<number, string>)
        }
      ]);
    };
    
    fetchHistory();
    
    // Initialize self-assessment with current PMO maturity level
    const initialAssessment: Record<number, string> = {};
    domains.forEach(domain => {
      initialAssessment[domain.id] = userData?.pmoMaturityLevel?.toLowerCase() || 'initial';
    });
    setSelfAssessment(initialAssessment);
    
  }, [userData?.pmoMaturityLevel]);
  
  const handleSelfAssessmentChange = (domainId: number, value: string) => {
    setSelfAssessment(prev => ({
      ...prev,
      [domainId]: value
    }));
  };
  
  const handleNotesChange = (domainId: number, value: string) => {
    setNotes(prev => ({
      ...prev,
      [domainId]: value
    }));
  };
  
  const getOverallMaturityLevel = (): string => {
    if (Object.keys(selfAssessment).length === 0) return userData?.pmoMaturityLevel?.toLowerCase() || 'initial';
    
    const maturityValues = Object.values(selfAssessment);
    
    // Count the frequency of each maturity level
    const frequencyMap: Record<string, number> = {};
    maturityValues.forEach(value => {
      frequencyMap[value] = (frequencyMap[value] || 0) + 1;
    });
    
    // Find the most frequent level
    let mostFrequentLevel = '';
    let highestFrequency = 0;
    
    Object.entries(frequencyMap).forEach(([level, frequency]) => {
      if (frequency > highestFrequency) {
        mostFrequentLevel = level;
        highestFrequency = frequency;
      }
    });
    
    return mostFrequentLevel;
  };
  
  const saveSelfAssessment = async () => {
    try {
      const overallLevel = getOverallMaturityLevel();
      
      // Update the user's PMO maturity level
      await updateUserProfile({
        pmoMaturityLevel: overallLevel.charAt(0).toUpperCase() + overallLevel.slice(1)
      });
      
      // In a full implementation, you would save the domain-specific assessments as well
      
      setAssessmentComplete(true);
      
      // Display a success message or redirect to another page
      setTimeout(() => {
        setAssessmentComplete(false);
      }, 3000);
    } catch (error) {
      console.error('Error saving assessment:', error);
    }
  };
  
  const generateAIAssessment = async () => {
    setIsGeneratingAssessment(true);
    
    try {
      // Verify data is available before proceeding
      if (!activeProject || !userData) {
        console.error('Cannot generate assessment: Missing project or user data');
        throw new Error('Missing required data to generate assessment');
      }
      
      // Gather all domain inputs
      const domainInputs = domains.map(domain => {
        return {
          domain,
          input: activeProject?.domainData?.domainInputs?.[domain.id]?.content || ''
        };
      });
      
      // Call the maturity assessment service
      const assessment = await maturityAssessmentService.generateMaturityAssessment({
        organizationName: userData.organizationName || '',
        industry: userData.industry || '',
        currentMaturityLevel: userData.pmoMaturityLevel || 'Initial',
        domainInputs,
        relevantDocuments: [],
        projectInfo: {
          name: activeProject?.name || 'PMO Implementation',
          startDate: activeProject?.startDate || '',
          endDate: activeProject?.endDate || '',
          budget: activeProject?.budget || 0,
          keyObjectives: activeProject?.keyObjectives || []
        }
      });
      
      // Validate assessment data
      if (!assessment || !assessment.overallMaturity) {
        throw new Error('Invalid assessment data received');
      }
      
      setAiAssessment(assessment);
      
      // Save the AI assessment to user profile
      await updateUserProfile({
        pmoMaturityLevel: assessment.overallMaturity.charAt(0).toUpperCase() + assessment.overallMaturity.slice(1)
      });
      
      // Update self-assessment with AI assessments for comparison
      setSelfAssessment(assessment.domainMaturity);
      
    } catch (error) {
      console.error('Error generating AI assessment:', error);
    } finally {
      setIsGeneratingAssessment(false);
      setAssessmentComplete(true);
    }
  };
  
  const exportAssessmentReport = async () => {
    setExportingReport(true);
    
    try {
      // Verify user data exists
      if (!userData) {
        throw new Error('User data is not available');
      }
      
      const reportTitle = `PMO Maturity Assessment Report - ${new Date().toLocaleDateString()}`;
      
      let reportContent = `# ${reportTitle}\n\n`;
      reportContent += `## Organization: ${userData?.organizationName || 'Not specified'}\n`;
      reportContent += `## Industry: ${userData?.industry || 'Not specified'}\n`;
      reportContent += `## Date: ${new Date().toLocaleDateString()}\n\n`;
      
      reportContent += `## Overall Maturity Level: ${getOverallMaturityLevel().toUpperCase()}\n\n`;
      
      reportContent += `## Domain-Specific Maturity Levels\n\n`;
      
      domains.forEach(domain => {
        const domainLevel = selfAssessment[domain.id] || 'Not assessed';
        reportContent += `### ${domain.name}\n`;
        reportContent += `- Maturity Level: **${domainLevel.toUpperCase()}**\n`;
        
        if (notes[domain.id]) {
          reportContent += `- Notes: ${notes[domain.id]}\n`;
        }
        
        reportContent += '\n';
      });
      
      // If AI assessment is available, include its insights
      if (aiAssessment) {
        reportContent += `## AI Assessment Insights\n\n`;
        
        reportContent += `### Strengths\n`;
        aiAssessment.strengths.forEach(strength => {
          reportContent += `- ${strength}\n`;
        });
        reportContent += '\n';
        
        reportContent += `### Improvement Areas\n`;
        aiAssessment.weaknesses.forEach(weakness => {
          reportContent += `- ${weakness}\n`;
        });
        reportContent += '\n';
        
        reportContent += `### Recommendations\n`;
        aiAssessment.recommendations.forEach(recommendation => {
          reportContent += `- ${recommendation}\n`;
        });
        reportContent += '\n';
        
        reportContent += `### Detailed Analysis\n\n`;
        reportContent += aiAssessment.report;
      }
      
      // Export the report as PDF
      await exportToPdf(
        reportContent,
        `PMO-Maturity-Assessment-Report-${new Date().toISOString().split('T')[0]}.pdf`,
        () => {
          setExportingReport(false);
        }
      );
      
    } catch (error) {
      console.error('Error exporting assessment report:', error);
      setExportingReport(false);
    }
  };
  
  // Add effect to handle refresh key changes
  useEffect(() => {
    if (refreshKey > 0) {
      // This will trigger when refreshKey changes
      console.log('Component refreshed via state update');
    }
  }, [refreshKey]);
  
  return (
    <ErrorBoundary
      fallbackRender={({ error, resetErrorBoundary }) => (
        <div className="min-h-[calc(100vh-64px)] flex items-center justify-center bg-neutral-50">
          <div className="text-center px-4 max-w-md">
            <AlertTriangle className="h-12 w-12 text-amber-500 mx-auto mb-4" />
            <h1 className="text-3xl font-bold text-neutral-800 mb-2">Something went wrong</h1>
            <p className="text-neutral-600 mb-8">
              {error.message || 'An unexpected error occurred. Please try again.'}
            </p>
            <button
              onClick={resetErrorBoundary}
              className="px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 transition-colors"
            >
              Try Again
            </button>
          </div>
        </div>
      )}
    >
      <Suspense fallback={<LoadingSpinner fullScreen text="Loading maturity assessment..." />}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="bg-white rounded-lg shadow-sm p-6 dark:bg-neutral-800 dark:border dark:border-neutral-700">
            <h1 className="text-2xl font-bold text-gray-800 dark:text-white mb-6">
              {t('dashboard.maturityAssessment', 'PMO Maturity Assessment')}
            </h1>
            
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6">
              <div className="mb-4 sm:mb-0">
                <h1 className="text-2xl font-bold text-gray-800 dark:text-white flex items-center">
                  <button
                    onClick={() => navigate('/dashboard')}
                    className="me-3 text-gray-600 hover:text-gray-800 dark:text-gray-200 dark:hover:text-white"
                    aria-label="Back to Dashboard"
                  >
                    {isRTL ? <ArrowRight className="h-5 w-5" /> : <ArrowLeft className="h-5 w-5" />}
                  </button>
                  <ChartBar className="h-6 w-6 me-2 text-primary-600 dark:text-white" />
                  {t('dashboard.maturityAssessment', 'PMO Maturity Assessment')}
                </h1>
                <p className="text-gray-600 dark:text-gray-200 mt-1 ms-8">
                  {t('dashboard.maturityAssessmentDescription', 'Evaluate your current PMO maturity level and identify opportunities for improvement.')}
                </p>
              </div>
              <div className="w-full sm:w-auto flex flex-col xs:flex-row gap-3">
                <button
                  onClick={() => setAssessmentType('manual')}
                  className={`px-4 py-3 rounded-md text-sm font-medium flex-1 sm:flex-none flex items-center justify-center ${
                    assessmentType === 'manual' 
                      ? 'bg-primary-600 text-white' 
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  <Clipboard className="h-4 w-4 me-2 flex-shrink-0" />
                  <span>{t('dashboard.selfAssessment', 'Self-Assessment')}</span>
                </button>
                <button
                  onClick={() => setAssessmentType('ai')}
                  className={`px-4 py-3 rounded-md text-sm font-medium flex-1 sm:flex-none flex items-center justify-center ${
                    assessmentType === 'ai' 
                      ? 'bg-secondary-600 text-white' 
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  <Sparkles className="h-4 w-4 me-2 flex-shrink-0" />
                  <span>{t('dashboard.aiGeneratedAssessment', 'AI Assessment')}</span>
                </button>
              </div>
            </div>
            
            {/* Overview Card */}
            <div className="bg-white rounded-lg shadow-sm p-6 mb-6 border border-gray-100">
              <div className="flex flex-col md:flex-row md:items-start gap-6">
                <div className="flex-1">
                  <h2 className="text-lg font-semibold text-gray-800 mb-2">{t('dashboard.currentMaturityProfile', 'Current Maturity Profile')}</h2>
                  <p className="text-sm text-gray-600 mb-4">
                    {t('dashboard.currentMaturityProfileDescription', 'Your organization\'s PMO is currently at the')} <span className="font-semibold">{userData?.pmoMaturityLevel}</span> {t('dashboard.currentMaturityProfileDescription2', 'level. This assessment will help you identify areas for improvement and create a roadmap for advancing your PMO capabilities.')}
                  </p>
                  
                  <h3 className="text-md font-medium text-gray-700 mb-2">{t('dashboard.organizationDetails', 'Organization Details')}</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-500">{t('dashboard.organization', 'Organization')}</p>
                      <p className="font-medium text-gray-800">{userData.organizationName || t('dashboard.notSpecified', 'Not specified')}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">{t('dashboard.industry', 'Industry')}</p>
                      <p className="font-medium text-gray-800">{userData.industry || t('dashboard.notSpecified', 'Not specified')}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">{t('dashboard.assessmentType', 'Assessment Type')}</p>
                      <p className="font-medium text-gray-800">
                        {assessmentType === 'manual' ? t('dashboard.selfAssessment', 'Self-Assessment') : t('dashboard.aiGeneratedAssessment', 'AI-Generated')}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">{t('dashboard.assessmentDate', 'Assessment Date')}</p>
                      <p className="font-medium text-gray-800">{new Date().toLocaleDateString()}</p>
                    </div>
                  </div>
                </div>
                
                <div className="md:w-96">
                  <MaturityRadarChart 
                    domainMaturity={
                      domains.reduce((acc, domain) => {
                        const level = selfAssessment[domain.id] || userData?.pmoMaturityLevel?.toLowerCase() || 'initial';
                        const levelIndex = maturityLevels.findIndex(l => l.value === level);
                        acc[domain.name] = levelIndex + 1;
                        return acc;
                      }, {} as Record<string, number>)
                    }
                  />
                </div>
              </div>
            </div>
            
            {assessmentType === 'manual' ? (
              /* Self-Assessment Form */
              <div className="bg-white rounded-lg shadow-sm p-6 mb-6 border border-gray-100">
                <h2 className="text-lg font-semibold text-gray-800 mb-4">{t('dashboard.selfAssessmentQuestionnaire', 'Self-Assessment Questionnaire')}</h2>
                <p className="text-sm text-gray-600 mb-6">
                  {t('dashboard.selfAssessmentDescription', `Rate your PMO's maturity level for each domain. Consider your processes, documentation, measurement capabilities, and continuous improvement efforts when making your assessment.`)}
                </p>
                
                {domains.map(domain => (
                  <div key={domain.id} className="mb-6 pb-6 border-b border-gray-200 last:border-b-0">
                    <h3 className="text-md font-medium text-gray-800 mb-2">{t(`domains.${domain.id}.name`, domain.name)}</h3>
                    <p className="text-sm text-gray-600 mb-3">{t(`domains.${domain.id}.description`, domain.description)}</p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-5 gap-2 mb-4">
                      {maturityLevels.map(level => (
                        <button
                          key={level.value}
                          className={`p-3 rounded-lg border ${
                            selfAssessment[domain.id] === level.value 
                              ? 'bg-primary-50 border-primary-300' 
                              : 'bg-gray-50 border-gray-200 hover:bg-gray-100'
                          } text-center`}
                          onClick={() => handleSelfAssessmentChange(domain.id, level.value)}
                        >
                          <p className="font-medium text-gray-800">{t(`maturityLevels.${level.value}.label`, level.label)}</p>
                          <p className="text-xs text-gray-500 mt-1">{t(`maturityLevels.${level.value}.description`, level.description)}</p>
                        </button>
                      ))}
                    </div>
                    
                    <div>
                      <label htmlFor={`notes-${domain.id}`} className="block text-sm font-medium text-gray-700 mb-1">
                        {t('dashboard.notes', 'Notes (Optional)')} 
                      </label>
                      <textarea
                        id={`notes-${domain.id}`}
                        className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 text-neutral-800 text-sm"
                        rows={2}
                        placeholder={t('dashboard.notesPlaceholder', 'Add any notes or context about your assessment...')}
                        value={notes[domain.id] || ''}
                        onChange={(e) => handleNotesChange(domain.id, e.target.value)}
                      ></textarea>
                    </div>
                  </div>
                ))}
                
                <div className="mt-6 flex flex-col sm:flex-row gap-3 sm:justify-end">
                  <button
                    onClick={() => navigate('/')}
                    className="px-5 py-3 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 w-full sm:w-auto flex items-center justify-center"
                  >
                    {t('common.cancel', 'Cancel')}
                  </button>
                  <button
                    onClick={saveSelfAssessment}
                    className="px-5 py-3 bg-primary-600 text-white rounded-md hover:bg-primary-700 flex items-center justify-center w-full sm:w-auto"
                    disabled={assessmentComplete}
                  >
                    {assessmentComplete ? (
                      <>
                        <Check className="h-4 w-4 me-2 flex-shrink-0" />
                        <span>{t('common.saved', 'Saved!')}</span>
                      </>
                    ) : (
                      <>
                        <Save className="h-4 w-4 me-2 flex-shrink-0" />
                        <span>{t('common.saveAssessment', 'Save Assessment')}</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            ) : (
              /* AI-Generated Assessment */
              <div className="space-y-6">
                <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-100">
                  <h2 className="text-lg font-semibold text-gray-800 mb-4">{t('dashboard.aiGeneratedAssessment', 'AI-Generated PMO Maturity Assessment')}</h2>
                  
                  {!isGeneratingAssessment && !aiAssessment ? (
                    <div className="bg-secondary-50 border border-secondary-200 rounded-lg p-6 text-center mb-6">
                      <Sparkles className="h-10 w-10 text-secondary-600 mx-auto mb-3" />
                      <h3 className="text-lg font-semibold text-gray-800 mb-2">{t('dashboard.generateAIAssessment', 'Generate an AI Assessment')}</h3>
                      <p className="text-sm text-gray-600 mb-4">
                        {t('dashboard.aiAssessmentDescription', `Our AI will analyze your domain inputs, project data, and uploaded documents to provide an objective assessment of your PMO's maturity across all domains.`)}
                      </p>
                      <button
                        onClick={generateAIAssessment}
                        className="px-5 py-3 bg-secondary-600 text-white rounded-md hover:bg-secondary-700 inline-flex items-center justify-center w-full sm:w-auto"
                      >
                        <Sparkles className="h-4 w-4 me-2" />
                        {t('dashboard.generateAssessment', 'Generate Assessment')}
                      </button>
                    </div>
                  ) : isGeneratingAssessment ? (
                    <div className="bg-secondary-50 border border-secondary-200 rounded-lg p-6 text-center mb-6">
                      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-secondary-600 mx-auto mb-4"></div>
                      <h3 className="text-lg font-semibold text-gray-800 mb-2">{t('dashboard.generatingAssessment', 'Generating Assessment...')}</h3>
                      <p className="text-sm text-gray-600">
                        {t('dashboard.generatingAssessmentDescription', 'Our AI is analyzing your PMO data across all domains. This may take a few moments.')}
                      </p>
                    </div>
                  ) : aiAssessment ? (
                    <div className="space-y-6">
                      <div className="bg-secondary-50 border border-secondary-200 rounded-lg p-6">
                        <div className="flex flex-col md:flex-row md:items-start gap-6">
                          <div className="flex-1">
                            <h3 className="text-lg font-semibold text-gray-800 mb-2">
                              {t('dashboard.aiAssessmentSummary', 'AI Assessment Summary')}
                            </h3>
                            <p className="text-sm text-gray-600 mb-4">
                              {t('dashboard.aiAssessmentSummaryDescription', `Based on our analysis, your PMO is currently at the <span className="font-semibold">{aiAssessment.overallMaturity.toUpperCase()}</span> level. Below are key strengths and areas for improvement.`)}
                            </p>
                            
                            <div className="mb-4">
                              <h4 className="text-sm font-medium text-gray-700 mb-2">{t('dashboard.keyStrengths', 'Key Strengths')}</h4>
                              <ul className="list-disc list-inside space-y-1">
                                {aiAssessment.strengths.map((strength, index) => (
                                  <li key={index} className="text-sm text-gray-600">{strength}</li>
                                ))}
                              </ul>
                            </div>
                            
                            <div>
                              <h4 className="text-sm font-medium text-gray-700 mb-2">{t('dashboard.areasForImprovement', 'Areas for Improvement')}</h4>
                              <ul className="list-disc list-inside space-y-1">
                                {aiAssessment.weaknesses.map((weakness, index) => (
                                  <li key={index} className="text-sm text-gray-600">{weakness}</li>
                                ))}
                              </ul>
                            </div>
                          </div>
                          
                          <div className="md:w-72">
                            <div className="bg-white p-4 rounded-lg border border-gray-200">
                              <h3 className="font-medium text-gray-800 mb-1">
                                {aiAssessment.overallMaturity.charAt(0).toUpperCase() + aiAssessment.overallMaturity.slice(1)}
                              </h3>
                              <p className="text-sm text-gray-600">
                                {maturityLevels.find(l => l.value === aiAssessment.overallMaturity)?.description || ''}
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div className="bg-white border border-gray-200 rounded-lg p-6">
                        <h3 className="text-lg font-semibold text-gray-800 mb-4">{t('dashboard.domainSpecificAssessment', 'Domain-Specific Assessment')}</h3>
                        
                        <div className="space-y-4">
                          {domains.map(domain => {
                            const maturityLevel = aiAssessment.domainMaturity[domain.id] || 'initial';
                            const levelIndex = maturityLevels.findIndex(l => l.value === maturityLevel);
                            
                            return (
                              <div key={domain.id} className="border border-gray-100 rounded-lg p-4">
                                <div className="flex items-center justify-between mb-2">
                                  <h4 className="font-medium text-gray-800">{t(`domains.${domain.id}.name`, domain.name)}</h4>
                                  <span className="text-sm font-medium bg-primary-100 text-primary-800 px-2 py-1 rounded-full">
                                    {maturityLevel.charAt(0).toUpperCase() + maturityLevel.slice(1)}
                                  </span>
                                </div>
                                
                                <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                                  <div 
                                    className="h-full bg-primary-600"
                                    style={{ width: `${((levelIndex + 1) / maturityLevels.length) * 100}%` }}
                                  ></div>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                      
                      <div className="bg-white border border-gray-200 rounded-lg p-6">
                        <h3 className="text-lg font-semibold text-gray-800 mb-4">{t('dashboard.maturityProgression', 'Maturity Progression')}</h3>
                        <div className="text-center text-gray-500 py-4">
                          Maturity progression visualization
                        </div>
                      </div>
                      
                      <div className="bg-white border border-gray-200 rounded-lg p-6">
                        <h3 className="text-lg font-semibold text-gray-800 mb-4">{t('dashboard.recommendations', 'Recommendations')}</h3>
                        <ul className="list-disc list-inside space-y-2 pl-4">
                          {aiAssessment.recommendations.map((recommendation, index) => (
                            <li key={index} className="text-gray-700">{recommendation}</li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  ) : null}
                </div>
                
                {aiAssessment && (
                  <div className="flex justify-center sm:justify-end">
                    <button
                      onClick={exportAssessmentReport}
                      disabled={exportingReport}
                      className={`px-5 py-3 bg-primary-600 text-white rounded-md hover:bg-primary-700 flex items-center justify-center w-full sm:w-auto ${
                        exportingReport ? 'opacity-70 cursor-not-allowed' : ''
                      }`}
                    >
                      {exportingReport ? (
                        <>
                          <Clock className="h-4 w-4 me-2 flex-shrink-0" />
                          <span>{t('dashboard.generatingReport', 'Generating Report...')}</span>
                        </>
                      ) : (
                        <>
                          <Download className="h-4 w-4 me-2 flex-shrink-0" />
                          <span>{t('dashboard.exportAssessmentReport', 'Export Report')}</span>
                        </>
                      )}
                    </button>
                  </div>
                )}
              </div>
            )}
            
            {/* Maturity Model Reference */}
            <div className="bg-gray-50 rounded-lg p-6 mt-6 border border-gray-200">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-gray-800">{t('dashboard.maturityModelReference', 'Maturity Model Reference')}</h2>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                {maturityLevels.map(level => (
                  <div key={level.value} className="bg-white p-4 rounded-lg border border-gray-200">
                    <h3 className="font-medium text-gray-800 mb-1">{t(`maturityLevels.${level.value}.label`, level.label)}</h3>
                    <p className="text-sm text-gray-600">{t(`maturityLevels.${level.value}.description`, level.description)}</p>
                    
                    <div className="mt-2 text-xs text-gray-500">
                      <p><strong>
                        {t('dashboard.documentation', 'Documentation')}:</strong> {level.value === 'initial' ? t('dashboard.minimalToNone', 'Minimal to none')   : 
                         level.value === 'defined' ? t('dashboard.basicDocumentation', 'Basic documentation') :
                         level.value === 'managed' ? t('dashboard.comprehensiveDocumentation', 'Comprehensive') :
                         level.value === 'optimized' ? t('dashboard.regularlyUpdated', 'Regularly updated') : t('dashboard.leadingPractice', 'Leading practice')}
                      </p>
                         
                      <p><strong>
                        {t('dashboard.metrics', 'Metrics')}:</strong> {level.value === 'initial' ? t('dashboard.adHocOrNone', 'Ad-hoc or none') : 
                         level.value === 'defined' ? t('dashboard.basicTracking', 'Basic tracking') :
                         level.value === 'managed' ? t('dashboard.dataDrivenDecisions', 'Data-driven decisions') :
                         level.value === 'optimized' ? t('dashboard.predictiveAnalytics', 'Predictive analytics') : t('dashboard.advancedAnalytics', 'Advanced analytics')}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </Suspense>
    </ErrorBoundary>
  );
};

export default MaturityAssessmentPage;