import React, { useState } from 'react';
import { Users, Plus, UserPlus, User, MoreHorizontal, Settings, UserCheck, LogOut, AlertTriangle, Search } from 'lucide-react';

const TeamsPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'myTeams' | 'joinedTeams'>('myTeams');
  const [teamMenuOpen, setTeamMenuOpen] = useState<number | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  
  const myTeams = [
    {
      id: 1,
      name: 'PMO Governance Team',
      role: 'Owner',
      members: 5,
      lastActive: '2 days ago',
      description: 'Responsible for PMO governance framework and oversight.'
    },
    {
      id: 2,
      name: 'Portfolio Management Office',
      role: 'Admin',
      members: 8,
      lastActive: 'Today',
      description: 'Manages the organization-wide project portfolio and prioritization.'
    }
  ];
  
  const joinedTeams = [
    {
      id: 3,
      name: 'Enterprise Project Office',
      role: 'Member',
      members: 12,
      lastActive: 'Yesterday',
      description: 'Oversees enterprise-wide projects and strategic initiatives.'
    },
    {
      id: 4,
      name: 'Organizational Development Committee',
      role: 'Member',
      members: 6,
      lastActive: '3 days ago',
      description: 'Focuses on organizational alignment and PMO maturity advancement.'
    }
  ];
  
  const filteredMyTeams = myTeams.filter(team => 
    team.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    team.description.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  const filteredJoinedTeams = joinedTeams.filter(team => 
    team.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    team.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold  text-neutral-800 flex items-center">
            <Users className="mr-2 text-primary-500 h-6 w-6" />
            My Teams
          </h1>
          <p className="text-neutral-600 mt-1">
            Collaborate with your teams on PMO domains and projects
          </p>
        </div>
        <div className="mt-4 md:mt-0">
          <button className="px-4 py-2 bg-gradient-to-r from-primary-600 to-primary-700 text-white rounded-lg shadow-sm hover:shadow-md transition-all duration-200 flex items-center">
            <Plus className="h-4 w-4 mr-2" />
            Create New Team
          </button>
        </div>
      </div>
      
      <div className="bg-white rounded-xl shadow-sm p-6 mb-6 border border-neutral-100">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
          <div className="mb-4 md:mb-0">
            <div className="flex border-b border-neutral-200">
              <button
                className={`py-2 px-4 font-medium text-sm border-b-2 ${
                  activeTab === 'myTeams'
                    ? 'border-primary-500 text-primary-600'
                    : 'border-transparent text-neutral-500 hover:text-neutral-700'
                }`}
                onClick={() => setActiveTab('myTeams')}
              >
                My Teams
              </button>
              <button
                className={`py-2 px-4 font-medium text-sm border-b-2 ${
                  activeTab === 'joinedTeams'
                    ? 'border-primary-500 text-primary-600'
                    : 'border-transparent text-neutral-500 hover:text-neutral-700'
                }`}
                onClick={() => setActiveTab('joinedTeams')}
              >
                Teams I've Joined
              </button>
            </div>
          </div>
          <div className="w-full md:w-64 relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-4 w-4 text-neutral-400" />
            </div>
            <input
              type="text"
              placeholder="Search teams..."
              className="pl-10 block w-full rounded-md border-neutral-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        
        {activeTab === 'myTeams' ? (
          <div className="space-y-4">
            {filteredMyTeams.length > 0 ? (
              filteredMyTeams.map(team => (
                <div key={team.id} className="bg-neutral-50 p-4 rounded-lg border border-neutral-100 hover:border-primary-200 transition-colors duration-200">
                  <div className="flex flex-col md:flex-row md:items-center justify-between">
                    <div className="flex items-start">
                      <div className="p-2 bg-primary-100 rounded-lg mr-4">
                        <Users className="h-6 w-6 text-primary-600" />
                      </div>
                      <div>
                        <div className="flex items-center">
                          <h3 className="font-semibold text-neutral-800">{team.name}</h3>
                          <span className="ml-2 text-xs bg-primary-100 text-primary-800 px-2 py-0.5 rounded-full">{team.role}</span>
                        </div>
                        <p className="text-sm text-neutral-600 mt-1">{team.description}</p>
                        <div className="flex items-center mt-2 text-xs text-neutral-500">
                          <span className="flex items-center">
                            <User className="h-3.5 w-3.5 mr-1" />
                            {team.members} members
                          </span>
                          <span className="mx-2">•</span>
                          <span>Active {team.lastActive}</span>
                        </div>
                      </div>
                    </div>
                    <div className="mt-4 md:mt-0 flex items-center space-x-2">
                      <button className="px-3 py-1.5 bg-primary-600 text-white text-sm rounded-md hover:bg-primary-700 transition-colors">
                        Manage Team
                      </button>
                      <div className="relative">
                        <button 
                          className="p-1.5 rounded-md hover:bg-neutral-200 transition-colors"
                          onClick={() => setTeamMenuOpen(teamMenuOpen === team.id ? null : team.id)}
                        >
                          <MoreHorizontal className="h-5 w-5 text-neutral-500" />
                        </button>
                        
                        {teamMenuOpen === team.id && (
                          <div className="absolute right-0 mt-1 w-48 bg-white rounded-md shadow-lg z-10 border border-neutral-100">
                            <div className="py-1">
                              <button className="flex items-center w-full px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-50">
                                <UserPlus className="h-4 w-4 mr-3 text-primary-500" />
                                Invite Members
                              </button>
                              <button className="flex items-center w-full px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-50">
                                <Settings className="h-4 w-4 mr-3 text-neutral-500" />
                                Team Settings
                              </button>
                              <div className="border-t border-neutral-100 my-1"></div>
                              <button className="flex items-center w-full px-4 py-2 text-sm text-secondary-700 hover:bg-secondary-50">
                                <LogOut className="h-4 w-4 mr-3 text-secondary-500" />
                                Delete Team
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="bg-neutral-50 p-8 rounded-lg border border-neutral-100 text-center">
                <div className="inline-flex items-center justify-center p-3 bg-neutral-100 rounded-full mb-4">
                  <Users className="h-8 w-8 text-neutral-500" />
                </div>
                <h3 className="text-lg font-semibold text-neutral-800 mb-2">No teams found</h3>
                <p className="text-neutral-600 max-w-md mx-auto">
                  {searchTerm 
                    ? `No teams match your search for "${searchTerm}".` 
                    : "You haven't created any teams yet. Create a team to collaborate with your colleagues."}
                </p>
                <button className="mt-4 px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 inline-flex items-center">
                  <Plus className="h-4 w-4 mr-1.5" />
                  Create New Team
                </button>
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            {filteredJoinedTeams.length > 0 ? (
              filteredJoinedTeams.map(team => (
                <div key={team.id} className="bg-neutral-50 p-4 rounded-lg border border-neutral-100 hover:border-primary-200 transition-colors duration-200">
                  <div className="flex flex-col md:flex-row md:items-center justify-between">
                    <div className="flex items-start">
                      <div className="p-2 bg-secondary-100 rounded-lg mr-4">
                        <UserCheck className="h-6 w-6 text-secondary-600" />
                      </div>
                      <div>
                        <div className="flex items-center">
                          <h3 className="font-semibold text-neutral-800">{team.name}</h3>
                          <span className="ml-2 text-xs bg-neutral-100 text-neutral-800 px-2 py-0.5 rounded-full">{team.role}</span>
                        </div>
                        <p className="text-sm text-neutral-600 mt-1">{team.description}</p>
                        <div className="flex items-center mt-2 text-xs text-neutral-500">
                          <span className="flex items-center">
                            <User className="h-3.5 w-3.5 mr-1" />
                            {team.members} members
                          </span>
                          <span className="mx-2">•</span>
                          <span>Active {team.lastActive}</span>
                        </div>
                      </div>
                    </div>
                    <div className="mt-4 md:mt-0 flex items-center space-x-2">
                      <button className="px-3 py-1.5 border border-neutral-200 text-neutral-700 text-sm rounded-md hover:bg-neutral-50 transition-colors">
                        View Team
                      </button>
                      <div className="relative">
                        <button 
                          className="p-1.5 rounded-md hover:bg-neutral-200 transition-colors"
                          onClick={() => setTeamMenuOpen(teamMenuOpen === team.id ? null : team.id)}
                        >
                          <MoreHorizontal className="h-5 w-5 text-neutral-500" />
                        </button>
                        
                        {teamMenuOpen === team.id && (
                          <div className="absolute right-0 mt-1 w-48 bg-white rounded-md shadow-lg z-10 border border-neutral-100">
                            <div className="py-1">
                              <button className="flex items-center w-full px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-50">
                                <Settings className="h-4 w-4 mr-3 text-neutral-500" />
                                View Details
                              </button>
                              <div className="border-t border-neutral-100 my-1"></div>
                              <button className="flex items-center w-full px-4 py-2 text-sm text-secondary-700 hover:bg-secondary-50">
                                <LogOut className="h-4 w-4 mr-3 text-secondary-500" />
                                Leave Team
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="bg-neutral-50 p-8 rounded-lg border border-neutral-100 text-center">
                <div className="inline-flex items-center justify-center p-3 bg-neutral-100 rounded-full mb-4">
                  <UserCheck className="h-8 w-8 text-neutral-500" />
                </div>
                <h3 className="text-lg font-semibold text-neutral-800 mb-2">No teams found</h3>
                <p className="text-neutral-600 max-w-md mx-auto">
                  {searchTerm 
                    ? `No teams match your search for "${searchTerm}".` 
                    : "You haven't joined any teams yet."}
                </p>
              </div>
            )}
          </div>
        )}
      </div>
      
      <div className="bg-gradient-to-r from-primary-700 to-secondary-700 rounded-xl shadow-md p-6 text-white">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="mb-4 md:mb-0 md:mr-6">
            <h2 className="text-xl font-bold flex items-center">
              <UserPlus className="h-5 w-5 mr-2" />
              Invite team members
            </h2>
            <p className="mt-2 text-white/80 max-w-xl">
              Collaborate more effectively by inviting your colleagues to join your PMO teams. Share templates, track progress, and align on strategic initiatives together.
            </p>
          </div>
          <div className="flex-shrink-0">
            <button className="px-4 py-2 bg-white text-primary-700 rounded-lg shadow-sm hover:shadow-md transition-all duration-200 font-medium">
              Send Invitations
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TeamsPage;