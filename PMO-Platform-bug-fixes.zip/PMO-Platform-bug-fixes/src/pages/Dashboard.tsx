import React, { useState, useEffect, Suspense, useCallback } from 'react';
import { useAppStore } from '../store';
import { domains } from '../data';
import { ArrowRight, CheckCircle2, Clock, FileText, Sparkles, Brain, Zap, Target, Plus, BarChart as ChartBar, Sliders, Layout, Grid, List, AlertTriangle, ArrowLeft, Loader2 } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import DashboardSkeleton from '../components/common/DashboardSkeleton';
import LoadingSpinner from '../components/common/LoadingSpinner';
import ConnectionStatus from '../components/ConnectionStatus';
import ErrorBoundary from '../components/common/ErrorBoundary';
import { useNavigationGuard } from '../hooks/useNavigationGuard';

// Lazily load heavy components
const DomainCard = React.lazy(() => import('../components/PMODomainTile'));
const ProgressChart = React.lazy(() => import('../components/ProgressChart'));
const ProjectDetailsCard = React.lazy(() => import('../components/ProjectDetailsCard'));
const CustomDashboard = React.lazy(() => import('../components/CustomDashboard'));
const GanttChart = React.lazy(() => import('../components/GanttChart'));

const Dashboard: React.FC = () => {
  const { navigate } = useNavigationGuard();
  const { userData, getOverallProgress, getActiveProject, createProject, connectionError, showConnectionErrors } = useAppStore();
  const { t, isRTL } = useLanguage();
  const [showNewProjectPrompt, setShowNewProjectPrompt] = useState(false);
  const [showAIAnalysisModal, setShowAIAnalysisModal] = useState(false);
  const [dashboardLayout, setDashboardLayout] = useState<'grid' | 'list'>('grid');
  const [showCustomizationPanel, setShowCustomizationPanel] = useState(false);
  const [customWidgets, setCustomWidgets] = useState<string[]>(['progress', 'tasks', 'domains', 'charts']);
  const [renderFallback, setRenderFallback] = useState(true);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isMounted, setIsMounted] = useState(false);
  
  const activeProject = getActiveProject();
  const overallProgress = getOverallProgress();

  useEffect(() => {
    // Mark component as mounted
    setIsMounted(true);
    
    // Check if there are no projects
    if (!activeProject) {
      setShowNewProjectPrompt(true);
    } else {
      setShowNewProjectPrompt(false);
    }

    // Load saved dashboard preferences
    const savedLayout = localStorage.getItem('dashboardLayout');
    if (savedLayout === 'grid' || savedLayout === 'list') {
      setDashboardLayout(savedLayout);
    }

    const savedWidgets = localStorage.getItem('dashboardWidgets');
    if (savedWidgets) {
      try {
        const widgets = JSON.parse(savedWidgets);
        if (Array.isArray(widgets) && widgets.length > 0) {
          setCustomWidgets(widgets);
        }
      } catch (e) {
        console.error('Error parsing saved widgets:', e);
        setError('Error loading dashboard preferences');
      }
    }
    
    // Set a short timeout to remove the fallback
    const timer = setTimeout(() => {
      setRenderFallback(false);
      setLoading(false);
    }, 500);
    
    return () => {
      setIsMounted(false);
      clearTimeout(timer);
    };
  }, [activeProject]);
    
  // Calculate completed tasks
  const totalTasks = Object.keys(activeProject?.domainData?.tasks || {}).length;
  const completedTasks = Object.values(activeProject?.domainData?.tasks || {}).filter(task => task?.completed).length;
  
  const handleCreateSampleProject = () => {
    try {
      setLoading(true);
      setError(null);
      createProject({
        name: t('dashboard.sampleProject', "Sample PMO Implementation"),
        description: t('dashboard.sampleDescription', "A sample project with pre-populated data for demonstration"),
        budget: 500000,
        keyObjectives: [
          t('dashboard.objective1', "Establish PMO governance framework"),
          t('dashboard.objective2', "Develop standard methodologies"),
          t('dashboard.objective3', "Implement performance metrics")
        ]
      });
      setShowNewProjectPrompt(false);
    } catch (err: any) {
      console.error("Error creating sample project:", err);
      setError(err?.message || "Failed to create sample project");
    } finally {
      setLoading(false);
    }
  };
  
  const toggleDashboardLayout = () => {
    const newLayout = dashboardLayout === 'grid' ? 'list' : 'grid';
    setDashboardLayout(newLayout);
    localStorage.setItem('dashboardLayout', newLayout);
  };

  const toggleWidget = (widget: string) => {
    setCustomWidgets(prev => {
      if (prev.includes(widget)) {
        const newWidgets = prev.filter(w => w !== widget);
        localStorage.setItem('dashboardWidgets', JSON.stringify(newWidgets));
        return newWidgets;
      } else {
        const newWidgets = [...prev, widget];
        localStorage.setItem('dashboardWidgets', JSON.stringify(newWidgets));
        return newWidgets;
      }
    });
  };

  const domainProgressData = domains.map(domain => {
    const progress = useAppStore().getDomainProgress(domain?.id);
    return {
      domain: domain?.name || "",
      progress: progress?.overallProgress || 0
    };
  }).sort((a, b) => b.progress - a.progress);
  
  const handleMaturityAssessmentClick = () => {
    navigate('/maturity-assessment');
  };

  const handleResourcesClick = () => {
    navigate('/resources');
  };
  
  if (renderFallback) {
    return <DashboardSkeleton />;
  }
  
  if (loading && !renderFallback) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="h-10 w-10 text-primary-600 animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-lg my-4">
        <div className="flex items-center">
          <AlertTriangle className="h-5 w-5 mr-2" />
          <p>{error}</p>
        </div>
        <button 
          onClick={() => setError(null)} 
          className="mt-2 px-4 py-2 bg-white border border-red-300 text-red-700 rounded hover:bg-red-50"
        >
          Dismiss
        </button>
      </div>
    );
  }
  
  return (
    <ErrorBoundary>
      <Suspense fallback={<LoadingSpinner fullScreen text="Loading dashboard..." />}>
        <div className="space-y-6 max-w-7xl mx-auto dashboard-overview">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div>
              <h1 className="text-2xl font-bold  text-neutral-800 flex items-center">
                <span className="bg-gradient-to-r from-primary-600 to-secondary-600 bg-clip-text text-transparent">
                  {t('dashboard.title')}
                </span>
              </h1>
              <p className="text-neutral-600 mt-1">
                {t('dashboard.subtitle')}
              </p>
            </div>
            <div className="mt-4 md:mt-0 flex items-center space-x-4 rtl:space-x-reverse">
              <button
                onClick={() => setShowCustomizationPanel(!showCustomizationPanel)}
                className="p-2 rounded-lg border border-gray-200 bg-white hover:bg-gray-50 text-gray-700"
                title="Customize Dashboard"
                aria-label="Customize Dashboard"
              >
                <Sliders className="h-5 w-5" />
              </button>
              <button
                className="p-2 rounded-lg border border-gray-200 bg-white hover:bg-gray-50 text-gray-700"
                title={dashboardLayout === 'grid' ? "Switch to List View" : "Switch to Grid View"}
                aria-label={dashboardLayout === 'grid' ? "Switch to List View" : "Switch to Grid View"}
                onClick={toggleDashboardLayout}
              >
                {dashboardLayout === 'grid' ? <List className="h-5 w-5" /> : <Grid className="h-5 w-5" />}
              </button>
              <button 
                className="px-4 py-2 border border-gray-300 bg-white rounded-md hover:bg-gray-50 text-gray-800 font-medium inline-flex items-center justify-center shadow-sm maturity-assessment"
                onClick={handleMaturityAssessmentClick}
              >
                <ChartBar className="h-4 w-4 me-2 text-primary-600" />
                {t('dashboard.maturityAssessment')}
              </button>
              
              <button 
                className="px-4 py-2 bg-gradient-to-r from-primary-600 to-secondary-600 text-white rounded-md hover:from-primary-700 hover:to-secondary-700 transition-all duration-300 inline-flex items-center justify-center shadow-sm resources-page"
                onClick={handleResourcesClick}
              >
                {t('sidebar.bestPractices')}
              </button>
            </div>
          </div>
          
          {connectionError && showConnectionErrors && (
            <ConnectionStatus />
          )}
          
          {/* Customization Panel */}
          {showCustomizationPanel && (
            <div className="bg-white rounded-lg shadow-md p-6 border border-gray-200">
              <div className="flex justify-between items-center mb-4">
                <h2 className="font-semibold text-gray-800 flex items-center">
                  <Layout className="h-5 w-5 me-2 text-primary-600" />
                  {t('dashboard.dashboardCustomization', 'Dashboard Customization')}
                </h2>
                <button 
                  onClick={() => setShowCustomizationPanel(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  {isRTL ? (
                    <ArrowLeft className="h-5 w-5" />
                  ) : (
                    <ArrowRight className="h-5 w-5" />
                  )}
                </button>
              </div>
              
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-700 mb-2">{t('dashboard.displayLayout', 'Display Layout')}</h3>
                  <div className="flex gap-3">
                    <button 
                      className={`p-3 border rounded-md flex flex-col items-center ${dashboardLayout === 'grid' ? 'border-primary-300 bg-primary-50 text-primary-700' : 'border-gray-200 text-gray-600 hover:bg-gray-50'}`}
                      onClick={() => {setDashboardLayout('grid'); localStorage.setItem('dashboardLayout', 'grid')}}
                    >
                      <Grid className="h-5 w-5 mb-1" />
                      <span className="text-sm">{t('dashboard.gridView', 'Grid View')}</span>
                    </button>
                    <button 
                      className={`p-3 border rounded-md flex flex-col items-center ${dashboardLayout === 'list' ? 'border-primary-300 bg-primary-50 text-primary-700' : 'border-gray-200 text-gray-600 hover:bg-gray-50'}`}
                      onClick={() => {setDashboardLayout('list'); localStorage.setItem('dashboardLayout', 'list')}}
                    >
                      <List className="h-5 w-5 mb-1" />
                      <span className="text-sm">{t('dashboard.listView', 'List View')}</span>
                    </button>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium text-gray-700 mb-2">{t('dashboard.widgetSelection', 'Widget Selection')}</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    <div className="flex items-center">
                      <input
                        type="checkbox"
                        id="widget-progress"
                        checked={customWidgets.includes('progress')}
                        onChange={() => toggleWidget('progress')}
                        className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                      />
                      <label htmlFor="widget-progress" className="ms-2 block text-sm text-gray-700">
                        {t('dashboard.progressOverview', 'Progress Overview')}
                      </label>
                    </div>
                    <div className="flex items-center">
                      <input
                        type="checkbox"
                        id="widget-tasks"
                        checked={customWidgets.includes('tasks')}
                        onChange={() => toggleWidget('tasks')}
                        className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                      />
                      <label htmlFor="widget-tasks" className="ms-2 block text-sm text-gray-700">
                        {t('dashboard.tasksStatus', 'Tasks Status')}
                      </label>
                    </div>
                    <div className="flex items-center">
                      <input
                        type="checkbox"
                        id="widget-domains"
                        checked={customWidgets.includes('domains')}
                        onChange={() => toggleWidget('domains')}
                        className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                      />
                      <label htmlFor="widget-domains" className="ms-2 block text-sm text-gray-700">
                        {t('dashboard.domains', 'Domains')}
                      </label>
                    </div>
                    <div className="flex items-center">
                      <input
                        type="checkbox"
                        id="widget-charts"
                        checked={customWidgets.includes('charts')}
                        onChange={() => toggleWidget('charts')}
                        className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                      />
                      <label htmlFor="widget-charts" className="ms-2 block text-sm text-gray-700">
                        {t('dashboard.chartsAnalytics', 'Charts & Analytics')}
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {showNewProjectPrompt ? (
            <div className="bg-white rounded-xl shadow-sm p-8 border border-neutral-100 text-center">
              <div className="inline-flex items-center justify-center p-4 bg-primary-100 rounded-full mb-4">
                <Plus className="h-8 w-8 text-primary-600" />
              </div>
              <h2 className="text-xl font-bold text-neutral-800 mb-2">{t('dashboard.createFirstProject', 'Create Your First PMO Project')}</h2>
              <p className="text-neutral-600 max-w-lg mx-auto mb-6">
                {t('dashboard.firstProjectDesc', 'Get started by creating your first PMO implementation project. You can set up project details, track progress across domains, and generate AI-powered recommendations.')}
              </p>
              <div className="flex justify-center space-x-4 rtl:space-x-reverse">
                <button
                  onClick={handleCreateSampleProject}
                  className="px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 export-project-btn"
                >
                  {t('dashboard.createSample', 'Create Sample Project')}
                </button>
              </div>
            </div>
          ) : (
            <Suspense fallback={<DashboardSkeleton />}>
              <CustomDashboard 
                activeProject={activeProject}
                overallProgress={overallProgress}
                completedTasks={completedTasks}
                totalTasks={totalTasks}
                userData={userData}
                layout={dashboardLayout}
                enabledWidgets={customWidgets}
                domainProgressData={domainProgressData}
                onNavigate={(path, state) => navigate(path, { state })}
                t={t}
                isRTL={isRTL}
              />
            </Suspense>
          )}
          
          {/* AI Analysis Modal - only render when visible */}
          {showAIAnalysisModal && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
              <div className="bg-white rounded-lg shadow-lg max-w-2xl w-full p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-semibold text-neutral-800 flex items-center">
                    <Brain className={`h-6 w-6 ${isRTL ? 'ms-2' : 'me-2'} text-primary-600`} />
                    {t('domain.aiConfigTitle', 'AI Analysis Configuration')}
                  </h3>
                  <button 
                    className="p-2 rounded-full hover:bg-neutral-100 text-neutral-500"
                    onClick={() => setShowAIAnalysisModal(false)}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>
                
                <div className="mb-6">
                  <p className="text-neutral-600">
                    {t('domain.selectDomainPrompt', 'Select a domain to analyze with our advanced AI. The analysis will generate comprehensive recommendations and templates based on your organization\'s specific context.')}
                  </p>
                </div>
                
                <div className="space-y-4 mb-6">
                  <div>
                    <label className="block text-sm font-medium text-neutral-700 mb-1">
                      {t('domain.selectDomain', 'Select Domain')}
                    </label>
                    <select className="w-full px-3 py-2 border border-neutral-300 rounded-md focus:ring-primary-500 focus:border-primary-500">
                      {domains.map(domain => (
                        <option key={domain.id} value={domain.id}>{t(`domains.${domain.id}.name`, domain.name)}</option>
                      ))}
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-neutral-700 mb-1">
                      {t('domain.analysisDepth', 'Analysis Depth')}
                    </label>
                    <div className="grid grid-cols-4 gap-2">
                      <button className="p-2 border border-neutral-200 rounded-md hover:bg-neutral-50 text-center">
                        <span className="font-medium text-sm">{t('domain.basic', 'Basic')}</span>
                        <span className="block text-xs text-neutral-500 mt-1">{t('domain.quickOverview', 'Quick overview')}</span>
                      </button>
                      <button className="p-2 border border-primary-300 bg-primary-50 rounded-md text-center">
                        <span className="font-medium text-sm">{t('domain.standard', 'Standard')}</span>
                        <span className="block text-xs text-neutral-500 mt-1">{t('domain.balancedAnalysis', 'Balanced analysis')}</span>
                      </button>
                      <button className="p-2 border border-neutral-200 rounded-md hover:bg-neutral-50 text-center">
                        <span className="font-medium text-sm">{t('domain.detailed', 'Detailed')}</span>
                        <span className="block text-xs text-neutral-500 mt-1">{t('domain.inDepthReview', 'In-depth review')}</span>
                      </button>
                      <button className="p-2 border border-neutral-200 rounded-md hover:bg-neutral-50 text-center">
                        <span className="font-medium text-sm">{t('domain.comprehensive', 'Comprehensive')}</span>
                        <span className="block text-xs text-neutral-500 mt-1">{t('domain.maximumDetail', 'Maximum detail')}</span>
                      </button>
                    </div>
                  </div>
                  
                  <div className="bg-primary-50 p-4 rounded-md border border-primary-100">
                    <div className="flex items-center">
                      <Sparkles className={`h-5 w-5 text-primary-600 ${isRTL ? 'ms-2' : 'me-2'}`} />
                      <div>
                        <h4 className="font-medium text-primary-800">{t('domain.geminiPowered', 'Gemini AI Powered Analysis')}</h4>
                        <p className="text-sm text-primary-600">{t('domain.advancedAiDesc', 'Advanced AI will analyze your inputs and generate tailored recommendations')}</p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="flex justify-end space-x-3 rtl:space-x-reverse">
                  <button 
                    className="px-4 py-2 border border-neutral-200 text-neutral-700 rounded-md hover:bg-neutral-50"
                    onClick={() => setShowAIAnalysisModal(false)}
                  >
                    {t('common.cancel')}
                  </button>
                  <button 
                    className="px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700"
                    onClick={() => {
                      setShowAIAnalysisModal(false);
                      navigate('/domains/1');
                    }}
                  >
                    {t('domain.startAnalysis', 'Start Analysis')}
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </Suspense>
    </ErrorBoundary>
  );
};

export default Dashboard;