import React, { useState, useEffect, useRef } from 'react';
import ResourceLibrary from '../components/ResourceLibrary';
import { BookOpen, FileText, Clock, Grid3X3, LayoutGrid, Tag, Folder, FolderOpen, PanelRight, Layers, Calendar, BarChart2 } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { domains } from '../data';
import { useAppStore } from '../store';

// Define tab types
type TabType = 'all' | 'domains' | 'tasks' | 'timeline' | 'recent';

// Define view mode
type ViewMode = 'grid' | 'list';

// Define time periods for timeline view
type TimePeriod = 'today' | 'week' | 'month' | 'quarter' | 'year';

const ResourcesPage: React.FC = () => {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState<TabType>('all');
  const [viewMode, setViewMode] = useState<ViewMode>('grid');
  const [selectedDomain, setSelectedDomain] = useState<number | null>(null);
  const [selectedTimePeriod, setSelectedTimePeriod] = useState<TimePeriod>('month');
  const [documentStats, setDocumentStats] = useState({
    total: 0,
    domains: 0,
    tasks: 0,
    recent: 0
  });
  const { getActiveProject } = useAppStore();
  
  // Add state to track component mount status
  const [isMounted, setIsMounted] = useState(false);
  const [isReady, setIsReady] = useState(false);
  const mountedRef = useRef(false);
  
  const activeProject = getActiveProject();
  
  // Set up component mount tracking
  useEffect(() => {
    mountedRef.current = true;
    setIsMounted(true);
    
    // Add a small delay to ensure the component is fully rendered
    const timer = setTimeout(() => {
      if (mountedRef.current) {
        setIsReady(true);
      }
    }, 300);
    
    return () => {
      mountedRef.current = false;
      clearTimeout(timer);
    };
  }, []);
  
  // Filter parameters to pass to ResourceLibrary
  const getFilterParams = () => {
    const today = new Date();
    let startDate;
    
    // Calculate dates for timeline filtering
    switch (activeTab === 'timeline' ? selectedTimePeriod : '') {
      case 'today':
        startDate = new Date(today);
        startDate.setHours(0, 0, 0, 0);
        return {
          dateRange: {
            start: startDate.toISOString(),
            end: today.toISOString()
          }
        };
      case 'week':
        startDate = new Date(today);
        startDate.setDate(today.getDate() - 7);
        return {
          dateRange: {
            start: startDate.toISOString(),
            end: today.toISOString()
          }
        };
      case 'month':
        startDate = new Date(today);
        startDate.setMonth(today.getMonth() - 1);
        return {
          dateRange: {
            start: startDate.toISOString(),
            end: today.toISOString()
          }
        };
      case 'quarter':
        startDate = new Date(today);
        startDate.setMonth(today.getMonth() - 3);
        return {
          dateRange: {
            start: startDate.toISOString(),
            end: today.toISOString()
          }
        };
      case 'year':
        startDate = new Date(today);
        startDate.setFullYear(today.getFullYear() - 1);
        return {
          dateRange: {
            start: startDate.toISOString(),
            end: today.toISOString()
          }
        };
    }
    
    // Handle other tabs
    switch (activeTab) {
      case 'domains':
        return { 
          source: 'domain_outputs',
          domainId: selectedDomain || undefined
        };
      case 'tasks':
        return { source: 'tasks' };
      case 'recent':
        return { 
          sortBy: 'date',
          sortDirection: 'desc' as 'desc',
          limit: 10
        };
      case 'all':
      default:
        return {};
    }
  };
  
  // Safe tab switching function
  const handleTabChange = (tab: TabType) => {
    if (!isMounted || !isReady) {
      console.warn('Tab change attempted before component was ready');
      return;
    }
    
    setActiveTab(tab);
    setSelectedDomain(null);
  };
  
  // Safe domain selection function
  const handleDomainSelect = (domainId: number | null) => {
    if (!isMounted || !isReady) {
      console.warn('Domain selection attempted before component was ready');
      return;
    }
    
    setSelectedDomain(domainId);
  };
  
  // Safe time period selection function
  const handleTimePeriodSelect = (period: TimePeriod) => {
    if (!isMounted || !isReady) {
      console.warn('Time period selection attempted before component was ready');
      return;
    }
    
    setSelectedTimePeriod(period);
  };
  
  // Safe view mode toggle function
  const handleViewModeChange = (mode: ViewMode) => {
    if (!isMounted || !isReady) {
      console.warn('View mode change attempted before component was ready');
      return;
    }
    
    setViewMode(mode);
  };
  
  // Update document stats when documents are loaded
  const handleDocumentsLoaded = (docs: any[]) => {
    if (!isMounted || !isReady) return;
    
    const domainDocs = docs.filter(doc => doc.source === 'domain_outputs').length;
    const taskDocs = docs.filter(doc => doc.source === 'tasks').length;
    
    // Get documents from last 7 days
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
    const recentDocs = docs.filter(doc => {
      if (!doc.created_date) return false;
      const docDate = new Date(doc.created_date);
      return docDate >= oneWeekAgo;
    }).length;
    
    setDocumentStats({
      total: docs.length,
      domains: domainDocs,
      tasks: taskDocs,
      recent: recentDocs
    });
  };
  
  // Show loading state if component is not ready
  if (!isReady) {
    return (
      <div className="max-w-7xl mx-auto">
        <div className="bg-gradient-to-r from-primary-600 to-secondary-700 rounded-xl shadow-lg p-6 mb-6 text-white animate-pulse">
          <div className="h-8 w-64 bg-white/20 rounded mb-2"></div>
          <div className="h-4 w-96 bg-white/10 rounded"></div>
        </div>
        <div className="bg-white dark:bg-neutral-800 rounded-xl shadow-sm overflow-hidden p-8">
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-500"></div>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="max-w-7xl mx-auto">
      {/* Header with improved design */}
      <div className="bg-gradient-to-r from-primary-600 to-secondary-700 rounded-xl shadow-lg p-6 mb-6 text-white">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold flex items-center">
              <BookOpen className="me-3 h-8 w-8" />
              {t('resources.resourcesLibrary', 'Project Assets Library')}
            </h1>
            <p className="mt-2 text-white/80 max-w-2xl">
              {t('resources.browseBestPractices', 'Access all your project documents, templates, and outputs in one organized place')}
            </p>
          </div>
          
          <div className="mt-4 md:mt-0 flex items-center space-x-2 bg-white/10 rounded-lg p-1.5">
            <button 
              onClick={() => handleViewModeChange('grid')}
              className={`p-2 rounded-md flex items-center ${viewMode === 'grid' 
                ? 'bg-white text-primary-700' 
                : 'text-white hover:bg-white/20'}`}
            >
              <Grid3X3 className="h-5 w-5" />
            </button>
            <button 
              onClick={() => handleViewModeChange('list')}
              className={`p-2 rounded-md flex items-center ${viewMode === 'list' 
                ? 'bg-white text-primary-700' 
                : 'text-white hover:bg-white/20'}`}
            >
              <LayoutGrid className="h-5 w-5" />
            </button>
          </div>
        </div>
        
        {/* Document stats */}
        <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white/10 rounded-lg p-3 shadow-sm">
            <div className="text-white/80 text-sm">{t('resources.totalAssets', 'Total Assets')}</div>
            <div className="text-white text-xl font-bold">{documentStats.total}</div>
          </div>
          <div className="bg-white/10 rounded-lg p-3 shadow-sm">
            <div className="text-white/80 text-sm">{t('resources.domainOutputs', 'Domain Outputs')}</div>
            <div className="text-white text-xl font-bold">{documentStats.domains}</div>
          </div>
          <div className="bg-white/10 rounded-lg p-3 shadow-sm">
            <div className="text-white/80 text-sm">{t('resources.taskAttachments', 'Task Attachments')}</div>
            <div className="text-white text-xl font-bold">{documentStats.tasks}</div>
          </div>
          <div className="bg-white/10 rounded-lg p-3 shadow-sm">
            <div className="text-white/80 text-sm">{t('resources.lastWeek', 'Last 7 Days')}</div>
            <div className="text-white text-xl font-bold">{documentStats.recent}</div>
          </div>
        </div>
      </div>
      
      {/* Main content area with tabs */}
      <div className="bg-white dark:bg-neutral-800 rounded-xl shadow-sm overflow-hidden">
        {/* Tabs navigation */}
        <div className="flex border-b border-gray-200 dark:border-gray-700 overflow-x-auto scrollbar-thin">
          <button
            className={`py-4 px-6 font-medium flex items-center whitespace-nowrap ${
              activeTab === 'all'
                ? 'border-b-2 border-primary-500 text-primary-600 dark:text-primary-400'
                : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
            onClick={() => handleTabChange('all')}
          >
            <Layers className="h-5 w-5 me-2" />
            {t('resources.allAssets', 'All Assets')}
          </button>
          
          <button
            className={`py-4 px-6 font-medium flex items-center whitespace-nowrap ${
              activeTab === 'domains'
                ? 'border-b-2 border-primary-500 text-primary-600 dark:text-primary-400'
                : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
            onClick={() => handleTabChange('domains')}
          >
            <FolderOpen className="h-5 w-5 me-2" />
            {t('resources.domainOutputs', 'Domain Outputs')}
          </button>
          
          <button
            className={`py-4 px-6 font-medium flex items-center whitespace-nowrap ${
              activeTab === 'tasks'
                ? 'border-b-2 border-primary-500 text-primary-600 dark:text-primary-400'
                : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
            onClick={() => handleTabChange('tasks')}
          >
            <FileText className="h-5 w-5 me-2" />
            {t('resources.taskAttachments', 'Task Attachments')}
          </button>
          
          <button
            className={`py-4 px-6 font-medium flex items-center whitespace-nowrap ${
              activeTab === 'timeline'
                ? 'border-b-2 border-primary-500 text-primary-600 dark:text-primary-400'
                : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
            onClick={() => handleTabChange('timeline')}
          >
            <Calendar className="h-5 w-5 me-2" />
            {t('resources.timeline', 'Timeline')}
          </button>
          
          <button
            className={`py-4 px-6 font-medium flex items-center whitespace-nowrap ${
              activeTab === 'recent'
                ? 'border-b-2 border-primary-500 text-primary-600 dark:text-primary-400'
                : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
            onClick={() => handleTabChange('recent')}
          >
            <Clock className="h-5 w-5 me-2" />
            {t('resources.recentlyAdded', 'Recently Added')}
          </button>
        </div>
        
        {/* Domain selector (only visible when domains tab is active) */}
        {activeTab === 'domains' && (
          <div className="bg-gray-50 dark:bg-gray-700 p-4 border-b border-gray-200 dark:border-gray-700 overflow-x-auto scrollbar-thin">
            <div className="flex items-center space-x-2">
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                {t('resources.filterByDomain', 'Filter by Domain:')}
              </span>
              
              <button
                className={`px-3 py-1.5 text-sm rounded-full ${
                  selectedDomain === null
                    ? 'bg-primary-100 text-primary-700 dark:bg-primary-900 dark:text-primary-300'
                    : 'bg-white dark:bg-gray-600 text-gray-700 dark:text-gray-300 border border-gray-300 dark:border-gray-600'
                }`}
                onClick={() => handleDomainSelect(null)}
              >
                {t('resources.allDomains', 'All Domains')}
              </button>
              
              {domains.map(domain => (
                <button
                  key={domain.id}
                  className={`px-3 py-1.5 text-sm rounded-full whitespace-nowrap ${
                    selectedDomain === domain.id
                      ? 'bg-primary-100 text-primary-700 dark:bg-primary-900 dark:text-primary-300'
                      : 'bg-white dark:bg-gray-600 text-gray-700 dark:text-gray-300 border border-gray-300 dark:border-gray-600'
                  }`}
                  onClick={() => handleDomainSelect(domain.id)}
                >
                  {t(`domains.${domain.id}.name`, domain.name)}
                </button>
              ))}
            </div>
          </div>
        )}
        
        {/* Time period selector (only visible when timeline tab is active) */}
        {activeTab === 'timeline' && (
          <div className="bg-gray-50 dark:bg-gray-700 p-4 border-b border-gray-200 dark:border-gray-700 overflow-x-auto scrollbar-thin">
            <div className="flex items-center space-x-2">
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                {t('resources.filterByPeriod', 'Time Period:')}
              </span>
              
              <button
                className={`px-3 py-1.5 text-sm rounded-full ${
                  selectedTimePeriod === 'today'
                    ? 'bg-primary-100 text-primary-700 dark:bg-primary-900 dark:text-primary-300'
                    : 'bg-white dark:bg-gray-600 text-gray-700 dark:text-gray-300 border border-gray-300 dark:border-gray-600'
                }`}
                onClick={() => handleTimePeriodSelect('today')}
              >
                {t('resources.today', 'Today')}
              </button>
              
              <button
                className={`px-3 py-1.5 text-sm rounded-full ${
                  selectedTimePeriod === 'week'
                    ? 'bg-primary-100 text-primary-700 dark:bg-primary-900 dark:text-primary-300'
                    : 'bg-white dark:bg-gray-600 text-gray-700 dark:text-gray-300 border border-gray-300 dark:border-gray-600'
                }`}
                onClick={() => handleTimePeriodSelect('week')}
              >
                {t('resources.lastWeek', 'Last 7 Days')}
              </button>
              
              <button
                className={`px-3 py-1.5 text-sm rounded-full ${
                  selectedTimePeriod === 'month'
                    ? 'bg-primary-100 text-primary-700 dark:bg-primary-900 dark:text-primary-300'
                    : 'bg-white dark:bg-gray-600 text-gray-700 dark:text-gray-300 border border-gray-300 dark:border-gray-600'
                }`}
                onClick={() => handleTimePeriodSelect('month')}
              >
                {t('resources.lastMonth', 'Last 30 Days')}
              </button>
              
              <button
                className={`px-3 py-1.5 text-sm rounded-full ${
                  selectedTimePeriod === 'quarter'
                    ? 'bg-primary-100 text-primary-700 dark:bg-primary-900 dark:text-primary-300'
                    : 'bg-white dark:bg-gray-600 text-gray-700 dark:text-gray-300 border border-gray-300 dark:border-gray-600'
                }`}
                onClick={() => handleTimePeriodSelect('quarter')}
              >
                {t('resources.lastQuarter', 'Last 3 Months')}
              </button>
              
              <button
                className={`px-3 py-1.5 text-sm rounded-full ${
                  selectedTimePeriod === 'year'
                    ? 'bg-primary-100 text-primary-700 dark:bg-primary-900 dark:text-primary-300'
                    : 'bg-white dark:bg-gray-600 text-gray-700 dark:text-gray-300 border border-gray-300 dark:border-gray-600'
                }`}
                onClick={() => handleTimePeriodSelect('year')}
              >
                {t('resources.lastYear', 'Last Year')}
              </button>
            </div>
          </div>
        )}
        
        {/* Main content */}
        <div className="p-4">
          <ResourceLibrary 
            viewMode={viewMode} 
            filterParams={getFilterParams()} 
            projectId={activeProject?.id}
            onDocumentsLoaded={handleDocumentsLoaded}
          />
        </div>
      </div>
    </div>
  );
};

export default ResourcesPage;