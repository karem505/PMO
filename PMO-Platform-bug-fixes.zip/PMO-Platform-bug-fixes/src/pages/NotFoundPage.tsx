import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Home, Search, ArrowLeft } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const NotFoundPage: React.FC = () => {
  const navigate = useNavigate();
  const { t, isRTL } = useLanguage();

  return (
    <div className="min-h-[calc(100vh-64px)] flex items-center justify-center bg-neutral-50">
      <div className="text-center px-4 max-w-md">
        <div className="relative mb-6">
          <div className="text-9xl font-bold text-neutral-200">404</div>
          <div className="absolute inset-0 flex items-center justify-center">
            <Search className="h-20 w-20 text-primary-500 opacity-70" />
          </div>
        </div>
        
        <h1 className="text-3xl font-bold text-neutral-800 mb-2">{t('notFound.title', 'Page Not Found')}</h1>
        <p className="text-neutral-600 mb-8">
          {t('notFound.description', "The page you're looking for doesn't exist or has been moved.")}
        </p>
        
        <div className={`flex flex-col sm:flex-row items-center justify-center space-y-3 sm:space-y-0 ${isRTL ? 'sm:space-x-reverse sm:space-x-4' : 'sm:space-x-4'}`}>
          <button
            onClick={() => navigate('/')}
            className="px-6 py-3 bg-gradient-to-r from-primary-600 to-secondary-600 text-white rounded-lg hover:from-primary-700 hover:to-secondary-700 transition-all duration-300 shadow-sm w-full sm:w-auto flex items-center justify-center"
          >
            <Home className={`h-5 w-5 ${isRTL ? 'ml-2' : 'mr-2'}`} />
            {t('notFound.goToDashboard', 'Go to Dashboard')}
          </button>
          <button
            onClick={() => navigate(-1)}
            className="px-6 py-3 border border-neutral-200 bg-white text-neutral-700 rounded-lg hover:bg-neutral-50 transition-colors w-full sm:w-auto flex items-center justify-center"
          >
            <ArrowLeft className={`h-5 w-5 ${isRTL ? 'ml-2' : 'mr-2'}`} />
            {t('notFound.goBack', 'Go Back')}
          </button>
        </div>
        
        <div className="mt-12 text-neutral-500">
          <p>{t('notFound.contactSupport', 'If you believe this is an error, please contact support.')}</p>
        </div>
      </div>
    </div>
  );
};

export default NotFoundPage;