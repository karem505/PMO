import React, { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { CheckCircle2, AlertCircle, LogIn } from 'lucide-react';
import Logo from '../components/Logo';
import { useLanguage } from '../contexts/LanguageContext';

const VerifyEmailPage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { t, isRTL } = useLanguage();
  const [verificationStatus, setVerificationStatus] = useState<'loading' | 'success' | 'error'>('loading');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  
  useEffect(() => {
    // This would normally verify the token/code from the URL
    // For demo purposes, we'll simulate the verification
    const searchParams = new URLSearchParams(location.search);
    const oobCode = searchParams.get('oobCode');
    
    // Check if there's a verification code
    if (!oobCode) {
      setVerificationStatus('error');
      setErrorMessage(t('verifyEmail.invalidLink', 'Invalid verification link. Please request a new verification email.'));
      return;
    }
    
    // Simulate API verification process
    const verifyEmail = async () => {
      try {
        // In real implementation, you would call your Firebase verification API
        // await applyActionCode(auth, oobCode);
        
        // Simulate verification (success 90% of the time)
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        if (Math.random() > 0.1) {
          setVerificationStatus('success');
        } else {
          setVerificationStatus('error');
          setErrorMessage(t('verifyEmail.expiredLink', 'Verification link has expired. Please request a new verification email.'));
        }
      } catch (error: any) {
        setVerificationStatus('error');
        setErrorMessage(error.message || t('verifyEmail.verificationError', 'Failed to verify email. Please try again.'));
      }
    };
    
    verifyEmail();
  }, [location.search, t]);
  
  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-50">
      <div className="w-full max-w-md">
        <div className="mb-6 flex justify-center">
          <Logo variant="auth" />
        </div>
        
        <div className="bg-white px-8 py-10 shadow-md rounded-lg text-center">
          {verificationStatus === 'loading' && (
            <>
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
              <h2 className="mt-6 text-xl font-semibold text-gray-800">{t('verifyEmail.verifying', 'Verifying Your Email')}</h2>
              <p className="mt-2 text-gray-600">{t('verifyEmail.pleaseWait', 'Please wait while we verify your email address...')}</p>
            </>
          )}
          
          {verificationStatus === 'success' && (
            <>
              <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-green-100">
                <CheckCircle2 className="h-10 w-10 text-green-600" />
              </div>
              <h2 className="mt-6 text-xl font-semibold text-gray-800">{t('verifyEmail.verificationSuccess', 'Email Successfully Verified!')}</h2>
              <p className="mt-2 text-gray-600">{t('verifyEmail.successMessage', 'Your email has been verified. You can now sign in to your account.')}</p>
              <button
                onClick={() => navigate('/login?emailVerified=true')}
                className="mt-6 w-full flex justify-center items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
              >
                <LogIn className={`${isRTL ? 'ml-2' : 'mr-2'} h-4 w-4`} />
                {t('verifyEmail.signIn', 'Sign In')}
              </button>
            </>
          )}
          
          {verificationStatus === 'error' && (
            <>
              <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-red-100">
                <AlertCircle className="h-10 w-10 text-red-600" />
              </div>
              <h2 className="mt-6 text-xl font-semibold text-gray-800">{t('verifyEmail.verificationFailure', 'Verification Failed')}</h2>
              <p className="mt-2 text-gray-600">{errorMessage || t('verifyEmail.defaultError', 'An error occurred during email verification.')}</p>
              <button
                onClick={() => navigate('/login')}
                className="mt-6 w-full flex justify-center items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
              >
                {t('verifyEmail.tryAgain', 'Try Again')}
              </button>
            </>
          )}
        </div>
        
        <div className="mt-6 text-center">
          <p className="text-sm text-gray-600">
            {t('verifyEmail.troubleMessage', "If you're having trouble with verification, please contact our support team.")}
          </p>
        </div>
      </div>
    </div>
  );
};

export default VerifyEmailPage;