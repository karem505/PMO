import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../components/auth/AuthContext';
import { 
  Shield, 
  Users, 
  Settings, 
  Database, 
  BarChart, 
  Server, 
  Lock,
  Activity,
  ArrowRight,
  BookOpen
} from 'lucide-react';

const AdminPage: React.FC = () => {
  const navigate = useNavigate();
  const { hasRole } = useAuth();
  
  // Redirect if not admin
  React.useEffect(() => {
    if (!hasRole('admin')) {
      navigate('/');
    }
  }, [hasRole, navigate]);

  const adminModules = [
    {
      title: 'User Management',
      description: 'Manage users, assign roles, and handle user accounts',
      icon: Users,
      path: '/admin/users',
      color: 'bg-blue-100 text-blue-600'
    },
    {
      title: 'Roles & Permissions',
      description: 'Configure access control and security policies',
      icon: Shield,
      path: '/admin/roles',
      color: 'bg-purple-100 text-purple-600'
    },
    {
      title: 'System Settings',
      description: 'Configure global application settings',
      icon: Settings,
      path: '/admin/settings',
      color: 'bg-gray-100 text-gray-600'
    },
    {
      title: 'Database Management',
      description: 'View and manage database records',
      icon: Database,
      path: '/admin/database',
      color: 'bg-green-100 text-green-600'
    },
    {
      title: 'Analytics & Reports',
      description: 'View system usage statistics and reports',
      icon: BarChart,
      path: '/admin/analytics',
      color: 'bg-amber-100 text-amber-600'
    },
    {
      title: 'System Health',
      description: 'Monitor system performance and status',
      icon: Activity,
      path: '/admin/health',
      color: 'bg-red-100 text-red-600'
    }
  ];

  return (
    <div className="max-w-6xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold  text-gray-800 flex items-center">
          <Shield className="mr-2 text-primary-600 h-6 w-6" />
          Admin Dashboard
        </h1>
        <p className="text-gray-600 mt-1">
          System administration and management
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {adminModules.map((module, index) => {
          const IconComponent = module.icon;
          
          return (
            <div 
              key={index}
              className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-all duration-200 group"
              onClick={() => navigate(module.path)}
            >
              <div className="p-6">
                <div className={`p-3 rounded-lg ${module.color} w-fit mb-4`}>
                  <IconComponent className="h-6 w-6" />
                </div>
                <h3 className="text-lg font-semibold text-gray-800 mb-2 group-hover:text-primary-700 transition-colors">
                  {module.title}
                </h3>
                <p className="text-gray-600">{module.description}</p>
              </div>
              <div className="px-6 py-4 border-t border-gray-100 flex justify-center">
                <button className="text-primary-600 font-medium flex items-center group-hover:text-primary-800 transition-all">
                  Access Module
                  <ArrowRight className="ml-2 h-4 w-4 transform group-hover:translate-x-1 transition-transform duration-200" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
      
      <div className="bg-white rounded-lg shadow-sm p-6 mt-8 border border-gray-200">
        <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
          <Lock className="h-5 w-5 mr-2 text-primary-600" />
          Security Overview
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-medium text-gray-700">System Access</h3>
              <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">Secure</span>
            </div>
            <p className="text-sm text-gray-600">
              Role-based access control is active with proper permission enforcement
            </p>
          </div>
          
          <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-medium text-gray-700">Authentication</h3>
              <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">Enabled</span>
            </div>
            <p className="text-sm text-gray-600">
              Multi-provider authentication with email and OAuth providers
            </p>
          </div>
          
          <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-medium text-gray-700">Database Security</h3>
              <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">Active</span>
            </div>
            <p className="text-sm text-gray-600">
              Row-level security policies enabled across all tables
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminPage;