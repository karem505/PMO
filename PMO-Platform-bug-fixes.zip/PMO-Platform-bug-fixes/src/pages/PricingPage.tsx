import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../components/auth/AuthContext';
import { CheckCircle, X, ShieldCheck, Zap, Users, Server, AlertCircle, Loader2, Check } from 'lucide-react';
import { SubscriptionTier, TIER_FEATURES, PRICING } from '../services/subscriptionService';
import Logo from '../components/Logo';
import { useLanguage } from '../contexts/LanguageContext';
import { useSubscription } from '../contexts/SubscriptionContext';
import axios from 'axios';
import PaymentForm from '../components/PaymentForm';
import apiClient from '../api/client';

const PricingPage: React.FC = () => {
  const { t, isRTL } = useLanguage();
  const { currentUser, isLoading } = useAuth();
  const { tier } = useSubscription();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const utm_source = searchParams.get('utm_source');
  const utm_campaign = searchParams.get('utm_campaign');
  const feature = searchParams.get('feature');

  const [annual, setAnnual] = useState<boolean>(true);
  const [processingTier, setProcessingTier] = useState<SubscriptionTier | null>(null);
  const [paymentTier, setPaymentTier] = useState<SubscriptionTier | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [haveSubscription, setHaveSubscription] = useState<boolean>(false);
  const [paymentSession, setPaymentSession] = useState<{
    sessionId: string;
    amount: number | string;
    description: string;
    currency: string;
  } | null>(null);

  // Reset any error or success message when billing period changes
  useEffect(() => {
    setError(null);
    setSuccess(null);
  }, [annual]);
  console.log({currentUser})
  const IsHaveSubscription = async () => {
    if(!currentUser) return;
    const response = await apiClient.get(`/subscription/check-premium?user_email=${currentUser?.email}`);
    if(response.data.is_premium){
      setHaveSubscription(true);
    }
  }
  useEffect(() => {
    IsHaveSubscription();
  }, [currentUser?.email]);
  // Handle subscription selection
  const handleSelectSubscription = async (tier: SubscriptionTier) => {
    if (!currentUser) {
      // Save selected plan in session storage and redirect to login
      sessionStorage.setItem('selectedPlan', JSON.stringify({
        tier,
        annual,
        redirectFrom: 'pricing'
      }));
      navigate('/login?redirect=/pricing');
      return;
    }

    // Skip for free tier
    if (tier === SubscriptionTier.FREE) {
      setProcessingTier(SubscriptionTier.FREE);
      try {
        const response = await apiClient.post('/subscription/setup-free',null,{
          params:{
            user_email: currentUser?.email
          }
        })
      if(response.status === 200){
        setHaveSubscription(true);
        setSuccess('You are now on the Free tier!');
        setTimeout(() => {
          navigate('/dashboard');
        }, 1500);
      }
      } catch (error) {
        console.error('Error setting up free subscription:', error);
      } finally {
        setProcessingTier(null);
      }
      return;
    }

    setProcessingTier(tier);
    setError(null);
    setPaymentTier(tier);
    console.log({tier})
    try {
      // Get price based on selected tier and billing period
      const price = annual 
        ? (PRICING[tier].annual/12).toFixed(2) 
        : PRICING[tier].monthly.toFixed(2);
      
      // تأكد من أن البيانات يتم إرسالها في جسم الطلب بتنسيق صحيح
      const response = await axios.post(`${import.meta.env.VITE_API_BASE_URL}/mpgs/initiate`, {
        amount: price,
        currency: 'USD',
        description: `Subscription to ${tier} tier (${annual ? 'annual' : 'monthly'})`,
        orderId: `order_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      });
      console.log(response.data)
      const sessionId = response.data.session.id;
      setProcessingTier(null);
      if(sessionId){
      // Set the payment session details to render the payment form
      setPaymentSession({
        sessionId,
        amount: price,
        currency: 'USD',
        description: `Subscription to ${tier} tier (${annual ? 'annual' : 'monthly'})`
      });
      }
    } catch (error: any) {
      console.error('Subscription error:', error);
      setError(error.message || 'An unexpected error occurred');
      setProcessingTier(null);
    }
  };

  // Check for payment status from URL params
  useEffect(() => {
    const subscription = searchParams.get('subscription');
    if (subscription === 'success') {
      setSuccess('Your subscription has been activated successfully!');
      setTimeout(() => {
        navigate('/dashboard', { replace: true });
      }, 2000);
    } else if (subscription === 'canceled') {
      setError('Your payment was canceled. You can try again when you\'re ready.');
    }
  }, [searchParams, navigate]);

  useEffect(() => {
    if (!document.getElementById('bank-masr-checkout-script')) {
      try {
        const script = document.createElement('script');
        script.id = 'bank-masr-checkout-script';
        script.src = 'https://banquemisr.gateway.mastercard.com/checkout/version/72/checkout.js';
        script.async = true;
        
        // Check if document.body exists before appending
        if (document && document.body) {
          document.body.appendChild(script);
        }
        
        // Add error handling for the script
        script.onerror = (error) => {
          console.error('Error loading payment script:', error);
          setError('Payment system unavailable. Please try again later.');
        };
      } catch (error) {
        console.error('Error setting up payment script:', error);
        setError('Payment system unavailable. Please try again later.');
      }
    }
  }, []);
  // Format price with currency
  const formatPrice = (price: number, currency: string = 'USD'): string => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency,
      minimumFractionDigits: 2
    }).format(price);
  };

  // Format annual pricing for display in two formats (monthly and annual total)
  const formatAnnualPrice = (monthlyPrice: number, monthsMultiplier: number = 12) => {
    const annualTotal = monthlyPrice * monthsMultiplier;
    return formatPrice(annualTotal);
  };

  // Show highlighted feature notification if applicable
  const renderFeatureHighlight = () => {
    if (!feature) return null;

    let featureText = '';
    switch (feature) {
      case 'projects':
        featureText = 'more projects';
        break;
      case 'aiAnalysis':
        featureText = 'more AI analyses';
        break;
      case 'storage':
        featureText = 'more storage space';
        break;
      case 'users':
        featureText = 'team collaboration';
        break;
      default:
        featureText = feature.replace(/([A-Z])/g, ' $1').toLowerCase();
    }

    return (
      <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
        <div className="flex items-start">
          <AlertCircle className="h-5 w-5 text-blue-500 mt-0.5 mr-2 flex-shrink-0" />
          <div>
            <p className="text-sm text-blue-800 font-medium">
              Upgrade to get {featureText}
            </p>
            <p className="text-xs text-blue-600 mt-1">
              You've reached the limit on your current plan. Upgrade now to unlock more capabilities!
            </p>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* Header */}
      <header className="px-4 py-6 mx-auto max-w-7xl">
        <div className="flex items-center justify-between">
          <Logo />
          <div className="flex items-center space-x-4">
            {!currentUser && !isLoading && (
              <>
                <button 
                  className="px-4 py-2 text-gray-700 transition-colors bg-white rounded-lg shadow-sm hover:bg-gray-50"
                  onClick={() => navigate('/login')}
                >
                  {t('common.signIn', 'Sign in')}
                </button>
                <button 
                  className="px-4 py-2 text-white transition-colors rounded-lg shadow-sm bg-primary-600 hover:bg-primary-700"
                  onClick={() => navigate('/register')}
                >
                  {t('subscription.getStarted', 'Get Started')}
                </button>
              </>
            )}
            {currentUser && (
              <button
                className="px-4 py-2 text-white transition-colors rounded-lg shadow-sm bg-primary-600 hover:bg-primary-700"
                onClick={() => navigate('/dashboard')}
              >
                {t('common.dashboard', 'Dashboard')}
              </button>
            )}
          </div>
        </div>
      </header>

      <main className="px-4 py-12 mx-auto max-w-7xl">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl md:text-5xl">
            {t('subscription.simpleTransparentPricing', 'Simple, Transparent Pricing')}
          </h1>
          <p className="max-w-2xl mx-auto mt-4 text-xl text-gray-600">
            {t('subscription.chooseThePerfectPlan', 'Choose the perfect plan for your PMO implementation needs')}
          </p>

          {/* Period Toggle */}
          <div className={`flex items-center justify-center mt-8 ${isRTL ? 'space-x-reverse space-x-3' : 'space-x-3'}`}>
            {isRTL ? (
              <>
                <span className={`text-sm font-medium ${annual ? 'text-gray-900' : 'text-gray-500'}`}>
                  {t('subscription.annualSave50', 'Annual')} <span className="px-1.5 py-0.5 text-xs bg-green-100 text-green-800 rounded-full">{t('subscription.save50', 'Save 50%')}</span>
                </span>
                <button
                  type="button"
                  className={`relative inline-flex h-6 w-12 items-center rounded-full ${annual ? 'bg-primary-600' : 'bg-gray-300'}`}
                  onClick={() => setAnnual(!annual)}
                >
                  <span
                    className={`inline-block h-5 w-5 rounded-full bg-white ${annual ? 'translate-x-6' : 'translate-x-1'} transition`}
                  />
                </button>
                <span className={`text-sm font-medium ${annual ? 'text-gray-500' : 'text-gray-900'}`}>
                  {t('subscription.monthly', 'Monthly')}
                </span>
              </>
            ) : (
              <>
                <span className={`text-sm font-medium ${annual ? 'text-gray-500' : 'text-gray-900'}`}>
                  {t('subscription.monthly', 'Monthly')}
                </span>
                <button
                  type="button"
                  className={`relative inline-flex h-6 w-12 items-center rounded-full ${annual ? 'bg-primary-600' : 'bg-gray-300'}`}
                  onClick={() => setAnnual(!annual)}
                >
                  <span
                    className={`inline-block h-5 w-5 rounded-full bg-white ${annual ? 'translate-x-6' : 'translate-x-1'} transition`}
                  />
                </button>
                <span className={`text-sm font-medium ${annual ? 'text-gray-900' : 'text-gray-500'}`}>
                  {t('subscription.annualSave50', 'Annual')} <span className="px-1.5 py-0.5 text-xs bg-green-100 text-green-800 rounded-full">{t('subscription.save50', 'Save 50%')}</span>
                </span>
              </>
            )}
          </div>

          {/* Error and Success Messages */}
          {error && (
            <div className="mt-6 p-4 bg-red-50 border border-red-200 rounded-lg mx-auto max-w-md">
              <div className="flex items-start">
                <X className="h-5 w-5 text-red-500 mt-0.5 mr-2 flex-shrink-0" />
                <div>
                  <p className="text-sm text-red-800">{error}</p>
                </div>
              </div>
            </div>
          )}

          {success && (
            <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg mx-auto max-w-md">
              <div className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                <div>
                  <p className="text-sm text-green-800">{success}</p>
                </div>
              </div>
            </div>
          )}

          {/* Feature Highlight */}
          {renderFeatureHighlight()}
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 gap-5 mt-12 md:grid-cols-2 lg:grid-cols-3">
          {/* Free Tier */}
          <div className="relative rounded-lg shadow-sm overflow-hidden border border-gray-200">
            <div className="px-6 py-8 bg-white sm:p-10 sm:pb-6">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 sm:text-xl">
                  {t('subscription.free', 'Free')}
                </h3>
                <div className="mt-4 flex items-baseline text-5xl font-extrabold text-gray-900">
                  {t('subscription.free', 'Free')}
                </div>
                <p className="mt-5 text-md text-gray-500">
                  {t('subscription.getStartedWithBasicPMOTools', 'Get started with basic PMO tools')}
                </p>
              </div>
            </div>
            <div className="px-6 pt-6 pb-8 bg-gray-50 sm:px-10 sm:py-8 h-full">
              <ul className="space-y-4">
                {TIER_FEATURES[SubscriptionTier.FREE].map((feature, index) => (
                  <li key={index} className="flex items-start">
                    <div className="flex-shrink-0">
                      <Check className="h-5 w-5 text-green-500" />
                    </div>
                    <p className="ml-3 text-sm text-gray-700">{t(`subscription.features.${feature.toLowerCase().replace(/\s+/g, '_')}`, feature)}</p>
                  </li>
                ))}
              </ul>
              {/* Free tier has no button */}
            </div>
          </div>

          {/* Premium/Pro Tier - Hide if user already has this tier */}
          {tier !== SubscriptionTier.PREMIUM && (
            <div className="relative rounded-lg shadow-lg overflow-hidden border-2 border-primary-600 transform hover:scale-105 transition-transform duration-300 z-10">
              <div className="absolute top-0 w-full">
                <div className="bg-primary-600 text-center py-1.5 text-sm font-medium text-white">
                  {t('subscription.mostPopular', 'Most Popular')}
                </div>
              </div>
              <div className="px-6 py-8 bg-white sm:p-10 sm:pb-6 pt-12">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 inline-flex items-center sm:text-xl">
                    {t('subscription.premium', 'Premium')}
                    <span className="ml-2 bg-gradient-to-r from-primary-500 to-secondary-500 text-white text-xs px-2 py-0.5 rounded-full">
                      Pro
                    </span>
                  </h3>
                  <div className="mt-4 flex items-baseline text-5xl font-extrabold text-gray-900">
                    {annual ? formatPrice(19.90) : formatPrice(PRICING[SubscriptionTier.PREMIUM].monthly)}
                    <span className="ml-1 text-xl font-medium text-gray-500">{t('subscription.perMonth', '/month')}</span>
                  </div>
                  {annual && (
                    <p className="mt-1 text-sm text-green-600">
                      {t('common.billedAnnually', 'Billed annually')} ({formatAnnualPrice(19.90)}{t('subscription.perYear', '/year')})
                    </p>
                  )}
                  {!annual && (
                    <p className="mt-1 text-sm text-gray-600">
                      {formatAnnualPrice(PRICING[SubscriptionTier.PREMIUM].monthly)}{t('subscription.perYear', '/year')}
                    </p>
                  )}
                  <p className="mt-5 text-md text-gray-500">
                    {t('subscription.perfectForSmallToMediumPMOs', 'Perfect for small to medium PMOs')}
                  </p>
                </div>
              </div>
              <div className="px-6 pt-6 pb-8 bg-gray-50 sm:px-10 sm:py-8">
                <ul className="space-y-4">
                  {TIER_FEATURES[SubscriptionTier.PREMIUM].map((feature, index) => (
                    <li key={index} className="flex items-start">
                      <div className="flex-shrink-0">
                        <Check className="h-5 w-5 text-green-500" />
                      </div>
                      <p className="ml-3 text-sm text-gray-700">{t(`subscription.features.${feature.toLowerCase().replace(/\s+/g, '_')}`, feature)}</p>
                    </li>
                  ))}
                </ul>
                <div className="mt-6">
                  <button
                    className="w-full px-4 py-2.5 shadow-sm text-sm font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700 focus:outline-none"
                    onClick={() => handleSelectSubscription(SubscriptionTier.PREMIUM)}
                    disabled={processingTier !== null}
                  >
                    {processingTier === SubscriptionTier.PREMIUM ? (
                      <Loader2 className="h-5 w-5 animate-spin mx-auto" />
                    ) : (
                      t('subscription.getStarted', 'Get Started')
                    )}
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Enterprise Tier - Hide if user already has this tier */}
          {tier !== SubscriptionTier.ENTERPRISE && (
            <div className="relative rounded-lg shadow-sm overflow-hidden border border-gray-200">
              <div className="px-6 py-8 bg-white sm:p-10 sm:pb-6">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 inline-flex items-center sm:text-xl">
                    {t('subscription.enterprise', 'Enterprise')}
                    <span className="ml-2 bg-gradient-to-r from-primary-700 to-secondary-800 text-white text-xs px-2 py-0.5 rounded-full">
                      Unlimited
                    </span>
                  </h3>
                  <div className="mt-4 flex items-baseline text-5xl font-extrabold text-gray-900">
                    {annual ? formatPrice(49.90) : formatPrice(PRICING[SubscriptionTier.ENTERPRISE].monthly)}
                    <span className="ml-1 text-xl font-medium text-gray-500">{t('subscription.perMonth', '/month')}</span>
                  </div>
                  {annual && (
                    <p className="mt-1 text-sm text-green-600">
                      {t('common.billedAnnually', 'Billed annually')} ({formatAnnualPrice(49.90)}{t('subscription.perYear', '/year')})
                    </p>
                  )}
                  {!annual && (
                    <p className="mt-1 text-sm text-gray-600">
                      {formatAnnualPrice(PRICING[SubscriptionTier.ENTERPRISE].monthly)}{t('subscription.perYear', '/year')}
                    </p>
                  )}
                  <p className="mt-5 text-md text-gray-500">
                    {t('subscription.forOrganizationsThatNeedItAll', 'For organizations that need it all')}
                  </p>
                </div>
              </div>
              <div className="px-6 pt-6 pb-8 bg-gray-50 sm:px-10 sm:py-8">
                <ul className="space-y-4">
                  {TIER_FEATURES[SubscriptionTier.ENTERPRISE].map((feature, index) => (
                    <li key={index} className="flex items-start">
                      <div className="flex-shrink-0">
                        <Check className="h-5 w-5 text-green-500" />
                      </div>
                      <p className="ml-3 text-sm text-gray-700">{t(`subscription.features.${feature.toLowerCase().replace(/\s+/g, '_')}`, feature)}</p>
                    </li>
                  ))}
                </ul>
                <div className="mt-6">
                  <button
                    className="w-full px-4 py-2.5 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none"
                    onClick={() => handleSelectSubscription(SubscriptionTier.ENTERPRISE)}
                    disabled={processingTier !== null}
                  >
                    {processingTier === SubscriptionTier.ENTERPRISE ? (
                      <Loader2 className="h-5 w-5 animate-spin mx-auto" />
                    ) : (
                      t('subscription.getStarted', 'Get Started')
                    )}
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Feature Comparison */}
        <div className="mt-16 pb-20 md:pb-10">
          <h2 className="text-2xl font-bold text-gray-900 text-center mb-8">
            {t('subscription.detailedFeatureComparison', 'Detailed Feature Comparison')}
          </h2>
          
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200 border border-gray-200 rounded-lg">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    {t('subscription.features', 'Features')}
                  </th>
                  <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                    {t('subscription.free', 'Free')}
                  </th>
                  <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-primary-600 uppercase tracking-wider bg-primary-50 border-x border-primary-100">
                    {t('subscription.premium', 'Premium')}
                  </th>
                  <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                    {t('subscription.enterprise', 'Enterprise')}
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 flex items-center">
                    <Zap className="h-5 w-5 text-yellow-500 mr-2 flex-shrink-0" />
                    <span className="min-w-[120px]">{t('subscription.projects', 'Projects')}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">
                    {t('subscription.upTo3', 'Up to 3')}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-center font-medium bg-primary-50 border-x border-primary-100">
                    {t('subscription.upTo20', 'Up to 20')}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">
                    {t('common.unlimited', 'Unlimited')}
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 flex items-center">
                    <ShieldCheck className="h-5 w-5 text-blue-500 mr-2 flex-shrink-0" />
                    <span className="min-w-[120px]">{t('subscription.aiAnalysis', 'AI Analysis')}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">
                    {t('subscription.threePerMonth', '3 / month')}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-center font-medium bg-primary-50 border-x border-primary-100">
                    {t('subscription.hundredPerMonth', '100 / month')}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">
                    {t('common.unlimited', 'Unlimited')}
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 flex items-center">
                    <Users className="h-5 w-5 text-indigo-500 mr-2 flex-shrink-0" />
                    <span className="min-w-[120px]">{t('subscription.teamMembers', 'Team Members')}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">
                    {t('subscription.oneUser', '1 user')}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-center font-medium bg-primary-50 border-x border-primary-100">
                    {t('subscription.upTo5Users', 'Up to 5 users')}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">
                    {t('common.unlimited', 'Unlimited')}
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 flex items-center">
                    <Server className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                    <span className="min-w-[120px]">{t('subscription.storage', 'Storage')}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">
                    {t('subscription.twoFiftyMB', '250 MB')}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-center font-medium bg-primary-50 border-x border-primary-100">
                    {t('subscription.fiveGB', '5 GB')}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">
                    {t('subscription.fiftyGB', '50 GB')}
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 flex items-center">
                    <ShieldCheck className="h-5 w-5 text-purple-500 mr-2 flex-shrink-0" />
                    <span className="min-w-[120px]">{t('subscription.whiteLabelingLower', 'White Labeling')}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-center">
                    <X className="h-5 w-5 text-red-500 mx-auto" />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-center bg-primary-50 border-x border-primary-100">
                    <X className="h-5 w-5 text-red-500 mx-auto" />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-center">
                    <Check className="h-5 w-5 text-green-500 mx-auto" />
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 flex items-center">
                    <Zap className="h-5 w-5 text-amber-500 mr-2 flex-shrink-0" />
                    <span className="min-w-[120px]">{t('subscription.prioritySupportLower', 'Priority Support')}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-center">
                    <X className="h-5 w-5 text-red-500 mx-auto" />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-center bg-primary-50 border-x border-primary-100">
                    <Check className="h-5 w-5 text-green-500 mx-auto" />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-center">
                    <Check className="h-5 w-5 text-green-500 mx-auto" />
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* FAQ */}
        <div className="mt-16">
          <h2 className="text-2xl font-bold text-gray-900 text-center">
            {t('subscription.frequentlyAskedQuestions', 'Frequently Asked Questions')}
          </h2>
          
          <div className="mt-8 grid gap-6 md:grid-cols-2">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-lg font-medium text-gray-900">{t('subscription.canIChangePlansLater', 'Can I change plans later?')}</h3>
              <p className="mt-2 text-gray-600">
                {t('subscription.canIChangePlansLaterAnswer', 'Yes, you can upgrade or downgrade your plan at any time. Changes take effect at your next billing cycle.')}
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-lg font-medium text-gray-900">{t('subscription.howDoesBillingWork', 'How does billing work?')}</h3>
              <p className="mt-2 text-gray-600">
                {t('subscription.howDoesBillingWorkAnswer', 'You can choose between monthly or annual billing. Annual plans offer a 50% discount compared to monthly billing.')}
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-lg font-medium text-gray-900">{t('subscription.whatHappensIfIReachMyUsageLimit', 'What happens if I reach my usage limit?')}</h3>
              <p className="mt-2 text-gray-600">
                {t('subscription.whatHappensIfIReachMyUsageLimitAnswer', 'You\'ll receive a notification when you\'re approaching your limits. To continue using those features, you\'ll need to upgrade to a higher tier.')}
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-lg font-medium text-gray-900">{t('subscription.isThereAFreeTrialForPaidPlans', 'Is there a free trial for paid plans?')}</h3>
              <p className="mt-2 text-gray-600">
                {t('subscription.isThereAFreeTrialForPaidPlansAnswer', 'Yes, we offer a 14-day free trial for Premium and Enterprise plans. You can explore all features before being charged.')}
              </p>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-16">
        <div className="max-w-7xl mx-auto py-12 px-4 overflow-hidden sm:px-6 lg:px-8">
          <p className="mt-8 text-center text-gray-500">
            &copy; {new Date().getFullYear()} {t('common.pmoBuilder', 'PMO Builder')} 
            <span className="ml-2 bg-primary-600 text-white px-2 py-1 rounded text-xs font-medium">
              {t('common.poweredByAI', 'Powered by AI')}
            </span>
            {' '}{t('common.allRightsReserved', 'All rights reserved.')}
          </p>
        </div>
      </footer>

      {/* Add this somewhere in your JSX where you want to show the payment form */}
      {paymentSession && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="relative w-full max-w-xl">
            <button 
              onClick={() => {
                setPaymentSession(null);
                setPaymentTier(null);
              }} 
              className="absolute top-10 right-0 text-primary-600 rounded-2xl p-2"
            >
              <X className="h-6 w-6" />
            </button>
            <div className="bg-white rounded-lg shadow-xl overflow-hidden">
              {error ? (
                <div className="p-6 text-center">
                  <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">Payment Error</h3>
                  <p className="text-gray-600 mb-4">{error}</p>
                  <button
                    onClick={() => {
                      setPaymentSession(null);
                      setPaymentTier(null);
                      setError(null);
                    }}
                    className="px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700"
                  >
                    Try Again Later
                  </button>
                </div>
              ) : (
                <PaymentForm 
                  sessionId={paymentSession.sessionId}
                  amount={paymentSession.amount}
                  currency={paymentSession.currency}
                  description={paymentSession.description}
                  paymentTier={paymentTier}
                  setPaymentSession={setPaymentSession}
                  onPaymentSuccess={(details) => {
                    setSuccess('Your subscription has been activated successfully!');
                  }}
                />
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PricingPage;