/**
 * Utility functions for safely handling data in the application
 */

/**
 * Ensures a value is an array, converting single items to arrays
 * and providing a default for null/undefined values
 * 
 * @param value The value to ensure is an array
 * @param defaultValue The default value if input is null/undefined (default: [])
 * @returns The value as an array
 */
export function ensureArray<T>(value: T | T[] | null | undefined, defaultValue: T[] = []): T[] {
  if (value === null || value === undefined) {
    return defaultValue;
  }
  
  return Array.isArray(value) ? value : [value];
}

/**
 * Provides a default value if the input is null, undefined, or empty string
 * 
 * @param value The input value
 * @param defaultValue The default value to use
 * @returns The input value or the default
 */
export function defaultIfEmpty<T>(value: T | null | undefined, defaultValue: T): T {
  if (value === null || value === undefined || value === '') {
    return defaultValue;
  }
  return value;
}

/**
 * Safely converts a value to a number, with a default value if conversion fails
 * 
 * @param value The value to convert
 * @param defaultValue The default value if conversion fails (default: 0)
 * @returns The converted number or default value
 */
export function toNumber(value: any, defaultValue = 0): number {
  if (value === null || value === undefined || value === '') {
    return defaultValue;
  }
  
  const num = Number(value);
  return isNaN(num) ? defaultValue : num;
}

/**
 * Safely converts a value to a boolean
 * 
 * @param value The value to convert
 * @param defaultValue The default value if conversion is ambiguous (default: false)
 * @returns The boolean value
 */
export function toBoolean(value: any, defaultValue = false): boolean {
  if (value === null || value === undefined) {
    return defaultValue;
  }
  
  if (typeof value === 'boolean') {
    return value;
  }
  
  if (typeof value === 'string') {
    const lowercased = value.toLowerCase().trim();
    if (lowercased === 'true' || lowercased === 'yes' || lowercased === '1') {
      return true;
    }
    if (lowercased === 'false' || lowercased === 'no' || lowercased === '0') {
      return false;
    }
  }
  
  if (typeof value === 'number') {
    return value !== 0;
  }
  
  return defaultValue;
}

/**
 * Safely truncates a string to a maximum length with an optional suffix
 * 
 * @param str The string to truncate
 * @param maxLength The maximum length
 * @param suffix The suffix to add if truncated (default: '...')
 * @returns The truncated string
 */
export function truncateString(str: string | null | undefined, maxLength: number, suffix = '...'): string {
  if (str === null || str === undefined) {
    return '';
  }
  
  if (str.length <= maxLength) {
    return str;
  }
  
  return str.substring(0, maxLength - suffix.length) + suffix;
}

/**
 * Safely formats a date string or object to a localized string
 * 
 * @param date The date to format
 * @param options The Intl.DateTimeFormat options
 * @param fallback The fallback string if date is invalid (default: '')
 * @returns The formatted date string
 */
export function formatDate(
  date: Date | string | number | null | undefined,
  options: Intl.DateTimeFormatOptions = { 
    year: 'numeric', 
    month: 'short', 
    day: 'numeric' 
  },
  fallback = ''
): string {
  if (date === null || date === undefined) {
    return fallback;
  }
  
  try {
    const dateObj = date instanceof Date ? date : new Date(date);
    if (isNaN(dateObj.getTime())) {
      return fallback;
    }
    return new Intl.DateTimeFormat('en-US', options).format(dateObj);
  } catch (error) {
    console.error('Error formatting date:', error);
    return fallback;
  }
}

/**
 * Safely removes null and undefined values from an object
 * 
 * @param obj The object to clean
 * @returns A new object without null/undefined values
 */
export function removeNullish<T extends Record<string, any>>(obj: T): Partial<T> {
  if (!obj || typeof obj !== 'object') {
    return {};
  }
  
  return Object.entries(obj).reduce((acc, [key, value]) => {
    if (value !== null && value !== undefined) {
      acc[key as keyof T] = value;
    }
    return acc;
  }, {} as Partial<T>);
}

/**
 * Safely picks specified properties from an object
 * 
 * @param obj The source object
 * @param keys The keys to pick
 * @returns A new object with only the specified keys
 */
export function pick<T extends Record<string, any>, K extends keyof T>(
  obj: T | null | undefined, 
  keys: K[]
): Pick<T, K> {
  if (!obj) {
    return {} as Pick<T, K>;
  }
  
  return keys.reduce((acc, key) => {
    if (key in obj) {
      acc[key] = obj[key];
    }
    return acc;
  }, {} as Pick<T, K>);
}

/**
 * Safely omits specified properties from an object
 * 
 * @param obj The source object
 * @param keys The keys to omit
 * @returns A new object without the specified keys
 */
export function omit<T extends Record<string, any>, K extends keyof T>(
  obj: T | null | undefined, 
  keys: K[]
): Omit<T, K> {
  if (!obj) {
    return {} as Omit<T, K>;
  }
  
  return Object.entries(obj).reduce((acc, [key, value]) => {
    if (!keys.includes(key as K)) {
      acc[key as keyof Omit<T, K>] = value;
    }
    return acc;
  }, {} as Omit<T, K>);
}

export default {
  ensureArray,
  defaultIfEmpty,
  toNumber,
  toBoolean,
  truncateString,
  formatDate,
  removeNullish,
  pick,
  omit
}; 