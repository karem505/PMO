import { AxiosError } from 'axios';

/**
 * Interface for standardized error response
 */
export interface ErrorResponse {
  message: string;
  code?: string | number;
  details?: Record<string, any>;
  originalError?: unknown;
}

/**
 * Safely extracts an error message from various error types
 * @param error Any error object
 * @returns A standardized error message string
 */
export function getErrorMessage(error: unknown): string {
  if (!error) {
    return 'An unknown error occurred';
  }
  
  // Handle string errors
  if (typeof error === 'string') {
    return error;
  }
  
  // Handle Error objects
  if (error instanceof Error) {
    return error.message || error.toString();
  }
  
  // Handle Axios errors
  if (isAxiosError(error)) {
    // Try to get detailed error from response data
    const responseData = error.response?.data;
    
    if (responseData) {
      if (typeof responseData === 'string') {
        return responseData;
      }
      
      if (typeof responseData === 'object') {
        // Check common error message fields
        const message = 
          responseData.message || 
          responseData.error || 
          responseData.errorMessage ||
          responseData.error_message ||
          responseData.error_description;
          
        if (message && typeof message === 'string') {
          return message;
        }
      }
    }
    
    // Fallback to status text or generic message
    return error.response?.statusText || 
           `Request failed with status ${error.response?.status || 'unknown'}`;
  }
  
  // Handle objects with message property
  if (typeof error === 'object' && error !== null) {
    const errorObj = error as Record<string, any>;
    
    if (typeof errorObj.message === 'string') {
      return errorObj.message;
    }
    
    if (typeof errorObj.error === 'string') {
      return errorObj.error;
    }
  }
  
  // Last resort: stringify the error
  try {
    return JSON.stringify(error);
  } catch {
    return 'An unknown error occurred';
  }
}

/**
 * Type guard for Axios errors
 */
export function isAxiosError(error: unknown): error is AxiosError {
  return (
    typeof error === 'object' && 
    error !== null && 
    'isAxiosError' in error && 
    (error as AxiosError).isAxiosError === true
  );
}

/**
 * Formats an error into a standardized error response object
 * @param error Any error object
 * @returns A standardized error response
 */
export function formatError(error: unknown): ErrorResponse {
  const message = getErrorMessage(error);
  const formattedError: ErrorResponse = { message };
  
  // Add error code if available
  if (isAxiosError(error) && error.response?.status) {
    formattedError.code = error.response.status;
  } else if (typeof error === 'object' && error !== null) {
    const errorObj = error as Record<string, any>;
    if (errorObj.code) {
      formattedError.code = errorObj.code;
    }
  }
  
  // Add error details if available
  if (isAxiosError(error) && error.response?.data) {
    formattedError.details = error.response.data;
  }
  
  // Store original error for debugging
  formattedError.originalError = error;
  
  return formattedError;
}

/**
 * Safely access nested properties in an object
 * @param obj The object to access
 * @param path The path to the property, using dot notation
 * @param defaultValue The default value to return if the property doesn't exist
 * @returns The value at the path or the default value
 */
export function safeGet<T>(
  obj: any, 
  path: string, 
  defaultValue: T
): T {
  if (!obj || !path) {
    return defaultValue;
  }
  
  const keys = path.split('.');
  let result = obj;
  
  for (const key of keys) {
    if (result === undefined || result === null) {
      return defaultValue;
    }
    result = result[key];
  }
  
  return (result === undefined || result === null) ? defaultValue : result as T;
}

/**
 * Safely executes a function and catches any errors
 * @param fn The function to execute
 * @param fallbackValue The value to return if the function throws an error
 * @returns The result of the function or the fallback value
 */
export function tryCatch<T>(fn: () => T, fallbackValue: T): T {
  try {
    return fn();
  } catch (error) {
    console.error('Error in tryCatch:', error);
    return fallbackValue;
  }
}

/**
 * Safely parses JSON with error handling
 * @param jsonString The JSON string to parse
 * @param fallbackValue The value to return if parsing fails
 * @returns The parsed object or the fallback value
 */
export function safeJsonParse<T>(jsonString: string, fallbackValue: T): T {
  try {
    return JSON.parse(jsonString) as T;
  } catch (error) {
    console.error('Error parsing JSON:', error);
    return fallbackValue;
  }
}

export default {
  getErrorMessage,
  isAxiosError,
  formatError,
  safeGet,
  tryCatch,
  safeJsonParse
}; 