import axios, { AxiosError, AxiosRequestConfig } from 'axios';
import { supabase } from '../services/supabaseClient';
import axiosRetry from 'axios-retry';

// Set the base URL from environment variables or fallback to localhost
export const baseURL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:10000';

const apiClient = axios.create({
  baseURL,
  timeout: 60000, // 60 seconds
  headers: {
    'Content-Type': 'application/json',
  },
});

// Configure retry logic for requests that fail due to network issues
axiosRetry(apiClient, {
  retries: 3, // Default retries
  retryDelay: (retryCount, error) => {
    // Increase retry delay for specific endpoints
    if (error?.config?.url?.includes('/pmo/recommendations')) {
      return retryCount * 5000; // Much longer delay for recommendations (5s, 10s, 15s)
    }
    return retryCount * 1000; // Standard delay (1s, 2s, 3s)
  },
  retryCondition: (error: AxiosError): boolean => {
    // Retry on network errors, 5xx responses, 429 (rate limit), and timeout errors
    return (
      axiosRetry.isNetworkOrIdempotentRequestError(error) ||
      (error.response?.status || 0) >= 500 ||
      error.response?.status === 429 ||
      error.code === 'ECONNABORTED' // Retry on timeout
    );
  },
  onRetry: (retryCount: number, error: AxiosError, requestConfig: AxiosRequestConfig) => {
    console.log(`Retry attempt ${retryCount} for ${requestConfig.url}`, error.message);
  },
});

// Add a request interceptor to include auth token
apiClient.interceptors.request.use(async (config) => {
  try {
    // Special handling for various endpoints with longer timeouts
    if (config.url?.includes('/pmo/recommendations')) {
      config.timeout = 1500000; // 25 minutes for recommendations (can take up to 20 minutes)
    } else if (config.url?.includes('/documents/completed-tasks')) {
      config.timeout = 120000; // 2 minutes for task completion checks
    } else if (config.url?.includes('/documents/upload')) {
      config.timeout = 180000; // 3 minutes for file uploads
    }
    
    // Get the current Supabase session
    const { data } = await supabase.auth.getSession();
    if (data.session?.access_token) {
      config.headers['Authorization'] = `Bearer ${data.session.access_token}`;
      
      // Always include the current user's email in X-User-Email header
      if (data.session.user?.email) {
        config.headers['X-User-Email'] = data.session.user.email;
      }
    }
    
    // Log outgoing requests in development
    if (import.meta.env.DEV) {
      console.log(`API Request: ${config.method?.toUpperCase()} ${config.url}`, config.data);
    }
    
    // Add user email header if present in localStorage
    const userEmail = localStorage.getItem('userEmail');
    if (userEmail && config.headers) {
      config.headers['X-User-Email'] = userEmail;
    }

    // Check if we're offline and reject if so
    if (!navigator.onLine) {
      return Promise.reject(new Error('You are currently offline. Please check your internet connection.'));
    }
    
    return config;
  } catch (error) {
    console.error('Error setting up auth token for API request:', error);
    return config;
  }
}, (error) => {
  console.error('Request interceptor error:', error);
  return Promise.reject(error);
});

// Add response interceptor to handle common errors
apiClient.interceptors.response.use(
  (response) => {
    // Log successful responses in development
    if (import.meta.env.DEV) {
      console.log(`API Response: ${response.status} ${response.config.url}`, 
        response.data ? 'Data received' : 'No data');
    }
    // Make sure data exists and is not null
    if (response.data === undefined || response.data === null) {
      response.data = {}; // Provide a default empty object
    }
    return response;
  },
  (error) => {
    // Create a user-friendly error message
    let errorMessage = 'An unexpected error occurred';
    
    if (error.response) {
      // The request was made and the server responded with a status code
      // that falls out of the range of 2xx
      const status = error.response.status;
      const data = error.response.data as any;
      
      if (status === 401) {
        errorMessage = 'You are not authorized to perform this action. Please log in again.';
        // Optionally redirect to login or refresh token
      } else if (status === 403) {
        errorMessage = 'You do not have permission to access this resource.';
      } else if (status === 404) {
        errorMessage = 'The requested resource was not found.';
      } else if (status === 429) {
        errorMessage = 'Too many requests. Please try again later.';
      } else if (status >= 500) {
        errorMessage = 'Server error. Please try again later.';
      }
      
      // Try to extract a more specific error message from the response
      if (data) {
        if (typeof data === 'string') {
          errorMessage = data;
        } else if (data.message) {
          errorMessage = data.message;
        } else if (data.error) {
          errorMessage = data.error;
        } else if (data.detail) {
          errorMessage = data.detail;
        }
      }
    } else if (error.request) {
      // The request was made but no response was received
      if (!navigator.onLine) {
        errorMessage = 'You are currently offline. Please check your internet connection.';
      } else {
        errorMessage = 'No response received from server. Please try again later.';
      }
    } else {
      // Something happened in setting up the request that triggered an Error
      errorMessage = error.message || 'Failed to send request.';
    }

    // Create a new error with the friendly message
    const enhancedError = new Error(errorMessage) as AxiosError;
    enhancedError.response = error.response;
    enhancedError.request = error.request;
    enhancedError.config = error.config;
    enhancedError.isAxiosError = true;
    
    // Log the error for debugging
    console.error('API Error:', { 
      url: error.config?.url,
      method: error.config?.method,
      status: error.response?.status,
      message: errorMessage
    });
    
    return Promise.reject(enhancedError);
  }
);

// Safe wrapper for API calls
export const safeApiCall = async <T>(apiPromise: Promise<any>): Promise<{ data: T | null; error: string | null }> => {
  try {
    const response = await apiPromise;
    return { data: response.data || null, error: null };
  } catch (error: any) {
    return { 
      data: null, 
      error: error.message || 'An unexpected error occurred' 
    };
  }
};

// Add a function to test backend connection
export const testBackendConnection = async (): Promise<boolean> => {
  console.log('🔍 BACKEND CONNECTION TEST STARTED - client.ts version');
  try {
    // Check if backend is available via healthcheck endpoint
    console.log('🔍 Attempting to connect to backend at:', baseURL + '/healthcheck');
    const healthResponse = await apiClient.get('/healthcheck', { timeout: 5000 });
    console.log('✅ Backend health check success:', healthResponse.data);
    
    // Debug auth info
    try {
      const { data: sessionData } = await supabase.auth.getSession();
      console.log('🔐 Current auth session:', sessionData?.session ? 'Active' : 'No active session');
      console.log('🔑 Session contains token:', sessionData?.session?.access_token ? 'Yes' : 'No');
      if (!sessionData?.session?.access_token) {
        console.warn('⚠️ No authentication token available - this will cause API requests to fail');
        // We'll continue anyway since the health check doesn't require auth
      }
    } catch (authError) {
      console.error('❌ Failed to check auth status:', authError);
    }
    
    // If we get here, the backend is available
    console.log('🎉 Backend connection test SUCCESSFUL');
    return true;
  } catch (error) {
    console.error('❌ Backend connection test FAILED:', error);
    console.error('❌ Error details:', {
      message: (error as any).message,
      response: (error as any).response?.data,
      status: (error as any).response?.status
    });
    return false;
  }
};

export default apiClient;
