import React from 'react';
import { Activity, Building, CheckSquare, BarChart } from 'lucide-react';
import { Link } from 'react-router-dom';
import mylogo from '../assests/logo.jpg';

interface LogoProps {
  variant?: 'default' | 'sidebar' | 'auth';
  showText?: boolean;
}

const Logo: React.FC<LogoProps> = ({ variant = 'default', showText = true }) => {
  const getLogoStyles = () => {
    switch (variant) {
      case 'sidebar':
        return {
          container: 'flex items-center',
          iconContainer: 'h-10 w-10 bg-gradient-to-br from-primary-500 to-secondary-500 flex items-center justify-center rounded-lg shadow-md',
          textContainer: showText ? 'ms-3 text-white' : 'hidden',
          title: 'text-lg font-bold text-white',
          subtitle: 'text-xs opacity-75'
        };
      case 'auth':
        return {
          container: 'flex flex-col items-center',
          iconContainer: 'h-16 w-16 bg-gradient-to-br from-primary-500 to-secondary-500 flex items-center justify-center rounded-xl shadow-lg',
          textContainer: showText ? 'mt-4 text-center' : 'hidden',
          title: 'text-2xl font-bold text-gray-900',
          subtitle: 'text-sm text-gray-600'
        };
      default:
        return {
          container: 'flex items-center',
          iconContainer: 'h-8 w-8 bg-gradient-to-br from-primary-500 to-secondary-500 flex items-center justify-center rounded-lg shadow-sm',
          textContainer: showText ? 'ms-2' : 'hidden',
          title: 'text-xl font-bold text-gray-900',
          subtitle: 'text-xs text-start text-gray-600'
        };
    }
  };

  const styles = getLogoStyles();

  return (
   <div className={styles.container}>
      <Link to={"/"}><div className={styles.iconContainer}>
        <div className="text-white">
          {/* Simple logo with P letters arranged in a square to represent PMO */}
          {/* <svg 
            xmlns="http://www.w3.org/2000/svg" 
            viewBox="0 0 24 24" 
            width="24" 
            height="24" 
            fill="none" 
            stroke="currentColor" 
            strokeWidth="2" 
            strokeLinecap="round" 
            strokeLinejoin="round"
            className="lucide lucide-activity"
          >
            <path d="M5 17h14v-4H5zm10-7h4V6H5v4h10z" stroke="white" fill="white"/>
            <path d="M7 10V6h2v4H7zM7 17v-4h2v4H7z" stroke="white" fill="white"/>
            <path d="M4 6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6z" />
          </svg> */}
          <img src={mylogo} alt="PMO Builder Logo" className={styles.iconContainer} />
        </div>
      </div></Link>
        <div className={styles.textContainer}>
          <div className={styles.title}>
            {variant === 'sidebar' ? (
              <span style={{color: 'white'}}>PMO Builder</span>
            ) : (
              <span className="text-gray-900">PMO Builder</span>
            )}
            {variant === 'sidebar' ? (
              <span className="ml-3 text-xs py-0.5 px-1.5 bg-primary-800 text-white rounded-sm font-medium">Beta</span>
            ) : (
              <span className="ml-3 text-xs py-0.5 px-1.5 bg-primary-100 text-primary-800 rounded-sm font-medium">Beta</span>
            )}
          </div>
          <div className={styles.subtitle}>Powered by AI</div>
          </div>
    </div>
  );
};

export default Logo;