import React from 'react';
import DocumentProcessor from './DocumentProcessor';

/**
 * Memoized version of DocumentProcessor that only re-renders when domainId or onProcessingComplete props change
 * This improves performance by preventing unnecessary re-renders when parent components update
 */
const MemoizedDocumentProcessor = React.memo(
  DocumentProcessor,
  (prevProps, nextProps) => {
    // Only re-render if these properties change
    return (
      prevProps.domainId === nextProps.domainId && 
      prevProps.onProcessingComplete === nextProps.onProcessingComplete
    );
  }
);

export default MemoizedDocumentProcessor; 