import React from 'react';
import TaskManager from './TaskManager';

// Helper function for shallow comparison of objects
const shallowEqual = (obj1: any, obj2: any): boolean => {
  if (obj1 === obj2) return true;
  if (!obj1 || !obj2) return false;
  
  const keys1 = Object.keys(obj1);
  const keys2 = Object.keys(obj2);
  
  if (keys1.length !== keys2.length) return false;
  
  for (const key of keys1) {
    if (obj1[key] !== obj2[key]) {
      // For nested objects like metadata, we could do a deeper check
      // But for most properties, a shallow check is sufficient and much faster
      if (typeof obj1[key] === 'object' && typeof obj2[key] === 'object') {
        // Only do one level deeper for critical nested objects
        if (key === 'metadata' || key === 'data') {
          const nestedEqual = shallowEqual(obj1[key], obj2[key]);
          if (!nestedEqual) return false;
        } else {
          return false;
        }
      } else {
        return false;
      }
    }
  }
  
  return true;
};

// Create a memoized version of TaskManager that only re-renders when props change
const MemoizedTaskManager = React.memo(TaskManager, (prevProps, nextProps) => {
  // First check ID equality as a fast path
  if (prevProps.task.id !== nextProps.task.id) return false;
  
  // Then do a shallow comparison of the task objects
  return shallowEqual(prevProps.task, nextProps.task) &&
         prevProps.onUpdate === nextProps.onUpdate &&
         prevProps.onDelete === nextProps.onDelete;
});

export default MemoizedTaskManager; 