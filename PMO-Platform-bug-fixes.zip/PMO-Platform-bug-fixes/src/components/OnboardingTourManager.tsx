import React from 'react';
import { useOnboarding } from '../contexts/OnboardingContext';
import OnboardingTour from './OnboardingTour';

const OnboardingTourManager: React.FC = () => {
  const { shouldShowTour, completeTour } = useOnboarding();

  return shouldShowTour ? (
    <OnboardingTour 
      isFirstLogin={shouldShowTour} 
      onComplete={completeTour} 
    />
  ) : null;
};

export default OnboardingTourManager; 