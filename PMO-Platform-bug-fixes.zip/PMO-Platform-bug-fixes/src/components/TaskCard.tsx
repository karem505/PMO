import React, { useState, useEffect, useRef } from 'react';
// Define Task interface since it's not exported from '../types'
interface Task {
  id: string;
  title: string;
  description: string;
  domainId: number;
  stage: string;
  templates?: string[];
  bestPractices?: string[];
}
import { useAppStore } from '../store';
import { Check, ChevronDown, ChevronUp, FileText, HelpCircle, Eye, X, Download, Sparkles, FileOutput, Paperclip, Calendar, Clock, Tag, AlertTriangle, CheckCircle, XCircle, Loader2, Users, Info } from 'lucide-react';
import TaskOutputGenerator from './TaskOutputGenerator';
import TaskFileAttachment from './TaskFileAttachment2';
import { useLanguage } from '../contexts/LanguageContext';
import axios from 'axios';
import { useAuth } from './auth/AuthContext';
import apiClient from '../api/client';
import { useToast } from '../hooks/useToast';
import useDebouncedState from '../hooks/useDebouncedState';

interface TaskCardProps {
  task: Task;
  onClick?: (taskId: string) => void;
  onToggleComplete?: (taskId: string, currentStatus: boolean) => void;
  onGeneratorClick?: (taskId: string) => void;
}

// Add TaskData interface
interface TaskData {
  notes?: string;
  completed?: boolean;
  attachments?: string[];
  customFields?: Record<string, any>;
  acceptanceStatus?: 'accepted' | 'needs-refinement' | 'rejected';
  acceptanceTimestamp?: string;
  apiResponse?: any;
  custom_fields?: Record<string, any>;
}

// Add this type declaration before the component definition
interface TaskQueueItem {
  taskId: string;
  callback: (status: any) => void;
}

interface TaskBatchQueue {
  tasks: TaskQueueItem[];
  timeoutId: NodeJS.Timeout | null;
  projectId: string;
}

// Add the type declaration for window
declare global {
  interface Window {
    taskBatchQueue: TaskBatchQueue;
  }
}

// Add a global toggle tracker at module level to prevent race conditions
let isTogglingOutput = false;
let toggleTimeoutId: number | null = null;

const TaskCard: React.FC<TaskCardProps> = ({ task, onClick, onToggleComplete, onGeneratorClick }) => {
  const [expanded, setExpanded] = useState(false);
  const [showTemplatePreview, setShowTemplatePreview] = useState<string | null>(null);
  const [showOutputGenerator, setShowOutputGenerator, setShowOutputGeneratorImmediate] = useDebouncedState(false, 300);
  const [isGenerating, setIsGenerating] = useState(false);
  const [taskData, setTaskData] = useState<TaskData>({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { getActiveProject, setTaskCompleted, updateTaskData } = useAppStore();
  const { t } = useLanguage();
  const { currentUser } = useAuth();
  const activeProject = getActiveProject();
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [fileAttachments, setFileAttachments] = useState<any[]>([]);
  const toast = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  // Add a ref to track component mount state
  const isMountedRef = useRef<boolean>(false);
  // Add the missing completionCheckedRef
  const completionCheckedRef = useRef<boolean>(false);
  // Add a closing state flag 
  const isClosingGeneratorRef = useRef(false);
  
  // Add a toggle lock ref to prevent multiple rapid calls
  const toggleLockRef = useRef(false);
  
  // Track component mount state
  useEffect(() => {
    isMountedRef.current = true;
    return () => {
      isMountedRef.current = false;
    };
  }, []);
  
  // Get task data from active project or fall back to userData
  useEffect(() => {
    if (activeProject?.domainData?.tasks?.[task?.id]) {
      setTaskData(activeProject.domainData.tasks[task.id]);
    } else {
      // Get from userData as fallback for backward compatibility
      const { userData } = useAppStore.getState();
      setTaskData(userData.tasks?.[task?.id] || { completed: false, notes: '', attachments: [], customFields: {} });
    }
  }, [task?.id, activeProject]);
  
  // Check if task has AI-generated content (saved notes)
  const hasGeneratedOutput = taskData?.notes && taskData.notes.length > 0;
  
  // Get output acceptance status
  const outputAcceptanceStatus = taskData?.acceptanceStatus || 'idle';
  
  // Parse attachments from the task data
  const [parsedAttachments, setParsedAttachments] = useState<any[]>([]);
  
  useEffect(() => {
    if (taskData?.attachments && Array.isArray(taskData.attachments) && taskData.attachments.length > 0) {
      try {
        const attachments = taskData.attachments
          .map((att: any) => {
            try {
              return typeof att === 'string' ? JSON.parse(att) : att;
            } catch (e) {
              console.error('Error parsing attachment:', e);
              return null;
            }
          })
          .filter(Boolean);
        
        setParsedAttachments(attachments);
      } catch (error) {
        console.error('Error processing attachments:', error);
        setParsedAttachments([]);
      }
    } else {
      setParsedAttachments([]);
    }
  }, [taskData?.attachments]);
  
  // Simplified task completion check that only runs once per component instance
  useEffect(() => {
    // Only check completion for tasks that belong to a project and aren't already marked as complete
    if (!activeProject?.id || !task?.id || taskData?.completed || completionCheckedRef.current) {
      return;
    }
    
    // Register this task ID to a global batch check queue instead of checking immediately
    if (window.taskBatchQueue === undefined) {
      window.taskBatchQueue = {
        tasks: [],
        timeoutId: null,
        projectId: activeProject.id
      };
    }
    
    // Add this task to the queue
    window.taskBatchQueue.tasks.push({
      taskId: task.id,
      callback: (status: any) => {
        if (status?.exists && status?.completed) {
          console.log(`Task ${task.id} is completed according to backend, updating local state`);
          
          // Update task data with completion information
          const updatedTaskData = {
            completed: true,
            acceptanceStatus: 'accepted' as const,
            acceptanceTimestamp: status.data?.timestamp || new Date().toISOString(),
            notes: status.data?.notes || taskData?.notes || ''
          };
          
          // Update both functions at once to prevent race conditions
          setTaskCompleted(task.id, true);
          updateTaskData(task.id, updatedTaskData);
        }
      }
    });
    
    // Mark as checked to prevent duplicate checks
    completionCheckedRef.current = true; 
    
    // Schedule batch check if not already scheduled
    if (!window.taskBatchQueue.timeoutId) {
      window.taskBatchQueue.timeoutId = setTimeout(async () => {
        try {
          if (window.taskBatchQueue.tasks.length === 0) return;
          
          console.log(`Batch checking ${window.taskBatchQueue.tasks.length} tasks`);
          
          setLoading(true);
          setError(null);
          
          // Use the batch API for efficient checking
          const response = await apiClient.post('/documents/completed-tasks/batch', {
            project_id: window.taskBatchQueue.projectId,
            task_ids: window.taskBatchQueue.tasks.map(t => t.taskId)
          });
          
          // Process results
          window.taskBatchQueue.tasks.forEach(task => {
            const status = response.data?.tasks?.[task.taskId];
            task.callback(status);
          });
          
          // Clear the queue
          window.taskBatchQueue.tasks = [];
          window.taskBatchQueue.timeoutId = null;
        } catch (error) {
          console.error('Error in batch task check:', error);
          setError('Failed to check task completion status');
          window.taskBatchQueue.timeoutId = null;
          window.taskBatchQueue.tasks = []; // Clear on error to prevent repeated failures
        } finally {
          setLoading(false);
        }
      }, 1000); // Batch tasks with 1 second delay
    }
    
  }, [activeProject?.id, task?.id]); // Removed taskData from dependencies
  
  const handleCardClick = () => {
    // Don't do anything if component is unmounted
    if (!isMountedRef.current) {
      console.warn('Task card not mounted, preventing click');
      return;
    }
    
    // Add delay for safety
    setTimeout(() => {
      setExpanded(!expanded);
      
      // REMOVED: Don't call onClick handler to prevent navigation
      // if (onClick && task?.id) {
      //   try {
      //     onClick(task.id);
      //   } catch (err) {
      //     console.error('Error in TaskCard onClick handler:', err);
      //   }
      // }
    }, 50);
  };
  
  const handleToggleComplete = (e: React.MouseEvent) => {
    e.preventDefault(); // Prevent default behavior
    e.stopPropagation(); // Prevent expansion when clicking the checkbox
    
    if (!isMountedRef.current) {
      console.warn('Task card not mounted, preventing toggle');
      return false;
    }
    
    // Add a small delay to prevent DOM errors
    setTimeout(() => {
      try {
        if (task?.id) {
          // Use the passed handler if provided, otherwise use the default one
          if (onToggleComplete) {
            onToggleComplete(task.id, !!taskData?.completed);
          } else {
            setTaskCompleted(task.id, !taskData?.completed);
          }
        }
      } catch (err) {
        console.error('Error toggling task completion:', err);
      }
    }, 50);
    
    return false; // Extra measure to prevent propagation
  };
  
  const handleNotesChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    if (task?.id) {
      updateTaskData(task.id, { notes: e.target.value });
    }
  };
  
  const handleSaveNotes = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!activeProject?.id || !task?.id) {
      toast.error('Cannot save notes: No active project or task ID');
      return;
    }
    
    try {
      setIsSaving(true);
      setError(null);
      
      // Log notes before appending to debug truncation
      console.log('Notes before form data:', taskData?.notes);
      
      // Create FormData object
      const formData = new FormData();
      
      // Add notes with proper encoding if they exist
      const notes = taskData?.notes || '';
      if (notes) {
        console.log('Length of notes:', notes.length);
        formData.append('notes', notes);
      }
      
      // Add attachments from TaskFileAttachment component
      if (parsedAttachments && parsedAttachments.length > 0) {
        parsedAttachments.forEach((attachment, index) => {
          // If we have the original File object (from newly added attachments)
          if (attachment?.file instanceof File) {
            console.log('Adding file to upload:', attachment.name);
            formData.append(`file_${index}`, attachment.file, attachment.name);
          }
        });
        
        // Add attachment metadata
        formData.append('attachmentData', JSON.stringify(
          parsedAttachments.map(att => ({
            id: att?.id,
            name: att?.name,
            size: att?.size,
            type: att?.type
          }))
        ));
      }
      
      // Use the new combined endpoint that handles both file upload and task completion
      const uploadResponse = await apiClient.post(
        `/documents/upload/${activeProject.id}/${task.id}`, 
        formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        }
      );
      
      if (uploadResponse?.data?.success) {
        toast.success('Task data saved successfully');
        
        // If there are new attachment URLs in the response, update our state
        if (uploadResponse.data?.attachments) {
          const newAttachments = uploadResponse.data.attachments.map((url: string) => {
            return JSON.stringify({
              id: Math.random().toString(36).substring(7),
              name: url.split('/').pop(),
              url: url,
              type: url.endsWith('.pdf') ? 'application/pdf' : 'text/plain',
              size: 0
            });
          });
          
          // Update task data with the new attachments
          const updatedAttachments = [...(taskData?.attachments || []), ...newAttachments];
          updateTaskData(task.id, { attachments: updatedAttachments });
        }
      } else {
        toast.error('Failed to save task data');
      }
    } catch (error: any) {
      console.error('Error saving task data:', error);
      setError(error?.response?.data?.message || 'Failed to save task data');
      toast.error(error?.response?.data?.message || 'Failed to save task data');
    } finally {
      setIsSaving(false);
    }
  };
  
  const handleOutputSaved = (taskId: string, output: string, attachments: string[]) => {
    // Make sure existing attachments is always an array
    const existingAttachments = Array.isArray(taskData.attachments) ? taskData.attachments : [];
    
    updateTaskData(taskId, { 
      notes: output,
      attachments: [...existingAttachments, ...attachments]
    });
  };
  
  const getStageColor = (stage: string) => {
    switch (stage) {
      case 'input':
        return 'bg-green-100 text-green-800';
      case 'processing':
        return 'bg-yellow-100 text-yellow-800';
      case 'output':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const handleShowTemplate = (templateName: string) => {
    setShowTemplatePreview(templateName);
  };

  const handleCloseTemplatePreview = () => {
    setShowTemplatePreview(null);
  };
  
  // Handle generation state changes
  const handleGeneratingState = (generating: boolean) => {
    setIsGenerating(generating);
    // If generation finished, we can show the output generator UI again
    if (!generating && !showOutputGenerator) {
      setShowOutputGenerator(true);
    }
  };
  
  const handleAttachmentUpdate = (newAttachments: any[]) => {
    console.log({newAttachments});
    // const file = e.target.files?.[0];
    
    if (!Array.isArray(newAttachments)) {
      console.error('handleAttachmentUpdate received non-array:', newAttachments);
      newAttachments = [];
    }
    
    setFileAttachments(newAttachments);
    updateTaskData(task.id, { 
      attachments: newAttachments.map(a => JSON.stringify(a))
    });
  };
  
  // Get the priority color
  const getPriorityColor = (priority?: string) => {
    if (!priority) return 'bg-gray-100 text-gray-800';
    
    switch(priority) {
      case 'high':
        return 'bg-red-100 text-red-800';
      case 'medium':
        return 'bg-blue-100 text-blue-800';
      case 'low':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  
  // Get acceptance status badge color and icon
  const getAcceptanceStatusBadge = () => {
    switch(outputAcceptanceStatus) {
      case 'accepted':
        return (
          <span className="text-xs px-2 py-1 rounded-full bg-green-100 text-green-800 flex items-center">
            <CheckCircle className="h-3 w-3 me-1" />
            Output Accepted
          </span>
        );
      case 'needs-refinement':
        return (
          <span className="text-xs px-2 py-1 rounded-full bg-blue-100 text-blue-800 flex items-center">
            <Pencil className="h-3 w-3 me-1" />
            Needs Refinement
          </span>
        );
      case 'rejected':
        return (
          <span className="text-xs px-2 py-1 rounded-full bg-red-100 text-red-800 flex items-center">
            <XCircle className="h-3 w-3 me-1" />
            Output Rejected
          </span>
        );
      default:
        return null;
    }
  };

  // Mock template content based on template name
  const getTemplateContent = (templateName: string): string => {
    return `# ${t(templateKey)}

## ${t('tasks.purpose')}
 ${t(`tasks.templateForStandardized`)} ${t(`domains.${task.domainId}.tasks.${task.id}.title`)} ${t(`tasks.withinYourPMO`)}

## ${t('tasks.overview')}
${t(`domains.${task.domainId}.tasks.${task.id}.description`)}
${t(`tasks.template`)}
`;
  };
  
  // Import Pencil icon component
  const Pencil = ({ className }: { className?: string }) => (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
      className={className}
    >
      <path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path>
    </svg>
  );
  
  const templateKey = task.templates && showTemplatePreview 
    ? `domains.${task.domainId}.tasks.${task.id}.templates.${[task.templates.findIndex((t: string) => t === showTemplatePreview)]}`
    : '';
  
  const toggleOutputGenerator = (e: React.MouseEvent) => {
    // Stop event propagation to prevent the card from expanding/collapsing
    if (e) {
      e.stopPropagation();
      e.preventDefault();
    }
    
    // First check global lock, which is more reliable than the ref across renders
    if (isTogglingOutput) {
      console.log('Global toggle lock active, ignoring click');
      return false;
    }
    
    // Then check component-specific locks
    if (isGenerating || toggleLockRef.current) {
      console.log('Generation in progress or toggle locked, ignoring click');
      return false;
    }
    
    // Set all locks
    isTogglingOutput = true;
    toggleLockRef.current = true;
    
    // Clear any existing timeout
    if (toggleTimeoutId) {
      clearTimeout(toggleTimeoutId);
      toggleTimeoutId = null;
    }
    
    console.log('TaskCard: toggleOutputGenerator called, current state:', {
      showOutputGenerator, 
      isGenerating,
      toggleLocked: toggleLockRef.current,
      globalLocked: isTogglingOutput
    });
    
    try {
      // Execute synchronously
      if (onGeneratorClick) {
        // Verify the component is still mounted before triggering generator click
        if (!isMountedRef.current) {
          console.warn('TaskCard: Component not mounted, canceling generator click');
          throw new Error('Component not mounted');
        }
        
        // Use the provided generator click handler if available - wrap in try/catch
        try {
          onGeneratorClick(task.id);
        } catch (error) {
          console.error('Error in onGeneratorClick callback:', error);
          // Don't rethrow - we've handled it here
        }
      } else {
        // Direct state manipulation
        if (showOutputGenerator) {
          console.log('TaskCard: Closing generator');
          setShowOutputGeneratorImmediate(false);
          setIsGenerating(false);
        } else {
          console.log('TaskCard: Opening generator');
          setExpanded(true);
          setShowOutputGeneratorImmediate(true);
        }
      }
    } catch (error) {
      console.error('Error in toggleOutputGenerator:', error);
    } finally {
      // Release the lock after a delay with safety fallback
      toggleTimeoutId = window.setTimeout(() => {
        toggleLockRef.current = false;
        isTogglingOutput = false;
        console.log('TaskCard: All toggle locks released');
        toggleTimeoutId = null;
      }, 1000); // Increased to 1 second for safety
    }
    
    return false; // Prevent event propagation
  };
  
  return (
    <div 
      className={`border rounded-lg shadow-sm overflow-hidden bg-white transition-all duration-200 ${
        expanded ? 'shadow-md' : 'hover:shadow-md'
      } ${
        taskData?.completed ? 'border-green-200 bg-green-50/30' : 'border-neutral-200'
      } ${
        task.stage === 'input' ? 'domain-input-task' : task.stage === 'output' ? 'domain-output-task' : ''
      }`}
      onClick={handleCardClick}
    >
      <div className="p-4">
        <div className="flex items-start justify-between">
          <div className="flex items-start gap-x-3">
            <button 
              className={`flex items-center cursor-auto justify-center `}
              // onClick={handleToggleComplete}
              aria-label={taskData.completed ? "Mark as incomplete" : "Mark as complete"}
            >
              <div className={`w-5 h-5 mt-0.5 rounded-full flex items-center justify-center ${taskData.completed ? 'bg-green-500 text-white' : 'border border-gray-300'}`}>
                {taskData.completed && <Check className="h-3 w-3" />}
              </div>
            </button>
            <div>
              <h3 className={`font-medium ${taskData.completed ? 'text-gray-500' : 'text-gray-800'}`}>{t(`domains.${task.domainId}.tasks.${task.id}.title`)}</h3>
              <p className="text-sm text-gray-600 mt-1">{t(`domains.${task.domainId}.tasks.${task.id}.description`)}</p>
              <div className="flex items-center flex-wrap mt-2 gap-2">
                <span className={`text-xs px-2 py-1 rounded-full ${getStageColor(task.stage)}`}>
                  {t(`domains.${task.domainId}.tasks.${task.id}.stage`)}
                </span>
                
                {taskData.customFields?.priority && (
                  <span className={`text-xs px-2 py-1 rounded-full flex items-center ${getPriorityColor(taskData.customFields.priority)}`}>
                    <Tag className="h-3 w-3 me-1" />
                    {taskData.customFields.priority.charAt(0).toUpperCase() + taskData.customFields.priority.slice(1)}
                  </span>
                )}
                
                {taskData.customFields?.dueDate && (
                  <span className="text-xs px-2 py-1 rounded-full bg-blue-100 text-blue-800 flex items-center">
                    <Calendar className="h-3 w-3 me-1" />
                    {new Date(taskData.customFields.dueDate).toLocaleDateString()}
                  </span>
                )}
                
                {task.templates && task.templates.length > 0 && (
                  <span className="text-xs px-2 py-1 rounded-full bg-gray-100 text-gray-800 flex items-center cursor-pointer" 
                        onClick={(e) => {e.stopPropagation(); task.templates && handleShowTemplate(task.templates[0]);}}>
                    <FileText className="h-3 w-3 me-1" />
                    Templates
                  </span>
                )}
                
                {parsedAttachments.length > 0 && (
                  <span className="text-xs px-2 py-1 rounded-full bg-sky-100 text-sky-800 flex items-center">
                    <Paperclip className="h-3 w-3 me-1" />
                    {parsedAttachments.length} file{parsedAttachments.length !== 1 ? 's' : ''}
                  </span>
                )}
                
                {/* Output acceptance status badge */}
                {outputAcceptanceStatus !== 'idle' && getAcceptanceStatusBadge()}
              </div>
            </div>
          </div>
          <div className="flex gap-x-2">
          {(task.stage === 'output' || task.stage === 'processing') && (
            <button
              className="p-1.5 rounded-md text-blue-600 hover:bg-blue-50 transition-colors"
              onClick={toggleOutputGenerator}
              aria-label="Generate AI output"
            >
              <Sparkles className="h-4 w-4" />
            </button>
            )}
            <button 
              className="p-1 rounded-full hover:bg-gray-100"
              onClick={(e) => {e.stopPropagation(); setExpanded(!expanded);}}
            >
              {expanded ? (
                <ChevronUp className="h-5 w-5 text-gray-500" />
              ) : (
                <ChevronDown className="h-5 w-5 text-gray-500" />
              )}
            </button>
          </div>
        </div>
        
        {expanded && !showOutputGenerator && (
          <div className="mt-4 pt-4 border-t border-gray-100">
            {/* Add info message only for processing tasks */}
            {task.stage === 'processing' && (
              <div className="mb-4 p-3 rounded-md bg-blue-50 border border-blue-100">
                <p className="text-xs text-blue-700 flex items-start">
                  <Info className="h-4 w-4 me-1.5 mt-0.5 flex-shrink-0" />
                  {t('tasks.processingTaskOptions', 'For processing tasks, you can add notes and upload files below, and/or generate AI recommendations using the sparkle icon in the top right.')}
                </p>
              </div>
            )}
            {task.bestPractices && task.bestPractices.length > 0 && (
              <div className="mb-4">
                <h4 className="text-sm font-medium text-gray-700 flex items-center">
                  <HelpCircle className="h-4 w-4 me-1.5 text-blue-500" />
                  {t('domain.BestPractices')}
                </h4>
                <ul className="mt-2 space-y-1">
                  {task.bestPractices.map((practice: string, index: number) => (
                    <li key={index} className="text-sm text-gray-600 flex items-start">
                      <span className="me-2">•</span>
                      <span>{t(`domains.${task.domainId}.tasks.${task.id}.bestPractices.${index}`, practice)}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
            
            {task.templates && task.templates.length > 0 && (
              <div className="mb-4">
                <h4 className="text-sm font-medium text-gray-700 flex items-center">
                  <FileText className="h-4 w-4 me-1.5 text-blue-500" />
                  {t('tasks.availableTemplates')}
                </h4>
                <ul className="mt-2 space-y-2">
                  {task.templates.map((template: string, index: number) => (
                    <li key={index} className="text-sm text-gray-600 flex items-center justify-between bg-gray-50 p-2 rounded-md">
                      <span>{t(`domains.${task.domainId}.tasks.${task.id}.templates.${index}`, template)}</span>
                      <div className="flex gap-x-1">
                        <button 
                          className="p-1 rounded-md hover:bg-blue-100 text-blue-600"
                          onClick={(e) => {e.stopPropagation(); handleShowTemplate(template);}}
                        >
                          <Eye className="h-4 w-4" />
                        </button>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            )}
            
            {/* Task Fields Summary */}
            {(taskData.customFields?.assignedTo || 
              taskData.customFields?.estimatedHours || 
              taskData.customFields?.dueDate) && (
              <div className="mb-4 grid grid-cols-1 md:grid-cols-3 gap-2">
                {taskData.customFields.dueDate && (
                  <div className="bg-blue-50 p-2 rounded-md">
                    <span className="text-xs font-medium text-blue-700 flex items-center">
                      <Calendar className="h-3.5 w-3.5 me-1" /> Due Date
                    </span>
                    <p className="text-sm text-blue-800">{new Date(taskData.customFields.dueDate).toLocaleDateString()}</p>
                  </div>
                )}
                
                {taskData.customFields.assignedTo && (
                  <div className="bg-purple-50 p-2 rounded-md">
                    <span className="text-xs font-medium text-purple-700 flex items-center">
                      <Users className="h-3.5 w-3.5 me-1" /> Assigned To
                    </span>
                    <p className="text-sm text-purple-800">{taskData.customFields.assignedTo}</p>
                  </div>
                )}
                
                {taskData.customFields.estimatedHours && (
                  <div className="bg-green-50 p-2 rounded-md">
                    <span className="text-xs font-medium text-green-700 flex items-center">
                      <Clock className="h-3.5 w-3.5 me-1" /> Estimate
                    </span>
                    <p className="text-sm text-green-800">{taskData.customFields.estimatedHours} hrs</p>
                  </div>
                )}
              </div>
            )}
            
            {/* Output acceptance status display */}
            {outputAcceptanceStatus !== 'idle' && (
              <div className={`mb-4 p-3 rounded-md ${
                outputAcceptanceStatus === 'accepted' ? 'bg-green-50 border border-green-200' :
                outputAcceptanceStatus === 'needs-refinement' ? 'bg-blue-50 border border-blue-200' :
                'bg-red-50 border border-red-200'
              }`}>
                <div className="flex items-start">
                  {outputAcceptanceStatus === 'accepted' ? (
                    <CheckCircle className="h-5 w-5 text-green-500 me-2 flex-shrink-0" />
                  ) : outputAcceptanceStatus === 'needs-refinement' ? (
                    <Pencil className="h-5 w-5 text-blue-500 me-2 flex-shrink-0" />
                  ) : (
                    <AlertTriangle className="h-5 w-5 text-red-500 me-2 flex-shrink-0" />
                  )}
                  
                  <div>
                    <h4 className={`text-sm font-medium ${
                      outputAcceptanceStatus === 'accepted' ? 'text-green-800' :
                      outputAcceptanceStatus === 'needs-refinement' ? 'text-blue-800' :
                      'text-red-800'
                    }`}>
                      {outputAcceptanceStatus === 'accepted' ? 'Output Accepted' :
                       outputAcceptanceStatus === 'needs-refinement' ? 'Output Needs Refinement' :
                       'Output Rejected'}
                    </h4>
                    <p className={`text-xs ${
                      outputAcceptanceStatus === 'accepted' ? 'text-green-700' :
                      outputAcceptanceStatus === 'needs-refinement' ? 'text-blue-700' :
                      'text-red-700'
                    } mt-1`}>
                      {outputAcceptanceStatus === 'accepted' ? 
                        'This output has been reviewed and accepted.' :
                       outputAcceptanceStatus === 'needs-refinement' ? 
                        'This output needs further refinement before acceptance.' :
                        'This output has been rejected. Consider regenerating it.'}
                    </p>
                    {taskData.acceptanceTimestamp && (
                      <p className={`text-xs ${
                        outputAcceptanceStatus === 'accepted' ? 'text-green-700' :
                        outputAcceptanceStatus === 'needs-refinement' ? 'text-blue-700' :
                        'text-red-700'
                      } mt-1`}>
                        Last updated: {new Date(taskData.acceptanceTimestamp).toLocaleString()}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            )}
            
            {/* Attachment preview */}
            {parsedAttachments.length > 0 && (
              <div className="mb-4">
                <h4 className="text-sm font-medium text-gray-700 flex items-center">
                  <Paperclip className="h-4 w-4 me-1.5 text-blue-500" />
                  Attachments
                </h4>
                <div className="mt-2 grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-1">
                  {parsedAttachments.map((attachment, index) => {
                    // Get file extension
                    const extension = attachment.name.split('.').pop()?.toUpperCase() || '';
                    const isImage = attachment.type?.startsWith('image/') || ['JPG', 'JPEG', 'PNG', 'GIF', 'WEBP', 'SVG'].includes(extension);
                    
                    return (
                      <a
                        key={index}
                        href={attachment.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center p-2 bg-gray-50 rounded-md border border-gray-100 hover:bg-gray-100 transition-colors text-gray-700 hover:text-blue-600"
                        onClick={e => e.stopPropagation()}
                      >
                        {isImage ? (
                          <div className="w-10 h-10 bg-gray-200 rounded-md overflow-hidden me-3 flex-shrink-0">
                            <img 
                              src={attachment.url} 
                              alt={attachment.name}
                              className="w-full h-full object-cover"
                              onError={(e) => {
                                const target = e.target as HTMLImageElement;
                                target.src = 'https://via.placeholder.com/40?text=Error';
                              }}
                            />
                          </div>
                        ) : (
                          <div className="w-10 h-10 bg-blue-50 rounded-md me-3 flex items-center justify-center flex-shrink-0">
                            <span className="text-xs font-bold text-blue-600">{extension}</span>
                          </div>
                        )}
                        <div className="overflow-hidden flex-1">
                          <p className="text-sm font-medium truncate">{attachment.name}</p>
                          <p className="text-xs text-gray-500">{formatFileSize(attachment.size)}</p>
                        </div>
                      </a>
                    );
                  })}
                </div>
              </div>
            )}
            
            {/* Only show output for non-input tasks */}
            {hasGeneratedOutput && task.stage !== 'input' && (
              <div className="mb-4">
                <h4 className="text-sm font-medium text-gray-700 flex items-center">
                  <FileOutput className="h-4 w-4 me-1.5 text-purple-600" />
                  Output
                </h4>
                <div className="mt-2 bg-gray-50 p-3 rounded-md text-sm text-gray-800 max-h-48 overflow-y-auto prose prose-sm">
                  {taskData.notes && taskData.notes.split("\n").map((line: string, i: number) => (
                    <div key={i}>{line}</div>
                  ))}
                </div>
                {/* Only show View Output button for output tasks, not for processing tasks */}
                {task.stage === 'output' && (
                  <div className="mt-2 flex justify-end">
                    <button
                      onClick={toggleOutputGenerator}
                      className="px-2 py-1 text-xs bg-purple-100 text-purple-800 rounded-md hover:bg-purple-200 flex items-center"
                    >
                      <Sparkles className="h-3 w-3 me-1" />
                      View Output
                    </button>
                  </div>
                )}
              </div>
            )}
            
            {task.stage !== 'output' && (
            <>
            <div className="mt-4">
              <h4 className="text-sm font-medium text-gray-700">{t('tasks.notes')}</h4>
              <form onSubmit={handleSaveNotes}>
                <textarea
                  className="mt-2 w-full p-2 border border-gray-300 rounded-md text-sm focus:ring-blue-500 focus:border-blue-500 text-neutral-800"
                  rows={3}
                  placeholder={t('tasks.addNotes', 'Add your notes here...')}
                  value={taskData.notes || ''}
                  onChange={handleNotesChange}
                  onClick={(e) => e.stopPropagation()}
                ></textarea>
                
                {(task.stage === 'input' || task.stage === 'processing') && (
                  <>
                    <TaskFileAttachment 
                      existingAttachments={parsedAttachments}
                      onUploadComplete={handleAttachmentUpdate}
                    />
                  </>
                )}
                
                {/* Add Save Notes button */}
                <div className="mt-2 flex justify-end">
                  <button
                    type="submit"
                    className="px-3 py-1.5 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center text-sm"
                  >
                    {isSaving ? (
                      <>
                        <Loader2 className="h-4 w-4 me-2 animate-spin" />
                        <span>Saving...</span>
                      </>
                    ) : (
                      <>
                        <Check className="h-3.5 w-3.5 me-1.5" />
                        {t('tasks.save')}
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
            
            </>)}
          </div>
        )}
        
        {/* Render TaskOutputGenerator only when showOutputGenerator is true and isGenerating is false */}
        {showOutputGenerator && expanded && !isGenerating && (
          <div className="mt-4 pt-4 border-t border-gray-100">
            <h4 className="text-sm font-medium text-gray-700 mb-3 flex items-center">
              <Sparkles className="h-4 w-4 me-1.5 text-purple-600" />
              {t('tasks.generateRecommendations', 'Generate Recommendations')}
            </h4>
            <div className="task-generator-container overflow-hidden rounded-lg">
              <TaskOutputGenerator 
                task={task} 
                taskData={taskData}
                onOutputSaved={handleOutputSaved}
                onClose={() => {
                  // Check if already closing to prevent duplicates
                  if (isClosingGeneratorRef.current) {
                    console.log('TaskCard: Already closing generator, ignoring duplicate call');
                    return;
                  }
                  
                  // Set closing flag to prevent race conditions
                  isClosingGeneratorRef.current = true;
                  
                  console.log('TaskCard: Closing output generator');
                  
                  // Set state with immediate version to avoid batching/race conditions
                  setShowOutputGeneratorImmediate(false);
                  
                  // Release closing lock after small delay
                  setTimeout(() => {
                    isClosingGeneratorRef.current = false;
                  }, 500);
                }}
                onGenerating={handleGeneratingState}
              />
            </div>
          </div>
        )}
        
        {/* When isGenerating is true, render only the TaskOutputGenerator component with no container */}
        {showOutputGenerator && isGenerating && (
          <TaskOutputGenerator 
            task={task} 
            taskData={taskData}
            onOutputSaved={handleOutputSaved}
            onClose={() => {
              // Check if already closing to prevent duplicates
              if (isClosingGeneratorRef.current) {
                console.log('TaskCard: Already closing generator, ignoring duplicate call');
                return;
              }
              
              // Set closing flag to prevent race conditions
              isClosingGeneratorRef.current = true;
              
              console.log('TaskCard: Closing output generator from generator state');
              
              // Set state with immediate version to avoid batching/race conditions
              setShowOutputGeneratorImmediate(false);
              setIsGenerating(false);
              
              // Release closing lock after small delay
              setTimeout(() => {
                isClosingGeneratorRef.current = false;
              }, 500);
            }}
            onGenerating={handleGeneratingState}
          />
        )}

        {/* For processing tasks, show notes/upload form even when generator is active */}
        {expanded && showOutputGenerator && !isGenerating && task.stage === 'processing' && (
          <div className="mt-4 pt-4 border-t border-gray-100">
            <h4 className="text-sm font-medium text-gray-700">{t('tasks.notes')}</h4>
            <form onSubmit={handleSaveNotes}>
              <textarea
                className="mt-2 w-full p-2 border border-gray-300 rounded-md text-sm focus:ring-blue-500 focus:border-blue-500 text-neutral-800"
                rows={3}
                placeholder={t('tasks.addNotes', 'Add your notes here...')}
                value={taskData.notes || ''}
                onChange={handleNotesChange}
                onClick={(e) => e.stopPropagation()}
              ></textarea>
              
              <TaskFileAttachment 
                existingAttachments={parsedAttachments}
                onUploadComplete={handleAttachmentUpdate}
              />
              
              {/* Add Save Notes button */}
              <div className="mt-2 flex justify-end">
                <button
                  type="submit"
                  className="px-3 py-1.5 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center text-sm"
                >
                  {isSaving ? (
                    <>
                      <Loader2 className="h-4 w-4 me-2 animate-spin" />
                      <span>Saving...</span>
                    </>
                  ) : (
                    <>
                      <Check className="h-3.5 w-3.5 me-1.5" />
                      {t('tasks.save')}
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        )}
      </div>

      {/* Template Preview Modal */}
      {showTemplatePreview && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4" onClick={e => e.stopPropagation()}>
          <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-gray-200 px-6 py-4">
              <h3 className="text-lg font-semibold text-gray-800 flex items-center">
                <FileText className="h-5 w-5 me-2 text-blue-600" />
                {t(templateKey)}
              </h3>
              <button 
                className="p-1 rounded-full hover:bg-gray-100"
                onClick={handleCloseTemplatePreview}
              >
                <X className="h-5 w-5 text-gray-500 " />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-6">
              <div className="prose max-w-none">
                <pre className="whitespace-pre-wrap dark:text-gray-400 font-sans text-sm">
                  {getTemplateContent(showTemplatePreview)}
                </pre>
              </div>
            </div>
            <div className="border-t border-gray-200 px-6 py-4 flex justify-between">
              <button 
                className="px-4 py-2 border border-gray-300 rounded-md text-gray-700  hover:bg-gray-50 flex items-center"
                onClick={handleCloseTemplatePreview}
              >
                {t('tasks.close')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// Helper function to format file size
const formatFileSize = (bytes?: number): string => {
  if (bytes === undefined) return 'Unknown size';
  if (bytes === 0) return '0 Bytes';
  
  const units = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  
  return `${parseFloat((bytes / Math.pow(1024, i)).toFixed(2))} ${units[i]}`;
};

export default TaskCard;