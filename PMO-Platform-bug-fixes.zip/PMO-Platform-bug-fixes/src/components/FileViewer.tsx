import React, { useState, useEffect } from 'react';
import { Loader2, AlertCircle, FileText } from 'lucide-react';

interface FileViewerProps {
  file: {
    name: string;
    url: string;
    type?: string;
  };
}

const FileViewer: React.FC<FileViewerProps> = ({ file }) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  useEffect(() => {
    setLoading(true);
    setError(null);
    
    // Check if the file URL is valid
    const img = new Image();
    img.onload = () => {
      setLoading(false);
    };
    img.onerror = () => {
      // This only checks if image loads, so we'll only set error for images
      if (getFileType() === 'image') {
        setError('Failed to load image');
      }
      setLoading(false);
    };
    
    // Attempt to load
    if (getFileType() === 'image') {
      img.src = file.url;
    } else {
      // For non-images, we don't need to preload, just show the appropriate viewer
      setLoading(false);
    }
    
    return () => {
      img.onload = null;
      img.onerror = null;
    };
  }, [file.url]);
  
  const getFileType = (): string => {
    if (file.type) {
      if (file.type.startsWith('image/')) return 'image';
      if (file.type.startsWith('video/')) return 'video';
      if (file.type.startsWith('audio/')) return 'audio';
      if (file.type === 'application/pdf') return 'pdf';
      if (file.type.includes('spreadsheet') || file.type.includes('excel')) return 'spreadsheet';
      if (file.type.includes('document') || file.type.includes('word')) return 'document';
      if (file.type.includes('presentation') || file.type.includes('powerpoint')) return 'presentation';
      if (file.type.startsWith('text/')) return 'text';
    }
    
    // Fallback to extension-based detection
    const extension = file.name.split('.').pop()?.toLowerCase();
    if (!extension) return 'unknown';
    
    if (['jpg', 'jpeg', 'png', 'gif', 'svg', 'webp'].includes(extension)) return 'image';
    if (['mp4', 'webm', 'ogg'].includes(extension)) return 'video';
    if (['mp3', 'wav', 'ogg'].includes(extension)) return 'audio';
    if (extension === 'pdf') return 'pdf';
    if (['xls', 'xlsx', 'csv'].includes(extension)) return 'spreadsheet';
    if (['doc', 'docx', 'rtf'].includes(extension)) return 'document';
    if (['ppt', 'pptx'].includes(extension)) return 'presentation';
    if (['txt', 'md', 'html', 'css', 'js', 'json', 'xml'].includes(extension)) return 'text';
    
    return 'unknown';
  };
  
  const renderFilePreview = () => {
    const fileType = getFileType();
    
    if (loading) {
      return (
        <div className="flex flex-col items-center justify-center min-h-[200px]">
          <Loader2 className="h-8 w-8 text-primary-500 animate-spin mb-3" />
          <p className="text-gray-500">Loading preview...</p>
        </div>
      );
    }
    
    if (error) {
      return (
        <div className="flex flex-col items-center justify-center min-h-[200px]">
          <AlertCircle className="h-8 w-8 text-red-500 mb-3" />
          <p className="text-red-500 font-medium">{error}</p>
          <p className="text-gray-500 mt-2">Try downloading the file instead</p>
        </div>
      );
    }
    
    switch (fileType) {
      case 'image':
        return (
          <div className="flex items-center justify-center">
            <img 
              src={file.url} 
              alt={file.name} 
              className="max-w-full max-h-[70vh] object-contain"
              onError={() => setError('Failed to load image')}
            />
          </div>
        );
      
      case 'video':
        return (
          <video 
            controls 
            className="max-w-full max-h-[70vh]"
            onError={() => setError('Failed to load video')}
          >
            <source src={file.url} />
            Your browser does not support the video tag.
          </video>
        );
      
      case 'audio':
        return (
          <div className="p-4 flex flex-col items-center">
            <div className="w-full max-w-md bg-gray-100 p-8 rounded-lg mb-4">
              <FileText className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <p className="text-center text-gray-700 font-medium">{file.name}</p>
            </div>
            <audio 
              controls 
              className="w-full max-w-md"
              onError={() => setError('Failed to load audio')}
            >
              <source src={file.url} />
              Your browser does not support the audio tag.
            </audio>
          </div>
        );
      
      case 'pdf':
        return (
          <iframe 
            src={file.url} 
            title={file.name}
            className="w-full h-[70vh]"
            onError={() => setError('Failed to load PDF')}
          />
        );
      
      case 'text':
        return (
          <div className="bg-gray-100 p-4 rounded-lg">
            <iframe 
              src={file.url} 
              title={file.name}
              className="w-full h-[70vh] bg-white rounded border border-gray-300"
              onError={() => setError('Failed to load text file')}
            />
          </div>
        );
      
      default:
        return (
          <div className="flex flex-col items-center justify-center min-h-[200px] p-6 bg-gray-50">
            <FilePreviewPlaceholder 
              fileType={fileType} 
              fileName={file.name} 
            />
            <p className="text-gray-500 mt-4">
              Preview not available for this file type.
            </p>
            <a
              href={file.url}
              download={file.name}
              className="mt-4 px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 transition-colors"
            >
              Download to view
            </a>
          </div>
        );
    }
  };
  
  return (
    <div className="file-viewer">
      {renderFilePreview()}
    </div>
  );
};

// Placeholder component for file types that can't be previewed
const FilePreviewPlaceholder: React.FC<{fileType: string; fileName: string}> = ({ fileType, fileName }) => {
  const iconColor = {
    document: 'text-blue-500',
    spreadsheet: 'text-green-500',
    presentation: 'text-orange-500',
    unknown: 'text-gray-500'
  };
  
  const fileTypeLabel = {
    document: 'Document',
    spreadsheet: 'Spreadsheet',
    presentation: 'Presentation',
    unknown: 'File',
  };
  
  const color = iconColor[fileType as keyof typeof iconColor] || iconColor.unknown;
  const label = fileTypeLabel[fileType as keyof typeof fileTypeLabel] || fileTypeLabel.unknown;
  const extension = fileName.split('.').pop()?.toUpperCase() || '';
  
  return (
    <div className="flex flex-col items-center">
      <div className={`w-20 h-24 relative ${color} bg-opacity-10 rounded-lg border border-opacity-20 flex items-center justify-center`}>
        <FileText className={`h-10 w-10 ${color}`} />
        <div className="absolute -bottom-2 -right-2 bg-gray-100 text-gray-700 text-xs font-bold px-2 py-1 rounded border border-gray-300">
          {extension}
        </div>
      </div>
      <p className="mt-4 text-gray-700 font-medium">{label}</p>
    </div>
  );
};

export default FileViewer;