import React from 'react';

const DashboardSkeleton: React.FC = () => {
  return (
    <div className="space-y-6 max-w-7xl mx-auto animate-pulse">
      {/* Header skeleton */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div className="w-1/2">
          <div className="h-7 w-48 bg-gray-300 rounded-md"></div>
          <div className="h-5 w-72 mt-2 bg-gray-200 rounded-md"></div>
        </div>
        <div className="mt-4 md:mt-0 flex items-center space-x-4">
          <div className="h-9 w-36 bg-gray-300 rounded-md"></div>
          <div className="h-9 w-36 bg-gray-300 rounded-md"></div>
        </div>
      </div>
      
      {/* Project card skeleton */}
      <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
        <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between">
          <div>
            <div className="h-7 w-64 bg-gray-300 rounded-md"></div>
            <div className="h-5 w-96 mt-2 bg-gray-200 rounded-md"></div>
            
            <div className="flex flex-wrap items-center mt-3 space-x-6">
              <div className="h-5 w-32 bg-gray-200 rounded-md"></div>
              <div className="h-5 w-32 bg-gray-200 rounded-md"></div>
            </div>
          </div>
          
          <div className="flex md:items-center space-x-3 mt-4 lg:mt-0">
            <div className="h-9 w-28 bg-gray-300 rounded-md"></div>
            <div className="h-9 w-28 bg-gray-300 rounded-md"></div>
            <div className="h-9 w-28 bg-gray-300 rounded-md"></div>
          </div>
        </div>
      </div>
      
      {/* Widget cards skeleton */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[1, 2, 3].map((i) => (
          <div key={i} className="bg-white rounded-lg shadow-sm p-6 border border-gray-100">
            <div className="flex justify-between items-start">
              <div className="h-6 w-36 bg-gray-300 rounded-md"></div>
              <div className="h-8 w-8 bg-gray-200 rounded-full"></div>
            </div>
            <div className="mt-4 space-y-2">
              <div className="h-8 w-20 bg-gray-300 rounded-md"></div>
              <div className="h-5 w-full bg-gray-200 rounded-md"></div>
              <div className="h-4 w-4/5 bg-gray-200 rounded-md"></div>
            </div>
          </div>
        ))}
      </div>
      
      {/* Chart skeleton */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="h-6 w-40 bg-gray-300 rounded-md"></div>
          <div className="mt-4 h-64 bg-gray-200 rounded-md"></div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="h-6 w-36 bg-gray-300 rounded-md mb-4"></div>
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex items-start">
                <div className="h-5 w-5 bg-gray-300 rounded-full mr-3 mt-0.5"></div>
                <div className="space-y-2 flex-1">
                  <div className="h-5 w-3/5 bg-gray-300 rounded-md"></div>
                  <div className="h-4 w-full bg-gray-200 rounded-md"></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      
      {/* Domains skeleton */}
      <div className="mt-4">
        <div className="flex items-center justify-between mb-4">
          <div className="h-6 w-32 bg-gray-300 rounded-md"></div>
          <div className="h-4 w-24 bg-gray-200 rounded-md"></div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} className="bg-white rounded-lg shadow-sm p-6 border border-gray-100">
              <div className="flex items-start mb-3">
                <div className="h-10 w-10 bg-gray-200 rounded-md mr-3"></div>
                <div className="flex-1">
                  <div className="h-5 w-full bg-gray-300 rounded-md"></div>
                  <div className="h-4 w-5/6 bg-gray-200 rounded-md mt-2"></div>
                </div>
              </div>
              <div className="h-2 w-full bg-gray-100 rounded-full mt-3">
                <div className="h-2 w-1/3 bg-gray-300 rounded-full"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DashboardSkeleton;