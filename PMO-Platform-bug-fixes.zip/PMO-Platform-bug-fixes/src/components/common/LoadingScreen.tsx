import React from 'react';
import { Loader2 } from 'lucide-react';
import Logo from '../Logo';
import { useLanguage } from '../../contexts/LanguageContext';
interface LoadingScreenProps {
  message?: string;
  showLogo?: boolean;
  minHeight?: string;
}

const LoadingScreen: React.FC<LoadingScreenProps> = ({ 
  message = 'Loading...', 
  showLogo = true,
  minHeight = 'min-h-screen'
}) => {
  const { t } = useLanguage();
  return (
    <div className={`flex items-center justify-center ${minHeight} bg-gray-50`}>
      <div className="text-center bg-white p-8 rounded-lg shadow-sm border border-gray-100 max-w-md w-full">
        {showLogo && (
          <div className="mb-6 flex justify-center">
            <Logo variant="auth" />
          </div>
        )}
        <Loader2 className="h-12 w-12 text-blue-600 animate-spin mx-auto mb-3" />
        <h2 className="mt-4 text-xl font-semibold text-gray-800">{message}</h2>
        <p className="mt-2 text-gray-600">{t('common.pleaseWait', 'Please wait while we prepare your content.')}</p>
      </div>
    </div>
  );
};

export default LoadingScreen;