import React, { ComponentType, useState, useEffect } from 'react';
import { Loader2, AlertTriangle } from 'lucide-react';

interface WithSafeDataHandlingProps {
  isLoading?: boolean;
  error?: string | Error | null;
  [key: string]: any;
}

/**
 * Higher-order component that provides safe data handling for components
 * that receive data from props, API calls, or other sources.
 * 
 * @param WrappedComponent - The component to wrap
 * @param defaultProps - Default props to use when data is loading
 * @param options - Configuration options
 * @returns A new component with safe data handling
 */
export function withSafeDataHandling<P extends object>(
  WrappedComponent: ComponentType<P>,
  defaultProps?: Partial<P>,
  options: {
    loadingComponent?: React.ReactNode;
    errorComponent?: React.ReactNode;
    checkDataReadiness?: (props: P) => boolean;
    loadingDelay?: number;
  } = {}
) {
  // Extract options with defaults
  const {
    loadingComponent,
    errorComponent,
    checkDataReadiness = () => true,
    loadingDelay = 300
  } = options;
  
  // Create the wrapped component
  const SafeComponent = (props: P & WithSafeDataHandlingProps) => {
    const { isLoading, error, ...restProps } = props;
    
    // State to track delayed loading for better UX
    const [showLoading, setShowLoading] = useState(false);
    
    // Show loading indicator after a delay to prevent flashing
    useEffect(() => {
      let timeoutId: number | undefined;
      
      if (isLoading) {
        timeoutId = window.setTimeout(() => {
          setShowLoading(true);
        }, loadingDelay);
      } else {
        setShowLoading(false);
      }
      
      return () => {
        if (timeoutId) {
          window.clearTimeout(timeoutId);
        }
      };
    }, [isLoading, loadingDelay]);
    
    // Format error message
    const errorMessage = error instanceof Error ? error.message : error;
    
    // Default loading component
    const defaultLoadingComponent = (
      <div className="flex flex-col items-center justify-center p-6 min-h-[200px] bg-white rounded-lg shadow-sm border border-neutral-100">
        <Loader2 className="h-8 w-8 text-primary-600 animate-spin mb-4" />
        <p className="text-neutral-600 font-medium">Loading...</p>
      </div>
    );
    
    // Default error component
    const defaultErrorComponent = (
      <div className="flex flex-col items-center justify-center p-6 bg-white rounded-lg shadow-sm border border-neutral-100">
        <AlertTriangle className="h-8 w-8 text-amber-500 mb-4" />
        <h3 className="text-lg font-semibold text-neutral-800 mb-2">Something went wrong</h3>
        <p className="text-neutral-600 mb-4 text-center">{errorMessage || 'An unexpected error occurred.'}</p>
      </div>
    );
    
    // Show loading component if loading
    if (isLoading && showLoading) {
      return <>{loadingComponent || defaultLoadingComponent}</>;
    }
    
    // Show error component if there's an error
    if (error) {
      return <>{errorComponent || defaultErrorComponent}</>;
    }
    
    // Merge props with default props
    const mergedProps = { ...defaultProps, ...restProps } as P;
    
    // Check if data is ready using the provided function
    const isDataReady = checkDataReadiness(mergedProps);
    
    // If data is not ready, show loading component
    if (!isDataReady) {
      return <>{loadingComponent || defaultLoadingComponent}</>;
    }
    
    // Render the wrapped component with merged props
    return <WrappedComponent {...mergedProps} />;
  };
  
  // Set display name for debugging
  const wrappedComponentName = WrappedComponent.displayName || WrappedComponent.name || 'Component';
  SafeComponent.displayName = `withSafeDataHandling(${wrappedComponentName})`;
  
  return SafeComponent as ComponentType<P & WithSafeDataHandlingProps>;
}

export default withSafeDataHandling;

// Simple loading component for reuse
export const LoadingIndicator: React.FC<{ text?: string }> = ({ text = 'Loading...' }) => (
  <div className="flex justify-center items-center h-32 w-full">
    <Loader2 className="h-8 w-8 text-primary-600 animate-spin" />
    <span className="ml-2 text-gray-600">{text}</span>
  </div>
);

// Simple error component for reuse
export const ErrorIndicator: React.FC<{ error: string; onRetry?: () => void }> = ({ 
  error, 
  onRetry 
}) => (
  <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-lg my-4">
    <div className="flex items-center">
      <AlertTriangle className="h-5 w-5 mr-2" />
      <p>{error}</p>
    </div>
    {onRetry && (
      <button
        onClick={onRetry}
        className="mt-2 px-4 py-2 bg-white border border-red-300 text-red-700 rounded hover:bg-red-50"
      >
        Try Again
      </button>
    )}
  </div>
);

// Custom hook for components that need to manage their own loading/error state
export const useSafeDataHandling = <T,>(initialData?: T) => {
  const [data, setData] = useState<T | undefined>(initialData);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const resetError = () => setError(null);

  return {
    data,
    setData,
    isLoading,
    setIsLoading,
    error,
    setError,
    resetError
  };
}; 