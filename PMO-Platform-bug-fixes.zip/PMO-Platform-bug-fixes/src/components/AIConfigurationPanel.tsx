import React, { useState, useEffect } from 'react';
import { Sliders, Zap, MoveRight, Brain, Settings, Book, Target, LayoutTemplate, Sparkles, Info } from 'lucide-react';
import { Domain } from '../types';
import { supabase } from '../services/supabaseClient';
import { useAuth } from './auth/AuthContext';

interface AIConfigurationPanelProps {
  domain: Domain;
  onStartAnalysis: () => void;
}

const AIConfigurationPanel: React.FC<AIConfigurationPanelProps> = ({ domain, onStartAnalysis }) => {
  const [expanded, setExpanded] = useState(false);
  const [analysisDepth, setAnalysisDepth] = useState('standard');
  const [focusAreas, setFocusAreas] = useState({
    strategic: true,
    operational: true,
    performance: true,
    competency: true
  });
  const [templateTypes, setTemplateTypes] = useState({
    governance: true,
    processes: true,
    assessment: true,
    implementation: true
  });
  const [useOpenAI, setUseOpenAI] = useState(true);
  const [quickMode, setQuickMode] = useState(true); // Default to quick mode
  const [savingConfig, setSavingConfig] = useState(false);
  const { currentUser } = useAuth();
  
  useEffect(() => {
    // Load saved configuration if available
    const loadConfig = async () => {
      if (currentUser) {
        try {
          const { data, error } = await supabase
            .from('ai_configurations')
            .select('*')
            .eq('user_id', currentUser.id)
            .eq('domain_id', domain.id)
            .maybeSingle();
            
          if (error) throw error;
          
          if (data) {
            setAnalysisDepth(data.analysis_depth || 'standard');
            setFocusAreas(data.focus_areas || {
              strategic: true,
              operational: true,
              performance: true,
              competency: true
            });
            setTemplateTypes(data.template_types || {
              governance: true,
              processes: true,
              assessment: true,
              implementation: true
            });
            setUseOpenAI(data.use_openai !== undefined ? data.use_openai : true);
            setQuickMode(data.quick_mode !== undefined ? data.quick_mode : true);
          }
        } catch (error) {
          console.error('Error loading AI configuration:', error);
        }
      }
    };
    
    loadConfig();
  }, [currentUser, domain.id]);
  
  const updateFocusArea = (area: string, checked: boolean) => {
    setFocusAreas(prev => ({ ...prev, [area]: checked }));
  };
  
  const updateTemplateType = (type: string, checked: boolean) => {
    setTemplateTypes(prev => ({ ...prev, [type]: checked }));
  };
  
  const handleAnalyze = async () => {
    // Log start time for performance tracking
    const startTime = performance.now();
    
    // Save AI configuration to Supabase if user is logged in
    if (currentUser) {
      setSavingConfig(true);
      try {
        const { error } = await supabase
          .from('ai_configurations')
          .upsert({
            user_id: currentUser.id,
            domain_id: domain.id,
            analysis_depth: analysisDepth,
            focus_areas: focusAreas,
            template_types: templateTypes,
            use_openai: useOpenAI,
            quick_mode: quickMode,
            last_updated: new Date().toISOString()
          }, {
            onConflict: 'user_id,domain_id'
          });
          
        if (error) throw error;
      } catch (error) {
        console.error('Error saving AI configuration:', error);
        // Continue with analysis even if save fails
      } finally {
        setSavingConfig(false);
      }
    }
    
    console.log('[Performance] Starting analysis with configuration:', {
      analysisDepth,
      useOpenAI,
      quickMode,
      focusAreas,
      templateTypes
    });
    
    // Call the parent component's analysis function
    onStartAnalysis();
    
    // Log end of preparation phase
    console.log('[Performance] Analysis preparation completed in', performance.now() - startTime, 'ms');
  };
  
  const selectedFocusAreasCount = Object.values(focusAreas).filter(Boolean).length;
  const selectedTemplateTypesCount = Object.values(templateTypes).filter(Boolean).length;
  
  return (
    <div className="bg-white rounded-lg shadow-sm p-6 mt-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <div className="p-2 bg-indigo-100 rounded-md mr-3">
            <Brain className="h-5 w-5 text-indigo-600" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-gray-800">
              AI Analysis Configuration
            </h2>
            <p className="text-sm text-gray-600">
              {expanded ? 
                "Customize your AI analysis settings below" : 
                "Configure how the AI analyzes your input data"}
            </p>
          </div>
        </div>
        <button
          onClick={() => setExpanded(!expanded)}
          className="text-blue-600 hover:text-blue-800"
        >
          {expanded ? "Hide Options" : "Show Options"}
        </button>
      </div>
      
      {expanded && (
        <div className="mt-4 space-y-5 border-t border-gray-100 pt-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center">
              <Zap className="h-4 w-4 text-amber-500 mr-1.5" />
              Analysis Depth
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
              <button
                className={`p-2 text-sm border rounded-md flex flex-col items-center justify-center ${
                  analysisDepth === 'basic' ? 'bg-blue-50 border-blue-300' : 'border-gray-200 hover:bg-gray-50'
                }`}
                onClick={() => setAnalysisDepth('basic')}
              >
                <span className="font-medium">Basic</span>
                <span className="text-xs text-gray-500 mt-1">Quick overview</span>
              </button>
              <button
                className={`p-2 text-sm border rounded-md flex flex-col items-center justify-center ${
                  analysisDepth === 'standard' ? 'bg-blue-50 border-blue-300' : 'border-gray-200 hover:bg-gray-50'
                }`}
                onClick={() => setAnalysisDepth('standard')}
              >
                <span className="font-medium">Standard</span>
                <span className="text-xs text-gray-500 mt-1">Balanced analysis</span>
              </button>
              <button
                className={`p-2 text-sm border rounded-md flex flex-col items-center justify-center ${
                  analysisDepth === 'detailed' ? 'bg-blue-50 border-blue-300' : 'border-gray-200 hover:bg-gray-50'
                }`}
                onClick={() => setAnalysisDepth('detailed')}
              >
                <span className="font-medium">Detailed</span>
                <span className="text-xs text-gray-500 mt-1">In-depth review</span>
              </button>
              <button
                className={`p-2 text-sm border rounded-md flex flex-col items-center justify-center ${
                  analysisDepth === 'comprehensive' ? 'bg-blue-50 border-blue-300' : 'border-gray-200 hover:bg-gray-50'
                }`}
                onClick={() => setAnalysisDepth('comprehensive')}
              >
                <span className="font-medium">Comprehensive</span>
                <span className="text-xs text-gray-500 mt-1">Maximum detail</span>
              </button>
            </div>
          </div>
          
          <div className="flex items-center justify-between bg-gradient-to-r from-indigo-50 to-purple-50 p-3 rounded-md border border-indigo-100">
            <div className="flex items-center">
              <div className="p-2 bg-indigo-100 rounded-md mr-3">
                <Sparkles className="h-4 w-4 text-indigo-600" />
              </div>
              <div>
                <h3 className="font-medium text-gray-800 flex items-center">
                  OpenAI Powered Analysis
                  <span className="ml-2 px-1.5 py-0.5 text-xs rounded-full bg-indigo-100 text-indigo-800">PRO</span>
                </h3>
                <p className="text-sm text-gray-600">Use advanced AI for more accurate, contextual analysis</p>
              </div>
            </div>
            <div className="relative inline-block w-12 mr-2 align-middle select-none">
              <input 
                type="checkbox" 
                name="useOpenAI" 
                id="useOpenAI" 
                checked={useOpenAI}
                onChange={(e) => setUseOpenAI(e.target.checked)}
                className="sr-only"
              />
              <label 
                htmlFor="useOpenAI"
                className={`block overflow-hidden h-6 rounded-full cursor-pointer transition-colors duration-200 ease-in-out ${useOpenAI ? 'bg-indigo-600' : 'bg-gray-300'}`}
              >
                <span 
                  className={`block h-6 w-6 rounded-full bg-white shadow transform transition-transform duration-200 ease-in-out ${useOpenAI ? 'translate-x-6' : 'translate-x-0'}`}
                ></span>
              </label>
            </div>
          </div>
          
          {/* Quick Mode Switch - Enabled by default for speed */}
          <div className="flex items-center justify-between bg-gradient-to-r from-green-50 to-blue-50 p-3 rounded-md border border-green-100">
            <div className="flex items-center">
              <div className="p-2 bg-green-100 rounded-md mr-3">
                <Zap className="h-4 w-4 text-green-600" />
              </div>
              <div>
                <h3 className="font-medium text-gray-800 flex items-center">
                  Quick Analysis Mode
                  <span className="ml-2 px-1.5 py-0.5 text-xs rounded-full bg-green-100 text-green-800">FAST</span>
                </h3>
                <p className="text-sm text-gray-600">Optimize for speed with simplified analysis and single template</p>
              </div>
            </div>
            <div className="relative inline-block w-12 mr-2 align-middle select-none">
              <input 
                type="checkbox" 
                name="quickMode" 
                id="quickMode" 
                checked={quickMode}
                onChange={(e) => setQuickMode(e.target.checked)}
                className="sr-only"
              />
              <label 
                htmlFor="quickMode"
                className={`block overflow-hidden h-6 rounded-full cursor-pointer transition-colors duration-200 ease-in-out ${quickMode ? 'bg-green-600' : 'bg-gray-300'}`}
              >
                <span 
                  className={`block h-6 w-6 rounded-full bg-white shadow transform transition-transform duration-200 ease-in-out ${quickMode ? 'translate-x-6' : 'translate-x-0'}`}
                ></span>
              </label>
            </div>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                <Target className="h-4 w-4 text-green-500 mr-1.5" />
                Focus Areas <span className="text-xs text-gray-500 ml-1">({selectedFocusAreasCount} selected)</span>
              </label>
              <div className="space-y-2 bg-gray-50 p-3 rounded-md">
                <div className="flex items-center">
                  <input 
                    id="focus-strategic" 
                    type="checkbox" 
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    checked={focusAreas.strategic}
                    onChange={(e) => updateFocusArea('strategic', e.target.checked)}
                  />
                  <label htmlFor="focus-strategic" className="ml-2 block text-sm text-gray-700">
                    Strategic Alignment
                  </label>
                </div>
                <div className="flex items-center">
                  <input 
                    id="focus-operational" 
                    type="checkbox" 
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    checked={focusAreas.operational}
                    onChange={(e) => updateFocusArea('operational', e.target.checked)}
                  />
                  <label htmlFor="focus-operational" className="ml-2 block text-sm text-gray-700">
                    Operational Excellence
                  </label>
                </div>
                <div className="flex items-center">
                  <input 
                    id="focus-performance" 
                    type="checkbox" 
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    checked={focusAreas.performance}
                    onChange={(e) => updateFocusArea('performance', e.target.checked)}
                  />
                  <label htmlFor="focus-performance" className="ml-2 block text-sm text-gray-700">
                    Performance & Metrics
                  </label>
                </div>
                <div className="flex items-center">
                  <input 
                    id="focus-competency" 
                    type="checkbox" 
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    checked={focusAreas.competency}
                    onChange={(e) => updateFocusArea('competency', e.target.checked)}
                  />
                  <label htmlFor="focus-competency" className="ml-2 block text-sm text-gray-700">
                    Competency Development
                  </label>
                </div>
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                <LayoutTemplate className="h-4 w-4 text-purple-500 mr-1.5" />
                Template Types <span className="text-xs text-gray-500 ml-1">({selectedTemplateTypesCount} selected)</span>
              </label>
              <div className="space-y-2 bg-gray-50 p-3 rounded-md">
                <div className="flex items-center">
                  <input 
                    id="template-governance" 
                    type="checkbox" 
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    checked={templateTypes.governance}
                    onChange={(e) => updateTemplateType('governance', e.target.checked)}
                  />
                  <label htmlFor="template-governance" className="ml-2 block text-sm text-gray-700">
                    Governance Frameworks
                  </label>
                </div>
                <div className="flex items-center">
                  <input 
                    id="template-processes" 
                    type="checkbox" 
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    checked={templateTypes.processes}
                    onChange={(e) => updateTemplateType('processes', e.target.checked)}
                  />
                  <label htmlFor="template-processes" className="ml-2 block text-sm text-gray-700">
                    Process Documentation
                  </label>
                </div>
                <div className="flex items-center">
                  <input 
                    id="template-assessment" 
                    type="checkbox" 
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    checked={templateTypes.assessment}
                    onChange={(e) => updateTemplateType('assessment', e.target.checked)}
                  />
                  <label htmlFor="template-assessment" className="ml-2 block text-sm text-gray-700">
                    Assessment Tools
                  </label>
                </div>
                <div className="flex items-center">
                  <input 
                    id="template-implementation" 
                    type="checkbox" 
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    checked={templateTypes.implementation}
                    onChange={(e) => updateTemplateType('implementation', e.target.checked)}
                  />
                  <label htmlFor="template-implementation" className="ml-2 block text-sm text-gray-700">
                    Implementation Guides
                  </label>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-blue-50 p-3 rounded-md">
            <div className="flex items-start">
              <Info className="h-4 w-4 text-blue-600 mt-0.5 mr-2 flex-shrink-0" />
              <div>
                <p className="text-xs text-blue-700">
                  <span className="font-semibold">Speed vs Quality:</span> Analysis typically takes 20-40 seconds with quick mode enabled. For more detailed analysis, disable quick mode (may take 60-90 seconds).
                </p>
                {quickMode && (
                  <p className="text-xs text-blue-700 mt-1">
                    <span className="font-medium">Quick Mode is enabled</span> - Analysis will prioritize speed over detail.
                  </p>
                )}
              </div>
            </div>
          </div>
          
          <div className="pt-4 flex items-center justify-between">
            <div className="text-sm text-gray-500 flex items-center">
              <Settings className="h-4 w-4 mr-1.5" />
              Analysis for {domain.name}
            </div>
            <button
              className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 flex items-center"
              onClick={handleAnalyze}
              disabled={savingConfig}
            >
              {savingConfig ? (
                <>Saving configuration...</>
              ) : useOpenAI ? (
                <>
                  Start {quickMode ? "Quick" : ""} OpenAI Analysis <Sparkles className="ml-1.5 h-4 w-4" />
                </>
              ) : (
                <>
                  Start Analysis <MoveRight className="ml-1.5 h-4 w-4" />
                </>
              )}
            </button>
          </div>
        </div>
      )}
      
      {!expanded && (
        <div className="mt-4 pt-4 border-t border-gray-100 flex justify-end">
          <button
            className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 flex items-center"
            onClick={handleAnalyze}
          >
            {useOpenAI ? (
              <>
                Quick Analysis with OpenAI <Sparkles className="ml-1.5 h-4 w-4" />
              </>
            ) : (
              <>
                Analyze with AI <MoveRight className="ml-1.5 h-4 w-4" />
              </>
            )}
          </button>
        </div>
      )}
    </div>
  );
};

export default AIConfigurationPanel;