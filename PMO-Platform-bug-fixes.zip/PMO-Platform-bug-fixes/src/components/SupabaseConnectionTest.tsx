import React, { useEffect, useState } from 'react';
import { supabase, isSupabaseConfigured } from '../services/supabaseClient';
import { AlertCircle, CheckCircle, RefreshCw, Globe, Key, Settings, ExternalLink } from 'lucide-react';

const SupabaseConnectionTest: React.FC = () => {
  const [connectionStatus, setConnectionStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [errorDetails, setErrorDetails] = useState<string | null>(null);
  const [supabaseUrl, setSupabaseUrl] = useState<string>('');
  const [hasKey, setHasKey] = useState<boolean>(false);
  const [pingTime, setPingTime] = useState<number | null>(null);

  useEffect(() => {
    // Get configuration info
    const url = import.meta.env.VITE_SUPABASE_URL || '';
    const key = import.meta.env.VITE_SUPABASE_ANON_KEY || '';
    
    setSupabaseUrl(url);
    setHasKey(!!key);

    // Test the connection on mount
    testConnection();
  }, []);

  const testConnection = async () => {
    setConnectionStatus('loading');
    setErrorDetails(null);
    setPingTime(null);
    
    try {
      // Check if Supabase is configured
      if (!isSupabaseConfigured()) {
        throw new Error('Supabase is not properly configured. Check your environment variables.');
      }

      const startTime = performance.now();
      
      // Try to ping Supabase with a simple query
      const { data, error } = await supabase
        .from('profiles')
        .select('count(*)', { count: 'exact', head: true });
        
      const endTime = performance.now();
      setPingTime(Math.round(endTime - startTime));

      if (error) {
        throw error;
      }

      console.log('Supabase connection successful:', data);
      setConnectionStatus('success');
    } catch (error) {
      console.error('Supabase connection error:', error);
      setConnectionStatus('error');
      setErrorDetails(error instanceof Error ? error.message : String(error));
    }
  };

  return (
    <div className="max-w-3xl mx-auto bg-white border border-gray-200 rounded-lg shadow-sm p-6">
      <h2 className="text-xl font-bold text-gray-800 flex items-center mb-4">
        <Globe className="mr-2 text-blue-600 h-6 w-6" />
        Supabase Connection Diagnostics
      </h2>

      <div className="space-y-6">
        {/* Configuration Status */}
        <div className="p-4 bg-gray-50 rounded-lg border border-gray-200">
          <h3 className="font-medium text-gray-800 mb-2 flex items-center">
            <Settings className="h-4 w-4 mr-2 text-gray-600" />
            Configuration Status
          </h3>
          
          <div className="space-y-2">
            <div className="flex items-start">
              <div className="flex-shrink-0 w-24 text-sm font-medium text-gray-500">URL:</div>
              <div className="flex-1">
                {supabaseUrl ? (
                  <div className="flex items-center">
                    <span className="text-sm text-gray-900">{supabaseUrl}</span>
                    <CheckCircle className="h-4 w-4 text-green-500 ml-2" />
                  </div>
                ) : (
                  <div className="flex items-center">
                    <span className="text-sm text-red-600">Missing Supabase URL</span>
                    <AlertCircle className="h-4 w-4 text-red-500 ml-2" />
                  </div>
                )}
              </div>
            </div>
            
            <div className="flex items-start">
              <div className="flex-shrink-0 w-24 text-sm font-medium text-gray-500">API Key:</div>
              <div className="flex-1">
                {hasKey ? (
                  <div className="flex items-center">
                    <span className="text-sm text-gray-900">●●●●●●●●●●●●●●●●●●●● (configured)</span>
                    <CheckCircle className="h-4 w-4 text-green-500 ml-2" />
                  </div>
                ) : (
                  <div className="flex items-center">
                    <span className="text-sm text-red-600">Missing Supabase API Key</span>
                    <AlertCircle className="h-4 w-4 text-red-500 ml-2" />
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
        
        {/* Connection Test */}
        <div className="p-4 bg-gray-50 rounded-lg border border-gray-200">
          <div className="flex justify-between items-center mb-2">
            <h3 className="font-medium text-gray-800 flex items-center">
              <Globe className="h-4 w-4 mr-2 text-blue-600" />
              Connection Test
            </h3>
            
            <button 
              onClick={testConnection} 
              disabled={connectionStatus === 'loading'}
              className="px-3 py-1.5 text-sm border border-blue-300 text-blue-700 bg-blue-50 rounded-md hover:bg-blue-100 flex items-center"
            >
              <RefreshCw className={`h-3.5 w-3.5 mr-1.5 ${connectionStatus === 'loading' ? 'animate-spin' : ''}`} />
              Test Connection
            </button>
          </div>
          
          <div className="mt-3">
            {connectionStatus === 'idle' && (
              <div className="py-3 text-center text-gray-500">
                Click "Test Connection" to check Supabase connectivity
              </div>
            )}
            
            {connectionStatus === 'loading' && (
              <div className="py-3 flex justify-center items-center text-blue-600">
                <RefreshCw className="h-5 w-5 animate-spin mr-3" />
                Testing connection to Supabase...
              </div>
            )}
            
            {connectionStatus === 'success' && (
              <div className="p-4 bg-green-50 border border-green-200 rounded-md flex items-start">
                <CheckCircle className="h-5 w-5 text-green-600 mt-0.5 mr-3 flex-shrink-0" />
                <div>
                  <p className="text-green-800 font-medium">Connection successful!</p>
                  <p className="text-green-700 text-sm mt-1">
                    Successfully connected to Supabase.
                    {pingTime && ` Response time: ${pingTime}ms`}
                  </p>
                </div>
              </div>
            )}
            
            {connectionStatus === 'error' && (
              <div className="p-4 bg-red-50 border border-red-200 rounded-md flex items-start">
                <AlertCircle className="h-5 w-5 text-red-600 mt-0.5 mr-3 flex-shrink-0" />
                <div>
                  <p className="text-red-800 font-medium">Connection failed</p>
                  <p className="text-red-700 text-sm mt-1">{errorDetails || 'Unknown error occurred'}</p>
                </div>
              </div>
            )}
          </div>
        </div>
        
        {/* Troubleshooting Guide */}
        <div className="p-4 bg-amber-50 rounded-lg border border-amber-200">
          <h3 className="font-medium text-amber-800 mb-2">Troubleshooting</h3>
          
          <div className="space-y-3 text-sm text-amber-700">
            <p className="flex items-start">
              <span className="inline-block w-5 h-5 rounded-full bg-amber-200 text-amber-800 flex items-center justify-center text-xs font-bold mr-2 flex-shrink-0">1</span>
              <span>Check that your Supabase project is online by visiting <a href={supabaseUrl} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline flex items-center">Supabase dashboard <ExternalLink className="h-3 w-3 ml-0.5" /></a></span>
            </p>
            
            <p className="flex items-start">
              <span className="inline-block w-5 h-5 rounded-full bg-amber-200 text-amber-800 flex items-center justify-center text-xs font-bold mr-2 flex-shrink-0">2</span>
              <span>Verify that your environment variables are correct in the <code className="bg-amber-100 px-1 py-0.5 rounded">.env</code> file</span>
            </p>
            
            <p className="flex items-start">
              <span className="inline-block w-5 h-5 rounded-full bg-amber-200 text-amber-800 flex items-center justify-center text-xs font-bold mr-2 flex-shrink-0">3</span>
              <span>Check for browser extensions or network settings that might be blocking the connection</span>
            </p>
            
            <p className="flex items-start">
              <span className="inline-block w-5 h-5 rounded-full bg-amber-200 text-amber-800 flex items-center justify-center text-xs font-bold mr-2 flex-shrink-0">4</span>
              <span>Ensure that your Supabase project has the correct CORS settings. Go to Project Settings → API → CORS and add your application's URL</span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SupabaseConnectionTest;