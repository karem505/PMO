import React from 'react';
import { Calendar, TrendingUp } from 'lucide-react';

interface MaturityHistoryEntry {
  date: string;
  overall: string;
  domains: Record<number, string>;
}

interface MaturityProgressTrackerProps {
  history: MaturityHistoryEntry[];
}

const MaturityProgressTracker: React.FC<MaturityProgressTrackerProps> = ({ history }) => {
  // Sort history by date
  const sortedHistory = [...history].sort((a, b) => 
    new Date(a.date).getTime() - new Date(b.date).getTime()
  );
  
  const maturityLevels = ['initial', 'defined', 'managed', 'optimized', 'innovative'];
  
  // Get the level index for the given level string
  const getLevelIndex = (level: string): number => {
    return maturityLevels.indexOf(level.toLowerCase());
  };
  
  // Get color class based on maturity level
  const getLevelColor = (level: string): string => {
    const index = getLevelIndex(level);
    switch (index) {
      case 0: return 'bg-red-100 border-red-200 text-red-800';
      case 1: return 'bg-amber-100 border-amber-200 text-amber-800';
      case 2: return 'bg-green-100 border-green-200 text-green-800';
      case 3: return 'bg-blue-100 border-blue-200 text-blue-800';
      case 4: return 'bg-purple-100 border-purple-200 text-purple-800';
      default: return 'bg-gray-100 border-gray-200 text-gray-800';
    }
  };
  
  // Calculate improvements between assessments
  const calculateImprovements = () => {
    if (sortedHistory.length < 2) return [];
    
    return sortedHistory.slice(1).map((entry, index) => {
      const previousEntry = sortedHistory[index];
      const currentOverallIndex = getLevelIndex(entry.overall);
      const previousOverallIndex = getLevelIndex(previousEntry.overall);
      
      const improvementCount = Object.keys(entry.domains).reduce((count, domainId) => {
        const domainIdNum = parseInt(domainId);
        const currentDomainIndex = getLevelIndex(entry.domains[domainIdNum]);
        const previousDomainIndex = getLevelIndex(previousEntry.domains[domainIdNum] || 'initial');
        
        return count + (currentDomainIndex > previousDomainIndex ? 1 : 0);
      }, 0);
      
      return {
        date: entry.date,
        overall: entry.overall,
        overallImprovement: currentOverallIndex > previousOverallIndex,
        previousDate: previousEntry.date,
        domainImprovements: improvementCount
      };
    });
  };
  
  const improvements = calculateImprovements();
  
  return (
    <div>
      <div className="flex items-center mb-4">
        <Calendar className="h-5 w-5 text-gray-500 mr-2" />
        <h3 className="font-medium text-gray-800">Maturity Progression Timeline</h3>
      </div>
      
      <div className="relative">
        {/* Timeline line */}
        <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-gray-200"></div>
        
        <div className="space-y-6">
          {sortedHistory.map((entry, index) => (
            <div key={index} className="flex">
              <div className={`z-10 flex items-center justify-center w-8 h-8 rounded-full border-2 mr-4 ${getLevelColor(entry.overall)}`}>
                {index + 1}
              </div>
              
              <div className="flex-1">
                <div className="bg-white border border-gray-200 rounded-lg p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <span className="text-sm text-gray-500 block mb-1">{new Date(entry.date).toLocaleDateString()}</span>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getLevelColor(entry.overall)}`}>
                        {entry.overall.toUpperCase()} Maturity
                      </span>
                    </div>
                    
                    {improvements[index - 1] && (
                      <div className="flex items-center">
                        <TrendingUp className="h-4 w-4 text-green-600 mr-1" />
                        <span className="text-xs text-green-600">
                          {improvements[index - 1].domainImprovements} domain{improvements[index - 1].domainImprovements !== 1 ? 's' : ''} improved
                        </span>
                      </div>
                    )}
                  </div>
                  
                  {Object.keys(entry.domains).length > 0 && (
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                      {Object.entries(entry.domains).map(([domainId, level]) => {
                        const domainIdNum = parseInt(domainId);
                        const previousLevel = index > 0 ? sortedHistory[index - 1].domains[domainIdNum] : null;
                        const improved = previousLevel && getLevelIndex(level) > getLevelIndex(previousLevel);
                        
                        return (
                          <div 
                            key={domainId} 
                            className={`p-2 rounded border text-xs ${getLevelColor(level)}`}
                          >
                            <div className="flex items-center justify-between">
                              <span>Domain {domainId}</span>
                              {improved && <TrendingUp className="h-3 w-3 text-green-700" />}
                            </div>
                            <span className="font-medium">{level.toUpperCase()}</span>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MaturityProgressTracker;