import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Upload, Paperclip, X, Download, Eye, Trash2, Loader2, CheckCircle, AlertCircle, FileText, File, AlertTriangle } from 'lucide-react';
import { useAuth } from './auth/AuthContext';
import { useAppStore } from '../store';
import { supabase } from '../services/supabaseClient';
import { v4 as uuidv4 } from 'uuid';
import FileViewer from './FileViewer';
import { TaskAttachment } from '../types';
import { useLanguage } from '../contexts/LanguageContext';
interface TaskFileAttachmentProps {
  taskId: string;
  projectId?: string;
  existingAttachments?: TaskAttachment[];
  onUploadComplete?: (attachments: TaskAttachment[]) => void;
}

const TaskFileAttachment: React.FC<TaskFileAttachmentProps> = ({ 
  taskId, 
  projectId,
  existingAttachments = [],
  onUploadComplete 
}) => {
  // State for attachments
  const [attachments, setAttachments] = useState<TaskAttachment[]>(existingAttachments || []);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [showAttachments, setShowAttachments] = useState(existingAttachments.length > 0);
  const [selectedFile, setSelectedFile] = useState<TaskAttachment | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [dragActive, setDragActive] = useState(false);
  const { t } = useLanguage();
  const { currentUser } = useAuth();
  const { getActiveProject, updateTaskData, connectionError, showConnectionErrors } = useAppStore();
  const activeProject = getActiveProject();

  // Update attachments when props change
  useEffect(() => {
    setAttachments(existingAttachments || []);
    setShowAttachments(existingAttachments.length > 0);
  }, [existingAttachments]);
  
  // Handle drag events
  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  }, []);

  // Handle drop event
  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFiles(e.dataTransfer.files);
    }
  }, []);
  
  // Process files for upload
  const handleFiles = async (files: FileList) => {
    if (!files || files.length === 0) return;
    
    setIsUploading(true);
    setUploadProgress(0);
    setUploadError(null);
    
    const newAttachments: TaskAttachment[] = [];
    let errorOccurred = false;
    
    // Validate files first
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      
      // Check file size (10MB)
      if (file.size > 10 * 1024 * 1024) {
        setUploadError(`File "${file.name}" exceeds the maximum size of 10MB.`);
        setIsUploading(false);
        return;
      }
      
      // Basic file type validation
      const fileType = file.type;
      const validTypes = [
        'image/', 'application/pdf', 'text/', 'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'application/zip', 'application/x-zip-compressed'
      ];
      
      // Check if file type starts with any of the valid types
      const isValid = validTypes.some(type => fileType.startsWith(type) || fileType === '');
      
      if (!isValid) {
        setUploadError(`File type "${fileType}" is not supported.`);
        setIsUploading(false);
        return;
      }
    }
    
    // Process each file
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      
      try {
        // If we're online and have Supabase connection, upload to storage
        if (currentUser && projectId && !connectionError) {
          try {
            // Create a unique file name to avoid collisions
            const fileExtension = file.name.split('.').pop();
            const fileName = `${uuidv4()}.${fileExtension}`;
            const filePath = `tasks/${taskId}/${fileName}`;
            
            // Show upload progress
            const uploadProgressHandler = (progress: { loaded: number; total: number }) => {
              const percentProgress = Math.round((progress.loaded / progress.total) * 100);
              setUploadProgress(percentProgress);
            };
            
            // Upload the file
            const { data, error } = await supabase.storage
              .from('task-attachments')
              .upload(filePath, file, {
                cacheControl: '3600',
                upsert: false
              });
            
            if (error) throw error;
            // Get the public URL
            const { data: urlData } = supabase.storage
              .from('task-attachments')
              .getPublicUrl(filePath);
              
            newAttachments.push({
              name: file.name,
              url: urlData.publicUrl,
              id: fileName,
              size: file.size,
              type: file.type,
              uploadDate: new Date().toISOString()
            });
            
          } catch (error) {
            console.error('Supabase upload error:', error);
            throw error;
          }
        } else {
          // Fallback for offline mode: Create object URLs
          const objectUrl = URL.createObjectURL(file);
          newAttachments.push({
            name: file.name,
            url: objectUrl,
            id: uuidv4(),
            size: file.size,
            type: file.type,
            uploadDate: new Date().toISOString()
          });
        }
        
        // Update progress
        setUploadProgress(Math.round(((i + 1) / files.length) * 100));
        
      } catch (error) {
        console.error('Error uploading file:', error);
        errorOccurred = true;
        setUploadError('Failed to upload file: ' + (error instanceof Error ? error.message : 'Unknown error'));
        break;
      }
    }
    
    // Update state with new attachments if no errors occurred
    if (!errorOccurred && newAttachments.length > 0) {
      const updatedAttachments = [...attachments, ...newAttachments];
      setAttachments(updatedAttachments);
      setShowAttachments(true);
      
      if (onUploadComplete) {
        onUploadComplete(updatedAttachments);
      }
      
      // Update task data directly in the store
      updateTaskData(taskId, {
        attachments: updatedAttachments.map(a => JSON.stringify(a))
      });
    }
    
    setIsUploading(false);
    // Reset the file input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };
  
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleFiles(files);
    }
  };
  
  const handleRemoveAttachment = async (id: string) => {
    try {
      // Remove from Supabase Storage if connected and not in offline mode
      if (currentUser && projectId && !connectionError) {
        const attachmentToRemove = attachments.find(a => a.id === id);
        if (attachmentToRemove) {
          try {
            const filePath = `tasks/${taskId}/${id}`;
            const { error } = await supabase.storage
              .from('task-attachments')
              .remove([filePath]);
              
            if (error) throw error;
          } catch (error) {
            console.warn('Error removing attachment from storage (continuing anyway):', error);
            // Continue with local removal even if storage removal fails
          }
        }
      }
      
      // Update state
      const updatedAttachments = attachments.filter(a => a.id !== id);
      setAttachments(updatedAttachments);
      
      if (onUploadComplete) {
        onUploadComplete(updatedAttachments);
      }
      
      // Update task data directly in the store
      updateTaskData(taskId, {
        attachments: updatedAttachments.map(a => JSON.stringify(a))
      });
      
      // Clear selected file if it's the one being removed
      if (selectedFile && selectedFile.id === id) {
        setSelectedFile(null);
      }
      
    } catch (error) {
      console.error('Error removing attachment:', error);
      setUploadError('Failed to remove attachment');
    }
  };
  
  const formatFileSize = (bytes?: number): string => {
    if (bytes === undefined) return 'Unknown size';
    if (bytes === 0) return '0 Bytes';
    
    const units = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    
    return `${parseFloat((bytes / Math.pow(1024, i)).toFixed(2))} ${units[i]}`;
  };
  
  const getFileTypeCategory = (file: {name: string, type?: string}): string => {
    if (!file.type) {
      // Try to guess type from extension
      const extension = file.name.split('.').pop()?.toLowerCase();
      if (!extension) return 'unknown';
      
      if (['jpg', 'jpeg', 'png', 'gif', 'svg', 'webp'].includes(extension)) {
        return 'image';
      } else if (['pdf', 'doc', 'docx'].includes(extension)) {
        return 'document';
      } else if (['xls', 'xlsx', 'csv'].includes(extension)) {
        return 'spreadsheet';
      } else if (['ppt', 'pptx'].includes(extension)) {
        return 'presentation';
      } else if (['txt', 'md', 'rtf'].includes(extension)) {
        return 'text';
      } else if (['js', 'jsx', 'ts', 'tsx', 'html', 'css', 'json', 'xml', 'sql'].includes(extension)) {
        return 'code';
      } else if (['zip', 'rar', '7z', 'tar', 'gz'].includes(extension)) {
        return 'archive';
      } else {
        return 'unknown';
      }
    }
    
    // Determine type from MIME type
    const supportedFileTypes = {
      image: ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml'],
      document: ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
      spreadsheet: ['application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'],
      presentation: ['application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation'],
      text: ['text/plain', 'text/markdown', 'text/html', 'text/css', 'text/javascript'],
      code: ['application/json', 'text/javascript', 'application/xml', 'text/css', 'text/html', 'application/x-sql'],
      archive: ['application/zip', 'application/x-rar-compressed', 'application/x-7z-compressed']
    };
    
    if (supportedFileTypes.image.includes(file.type)) {
      return 'image';
    } else if (supportedFileTypes.document.includes(file.type)) {
      return 'document';
    } else if (supportedFileTypes.spreadsheet.includes(file.type)) {
      return 'spreadsheet';
    } else if (supportedFileTypes.presentation.includes(file.type)) {
      return 'presentation';
    } else if (supportedFileTypes.text.includes(file.type)) {
      return 'text';
    } else if (supportedFileTypes.code.includes(file.type)) {
      return 'code';
    } else if (supportedFileTypes.archive.includes(file.type)) {
      return 'archive';
    } else {
      return 'unknown';
    }
  };
  
  const getFileIcon = (file: {name: string, type?: string}) => {
    const fileType = getFileTypeCategory(file);
    
    switch(fileType) {
      case 'image':
        return <File className="h-5 w-5 text-purple-500" />;
      case 'document':
        return <FileText className="h-5 w-5 text-blue-500" />;
      case 'spreadsheet':
        return <File className="h-5 w-5 text-green-500" />;
      case 'presentation':
        return <File className="h-5 w-5 text-orange-500" />;
      case 'text':
        return <FileText className="h-5 w-5 text-gray-500" />;
      case 'code':
        return <File className="h-5 w-5 text-yellow-500" />;
      case 'archive':
        return <File className="h-5 w-5 text-indigo-500" />;
      default:
        return <File className="h-5 w-5 text-gray-500" />;
    }
  };

  const viewFile = (file: TaskAttachment) => {
    setSelectedFile(file);
  };
  
  const handleSelectFile = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };
  
  return (
    <div className="mt-4 border-t border-gray-100 pt-4">
      <div className="flex items-center justify-between cursor-pointer mb-4" onClick={() => setShowAttachments(!showAttachments)}>
        <h3 className="text-sm font-medium text-gray-700 flex items-center">
          <Paperclip className="h-4 w-4 mr-2 text-gray-500" />
          {t('tasks.attachments','Attachments')} {attachments.length > 0 && `(${attachments.length})`}
        </h3>
        {showAttachments ? (
          <ChevronUp className="h-4 w-4 text-gray-400" />
        ) : (
          <ChevronDown className="h-4 w-4 text-gray-400" />
        )}
      </div>
      
      {showAttachments && (
        <div>
          {/* File upload area */}
          <div 
            className={`border-2 border-dashed rounded-lg p-4 text-center mb-4 ${
              dragActive 
                ? 'border-primary-400 bg-primary-50' 
                : 'border-gray-300 hover:border-gray-400'
            } transition-colors cursor-pointer`}
            onClick={handleSelectFile}
            onDragEnter={handleDrag}
            onDragOver={handleDrag}
            onDragLeave={handleDrag}
            onDrop={handleDrop}
          >
            <input
              type="file"
              ref={fileInputRef}
              className="hidden"
              onChange={handleFileChange}
              multiple
              accept=".jpg,.jpeg,.png,.gif,.svg,.webp,.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.md,.json,.zip,.rar,.7z,.html,.css,.js,.ts"
            />
            <Upload className="h-6 w-6 text-gray-400 mx-auto mb-2" />
            <p className="text-sm text-gray-600 mb-1">
              {t('tasks.dragAndDropFilesHere','Drag and drop files here, or click to select files')}
            </p>
            <p className="text-xs text-gray-500">
              {t('tasks.supportedFormats','Supported formats: documents (Max 10MB)')}
            </p>
          </div>
          
          {/* Upload progress */}
          {isUploading && (
            <div className="mb-4">
              <div className="flex justify-between items-center mb-1">
                <span className="text-xs font-medium text-gray-700">{t('tasks.uploading','Uploading...')}</span>
                <span className="text-xs text-gray-500">{uploadProgress}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-1.5">
                <div
                  className="bg-primary-600 h-1.5 rounded-full transition-all duration-300"
                  style={{ width: `${uploadProgress}%` }}
                ></div>
              </div>
            </div>
          )}
          
          {/* Error message */}
          {uploadError && (
            <div className="mb-4 p-3 bg-red-50 text-red-700 text-sm rounded-md flex items-start">
              <AlertCircle className="h-4 w-4 mt-0.5 mr-2 flex-shrink-0" />
              <span>{uploadError}</span>
            </div>
          )}
          
          {/* Connection error message */}
          {connectionError && showConnectionErrors && (
            <div className="bg-amber-50 dark:bg-amber-900/30 border border-amber-200 dark:border-amber-800 rounded-md p-4 mb-4 flex items-start">
              <AlertTriangle className="h-5 w-5 text-amber-600 dark:text-amber-500 mt-0.5 me-2 flex-shrink-0" />
              <div>
                <p className="font-medium">{t('tasks.workingInOfflineMode','Working in offline mode')}</p>
                <p className="text-xs mt-1">
                  {t('tasks.workingOfflineFileUploadLimited','Working offline - file upload might be limited')}
                </p>
              </div>
            </div>
          )}
          
          {/* File list */}
          {attachments.length > 0 ? (
            <div className="space-y-2 max-h-60 overflow-y-auto pr-1 mb-4">
              {attachments.map((attachment) => (
                <div key={attachment.id} className="flex items-center justify-between p-2 bg-gray-50 rounded-lg border border-gray-100">
                  <div className="flex items-center overflow-hidden">
                    {getFileIcon(attachment)}
                    <div className="ml-2 min-w-0">
                      <p className="text-sm font-medium text-gray-700 truncate">{attachment.name}</p>
                      <p className="text-xs text-gray-500">{formatFileSize(attachment.size)}</p>
                    </div>
                  </div>
                  
                  <div className="flex space-x-1">
                    {/* Preview button */}
                    <button
                      className="p-1.5 hover:bg-gray-200 rounded-md transition-colors"
                      onClick={(e) => {
                        e.stopPropagation();
                        viewFile(attachment);
                      }}
                      title="Preview"
                    >
                      <Eye className="h-4 w-4 text-gray-600" />
                    </button>
                    
                    {/* Download button */}
                    <a
                      href={attachment.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-1.5 hover:bg-gray-200 rounded-md transition-colors"
                      onClick={e => e.stopPropagation()}
                      download={attachment.name}
                      title="Download"
                    >
                      <Download className="h-4 w-4 text-gray-600" />
                    </a>
                    
                    {/* Delete button */}
                    <button
                      className="p-1.5 hover:bg-red-100 rounded-md transition-colors"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleRemoveAttachment(attachment.id);
                      }}
                      title="Delete"
                    >
                      <Trash2 className="h-4 w-4 text-red-600" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-gray-500 italic mt-2 mb-4">{t('tasks.noAttachmentsAddedYet','No attachments added yet')}</p>
          )}
          
          {/* Add attachment button */}
          <button
            className="flex items-center text-sm text-primary-600 hover:text-primary-800"
            onClick={handleSelectFile}
            disabled={isUploading}
          >
            <Upload className="h-4 w-4 mr-1.5" />
            {t('tasks.addAttachment','Add Attachment')}
          </button>
        </div>
      )}
      
      {/* File preview */}
      {selectedFile && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-gray-200 px-6 py-4">
              <h3 className="text-lg font-semibold text-gray-800 flex items-center truncate">
                {getFileIcon(selectedFile)}
                <span className="ml-2 truncate">{selectedFile.name}</span>
              </h3>
              <div className="flex items-center space-x-2">
                <a
                  href={selectedFile.url}
                  download={selectedFile.name}
                  className="p-2 hover:bg-gray-100 rounded-full"
                  title="Download"
                >
                  <Download className="h-5 w-5 text-gray-500" />
                </a>
                <button
                  onClick={() => setSelectedFile(null)}
                  className="p-2 hover:bg-gray-100 rounded-full"
                  title="Close"
                >
                  <X className="h-5 w-5 text-gray-500" />
                </button>
              </div>
            </div>
            <div className="flex-1 overflow-auto p-4 bg-gray-50">
              <FileViewer file={selectedFile} />
            </div>
            <div className="border-t border-gray-200 px-6 py-4 flex justify-between items-center">
              <div className="text-sm text-gray-500">
                {formatFileSize(attachments.find(a => a.id === selectedFile.id)?.size)}
              </div>
              <button
                onClick={() => setSelectedFile(null)}
                className="px-4 py-2 bg-gray-100 text-gray-800 rounded-md hover:bg-gray-200 transition-colors"
              >
                {t('tasks.close','Close')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const ChevronUp: React.FC<{className?: string}> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <polyline points="18 15 12 9 6 15"></polyline>
  </svg>
);

const ChevronDown: React.FC<{className?: string}> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <polyline points="6 9 12 15 18 9"></polyline>
  </svg>
);

export default TaskFileAttachment;