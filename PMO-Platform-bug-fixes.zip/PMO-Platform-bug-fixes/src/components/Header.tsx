import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Shield, Settings, LogOut, User, HelpCircle, ChevronDown, Menu, X, Sun, Moon } from 'lucide-react';
import { useAuth } from './auth/AuthContext';
import LanguageSwitcher from './LanguageSwitcher';
import ProjectSelector from './ProjectSelector';
import SubscriptionBadge from './SubscriptionBadge';
import { CreditCard } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { useLanguage } from '../contexts/LanguageContext';
import axios from 'axios';
import apiClient from '../api/client';

interface HeaderProps {
  isAdmin?: boolean;
  toggleSidebar?: () => void;
  sidebarOpen?: boolean;
  setSidebarOpen?: (open: boolean) => void;
}

const Header: React.FC<HeaderProps> = ({ isAdmin = false, toggleSidebar, sidebarOpen, setSidebarOpen }) => {
  const { t } = useLanguage();
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const navigate = useNavigate();
  const { currentUser, session, userProfile, signOut } = useAuth();
  const { darkMode, toggleDarkMode } = useTheme();
  const [remainingTokens, setRemainingTokens] = useState(0);
  
  useEffect(() => {
    if (currentUser) {
      apiClient.get('/pmo/tokens', {
        params: {
          'x-user-email': currentUser?.email,
        },
      }).then((response) => {
        setRemainingTokens(response.data.remaining_tokens);
      }).catch((error) => {
        console.error('error', error);
      });
    }
  }, [currentUser]);

  // Close sidebar when mobile menu is opened
  useEffect(() => {
    if (mobileMenuOpen && setSidebarOpen && sidebarOpen) {
      setSidebarOpen(false);
    }
  }, [mobileMenuOpen, setSidebarOpen, sidebarOpen]);

  const handleSignOut = async () => {
    try {
      setUserMenuOpen(false);
      await signOut();
    } catch (error) {
      console.error('Error signing out:', error);
      window.location.href = '/';
    }
  };

  // Close menus when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as HTMLElement;
      if (!target.closest('.user-menu') && !target.closest('.mobile-menu')) {
        setUserMenuOpen(false);
        setMobileMenuOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Handle toggle sidebar function to close mobile menu if needed
  const handleToggleSidebar = () => {
    if (mobileMenuOpen) {
      setMobileMenuOpen(false);
    }
    if (toggleSidebar) {
      toggleSidebar();
    }
  };

  return (
    <header className="bg-white border-b border-gray-200 dark:bg-neutral-800 dark:border-neutral-700 sticky top-0 z-50">
      <div className="max-w-8xl mx-auto">
        <div className="flex h-16 items-center justify-between px-4 sm:px-6 lg:px-8">
          {/* Left section */}
          <div className="flex items-center">
            <button 
              type="button" 
              className="lg:hidden p-2 text-gray-500 hover:text-gray-700 focus:outline-none"
              onClick={handleToggleSidebar}
              aria-label="Toggle sidebar"
            >
              <Menu className="h-6 w-6" />
            </button>
            
            <div className="hidden sm:flex items-center ml-4">
              <div className="projects-tab">
                <ProjectSelector />
              </div>
            </div>
          </div>

          {/* Center section - Tokens (hidden on mobile) */}
          <div className="hidden sm:block tokens-display">
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
              {t('common.remainingTokens', 'Remaining Tokens')}: {remainingTokens}
            </span>
          </div>

          {/* Right section */}
          <div className="flex items-center space-x-2 sm:space-x-4 rtl:space-x-reverse">
            {/* Mobile menu toggle */}
            <button
              className="sm:hidden p-2 text-gray-500 hover:text-gray-700 focus:outline-none"
              onClick={() => {
                setMobileMenuOpen(!mobileMenuOpen);
                // Close sidebar if it's open
                if (setSidebarOpen && sidebarOpen) {
                  setSidebarOpen(false);
                }
              }}
              aria-label="Toggle mobile menu"
            >
              {mobileMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Settings className="h-6 w-6" />
              )}
            </button>
            
            {/* Desktop navigation */}
            <div className="hidden sm:flex items-center space-x-4 rtl:space-x-reverse">
              <LanguageSwitcher minimal />
              <button
                onClick={toggleDarkMode}
                className="p-1.5 rounded-full hover:bg-gray-100 dark:hover:bg-neutral-700"
                aria-label="Toggle dark mode"
              >
                {darkMode ? (
                  <Sun className="h-5 w-5 text-gray-500 dark:text-gray-300" />
                ) : (
                  <Moon className="h-5 w-5 text-gray-500 dark:text-gray-300" />
                )}
              </button>

              <SubscriptionBadge showUpgrade className="upgrade-button" />

              <button
                onClick={() => navigate('/dashboard/help')}
                className="p-1.5 rounded-full hover:bg-gray-100 dark:hover:bg-neutral-700"
                aria-label="Help"
              >
                <HelpCircle className="h-5 w-5 text-gray-500 dark:text-gray-300" />
              </button>
            </div>

            {/* User menu */}
            <div className="relative user-menu">
              <button 
                onClick={() => setUserMenuOpen(!userMenuOpen)}
                className="flex items-center text-sm rounded-full focus:outline-none"
                aria-expanded={userMenuOpen}
                aria-haspopup="true"
              >
                <span className="sr-only">Open user menu</span>
                <div className="h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden">
                  {userProfile?.photoURL ? (
                    <img 
                      src={userProfile.photoURL} 
                      alt="User" 
                      className="h-8 w-8 rounded-full object-cover"
                    />
                  ) : (
                    <span className="text-xs font-medium text-gray-700 dark:text-gray-300">
                      {userProfile?.displayName?.[0] || currentUser?.email?.[0]?.toUpperCase() || 'U'}
                    </span>
                  )}
                </div>
                <ChevronDown className="ml-1 h-4 w-4 text-gray-400" />
              </button>

              {/* User dropdown menu */}
              {userMenuOpen && (
                <div className="absolute right-0 rtl:left-0 rtl:right-auto z-[1000] mt-2 w-48 origin-top-right rounded-md bg-white dark:bg-neutral-800 py-1 shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
                  <div className="px-4 py-3 border-b border-gray-100 dark:border-neutral-700">
                    <p className="text-sm font-medium text-gray-900 dark:text-white truncate">
                      {userProfile?.displayName || 'User'}
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400 truncate">
                      {currentUser?.email}
                    </p>
                  </div>
                  <div className="border-t border-gray-100 dark:border-neutral-700">
                    <button
                      onClick={handleSignOut}
                      className="flex w-full items-center px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-neutral-700"
                    >
                      <LogOut className="h-4 w-4 mr-3 rtl:ml-3 rtl:mr-0" />
                      {t('header.signOut', 'Sign out')}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="sm:hidden mobile-menu border-t border-gray-200 dark:border-neutral-700 bg-white dark:bg-neutral-800">
            <div className="px-4 py-3 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  {t('common.remainingTokens', 'Remaining Tokens')}: {remainingTokens}
                </span>
                <LanguageSwitcher minimal />
              </div>
              
              {/* Main navigation links for mobile */}
              <div className="flex flex-col space-y-2 border-b pb-2 border-gray-200 dark:border-neutral-700">
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    navigate('/pricing');
                  }}
                  className="w-full text-left py-2 px-3 text-sm text-gray-700 dark:text-gray-300 rounded-md hover:bg-gray-100 dark:hover:bg-neutral-700"
                >
                  {t('common.pricing', 'Pricing')}
                </button>
                <button
                  onClick={toggleDarkMode}
                  className="w-full text-left py-2 px-3 text-sm text-gray-700 dark:text-gray-300 rounded-md hover:bg-gray-100 dark:hover:bg-neutral-700"
                >
                  {darkMode ? t('settings.lightMode', 'Light Mode') : t('settings.darkMode', 'Dark Mode')}
                </button>
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    navigate('/dashboard/help');
                  }}
                  className="w-full text-left py-2 px-3 text-sm text-gray-700 dark:text-gray-300 rounded-md hover:bg-gray-100 dark:hover:bg-neutral-700"
                >
                  {t('common.help', 'Help')}
                </button>
                {!currentUser ? (
                  <button
                    onClick={() => {
                      setMobileMenuOpen(false);
                      navigate('/auth/signin');
                    }}
                    className="w-full text-left py-2 px-3 text-sm font-medium text-blue-600 dark:text-blue-400 rounded-md hover:bg-blue-50 dark:hover:bg-blue-900/20"
                  >
                    Sign in
                  </button>
                ) : null}
              </div>
              
              <div className="py-2">
                <SubscriptionBadge showUpgrade />
              </div>

              <div className="pt-2">
                <ProjectSelector />
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;