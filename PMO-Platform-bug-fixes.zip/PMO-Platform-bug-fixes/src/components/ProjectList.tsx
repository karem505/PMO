import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppStore } from '../store';
import { 
  Briefcase, 
  Calendar, 
  Plus, 
  Search, 
  Tag, 
  Filter, 
  CheckCircle, 
  AlertCircle, 
  Lock
} from 'lucide-react';
import { useAuth } from './auth/AuthContext';
import { Project } from '../types';

const ProjectList: React.FC = () => {
  const { getProjects, setActiveProject, getActiveProjectId } = useAppStore();
  const { hasPermission } = useAuth();
  const navigate = useNavigate();
  
  const [searchTerm, setSearchTerm] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);
  
  const projects = getProjects();
  const activeProjectId = getActiveProjectId();
  
  // Deduplicate projects with the same name
  const deduplicatedProjects = React.useMemo(() => {
    // Fix for empty projects array
    if (!projects || !projects.length) {
      return [];
    }
    
    // First check if the active project is included
    const activeProjectId = getActiveProjectId();
    const activeProjectExists = projects.some(p => p.id === activeProjectId);
    
    // Group projects by name
    const projectsByName = projects.reduce((acc, project) => {
      if (!acc[project.name]) {
        acc[project.name] = [];
      }
      acc[project.name].push(project);
      return acc;
    }, {} as Record<string, Project[]>);
    
    // For each group with multiple projects, keep only one
    const result: Project[] = [];
    
    Object.entries(projectsByName).forEach(([name, groupProjects]) => {
      // Special case: if a project is active, always include it
      const activeProject = groupProjects.find(p => p.id === activeProjectId);
      if (activeProject) {
        result.push(activeProject);
        return;
      }
      
      // Normal case: pick one project from the group
      if (groupProjects.length > 1) {
        // For default projects, prioritize ones with is_default flag
        const defaultFlagProject = groupProjects.find(p => p.is_default);
        
        // Choose the most appropriate project
        const chosenProject = defaultFlagProject || 
          // Otherwise, sort by creation date (newest first) and take the first one
          [...groupProjects].sort((a, b) => 
            new Date(b.createdAt || '').getTime() - new Date(a.createdAt || '').getTime()
          )[0];
        
        result.push(chosenProject);
      } else {
        // If only one project with this name, add it directly
        result.push(groupProjects[0]);
      }
    });
    
    return result;
  }, [projects, getActiveProjectId]);
  
  // Filter projects based on search term
  const filteredProjects = deduplicatedProjects.filter(project => 
    project.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    project.description?.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  const handleProjectClick = (projectId: string) => {
    setActiveProject(projectId);
  };
  
  const canCreateProject = hasPermission('project:create');
  
  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-neutral-800">Projects</h2>
        <div className="flex items-center space-x-2">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-4 w-4 text-neutral-400" />
            </div>
            <input
              type="text"
              placeholder="Search projects..."
              className="pl-10 pr-4 py-2 border border-neutral-200 rounded-lg focus:ring-primary-500 focus:border-primary-500 w-48"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          {canCreateProject && (
            <button
              onClick={() => setShowCreateModal(true)}
              className="p-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700"
            >
              <Plus className="h-5 w-5" />
            </button>
          )}
        </div>
      </div>
      
      {filteredProjects.length === 0 ? (
        <div className="text-center py-8 bg-neutral-50 rounded-lg border border-neutral-200">
          <p className="text-neutral-600">No projects found</p>
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="mt-2 text-sm text-primary-600 hover:text-primary-700"
            >
              Clear search
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-3 max-h-[600px] overflow-y-auto pr-2">
          {filteredProjects.map((project) => (
            <ProjectCard
              key={project.id}
              project={project}
              isActive={project.id === activeProjectId}
              onClick={() => handleProjectClick(project.id)}
            />
          ))}
        </div>
      )}
    </div>
  );
};

interface ProjectCardProps {
  project: Project;
  isActive: boolean;
  onClick: () => void;
}

const ProjectCard: React.FC<ProjectCardProps> = ({ 
  project, 
  isActive, 
  onClick
}) => {
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };
  
  return (
    <div 
      className={`p-4 rounded-lg border ${
        isActive 
          ? 'border-primary-300 bg-primary-50' 
          : 'border-neutral-200 bg-white hover:border-neutral-300'
      } cursor-pointer transition-colors`}
      onClick={onClick}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <div className={`p-2 rounded-md ${isActive ? 'bg-primary-100' : 'bg-neutral-100'} mr-3`}>
            <Briefcase className={`h-5 w-5 ${isActive ? 'text-primary-600' : 'text-neutral-600'}`} />
          </div>
          <div>
            <h3 className={`font-medium ${isActive ? 'text-primary-800' : 'text-neutral-800'}`}>
              {project.name}
            </h3>
            <div className="flex items-center text-xs text-neutral-500 mt-1">
              <Calendar className="h-3 w-3 mr-1" />
              <span className="text-gray-600">
                {formatDate(project.startDate)} - {formatDate(project.endDate)}
              </span>
            </div>
          </div>
        </div>
        
        {isActive && (
          <div className="flex space-x-1">
            <div className="p-1.5 bg-primary-100 rounded">
              <CheckCircle className="h-4 w-4 text-primary-600" />
            </div>
          </div>
        )}
      </div>
      
      {project.description && (
        <p className="mt-2 text-sm text-neutral-600 line-clamp-2">
          {project.description}
        </p>
      )}
      
      {project.permissions && project.permissions.length > 0 && (
        <div className="mt-2 flex items-center">
          <Lock className="h-3.5 w-3.5 text-neutral-400 mr-1.5" />
          <span className="text-xs text-neutral-500">
            Shared with <span className="text-gray-600">{project.permissions.length}</span> user{project.permissions.length !== 1 ? 's' : ''}
          </span>
        </div>
      )}
    </div>
  );
};

export default ProjectList;