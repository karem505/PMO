import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppStore } from '../store';
import { getIconComponent } from '../data';
import { ArrowRight } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useSubscription } from '../contexts/SubscriptionContext';
import { SubscriptionTier } from '../services/subscriptionService';
import DomainCardSkeleton from './common/DomainCardSkeleton';
import { captureException } from '../services/sentryService';
import DomainLock from './DomainLock';
import { useNavigationGuard } from '../hooks/useNavigationGuard';

// Define Domain type locally if not exported from types.ts
interface Domain {
  id: number;
  name: string;
  description: string;
  icon: string;
  subscription?: SubscriptionTier;
  [key: string]: any;
}

interface DomainCardProps {
  domain: Domain | null;
  isLoading?: boolean;
  error?: string | null;
}

/**
 * DomainCard component with enhanced safety measures to prevent nodeName errors
 */
const DomainCard: React.FC<DomainCardProps> = ({ domain, isLoading, error }) => {
  const { navigate } = useNavigationGuard();
  const { getDomainProgress } = useAppStore();
  const { t, isRTL } = useLanguage();
  const { tier } = useSubscription();
  const [isMounted, setIsMounted] = useState(false);
  const [isReady, setIsReady] = useState(false);
  const navigationInProgressRef = useRef(false);
  
  // Use effect to track component mount state and add safety delay
  useEffect(() => {
    setIsMounted(true);
    
    // Add a small delay before allowing interactions
    const timer = setTimeout(() => {
      if (isMounted) {
        setIsReady(true);
      }
    }, 500);
    
    return () => {
      setIsMounted(false);
      clearTimeout(timer);
    };
  }, []);
  
  // Safe domain properties with fallbacks
  const domainId = domain?.id || 0;
  const domainName = domain?.name || 'Loading...';
  const domainDescription = domain?.description || '';
  const iconName = domain?.icon || 'default';
  
  // If domain doesn't exist or has no ID, don't render the component
  if (!domain?.id) {
    return null;
  }
  
  // Get progress safely
  const progress = getDomainProgress(domainId) || { 
    inputProgress: 0, 
    processingProgress: 0, 
    outputProgress: 0,
    overallProgress: 0
  };
  
  // Get icon component
  const IconComponent = getIconComponent(iconName);
  
  // Enhanced locked domain check with safe tier access
  const currentTier = tier || SubscriptionTier.FREE;
  const isLocked = currentTier === SubscriptionTier.FREE && domainId > 2;
  
  // Show loading skeleton while loading
  if (isLoading) {
    return <DomainCardSkeleton />;
  }
  
  const handleClick = () => {
    // Prevent multiple rapid clicks
    if (navigationInProgressRef.current) {
      console.warn('Navigation already in progress, ignoring click');
      return;
    }
    
    // Only navigate if component is mounted and ready
    if (isMounted && isReady) {
      try {
        // Set navigation in progress flag
        navigationInProgressRef.current = true;
        
        if (isLocked) {
          navigate('/pricing');
        } else {
          navigate(`/domain/${domain.id}`);
        }
        
        // Reset navigation flag after a delay
        setTimeout(() => {
          navigationInProgressRef.current = false;
        }, 500);
      } catch (error) {
        console.error('Navigation error:', error);
        captureException(error);
        
        // Reset navigation flag
        navigationInProgressRef.current = false;
        
        // Fallback for critical errors
        if (error instanceof Error && error.message.includes('nodeName')) {
          setTimeout(() => {
            window.location.href = isLocked ? '/pricing' : `/domain/${domain.id}`;
          }, 100);
        }
      }
    } else {
      console.warn('Navigation attempted before component was ready');
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      handleClick();
    }
  };
  
  return (
    <div 
      className={`relative rounded-lg p-3 sm:p-4 transition-all duration-150 bg-white border border-gray-100 hover:border-gray-200 hover:shadow cursor-pointer ${isLocked ? 'opacity-80' : ''} ${isRTL ? 'rtl' : ''}`}
      onClick={handleClick}
      onKeyDown={handleKeyDown}
      role="button"
      tabIndex={0}
      aria-label={`Navigate to domain: ${t(`domains.${domainId}.name`, domainName)}`}
    >
      {isLocked && (
        <div className="absolute top-2 right-2 bg-amber-100 text-amber-800 text-xs font-medium px-2 py-1 rounded">
          {t('subscription.premium', 'Premium')}
        </div>
      )}
      
      <div className="flex items-start mb-4">
        {IconComponent && (
          <div className={`p-2 bg-blue-50 rounded ${isRTL ? 'ms-3' : 'me-3'}`}>
            <IconComponent className="h-5 w-5 text-blue-500" />
          </div>
        )}
        <div>
          <h3 className="font-semibold text-gray-900 text-base sm:text-lg">{t(`domains.${domainId}.name`, domainName)}</h3>
          <p className="text-sm text-gray-500">{t(`domains.${domainId}.description`, domainDescription)}</p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mb-3">
        <div>
          <div className="flex justify-between items-center mb-1">
            <span className="text-xs font-medium text-gray-500">{t('domain.inputStage', 'Input')}</span>
            <span className="text-xs font-semibold text-gray-600">{Math.round(progress?.inputProgress || 0)}%</span>
          </div>
          <div className="w-full h-1 bg-gray-100 rounded-full overflow-hidden">
            <div 
              className="h-full bg-green-500 rounded-full"
              style={{ width: `${progress?.inputProgress || 0}%` }}
            ></div>
          </div>
        </div>
        <div>
          <div className="flex justify-between items-center mb-1">
            <span className="text-xs font-medium text-gray-500">{t('domain.processingStage', 'Process')}</span>
            <span className="text-xs font-semibold text-gray-600">{Math.round(progress?.processingProgress || 0)}%</span>
          </div>
          <div className="w-full h-1 bg-gray-100 rounded-full overflow-hidden">
            <div 
              className="h-full bg-amber-500 rounded-full"
              style={{ width: `${progress?.processingProgress || 0}%` }}
            ></div>
          </div>
        </div>
        <div>
          <div className="flex justify-between items-center mb-1">
            <span className="text-xs font-medium text-gray-500">{t('domain.outputStage', 'Output')}</span>
            <span className="text-xs font-semibold text-gray-600">{Math.round(progress?.outputProgress || 0)}%</span>
          </div>
          <div className="w-full h-1 bg-gray-100 rounded-full overflow-hidden">
            <div 
              className="h-full bg-indigo-500 rounded-full"
              style={{ width: `${progress?.outputProgress || 0}%` }}
            ></div>
          </div>
        </div>
      </div>
      
      <div className={`mt-2 flex justify-end ${isRTL ? 'flex-row-reverse' : ''}`}>
        <span className="inline-flex items-center text-xs font-medium text-blue-600">
          {t('domain.explore', 'Explore')}
          <ArrowRight className={`h-3 w-3 ${isRTL ? 'mr-1 rotate-180' : 'ml-1'}`} />
        </span>
      </div>
      
      {isLocked && <DomainLock domainName={t(`domains.${domainId}.name`, domainName)} />}
    </div>
  );
};

export { DomainCard };
export default DomainCard;