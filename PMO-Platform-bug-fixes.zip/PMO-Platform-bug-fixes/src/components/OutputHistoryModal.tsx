import React, { useState, useMemo } from 'react';
import { X, Calendar, Check, XCircle, ArrowDownToLine, ArrowLeft, ArrowRight } from 'lucide-react';
import { TaskOutputVersion } from '../types';
import ReactMarkdown from 'react-markdown';

interface OutputHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  history: TaskOutputVersion[];
  onRestore?: (version: TaskOutputVersion) => void;
}

const OutputHistoryModal: React.FC<OutputHistoryModalProps> = ({
  isOpen,
  onClose,
  history,
  onRestore
}) => {
  const [selectedVersion, setSelectedVersion] = useState<number | null>(null);

  // Sort versions by timestamp descending (newest first)
  const sortedHistory = useMemo(() => {
    return [...history].sort((a, b) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
  }, [history]);

  // Select first version by default
  useEffect(() => {
    if (sortedHistory.length > 0 && selectedVersion === null) {
      setSelectedVersion(0);
    }
  }, [sortedHistory, selectedVersion]);

  if (!isOpen) return null;

  const currentVersion = selectedVersion !== null ? sortedHistory[selectedVersion] : null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-5xl w-full max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between border-b border-gray-200 px-6 py-4">
          <h2 className="text-xl font-semibold text-gray-800">Output History</h2>
          <button
            onClick={onClose}
            className="p-1 rounded-full hover:bg-gray-100"
          >
            <X className="h-6 w-6 text-gray-400" />
          </button>
        </div>

        <div className="flex-1 flex overflow-hidden">
          {/* Sidebar with versions */}
          <div className="w-64 border-r border-gray-200 overflow-y-auto">
            <div className="p-4">
              <h3 className="font-medium text-gray-700 mb-2">Versions ({sortedHistory.length})</h3>
              <div className="space-y-2">
                {sortedHistory.map((version, index) => (
                  <div 
                    key={index}
                    className={`p-3 rounded-md cursor-pointer border ${
                      selectedVersion === index 
                        ? 'border-blue-400 bg-blue-50' 
                        : 'border-gray-200 hover:bg-gray-50'
                    }`}
                    onClick={() => setSelectedVersion(index)}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <div className="text-xs font-medium text-gray-500 flex items-center">
                        <Calendar className="h-3 w-3 mr-1" />
                        {new Date(version.timestamp).toLocaleString()}
                      </div>
                      {version.status === 'accepted' && (
                        <span className="px-1.5 py-0.5 bg-green-100 text-green-800 text-xs rounded-full flex items-center">
                          <Check className="h-2.5 w-2.5 mr-0.5" />
                          Accepted
                        </span>
                      )}
                      {version.status === 'rejected' && (
                        <span className="px-1.5 py-0.5 bg-red-100 text-red-800 text-xs rounded-full flex items-center">
                          <XCircle className="h-2.5 w-2.5 mr-0.5" />
                          Rejected
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-gray-600 line-clamp-2">
                      {version.content.substring(0, 100)}...
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Version content viewer */}
          <div className="flex-1 flex flex-col overflow-hidden">
            <div className="flex-1 overflow-y-auto p-6">
              {currentVersion ? (
                <div>
                  <div className="mb-4 flex items-center justify-between">
                    <div>
                      <h3 className="font-medium text-gray-800">Version from {new Date(currentVersion.timestamp).toLocaleString()}</h3>
                      {currentVersion.comments && (
                        <p className="text-sm text-gray-600 mt-1">{currentVersion.comments}</p>
                      )}
                    </div>
                    <div className="flex items-center space-x-2">
                      <button
                        className="p-1 rounded-md hover:bg-gray-100"
                        onClick={() => setSelectedVersion(prev => (prev !== null && prev > 0) ? prev - 1 : prev)}
                        disabled={selectedVersion === 0}
                      >
                        <ArrowLeft className={`h-5 w-5 ${selectedVersion === 0 ? 'text-gray-300' : 'text-gray-600'}`} />
                      </button>
                      <span className="text-sm text-gray-500">
                        {(selectedVersion !== null ? selectedVersion + 1 : 0)} / {sortedHistory.length}
                      </span>
                      <button
                        className="p-1 rounded-md hover:bg-gray-100"
                        onClick={() => setSelectedVersion(prev => (prev !== null && prev < sortedHistory.length - 1) ? prev + 1 : prev)}
                        disabled={selectedVersion === sortedHistory.length - 1}
                      >
                        <ArrowRight className={`h-5 w-5 ${selectedVersion === sortedHistory.length - 1 ? 'text-gray-300' : 'text-gray-600'}`} />
                      </button>
                    </div>
                  </div>
                  
                  <div className="prose prose-sm max-w-none bg-gray-50 p-4 rounded-md border border-gray-200">
                    <ReactMarkdown>{currentVersion.content}</ReactMarkdown>
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-center h-full text-gray-500">
                  <p>Select a version to view</p>
                </div>
              )}
            </div>
            
            <div className="border-t border-gray-200 p-4 flex justify-between items-center">
              <div className="text-sm text-gray-500">
                {history.length} version{history.length !== 1 ? 's' : ''} available
              </div>
              
              <div className="space-x-3">
                {currentVersion && onRestore && (
                  <button
                    onClick={() => onRestore(currentVersion)}
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center"
                  >
                    <ArrowDownToLine className="h-4 w-4 mr-1.5" />
                    Restore This Version
                  </button>
                )}
                
                <button
                  onClick={onClose}
                  className="px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OutputHistoryModal;