import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Upload, Paperclip, X, Download, Eye, Trash2, FileText, File } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';
import FileViewer from './FileViewer';
import { useLanguage } from '../contexts/LanguageContext';
export interface TaskAttachment {
    id: string;
    name: string;
    url: string;
    size: number;
    type: string;
    uploadDate: string;
    /** NEW: keep a handle to the original File so you can send it on form-submit */
    file?: File;
  }
interface TaskFileAttachmentProps {
  existingAttachments?: TaskAttachment[];
  onUploadComplete?: (attachments: TaskAttachment[]) => void;
}

const TaskFileAttachment: React.FC<TaskFileAttachmentProps> = ({
  existingAttachments = [],
  onUploadComplete
}) => {
  const { t } = useLanguage();
  const fileInputRef = useRef<HTMLInputElement>(null);

  // core state: just local attachments
  const [attachments, setAttachments] = useState<TaskAttachment[]>(existingAttachments);
  const [showAttachments, setShowAttachments] = useState(existingAttachments.length > 0);
  const [selectedFile, setSelectedFile] = useState<TaskAttachment | null>(null);
  const [dragActive, setDragActive] = useState(false);

  // Define supported file types
  const acceptedFileTypes = ".docx,.pdf";

  useEffect(() => {
    setAttachments(existingAttachments);
    setShowAttachments(existingAttachments.length > 0);
  }, [existingAttachments]);

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault(); e.stopPropagation();
    setDragActive(e.type === 'dragenter' || e.type === 'dragover');
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault(); e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files?.length) {
      handleFiles(e.dataTransfer.files);
    }
  }, []);

  /**
   * Replace all of the Supabase logic with a simple:
   *   1) create an Object URL for preview
   *   2) push into state
   *   3) fire onUploadComplete
   */
  const handleFiles = (files: FileList) => {
    // Validate file types
    const validFiles = Array.from(files).filter(file => {
      const extension = file.name.split('.').pop()?.toLowerCase();
      return extension && ['docx', 'pdf'].includes(extension);
    });

    if (validFiles.length === 0) {
      alert('Please select valid files (docx, pdf)');
      return;
    }

    const newAttachments: TaskAttachment[] = validFiles.map(file => ({
      id: uuidv4(),
      name: file.name,
      url: URL.createObjectURL(file),
      size: file.size,
      type: file.type,
      uploadDate: new Date().toISOString(),
      file                // <-- carry the raw file for later
    }));

    const updated = [...attachments, ...newAttachments];
    setAttachments(updated);
    setShowAttachments(true);

    if (onUploadComplete) {
      onUploadComplete(updated);
    }

    // clear input so you can re-upload same file if needed
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  /** Just filter it out, then fire onUploadComplete again */
  const handleRemoveAttachment = (id: string) => {
    const updated = attachments.filter(a => a.id !== id);
    setAttachments(updated);
    if (selectedFile?.id === id) {
      setSelectedFile(null);
    }
    if (onUploadComplete) {
      onUploadComplete(updated);
    }
  };

  // Simple function to trigger file input click
  const openFileDialog = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const formatFileSize = (bytes?: number): string => {
    if (bytes === undefined) return 'Unknown size';
    if (bytes === 0) return '0 Bytes';
    
    const units = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    
    return `${parseFloat((bytes / Math.pow(1024, i)).toFixed(2))} ${units[i]}`;
  };
  
  const getFileTypeCategory = (file: {name: string, type?: string}): string => {
    if (!file.type) {
      // Try to guess type from extension
      const extension = file.name.split('.').pop()?.toLowerCase();
      if (!extension) return 'unknown';
      
      if (['pdf', 'doc', 'docx'].includes(extension)) {
        return 'document';
      } else {
        return 'unknown';
      }
    }
    
    // Determine type from MIME type
    const supportedFileTypes = {
      document: ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document']
    };
    
    if (supportedFileTypes.document.includes(file.type)) {
      return 'document';
    } else {
      return 'unknown';
    }
  };
  
  const getFileIcon = (file: {name: string, type?: string}) => {
    const fileType = getFileTypeCategory(file);
    
    switch(fileType) {
      case 'document':
        return <FileText className="h-5 w-5 text-blue-500" />;
      default:
        return <File className="h-5 w-5 text-gray-500" />;
    }
  };

  const viewFile = (file: TaskAttachment) => {
    setSelectedFile(file);
  };
  
  return (
    <div className="mt-4 border-t border-gray-100 pt-4">
      <div
        className="flex items-center justify-between cursor-pointer mb-4"
        onClick={() => setShowAttachments(!showAttachments)}
      >
        <h3 className="text-sm font-medium text-gray-700 flex items-center">
          <Paperclip className="h-4 w-4 mr-2 text-gray-500" />
          {t('tasks.attachments','Attachments')} ({attachments.length})
        </h3>
        <span>{showAttachments ? '▲' : '▼'}</span>
      </div>

      {showAttachments && (
        <>
          {/* File Input */}
          <input
            type="file"
            ref={fileInputRef}
            className="hidden"
            onChange={(e) => e.target.files && handleFiles(e.target.files)}
            accept={acceptedFileTypes}
          />
          
          {/* Drop Zone */}
          <div
            className={`border-2 border-dashed rounded-lg p-4 text-center mb-4 ${
              dragActive
                ? 'border-primary-400 bg-primary-50'
                : 'border-gray-300 hover:border-gray-400'
            } transition-colors cursor-pointer`}
            onClick={() => openFileDialog()}
            onDragEnter={handleDrag}
            onDragOver={handleDrag}
            onDragLeave={handleDrag}
            onDrop={handleDrop}
          >
            <Upload className="h-6 w-6 text-gray-400 mx-auto mb-2" />
            <p className="text-sm text-gray-600 mb-1">
              {t('tasks.dragAndDropFilesHere','Drag & drop files here or click to select')}
            </p>
            <p className="text-xs text-gray-500">
              Supported formats: DOCX, PDF
            </p>
          </div>

          {/* File list */}
          {attachments.length ? (
            <div className="space-y-2 max-h-60 overflow-y-auto pr-1 mb-4">
              {attachments.map(att => (
                <div
                  key={att.id}
                  className="flex items-center justify-between p-2 bg-gray-50 rounded-lg border border-gray-100"
                >
                  <div className="flex items-center overflow-hidden">
                    {getFileIcon(att)}
                    <div className="ml-2 min-w-0">
                      <p className="text-sm font-medium text-gray-700 truncate">{att.name}</p>
                      <p className="text-xs text-gray-500">
                        {(att.size / 1024).toFixed(1)} KB
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-x-1">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleRemoveAttachment(att.id);
                      }}
                      className="p-1 hover:bg-red-100 rounded-md"
                    >
                      <Trash2 className="h-4 w-4 text-red-600" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-gray-500 italic mt-2 mb-4">
              {t('tasks.noAttachmentsAddedYet','No attachments added yet')}
            </p>
          )}

          {/* Add Attachment Button */}
          <button
            type="button"
            className="flex items-center text-sm text-primary-600 hover:text-primary-800"
            onClick={() => openFileDialog()}
          >
            <Upload className="h-4 w-4 mr-1.5" />
            {t('tasks.addAttachment','Add Attachment')}
          </button>
        </>
      )}

      {/* Preview modal */}
      {selectedFile && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-gray-200 px-6 py-4">
              <h3 className="text-lg font-semibold text-gray-800 flex items-center truncate">
                {getFileIcon(selectedFile)}
                <span className="ml-2 truncate">{selectedFile.name}</span>
              </h3>
              <div className="flex items-center space-x-2">
                <a
                  href={selectedFile.url}
                  download={selectedFile.name}
                  className="p-2 hover:bg-gray-100 rounded-full"
                  title="Download"
                >
                  <Download className="h-5 w-5 text-gray-500" />
                </a>
                <button
                  onClick={() => setSelectedFile(null)}
                  className="p-2 hover:bg-gray-100 rounded-full"
                  title="Close"
                >
                  <X className="h-5 w-5 text-gray-500" />
                </button>
              </div>
            </div>
            <div className="flex-1 overflow-auto p-4 bg-gray-50">
              <FileViewer file={selectedFile} />
            </div>
            <div className="border-t border-gray-200 px-6 py-4 flex justify-between items-center">
              <div className="text-sm text-gray-500">
                {formatFileSize(attachments.find(a => a.id === selectedFile.id)?.size)}
              </div>
              <button
                onClick={() => setSelectedFile(null)}
                className="px-4 py-2 bg-gray-100 text-gray-800 rounded-md hover:bg-gray-200 transition-colors"
              >
                {t('tasks.close','Close')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TaskFileAttachment;