import React, { useState, useEffect, useCallback } from 'react';
import { useAppStore } from '../store';
import { Domain } from '../types';
import { FileText, Download, CheckCircle, ExternalLink, Sparkles, File as FilePdf, Loader2, Link, BarChart as FlowChart, Network, GitBranch, Workflow, Info, AlertTriangle } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import TemplateExportPanel from './TemplateExportPanel';
import { exportToPdf } from '../utils/exportUtils';
import { useLanguage } from '../contexts/LanguageContext';
import { documentProcessingService } from '../services/documentProcessingService';
import DiagramGenerator from './DiagramGenerator';
import VisualizeButton from './VisualizeButton';
import SourceValidation from './SourceValidation';
import { aiValidationService } from '../services/aiValidationService';

interface DomainOutputDisplayProps {
  domain: Domain;
}

const DomainOutputDisplay: React.FC<DomainOutputDisplayProps> = ({ domain }) => {
  const { getDomainOutput, getActiveProject, connectionError, showConnectionErrors } = useAppStore();
  const { t, isRTL } = useLanguage();
  const [activeTab, setActiveTab] = useState<'analysis' | 'templates' | 'diagrams'>('analysis');
  const [activeTemplate, setActiveTemplate] = useState<number>(0);
  const [downloadStatus, setDownloadStatus] = useState<{[key: string]: boolean}>({});
  const [pdfExporting, setPdfExporting] = useState(false);
  const [relatedDocuments, setRelatedDocuments] = useState<any[]>([]);
  const [isLoadingDocs, setIsLoadingDocs] = useState(false);
  const [visualizations, setVisualizations] = useState<{type: string, title: string}[]>([]);
  const [activeDiagramIndex, setActiveDiagramIndex] = useState(0);
  const [diagramSections, setDiagramSections] = useState<{title: string, content: string, type: string}[]>([]);
  const [isGeneratingDiagrams, setIsGeneratingDiagrams] = useState(false);
  const [renderTime, setRenderTime] = useState<number | null>(null);
  const [expandedSections, setExpandedSections] = useState<{[key: string]: boolean}>({});
  const [refreshDocs, setRefreshDocs] = useState(0); // State to force document reload
  const [validatingContent, setValidatingContent] = useState(false);
  const [enhancedContent, setEnhancedContent] = useState<string | null>(null);
  const [validationResult, setValidationResult] = useState<any>(null);
  
  const domainOutput = getDomainOutput(domain.id);
  const activeProject = getActiveProject();
  
  // Performance monitoring
  useEffect(() => {
    const startTime = performance.now();
    
    // Save render time on cleanup
    return () => {
      const endTime = performance.now();
      setRenderTime(endTime - startTime);
      console.log(`[Performance] DomainOutputDisplay rendered in ${(endTime - startTime).toFixed(2)}ms`);
    };
  }, []);
  
  // Force document refresh when analysis tab is active
  const refreshDocuments = useCallback(() => {
    // Only trigger a refresh if we're on the analysis tab
    if (activeTab === 'analysis') {
      setRefreshDocs(prev => prev + 1);
    }
  }, [activeTab]);
  
  // Reset active template when language changes
  useEffect(() => {
    setActiveTemplate(0);
  }, [isRTL]);
  
  useEffect(() => {
    // Analyze content for diagram-worthy sections when domainOutput changes
    if (domainOutput) {
      identifyDiagramSections(domainOutput.content);
      
      // Try to validate and enhance with external sources
      validateAndEnhanceContent();
    }
  }, [domainOutput]);
  
  // Validate content with external sources
  const validateAndEnhanceContent = async () => {
    if (!domainOutput || !domainOutput.content || validatingContent) return;
    
    setValidatingContent(true);
    
    try {
      const { 
        enhancedContent, 
        validationResult,
        externalSourcesAdded 
      } = await aiValidationService.enhanceAnalysisWithExternalSources(
        domainOutput.content, 
        domain.name, 
        []
      );
      
      // Only use enhanced content if external sources were added
      if (externalSourcesAdded) {
        setEnhancedContent(enhancedContent);
      }
      
      setValidationResult(validationResult);
    } catch (error) {
      console.error('Error validating content:', error);
      // Just continue without validation
    } finally {
      setValidatingContent(false);
    }
  };
  
  // Load related documents with automatic refresh feature
  useEffect(() => {
    const loadRelatedDocuments = async () => {
      if (!domainOutput || !activeProject) return;
      
      setIsLoadingDocs(true);
      try {
        // Only fetch document details if we're on the analysis tab
        if (activeTab === 'analysis') {
          // Get documents from this domain
          const documents = await documentProcessingService.getDomainDocuments(
            domain.id,
            activeProject.id
          );
          
          // Extract document sources (filenames)
          const sources = documents.map(doc => doc.metadata.source || 'Unnamed document')
                                  .filter((value, index, self) => self.indexOf(value) === index);
          
          setRelatedDocuments(sources);
        } 
      } catch (error) {
        console.error('Error loading related documents:', error);
      } finally {
        setIsLoadingDocs(false);
      }
    };
    
    if (activeTab === 'analysis') {
      loadRelatedDocuments();
    }
  }, [domain.id, domainOutput, activeProject, activeTab, refreshDocs]);
  
  // Set up periodic document refresh - every 5 seconds when tab is visible
  useEffect(() => {
    // Only set up refresh timer if we're on the analysis tab
    if (activeTab !== 'analysis') return;
    
    // Create an interval to check for new documents
    const interval = setInterval(() => {
      refreshDocuments();
    }, 5000);
    
    return () => clearInterval(interval);
  }, [activeTab, refreshDocuments]);
  
  const identifyDiagramSections = (content: string) => {
    if (!content) return;
    
    // For performance reasons, limit content analysis
    const contentToAnalyze = content.length > 10000 
      ? content.substring(0, 10000) + "..." 
      : content;
    
    // Find sections in the content that would make good diagrams
    const sections = [];
    
    // Split content by headings (## or ###)
    const headingRegex = /(?:^|\n)(?:#{2,3})\s+([^\n]+)/g;
    const matches = [...contentToAnalyze.matchAll(headingRegex)];
    
    // Only process a limited number of headings
    const maxHeadings = 3;
    const matchesToProcess = matches.slice(0, maxHeadings);
    
    if (matchesToProcess.length === 0) {
      // If no headings, treat the whole content as one section
      sections.push({
        title: 'Process Overview',
        content: contentToAnalyze.substring(0, Math.min(2000, contentToAnalyze.length)),
        type: 'flowchart'
      });
    } else {
      // Process each heading and its content (limit to first 3)
      matchesToProcess.forEach((match, index) => {
        const headingText = match[1];
        const startPos = match.index! + match[0].length;
        const endPos = index < matchesToProcess.length - 1 ? matchesToProcess[index + 1].index : contentToAnalyze.length;
        
        if (endPos && startPos < endPos) {
          // Limit section content for performance
          const sectionContent = contentToAnalyze.substring(startPos, endPos).trim();
          const limitedContent = sectionContent.length > 2000 
            ? sectionContent.substring(0, 2000) + "..." 
            : sectionContent;
          
          // Only include sections with enough content for a diagram
          if (limitedContent.length > 100) {
            // Determine diagram type based on heading/content keywords
            const lowerContent = limitedContent.toLowerCase();
            const lowerHeading = headingText.toLowerCase();
            
            let diagramType = 'flowchart'; // default
            
            if (lowerHeading.includes('process') || lowerHeading.includes('flow') || lowerContent.includes('step') || lowerContent.includes('procedure')) {
              diagramType = 'flowchart';
            } else if (lowerHeading.includes('structure') || lowerHeading.includes('organization') || lowerContent.includes('component')) {
              diagramType = 'classDiagram';
            } else if (lowerHeading.includes('sequence') || lowerHeading.includes('interaction')) {
              diagramType = 'sequence';
            }
            
            sections.push({
              title: headingText,
              content: limitedContent,
              type: diagramType
            });
          }
        }
      });
    }
    
    // Limit the number of diagram sections for performance
    const limitedSections = sections.slice(0, 2);
    setDiagramSections(limitedSections);
    
    // Setup visualizations list
    const visTypes = limitedSections.map(section => ({
      type: section.type,
      title: section.title
    }));
    
    setVisualizations(visTypes);
  };

  const handleAddVisualization = (type: string) => {
    if (!domainOutput) return;
    
    const defaultTitles: {[key: string]: string} = {
      'flowchart': 'Process Flow',
      'sequence': 'Sequence Diagram',
      'classDiagram': 'Structure Diagram',
      'stateDiagram': 'State Diagram',
      'gantt': 'Project Timeline',
      'pieChart': 'Data Distribution',
      'er': 'Entity Relationship'
    };
    
    const title = defaultTitles[type] || 'Diagram';
    
    // Extract a small sample of content for performance
    const contentSample = domainOutput.content.substring(0, 1000);
    
    const newSection = {
      title,
      content: contentSample,
      type
    };
    
    setDiagramSections([...diagramSections, newSection]);
    setVisualizations([...visualizations, { type, title }]);
    
    // Switch to diagrams tab
    setActiveTab('diagrams');
    setActiveDiagramIndex(visualizations.length);
  };
  
  const toggleSection = (section: string) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const handleVisualizationClick = (index: number) => {
    setActiveDiagramIndex(index);
  };

  const handleGenerateAllDiagrams = async () => {
    if (!domainOutput) return;
    
    setIsGeneratingDiagrams(true);
    
    // For performance, just create a single diagram
    const processFlowContent = domainOutput.content.substring(0, Math.min(1500, domainOutput.content.length));
    
    const newSections = [
      { title: 'Process Flow', content: processFlowContent, type: 'flowchart' }
    ];
    
    setDiagramSections(newSections);
    setVisualizations(newSections.map(section => ({ type: section.type, title: section.title })));
    
    setActiveTab('diagrams');
    setActiveDiagramIndex(0);
    setIsGeneratingDiagrams(false);
  };

  if (!domainOutput) return null;

  const handleDownload = (content: string, filename: string, format: 'md' | 'pdf' = 'md') => {
    if (format === 'pdf') {
      setPdfExporting(true);
      
      exportToPdf(content, filename, () => {
        setPdfExporting(false);
        
        // Show temporary download success status
        const statusKey = `${filename}-${new Date().getTime()}`;
        setDownloadStatus(prev => ({ ...prev, [statusKey]: true }));
        setTimeout(() => {
          setDownloadStatus(prev => ({ ...prev, [statusKey]: false }));
        }, 2000);
      });
      
      return;
    }
    
    // Create the template content in Markdown
    const element = document.createElement('a');
    const file = new Blob([content], { type: 'text/markdown' });
    element.href = URL.createObjectURL(file);
    element.download = filename;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    
    // Show temporary download success status
    const statusKey = `${filename}-${new Date().getTime()}`;
    setDownloadStatus(prev => ({ ...prev, [statusKey]: true }));
    setTimeout(() => {
      setDownloadStatus(prev => ({ ...prev, [statusKey]: false }));
    }, 2000);
  };
  
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString(isRTL ? 'ar-SA' : 'en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };
  
  // Progressive loading - only render what's needed
  const renderAnalysisContent = () => {
    // If content is very long, only render a limited amount
    const content = enhancedContent || domainOutput.content;
    const MAX_VISIBLE_LENGTH = 5000;
    
    if (content.length > MAX_VISIBLE_LENGTH && !expandedSections['analysis']) {
      // Find a good breaking point - end of a paragraph or section
      let breakPoint = content.substring(0, MAX_VISIBLE_LENGTH).lastIndexOf('\n\n');
      if (breakPoint === -1) breakPoint = MAX_VISIBLE_LENGTH;
      
      return (
        <div className="prose max-w-none">
          <ReactMarkdown>{content.substring(0, breakPoint)}</ReactMarkdown>
          <div className="text-center my-4 py-4 border-t border-b border-gray-100">
            <button 
              className="px-4 py-2 bg-blue-50 text-blue-700 rounded-md hover:bg-blue-100"
              onClick={() => toggleSection('analysis')}
            >
              Show full content ({Math.round(content.length / 1000)}K characters)
            </button>
          </div>
        </div>
      );
    }
    
    return (
      <div className="prose max-w-none">
        <ReactMarkdown>{content}</ReactMarkdown>
        {expandedSections['analysis'] && content.length > MAX_VISIBLE_LENGTH && (
          <div className="text-center mt-8">
            <button 
              className="px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200"
              onClick={() => toggleSection('analysis')}
            >
              Show less
            </button>
          </div>
        )}
      </div>
    );
  };
  
  return (
    <div className="bg-white rounded-lg shadow-sm mt-6">
      <div className="px-6 py-4 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-gray-800 flex items-center">
            <CheckCircle className={`h-5 w-5 ${isRTL ? 'ml-2' : 'mr-2'} text-green-500`} />
            {t('domain.aiGeneratedAnalysis', 'AI-Generated Analysis for')} {t(`domains.${domain.id}.name`, domain.name)}
            <span className={`${isRTL ? 'mr-2' : 'ml-2'} flex items-center text-xs bg-indigo-100 text-indigo-800 px-2 py-0.5 rounded-full`}>
              <Sparkles className={`h-3 w-3 ${isRTL ? 'ml-1' : 'mr-1'}`} />
              OpenAI
            </span>
          </h2>
          <span className="text-sm text-gray-500">{t('domain.generated', 'Generated')}: {formatDate(domainOutput.generatedDate)}</span>
        </div>
      </div>
      
      {connectionError && showConnectionErrors && (
        <div className="bg-amber-50 dark:bg-amber-900/30 border border-amber-200 dark:border-amber-800 rounded-md p-4 mb-4 flex items-start">
          <AlertTriangle className="h-5 w-5 text-amber-600 dark:text-amber-500 mt-0.5 me-2 flex-shrink-0" />
          <div>
            <p className="text-sm font-medium text-amber-800 dark:text-amber-400">
              Working in offline mode - PDF exports and some features may be limited
            </p>
            <p className="text-xs text-amber-700 dark:text-amber-300 mt-1">
              You appear to be working offline or have connection issues with the database.
            </p>
          </div>
        </div>
      )}
      
      <div className="border-b border-gray-200">
        <nav className="flex -mb-px">
          <button
            className={`py-3 px-4 font-medium text-sm ${
              activeTab === 'analysis'
                ? 'border-b-2 border-blue-500 text-blue-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
            onClick={() => {
              setActiveTab('analysis');
              // Refresh documents when switching to analysis tab
              refreshDocuments();
            }}
          >
            {t('domain.analysis', 'Analysis')}
          </button>
          <button
            className={`py-3 px-4 font-medium text-sm ${
              activeTab === 'templates'
                ? 'border-b-2 border-blue-500 text-blue-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
            onClick={() => setActiveTab('templates')}
          >
            {t('domain.templates', 'Templates')} ({domainOutput.templates.length})
          </button>
          <button
            className={`py-3 px-4 font-medium text-sm ${
              activeTab === 'diagrams'
                ? 'border-b-2 border-blue-500 text-blue-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
            onClick={() => setActiveTab('diagrams')}
          >
            Visualizations {visualizations.length > 0 && `(${visualizations.length})`}
          </button>
        </nav>
      </div>
      
      {activeTab === 'analysis' ? (
        <div className="px-6 py-4 prose max-w-none">
          <div className="flex justify-between mb-4">
            <div className="flex items-start space-x-2">
              <h3 className="text-lg font-semibold text-gray-800">Analysis</h3>
              {relatedDocuments.length > 0 && (
                <div className="px-2 py-1 bg-blue-50 border border-blue-100 rounded-md text-xs text-blue-700 flex items-center">
                  <Link className="h-3.5 w-3.5 mr-1.5" />
                  <span>{relatedDocuments.length} document{relatedDocuments.length !== 1 ? 's' : ''} referenced</span>
                </div>
              )}
            </div>
            <div className="flex space-x-2 rtl:space-x-reverse">
              <VisualizeButton 
                onVisualize={handleAddVisualization}
              />
              <button
                className="px-3 py-1 text-sm border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 flex items-center"
                onClick={() => handleDownload(enhancedContent || domainOutput.content, `${domain.name.replace(/\s+/g, '-')}-Analysis.md`)}
                disabled={pdfExporting}
              >
                <Download className={`h-4 w-4 ${isRTL ? 'ml-1' : 'mr-1'}`} />
                {t('domain.downloadMarkdown', 'Download Markdown')}
              </button>
              <button
                className={`px-3 py-1 text-sm border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 flex items-center ${pdfExporting ? 'opacity-50 cursor-not-allowed' : ''}`}
                onClick={() => handleDownload(enhancedContent || domainOutput.content, `${domain.name.replace(/\s+/g, '-')}-Analysis.pdf`, 'pdf')}
                disabled={pdfExporting}
              >
                {pdfExporting ? (
                  <>
                    <Loader2 className={`h-4 w-4 ${isRTL ? 'ml-1' : 'mr-1'} animate-spin`} />
                    {t('domain.generatingPdf', 'Generating PDF...')}
                  </>
                ) : (
                  <>
                    <FilePdf className={`h-4 w-4 ${isRTL ? 'ml-1' : 'mr-1'}`} />
                    {t('domain.downloadPdf', 'Download PDF')}
                  </>
                )}
              </button>
            </div>
          </div>
          
          {/* Source Validation Component */}
          {validationResult && (
            <SourceValidation 
              content={domainOutput.content}
              domainName={domain.name}
              className="mb-4"
            />
          )}

          {relatedDocuments.length > 0 && (
            <div className="mb-4 p-3 bg-gray-50 rounded-lg border border-gray-200">
              <h4 className="text-sm font-medium text-gray-700 mb-2 flex items-center">
                <Link className="h-4 w-4 mr-2 text-blue-600" />
                Documents Referenced in Analysis
              </h4>
              {isLoadingDocs ? (
                <div className="text-sm text-gray-500 flex items-center">
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Loading document references...
                </div>
              ) : (
                <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {relatedDocuments.map((source, index) => (
                    <li key={index} className="text-sm text-gray-600 flex items-center">
                      <FileText className="h-4 w-4 text-blue-500 mr-2 flex-shrink-0" />
                      <span className="truncate">{source}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}
          
          <div className="bg-gray-50 p-6 rounded-lg markdown-content">
            {renderAnalysisContent()}
          </div>
        </div>
      ) : activeTab === 'templates' ? (
        <div className="p-6">
          {domainOutput.templates.length > 0 ? (
            <div>
              <div className="flex mb-4 overflow-x-auto pb-2 scrollbar-thin">
                {domainOutput.templates.map((template, index) => (
                  <button
                    key={index}
                    className={`px-4 py-2 rounded-md text-sm mr-2 rtl:mr-0 rtl:ml-2 flex items-center whitespace-nowrap ${
                      activeTemplate === index
                        ? 'bg-blue-100 text-blue-600'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                    onClick={() => setActiveTemplate(index)}
                  >
                    <FileText className={`h-4 w-4 ${isRTL ? 'ml-1' : 'mr-1'}`} />
                    {template.name}
                  </button>
                ))}
              </div>
              
              <div className="bg-gray-50 p-6 rounded-lg">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-medium text-gray-800">{domainOutput.templates[activeTemplate]?.name}</h3>
                  <div className="flex space-x-2 rtl:space-x-reverse">
                    <VisualizeButton 
                      onVisualize={handleAddVisualization}
                    />
                    <button
                      className="px-3 py-1.5 text-sm border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 flex items-center"
                      onClick={() => 
                        handleDownload(
                          domainOutput.templates[activeTemplate].content, 
                          `${domainOutput.templates[activeTemplate].name.replace(/\s+/g, '-')}.md`
                        )
                      }
                      disabled={pdfExporting}
                    >
                      <Download className={`h-4 w-4 ${isRTL ? 'ml-1' : 'mr-1'}`} />
                      {t('domain.downloadMarkdown', 'Download Markdown')}
                    </button>
                    <button
                      className={`px-3 py-1.5 text-sm border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 flex items-center ${pdfExporting ? 'opacity-50 cursor-not-allowed' : ''}`}
                      onClick={() => 
                        handleDownload(
                          domainOutput.templates[activeTemplate].content, 
                          `${domainOutput.templates[activeTemplate].name.replace(/\s+/g, '-')}.pdf`,
                          'pdf'
                        )
                      }
                      disabled={pdfExporting}
                    >
                      {pdfExporting ? (
                        <>
                          <Loader2 className={`h-4 w-4 ${isRTL ? 'ml-1' : 'mr-1'} animate-spin`} />
                          {t('domain.generating', 'Generating...')}
                        </>
                      ) : (
                        <>
                          <FilePdf className={`h-4 w-4 ${isRTL ? 'ml-1' : 'mr-1'}`} />
                          {t('domain.downloadPdf', 'Download PDF')}
                        </>
                      )}
                    </button>
                  </div>
                </div>
                <div className="prose max-w-none markdown-content">
                  <ReactMarkdown>{domainOutput.templates[activeTemplate]?.content}</ReactMarkdown>
                </div>
                
                {/* Add the template export panel */}
                <TemplateExportPanel template={domainOutput.templates[activeTemplate]} />
              </div>
              
              <div className="mt-6 border-t border-gray-200 pt-6">
                <h3 className="text-md font-medium text-gray-800 mb-4">{t('domain.allTemplates', 'All Available Templates')}</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {domainOutput.templates.map((template, index) => {
                    const statusKey = `${template.name.replace(/\s+/g, '-')}.md-${index}`;
                    return (
                      <div key={index} className="flex items-center justify-between p-3 bg-white border border-gray-200 rounded-md hover:border-blue-300 transition-colors duration-200">
                        <div className="flex items-center">
                          <div className="p-2 bg-blue-50 rounded-md mr-3 rtl:mr-0 rtl:ml-3">
                            <FileText className="h-5 w-5 text-blue-500" />
                          </div>
                          <div>
                            <p className="text-sm font-medium text-gray-800">{template.name}</p>
                            <p className="text-xs text-gray-500">{t('domain.markdownFormat', 'Markdown')} • {countWords(template.content)} {t('domain.words', 'words')}</p>
                          </div>
                        </div>
                        <div className="flex space-x-1 rtl:space-x-reverse">
                          <button 
                            className="p-1.5 rounded-md border border-gray-200 hover:bg-blue-50 hover:border-blue-200"
                            onClick={() => 
                              handleDownload(
                                template.content, 
                                `${template.name.replace(/\s+/g, '-')}.md`
                              )
                            }
                            disabled={pdfExporting}
                          >
                            {downloadStatus[statusKey] ? (
                              <CheckCircle className="h-4 w-4 text-green-500" />
                            ) : (
                              <Download className="h-4 w-4 text-blue-500" />
                            )}
                          </button>
                          <button 
                            className="p-1.5 rounded-md border border-gray-200 hover:bg-red-50 hover:border-red-200"
                            onClick={() => 
                              handleDownload(
                                template.content, 
                                `${template.name.replace(/\s+/g, '-')}.pdf`,
                                'pdf'
                              )
                            }
                            disabled={pdfExporting}
                          >
                            {pdfExporting && `${template.name.replace(/\s+/g, '-')}.pdf` === `${domainOutput.templates[activeTemplate].name.replace(/\s+/g, '-')}.pdf` ? (
                              <Loader2 className="h-4 w-4 text-blue-500 animate-spin" />
                            ) : (
                              <FilePdf className="h-4 w-4 text-red-500" />
                            )}
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
                
                <div className="mt-6 p-4 bg-blue-50 rounded-md">
                  <div className="flex items-start">
                    <ExternalLink className={`h-5 w-5 text-blue-500 mt-0.5 ${isRTL ? 'ml-2' : 'mr-2'}`} />
                    <div>
                      <h4 className="text-sm font-medium text-blue-800">{t('domain.usingTemplates', 'Using These Templates')}</h4>
                      <p className="text-xs text-blue-700 mt-1">
                        {t('domain.templateDescription', 'These templates are available in Markdown and PDF formats. Markdown can be imported into document editors, project management tools, or converted to other formats. PDF files are ready for printing or sharing with stakeholders.')}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-10">
              <FileText className="h-10 w-10 text-gray-400 mx-auto mb-3" />
              <p className="text-gray-600">{t('domain.noTemplates', 'No templates available for this domain')}</p>
            </div>
          )}
        </div>
      ) : (
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-800 flex items-center">
              <FlowChart className="h-5 w-5 mr-2 text-primary-600" />
              Visual Diagrams & Process Maps
            </h3>
            
            <div className="flex space-x-2">
              <VisualizeButton
                onVisualize={handleAddVisualization}
              />
              
              {visualizations.length === 0 && (
                <button 
                  onClick={handleGenerateAllDiagrams}
                  disabled={isGeneratingDiagrams}
                  className={`px-3 py-1.5 bg-primary-600 text-white text-sm rounded-md hover:bg-primary-700 flex items-center ${
                    isGeneratingDiagrams ? 'opacity-70 cursor-not-allowed' : ''
                  }`}
                >
                  {isGeneratingDiagrams ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-1.5 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <Sparkles className="h-4 w-4 mr-1.5" />
                      Generate Diagram
                    </>
                  )}
                </button>
              )}
            </div>
          </div>
          
          {visualizations.length > 0 ? (
            <div>
              <div className="flex mb-4 overflow-x-auto scrollbar-thin pb-2">
                {visualizations.map((vis, index) => {
                  // Get the appropriate icon based on diagram type
                  let Icon = FlowChart;
                  switch (vis.type) {
                    case 'sequence':
                      Icon = GitBranch;
                      break;
                    case 'classDiagram':
                      Icon = Network;
                      break;
                    case 'stateDiagram':
                      Icon = Workflow;
                      break;
                    default:
                      Icon = FlowChart;
                  }
                  
                  return (
                    <button
                      key={index}
                      className={`px-4 py-2 rounded-md text-sm mr-2 flex items-center whitespace-nowrap ${
                        activeDiagramIndex === index
                          ? 'bg-blue-100 text-blue-600'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                      onClick={() => handleVisualizationClick(index)}
                    >
                      <Icon className="h-4 w-4 mr-1.5" />
                      {vis.title}
                    </button>
                  );
                })}
              </div>
              
              {/* Display the active diagram */}
              {diagramSections[activeDiagramIndex] && (
                <DiagramGenerator
                  textContent={diagramSections[activeDiagramIndex].content}
                  diagramType={diagramSections[activeDiagramIndex].type as any}
                  title={diagramSections[activeDiagramIndex].title}
                />
              )}
              
              <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-100">
                <div className="flex items-start">
                  <Info className="h-5 w-5 text-blue-600 mr-3 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-blue-800">About Visual Diagrams</h4>
                    <p className="text-sm text-blue-700 mt-1">
                      Visualizations are automatically generated from the text content. They help transform complex process descriptions into easy-to-understand visual formats.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          ) : isGeneratingDiagrams ? (
            <div className="bg-gray-50 p-10 rounded-lg border border-gray-200 flex flex-col items-center">
              <Loader2 className="h-10 w-10 text-primary-600 animate-spin mb-4" />
              <h4 className="text-lg font-medium text-gray-800 mb-2">Analyzing Content</h4>
              <p className="text-gray-600 text-center">
                We're analyzing the document content to identify processes and structures 
                that can be visualized effectively.
              </p>
            </div>
          ) : (
            <div className="bg-gray-50 p-10 rounded-lg border border-gray-200 text-center">
              <FlowChart className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h4 className="text-lg font-medium text-gray-800 mb-2">No Diagrams Generated Yet</h4>
              <p className="text-gray-600 max-w-md mx-auto mb-6">
                Visualize text descriptions as interactive diagrams, process maps, and flowcharts to make complex information easier to understand.
              </p>
              <div className="flex flex-col sm:flex-row justify-center gap-3">
                <button
                  onClick={handleGenerateAllDiagrams}
                  className="px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 flex items-center justify-center"
                >
                  <Sparkles className="h-4 w-4 mr-1.5" />
                  Generate Diagram
                </button>
                <VisualizeButton
                  onVisualize={handleAddVisualization}
                  className="sm:w-auto w-full"
                />
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

// Helper function to count words in a string
function countWords(str: string): number {
  return str.split(/\s+/).filter(word => word.length > 0).length;
}

export default DomainOutputDisplay;