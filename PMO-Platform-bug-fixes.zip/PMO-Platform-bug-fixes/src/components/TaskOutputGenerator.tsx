import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
// Define Task and DocumentChunk interfaces directly since they're not exported from types
interface Task {
  id: string;
  title: string;
  description: string;
  domainId: number;
  stage: string;
  templates?: string[];
  bestPractices?: string[];
}

interface DocumentChunk {
  content: string;
  metadata: {
    source?: string;
    [key: string]: any;
  };
}

import { useAppStore } from '../store';
import { Sparkles, Download, CheckCircle, Loader2, AlertTriangle, Link, BarChart as FlowChart, Info, X, Save, Clock } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { exportToPdf } from '../utils/exportUtils';
import { documentProcessingService } from '../services/documentProcessingService';
import ProcessMapGenerator from './ProcessMapGenerator';
import VisualizeButton from './VisualizeButton';
import { taskPromptService } from '../services/taskPromptService';
import OpenAI from 'openai';
import SourceValidation from './SourceValidation';
import { aiValidationService } from '../services/aiValidationService';
import TaskOutputAcceptance from './TaskOutputAcceptance';
import { useTranslation } from 'react-i18next';
import axios from 'axios';
import apiClient, { testBackendConnection } from '../api/client';
import { useToast } from '../hooks/useToast';
import { useLanguage } from '../contexts/LanguageContext';
import { translations } from '../translations';
import { enTaskTranslations, arTaskTranslations } from '../translations/task_translations';
import { supabase } from '../services/supabaseClient';

interface TaskOutputGeneratorProps {
  task: Task;
  onOutputSaved: (taskId: string, output: string, attachments: string[] ) => void;
  taskData: any;
  onClose?: () => void; // Add optional onClose prop
  onGenerating?: (isGenerating: boolean) => void; // Add prop to communicate generation state
}

// Replace the generationSteps array with translation keys
const generationSteps = [
  {
    step: 1,
    messageKey: 'generationSteps.step1'
  },
  {
    step: 2,
    messageKey: 'generationSteps.step2'
  },
  {
    step: 3,
    messageKey: 'generationSteps.step3'
  },
  {
    step: 4,
    messageKey: 'generationSteps.step4'
  },
  {
    step: 5,
    messageKey: 'generationSteps.step5'
  },
  {
    step: 6,
    messageKey: 'generationSteps.step6'
  },
  {
    step: 7,
    messageKey: 'generationSteps.step7'
  }
];

// Add TaskData interface to fix type issues
interface TaskData {
  notes?: string;
  completed?: boolean;
  attachments?: string[];
  customFields?: Record<string, any>;
  acceptanceStatus?: 'accepted' | 'needs-refinement' | 'rejected';
  acceptanceTimestamp?: string;
  documentUrl?: string; // URL to the generated document for download
}

interface ProcessMapGeneratorProps {
  text: string;
  title?: string;
  onError?: (error: Error) => void;
}

const TaskOutputGenerator: React.FC<TaskOutputGeneratorProps> = ({ task, onOutputSaved, taskData, onClose, onGenerating }) => {
  // Keep existing i18n for compatibility
  const { t: t2, i18n } = useTranslation();
  
  // Add fallback for useLanguage when provider is not available
  let language = 'en';
  let isRTL = false;
  
  try {
    // Try to get language and isRTL from app context
    const languageContext = useLanguage();
    language = languageContext?.language || 'en';
    isRTL = languageContext?.isRTL || false;
  } catch (error) {
    // Fallback to i18n data if useLanguage fails
    console.warn('Language provider not available, using i18n fallback');
    language = i18n?.language?.substring(0, 2) || 'en';
    isRTL = language === 'ar';
  }
  
  // Create a custom translation function that specifically uses task translations
  const t = useCallback((key: string, defaultValue?: string) => {
    // Get the current task translations based on language
    const taskTranslations = language === 'ar' ? arTaskTranslations : enTaskTranslations;
    
    // Check if the key exists in task translations using type-safe approach
    if (taskTranslations.hasOwnProperty(key)) {
      return taskTranslations[key as keyof typeof taskTranslations];
    }
    
    // Fallback to default value or key
    return defaultValue || key;
  }, [language]);

  // Function to translate task titles
  const translateTaskTitle = useCallback((title: string) => {
    // Common PMO task title translations
    const taskTitleTranslations: Record<string, Record<string, string>> = {
      "Implement PMO Charter and Governance": {
        "ar": "تنفيذ ميثاق مكتب إدارة المشاريع والحوكمة"
      },
      "Implement Governance Framework": {
        "ar": "تنفيذ إطار الحوكمة"
      },
      "Develop Project Management Methodology": {
        "ar": "تطوير منهجية إدارة المشاريع"
      },
      "Establish PMO Metrics": {
        "ar": "إنشاء مقاييس مكتب إدارة المشاريع"
      },
      "Implement Portfolio Management": {
        "ar": "تنفيذ إدارة المحفظة"
      }
    };
    
    // Check if we have a translation for this title
    if (language !== 'en' && title in taskTitleTranslations && language in taskTitleTranslations[title]) {
      return taskTitleTranslations[title][language];
    }
    
    // Return original title if no translation found
    return title;
  }, [language]);
  
  const [isInitializing, setIsInitializing] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [output, setOutput] = useState<string>('');
  const [savedOutput, setSavedOutput] = useState<string>('');
  const [exportingPdf, setExportingPdf] = useState(false);
  const [outputSaved, setOutputSaved] = useState(false);
  const [linkedDocuments, setLinkedDocuments] = useState<DocumentChunk[]>([]);
  const [crossDomainDocuments, setCrossDomainDocuments] = useState<DocumentChunk[]>([]);
  const [isLoadingDocs, setIsLoadingDocs] = useState(false);
  const [showVisualization, setShowVisualization] = useState(false);
  const [visualizationType, setVisualizationType] = useState<string>('flowchart');
  const [generatingPrompt, setGeneratingPrompt] = useState(false);
  const [prompt, setPrompt] = useState<string>(''); // Store the generated prompt
  const [generationStartTime, setGenerationStartTime] = useState<number | null>(null);
  const [elapsedTime, setElapsedTime] = useState<number>(0);
  const [showPrompt, setShowPrompt] = useState(false);
  const [isValidating, setIsValidating] = useState(false);
  const [validationResult, setValidationResult] = useState<any>(null);
  const [enhancedOutput, setEnhancedOutput] = useState<string | null>(null);
  const [showAcceptanceUI, setShowAcceptanceUI] = useState(false);
  const [acceptanceStatus, setAcceptanceStatus] = useState<'idle' | 'accepted' | 'needs-refinement' | 'rejected'>('idle');
  const [generatedFileUrl, setGeneratedFileUrl] = useState<string | null>(null);
  const [generatedFileName, setGeneratedFileName] = useState<string | null>(null);
  const [currentGenerationStep, setCurrentGenerationStep] = useState<number>(0);
  const [randomSitesNumber, setRandomSitesNumber] = useState<number>(0);
  const [selectedLanguage, setSelectedLanguage] = useState<'english' | 'arabic'>('english');
  const [error, setError] = useState<string | null>(null);
  const toast = useToast();
  const [showCloseConfirmation, setShowCloseConfirmation] = useState(false);
  const [showCancelConfirmation, setShowCancelConfirmation] = useState(false);

  const { getActiveProject, getDomainOutput, getDomainInput, connectionError, showConnectionErrors, updateTaskData } = useAppStore();
  const activeProject = getActiveProject();

  // Add a state variable for estimated time remaining
  const [estimatedTimeRemaining, setEstimatedTimeRemaining] = useState<number | null>(null);
  const [canCancel, setCanCancel] = useState<boolean>(false);

  // Add state for sub-steps in the final generation phase
  const [currentSubStep, setCurrentSubStep] = useState<number>(0);
  const [totalSubSteps, setTotalSubSteps] = useState<number>(0);

  // Add a reference to the API call that can be aborted
  const abortControllerRef = useRef<AbortController | null>(null);

  // Add a ref for the saved timeout
  const savedTimeoutRef = useRef<number | null>(null);
  
  // Add state for download loading
  const [isDownloading, setIsDownloading] = useState(false);

  // Add at the top of the component with other refs
  const isCancellingRef = useRef<boolean>(false);
  const isUnmountingRef = useRef<boolean>(false);

  // Add a simple resetState function to ensure a clean slate when reopening
  const resetState = useCallback(() => {
    console.log('TaskOutputGenerator: Resetting component state');
    
    // Reset all loading states
    setIsInitializing(false);
    setIsGenerating(false);
    setIsLoadingDocs(false);
    setGeneratingPrompt(false);
    
    // Reset generation artifacts
    setGenerationStartTime(null);
    setCurrentGenerationStep(0);
    setCurrentSubStep(0);
    
    // Reset the generation lock
    generationLockRef.current = false;
    
    // Clear API state
    if (abortControllerRef.current) {
      try {
        abortControllerRef.current.abort();
      } catch (err) {
        console.error('Error aborting controller during reset:', err);
      }
      abortControllerRef.current = null;
    }
    
    currentRequestIdRef.current = null;
    
    // Do NOT reset output or generatedFileUrl as those should persist
    // Only reset error state
    setError(null);
  }, []);  // No dependencies to avoid unnecessary recreation

  // Define the sub-step messages once to be reused
  const subStepMessages = [
    'generationSubSteps.structuring',
    'generationSubSteps.drafting',
    'generationSubSteps.enhancing',
    'generationSubSteps.reviewing',
    'generationSubSteps.finalizing'
  ];

  // Add a ref to track the current request ID
  const currentRequestIdRef = useRef<string | null>(null);

  // Add a ref to track if component is mounted
  const isMounted = useRef(true);

  // Add a ref to track animation frame ID for cleanup
  const animationFrameRef = useRef<number | null>(null);
  const transitionTimeoutRef = useRef<number | null>(null);

  // Add generation lock ref to prevent multiple simultaneous generation calls
  const generationLockRef = useRef<boolean>(false);

  // Add global safety timeout to prevent loading state from getting stuck
  useEffect(() => {
    // Skip if component is already showing content or if we're actively generating
    if (!isInitializing && !isLoadingDocs && !generatingPrompt) {
      return;
    }
    
    // Don't interrupt active generation API calls
    if (abortControllerRef.current !== null && isGenerating) {
      // API call is in progress, don't reset states
      return;
    }
    
    // Set timeout to force exit loading states if they persist too long
    const safetyTimeout = setTimeout(() => {
      if (!isMounted.current) return;

      console.warn("Safety timeout triggered - component has been in loading state too long");
      
      if (isInitializing) {
        safeSetState(setIsInitializing, false);
      }
      
      if (isLoadingDocs) {
        safeSetState(setIsLoadingDocs, false);
      }
      
      if (generatingPrompt) {
        safeSetState(setGeneratingPrompt, false);
      }
      
      // If we were stuck in generation initialization but API isn't running, reset state
      if (isGenerating && abortControllerRef.current === null) {
        safeSetState(setIsGenerating, false);
        safeSetState(setError, "Generation is taking too long. Please try again.");
      }
    }, 15000); // 15 seconds timeout
    
    return () => clearTimeout(safetyTimeout);
  }, [isInitializing, isLoadingDocs, generatingPrompt, isGenerating]);

  // Safe state update function to prevent updates after unmount
  const safeSetState = (setter: any, value: any) => {
    if (isMounted.current) {
      setter(value);
    }
  };

  // Fix the updateIsGenerating function to prevent flickering
  const updateIsGenerating = useCallback((generating: boolean): void => {
    // Add debug logging
    console.log(`updateIsGenerating called with: ${generating ? 'true' : 'false'}, current states:`, {
      isInitializing,
      isGenerating,
      hasTimeout: transitionTimeoutRef.current !== null
    });
    
    // Clear any existing timeouts to prevent race conditions
    if (transitionTimeoutRef.current) {
      clearTimeout(transitionTimeoutRef.current);
      transitionTimeoutRef.current = null;
    }
    
    if (generating) {
      // First set initializing, then generating with a slight delay
      safeSetState(setIsInitializing, true);
      
      // Set a safety timeout to ensure we don't get stuck in initializing state
      const safetyTimeout = setTimeout(() => {
        if (isMounted.current && isInitializing && !isGenerating) {
          console.log('Safety timeout triggered - forcing state progression');
          safeSetState(setIsGenerating, true);
          
          // If generation lock is stuck, reset it
          if (!isGenerating && !abortControllerRef.current) {
            generationLockRef.current = false;
          }
        }
      }, 3000); // Force progression after 3 seconds
      
      // Use a timeout to ensure proper state sequence
      transitionTimeoutRef.current = window.setTimeout(() => {
        if (isMounted.current) {
          clearTimeout(safetyTimeout);
          safeSetState(setIsGenerating, true);
        }
      }, 150);
    } else {
      // When stopping, first remove generating state
      safeSetState(setIsGenerating, false);
      
      // Then remove initializing state after a delay
      transitionTimeoutRef.current = window.setTimeout(() => {
        if (isMounted.current) {
          safeSetState(setIsInitializing, false);
        }
        
        // Also reset the generation lock
        generationLockRef.current = false;
      }, 500);
    }
    
    // Notify parent
    if (onGenerating) {
      onGenerating(generating);
    }
  }, [onGenerating, isInitializing, isGenerating]);

  // Add cleanup for animation frame and timeouts
  useEffect(() => {
    // Set mounted flag
    isMounted.current = true;
    isUnmountingRef.current = false;
    isCancellingRef.current = false;
    
    // Clear any error state on mount
    setError(null);
    
    // Reset generation lock on mount in case it was stuck from a previous render
    generationLockRef.current = false;
    
    // Log component mounting for debugging
    console.log('TaskOutputGenerator mounted', { task: task?.id });
    
    return () => {
      // Log component unmounting for debugging
      console.log('TaskOutputGenerator unmounting', { task: task?.id });
      
      // Mark component as unmounting to prevent additional calls
      isUnmountingRef.current = true;
      isMounted.current = false;
      
      // Reset state to prevent memory leaks
      resetState();
    };
  }, [task?.id]);

  // Complete reset function to ensure clean state
  const resetAllStates = useCallback(() => {
    console.log('TaskOutputGenerator: Resetting all states');
    
      // Mark component as unmounted to prevent state updates
      isMounted.current = false;
    
    // Reset generation lock
    generationLockRef.current = false;
      
      // Cancel any animation frames
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
        animationFrameRef.current = null;
      }
      
      // Clear all timeouts
      if (transitionTimeoutRef.current) {
        clearTimeout(transitionTimeoutRef.current);
        transitionTimeoutRef.current = null;
      }
      
      if (savedTimeoutRef.current) {
        clearTimeout(savedTimeoutRef.current);
        savedTimeoutRef.current = null;
      }
      
    // Reset all loading states
      setIsInitializing(false);
      setIsGenerating(false);
      setIsLoadingDocs(false);
      setGeneratingPrompt(false);
    setGenerationStartTime(null);
    setCurrentGenerationStep(0);
    setCurrentSubStep(0);
    setError(null);
      
      // Force all loading-related state variables to false to prevent zombie loading indicators
      updateIsGenerating(false);
      
      // Abort any ongoing API requests
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    
    // Reset request ID
    currentRequestIdRef.current = null;
  }, [updateIsGenerating]);

  // Direct close function that cleans up all state and calls onClose
  const handleDirectClose = useCallback(() => {
    // Prevent multiple close calls or closing during cancellation
    if (isUnmountingRef.current || isCancellingRef.current) {
      console.log('TaskOutputGenerator: Already unmounting, ignoring close call');
      return;
    }
    
    console.log('TaskOutputGenerator: Direct close called');
    
    // Mark as unmounting to prevent multiple close calls
    isUnmountingRef.current = true;
    
    // First abort any ongoing API request to prevent zombie processes
    if (abortControllerRef.current) {
      try {
        abortControllerRef.current.abort();
        console.log('Aborting backend generation request during direct close');
      } catch (error) {
        console.error('Error aborting request during direct close:', error);
      }
      abortControllerRef.current = null;
    }
    
    // Cancel any pending timeouts to prevent background updates
    if (transitionTimeoutRef.current) {
      clearTimeout(transitionTimeoutRef.current);
      transitionTimeoutRef.current = null;
    }
    
    // Reset generation lock if active
    generationLockRef.current = false;
    
    // Reset all states first using our cleanup function
    resetState();
    
    // Then notify the parent about generation state - ALWAYS before onClose
    if (onGenerating && typeof onGenerating === 'function') {
      onGenerating(false);
    }
    
    // Directly call onClose - make this SYNCHRONOUS without setTimeout
    if (onClose && typeof onClose === 'function') {
      console.log('TaskOutputGenerator: Calling onClose');
      onClose();
    }
  }, [resetState, onGenerating, onClose]);

  /* The loadRelatedDocuments function is defined elsewhere in the file */

  // Initialize totalSubSteps based on the array length
  useEffect(() => {
    setTotalSubSteps(subStepMessages.length);
  }, [subStepMessages.length]);

  // Fetch task data and related documents
  useEffect(() => {
    const loadTaskData = async () => {
      if (!activeProject) return;

      try {
        // Set a safety timeout to ensure we don't get stuck in loading
        const taskDataTimeout = setTimeout(() => {
          if (isMounted.current && isLoadingDocs) {
            console.log("Task data loading taking too long, continuing with UI rendering");
            safeSetState(setIsLoadingDocs, false);
          }
        }, 5000); // 5 second timeout
        
        // Load task data first - this is quick and should not delay UI
      const taskData = activeProject.domainData?.tasks?.[task?.id];
      if (taskData?.notes) {
          safeSetState(setSavedOutput, taskData.notes);
        
        // If there's saved output, show the acceptance UI only for non-processing tasks
        if (taskData.notes.trim().length > 0 && task?.stage !== 'processing') {
            safeSetState(setShowAcceptanceUI, true);
        }
        
        // Load acceptance status if available
        if (taskData.acceptanceStatus) {
            safeSetState(setAcceptanceStatus, taskData.acceptanceStatus);
          }
          
          // Check for document URL in customFields
          if (taskData.customFields?.documentUrl && !generatedFileUrl) {
            console.log('Loading saved document URL from task data:', taskData.customFields.documentUrl);
            safeSetState(setGeneratedFileUrl, taskData.customFields.documentUrl);
            
            // Try to extract filename from URL
            const url = taskData.customFields.documentUrl;
            const urlParts = url.split('/');
            let fileName = urlParts[urlParts.length - 1];
            
            if (fileName.includes('?')) {
              fileName = fileName.split('?')[0];
            }
            
            if (!fileName.toLowerCase().endsWith('.docx')) {
              fileName = `${task.title.replace(/\s+/g, '-')}-${new Date().toISOString().slice(0, 10)}.docx`;
            }
            
            safeSetState(setGeneratedFileName, fileName);
          }
        }

        // After loading task data, start document loading in background
        // This will happen asynchronously and shouldn't block UI rendering
        if (isMounted.current) {
          // Instead of calling loadRelatedDocuments directly, use the safe document loading function
          safeLoadDocuments();
        }

        clearTimeout(taskDataTimeout);
      } catch (error) {
        console.error("Error loading task data:", error);
        // Ensure we exit loading state even on error
        safeSetState(setIsLoadingDocs, false);
      }
    };

    // Safe document loading function that handles its own errors
    const safeLoadDocuments = async () => {
      if (isLoadingDocs) return;
      
      safeSetState(setIsLoadingDocs, true);
      safeSetState(setError, null);
      
      const loadingTimeout = setTimeout(() => {
        if (isMounted.current && isLoadingDocs) {
          console.log('Document loading timed out, continuing with available data');
          safeSetState(setIsLoadingDocs, false);
        }
      }, 10000);
      
      try {
        if (!activeProject) {
          clearTimeout(loadingTimeout);
          safeSetState(setIsLoadingDocs, false);
          return;
        }
        
        // Load domain documents
        try {
          const domainDocs = await documentProcessingService.getDomainDocuments(
            task?.domainId, 
            activeProject.id
          ) || [];
          
          if (isMounted.current) {
            safeSetState(setLinkedDocuments, domainDocs);
          }
        } catch (docError) {
          console.error('Error loading domain documents:', docError);
        }
        
        // Load cross-domain documents
        try {
          const crossDocs = await documentProcessingService.getRelevantCrossDomainChunks(
            (task?.title || "") + " " + (task?.description || ""),
            task?.domainId,
            activeProject.id,
            3
          );
          
          if (isMounted.current) {
            safeSetState(setCrossDomainDocuments, crossDocs || []);
          }
        } catch (crossError) {
          console.error('Error loading cross-domain documents:', crossError);
        }
      } catch (mainError) {
        console.error('Error in document loading process:', mainError);
      } finally {
        clearTimeout(loadingTimeout);
        if (isMounted.current) {
          safeSetState(setIsLoadingDocs, false);
        }
      }
    };

    loadTaskData();
  }, [task?.id, activeProject, task?.stage, isLoadingDocs, generatedFileUrl]);
  
  // For tracking elapsed time during generation and updating step
  useEffect(() => {
    let interval: number | undefined;
    
    if (generationStartTime && isGenerating) {
      interval = window.setInterval(() => {
        if (generationStartTime) {
          const newElapsedTime = Math.floor((Date.now() - generationStartTime) / 1000);
          setElapsedTime(newElapsedTime);
          
          // Update generation step based on elapsed time - adjusted for longer generation times
          // Spread steps across 4 minutes (240 seconds) for main steps, but estimate total time as 7 minutes
          const totalGenerationTime = 240; // 4 minutes in seconds for distributing steps
          const stepsCount = generationSteps.length;
          const timePerStep = totalGenerationTime / stepsCount;
          
          // Calculate step based on elapsed time
          const newStep = Math.min(Math.floor(newElapsedTime / timePerStep) + 1, stepsCount);
          
          // Only update step if it's changed
          if (newStep !== currentGenerationStep) {
            setCurrentGenerationStep(newStep);
            
            // For step 5, generate random number of sites
            if (newStep === 5) {
              setRandomSitesNumber(Math.floor(Math.random() * (100 - 20 + 1)) + 20);
            }
            
            // Reset sub-steps when changing main steps
            setCurrentSubStep(0);
          }
          
          // Update sub-steps for the final generation step (step 7)
          if (currentGenerationStep === 7) {
            // Calculate sub-step based on time in this step
            const timeInFinalStep = newElapsedTime - (6 * timePerStep);
            const subStepDuration = timePerStep / totalSubSteps;
            const newSubStep = Math.min(Math.floor(timeInFinalStep / subStepDuration) + 1, totalSubSteps);
            
            if (newSubStep !== currentSubStep) {
              setCurrentSubStep(newSubStep);
            }
          }
          
          // Calculate estimated time remaining after 30 seconds have passed
          if (newElapsedTime > 30) {
            // Assume total time is 7 minutes (420 seconds) for complex tasks
            const estimatedTotal = 420;
            const remaining = Math.max(0, estimatedTotal - newElapsedTime);
            setEstimatedTimeRemaining(remaining);
            
            // Allow cancellation after 7 minutes (420 seconds)
            if (newElapsedTime > 420 && !canCancel) {
              setCanCancel(true);
            }
          }
        }
      }, 1000);
    } else {
      setElapsedTime(0);
      setCurrentGenerationStep(0);
      setEstimatedTimeRemaining(null);
      setCanCancel(false);
      setCurrentSubStep(0);
    }
    
    return () => {
      if (interval) window.clearInterval(interval);
    };
  }, [generationStartTime, isGenerating, currentGenerationStep, currentSubStep, totalSubSteps, canCancel]);

  // Add an effect to clean up the abort controller on unmount
  useEffect(() => {
    return () => {
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
        abortControllerRef.current = null;
      }
    };
  }, []);

  // Generate a dynamic task-specific prompt using AI
  const generateDynamicPrompt = async () => {
    if (!activeProject) return '';
    
    setGeneratingPrompt(true);
    setError(null);
    try {
      // Get the custom prompt from the taskPromptService
      const dynamicPrompt = await taskPromptService.generateTaskPrompt(
        task,
        savedOutput || '', // Use existing output as context if available
        activeProject.id
      );
      
      setPrompt(dynamicPrompt || '');
      setShowPrompt(true); // Show the prompt to the user
      
      return dynamicPrompt || '';
    } catch (error: any) {
      console.error('Error generating prompt:', error);
      setError(error?.message || 'Failed to generate prompt');
      toast.error('Error generating task prompt');
      return '';
    } finally {
      setGeneratingPrompt(false);
    }
  };

  // Update handleCancelGeneration to reset all states properly
  const handleCancelGeneration = () => {
    // Prevent multiple cancellations
    if (isCancellingRef.current || isUnmountingRef.current) {
      console.log('Cancel already in progress or component unmounting, ignoring duplicate cancel');
      return;
    }
    
    // Set cancelling flag to prevent duplicate cancellations
    isCancellingRef.current = true;
    
    console.log('Canceling generation...');
    // First ensure no other confirmation dialogs are showing
    setShowCloseConfirmation(false);
    setShowCancelConfirmation(true);
  };

  // Update confirmCancelGeneration to ensure proper cleanup
  const confirmCancelGeneration = () => {
    console.log('Confirming generation cancellation, cleaning up...');
    
    // Always hide the dialog first to avoid UI glitches
    setShowCancelConfirmation(false);
    
    // First abort any ongoing API request
    if (abortControllerRef.current) {
      try {
        abortControllerRef.current.abort();
        console.log('Aborting backend generation request during cancel');
      } catch (error) {
        console.error('Error aborting request during cancel:', error);
      }
      abortControllerRef.current = null;
    }

    // Cancel any pending timeouts
    if (transitionTimeoutRef.current) {
      clearTimeout(transitionTimeoutRef.current);
      transitionTimeoutRef.current = null;
    }
    
    // Check if component is still mounted before updating state
    if (!isMounted.current || isUnmountingRef.current) {
      console.log('Component unmounting during cancellation, skipping state updates');
      return;
    }
    
    // Use a synchronous reset approach rather than the complex reset function
    // This avoids React batch update issues
    setIsInitializing(false);
    setIsGenerating(false);
    setIsLoadingDocs(false);
    setGeneratingPrompt(false);
    setGenerationStartTime(null);
    setCurrentGenerationStep(0);
    setCurrentSubStep(0);
    setShowCancelConfirmation(false);
    setElapsedTime(0);
    
    // Release the generation lock
    generationLockRef.current = false;
    
    // Notify parent that generation is complete - do this IMMEDIATELY
    if (onGenerating && typeof onGenerating === 'function') {
      onGenerating(false);
    }
    
    // Reset cancel flag to allow future cancellations
    setTimeout(() => {
      if (isMounted.current && !isUnmountingRef.current) {
        isCancellingRef.current = false;
      }
    }, 500);
  };

  // Use the imported testBackendConnection function from client.ts

  // Add a function to handle backend connection errors
  const handleBackendConnectionError = async () => {
    // First check if authentication is the issue
    const { data } = await supabase.auth.getSession();
    const isAuthenticated = !!data.session?.access_token;
    
    let errorMessage;
    
    if (!isAuthenticated) {
      errorMessage = 
        'You are not authenticated. Please log in first before generating content.\n' +
        'The backend API requires authentication to access the /pmo/recommendations endpoint.';
      
      toast.error('Authentication required. Please log in first.');
    } else {
      errorMessage = 
        'Cannot connect to the backend API server. Please ensure that:\n' +
        '1. The backend server is running (run "cd backend && python -m uvicorn main:app --reload")\n' +
        '2. The server is running on port 10000\n' +
        '3. The VITE_API_BASE_URL in your .env file is set to "http://localhost:10000"';
      
      toast.error('Cannot connect to the backend API. Check the console for details.');
    }
    
    safeSetState(setError, errorMessage);
    console.error(errorMessage);
  };

  // Enhanced generateOutput function with improved download handling
  const generateOutput = async () => {
    console.log("===== GENERATE OUTPUT CALLED =====");
    
    // Debug various conditions
    console.log({
      generationLockActive: generationLockRef.current,
      isGenerating,
      isInitializing,
      activeProject: !!activeProject,
      taskId: task?.id
    });
    
    // Check if generation lock is active - prevent starting if locked
    if (generationLockRef.current === true) {
      console.log('Generation is locked, cannot start new generation');
      return;
    }

    // Check if we're already generating or initializing
    if (isGenerating || isInitializing) {
      console.log('Generation already in progress, ignoring call');
      return;
    }
    
    if (!activeProject) {
      toast.error('No active project selected');
      return;
    }
    
    if (!task?.id) {
      toast.error('Invalid task data');
      return;
    }
    
    // Check if we're authenticated first
    const { data: authData } = await supabase.auth.getSession();
    if (!authData?.session?.access_token) {
      console.error('Authentication missing: No valid session token found');
      toast.error('You need to log in first');
      return;
    }
    console.log('Authentication check passed, session token exists');

    // Test backend connection directly instead of using the imported function
    console.log('Attempting DIRECT backend connection test...');
    let isBackendConnected = false;
    try {
      console.log('📡 Directly calling API endpoint: /healthcheck');
      const response = await apiClient.get('/healthcheck', { timeout: 5000 });
      console.log('📡 Healthcheck response:', response.data);
      isBackendConnected = true;
    } catch (err) {
      console.error('📡 ERROR calling healthcheck directly:', err);
      handleBackendConnectionError();
      return;
    }
    console.log('Backend connection test result:', isBackendConnected);
    
    if (!isBackendConnected) {
      console.error('Backend connection test failed');
      handleBackendConnectionError();
      return;
    }
    
    console.log('Backend connection test succeeded, continuing with generation');

    console.log('Starting generation with clean state check');
    
    try {
      // Set generation lock to prevent multiple starts
      generationLockRef.current = true;
      console.log('Generation lock set to true');
      
      // Set initial states
      safeSetState(setError, null);
    safeSetState(setOutput, '');
    safeSetState(setEnhancedOutput, null);
      safeSetState(setIsInitializing, true);
      safeSetState(setGeneratedFileUrl, null);  // Reset file URL
      safeSetState(setGeneratedFileName, null); // Reset file name
      
      // Small delay to ensure UI updates
      await new Promise(resolve => setTimeout(resolve, 100));
      
      // Set generation state
      safeSetState(setIsGenerating, true);
    safeSetState(setGenerationStartTime, Date.now());
    
      // Create new abort controller
    const abortController = new AbortController();
    abortControllerRef.current = abortController;
    
      // Notify parent
      if (onGenerating) {
        onGenerating(true);
      }
      
      // Set a warning timeout
      const warningTimeout = setTimeout(() => {
        if (isMounted.current) {
        toast.warning('The generation is taking longer than expected. You can continue waiting or cancel and try again.');
        safeSetState(setCanCancel, true);
      }
      }, 90000);
    
      // Generate prompt first
      safeSetState(setGeneratingPrompt, true);
      const dynamicPrompt = await generateDynamicPrompt();
      safeSetState(setGeneratingPrompt, false);
      
      if (!dynamicPrompt) {
        throw new Error('Failed to generate a prompt for this task');
      }
      
      // Check for abort
      if (abortController.signal.aborted) {
        throw new Error('Generation was cancelled');
      }
      
      // Generate unique request ID
      const requestId = `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
      currentRequestIdRef.current = requestId;
      
      // Prepare payload
      const requestPayload = {
        title: task.title,
        description: task.description,
        domain: task.domainId.toString(),
        stage: task.stage,
        bestPractices: task.bestPractices || [],
        user_input: dynamicPrompt,
        project_id: activeProject.id,
        task_id: task.id,
        language: selectedLanguage,
        request_id: requestId
      };
      
      // Make API call
      console.log('Making API call to /pmo/recommendations with payload:', JSON.stringify(requestPayload));
      try {
        console.log('About to make API request, checking auth session first...');
        const { data: authCheck } = await supabase.auth.getSession();
        console.log('Auth status before API call:', authCheck?.session ? 'Authenticated' : 'Not authenticated');
        
        console.log('Starting API request to /pmo/recommendations');
        const response = await apiClient.post('/pmo/recommendations', requestPayload, {
          signal: abortController.signal,
          timeout: 180000,
          headers: {
            'Authorization': `Bearer ${authCheck?.session?.access_token}`
          }
        });
        
        console.log('API response received:', response);
        
        if (!response.data || !response.data.public_url) {
          console.error('Invalid API response format:', response.data);
          throw new Error('Invalid response from API');
        }
        
        // Check for abort
        if (abortController.signal.aborted) {
          throw new Error('Generation was cancelled');
        }
        
        // Get content
        console.log('Fetching content from URL:', response.data.public_url);
        const contentResponse = await axios.get(response.data.public_url, {
          signal: abortController.signal,
          timeout: 30000
        });
        
        console.log('Content response received, length:', contentResponse.data?.length || 0);
        
        if (!isMounted.current) return null;
        
        // Update output state
        safeSetState(setOutput, contentResponse.data);
        
        // Store document URL - make sure this works
        console.log('Response contains public_url:', response.data.public_url);
        if (response.data.public_url) {
          const docxUrl = response.data.public_url;
          console.log('Setting generated file URL to:', docxUrl);
          safeSetState(setGeneratedFileUrl, docxUrl);
          
          // Extract filename
          const urlParts = docxUrl.split('/');
          let fileName = urlParts[urlParts.length - 1];
          
          if (fileName.includes('?')) {
            fileName = fileName.split('?')[0];
          }
          
          if (!fileName.toLowerCase().endsWith('.docx')) {
            fileName = `${task.title.replace(/\s+/g, '-')}-${new Date().toISOString().slice(0, 10)}.docx`;
          }
          
          console.log('Setting generated file name to:', fileName);
          safeSetState(setGeneratedFileName, fileName);
        }
        
        // Ensure minimum loading time for UX
        const elapsedTime = (Date.now() - (generationStartTime || Date.now())) / 1000;
        const minLoadTime = 10; // Reduced to 10 seconds for better UX
        
        if (elapsedTime < minLoadTime) {
          await new Promise(resolve => setTimeout(resolve, (minLoadTime - elapsedTime) * 1000));
        }
        
        // Clear timeouts
        clearTimeout(warningTimeout);
        
        // Success notification
        toast.success('Generation completed! You can now download the document.');
        
        return contentResponse.data;
      } catch (error: any) {
        console.error('Error generating output:', error);
        
        if (!isMounted.current) return null;
        
        // Handle specific errors - ensure we're only using includes on strings
        const errorMessage = typeof error?.message === 'string' ? error.message : '';
        const errorName = typeof error?.name === 'string' ? error.name : '';
        
        if (errorName === 'AbortError' || errorMessage.includes('abort') || errorMessage.includes('cancel')) {
          safeSetState(setError, 'Generation was cancelled');
          toast.info('Generation cancelled');
        } else if (error.code === 'ECONNABORTED' || errorMessage.includes('timeout')) {
          safeSetState(setError, 'Generation timed out. Please try again later.');
          toast.error('Generation timed out');
        } else if (error?.response?.status === 401 || error?.response?.status === 403) {
          // Handle authentication and permission errors
          const errorMsg = 'Authentication required. Please log in first.';
          safeSetState(setError, errorMsg);
          toast.error(errorMsg);
          
          // Debug output for authentication issues
          console.error('Authentication error details:', {
            status: error?.response?.status,
            data: error?.response?.data,
            headers: error?.response?.headers
          });
          
        } else {
          // Safely extract error message from response
          let errorMsg = 'Failed to generate output';
          
          if (error?.response?.data?.detail && typeof error.response.data.detail === 'string') {
            errorMsg = error.response.data.detail;
          } else if (typeof error?.message === 'string') {
            errorMsg = error.message;
          }
          
          safeSetState(setError, errorMsg);
          toast.error(errorMsg);
        }
        
        return null;
      } finally {
        // CRITICAL: Reset all states and refs to ensure clean state for next generation
        
        // Reset all controllers and request IDs
        abortControllerRef.current = null;
        currentRequestIdRef.current = null;
        
        // Reset loading states
        safeSetState(setIsGenerating, false);
        safeSetState(setIsInitializing, false);
        safeSetState(setGeneratingPrompt, false);
        safeSetState(setGenerationStartTime, null);
        
        // Clear generation lock - IMPORTANT for allowing next generation attempt
        generationLockRef.current = false;
        
        // Notify parent
        if (onGenerating) {
          onGenerating(false);
        }
        
        console.log('Generation attempt completed, all states reset');
      }
    } catch (error) {
      console.error('Unexpected error in generateTaskOutput:', error);
      return generateMockOutput(task);
    }
  };

  // Effect to handle document URL availability - don't auto-download
  useEffect(() => {
    if (generatedFileUrl) {
      console.log('Generated file URL available:', generatedFileUrl);
      // Don't automatically trigger download, just make the button available
    }
    
    // Empty cleanup function to maintain consistent return type
    return () => {};
  }, [generatedFileUrl]);

  // Create a variable to track the last download time to prevent accidental clicks
  const lastDownloadTimestamp = useRef<number>(0);
  
  const handleDownload = async (e?: React.MouseEvent<HTMLButtonElement, MouseEvent> | React.KeyboardEvent) => {
    // Prevent event propagation to avoid accidental clicks elsewhere triggering download
    if (e) {
      e.stopPropagation();
      e.preventDefault();
    }
    
    // Prevent downloads if already downloading
    if (isDownloading) return;
    
    // Add time-based throttling to prevent accidental double-clicks
    const now = Date.now();
    if (now - lastDownloadTimestamp.current < 3000) {
      console.log('Download throttled - ignoring click within 3 seconds of previous download');
      return;
    }
    lastDownloadTimestamp.current = now;
    
    setIsDownloading(true);
    toast.info(t('downloading', 'جار التنزيل...'));
    
    try {
      if (!generatedFileUrl) {
        console.error('No file URL available to download');
        toast.error(t('noFileAvailableToDownload', 'No file available to download.'));
        return;
      }
      
      // Use the direct URL from the server - this should be a DOCX file
      const fileName = generatedFileName || `${task.title.replace(/\s+/g, '-')}-output.docx`;
      console.log(`Downloading file: ${fileName} from URL: ${generatedFileUrl}`);
      
      // Create a temporary anchor element for download
      const link = document.createElement('a');
      link.href = generatedFileUrl;
      link.setAttribute('download', fileName);
      link.setAttribute('target', '_blank');
      document.body.appendChild(link);
      
      // Log before click
      console.log('Triggering download click');
      link.click();
      
      // Log after click
      console.log('Download click triggered');
      
      // Clean up
      setTimeout(() => {
        if (link.parentNode) {
          link.parentNode.removeChild(link);
        }
        console.log('Download link removed from DOM');
      }, 100);
      
      toast.success(t('downloadInitiatedCheckYourDownloadsFolder', 'Download initiated. Check your downloads folder.'));
      
      // Add a page refresh after successful download to prevent auto-download issue
      setTimeout(() => {
        window.location.reload();
      }, 1500); // Refresh after 1.5 seconds to allow the toast to be seen
    } catch (error) {
      console.error('Error downloading file:', error);
      toast.error(t('failedToDownloadFilePleaseTryAgain', 'Failed to download file. Please try again.'));
    } finally {
      setTimeout(() => {
        setIsDownloading(false);
      }, 2000); // Give it 2 seconds before allowing another download click
    }
  };
  
  // Validate output with external sources
  const validateOutput = async (content: string) => {
    if (!content) return null;
    
    setIsValidating(true);
    try {
      const {
        enhancedContent,
        validationResult,
        externalSourcesAdded
      } = await aiValidationService.enhanceAnalysisWithExternalSources(
        content,
        task.title,
        [...linkedDocuments, ...crossDomainDocuments]
      );
      
      setValidationResult(validationResult);
      
      if (externalSourcesAdded) {
        setEnhancedOutput(enhancedContent);
        toast.success('Output validation completed with additional references.');
      } else {
        toast.success('Output validation passed successfully.');
      }
      
      return validationResult;
    } catch (error) {
      console.error('Error validating output:', error);
      toast.error('Failed to validate output.');
      return null;
    } finally {
      setIsValidating(false);
    }
  };

  const generateTaskOutput = async (
    task: Task,
    dynamicPrompt: string,
    inputContent: string,
    analysisContent: string,
    documentChunks: DocumentChunk[] = []
  ): Promise<string> => {
    // Access OpenAI API key from env vars
    const apiKey = import.meta.env.VITE_OPENAI_API_KEY;
    
    if (!apiKey) {
      console.warn('OpenAI API key not found, using mock output');
      return generateMockOutput(task);
    }
    
    // Set a reasonable timeout
    const controller = new AbortController();
    const timeoutId = setTimeout(() => {
      controller.abort();
      console.warn('OpenAI API request timed out after 25 minutes');
    }, 1500000); // 25 minutes timeout
    
    try {
      // Create an OpenAI client
      const openai = new OpenAI({
        apiKey,
        dangerouslyAllowBrowser: true
      });
      
      // Process document chunks into a summary format
      const documentSummary = documentChunks.length > 0
        ? documentChunks.map(chunk => 
            `From ${chunk.metadata.source || 'Document'}: ${chunk.content.substring(0, 150)}...`
          ).join('\n\n').substring(0, 500)
        : '';
      
      try {
        // Call OpenAI API
        const response = await openai.chat.completions.create({
          model: "gpt-3.5-turbo",
          messages: [
            {
              role: "system",
              content: `You are an expert PMO (Project Management Office) consultant who creates practical deliverables for PMO implementation tasks. Focus on creating useful, actionable content based on the prompt provided.`
            },
            {
              role: "user",
              content: `${dynamicPrompt}

ADDITIONAL CONTEXT:
- Task ID: ${task.id}
- Domain Content: ${inputContent ? inputContent.substring(0, 200) + "..." : "None provided"}
- Analysis: ${analysisContent ? analysisContent.substring(0, 200) + "..." : "None available"}
${documentSummary ? `\nDocument Context:\n${documentSummary}` : ""}`
            }
          ],
          max_tokens: 1500,
          temperature: 0.5
        }, { signal: controller.signal });
        
        // Get the generated content
        const generatedText = response.choices[0]?.message?.content || '';
        
        if (!generatedText) {
          console.warn('Empty response from OpenAI API, using mock output');
          return generateMockOutput(task);
        }
        
        return generatedText;
      } catch (apiError: any) {
        console.error('Error calling OpenAI API:', apiError);
        
        // Check if this was a rate limit error
        if (apiError.status === 429) {
          return `# ${task.title}\n\n**Note: We're experiencing high demand right now.**\n\nPlease try again in a few minutes. Our AI system is currently processing many requests.`;
        }
        
        // Check if this was an authentication error
        if (apiError.status === 401) {
          console.error('Authentication error with OpenAI API');
          return generateMockOutput(task);
        }
        
        // For all other errors
        return generateMockOutput(task);
      }
    } catch (error) {
      console.error('Unexpected error in generateTaskOutput:', error);
      return generateMockOutput(task);
    } finally {
      clearTimeout(timeoutId);
    }
  };

  const generateMockOutput = (task: Task): string => {
    // Generate a mock output based on task info
    const taskStageCapitalized = task.stage.charAt(0).toUpperCase() + task.stage.slice(1);
    
    return `# ${task.title} Deliverable

## Overview
This deliverable provides a comprehensive approach to ${task.title.toLowerCase()} as part of the ${taskStageCapitalized} stage for your PMO implementation.

## Purpose
${task.description}

## Process Flow
1. **Initiate the Process**: Begin by gathering key stakeholders and defining the scope
2. **Conduct Current State Assessment**: Evaluate existing practices and identify gaps
3. **Develop Implementation Plan**: Create detailed implementation steps and timelines
4. **Decision Point**: Is executive approval required?
   - If YES: Submit for approval and wait for decision
   - If NO: Proceed with implementation
5. **Execute Implementation**: Deploy the solution according to the plan
6. **Monitor & Measure**: Track key metrics to evaluate effectiveness
7. **Review & Adjust**: Analyze results and make necessary adjustments
8. **Formalize Process**: Document the final process and incorporate into PMO standards

## Key Components

### 1. Assessment Framework
- Current state evaluation methodology
- Gap analysis approach
- Benchmarking criteria against industry standards
- Measurement metrics and KPIs

### 2. Implementation Guidelines
- Step-by-step implementation process
- Roles and responsibilities matrix
- Required resources and tools
- Timeline and milestones

### 3. Best Practices Integration
${task.bestPractices?.map((practice: string) => `- ${practice}`).join('\n') || '- Best practices not specified'}

### 4. Templates and Tools
- ${task.title.split(' ')[0]} template
- Assessment worksheet
- Implementation checklist
- Progress tracking dashboard

## Implementation Recommendations
1. Begin with a comprehensive assessment of current capabilities
2. Identify key stakeholders and secure their engagement
3. Develop a phased implementation approach
4. Create a communication plan for all affected parties
5. Establish clear metrics to measure success
6. Implement feedback mechanisms for continuous improvement
7. Document lessons learned throughout the process

## References
- PMI Standard for Project Management Offices
- Industry benchmarking data
- Organizational best practices

---

*Note: This deliverable should be tailored to your specific organizational context and requirements.*`;
  };

  // Clean up any pending timeouts when component unmounts
  useEffect(() => {
    return () => {
      if (savedTimeoutRef.current) {
        clearTimeout(savedTimeoutRef.current);
        savedTimeoutRef.current = null;
      }
    };
  }, []);

  const handleSave = () => {
    if (!activeProject) {
      toast.error('No active project selected. Please select a project first.');
      return;
    }
    
    if (!output && !enhancedOutput) {
      toast.error('No output to save. Please generate output first.');
      return;
    }
    
    const contentToSave = enhancedOutput || output;
    
    // Validate that we have actual content to save
    if (!contentToSave.trim()) {
      toast.error('Cannot save empty content. Please regenerate the output.');
      return;
    }
    
    // Just save the content
    updateTaskData(task.id, { 
      notes: contentToSave
    });
    
    // Then call onOutputSaved to handle any other necessary updates
    onOutputSaved(task.id, contentToSave, []);
    setOutputSaved(true);
    setSavedOutput(contentToSave);
      
    // Show success toast
    toast.success('Task output saved successfully!');
      
    // Clear any existing timeout
    if (savedTimeoutRef.current) {
      clearTimeout(savedTimeoutRef.current);
    }
    
    // Reset saved indicator after a delay - using functional update
    savedTimeoutRef.current = window.setTimeout(() => {
      setOutputSaved(prevState => false);
      savedTimeoutRef.current = null;
    }, 3000);
  };

  const handleExportPdf = async () => {
    setExportingPdf(true);
    try {
      const fileName = `${task.title.replace(/\s+/g, '-')}-Output.pdf`;
      await exportToPdf(enhancedOutput || output, fileName);
      toast.success('PDF export completed successfully.');
    } catch (error) {
      console.error('Error exporting to PDF:', error);
      toast.error('Failed to export PDF. Please try again.');
    } finally {
      setExportingPdf(false);
    }
  };
  
  // Add error handling for visualization
  const handleVisualizeClick = (type: string) => {
    try {
    setVisualizationType(type);
    setShowVisualization(true);
    } catch (error) {
      console.error('Error showing visualization:', error);
      toast.error('Failed to show visualization. Please try again.');
    }
  };
  
  // Format elapsed time as mm:ss
  const formatElapsedTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  // Handle output acceptance
  const handleOutputAcceptance = (content: string, status: 'accepted' | 'needs-refinement' | 'rejected', taskCompleted?: boolean) => {
    // Update the output saved in the store
    onOutputSaved(task.id, content, []);
    
    // Update the acceptance status
    updateTaskData(task.id, {
      acceptanceStatus: status,
      completed: status === 'accepted' && taskCompleted === true
    } as TaskData);
    
    // Update local state - use functional updates to avoid race conditions
    setAcceptanceStatus(prevStatus => status);
    setSavedOutput(prevOutput => content);
    
    if (status === 'rejected') {
      // Clear output to allow regeneration
      setOutput('');
      setEnhancedOutput(null);
    }
  };

  const reset = () => {
    // Reset all UI states
    if (isMounted.current) {
      setIsInitializing(false);
      setIsGenerating(false);
      setIsLoadingDocs(false);
      setGeneratingPrompt(false);
    setGenerationStartTime(null);
      setCurrentGenerationStep(0);
      setCurrentSubStep(0);
      setError(null);
      
      // Reset API-related state
      if (abortControllerRef.current) {
        try {
          abortControllerRef.current.abort();
        } catch (err) {
          console.error('Error aborting controller during reset:', err);
        }
        abortControllerRef.current = null;
      }
      
      // Reset request ID
      currentRequestIdRef.current = null;
      
      // Reset generation lock
      generationLockRef.current = false;
      
      // Clear any timeouts
      if (transitionTimeoutRef.current) {
        clearTimeout(transitionTimeoutRef.current);
        transitionTimeoutRef.current = null;
      }
      
      if (savedTimeoutRef.current) {
        clearTimeout(savedTimeoutRef.current);
        savedTimeoutRef.current = null;
      }
      
      // Cancel any animation frames
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
        animationFrameRef.current = null;
      }
    }
    
    // Notify parent component that generation is complete
    if (onGenerating) {
      onGenerating(false);
    }
  };

  // Update the getCurrentStepMessage function to include sub-steps
  const getCurrentStepMessage = () => {
    if (currentGenerationStep === 0 || currentGenerationStep > generationSteps.length) {
      return '';
    }
    
    const stepData = generationSteps[currentGenerationStep - 1];
    
    // Replace placeholder with random number for step 5
    if (currentGenerationStep === 5) {
      // Ensure randomSitesNumber is a valid number before calling toString
      const numberToDisplay = typeof randomSitesNumber === 'number' ? randomSitesNumber.toString() : '3';
      return t(stepData.messageKey).replace('${RANDOM_NUMBER}', numberToDisplay);
    }
    
    // Add sub-step information for the final generation step (step 7)
    if (currentGenerationStep === 7 && currentSubStep > 0) {
      const baseMessage = t(stepData.messageKey);
      
      // Only show sub-step message if we have one for this sub-step
      if (currentSubStep <= subStepMessages.length) {
        return `${baseMessage}\n\n${t(subStepMessages[currentSubStep - 1], 'Processing...')}`;
      }
    }
    
    return t(stepData.messageKey);
  };

  // Replace the LoadingIndicator component with a translated version
  const LoadingIndicator = () => (
    <div className="task-output-generator-loading w-full h-[200px] overflow-hidden">
      <div className="flex flex-col items-center justify-center h-full fade-transition">
        <div className="relative w-16 h-16 mb-4">
          <div className="absolute inset-0 rounded-full border-4 border-t-blue-600 border-blue-200 animate-spin"></div>
          <div className="absolute inset-0 flex items-center justify-center">
            <Sparkles className="h-6 w-6 text-blue-600" />
          </div>
        </div>
        <h3 className="text-lg font-medium text-gray-800 mb-1">{t('loadingContent', 'Loading Content')}</h3>
        <p className="text-gray-500 text-sm text-center">{t('preparingTaskData', 'Preparing task data and recommendations...')}</p>
      </div>
    </div>
  );

  // Handle close button click
  const handleCloseClick = () => {
    console.log('Close button clicked');
    
    // Simple direct close if not generating
    if (!isGenerating && !isInitializing) {
      console.log('Not generating, closing directly');
      handleDirectClose();
      return;
    }
    
    // If generating, show confirmation dialog
      setShowCancelConfirmation(false);
      setShowCloseConfirmation(true);
  };

  // Handle confirmation dialog responses
  const handleConfirmClose = () => {
    console.log('Confirm close called');
    
    // Hide the confirmation dialog first
    setShowCloseConfirmation(false);
    
    // Abort the API request if it's in progress
    if (abortControllerRef.current) {
      try {
        abortControllerRef.current.abort();
        console.log('Aborting backend generation request during close');
      } catch (error) {
        console.error('Error aborting request during close:', error);
      }
      abortControllerRef.current = null;
    }
    
    // Reset all generation states
    setIsInitializing(false);
    setIsGenerating(false);
    setIsLoadingDocs(false);
    setGeneratingPrompt(false);
    setGenerationStartTime(null);
    
    // Use handleDirectClose to ensure consistent closing behavior
    handleDirectClose();
  };

  const handleCancelClose = () => {
    console.log('Cancel close called');
      setShowCloseConfirmation(false);
  };

  // Add close confirmation dialog render function to reuse in multiple places
  const renderCloseConfirmationDialog = () => {
    if (!showCloseConfirmation) return null;
    
    return (
      <div 
        className="fixed inset-0 bg-black/60 z-[60] flex items-center justify-center p-4" 
        role="dialog" 
        aria-modal="true" 
        aria-labelledby="close-dialog-title">
        <div 
          className="bg-white rounded-lg shadow-xl p-6 max-w-md w-full border-2 border-blue-200"
        onClick={(e) => e.stopPropagation()}>
          <div className="flex items-center mb-4 text-blue-600">
            <Info className="h-6 w-6 mr-2" />
            <h3 id="close-dialog-title" className="text-lg font-semibold">{t('closeGenerator', 'Close Generator?')}</h3>
          </div>
          
          <p className="text-gray-700 mb-5">
            {t('closeGeneratorConfirmation', 'Are you sure you want to close the generator? Any unsaved progress will be lost.')}
          </p>
          
          <div className="flex justify-end gap-3">
          <button 
              onClick={handleCancelClose}
              className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 font-medium"
          >
              {t('stayHere', 'No, Stay Here')}
          </button>
            <button
              onClick={() => {
                console.log('Yes, Close button clicked');
                handleConfirmClose();
              }}
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 font-medium"
              id="confirm-close-button"
            >
              {t('yesClose', 'Yes, Close')}
            </button>
          </div>
        </div>
      </div>
    );
  };

  // Update the renderCancelConfirmationDialog function with translations
  const renderCancelConfirmationDialog = () => {
    if (!showCancelConfirmation) return null;
    
    return (
      <div className="fixed inset-0 bg-black/60 z-[60] flex items-center justify-center p-4" 
        role="dialog" 
        aria-modal="true" 
        aria-labelledby="cancel-dialog-title"
        onClick={(e) => e.stopPropagation()}>
        <div className="bg-white rounded-lg shadow-xl p-6 max-w-md w-full border-2 border-red-200"
          onClick={(e) => e.stopPropagation()}>
          <div className="flex items-center mb-4 text-red-600">
            <AlertTriangle className="h-6 w-6 mr-2" />
            <h3 id="cancel-dialog-title" className="text-lg font-semibold">{t('cancelGenerationQuestion', 'Cancel Generation?')}</h3>
          </div>
          
          <p className="text-gray-700 mb-5">
            {t('cancelGenerationConfirmation', 'Are you sure you want to cancel the generation process? This will stop the backend process completely.')}
          </p>
          
          <div className="flex justify-end gap-3">
            <button
              onClick={() => {
                requestAnimationFrame(() => {
                  setShowCancelConfirmation(false);
                });
              }}
              className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 font-medium"
            >
              {t('noContinue', 'No, Continue')}
            </button>
            <button
              onClick={confirmCancelGeneration}
              className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 font-medium"
            >
              {t('yesCancel', 'Yes, Cancel')}
            </button>
          </div>
        </div>
      </div>
    );
  };

  // Add error handling for markdown rendering
  const renderMarkdown = useCallback((content: string) => {
    try {
      return <ReactMarkdown>{content}</ReactMarkdown>;
    } catch (error) {
      console.error('Error rendering markdown:', error);
      return (
        <div className="text-red-500 p-4 border border-red-200 rounded">
          <p className="font-medium">{t('errorRenderingContent', 'Error rendering content')}</p>
          <p className="text-sm mt-2">{t('contentDisplayError', 'The content could not be displayed properly. Please try regenerating the output.')}</p>
          <pre className="mt-4 text-xs bg-gray-50 p-2 rounded overflow-auto max-h-40">{content.substring(0, 500)}...</pre>
                </div>
      );
    }
  }, [t]);

  // Memoize markdown rendering for better performance
  const memoizedMarkdown = useMemo(() => {
    if (output) {
      return renderMarkdown(enhancedOutput || output);
    } else if (savedOutput) {
      return renderMarkdown(savedOutput);
    }
    return null;
  }, [output, enhancedOutput, savedOutput, renderMarkdown]);

  // Fix the styling for the initializing state
  if (isInitializing && !isGenerating) {
    return (
      <>
        {/* This style element ensures any p-4 parent containers don't show through */}
        <style>{`
          div.p-4 { background-color: transparent !important; overflow: hidden !important; }
        `}</style>
      <div className="task-output-generator-modal fixed inset-0 flex items-center justify-center z-[99999] bg-indigo-900/90 backdrop-blur-sm">
        <div className="bg-indigo-800/30 rounded-lg p-8 shadow-xl max-w-md w-full relative border border-indigo-700/50">
          <div className="flex flex-col items-center">
            <div className="w-16 h-16 relative mb-4">
              <div className="absolute inset-0 rounded-full border-4 border-t-white border-white/30 animate-spin"></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <Sparkles className="h-6 w-6 text-white" />
              </div>
            </div>
            <h3 className="text-lg font-medium text-white mb-1">{t('loadingContent', 'Loading Content')}</h3>
            <p className="text-white/80 text-center text-sm">{t('preparingTaskData', 'Preparing task data and recommendations...')}</p>
          </div>
        </div>
      </div>
      </>
    );
  }

  // Fix the styling for the generating state
  if (isGenerating) {
    return (
      <>
        <div className="fixed inset-0 bg-indigo-900/90 flex items-center justify-center z-[99999] transition-opacity duration-500" 
             role="dialog" 
             aria-modal="true" 
             aria-labelledby="generation-title">
          <div className="max-w-md w-full text-center relative p-8 bg-indigo-800/30 rounded-lg backdrop-blur-sm shadow-xl">
            {/* Cancel button */}
              <button
              className="absolute top-3 right-3 p-2 rounded-md bg-indigo-800/60 hover:bg-indigo-700 transition-colors flex items-center"
                onClick={handleCancelGeneration}
              aria-label={t('cancelGeneration', 'Cancel generation')}
              >
              <X className="h-5 w-5 text-white" />
              {canCancel && <span className="ml-1 text-sm text-white">{t('cancel', 'Cancel')}</span>}
              </button>
            
            <div className="mb-6">
              <div className="relative mx-auto w-20 h-20">
                <div className="animate-spin rounded-full h-20 w-20 border-4 border-t-transparent border-white/80" role="status"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <Sparkles className="h-8 w-8 text-white" />
            </div>
              </div>
        </div>
        
            <h3 id="generation-title" className="text-xl font-semibold text-white mb-2">{t('generating', 'Generating...')}</h3>
            <p className="text-white/80 text-sm mb-4">{t('generatingMessage', "You'll also find the generated documents in the Project Assets page.")}</p>
            
            {/* Add message about long processing time */}
            <div className="bg-indigo-700/50 p-3 rounded-md mb-6">
              <p className="text-white/90 text-sm">
                <Clock className="inline-block h-4 w-4 mr-1.5 align-text-bottom" />
                {t('longProcessingTimeMessage', 'This may take 4-20 minutes for complex outputs. You can safely navigate away - the process will continue in the background.')}
              </p>
            </div>
            
            {currentGenerationStep > 0 ? (
              <div className="mb-4" aria-live="polite">
                <div className="flex justify-between text-white/80 text-sm mb-2">
                  <span>{`${t('step', 'Step')} ${currentGenerationStep}/${generationSteps.length}`}</span>
                  <span>{formatElapsedTime(elapsedTime)}</span>
                </div>
                
                {/* Progress bar */}
                <div className="w-full bg-indigo-800/50 rounded-full h-2.5 mb-3 overflow-hidden" role="progressbar" aria-valuenow={(currentGenerationStep / generationSteps.length) * 100} aria-valuemin={0} aria-valuemax={100}>
                  <div 
                    className="bg-white h-2.5 rounded-full transition-all duration-300" 
                    style={{ width: `${Math.min((currentGenerationStep / generationSteps.length) * 100, 95)}%` }}
                  />
                </div>
                
                <p className="text-white/90 text-sm mt-3 bg-indigo-800/30 p-3 rounded-md">
                  {getCurrentStepMessage()}
                </p>
                
                {estimatedTimeRemaining !== null && (
                  <p className="text-white/90 text-sm mt-3">{t('estimatedTimeRemaining', 'Est. remaining:')} ~{formatElapsedTime(estimatedTimeRemaining)}</p>
                )}
                
                {/* Add explicit cancel button at the bottom when processing takes too long */}
                {canCancel && (
                <button
                    onClick={handleCancelGeneration}
                    className="mt-5 px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors"
                >
                    {t('cancelGeneration', 'Cancel Generation')}
                </button>
                )}
              </div>
            ) : (
              <div className="rounded-md p-4 bg-indigo-800/40 mt-4" aria-live="polite">
                <p className="text-sm text-white">{t('thinkingAndAnalyzing', 'Thinking and analyzing your requirements...')}</p>
          </div>
        )}
      </div>
        </div>
        {renderCancelConfirmationDialog()}
      </>
    );
  }

  // Fix for the loading documents UI
    {/* Loading documents or generating prompt dialog */}
  {(isLoadingDocs || generatingPrompt) && (
    <>
      <div 
        className="fixed inset-0 flex items-center justify-center z-[9999] bg-indigo-900/75 backdrop-blur-sm"
          aria-live="polite"
          role="status"
        style={{ backgroundColor: 'rgba(49, 46, 129, 0.75)' }}
      >
        <div className="flex flex-col items-center" style={{ backgroundColor: 'transparent' }}>
          <div className="w-16 h-16 relative" style={{ backgroundColor: 'transparent' }}>
            <div className="absolute inset-0 rounded-full border-4 border-t-white border-white/30 animate-spin"></div>
              <div className="absolute inset-0 flex items-center justify-center">
              <Sparkles className="h-6 w-6 text-white" />
              </div>
            </div>
          <p className="text-white mt-4 font-medium">
            {generatingPrompt ? t('generatingPrompt', 'Generating prompt...') : t('loadingDocs', 'Loading documents...')}
          </p>
          
          {/* Direct close button using handleDirectClose */}
          <button
            onClick={handleCancelGeneration}
            className="mt-6 px-4 py-2 bg-red-600 text-white text-sm font-medium rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
          >
            {t('cancel', 'Cancel')}
          </button>
          </div>
        </div>
        {renderCancelConfirmationDialog()}
        {renderCloseConfirmationDialog()}
      </>
  )}

  if (error) {
    return (
      <>
        <div className="bg-white rounded-lg p-6 shadow-md my-4 relative min-h-[250px] transition-all duration-300 ease-in-out border border-gray-200 overflow-hidden">
          {/* Add close button */}
          {onClose && (
            <button 
              className="absolute top-3 right-3 p-1.5 rounded-full hover:bg-gray-100 transition-colors"
              onClick={() => {
                // Reset loading states before closing to prevent glitches
                resetState();
                onClose();
              }}
              aria-label={t('close', 'Close')}
            >
              <X className="h-5 w-5 text-gray-500" />
            </button>
          )}
          <div className="flex flex-col items-center justify-center text-red-500 h-full py-4">
            <AlertTriangle className="h-8 w-8 mb-2" />
            <span className="text-center">
              {typeof error === 'string' ? error : 'An error occurred during generation'}
            </span>
        <button
        onClick={() => {
          resetState();
          setError(null);
        }}
              className="mt-4 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
        >
              {t('tryAgain', 'Try Again')}
        </button>
      </div>
        </div>
        {renderCancelConfirmationDialog()}
      </>
    );
  }

  // For all non-generating states, show the white UI
  return (
    <>
      <div className={`bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden task-output-generator ${isRTL ? 'rtl' : ''}`}>
        <div className="flex items-center justify-between border-b border-gray-200 bg-gradient-to-r from-blue-600 to-blue-700 px-6 py-4">
          <h3 className="text-xl font-semibold text-white flex items-center">
            <div className="bg-white/20 rounded-full p-1.5 mr-3 backdrop-blur-sm">
              <Sparkles className="h-5 w-5 text-white" />
            </div>
            {translateTaskTitle(task?.title || t('taskOutputGenerator','Task Output Generator'))}
          </h3>
          {onClose && (
            <button 
              className="p-2 rounded-full hover:bg-white/20 transition-all duration-200"
              onClick={handleDirectClose}
              aria-label={t('close', 'Close')}
            >
              <X className="h-5 w-5 text-white" />
            </button>
          )}
        </div>
        
        <div className="p-6 bg-gradient-to-b from-gray-50 to-white">
      <p className="text-sm text-gray-600 mb-6">
        {t('generateComprehensiveOutputDeliverableForThisTaskBasedOnBestPracticesDomainContextAndYourOrganizationDocuments','Generate a comprehensive output deliverable for this task based on best practices, domain context, and your organization\'s documents.')}
      </p>
      
      {connectionError && showConnectionErrors && (
        <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-100 dark:border-yellow-800 rounded-md p-3 mb-4">
          <div className="flex">
            <AlertTriangle className="flex-shrink-0 mr-2 h-5 w-5 text-yellow-500" />
            <div>
              <h4 className="text-sm font-medium text-amber-800">{t('workingInOfflineMode','Working in offline mode')}</h4>
              <p className="text-xs text-amber-700 mt-1">{t('youCanContinueWorkingButSomeAIFeaturesLimited','You can continue working, but some AI features might be limited.')}</p>
            </div>
          </div>
        </div>
      )}
      
      {/* Related documents section */}
      {(linkedDocuments.length > 0 || crossDomainDocuments.length > 0) && (
        <div className="mb-4 p-3 bg-gray-50 rounded-lg border border-gray-200">
          <h4 className="text-sm font-medium text-gray-700 mb-2 flex items-center">
            <Link className="h-4 w-4 mr-2 text-blue-600" />
            {t('documentsReferencedInAnalysis','Documents Referenced in Analysis')}
          </h4>
          {isLoadingDocs ? (
            <div className="text-sm text-gray-500 flex items-center">
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              {t('loadingDocumentReferences','Loading document references...')}
            </div>
          ) : (
            <>
              {linkedDocuments.length > 0 && (
                <div className="mb-3">
                  <h5 className="text-sm font-medium text-gray-700 mb-1">{t('domainDocuments','Domain Documents')}</h5>
                  <ul className="space-y-1">
                    {linkedDocuments.map((doc, index) => (
                      <li key={index} className="text-sm text-gray-600 flex items-start">
                        <span className="bg-gray-200 text-gray-700 rounded-full w-5 h-5 inline-flex items-center justify-center text-xs mr-2 flex-shrink-0 mt-0.5">{index+1}</span>
                        <span className="flex-1">{doc.metadata.source || t('document','Document')}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              
              {crossDomainDocuments.length > 0 && (
                <div>
                  <h5 className="text-sm font-medium text-gray-700 mb-1">{t('crossDomainReferences','Cross-Domain References')}</h5>
                  <ul className="space-y-1">
                    {crossDomainDocuments.map((doc, index) => (
                      <li key={index} className="text-sm text-gray-600 flex items-start">
                        <span className="bg-purple-100 text-purple-700 rounded-full w-5 h-5 inline-flex items-center justify-center text-xs mr-2 flex-shrink-0 mt-0.5">{index+1}</span>
                        <span className="flex-1">{doc.metadata.source || t('crossDomainDocument','Cross-domain document')}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </>
          )}
        </div>
      )}
      
      {/* Display prompt when being generated or when user wants to view it */}
      {(generatingPrompt || showPrompt) && prompt && (
        <div className="mb-4 p-4 bg-blue-50 rounded-lg border border-blue-100">
          <div className="flex justify-between items-start mb-2">
            <h4 className="text-sm font-medium text-blue-800 flex items-center">
              <Sparkles className="h-4 w-4 mr-2 text-blue-600" />
              {generatingPrompt ? t('generatingTaskPrompt','Generating Task Prompt...') : t('taskSpecificAIPrompt','Task-Specific AI Prompt')}
            </h4>
            {!generatingPrompt && (
              <button 
                className="text-xs bg-blue-600 text-white px-2 py-1 rounded hover:bg-blue-700"
                onClick={() => setShowPrompt(false)}
              >
                {t('hidePrompt','Hide Prompt')}
              </button>
            )}
          </div>
          
          {generatingPrompt ? (
            <div className="flex items-center">
              <Loader2 className="h-4 w-4 mr-2 animate-spin text-blue-600" />
              <span className="text-sm text-blue-700">{t('creatingPersonalizedPromptForThisTask','Creating personalized prompt for this task...')}</span>
            </div>
          ) : (
            <div className="text-sm text-blue-700 bg-white p-3 rounded border border-blue-200 max-h-64 overflow-y-auto prose prose-sm">
                  <pre 
                    className="whitespace-pre-wrap font-sans text-xs"
                    tabIndex={0}
                    aria-label={t('generatedPrompt', 'Generated prompt for this task')}
                  >{prompt}</pre>
            </div>
          )}
        </div>
      )}
      
      {/* Main content area for output generation or display */}
      {(!output && !savedOutput) ? (
        <div className="bg-blue-50 p-6 rounded-lg border border-blue-100 text-center">
          <Sparkles className="h-10 w-10 text-blue-600 mx-auto mb-3" />
          <h3 className="text-lg font-medium text-gray-800 mb-2">{t('generateTaskOutput','Generate Task Output')}</h3>
          <p className="text-sm text-gray-600 mb-4 max-w-lg mx-auto">
            {t('ourAIWillAnalyzeYourTaskRequirementsAndContextToCreateAPersonalizedComprehensiveDeliverableForThisSpecificTask','Our AI will analyze your task requirements and context to create a personalized, comprehensive deliverable for this specific task. Please note this process may take anywhere from 1 to 20 minutes depending on the complexity of the task.')}
          </p>
          <div className="flex flex-col items-center gap-3">
            {/* Language selection toggle */}
            <div className="mb-4 flex items-center justify-center space-x-6">
              <div className="flex items-center">
                <input
                  type="radio"
                  id="language-english"
                  name="language"
                  value="english"
                  checked={selectedLanguage === 'english'}
                  onChange={() => {
                    if (selectedLanguage !== 'english' && !isGenerating) {
                      setSelectedLanguage('english');
                      toast.success(t('languageSetToEnglish', 'Language set to English'));
                    }
                  }}
                  disabled={isGenerating}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 disabled:opacity-50"
                />
                <label htmlFor="language-english" className={`ml-2 text-sm font-medium ${isGenerating ? 'text-gray-400' : 'text-gray-700'}`}>
                  {t('english', 'English')}
                </label>
              </div>
              <div className="flex items-center">
                <input
                  type="radio"
                  id="language-arabic"
                  name="language"
                  value="arabic"
                  checked={selectedLanguage === 'arabic'}
                  onChange={() => {
                    if (selectedLanguage !== 'arabic' && !isGenerating) {
                      setSelectedLanguage('arabic');
                      toast.success(t('languageSetToArabic', 'Language set to Arabic'));
                    }
                  }}
                  disabled={isGenerating}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 disabled:opacity-50"
                />
                <label htmlFor="language-arabic" className={`ml-2 text-sm font-medium ${isGenerating ? 'text-gray-400' : 'text-gray-700'}`}>
                  {t('arabic', 'العربية (Arabic)')}
                </label>
              </div>
            </div>
            
            <button
              onClick={() => {
                console.log("Generate button clicked");
                generateOutput();
              }}
              disabled={isGenerating}
              className={`px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center justify-center min-w-[200px] ${
                isGenerating ? 'opacity-70 cursor-not-allowed' : ''
              }`}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  if (!isGenerating) generateOutput();
                }
              }}
            >
              {isGenerating ? (
                <>
                  <Loader2 className="h-4 w-4 mr-1.5 animate-spin" />
                  {t('generating', 'Generating...')}
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4 mr-2" />
                  {t('generateRecommendations', 'Generate Recommendations')}
                </>
              )}
            </button>
          </div>
        </div>
      ) : (
        <div>
          {/* Source validation if available */}
          {validationResult && (
            <div className="mb-4">
              <SourceValidation
                content={enhancedOutput || output}
                domainName={task.title}
              />
            </div>
          )}

          {/* Content Acceptance UI */}
          {showAcceptanceUI && (
            <>
              <TaskOutputAcceptance
                taskId={task.id}
                content={enhancedOutput || output || savedOutput}
                onSave={handleOutputAcceptance}
                onRegenerate={generateOutput}
              />
              
              {/* Enhanced document download section for acceptance UI */}
              {generatedFileUrl && (
                <div className="mb-6 mt-6 bg-gradient-to-r from-green-50 to-green-100 rounded-lg p-4 border-l-4 border-l-green-500 shadow-sm transition-all duration-300">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                    <div className="flex items-center">
                      <div className="bg-green-100 rounded-full p-2 mr-3">
                        <Download className="h-5 w-5 text-green-600" />
                      </div>
                      <div>
                        <h4 className="font-medium text-green-900 mb-0.5">
                          {t('documentReady', 'Your document is ready')}
                        </h4>
                        <p className="text-sm text-green-700">
                          <span className="font-medium">{generatedFileName}</span>
                        </p>
                      </div>
                    </div>
                    <button 
                      onClick={handleDownload}
                      disabled={isDownloading}
                      className={`px-4 py-2 rounded-md text-white bg-green-600 hover:bg-green-700 shadow-sm hover:shadow flex items-center justify-center transition-all ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' || e.key === ' ') {
                          e.preventDefault();
                          if (!isDownloading) handleDownload();
                        }
                      }}
                    >
                      {isDownloading ? (
                        <>
                          <Loader2 className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'} animate-spin`} />
                          <span>{t('downloading', 'Downloading...')}</span>
                        </>
                      ) : (
                        <>
                          <Download className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
                          <span>{t('downloadNow', 'Download Now')}</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}
            </>
          )}

          {/* Saved output display - only show if no active output and not showing acceptance UI */}
          {savedOutput && !output && !showAcceptanceUI && (
            <div className="mb-6">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-6 gap-4 pb-4 border-b border-gray-100">
                <h4 className="font-medium text-lg text-gray-800 flex items-center">
                  <div className="bg-green-100 rounded-full p-1.5 mr-3">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                  </div>
                  {t('savedTaskOutput','Saved Task Output')}
                </h4>
                
                <div className="flex flex-wrap gap-3">
                  {/* Removed Visualize button */}
                  {/* Removed Regenerate button */}
                  
                  {/* Download button with enhanced styling */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      e.preventDefault();
                      handleDownload(e);
                    }}
                    disabled={isDownloading || !generatedFileUrl}
                    className={`px-4 py-2 rounded-md text-sm font-medium flex items-center shadow-sm ${
                      generatedFileUrl 
                        ? 'bg-green-600 hover:bg-green-700 text-white' 
                        : 'bg-gray-100 text-gray-500 border border-gray-200'
                    } transition-colors`}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        e.stopPropagation();
                        if (!isDownloading && generatedFileUrl) handleDownload(e);
                      }
                    }}
                    title={generatedFileUrl ? t('downloadDoc', 'تنزيل المستند') : t('documentNotAvailable', 'المستند غير متاح للتنزيل')}
                  >
                    {isDownloading ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        {t('downloading', 'جار التنزيل...')}
                      </>
                    ) : (
                      <>
                        <Download className="h-4 w-4 mr-2" />
                        {t('download', 'Download')}
                      </>
                    )}
                  </button>
                </div>
              </div>
              
                  {/* Enhanced file download section with better styling */}
                  <div className={`mb-6 ${generatedFileUrl ? 'bg-gradient-to-r from-green-50 to-green-100' : 'bg-blue-50'} 
                    rounded-lg p-5 border-l-4 ${generatedFileUrl ? 'border-l-green-500' : 'border-l-blue-400'} shadow-sm transition-all duration-300`}>
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                      <div className="flex items-center">
                        {generatedFileUrl ? (
                          <>
                            <div className="bg-white rounded-full p-2 mr-3 shadow-sm">
                              <Download className="h-5 w-5 text-green-600" />
                            </div>
                            <div>
                              <h4 className="font-medium text-green-900 mb-0.5">
                                {t('documentReady', 'المستند جاهز')}
                              </h4>
                              <p className="text-sm text-green-700">
                                <span className="font-medium">{generatedFileName}</span>
                              </p>
                            </div>
                          </>
                        ) : (
                          <>
                            <div className="bg-white rounded-full p-2 mr-3 shadow-sm">
                              <Info className="h-5 w-5 text-blue-600" />
                            </div>
                            <div>
                              <h4 className="font-medium text-blue-900 mb-0.5">
                                {t('documentDownloadTitle', 'Task Document')}
                              </h4>
                              <p className="text-sm text-blue-700">
                                {t('documentDownloadInfo', 'Download the generated document for this task')}
                              </p>
                            </div>
                          </>
                        )}
                      </div>
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          e.preventDefault();
                          handleDownload(e);
                        }}
                        disabled={isDownloading || !generatedFileUrl}
                        className={`px-5 py-2.5 rounded-md text-white flex items-center justify-center transition-all font-medium
                          ${generatedFileUrl 
                            ? 'bg-green-600 hover:bg-green-700 shadow-sm hover:shadow' 
                            : 'bg-gray-300 cursor-not-allowed opacity-80'
                          } ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' || e.key === ' ') {
                            e.preventDefault();
                            e.stopPropagation();
                            if (!isDownloading && generatedFileUrl) handleDownload(e);
                          }
                        }}
                        title={generatedFileUrl ? t('downloadDoc', 'تنزيل المستند') : t('documentNotAvailable', 'المستند غير متاح للتنزيل')}
                      >
                        {isDownloading ? (
                          <>
                            <Loader2 className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'} animate-spin`} />
                            <span>{t('downloading', 'جار التنزيل...')}</span>
                          </>
                        ) : (
                          <>
                            <Download className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
                            <span>{t('downloadDoc', 'تنزيل المستند')}</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
            </div>
          )}

          {/* Active output display */}
          {output && (
            <div className="mb-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-6 gap-4 pb-4 border-b border-gray-100">
                <h4 className="font-medium text-lg text-gray-800 flex items-center">
                  <div className="bg-green-100 rounded-full p-1.5 mr-3">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                  </div>
                  {t('generatedOutput', 'Generated Output')}
                </h4>
                
                <div className="flex flex-wrap gap-3">
                  {/* Removed Visualize button */}
                  {/* Removed Save button */}
                  
                  {/* Download button - highlighted when there's a document */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      e.preventDefault();
                      handleDownload(e);
                    }}
                    disabled={isDownloading || !generatedFileUrl}
                    className={`px-4 py-2 rounded-md flex items-center text-sm font-medium shadow-sm transition-all
                      ${generatedFileUrl 
                      ? 'bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white' 
                      : 'bg-gray-100 text-gray-500 border border-gray-200'} 
                      ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}
                    title={t('downloadDoc', 'تنزيل المستند')}
                  >
                    {isDownloading ? (
                      <>
                        <Loader2 className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'} animate-spin`} />
                        <span>{t('downloading', 'جار التنزيل...')}</span>
                      </>
                    ) : (
                      <>
                        <Download className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
                        <span>{t('downloadDoc', 'تنزيل المستند')}</span>
                      </>
                    )}
                  </button>
                  
                  {/* Close button */}
                  {onClose && (
                    <button 
                      onClick={handleCloseClick}
                      className="px-4 py-2 border border-red-200 text-sm font-medium text-red-600 rounded-md hover:bg-red-50 flex items-center shadow-sm transition-colors"
                    >
                      <X className="h-4 w-4 mr-2" />
                      {t('close', 'Close')}
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      )}
      
      <div className="mt-8">
        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border-l-4 border-l-blue-400 rounded-lg p-5 shadow-sm">
          <div className="flex items-start">
            <div className="bg-white rounded-full p-2 shadow-sm mr-4 flex-shrink-0">
              <Info className="h-5 w-5 text-blue-500" />
            </div>
            <div>
              <h4 className="text-base font-medium text-blue-900 mb-2">{t('aboutTaskSpecificGeneration', 'About Task-Specific Generation')}</h4>
              <p className="text-sm text-blue-800 mb-3">
                {t('thisFeatureCreatesPersonalizedContentTailoredToThisSpecificTaskUsing', 'This feature creates personalized content tailored to this specific task, using:')}
              </p>
              <ul className="text-sm text-blue-700 list-none space-y-2">
                <li className="flex items-center">
                  <div className="w-1.5 h-1.5 rounded-full bg-blue-500 mr-2 flex-shrink-0"></div>
                  {t('taskDetailsAndBestPractices', 'Task details and best practices')}
                </li>
                <li className="flex items-center">
                  <div className="w-1.5 h-1.5 rounded-full bg-blue-500 mr-2 flex-shrink-0"></div>
                  {t('domainContextAndRelatedDocuments', 'Domain context and related documents')}
                </li>
                <li className="flex items-center">
                  <div className="w-1.5 h-1.5 rounded-full bg-blue-500 mr-2 flex-shrink-0"></div>
                  {t('aiGeneratedTaskSpecificPrompts', 'AI-generated task-specific prompts')}
                </li>
                <li className="flex items-center">
                  <div className="w-1.5 h-1.5 rounded-full bg-blue-500 mr-2 flex-shrink-0"></div>
                  {t('externalKnowledgeSourcesForValidationAndEnrichment', 'External knowledge sources for validation and enrichment')}
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
      </div>
      {renderCancelConfirmationDialog()}
      {renderCloseConfirmationDialog()}
    </>
  );
};

export default TaskOutputGenerator;