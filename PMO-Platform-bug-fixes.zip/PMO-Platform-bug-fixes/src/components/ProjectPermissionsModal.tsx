import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Users, 
  UserPlus, 
  Shield, 
  X, 
  Search, 
  Mail, 
  Trash2, 
  AlertCircle, 
  Loader2, 
  Check
} from 'lucide-react';
import { useAuth } from './auth/AuthContext';
import { supabase } from '../services/supabaseClient';
import { setProjectPermission, removeProjectPermission } from '../services/supabaseService';

interface ProjectPermissionsModalProps {
  projectId: string;
  projectName: string;
  onClose: () => void;
  onUpdate?: () => void;
}

const ProjectPermissionsModal: React.FC<ProjectPermissionsModalProps> = ({ 
  projectId, 
  projectName,
  onClose,
  onUpdate
}) => {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  
  const [permissions, setPermissions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<'viewer' | 'editor' | 'admin'>('viewer');
  const [inviting, setInviting] = useState(false);
  const [searchingUser, setSearchingUser] = useState(false);
  const [foundUser, setFoundUser] = useState<any | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  
  useEffect(() => {
    fetchProjectPermissions();
  }, [projectId]);
  
  const fetchProjectPermissions = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('project_permissions')
        .select(`
          id,
          role,
          created_at,
          user:user_id (
            id,
            email,
            display_name:profiles!user_id (display_name, photo_url)
          )
        `)
        .eq('project_id', projectId);
      
      if (error) throw error;
      
      // Format the permissions data
      const formattedPermissions = data?.map(permission => ({
        id: permission.id,
        role: permission.role,
        userId: permission.user.id,
        email: permission.user.email,
        displayName: permission.user.display_name?.display_name || permission.user.email.split('@')[0],
        photoUrl: permission.user.display_name?.photo_url,
        createdAt: permission.created_at
      })) || [];
      
      setPermissions(formattedPermissions);
    } catch (error) {
      console.error('Error fetching project permissions:', error);
      setError('Failed to load project permissions');
    } finally {
      setLoading(false);
    }
  };
  
  const handleSearchUser = async () => {
    if (!email) return;
    
    setSearchingUser(true);
    setFoundUser(null);
    setError(null);
    
    try {
      // First check if user exists
      const { data, error } = await supabase
        .from('profiles')
        .select('id, email, display_name, photo_url')
        .ilike('email', email)
        .limit(1);
      
      if (error) throw error;
      
      if (data && data.length > 0) {
        setFoundUser(data[0]);
      } else {
        setError('User not found. Please check the email address.');
      }
    } catch (error) {
      console.error('Error searching user:', error);
      setError('Failed to search for user');
    } finally {
      setSearchingUser(false);
    }
  };
  
  const handleInviteUser = async () => {
    if (!foundUser) return;
    
    // Check if user already has permission
    if (permissions.some(p => p.userId === foundUser.id)) {
      setError('This user already has access to this project');
      return;
    }
    
    setInviting(true);
    setError(null);
    
    try {
      // Set project permission
      await setProjectPermission(projectId, foundUser.id, role);
      
      // Add to local state
      setPermissions([...permissions, {
        id: 'temp-' + Date.now(),
        role,
        userId: foundUser.id,
        email: foundUser.email,
        displayName: foundUser.display_name || foundUser.email.split('@')[0],
        photoUrl: foundUser.photo_url,
        createdAt: new Date().toISOString()
      }]);
      
      // Reset form
      setEmail('');
      setRole('viewer');
      setFoundUser(null);
      
      // Show success message
      setSuccess('User successfully invited to the project');
      
      // Clear success after 3 seconds
      setTimeout(() => {
        setSuccess(null);
      }, 3000);
      
      // Notify parent component
      if (onUpdate) onUpdate();
    } catch (error) {
      console.error('Error inviting user:', error);
      setError('Failed to invite user to the project');
    } finally {
      setInviting(false);
    }
  };
  
  const handleRemovePermission = async (permissionId: string, userId: string) => {
    try {
      await removeProjectPermission(projectId, userId);
      
      // Update local state
      setPermissions(permissions.filter(p => p.userId !== userId));
      
      // Notify parent component
      if (onUpdate) onUpdate();
    } catch (error) {
      console.error('Error removing permission:', error);
      setError('Failed to remove user from project');
    }
  };
  
  const getRoleBadgeClass = (role: string) => {
    switch (role) {
      case 'admin':
        return 'bg-red-100 text-red-800';
      case 'editor':
        return 'bg-blue-100 text-blue-800';
      case 'viewer':
      default:
        return 'bg-green-100 text-green-800';
    }
  };
  
  const getRoleDescription = (role: string) => {
    switch (role) {
      case 'admin':
        return 'Can manage the project, users, and all settings';
      case 'editor':
        return 'Can edit project data and analyze domains';
      case 'viewer':
      default:
        return 'Can view project data but cannot make changes';
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-3xl w-full">
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-800 flex items-center">
            <Users className="h-5 w-5 mr-2 text-primary-600" />
            Project Access Control
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        
        <div className="p-6">
          <div className="mb-6">
            <h3 className="font-medium text-gray-800 mb-2">Project: {projectName}</h3>
            <p className="text-gray-600 text-sm">
              Manage who has access to this project and what level of access they have. 
              As the project owner, you automatically have admin access.
            </p>
          </div>
          
          {error && (
            <div className="mb-4 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-md flex items-start">
              <AlertCircle className="h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}
          
          {success && (
            <div className="mb-4 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-md flex items-start">
              <Check className="h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
              <span>{success}</span>
            </div>
          )}
          
          <div className="p-4 border border-gray-200 rounded-lg mb-6">
            <h3 className="font-medium text-gray-800 mb-3 flex items-center">
              <UserPlus className="h-5 w-5 mr-2 text-primary-600" />
              Invite User
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  User Email
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Mail className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="email"
                    className="pl-10 block w-full rounded-md border-gray-300 shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                    placeholder="user@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                  {searchingUser ? (
                    <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
                      <Loader2 className="h-5 w-5 text-gray-400 animate-spin" />
                    </div>
                  ) : (
                    <div className="absolute inset-y-0 right-0 pr-1 flex items-center">
                      <button
                        type="button"
                        onClick={handleSearchUser}
                        className="p-1 rounded-md text-gray-400 hover:text-primary-600 hover:bg-gray-100"
                      >
                        <Search className="h-5 w-5" />
                      </button>
                    </div>
                  )}
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Access Level
                </label>
                <select
                  className="block w-full rounded-md border-gray-300 shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                  value={role}
                  onChange={(e) => setRole(e.target.value as any)}
                >
                  <option value="viewer">Viewer</option>
                  <option value="editor">Editor</option>
                  <option value="admin">Admin</option>
                </select>
              </div>
            </div>
            
            {foundUser && (
              <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-md">
                <div className="flex items-start">
                  <div className="flex-shrink-0">
                    {foundUser.photo_url ? (
                      <img
                        src={foundUser.photo_url}
                        alt="User"
                        className="w-10 h-10 rounded-full object-cover"
                      />
                    ) : (
                      <div className="w-10 h-10 rounded-full bg-primary-100 flex items-center justify-center text-primary-800 font-semibold">
                        {(foundUser.display_name || foundUser.email || 'U')[0].toUpperCase()}
                      </div>
                    )}
                  </div>
                  <div className="ml-3">
                    <h4 className="font-medium text-gray-800">
                      {foundUser.display_name || foundUser.email.split('@')[0]}
                    </h4>
                    <p className="text-sm text-gray-600">{foundUser.email}</p>
                  </div>
                  <button
                    className="ml-auto px-3 py-1 bg-primary-600 text-white text-sm rounded-md hover:bg-primary-700 flex items-center"
                    onClick={handleInviteUser}
                    disabled={inviting}
                  >
                    {inviting ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-1.5 animate-spin" />
                        Inviting...
                      </>
                    ) : (
                      <>
                        <UserPlus className="h-4 w-4 mr-1.5" />
                        Add to Project
                      </>
                    )}
                  </button>
                </div>
                <p className="mt-2 text-sm text-green-700">
                  This user will be given {role} access to the project. 
                  <span className="font-medium"> {getRoleDescription(role)}</span>
                </p>
              </div>
            )}
          </div>
          
          <div>
            <h3 className="font-medium text-gray-800 mb-3 flex items-center">
              <Shield className="h-5 w-5 mr-2 text-primary-600" />
              Current Access
            </h3>
            
            {loading ? (
              <div className="flex justify-center items-center py-12">
                <Loader2 className="h-6 w-6 text-primary-600 animate-spin mr-3" />
                <span className="text-gray-600">Loading users...</span>
              </div>
            ) : permissions.length === 0 ? (
              <div className="text-center py-8 bg-gray-50 rounded-lg border border-gray-200">
                <Users className="h-12 w-12 mx-auto text-gray-400 mb-3" />
                <p className="text-gray-600">No users have been granted access to this project yet</p>
                <p className="text-sm text-gray-500 mt-1">As the project owner, you have full access by default</p>
              </div>
            ) : (
              <div className="overflow-hidden rounded-lg border border-gray-200">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        User
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Access Level
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Added
                      </th>
                      <th scope="col" className="relative px-6 py-3">
                        <span className="sr-only">Actions</span>
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {permissions.map((permission) => (
                      <tr key={permission.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="flex-shrink-0 h-10 w-10">
                              {permission.photoUrl ? (
                                <img className="h-10 w-10 rounded-full" src={permission.photoUrl} alt="" />
                              ) : (
                                <div className="h-10 w-10 rounded-full bg-primary-100 flex items-center justify-center text-primary-800 font-semibold">
                                  {permission.displayName[0].toUpperCase()}
                                </div>
                              )}
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-gray-900">
                                {permission.displayName}
                              </div>
                              <div className="text-sm text-gray-500">
                                {permission.email}
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getRoleBadgeClass(permission.role)}`}>
                            {permission.role.charAt(0).toUpperCase() + permission.role.slice(1)}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {new Date(permission.createdAt).toLocaleDateString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          {/* Don't show delete button if this is the current user or if user is the project owner */}
                          {permission.userId !== currentUser?.id && (
                            <button
                              onClick={() => handleRemovePermission(permission.id, permission.userId)}
                              className="text-red-600 hover:text-red-900"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
        
        <div className="px-6 py-4 border-t border-gray-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProjectPermissionsModal;