import React, { useState, useEffect } from 'react';
import { Check, AlertTriangle, ExternalLink, ChevronDown, ChevronUp, Info, RefreshCw, Shield, Clock } from 'lucide-react';
import { externalSourceService, SourceValidationResult } from '../services/externalSourceService';

interface SourceValidationProps {
  content: string;
  domainName: string;
  onUpdate?: (result: SourceValidationResult) => void;
  strictness?: 'low' | 'medium' | 'high';
  className?: string;
  compact?: boolean;
}

const SourceValidation: React.FC<SourceValidationProps> = ({
  content,
  domainName,
  onUpdate,
  strictness = 'medium',
  className = '',
  compact = false
}) => {
  const [validationResult, setValidationResult] = useState<SourceValidationResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showDetails, setShowDetails] = useState(false);
  const [validationTimeAgo, setValidationTimeAgo] = useState<string>('');

  useEffect(() => {
    // Reset if content changes significantly
    if (content && content.length > 100) {
      validateContent();
    }
  }, [content, domainName, strictness]);

  // Calculate time since validation
  useEffect(() => {
    if (validationResult?.validationDate) {
      const updateTimeAgo = () => {
        const validationTime = new Date(validationResult.validationDate).getTime();
        const now = Date.now();
        const diffInMinutes = Math.floor((now - validationTime) / (1000 * 60));
        
        if (diffInMinutes < 1) {
          setValidationTimeAgo('just now');
        } else if (diffInMinutes < 60) {
          setValidationTimeAgo(`${diffInMinutes} minute${diffInMinutes !== 1 ? 's' : ''} ago`);
        } else if (diffInMinutes < 1440) { // less than a day
          const hours = Math.floor(diffInMinutes / 60);
          setValidationTimeAgo(`${hours} hour${hours !== 1 ? 's' : ''} ago`);
        } else {
          const days = Math.floor(diffInMinutes / 1440);
          setValidationTimeAgo(`${days} day${days !== 1 ? 's' : ''} ago`);
        }
      };
      
      updateTimeAgo();
      const interval = setInterval(updateTimeAgo, 60000); // Update every minute
      
      return () => clearInterval(interval);
    }
  }, [validationResult]);

  const validateContent = async () => {
    if (!content || content.length < 100) return;
    
    setIsLoading(true);
    setError(null);
    
    try {
      // Create a time buffer for visual feedback (min 1 second)
      const startTime = Date.now();
      const result = await externalSourceService.validateContent(content, domainName, { strictness });
      const endTime = Date.now();
      
      // Ensure loading indicator shows for at least 1 second for better UX
      const processingTime = endTime - startTime;
      if (processingTime < 1000) {
        await new Promise(resolve => setTimeout(resolve, 1000 - processingTime));
      }
      
      setValidationResult(result);
      if (onUpdate) {
        onUpdate(result);
      }
    } catch (err) {
      setError('Unable to validate content. Please try again later.');
      console.error('Validation error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const refreshValidation = () => {
    // Clear current validation and re-validate
    setValidationResult(null);
    validateContent();
  };

  // Render compact version
  if (compact) {
    if (isLoading) {
      return (
        <div className={`inline-flex items-center px-3 py-1 text-sm bg-blue-50 text-blue-700 rounded-full ${className}`}>
          <RefreshCw className="w-3.5 h-3.5 mr-1.5 animate-spin" />
          Validating sources...
        </div>
      );
    }

    if (!validationResult) {
      return (
        <div className={`inline-flex items-center px-3 py-1 text-sm bg-gray-100 text-gray-600 rounded-full ${className}`}>
          <Shield className="w-3.5 h-3.5 mr-1.5" />
          Not validated
        </div>
      );
    }

    if (validationResult.isValid) {
      return (
        <div className={`inline-flex items-center px-3 py-1 text-sm bg-green-50 text-green-700 rounded-full ${className}`}>
          <Check className="w-3.5 h-3.5 mr-1.5" />
          Verified ({Math.round(validationResult.confidence * 100)}%)
        </div>
      );
    }

    return (
      <div className={`inline-flex items-center px-3 py-1 text-sm bg-yellow-50 text-yellow-700 rounded-full ${className}`}>
        <AlertTriangle className="w-3.5 h-3.5 mr-1.5" />
        Needs review
      </div>
    );
  }

  // Render full version
  return (
    <div className={`border rounded-lg overflow-hidden ${className}`}>
      <div className={`p-4 ${
        isLoading ? 'bg-blue-50 border-blue-100' :
        error ? 'bg-red-50 border-red-100' :
        !validationResult ? 'bg-gray-50 border-gray-100' :
        validationResult.isValid ? 'bg-green-50 border-green-100' :
        'bg-yellow-50 border-yellow-100'
      }`}>
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            {isLoading ? (
              <div className="w-8 h-8 flex items-center justify-center rounded-full bg-blue-100 mr-3">
                <RefreshCw className="w-5 h-5 text-blue-600 animate-spin" />
              </div>
            ) : error ? (
              <div className="w-8 h-8 flex items-center justify-center rounded-full bg-red-100 mr-3">
                <AlertTriangle className="w-5 h-5 text-red-600" />
              </div>
            ) : !validationResult ? (
              <div className="w-8 h-8 flex items-center justify-center rounded-full bg-gray-100 mr-3">
                <Shield className="w-5 h-5 text-gray-500" />
              </div>
            ) : validationResult.isValid ? (
              <div className="w-8 h-8 flex items-center justify-center rounded-full bg-green-100 mr-3">
                <Check className="w-5 h-5 text-green-600" />
              </div>
            ) : (
              <div className="w-8 h-8 flex items-center justify-center rounded-full bg-yellow-100 mr-3">
                <AlertTriangle className="w-5 h-5 text-yellow-600" />
              </div>
            )}
            
            <div>
              <h3 className="font-medium">
                {isLoading ? 'Validating sources...' : 
                error ? 'Validation Error' :
                !validationResult ? 'Source Validation' :
                validationResult.isValid ? 'Content Verified' :
                'Content Needs Review'}
              </h3>
              <p className="text-sm">
                {isLoading ? 'Checking content against trusted sources' :
                error ? error :
                !validationResult ? 'Click to validate against trusted sources' :
                validationResult.isValid 
                  ? `Verified with ${validationResult.confidence.toFixed(2) * 100}% confidence` 
                  : 'Some information may need verification'}
              </p>
            </div>
          </div>

          <div className="flex items-center">
            {validationResult && (
              <span className="text-xs mr-3">
                <Clock className="inline h-3.5 w-3.5 mr-1" />
                {validationTimeAgo}
              </span>
            )}
            {!isLoading && (
              <div>
                {validationResult ? (
                  <button 
                    onClick={() => setShowDetails(!showDetails)}
                    className="p-1.5 rounded-full hover:bg-black/5 transition-colors"
                    aria-label={showDetails ? "Hide details" : "Show details"}
                  >
                    {showDetails ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
                  </button>
                ) : (
                  <button 
                    onClick={validateContent}
                    className="px-3 py-1.5 text-sm bg-blue-600 text-white rounded-md hover:bg-blue-700"
                  >
                    Validate Now
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {showDetails && validationResult && (
        <div className="p-4 bg-white border-t border-gray-200">
          <div className="space-y-4">
            {/* Sources used */}
            {validationResult.sourcesUsed.length > 0 && (
              <div>
                <h4 className="text-sm font-medium mb-2">Sources Used for Validation</h4>
                <div className="space-y-2">
                  {validationResult.sourcesUsed.map((source, index) => (
                    <div key={index} className="flex items-start p-3 bg-gray-50 rounded-md border border-gray-100">
                      <div className="flex-1">
                        <p className="font-medium text-sm">{source.name}</p>
                        {source.snippet && (
                          <p className="text-xs mt-1 text-gray-600 italic">{source.snippet}</p>
                        )}
                      </div>
                      <a 
                        href={source.url} 
                        target="_blank" 
                        rel="noopener noreferrer" 
                        className="ml-2 p-1.5 text-blue-600 hover:bg-blue-50 rounded"
                      >
                        <ExternalLink className="h-4 w-4" />
                      </a>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            {/* Suggested corrections */}
            {validationResult.suggestedCorrections && validationResult.suggestedCorrections.length > 0 && (
              <div>
                <h4 className="text-sm font-medium mb-2">Suggested Corrections</h4>
                <div className="space-y-2">
                  {validationResult.suggestedCorrections.map((correction, index) => (
                    <div key={index} className="p-3 bg-yellow-50 rounded-md border border-yellow-100">
                      <div className="flex items-start gap-1">
                        <div>
                          <span className="text-xs inline-block px-1.5 py-0.5 bg-gray-100 text-gray-800 rounded mr-1">Original</span>
                        </div>
                        <p className="flex-1 text-sm">{correction.original}</p>
                      </div>
                      <div className="flex items-start gap-1 mt-1">
                        <div>
                          <span className="text-xs inline-block px-1.5 py-0.5 bg-green-100 text-green-800 rounded mr-1">Suggested</span>
                        </div>
                        <p className="flex-1 text-sm">{correction.correction}</p>
                      </div>
                      <p className="text-xs mt-1 text-gray-600">{correction.explanation}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            {/* Actions */}
            <div className="flex justify-between">
              <button 
                onClick={refreshValidation}
                className="flex items-center text-blue-600 hover:text-blue-800 text-sm"
              >
                <RefreshCw className="h-4 w-4 mr-1.5" />
                Refresh Validation
              </button>
              
              <div className="flex items-center text-gray-500 text-xs">
                <Info className="h-3.5 w-3.5 mr-1" />
                <span>
                  {validationResult.isValid 
                    ? 'This content has been verified against trusted external sources' 
                    : 'Review suggested corrections before using this content'}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SourceValidation;