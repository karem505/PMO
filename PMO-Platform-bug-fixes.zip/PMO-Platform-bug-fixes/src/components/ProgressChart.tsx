import React, { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, Cell } from 'recharts';
import { useAppStore } from '../store';
import { domains } from '../data';
import { PieChart, Pie, Sector, LineChart, Line } from 'recharts';
import { BarChart3, PieChart as PieChartIcon, LineChart as LineChartIcon } from 'lucide-react';

const ProgressChart: React.FC = () => {
  const { getDomainProgress } = useAppStore();
  const [activeChartType, setActiveChartType] = useState<'bar' | 'pie' | 'line'>('bar');
  const [activeIndex, setActiveIndex] = useState(0);
  
  const data = domains.map(domain => {
    const progress = getDomainProgress(domain.id);
    return {
      name: domain.name.split(' ').slice(-1)[0], // Use last word of domain name for brevity
      fullName: domain.name,
      input: Math.round(progress.inputProgress),
      processing: Math.round(progress.processingProgress),
      output: Math.round(progress.outputProgress),
      overall: Math.round(progress.overallProgress),
      color: progress.overallProgress < 25 ? '#EF4444' : 
              progress.overallProgress < 50 ? '#F59E0B' : 
              progress.overallProgress < 75 ? '#10B981' : 
              '#3B82F6'
    };
  });
  
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const domainData = data.find(d => d.name === label);
      return (
        <div className="bg-white p-4 shadow-md rounded-md border border-gray-200">
          <p className="font-medium text-gray-800">{domainData?.fullName}</p>
          <p className="text-sm text-green-600">Input: {payload[0]?.value}%</p>
          <p className="text-sm text-yellow-600">Processing: {payload[1]?.value}%</p>
          <p className="text-sm text-purple-600">Output: {payload[2]?.value}%</p>
          <p className="text-sm font-medium text-blue-600">Overall: {payload[3]?.value}%</p>
        </div>
      );
    }
    return null;
  };
  
  const renderActiveShape = (props: any) => {
    const RADIAN = Math.PI / 180;
    const { cx, cy, midAngle, innerRadius, outerRadius, startAngle, endAngle, fill, payload, percent, value } = props;
    const sin = Math.sin(-RADIAN * midAngle);
    const cos = Math.cos(-RADIAN * midAngle);
    const sx = cx + (outerRadius + 10) * cos;
    const sy = cy + (outerRadius + 10) * sin;
    const mx = cx + (outerRadius + 30) * cos;
    const my = cy + (outerRadius + 30) * sin;
    const ex = mx + (cos >= 0 ? 1 : -1) * 22;
    const ey = my;
    const textAnchor = cos >= 0 ? 'start' : 'end';

    return (
      <g>
        <text x={cx} y={cy} dy={8} textAnchor="middle" fill={fill}>
          {payload.name}
        </text>
        <Sector
          cx={cx}
          cy={cy}
          innerRadius={innerRadius}
          outerRadius={outerRadius}
          startAngle={startAngle}
          endAngle={endAngle}
          fill={payload.color}
        />
        <Sector
          cx={cx}
          cy={cy}
          startAngle={startAngle}
          endAngle={endAngle}
          innerRadius={outerRadius + 6}
          outerRadius={outerRadius + 10}
          fill={payload.color}
        />
        <path d={`M${sx},${sy}L${mx},${my}L${ex},${ey}`} stroke={payload.color} fill="none" />
        <circle cx={ex} cy={ey} r={2} fill={payload.color} stroke="none" />
        <text x={ex + (cos >= 0 ? 1 : -1) * 12} y={ey} textAnchor={textAnchor} fill="#333">{`${payload.fullName}`}</text>
        <text x={ex + (cos >= 0 ? 1 : -1) * 12} y={ey} dy={18} textAnchor={textAnchor} fill="#999">
          {`(${value}%)`}
        </text>
      </g>
    );
  };

  const onPieEnter = (_: any, index: number) => {
    setActiveIndex(index);
  };
  
  return (
    <div className="bg-white rounded-xl shadow-sm p-4 md:p-6 hover:shadow-md transition-all duration-300">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-medium text-gray-800">Domain Progress</h3>
        <div className="flex space-x-1">
          <button
            onClick={() => setActiveChartType('bar')}
            className={`p-1.5 rounded ${activeChartType === 'bar' ? 'bg-primary-100 text-primary-700' : 'hover:bg-gray-100 text-gray-600'}`}
            title="Bar Chart"
          >
            <BarChart3 className="h-5 w-5" />
          </button>
          <button
            onClick={() => setActiveChartType('pie')}
            className={`p-1.5 rounded ${activeChartType === 'pie' ? 'bg-primary-100 text-primary-700' : 'hover:bg-gray-100 text-gray-600'}`}
            title="Pie Chart"
          >
            <PieChartIcon className="h-5 w-5" />
          </button>
          <button
            onClick={() => setActiveChartType('line')}
            className={`p-1.5 rounded ${activeChartType === 'line' ? 'bg-primary-100 text-primary-700' : 'hover:bg-gray-100 text-gray-600'}`}
            title="Line Chart"
          >
            <LineChartIcon className="h-5 w-5" />
          </button>
        </div>
      </div>

      <div className="h-80">
        {activeChartType === 'bar' && (
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={data}
              margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis unit="%" />
              <Tooltip content={<CustomTooltip />} />
              <Legend />
              <Bar dataKey="input" name="Input" fill="#10B981" />
              <Bar dataKey="processing" name="Processing" fill="#F59E0B" />
              <Bar dataKey="output" name="Output" fill="#8B5CF6" />
              <Bar dataKey="overall" name="Overall">
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        )}

        {activeChartType === 'pie' && (
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                activeIndex={activeIndex}
                activeShape={renderActiveShape}
                data={data}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={5}
                dataKey="overall"
                onMouseEnter={onPieEnter}
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        )}

        {activeChartType === 'line' && (
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={data}
              margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis unit="%" />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="input" name="Input" stroke="#10B981" activeDot={{ r: 8 }} />
              <Line type="monotone" dataKey="processing" name="Processing" stroke="#F59E0B" />
              <Line type="monotone" dataKey="output" name="Output" stroke="#8B5CF6" />
              <Line type="monotone" dataKey="overall" name="Overall" stroke="#3B82F6" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        )}
      </div>
      
      <div className="mt-4 text-center text-sm text-gray-500">
        <p>Click on chart type icons above to change visualization</p>
      </div>
    </div>
  );
};

export default ProgressChart;