import { useEffect, useRef, useState } from "react";
import apiClient from "../api/client";
import TaskDetailPage from './../pages/TaskDetailPage';
import { useAuth } from "./auth/AuthContext";
import { SubscriptionTier } from '../services/subscriptionService';
import { CreditCard, Lock } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

// Add props to receive sessionId and callback for payment completion
interface PaymentFormProps {
  sessionId: string;
  amount: number | string;
  description: string; 
  currency: string;
  paymentTier: SubscriptionTier | null;
  setPaymentSession: React.Dispatch<React.SetStateAction<{
    sessionId: string;
    amount: number | string;
    description: string;
    currency: string;
  } | null>>;
  onPaymentSuccess?: (paymentDetails: any) => void;
}

// Add type definition for PaymentSession to avoid window property errors
declare global {
  interface Window {
    PaymentSession?: any;
  }
}

// Format currency for display
const formatCurrency = (amount: number | string, currency: string = 'USD'): string => {
  const numAmount = typeof amount === 'string' ? parseFloat(amount) : amount;
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency,
    minimumFractionDigits: 2
  }).format(numAmount);
};

const PaymentForm = ({ sessionId, paymentTier, amount, description, currency, onPaymentSuccess, setPaymentSession }: PaymentFormProps) => {
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [success, setSuccess] = useState(false);
  const [paymentDetails, setPaymentDetails] = useState<any>(null);
  const [scriptLoaded, setScriptLoaded] = useState(false);
  const formRef = useRef(null);
  const { currentUser } = useAuth();
  const { t } = useLanguage();
  
  const SetToSupabase = async (paymentDetails: any) => {
    try {
      const des = paymentDetails.order.description;
      const response = await apiClient.post('/subscription/set', null, {
        params: {
          user_email: currentUser?.email,
          tier: paymentTier == 'premium' ? 'pro' : 'enterprise',
          payment_provider: paymentDetails.sourceOfFunds.provided.card.brand,
          payment_id: paymentDetails.order.id,
        }
      });
    } catch (error) {
      console.error('Error setting subscription in database:', error);
      setErrorMsg("Failed to update subscription. Please contact support.");
    }
  }
  
  useEffect(() => {
    // Guard against missing sessionId or already loaded script
    if (!sessionId || scriptLoaded) return;
    
    // Check if document exists (for SSR safety)
    if (typeof document === 'undefined') return;
    
    try {
      // Check if script already exists to avoid duplicates
      if (document.getElementById('payment-session-script')) {
        initializePaymentSession();
        return;
      }
      
      const script = document.createElement("script");
      script.id = 'payment-session-script';
      script.src = "https://banquemisr.gateway.mastercard.com/form/version/100/merchant/PROFESSIONAL/session.js";
      
      script.onload = () => {
        setScriptLoaded(true);
        initializePaymentSession();
      };
      
      script.onerror = () => {
        setErrorMsg("Failed to load payment processor. Please try again later.");
        console.error("Payment script failed to load");
      };
      
      // Only attempt to append if body exists
      if (document.body) {
        document.body.appendChild(script);
      } else {
        setErrorMsg("Payment form cannot be initialized. Please try again later.");
      }
    } catch (error) {
      console.error("Error loading payment script:", error);
      setErrorMsg("Payment system error. Please try again later.");
    }
  }, [sessionId]);
  
  const initializePaymentSession = () => {
    if (!window.PaymentSession) {
      setErrorMsg("Payment processor not available. Please try again later.");
      return;
    }
    
    try {
      window.PaymentSession.configure({
        session: sessionId,
        fields: {
          card: {
            number: "#card-number",
            securityCode: "#security-code",
            expiryMonth: "#expiry-month",
            expiryYear: "#expiry-year",
            nameOnCard: "#cardholder-name"
          }
        },
        frameEmbeddingMitigation: ["javascript"],
        callbacks: {
          initialized(response: { status: string, [key: string]: any }) {
            if (response.status === "ok") {
              const sessionIdElement = document.getElementById("sessionId");
              if (sessionIdElement) {
                (sessionIdElement as HTMLInputElement).value = sessionId;
              }
            } else {
              setErrorMsg("Error initializing payment session.");
            }
          },
          formSessionUpdate(response: { 
            status: string, 
            session?: { id: string },
            order?: { 
              amount: number | string,
              currency: string,
              description: string,
              id: string
            },
            sourceOfFunds?: {
              provided: {
                card: {
                  brand: string
                }
              }
            },
            [key: string]: any 
          }) {
            if (response.status === "ok") {
              // Save payment details and set success state
              SetToSupabase(response);
              setPaymentDetails({
                sessionId: response.session?.id || 'unknown',
                amount: response.order?.amount || amount,
                currency: response.order?.currency || currency,
                description: response.order?.description || description,
                timestamp: new Date().toISOString(),
                transactionId: response.order?.id || 'unknown',
                status: "COMPLETED"
              });
              setSuccess(true);
              
              // Call the parent callback if provided
              if (onPaymentSuccess) {
                onPaymentSuccess(paymentDetails);
              }
            } else {
              setErrorMsg("Please check your card details.");
            }
          }
        },
        interaction: {
          displayControl: {
            formatCard: "EMBOSSED",
            invalidFieldCharacters: "REJECT"
          }
        }
      });
    } catch (error) {
      console.error("Error configuring payment session:", error);
      setErrorMsg("Payment configuration error. Please try again later.");
    }
  };

  const handlePay = () => {
    setLoading(true);
    setErrorMsg("");
    
    try {
      if (window.PaymentSession) {
        window.PaymentSession.updateSessionFromForm("card");
      } else {
        setErrorMsg("Payment processor not available. Please refresh and try again.");
      }
    } catch (error) {
      console.error("Error processing payment:", error);
      setErrorMsg("Payment processing error. Please try again.");
    } finally {
      setTimeout(() => setLoading(false), 2000); // Simulate waiting time
    }
  };

  // If there's an error, show error UI with retry option
  if (errorMsg && !success) {
    return (
      <div className="max-w-xl mx-auto p-6 shadow-xl rounded-2xl bg-white space-y-4 mt-10">
        <h2 className="text-2xl font-bold text-gray-800">Payment Error</h2>
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
          <p className="text-red-700">{errorMsg}</p>
        </div>
        <button
          onClick={() => {
            setErrorMsg("");
            setPaymentSession(null);
          }}
          className="w-full py-2 rounded-lg text-white bg-blue-600 hover:bg-blue-700"
        >
          Try Again
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-xl mx-auto p-6 shadow-xl rounded-2xl bg-white space-y-4 mt-10">
      <h2 className="text-2xl font-bold text-gray-800">💳 Enter Payment Details</h2>

      {success ? (
        // Payment success UI
        <div className="space-y-4">
          <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
            <div className="flex items-center">
              <svg className="h-6 w-6 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              <p className="text-green-700 font-medium">Payment Completed Successfully!</p>
            </div>
          </div>
          
          {/* Payment Details */}
          <div className="border border-gray-200 rounded-lg p-4">
            <h3 className="font-medium text-lg mb-3">Payment Details</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Amount:</span>
                <span className="font-medium">{formatCurrency(amount, currency)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Description:</span>
                <span className="font-medium">{description}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Transaction ID:</span>
                <span className="font-medium">{paymentDetails?.transactionId || 'N/A'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Date:</span>
                <span className="font-medium">
                  {paymentDetails?.timestamp 
                    ? new Date(paymentDetails.timestamp).toLocaleString() 
                    : new Date().toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Status:</span>
                <span className="font-medium text-green-600">COMPLETED</span>
              </div>
            </div>
          </div>
        </div>
      ) : (
        // Payment form UI
        <>
          <div className="space-y-3">
            <input id="card-number" className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 text-gray-800" placeholder="Card Number" readOnly />
            <input id="expiry-month" className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 text-gray-800" placeholder="Expiry Month" readOnly />
            <input id="expiry-year" className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 text-gray-800" placeholder="Expiry Year" readOnly />
            <input id="security-code" className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 text-gray-800" placeholder="Security Code" readOnly />
            <input id="cardholder-name" className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 text-gray-800" placeholder="Cardholder Name" readOnly />
          </div>

          {/* Price Summary */}
          <div className="mt-4 p-4 bg-gray-50 border border-gray-200 rounded-lg">
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">{t('subscription.price', 'Price')}:</span>
                <span className="font-medium">{formatCurrency(amount, currency)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">{t('subscription.tax', 'Tax')}:</span>
                <span className="font-medium text-green-600">0% - {t('subscription.noTax', 'No Tax Applied')}</span>
              </div>
              <div className="pt-2 border-t border-gray-200 flex justify-between mt-2">
                <span className="font-medium">{t('subscription.total', 'Total')}:</span>
                <span className="font-bold">{formatCurrency(amount, currency)}</span>
              </div>
            </div>
          </div>

          <button
            onClick={handlePay}
            disabled={loading || !sessionId || !scriptLoaded}
            className={`w-full py-2 rounded-lg text-white ${loading || !scriptLoaded ? 'bg-gray-400' : 'bg-blue-600 hover:bg-blue-700'}`}
          >
            {loading ? "Processing..." : !scriptLoaded ? "Loading Payment..." : "Pay Now"}
          </button>
        </>
      )}

      <form ref={formRef} method="POST" action="https://my.company.com/pay" className="hidden">
        <input type="text" name="email" />
        <input type="hidden" name="sessionId" id="sessionId" />
      </form>
    </div>
  );
};

export default PaymentForm;
