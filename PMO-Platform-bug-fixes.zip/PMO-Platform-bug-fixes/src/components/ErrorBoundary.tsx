import React from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';
import { captureException } from '../services/sentryService';

interface Props {
  children: React.ReactNode;
  fallbackRender?: (props: { error: Error; resetErrorBoundary: () => void }) => React.ReactNode;
  onReset?: () => void;
  onError?: (error: Error, info: React.ErrorInfo) => void;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: React.ErrorInfo | null;
  isNodeNameError: boolean;
  errorCount: number;
}

/**
 * Enhanced ErrorBoundary component that specifically handles DOM-related errors
 * like "Cannot read properties of null (reading 'nodeName')"
 */
class ErrorBoundary extends React.Component<Props, State> {
  // Track if we've already tried to auto-recover
  private hasAttemptedAutoRecover = false;
  
  constructor(props: Props) {
    super(props);
    this.state = { 
      hasError: false, 
      error: null,
      errorInfo: null,
      isNodeNameError: false,
      errorCount: 0
    };
  }

  static getDerivedStateFromError(error: Error): Partial<State> {
    // Check for the specific "Cannot read properties of null (reading 'nodeName')" error
    const isNodeNameError = error.message && error.message.includes("Cannot read properties of null (reading 'nodeName')");
    
    if (isNodeNameError) {
      console.warn('Caught null nodeName error - applying immediate recovery strategy');
      
      // Log additional details for debugging
      console.info('This error typically happens when trying to access DOM properties before the component is mounted or after it unmounts');
      
      // Force a full page reload for nodeName errors - this is the most reliable fix
      try {
        // Add a flag to session storage to prevent infinite reload loops
        const reloadCount = parseInt(sessionStorage.getItem('errorBoundary_reloadCount') || '0', 10);
        if (reloadCount < 2) { // Only reload twice to prevent loops
          sessionStorage.setItem('errorBoundary_reloadCount', (reloadCount + 1).toString());
          console.log(`Forcing page reload (attempt ${reloadCount + 1})`);
          
          // Use a short timeout to allow logging to complete
          setTimeout(() => {
            window.location.reload();
          }, 100);
        } else {
          console.warn('Too many reload attempts, stopping automatic recovery');
          sessionStorage.removeItem('errorBoundary_reloadCount');
        }
      } catch (reloadError) {
        console.error('Failed to reload page:', reloadError);
      }
    }
    
    return { 
      hasError: true, 
      error,
      isNodeNameError,
      errorCount: (error as any)._errorCount || 1
    };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('Error caught by ErrorBoundary:', error);
    console.error('Component stack:', errorInfo.componentStack);
    
    // Check if this is the nodeName error
    const isNodeNameError = error.message && error.message.includes("Cannot read properties of null (reading 'nodeName')");
    
    if (isNodeNameError) {
      this.setState({ isNodeNameError: true });
      
      // Track error count to prevent infinite loops
      (error as any)._errorCount = ((error as any)._errorCount || 0) + 1;
      
      // If this is the first occurrence, try to auto-recover
      if (!this.hasAttemptedAutoRecover && (error as any)._errorCount <= 2) {
        this.hasAttemptedAutoRecover = true;
        
        // Force a reload for the most reliable fix
        try {
          console.log('Forcing immediate page reload to recover from nodeName error');
          window.location.reload();
        } catch (reloadError) {
          console.error('Failed to reload page:', reloadError);
        }
      }
    }
    
    // Call the onError prop if provided
    if (this.props.onError) {
      this.props.onError(error, errorInfo);
    }
    
    // Report to Sentry with additional context
    captureException(error, {
      componentStack: errorInfo.componentStack,
      errorInfo: errorInfo,
      location: window.location.href,
      isNodeNameError: isNodeNameError,
      // Add additional context that might help debug the issue
      url: window.location.href,
      userAgent: navigator.userAgent,
      windowDimensions: `${window.innerWidth}x${window.innerHeight}`,
      timestamp: new Date().toISOString(),
      documentReady: document.readyState,
      // DOM structure information
      bodyChildCount: document.body?.childElementCount,
      rootElementExists: !!document.getElementById('root'),
      // Error count to track repeated errors
      errorCount: (error as any)._errorCount || 1
    });
    
    this.setState({ 
      errorInfo,
      errorCount: (error as any)._errorCount || 1
    });
    
    // For nodeName errors, attempt immediate recovery
    if (isNodeNameError && !this.hasAttemptedAutoRecover) {
      // Set a timeout to auto-reset the error boundary
      setTimeout(() => {
        console.log('Auto-recovering from nodeName error');
        this.resetErrorBoundary();
      }, 2000);
    }
  }

  resetErrorBoundary = () => {
    // Call the onReset prop if provided
    if (this.props.onReset) {
      this.props.onReset();
    }
    
    // Special handling for nodeName errors
    const isNodeNameError = this.state.isNodeNameError || 
      (this.state.error?.message?.includes("Cannot read properties of null (reading 'nodeName')"));
    
    if (isNodeNameError) {
      // For nodeName errors, force a full page reload
      try {
        console.log('Forcing page reload to recover from nodeName error');
        window.location.reload();
        return; // Don't continue with normal reset
      } catch (reloadError) {
        console.error('Failed to reload page:', reloadError);
      }
    }
    
    // Clear the error state
    this.setState({ 
      hasError: false, 
      error: null,
      errorInfo: null,
      isNodeNameError: false,
      errorCount: 0
    });
    
    // Reset auto-recovery flag
    this.hasAttemptedAutoRecover = false;
  };

  // Restore scroll position after reload
  componentDidMount() {
    try {
      // Check if we're recovering from an error reload
      const reloadCount = parseInt(sessionStorage.getItem('errorBoundary_reloadCount') || '0', 10);
      if (reloadCount > 0) {
        console.log(`Recovered after ${reloadCount} reload(s)`);
        sessionStorage.removeItem('errorBoundary_reloadCount');
      }
      
      const savedScrollPos = sessionStorage.getItem('errorBoundary_scrollPos');
      if (savedScrollPos) {
        window.scrollTo(0, parseInt(savedScrollPos, 10));
        sessionStorage.removeItem('errorBoundary_scrollPos');
      }
    } catch (error) {
      console.error('Error restoring scroll position:', error);
    }
    
    // Add a MutationObserver to detect DOM changes that might cause nodeName errors
    this.setupDOMObserver();
  }
  
  componentWillUnmount() {
    // Clean up the DOM observer
    if (this._domObserver) {
      this._domObserver.disconnect();
    }
  }
  
  // MutationObserver to detect and prevent DOM issues
  _domObserver: MutationObserver | null = null;
  
  setupDOMObserver() {
    try {
      // Create a MutationObserver to watch for problematic DOM changes
      this._domObserver = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
          // Check for removed nodes that might cause nodeName errors
          if (mutation.type === 'childList' && mutation.removedNodes.length > 0) {
            // Check if any removed node has active event listeners or refs
            // This is a heuristic and can't catch all cases
            for (let i = 0; i < mutation.removedNodes.length; i++) {
              const node = mutation.removedNodes[i];
              if (node instanceof Element && node.hasAttribute('data-reactroot')) {
                console.warn('Detected removal of React root element - this could cause nodeName errors');
              }
            }
          }
        }
      });
      
      // Start observing the document with the configured parameters
      this._domObserver.observe(document.body, { 
        childList: true, 
        subtree: true,
        attributes: true,
        attributeFilter: ['id', 'class']
      });
    } catch (error) {
      console.error('Failed to setup DOM observer:', error);
    }
  }

  render() {
    if (this.state.hasError) {
      if (this.props.fallbackRender) {
        return this.props.fallbackRender({
          error: this.state.error!,
          resetErrorBoundary: this.resetErrorBoundary
        });
      }

      // Special handling for the nodeName error
      const isNodeNameError = this.state.isNodeNameError || 
        (this.state.error?.message?.includes("Cannot read properties of null (reading 'nodeName')"));
      
      const errorMessage = isNodeNameError 
        ? 'The application encountered a rendering issue. This has been automatically handled.'
        : this.state.error?.message || 'An unexpected error occurred. Please try again.';

      return (
        <div className="min-h-[calc(100vh-64px)] flex items-center justify-center bg-neutral-50 p-4">
          <div className="text-center px-4 max-w-md bg-white rounded-lg shadow-md p-6 border border-neutral-100">
            <AlertTriangle className="h-12 w-12 text-amber-500 mx-auto mb-4" />
            <h1 className="text-xl font-bold text-neutral-800 mb-2">Something went wrong</h1>
            <p className="text-neutral-600 mb-4">
              {errorMessage}
            </p>
            
            {isNodeNameError && (
              <div className="bg-blue-50 border border-blue-100 rounded-md p-3 mb-4 text-left">
                <p className="text-sm text-blue-800">
                  This is a known issue that occurs when a component tries to access DOM elements that aren't ready yet. 
                  The system is attempting to recover automatically. If it doesn't resolve in a few seconds, click the button below.
                </p>
              </div>
            )}
            
            <button
              onClick={this.resetErrorBoundary}
              className="px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 transition-colors flex items-center justify-center mx-auto"
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              {isNodeNameError ? 'Reload Page' : 'Try Again'}
            </button>
          </div>
        </div>
      );
    }

    // Wrap children in a div with error protection
    return (
      <div id="error-boundary-container">
        {this.props.children}
      </div>
    );
  }
}

export default ErrorBoundary; 