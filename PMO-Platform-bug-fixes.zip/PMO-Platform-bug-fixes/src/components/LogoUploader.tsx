import React, { useState, useRef } from 'react';
import { Upload, Image, X, Check, AlertCircle, Loader2 } from 'lucide-react';
import { fileToDataUrl, validateImage, resizeImage } from '../utils/imageUtils';
import { useAuth } from './auth/AuthContext';
import { useAppStore } from '../store';

interface LogoUploaderProps {
  onUploadComplete?: (logoUrl: string) => void;
}

const LogoUploader: React.FC<LogoUploaderProps> = ({ onUploadComplete }) => {
  const { userProfile, updateLocalUserProfile } = useAuth();
  const { userData } = useAppStore();
  const [previewUrl, setPreviewUrl] = useState<string | null>(userProfile?.logoUrl || null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    
    const file = files[0];
    
    // Reset states
    setError(null);
    setSuccess(false);
    
    // Validate file
    const validation = validateImage(file);
    if (!validation.valid) {
      setError(validation.message || 'Invalid file');
      return;
    }
    
    try {
      // Convert file to data URL for preview
      const dataUrl = await fileToDataUrl(file);
      
      // Resize image for preview
      const resizedDataUrl = await resizeImage(dataUrl, 400, 400);
      setPreviewUrl(resizedDataUrl);
      
      // In a real implementation, we would upload the file to Firebase Storage here
      // For demo purposes, we'll simulate the upload
      handleUpload(file);
    } catch (err) {
      setError('Error processing image');
      console.error('Error processing image:', err);
    }
  };
  
  const handleUpload = async (file: File) => {
    setIsUploading(true);
    setUploadProgress(0);
    
    try {
      // Simulate upload progress
      const simulateProgress = () => {
        const interval = setInterval(() => {
          setUploadProgress(prev => {
            const next = prev + 10;
            if (next >= 100) {
              clearInterval(interval);
              return 100;
            }
            return next;
          });
        }, 300);
        
        // Simulate upload completion
        setTimeout(() => {
          clearInterval(interval);
          setIsUploading(false);
          setUploadProgress(100);
          setSuccess(true);
          
          // Update user profile with the new logo URL
          // In a real implementation, we'd use the actual URL from Firebase Storage
          if (previewUrl) {
            updateLocalUserProfile({ logoUrl: previewUrl });
            if (onUploadComplete) onUploadComplete(previewUrl);
          }
          
          // Reset success message after a delay
          setTimeout(() => setSuccess(false), 3000);
        }, 3000);
      };
      
      simulateProgress();
      
      /* 
      In a real implementation with Firebase Storage:
      
      const storageRef = ref(storage, `logos/${userProfile.id}/${file.name}`);
      const uploadTask = uploadBytesResumable(storageRef, file);
      
      uploadTask.on('state_changed',
        (snapshot) => {
          const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
          setUploadProgress(progress);
        },
        (error) => {
          setError('Upload failed: ' + error.message);
          setIsUploading(false);
        },
        async () => {
          const downloadUrl = await getDownloadURL(uploadTask.snapshot.ref);
          setIsUploading(false);
          setUploadProgress(100);
          setSuccess(true);
          updateLocalUserProfile({ logoUrl: downloadUrl });
          if (onUploadComplete) onUploadComplete(downloadUrl);
        }
      );
      */
    } catch (err) {
      setError('Upload failed');
      setIsUploading(false);
      console.error('Upload error:', err);
    }
  };
  
  const handleRemoveLogo = () => {
    setPreviewUrl(null);
    setError(null);
    setSuccess(false);
    updateLocalUserProfile({ logoUrl: null });
    if (onUploadComplete) onUploadComplete('');
    
    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };
  
  const handleSelectFile = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };
  
  return (
    <div className="space-y-4">
      <div className="p-6 border border-gray-200 rounded-lg">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-medium text-gray-800">Organization Logo</h3>
          {previewUrl && (
            <button
              type="button"
              onClick={handleRemoveLogo}
              className="text-red-600 text-sm hover:text-red-800 flex items-center"
            >
              <X className="h-4 w-4 mr-1" />
              Remove Logo
            </button>
          )}
        </div>
        
        <div className="flex items-center space-x-6">
          <div className="w-32 h-32 border border-gray-200 rounded-lg flex items-center justify-center overflow-hidden bg-gray-50">
            {previewUrl ? (
              <img 
                src={previewUrl} 
                alt="Organization Logo" 
                className="max-w-full max-h-full object-contain"
              />
            ) : (
              <Image className="h-12 w-12 text-gray-400" />
            )}
          </div>
          
          <div className="flex-1 space-y-4">
            <div>
              <label htmlFor="logo-upload" className="block text-sm font-medium text-gray-700 mb-1">
                Upload Logo
              </label>
              <p className="text-sm text-gray-500 mb-2">
                Recommended size: 400x400px. Max file size: 2MB. Supported formats: JPG, PNG, SVG.
              </p>
              
              <input
                type="file"
                id="logo-upload"
                ref={fileInputRef}
                className="hidden"
                accept="image/jpeg,image/png,image/svg+xml,image/webp"
                onChange={handleFileChange}
              />
              
              <div className="flex flex-col sm:flex-row sm:space-x-3 space-y-2 sm:space-y-0">
                <button
                  type="button"
                  onClick={handleSelectFile}
                  disabled={isUploading}
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center justify-center disabled:opacity-60 disabled:cursor-not-allowed"
                >
                  <Upload className="h-4 w-4 mr-2" />
                  {previewUrl ? 'Change Logo' : 'Upload Logo'}
                </button>
                
                {previewUrl && !isUploading && !success && (
                  <button
                    type="button"
                    onClick={() => handleUpload(new File([], 'dummy'))}
                    className="px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors flex items-center justify-center"
                  >
                    <Check className="h-4 w-4 mr-2" />
                    Save Changes
                  </button>
                )}
              </div>
            </div>
            
            {/* Error message */}
            {error && (
              <div className="flex items-start text-red-600 text-sm">
                <AlertCircle className="h-4 w-4 mr-1.5 mt-0.5 flex-shrink-0" />
                <span>{error}</span>
              </div>
            )}
            
            {/* Success message */}
            {success && (
              <div className="flex items-center text-green-600 text-sm">
                <Check className="h-4 w-4 mr-1.5" />
                <span>Logo updated successfully!</span>
              </div>
            )}
            
            {/* Upload progress */}
            {isUploading && (
              <div className="space-y-2">
                <div className="flex items-center">
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  <span className="text-sm text-gray-600">Uploading... {uploadProgress.toFixed(0)}%</span>
                </div>
                <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-blue-600 rounded-full transition-all duration-300"
                    style={{ width: `${uploadProgress}%` }}
                  ></div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default LogoUploader;