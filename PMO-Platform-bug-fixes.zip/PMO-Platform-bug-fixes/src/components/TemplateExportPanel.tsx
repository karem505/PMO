import React, { useState } from 'react';
import { Download, Loader2, FileOutput, CheckCircle, AlertTriangle, FileCode, File as FilePdf } from 'lucide-react';
import { exportToPdf } from '../utils/exportUtils';

interface TemplateExportPanelProps {
  template: {
    name: string;
    content: string;
  };
}

const TemplateExportPanel: React.FC<TemplateExportPanelProps> = ({ template }) => {
  const [exportStatus, setExportStatus] = useState<Record<string, 'idle' | 'loading' | 'success' | 'error'>>({
    md: 'idle',
    docx: 'idle',
    pdf: 'idle',
    html: 'idle'
  });
  
  const exportFormats = [
    { id: 'md', name: 'Markdown', icon: FileCode, bgColor: 'bg-blue-100', textColor: 'text-blue-800' },
    { id: 'pdf', name: 'PDF', icon: FilePdf, bgColor: 'bg-red-100', textColor: 'text-red-800' },
    { id: 'docx', name: 'Word (DOCX)', icon: FileOutput, bgColor: 'bg-blue-100', textColor: 'text-blue-800' },
    { id: 'html', name: 'HTML', icon: FileCode, bgColor: 'bg-purple-100', textColor: 'text-purple-800' }
  ];
  
  const handleExport = async (format: string) => {
    setExportStatus(prev => ({ ...prev, [format]: 'loading' }));
    
    try {
      if (format === 'md') {
        // Create the template content in Markdown
        const element = document.createElement('a');
        const file = new Blob([template.content], { type: 'text/markdown' });
        element.href = URL.createObjectURL(file);
        element.download = `${template.name.replace(/\s+/g, '-')}.md`;
        document.body.appendChild(element);
        element.click();
        document.body.removeChild(element);
        
        setExportStatus(prev => ({ ...prev, [format]: 'success' }));
        
        // Reset success status after 2 seconds
        setTimeout(() => {
          setExportStatus(prev => ({ ...prev, [format]: 'idle' }));
        }, 2000);
      } else if (format === 'pdf') {
        // Use the utility to generate PDF directly from the content string
        exportToPdf(
          template.content, 
          `${template.name.replace(/\s+/g, '-')}.pdf`,
          () => {
            setExportStatus(prev => ({ ...prev, [format]: 'success' }));
            // Reset success status after 2 seconds
            setTimeout(() => {
              setExportStatus(prev => ({ ...prev, [format]: 'idle' }));
            }, 2000);
          }
        );
      } else {
        // For other formats, we show a coming soon message
        setExportStatus(prev => ({ ...prev, [format]: 'error' }));
        
        // Reset status after 3 seconds
        setTimeout(() => {
          setExportStatus(prev => ({ ...prev, [format]: 'idle' }));
        }, 3000);
      }
    } catch (error) {
      console.error(`Error exporting to ${format}:`, error);
      setExportStatus(prev => ({ ...prev, [format]: 'error' }));
      
      // Reset error status after 3 seconds
      setTimeout(() => {
        setExportStatus(prev => ({ ...prev, [format]: 'idle' }));
      }, 3000);
    }
  };
  
  return (
    <div className="mt-4 p-4 bg-gray-50 rounded-lg">
      <h3 className="text-sm font-medium text-gray-800 mb-3">Export Template</h3>
      
      <div className="grid grid-cols-2 gap-3">
        {exportFormats.map(format => (
          <div 
            key={format.id}
            className="flex items-center justify-between p-3 bg-white border border-gray-200 rounded-md hover:border-blue-300 transition-colors duration-200"
          >
            <div className="flex items-center">
              <div className={`p-2 ${format.bgColor} rounded-md mr-3`}>
                <format.icon className={`h-5 w-5 ${format.textColor}`} />
              </div>
              <span className="text-sm font-medium text-gray-800">{format.name}</span>
            </div>
            <button
              onClick={() => handleExport(format.id)}
              disabled={exportStatus[format.id] === 'loading'}
              className={`p-1.5 rounded-md ${
                exportStatus[format.id] === 'loading' ? 'bg-gray-100' : 
                'border border-gray-200 hover:bg-blue-50 hover:border-blue-200'
              }`}
            >
              {exportStatus[format.id] === 'loading' && (
                <Loader2 className="h-4 w-4 text-blue-500 animate-spin" />
              )}
              {exportStatus[format.id] === 'success' && (
                <CheckCircle className="h-4 w-4 text-green-500" />
              )}
              {exportStatus[format.id] === 'error' && (
                <AlertTriangle className="h-4 w-4 text-amber-500" />
              )}
              {exportStatus[format.id] === 'idle' && (
                <Download className="h-4 w-4 text-blue-500" />
              )}
            </button>
          </div>
        ))}
      </div>
      
      {(exportStatus.docx === 'error' || exportStatus.html === 'error') ? (
        <div className="mt-3 p-3 bg-amber-50 border border-amber-100 rounded-md">
          <div className="flex items-start">
            <AlertTriangle className="h-4 w-4 text-amber-500 mt-0.5 mr-2" />
            <div>
              <p className="text-xs text-amber-800">
                Export to Word (DOCX) and HTML formats is coming soon! Currently, only Markdown (.md) and PDF export are supported.
              </p>
            </div>
          </div>
        </div>
      ) : null}
      
      {exportStatus.pdf === 'error' && (
        <div className="mt-3 p-3 bg-amber-50 border border-amber-100 rounded-md">
          <div className="flex items-start">
            <AlertTriangle className="h-4 w-4 text-amber-500 mt-0.5 mr-2" />
            <div>
              <p className="text-xs text-amber-800">
                There was an error generating the PDF. This could be due to the complexity of the content. 
                Try using the Markdown export option instead.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TemplateExportPanel;