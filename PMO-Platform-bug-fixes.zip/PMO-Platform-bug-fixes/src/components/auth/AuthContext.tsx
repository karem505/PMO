import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '../../services/supabaseClient';
import { UserData, UserRole, Permission } from '../../types/index';
import { getUserProfile, updateUserProfile as updateProfileInDb } from '../../services/supabaseService';
import apiClient from '../../api/client';
import { useAppStore } from '../../store';

interface AuthContextType {
  currentUser: User | null;
  session: Session | null;
  isLoading: boolean;
  isAdmin: boolean;
  userProfile: UserData | null;
  userRoles: UserRole[];
  userPermissions: Permission[];
  signOut: () => Promise<void>;
  updateUserProfile: (data: Partial<UserData>) => Promise<boolean>;
  hasPermission: (permission: string, resourceType?: string, resourceId?: string) => boolean;
  networkError: boolean;
  authError: string | null;
}

interface AuthProviderProps {
  children: React.ReactNode;
}

// Create the context with default values
const AuthContext = createContext<AuthContextType>({
  currentUser: null,
  session: null,
  isLoading: true,
  isAdmin: false,
  userProfile: null,
  userRoles: [],
  userPermissions: [],
  signOut: async () => {},
  updateUserProfile: async () => false,
  hasPermission: () => false,
  networkError: false,
  authError: null
});

export const useAuth = () => {
  const context = useContext(AuthContext);
  
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  
  return context;
};

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [userProfile, setUserProfile] = useState<UserData | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [userRoles, setUserRoles] = useState<UserRole[]>([]);
  const [userPermissions, setUserPermissions] = useState<Permission[]>([]);
  const [authInitialized, setAuthInitialized] = useState(false);
  const [networkError, setNetworkError] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const { createProject } = useAppStore();

  // Function to fetch user profile
  const fetchUserProfile = async (user: User): Promise<UserData | null> => {
    try {
      const userProfile = await getUserProfile(user.id);
      return userProfile;
    } catch (error) {
      console.error('Error fetching user profile:', error);
      setNetworkError(true);
      return null;
    }
  };

  // Helper function to clear all auth-related data
  const clearAllAuthData = () => {
    // Clear all session storage
    sessionStorage.removeItem('authToken');
    sessionStorage.removeItem('cachedAuthData');
    sessionStorage.removeItem('cachedProfile');
    sessionStorage.removeItem('cachedRoles');
    sessionStorage.removeItem('cachedPermissions');
    sessionStorage.removeItem('cachedIsAdmin');
    
    // Clear all localStorage items related to auth
    // Legacy format (key-based)
    localStorage.removeItem('supabase.auth.token');
    localStorage.removeItem('supabase.auth.expires_at');
    localStorage.removeItem('supabase.auth.refresh_token');
    
    // Current format (prefix-based)
    const localStorageKeys = Object.keys(localStorage);
    for (const key of localStorageKeys) {
      if (
        key.startsWith('sb-') || 
        key.startsWith('supabase.auth.') || 
        key.includes('auth')
      ) {
        localStorage.removeItem(key);
      }
    }
    
    // Clear Supabase specific items - get the project reference from the URL
    try {
      // Get the project reference from the config
      const supabaseUrlStr = import.meta.env.VITE_SUPABASE_URL || '';
      if (supabaseUrlStr) {
        const supabaseUrl = new URL(supabaseUrlStr);
        const projectRef = supabaseUrl.hostname.split('.')[0];
        if (projectRef) {
          localStorage.removeItem(`sb-${projectRef}-auth-token`);
          localStorage.removeItem(`sb-${projectRef}-provider-token`);
          
          // Clear any key containing this project ref
          for (const key of localStorageKeys) {
            if (key.includes(projectRef)) {
              localStorage.removeItem(key);
            }
          }
        }
      }
    } catch (error) {
      console.error('Error clearing Supabase specific storage:', error);
    }
    
    // Clear state
    setCurrentUser(null);
    setUserProfile(null);
    setIsAdmin(false);
    setSession(null);
    setUserRoles([]);
    setUserPermissions([]);
  };

  // Check for auth on mount
  useEffect(() => {
    const initializeAuth = async () => {
      try {
        const { data: { session }, error } = await supabase.auth.getSession();
        
        if (error) {
          console.error('Error getting session:', error);
          clearAllAuthData();
          setAuthError(error.message);
          setIsLoading(false);
          return;
        }
        
        if (session) {
          setSession(session);
          setCurrentUser(session.user);
          
          if (session.user) {
            // Store user email in localStorage for API calls
            if (session.user.email) {
              localStorage.setItem('userEmail', session.user.email);
            }
            const profile = await fetchUserProfile(session.user);
            setUserProfile(profile);
          }
          
          setAuthInitialized(true);
          setIsLoading(false);
        } else {
          // No session found, clear loading state
          setIsLoading(false);
        setAuthInitialized(true);
        }
      } catch (error) {
        console.error('Error initializing auth:', error);
        clearAllAuthData();
        setIsLoading(false);
        setAuthInitialized(true);
      }
    };
    
    initializeAuth();
  }, []);

  // Listen for auth changes
  useEffect(() => {
    if (!authInitialized) return;
    
    // Handle session changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, currentSession) => {
        console.log('Auth state changed:', event);
        
        // Handle token refresh errors
        if (event === 'TOKEN_REFRESHED' && !currentSession) {
          console.warn('Token refresh failed');
          clearAllAuthData();
          setAuthError('Session expired. Please sign in again.');
          setIsLoading(false);
          return;
        }
        
        // Handle sign out event explicitly
        if (event === 'SIGNED_OUT') {
          console.log('User signed out');
          clearAllAuthData();
          setIsLoading(false);
          return;
        }
        
        setSession(currentSession);
        setCurrentUser(currentSession?.user ?? null);
        
        if (currentSession?.user) {
          // Flag to track if this is a new user signing up with email (not OAuth)
          const isEmailSignUp = sessionStorage.getItem('emailSignUp') === 'true';
          
          // Store user email in localStorage for API calls
          if (currentSession.user.email) {
            localStorage.setItem('userEmail', currentSession.user.email);
          }
          
          const profile = await fetchUserProfile(currentSession.user);
          setUserProfile(profile);
          
          // Remove the email signup flag immediately after processing
          if (isEmailSignUp) {
            sessionStorage.removeItem('emailSignUp');
          }
        } else {
          setUserProfile(null);
          setIsAdmin(false);
          setUserRoles([]);
          setUserPermissions([]);
        }
        
        setIsLoading(false);
      }
    );
    
    // Cleanup
    return () => {
      subscription.unsubscribe();
    };
  }, [authInitialized]);

  // Sign out function
  const signOut = async () => {
    try {
      // First clear all local auth data
      clearAllAuthData();
      
      // Then sign out from Supabase
      const { error } = await supabase.auth.signOut();
      
      if (error) {
        console.error('Error signing out from Supabase:', error);
      }
      
      // Force a page reload to ensure all state is reset
      window.location.href = '/';
    } catch (error) {
      console.error('Error signing out:', error);
      // Still try to redirect even if there's an error
      window.location.href = '/';
    }
  };

  // Update user profile
  const updateUserProfile = async (data: Partial<UserData>): Promise<boolean> => {
    if (!currentUser) return false;
    
    try {
      const success = await updateProfileInDb(currentUser.id, data);
      
      if (success) {
        // Update local state
        setUserProfile((prevProfile: UserData | null) => {
          if (!prevProfile) return null;
          return { ...prevProfile, ...data };
        });
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('Error updating user profile:', error);
      setNetworkError(true);
      return false;
    }
  };

  // Check if user has a specific permission
  const hasPermission = (permission: string, resourceType?: string, resourceId?: string): boolean => {
    if (isAdmin) return true;
    
    // Check if user has the exact permission
    return userPermissions.some(p => 
      p.name === permission && 
      (!resourceType || p.resourceType === resourceType) && 
      (!resourceId || p.resourceId === resourceId)
    );
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        session,
        isLoading,
        isAdmin,
        userProfile,
        userRoles,
        userPermissions,
        signOut,
        updateUserProfile,
        hasPermission,
        networkError,
        authError
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};