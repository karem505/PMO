import React, { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from './AuthContext';
import { supabase } from '../../services/supabaseClient';
import Logo from '../Logo';
import apiClient from '../../api/client';
import LoadingScreen from '../common/LoadingScreen';

const AuthCallback: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { currentUser, isLoading } = useAuth();
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string>("Processing authentication...");
  const [setupAttempted, setSetupAttempted] = useState(false);

  useEffect(() => {
    const handleCallback = async () => {
      try {
        // Parse the URL to check for error params
        const params = new URLSearchParams(location.search);
        const errorParam = params.get('error');
        const errorCode = params.get('error_code');
        const errorDescription = params.get('error_description');
        
        if (errorParam) {
          console.error('OAuth error:', errorParam, errorDescription);
          
          // Handle database error during user creation
          if (errorCode === 'unexpected_failure' && errorDescription?.includes('Database error')) {
            try {
              // Get the session to see if we have a valid user despite the error
              const { data: { session }, error: sessionError } = await supabase.auth.getSession();
              
              if (session?.user) {
                console.log('Found valid session despite error, attempting recovery...');
                
                // First check if profile already exists
                const { data: existingProfile } = await supabase
                  .from('profiles')
                  .select('id')
                  .eq('id', session.user.id)
                  .single();
                
                if (!existingProfile) {
                  // Try to create the user profile directly
                  const { error: profileError } = await supabase
                    .from('profiles')
                    .insert([{
                      id: session.user.id,
                      email: session.user.email,
                      display_name: session.user.user_metadata?.full_name || session.user.email?.split('@')[0],
                      photo_url: session.user.user_metadata?.avatar_url,
                      created_at: new Date().toISOString(),
                      organization_name: "",
                      industry: "",
                      pmo_maturity_level: "Initial"
                    }]);
                  
                  if (!profileError) {
                    console.log('Successfully recovered from database error');
                    // Set up free subscription
                    if (session.user.email) {
                      localStorage.setItem('userEmail', session.user.email);
                      await apiClient.post('/subscription/setup-free', {
                        user_email: session.user.email
                      });
                    }
                    // Redirect to dashboard since we recovered
                    navigate('/dashboard');
                    return;
                  }
                } else {
                  console.log('Profile already exists, redirecting to dashboard');
                  navigate('/dashboard');
                  return;
                }
              }
            } catch (recoveryError) {
              console.error('Recovery attempt failed:', recoveryError);
            }
            
            setError("There was an issue setting up your account. This might be because:\n" +
                    "• A profile already exists for this email\n" +
                    "• There was a temporary database connection issue\n\n" +
                    "Please try signing in instead, or contact support if the issue persists.");
          } else if (errorCode === 'bad_oauth_state') {
            setError(
              "Authentication failed due to invalid state. This typically happens if you've opened multiple sign-in tabs or " +
              "your browser is blocking third-party cookies. Please try:\n\n" +
              "1. Close all other tabs/windows of this site\n" +
              "2. Use a private/incognito window\n" +
              "3. Ensure third-party cookies are not blocked in your browser"
            );
          } else {
            setError(`Authentication error: ${errorDescription || errorParam}`);
          }
          
          // Clean up session storage
          sessionStorage.removeItem('newUserSignup');
          localStorage.removeItem('supabase_oauth_state');
          
          // Redirect to login after a delay
          setTimeout(() => {
            navigate('/login');
          }, 5000);
          return;
        }

        // Get the session to see if authentication was successful
        const { data: { session }, error: sessionError } = await supabase.auth.getSession();
        
        if (sessionError) {
          throw sessionError;
        }
        
        if (!session) {
          throw new Error("No session found after authentication");
        }

        // Set the auth token for subsequent API calls
        apiClient.defaults.headers.common['Authorization'] = `Bearer ${session.access_token}`;
        
        // Check if this is a new user by checking the newUserSignup flag
        const isNewUser = sessionStorage.getItem('newUserSignup') === 'true';
        
        if (isNewUser && !setupAttempted) {
          setMessage("Setting up your account...");
          setSetupAttempted(true);
          
          try {
            console.log('Starting user setup for:', session.user.id);
            
            // Call backend to handle user setup
            const response = await apiClient.post('/auth/setup-user', {
              user_id: session.user.id,
              email: session.user.email,
              display_name: session.user.user_metadata?.full_name,
              photo_url: session.user.user_metadata?.avatar_url,
              team_code: sessionStorage.getItem('team_code')
            });
            
            console.log('User setup response:', response.data);
            
            if (response.data.status !== 'success') {
              throw new Error(response.data.message || 'User setup failed');
            }
            
            // Set up free subscription using existing endpoint
            const subscriptionResponse = await apiClient.post('/subscription/setup-free', {
              user_email: session.user.email
            });
            
            console.log('Subscription setup response:', subscriptionResponse.data);
            
          } catch (setupError: any) {
            console.error('Error setting up user:', setupError.response?.data || setupError);
            throw new Error(
              setupError.response?.data?.detail || 
              setupError.message || 
              'Failed to complete account setup. Please try again or contact support.'
            );
          }
        } else {
          console.log('Existing user detected or setup already attempted, skipping setup');
        }
        
        // Clean up session storage
        sessionStorage.removeItem('newUserSignup');
        sessionStorage.removeItem('team_code');
        localStorage.removeItem('supabase_oauth_state');
        
        // Redirect to dashboard
        setMessage("Authentication successful! Redirecting to dashboard...");
        navigate('/dashboard');
        
      } catch (error: any) {
        console.error('Error in auth callback:', error);
        setError(error.message || 'Authentication failed');
        
        // Clean up on error
        sessionStorage.removeItem('newUserSignup');
        sessionStorage.removeItem('team_code');
        localStorage.removeItem('supabase_oauth_state');
        delete apiClient.defaults.headers.common['Authorization'];
        
        // Redirect to login after a delay
        setTimeout(() => {
          navigate('/login');
        }, 5000);
      }
    };
    
    handleCallback();
  }, [navigate, location, setupAttempted]);

  useEffect(() => {
    const setupNewUser = async () => {
      try {
        const newUserSignup = sessionStorage.getItem('newUserSignup');
        if (!newUserSignup || !currentUser) return;

        // Setup user account
        const { error: setupError } = await supabase.functions.invoke('auth-setup-user', {
          body: { email: currentUser.email },
        });

        if (setupError) {
          console.error('Error setting up user:', setupError);
          setError('Failed to set up user account');
          return;
        }

        // Setup free subscription
        if (!currentUser.email) {
          setError('User email not found');
          return;
        }

        // Store email in localStorage for API calls
        localStorage.setItem('userEmail', currentUser.email);
        
        // Setup subscription via API
        await apiClient.post('/subscription/setup-free', {
          user_email: currentUser.email
        });

        // Clear the new user flag
        sessionStorage.removeItem('newUserSignup');

        // Get redirect path or default to dashboard
        const redirectPath = localStorage.getItem('redirectAfterLogin') || '/dashboard';
        localStorage.removeItem('redirectAfterLogin');
        navigate(redirectPath);
      } catch (err: any) {
        console.error('Error in setup process:', err);
        setError(err.message || 'An unexpected error occurred');
      }
    };

    if (currentUser && !isLoading) {
      setupNewUser();
    }
  }, [currentUser, isLoading, navigate]);

  if (error) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gray-50">
        <div className="w-full max-w-md">
          <div className="bg-white px-8 py-10 shadow-md rounded-lg text-center">
            <div className="mb-6">
              <Logo variant="auth" />
            </div>
            
            <div className="animate-pulse rounded-full h-12 w-12 bg-red-100 mx-auto flex items-center justify-center">
              <span className="text-red-500 text-xl">!</span>
            </div>
            <h2 className="mt-4 text-xl font-semibold text-red-600">Authentication Error</h2>
            <div className="mt-2 text-sm text-gray-600 whitespace-pre-line">{error}</div>
            <p className="mt-4 text-sm text-gray-500">Redirecting to login page...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-50">
      <div className="w-full max-w-md">
        <div className="bg-white px-8 py-10 shadow-md rounded-lg text-center">
          <div className="mb-6">
            <Logo variant="auth" />
          </div>
          
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-800 font-medium">{message}</p>
        </div>
      </div>
    </div>
  );
};

export default AuthCallback; 