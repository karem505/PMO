import React, { useState, useEffect } from 'react';
import { useAppStore } from '../store';
import { domains } from '../data';
import { 
  Calendar, 
  ChevronLeft, 
  ChevronRight, 
  Edit, 
  Save, 
  X, 
  Plus, 
  Trash2, 
  MoreHorizontal,
  Check,
  Ban,
  CalendarDays
} from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useToast } from '../hooks/useToast';

interface GanttChartProps {
  projectId?: string;
  editable?: boolean;
  className?: string;
}

interface TaskItem {
  id: string;
  title: string;
  domain: number;
  start: Date;
  end: Date;
  progress: number;
  color?: string;
  dependencies?: string[];
  isEditing?: boolean;
}

const GanttChart: React.FC<GanttChartProps> = ({ 
  projectId, 
  editable = true,
  className = '' 
}): JSX.Element => {
  const { getActiveProject, getDomainProgress } = useAppStore();
  const activeProject = getActiveProject();
  const { t } = useLanguage();
  const toast = useToast();
  // Default date ranges based on project
  const defaultStartDate = activeProject?.startDate 
    ? new Date(activeProject.startDate) 
    : new Date();
  const defaultEndDate = activeProject?.endDate 
    ? new Date(activeProject.endDate) 
    : new Date(new Date().setMonth(new Date().getMonth() + 6));
  
  // State for chart configuration
  const [chartStartDate, setChartStartDate] = useState<Date>(defaultStartDate);
  const [chartEndDate, setChartEndDate] = useState<Date>(defaultEndDate);
  const [zoomLevel, setZoomLevel] = useState<'day' | 'week' | 'month'>('week');
  const [tasks, setTasks] = useState<TaskItem[]>([]);
  const [editingTask, setEditingTask] = useState<string | null>(null);
  const [showDetails, setShowDetails] = useState<string | null>(null);
  const [editFormData, setEditFormData] = useState<Partial<TaskItem>>({});
  const [showAddTask, setShowAddTask] = useState(false);
  
  // Calculate total days in the chart range
  const totalDays = Math.ceil((chartEndDate.getTime() - chartStartDate.getTime()) / (24 * 60 * 60 * 1000));
  
  // Generate calendar headers based on zoom level
  const calendarHeaders = React.useMemo(() => {
    const headers = [];
    const currentDate = new Date(chartStartDate);
    
    switch (zoomLevel) {
      case 'day':
        for (let i = 0; i < totalDays; i++) {
          headers.push({
            label: currentDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
            date: new Date(currentDate)
          });
          currentDate.setDate(currentDate.getDate() + 1);
        }
        break;
      case 'week':
        // Group by weeks
        let currentWeekStart = new Date(currentDate);
        currentWeekStart.setDate(currentWeekStart.getDate() - currentWeekStart.getDay()); // Start from Sunday
        
        while (currentWeekStart < chartEndDate) {
          const weekEndDate = new Date(currentWeekStart);
          weekEndDate.setDate(weekEndDate.getDate() + 6); // End on Saturday
          
          headers.push({
            label: `${currentWeekStart.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - ${weekEndDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}`,
            date: new Date(currentWeekStart),
            endDate: weekEndDate
          });
          
          currentWeekStart.setDate(currentWeekStart.getDate() + 7); // Move to next week
        }
        break;
      case 'month':
        // Group by months
        while (currentDate < chartEndDate) {
          const monthName = currentDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
          
          // Calculate month end
          const monthEndDate = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
          
          headers.push({
            label: monthName,
            date: new Date(currentDate),
            endDate: monthEndDate
          });
          
          // Move to next month
          currentDate.setMonth(currentDate.getMonth() + 1);
        }
        break;
    }
    
    return headers;
  }, [chartStartDate, chartEndDate, totalDays, zoomLevel]);
  
  // Initialize tasks based on domains when component mounts
  useEffect(() => {
    if (domains && domains.length > 0) {
      // Sort domains by their ID for consistent ordering
      const sortedDomains = [...domains].sort((a, b) => a.id - b.id);
      
      // Calculate duration for each domain based on project length
      const projectDurationDays = totalDays;
      const daysPerDomain = Math.floor(projectDurationDays / sortedDomains.length);
      
      // Create task items for each domain
      const domainTasks: TaskItem[] = sortedDomains.map((domain, index) => {
        // Get domain progress
        const progress = getDomainProgress(domain.id);
        
        // Calculate start and end dates
        const startOffset = index * daysPerDomain;
        const start = new Date(chartStartDate);
        start.setDate(start.getDate() + startOffset);
        
        const end = new Date(start);
        end.setDate(end.getDate() + daysPerDomain);
        
        // Assign a color based on domain
        const colors = [
          '#3B82F6', // blue
          '#8B5CF6', // purple  
          '#EC4899', // pink
          '#10B981', // green
          '#F59E0B', // amber
          '#6366F1', // indigo
        ];
        
        return {
          id: `domain-${domain.id}`,
          title: t(`domains.${domain.id}.name`, domain.name),
          domain: domain.id,
          start,
          end,
          progress: Math.round(progress.overallProgress), // Convert to percentage
          color: colors[index % colors.length]
        };
      });
      
      setTasks(domainTasks);
    }
  }, [chartStartDate, chartEndDate, totalDays]);
  
  // Calculate position and size for a task bar
  const getTaskPosition = (task: TaskItem) => {
    const startTime = task.start.getTime();
    const endTime = task.end.getTime();
    const chartStartTime = chartStartDate.getTime();
    const chartEndTime = chartEndDate.getTime();
    
    const chartDuration = chartEndTime - chartStartTime;
    
    // Calculate start and end positions as percentages
    const startPercent = Math.max(0, ((startTime - chartStartTime) / chartDuration) * 100);
    const endPercent = Math.min(100, ((endTime - chartStartTime) / chartDuration) * 100);
    
    // Calculate width
    const width = Math.max(0, endPercent - startPercent);
    
    return {
      left: `${startPercent}%`,
      width: `${width}%`
    };
  };
  
  // Handle task edit form submission
  const handleTaskSubmit = (taskId: string) => {
    if (!editFormData.title || !editFormData.start || !editFormData.end) {
      toast.error(t('ganttChart.provideAllRequiredInformation', "Please provide all required information"));
      return;
    }
    
    // Update task in state
    setTasks(prevTasks => 
      prevTasks.map(task => 
        task.id === taskId 
          ? { 
              ...task, 
              ...editFormData,
              // Ensure progress is a number
              progress: typeof editFormData.progress === 'number' 
                ? editFormData.progress 
                : task.progress
            } 
          : task
      )
    );
    
    // Clear editing state
    setEditingTask(null);
    setEditFormData({});
  };
  
  // Handle adding a new task
  const handleAddTask = () => {
    if (!editFormData.title || !editFormData.start || !editFormData.end || editFormData.domain === undefined) {
      toast.error(t('ganttChart.provideAllRequiredInformationForNewTask', "Please provide all required information for the new task"));
      return;
    }
    
    // Create a new task
    const newTask: TaskItem = {
      id: `task-${Date.now()}`,
      title: editFormData.title as string,
      domain: editFormData.domain as number,
      start: editFormData.start as Date,
      end: editFormData.end as Date,
      progress: editFormData.progress as number || 0,
      color: editFormData.color as string || '#3B82F6',
      dependencies: editFormData.dependencies || []
    };
    
    // Add to tasks
    setTasks(prevTasks => [...prevTasks, newTask]);
    
    // Reset form
    setShowAddTask(false);
    setEditFormData({});
  };
  
  // Format date for input fields
  const formatDateForInput = (date: Date) => {
    return date.toISOString().split('T')[0];
  };
  
  // Change time scale
  const changeTimeScale = (scale: 'day' | 'week' | 'month') => {
    setZoomLevel(scale);
  };

  return (
    <div className={`bg-white rounded-lg shadow-sm border border-gray-200 ${className}`}>
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-medium text-gray-800 flex items-center">
            <Calendar className="h-5 w-5 me-2 text-primary-600" />
            {t('ganttChart.projectTimeline', 'Project Timeline')}
          </h3>
          
          {/* Controls */}
          <div className="flex items-center gap-x-4">
            <div className="flex items-center gap-x-1 bg-gray-100 rounded-md p-1">
              <button 
                onClick={() => changeTimeScale('day')}
                className={`px-3 py-1 rounded text-xs ${zoomLevel === 'day' ? 'bg-white shadow-sm text-primary-700' : 'text-gray-700'}`}
              >
                {t('ganttChart.day', 'Day')}
              </button>
              <button 
                onClick={() => changeTimeScale('week')}
                className={`px-3 py-1 rounded text-xs ${zoomLevel === 'week' ? 'bg-white shadow-sm text-primary-700' : 'text-gray-700'}`}
              >
                {t('ganttChart.week', 'Week')}
              </button>
              <button 
                onClick={() => changeTimeScale('month')}
                className={`px-3 py-1 rounded text-xs ${zoomLevel === 'month' ? 'bg-white shadow-sm text-primary-700' : 'text-gray-700'}`}
              >
                {t('ganttChart.month', 'Month')}
              </button>
            </div>
            
            <div className="flex items-center gap-x-1">
              <button 
                onClick={() => {
                  // Move back by different amounts based on zoom level
                  const newStartDate = new Date(chartStartDate);
                  const newEndDate = new Date(chartEndDate);
                  
                  if (zoomLevel === 'day') {
                    newStartDate.setDate(newStartDate.getDate() - 7);
                    newEndDate.setDate(newEndDate.getDate() - 7);
                  } else if (zoomLevel === 'week') {
                    newStartDate.setDate(newStartDate.getDate() - 14);
                    newEndDate.setDate(newEndDate.getDate() - 14);
                  } else {
                    newStartDate.setMonth(newStartDate.getMonth() - 1);
                    newEndDate.setMonth(newEndDate.getMonth() - 1);
                  }
                  
                  setChartStartDate(newStartDate);
                  setChartEndDate(newEndDate);
                }}
                className="p-1 rounded hover:bg-gray-100"
              >
                <ChevronLeft className="h-5 w-5 text-gray-500" />
              </button>
              
              <button 
                onClick={() => {
                  // Move forward by different amounts based on zoom level
                  const newStartDate = new Date(chartStartDate);
                  const newEndDate = new Date(chartEndDate);
                  
                  if (zoomLevel === 'day') {
                    newStartDate.setDate(newStartDate.getDate() + 7);
                    newEndDate.setDate(newEndDate.getDate() + 7);
                  } else if (zoomLevel === 'week') {
                    newStartDate.setDate(newStartDate.getDate() + 14);
                    newEndDate.setDate(newEndDate.getDate() + 14);
                  } else {
                    newStartDate.setMonth(newStartDate.getMonth() + 1);
                    newEndDate.setMonth(newEndDate.getMonth() + 1);
                  }
                  
                  setChartStartDate(newStartDate);
                  setChartEndDate(newEndDate);
                }}
                className="p-1 rounded hover:bg-gray-100"
              >
                <ChevronRight className="h-5 w-5 text-gray-500" />
              </button>
            </div>
          </div>
        </div>
        
        {/* Date Range Display */}
        <div className="mt-2 text-sm text-gray-500 flex items-center">
          <CalendarDays className="h-4 w-4 me-1 text-gray-400" />
          {chartStartDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })} 
          {' - '} 
          {chartEndDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
        </div>
      </div>
      
      <div className="overflow-x-auto">
        <div className="min-w-[800px]">
          {/* Header Row - Time Scale */}
          <div className="flex border-b border-gray-200">
            {/* Task Column */}
            <div className="w-64 flex-shrink-0 p-3 bg-gray-50 border-r border-gray-200">
              <h4 className="text-sm font-medium text-gray-700">Domain / Task</h4>
            </div>
            
            {/* Time Scale */}
            <div className="flex-1 flex">
              {calendarHeaders.map((header, index) => (
                <div 
                  key={index} 
                  className="flex-1 p-2 text-center text-xs text-gray-600 font-medium border-r border-gray-100"
                  style={{ 
                    minWidth: zoomLevel === 'day' ? '80px' : 
                             zoomLevel === 'week' ? '120px' : '160px' 
                  }}
                >
                  {header.label}
                </div>
              ))}
            </div>
          </div>
          
          {/* Task Rows */}
          <div className="relative">
            {tasks.map((task, taskIndex) => (
              <div 
                key={task.id}
                className="flex hover:bg-gray-50 border-b border-gray-100"
              >
                {/* Task Name */}
                <div 
                  className="w-64 flex-shrink-0 p-3 border-r border-gray-100 flex items-center justify-between cursor-pointer"
                  onClick={() => setShowDetails(showDetails === task.id ? null : task.id)}
                >
                  <div className="flex items-center">
                    <div 
                      className="w-3 h-3 rounded-full me-2" 
                      style={{ backgroundColor: task.color || '#3B82F6' }}
                    ></div>
                    <span className="text-sm font-medium text-gray-700 truncate">
                      {task.title}
                    </span>
                  </div>
                  
                </div>
                
                {/* Gantt Bar Container */}
                <div className="flex-1 relative h-12">
                  {/* Gantt Bar */}
                  <div 
                    className="absolute top-1/2 transform -translate-y-1/2 h-6 rounded-md shadow-sm flex items-center px-2 cursor-pointer"
                    style={{ 
                      ...getTaskPosition(task),
                      backgroundColor: task.color || '#3B82F6'
                    }}
                    onClick={() => setShowDetails(showDetails === task.id ? null : task.id)}
                  >
                    {/* Progress Bar */}
                    <div 
                      className="absolute top-0 left-0 h-full bg-white bg-opacity-20 rounded-l-md"
                      style={{ width: `${task.progress}%` }}
                    ></div>
                    
                    {/* Task Title on Bar */}
                    <span className="text-xs text-white font-medium z-10 truncate">
                      {task.progress}%
                    </span>
                  </div>
                </div>
              </div>
            ))}
            
            {/* Today's Date Line */}
            {(() => {
              const today = new Date();
              const chartStartTime = chartStartDate.getTime();
              const chartEndTime = chartEndDate.getTime();
              
              // Only show if today is within the chart range
              if (today >= chartStartDate && today <= chartEndDate) {
                const chartDuration = chartEndTime - chartStartTime;
                const todayPosition = ((today.getTime() - chartStartTime) / chartDuration) * 100;
                
                return (
                  <div 
                    className="absolute top-0 h-full border-l-2 border-red-500 z-10"
                    style={{ left: `calc(${todayPosition}% + 256px)` }}
                  >
                    <div className="absolute -top-6 -left-[30px] bg-red-500 text-white px-2 py-0.5 rounded text-xs whitespace-nowrap">
                      {t('ganttChart.today', 'Today')}
                    </div>
                  </div>
                );
              }
              
              return null;
            })()}
          </div>
        </div>
      </div>

      {/* Task Details Panel */}
      {showDetails && tasks.find(t => t.id === showDetails) && (
        <div className="border-t border-gray-200 p-4">
          {(() => {
            const task = tasks.find(t => t.id === showDetails);
            if (!task) return null;
            
            return (
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-medium text-gray-800 flex items-center">
                    <div 
                      className="w-3 h-3 rounded-full me-2" 
                      style={{ backgroundColor: task.color || '#3B82F6' }}
                    ></div>
                    {task.title}
                  </h3>
                  
                  {editable && (
                    <div className="flex items-center gap-x-2">
                      <button
                        onClick={() => {
                          setEditingTask(task.id);
                          setEditFormData({
                            title: task.title,
                            start: task.start,
                            end: task.end,
                            progress: task.progress,
                            color: task.color,
                            domain: task.domain,
                            dependencies: task.dependencies
                          });
                        }}
                        className="text-blue-600 hover:text-blue-800 text-sm flex items-center"
                      >

                      </button>
      
                      <button 
                        onClick={() => setShowDetails(null)}
                        className="text-gray-500 hover:text-gray-700"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                  )}
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-3 bg-gray-50 rounded-md">
                    <h4 className="text-xs text-gray-500 mb-1">{t('ganttChart.timeline', 'Timeline')}</h4>
                    <p className="text-sm text-gray-800">
                      {task.start.toLocaleDateString()} - {task.end.toLocaleDateString()}
                    </p>
                  </div>
                  
                  <div className="p-3 bg-gray-50 rounded-md">
                    <h4 className="text-xs text-gray-500 mb-1">{t('ganttChart.progress', 'Progress')}</h4>
                    <div className="flex items-center">
                      <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                        <div 
                          className="h-full rounded-full" 
                          style={{ 
                            width: `${task.progress}%`,
                            backgroundColor: task.color 
                          }}
                        ></div>
                      </div>
                      <span className="ms-2 text-sm font-medium text-gray-700">
                        {task.progress}%
                      </span>
                    </div>
                  </div>
                  
                  <div className="p-3 bg-gray-50 rounded-md">
                    <h4 className="text-xs text-gray-500 mb-1">{t('ganttChart.domain', 'Domain')}</h4>
                    <p className="text-sm text-gray-800">
                      {t(`domains.${domains.find(d => d.id === task.domain)?.id}.name`, domains.find(d => d.id === task.domain)?.name) || t('ganttChart.unknownDomain', 'Unknown Domain')}
                    </p>
                  </div>
                </div>
                
                {task.dependencies && task.dependencies.length > 0 && (
                  <div className="mt-4">
                    <h4 className="text-sm font-medium text-gray-700 mb-2">{t('ganttChart.dependencies', 'Dependencies')}</h4>
                    <div className="flex flex-wrap gap-2">
                      {task.dependencies.map(depId => {
                        const depTask = tasks.find(t => t.id === depId);
                        return depTask ? (
                          <div 
                            key={depId} 
                            className="px-2 py-1 bg-gray-100 text-xs rounded-md flex items-center"
                            style={{ borderLeft: `3px solid ${depTask.color || '#3B82F6'}` }}
                          >
                            {depTask.title}
                          </div>
                        ) : null;
                      })}
                    </div>
                  </div>
                )}
              </div>
            );
          })()}
        </div>
      )}
      
      {/* Legend */}
      <div className="p-4 border-t border-gray-200">
        <h4 className="text-xs text-gray-500 mb-2">{t('ganttChart.legend', 'Legend')}</h4>
        <div className="flex flex-wrap gap-4">
          {tasks.map(task => (
            <div key={task.id} className="flex items-center">
              <div 
                className="w-3 h-3 rounded-full me-1" 
                style={{ backgroundColor: task.color || '#3B82F6' }}
              ></div>
              <span className="text-xs text-gray-700">{task.title}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default GanttChart;