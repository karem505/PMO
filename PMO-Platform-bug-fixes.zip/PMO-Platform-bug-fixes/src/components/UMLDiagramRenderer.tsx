import React, { useEffect, useRef, useState } from 'react';
import { Loader2, AlertCircle, Download } from 'lucide-react';
import html2canvas from 'html2canvas';

interface UMLDiagramRendererProps {
  diagramCode: string;
  title: string;
  onError?: (error: string) => void;
}

const UMLDiagramRenderer: React.FC<UMLDiagramRendererProps> = ({ 
  diagramCode, 
  title,
  onError 
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isRendering, setIsRendering] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const renderUml = async () => {
      setIsRendering(true);
      setError(null);
      
      if (!containerRef.current) return;
      
      try {
        // Load the UML rendering script dynamically
        const script = document.createElement('script');
        script.src = 'https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js';
        script.async = true;
        document.body.appendChild(script);
        
        // Wait for script to load and initialize
        script.onload = async () => {
          try {
            // Access the global mermaid object
            const mermaid = (window as any).mermaid;
            
            // Configure mermaid
            mermaid.initialize({
              startOnLoad: false,
              theme: 'neutral',
              securityLevel: 'loose',
              fontFamily: 'Inter, sans-serif',
              fontSize: 16,
              flowchart: {
                useMaxWidth: true,
                htmlLabels: true,
                curve: 'basis'
              }
            });
            
            // Remove existing content
            containerRef.current!.innerHTML = '';
            
            // Create a new div for the diagram
            const diagramDiv = document.createElement('div');
            diagramDiv.className = 'mermaid';
            diagramDiv.textContent = diagramCode;
            containerRef.current!.appendChild(diagramDiv);
            
            // Render the diagram
            await mermaid.run();
            setIsRendering(false);
          } catch (err) {
            console.error('Error rendering UML diagram:', err);
            setError('Failed to render diagram. The diagram code may be invalid.');
            if (onError) onError('Render error: ' + String(err));
            setIsRendering(false);
          }
        };
        
        script.onerror = () => {
          setError('Failed to load diagram rendering library.');
          if (onError) onError('Script loading error');
          setIsRendering(false);
        };
        
      } catch (err) {
        console.error('Error in UML rendering setup:', err);
        setError('Failed to set up diagram rendering.');
        if (onError) onError('Setup error: ' + String(err));
        setIsRendering(false);
      }
    };
    
    renderUml();
    
    // Cleanup function
    return () => {
      // Remove any script tags or other artifacts if needed
    };
  }, [diagramCode, onError]);

  const handleExport = async () => {
    if (!containerRef.current) return;
    
    try {
      const svg = containerRef.current.querySelector('svg');
      if (!svg) throw new Error('No SVG element found');
      
      // Use html2canvas to create an image
      const canvas = await html2canvas(containerRef.current);
      const imageUrl = canvas.toDataURL('image/png');
      
      // Create download link
      const link = document.createElement('a');
      link.href = imageUrl;
      link.download = `${title.replace(/\s+/g, '-').toLowerCase()}.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
    } catch (err) {
      console.error('Error exporting diagram:', err);
      setError('Failed to export diagram as image');
      if (onError) onError('Export error: ' + String(err));
    }
  };

  return (
    <div className="bg-white border border-gray-200 rounded-lg">
      {isRendering ? (
        <div className="flex flex-col items-center justify-center p-8">
          <Loader2 className="h-8 w-8 text-blue-500 animate-spin mb-4" />
          <p className="text-gray-600">Rendering diagram...</p>
        </div>
      ) : error ? (
        <div className="p-6 text-center">
          <AlertCircle className="h-10 w-10 text-red-500 mx-auto mb-4" />
          <p className="text-red-600 font-medium mb-2">Error rendering diagram</p>
          <p className="text-gray-600">{error}</p>
        </div>
      ) : (
        <div className="p-4">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-medium text-gray-800">{title}</h3>
            <button
              onClick={handleExport}
              className="px-3 py-1.5 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 flex items-center text-sm"
            >
              <Download className="h-4 w-4 mr-1.5" />
              Export Image
            </button>
          </div>
          <div 
            ref={containerRef} 
            className="overflow-auto max-h-[500px]" 
          />
        </div>
      )}
    </div>
  );
};

export default UMLDiagramRenderer;