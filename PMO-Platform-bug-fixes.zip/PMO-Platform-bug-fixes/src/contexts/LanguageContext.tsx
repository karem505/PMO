import React, { createContext, useContext, useState, useEffect } from 'react';
import { translations } from '../translations';
import { useAuth } from '../components/auth/AuthContext';
type Language = 'en' | 'ar';

type LanguageContextType = {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string, defaultValue?: string) => string;
  isRTL: boolean;
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Check for saved language preference or browser language
  const [language, setLanguageState] = useState<Language>(() => {
    const savedLanguage = localStorage.getItem('locale');
    if (savedLanguage === 'ar' || savedLanguage === 'en') {
      return savedLanguage;
    }
    // Check browser language
    const browserLang = navigator.language.split('-')[0];
    return browserLang === 'ar' ? 'ar' : 'en';
  });
  // RTL detection
  const isRTL = language === 'ar';

  // Apply RTL attribute to document
  useEffect(() => {
    document.documentElement.dir = isRTL ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
    document.body.classList.toggle('rtl', isRTL);
    
    // Force a re-render of all components to apply RTL properly
    const html = document.documentElement;
    html.style.display = 'none';
    // Force reflow
    html.offsetHeight;
    html.style.display = '';
    
    // Save preference to localStorage
    localStorage.setItem('locale', language);
  }, [language, isRTL]);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
  };

  // Translation function
  const t = (key: string, defaultValue?: string): string => {
    const keys = key.split('.');
    let result = translations[language];
    
    for (const k of keys) {
      if (result && typeof result === 'object' && k in result) {
        result = result[k];
      } else {
        // Fallback to English if key not found
        if (language !== 'en') {
          let englishResult = translations['en'];
          for (const englishKey of keys) {
            if (englishResult && typeof englishResult === 'object' && englishKey in englishResult) {
              englishResult = englishResult[englishKey];
            } else {
              // Return the default value or the key if not found in English either
              return defaultValue || key;
            }
          }
          return typeof englishResult === 'string' ? englishResult : defaultValue || key;
        }
        return defaultValue || key; // Return the default value or the key if not found
      }
    }
    
    return typeof result === 'string' ? result : defaultValue || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, isRTL }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};