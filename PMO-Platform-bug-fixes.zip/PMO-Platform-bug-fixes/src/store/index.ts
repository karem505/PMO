import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { UserData, TaskData, DomainProgress, DomainInput, DomainOutput, GeneratedTemplate, Project, ProcessedDocument } from '../types';
import { domains, tasks } from '../data';
import { openaiService } from '../services/openaiService';
import { v4 as uuidv4 } from 'uuid';
import { 
  getProjects as fetchProjects,
  createProject as createProjectInDb,
  updateProject as updateProjectInDb,
  deleteProject as deleteProjectInDb,
  getDomainInputs,
  saveDomainInput,
  getDomainOutputs,
  saveDomainOutput,
  getTasks as fetchTasks,
  saveTask,
  getCurrentUser,
  getCurrentSession
} from '../services/supabaseService';
import { supabase } from '../services/supabaseClient';
import axios from 'axios';
import apiClient from '../api/client';

interface AppState {
  userData: UserData;
  currentDomain: number | null;
  isAnalyzing: boolean;
  processedDocuments: ProcessedDocument[];
  connectionError: boolean;
  showConnectionErrors: boolean;
  updateUserProfile: (data: Partial<UserData>) => void;
  updateTaskData: (taskId: string, data: Partial<TaskData>) => void;
  setTaskCompleted: (taskId: string, completed: boolean) => void;
  setCurrentDomain: (domainId: number | null) => void;
  getDomainProgress: (domainId: number) => DomainProgress;
  getOverallProgress: () => number;
  updateDomainInput: (domainId: number, content: string) => Promise<void>;
  getDomainInput: (domainId: number) => DomainInput | null;
  analyzeDomainInput: (domainId: number) => Promise<void>;
  getDomainOutput: (domainId: number) => DomainOutput | null;
  getPreviousDomainId: (domainId: number) => number | null;
  exportUserData: () => Promise<string>;
  importUserData: (data: any) => Promise<void>;
  resetUserData: () => Promise<void>;
  createProject: (project: Partial<Project>) => Promise<string>;
  updateProject: (projectId: string, projectData: Partial<Project>) => Promise<void>;
  deleteProject: (projectId: string) => Promise<void>;
  getProjects: () => Project[];
  getProject: (projectId: string) => Project | undefined;
  setActiveProject: (projectId: string) => void;
  getActiveProject: () => Project | undefined;
  getActiveProjectId: () => string | undefined;
  fetchProjectsFromDb: () => Promise<void>;
  syncWithSupabase: (shouldReload?: boolean) => Promise<boolean>;
  addProcessedDocument: (document: ProcessedDocument) => void;
  getDocumentsForDomain: (domainId: number) => ProcessedDocument[];
  setConnectionError: (hasError: boolean) => void;
  setShowConnectionErrors: (show: boolean) => void;
}

// Initialize empty task data structure
const initializeTaskData = () => {
  const taskData: Record<string, TaskData> = {};
  tasks.forEach(task => {
    taskData[task.id] = {
      completed: false,
      notes: '',
      attachments: [],
      customFields: {}
    };
  });
  return taskData;
};

// Default user data state
const getDefaultUserData = (): UserData => {
  // Initialize with placeholder project data
  // A real project will be created asynchronously via API
  return {
    organizationName: '',
    industry: '',
    pmoMaturityLevel: 'Initial',
    tasks: initializeTaskData(),
    domainInputs: {},
    generatedOutputs: {},
    projects: [],
    activeProjectId: ''
  };
};

// Create a default project via API
const createDefaultProject = async () => {
  try {
    // Get the current user if available
    let owner_id = '';
    try {
      const user = await getCurrentUser();
      if (user) {
        owner_id = user.id;
      }
    } catch (error) {
      console.warn('User not logged in, creating anonymous project');
    }
    
    // Default project data
    const defaultProjectData = {
      name: "Default PMO Implementation",
      description: "Initial PMO implementation project",
      budget: 450000,
      owner_id
    };
    
    // Create project using the API
    const projectId = await useAppStore.getState().createProject(defaultProjectData);
    return projectId;
  } catch (error) {
    console.error('Error creating default project:', error);
    // Fallback to a local project if API fails
    return null;
  }
};

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      userData: getDefaultUserData(),
      currentDomain: null,
      isAnalyzing: false,
      processedDocuments: [],
      connectionError: false,
      showConnectionErrors: false,

      setConnectionError: (hasError) => {
        set({ connectionError: hasError });
      },

      setShowConnectionErrors: (show) => {
        set({ showConnectionErrors: show });
      },

      updateUserProfile: (data) => {
        set(state => ({
          userData: {
            ...state.userData,
            ...data
          }
        }));
      },

      updateTaskData: (taskId, data) => {
        const activeProject = get().getActiveProject();
        
        if (activeProject && activeProject.domainData?.tasks?.[taskId]) {
          set(state => {
            const updatedProjects = state.userData.projects.map(project => {
              if (project.id === activeProject.id) {
                // Make sure domainData and tasks object exists
                const domainData = project.domainData || { tasks: {}, domainInputs: {}, generatedOutputs: {} };
                const tasks = domainData.tasks || {};
                
                return {
                  ...project,
                  domainData: {
                    ...domainData,
                    tasks: {
                      ...tasks,
                      [taskId]: {
                        ...tasks[taskId],
                        ...data
                      }
                    }
                  }
                };
              }
              return project;
            });
            
            return {
              userData: {
                ...state.userData,
                projects: updatedProjects
              }
            };
          });
        } else {
          // Fall back to updating in userData directly
          set(state => ({
            userData: {
              ...state.userData,
              tasks: {
                ...state.userData.tasks,
                [taskId]: {
                  ...state.userData.tasks[taskId],
                  ...data
                }
              }
            }
          }));
        }
        
        // Sync with Supabase in the background
        try {
          const state = get();
          const activeProject = state.getActiveProject();
          if (activeProject) {
            getCurrentUser().then(user => {
              if (user) {
                saveTask({
                  project_id: activeProject.id,
                  task_id: taskId,
                  completed: data.completed !== undefined ? data.completed : state.userData.tasks[taskId]?.completed || false,
                  notes: data.notes !== undefined ? data.notes : state.userData.tasks[taskId]?.notes || '',
                  attachments: data.attachments !== undefined ? data.attachments : state.userData.tasks[taskId]?.attachments || [],
                  custom_fields: data.customFields !== undefined ? data.customFields : state.userData.tasks[taskId]?.customFields || {},
                  updated_by: user.id
                }).catch(err => {
                  console.error("Background task sync failed:", err);
                  set({ connectionError: true });
                });
              }
            }).catch(err => {
              console.error("Failed to get current user for task sync:", err);
              set({ connectionError: true });
            });
          }
        } catch (err) {
          console.error("Error in background task sync:", err);
          set({ connectionError: true });
        }
      },

      setTaskCompleted: (taskId, completed) => {
        const state = get();
        state.updateTaskData(taskId, { completed });
      },

      setCurrentDomain: (domainId) => {
        set({ currentDomain: domainId });
      },

      getDomainProgress: (domainId: number): DomainProgress => {
        const state = get();
        const activeProject = state.getActiveProject();
        
        // Calculate tasks for this domain
        const domainTasks = tasks.filter(task => task.domainId === domainId);
        
        if (domainTasks.length === 0) {
          // Return safe default values if no tasks found for this domain
          return {
            inputProgress: 0,
            processingProgress: 0,
            outputProgress: 0,
            overallProgress: 0
          };
        }
        
        const inputTasks = domainTasks.filter(task => task.stage === 'input');
        const processingTasks = domainTasks.filter(task => task.stage === 'processing');
        const outputTasks = domainTasks.filter(task => task.stage === 'output');
        
        // Calculate task completion counts
        let completedInputTasks = 0;
        let completedProcessingTasks = 0;
        let completedOutputTasks = 0;
        
        domainTasks.forEach(task => {
          let isCompleted = false;
          
          if (activeProject && activeProject.domainData?.tasks?.[task.id]) {
            isCompleted = !!activeProject.domainData.tasks[task.id].completed;
          } else {
            isCompleted = !!state.userData.tasks[task.id]?.completed;
          }
          
          if (isCompleted) {
            if (task.stage === 'input') completedInputTasks++;
            else if (task.stage === 'processing') completedProcessingTasks++;
            else if (task.stage === 'output') completedOutputTasks++;
          }
        });
        
        // Calculate progress for each stage (with safe fallbacks)
        const inputProgress = inputTasks.length > 0 
          ? (completedInputTasks / inputTasks.length) * 100 
          : 0;
        
        const processingProgress = processingTasks.length > 0 
          ? (completedProcessingTasks / processingTasks.length) * 100 
          : 0;
        
        const outputProgress = outputTasks.length > 0 
          ? (completedOutputTasks / outputTasks.length) * 100 
          : 0;
        
        // Calculate overall progress (weighted average)
        const totalTasks = domainTasks.length;
        const completedTasks = completedInputTasks + completedProcessingTasks + completedOutputTasks;
        
        // Check if domain has input and output
        const hasInput = !!state.getDomainInput(domainId);
        const hasOutput = !!state.getDomainOutput(domainId);
        
        // Calculate overall progress: tasks (70%), input (15%), output (15%)
        let overallProgress = totalTasks > 0 
          ? (completedTasks / totalTasks) * 70 
          : 0;
          
        if (hasInput) overallProgress += 15;
        if (hasOutput) overallProgress += 15;
        
        // Make sure we show 100% when all metrics are at 100%
        // Relaxed condition to fix rounding errors and edge cases
        if (inputProgress >= 99 && processingProgress >= 99 && outputProgress >= 99 && hasInput && hasOutput) {
          overallProgress = 100;
        }
        
        // Also show 100% if all tasks are completed and we have input/output
        if (totalTasks > 0 && completedTasks === totalTasks && hasInput && hasOutput) {
          overallProgress = 100;
        }
        
        return {
          inputProgress: Math.max(0, Math.min(100, inputProgress)) || 0,
          processingProgress: Math.max(0, Math.min(100, processingProgress)) || 0,
          outputProgress: Math.max(0, Math.min(100, outputProgress)) || 0,
          overallProgress: Math.max(0, Math.min(100, overallProgress)) || 0
        };
      },

      getOverallProgress: () => {
        const state = get();
        
        // Calculate average progress across all domains
        const totalProgress = domains.reduce((sum, domain) => {
          const domainProgress = state.getDomainProgress(domain.id);
          return sum + domainProgress.overallProgress;
        }, 0);
        
        return totalProgress / domains.length;
      },

      getDomainInput: (domainId) => {
        const state = get();
        const activeProject = state.getActiveProject();
        
        // First check if there's a domain input in the active project
        if (activeProject && activeProject.domainData?.domainInputs?.[domainId]) {
          return activeProject.domainData.domainInputs[domainId];
        }
        
        // Fall back to user data if not in active project
        return state.userData.domainInputs[domainId] || null;
      },

      updateDomainInput: async (domainId, content) => {
        const state = get();
        const activeProject = state.getActiveProject();
        
        if (activeProject) {
          // Update in project first
          set(state => {
            const updatedProjects = state.userData.projects.map(project => {
              if (project.id === activeProject.id) {
                // Ensure domainData and domainInputs objects exist
                const domainData = project.domainData || { tasks: {}, domainInputs: {}, generatedOutputs: {} };
                const domainInputs = domainData.domainInputs || {};
                
                return {
                  ...project,
                  domainData: {
                    ...domainData,
                    domainInputs: {
                      ...domainInputs,
                      [domainId]: {
                        content,
                        lastUpdated: new Date().toISOString()
                      }
                    }
                  }
                };
              }
              return project;
            });
            
            return {
              userData: {
                ...state.userData,
                projects: updatedProjects
              }
            };
          });
          
          // Sync with Supabase if user is authenticated
          try {
            const session = await getCurrentSession();
            if (session) {
              await saveDomainInput({
                project_id: activeProject.id,
                domain_id: domainId,
                content,
                created_by: session.user.id
              });
            }
          } catch (error) {
            console.error('Error saving domain input to Supabase:', error);
            // Mark connection as having error
            set({ connectionError: true });
          }
        } else {
          // Fall back to updating in userData directly
          set(state => ({
            userData: {
              ...state.userData,
              domainInputs: {
                ...state.userData.domainInputs,
                [domainId]: {
                  content,
                  lastUpdated: new Date().toISOString()
                }
              }
            }
          }));
        }
      },

      getPreviousDomainId: (domainId) => {
        const sortedDomains = [...domains].sort((a, b) => a.id - b.id);
        const currentIndex = sortedDomains.findIndex(d => d.id === domainId);
        
        if (currentIndex <= 0) {
          return null; // First domain or domain not found
        }
        
        return sortedDomains[currentIndex - 1].id;
      },

      analyzeDomainInput: async (domainId) => {
        const state = get();
        const activeProject = state.getActiveProject();
        const domainInput = state.getDomainInput(domainId);
        
        if (!domainInput || !domainInput.content) {
          throw new Error('Domain input is empty');
        }
        
        // Find the domain object
        const domain = domains.find(d => d.id === domainId);
        if (!domain) {
          throw new Error('Domain not found');
        }
        
        // Get previous domain output for context if available
        const previousDomainId = state.getPreviousDomainId(domainId);
        const previousOutput = previousDomainId ? state.getDomainOutput(previousDomainId) : null;
        
        // Start analysis
        set({ isAnalyzing: true });
        
        // Set a timeout to update connectionError if analysis takes too long
        const timeout = setTimeout(() => {
          if (get().isAnalyzing) {
            console.warn('Analysis taking a long time, marking as potential connection error');
            set({ connectionError: true });
          }
        }, 60000); // 60 seconds
        
        try {
          // Get user session
          const session = await getCurrentSession();
          
          // Generate analysis using AI
          const startTime = performance.now();
          console.log('[Performance] Starting analysis for domain', domainId, 'at', new Date().toISOString());
          
          const { content, templates } = await openaiService.analyzeDomainInput(
            domain.name,
            domain.description,
            domainInput.content,
            previousOutput?.content || null,
            state.userData.organizationName,
            state.userData.industry,
            state.userData.pmoMaturityLevel,
            activeProject?.id
          );
          
          clearTimeout(timeout);
          
          const elapsedTime = performance.now() - startTime;
          console.log(`[Performance] Analysis completed in ${(elapsedTime/1000).toFixed(2)} seconds`);
          
          // Save the output
          const domainOutput: DomainOutput = {
            content,
            generatedDate: new Date().toISOString(),
            templates
          };
          
          // Update in the store
          if (activeProject) {
            set(state => {
              const updatedProjects = state.userData.projects.map(project => {
                if (project.id === activeProject.id) {
                  // Ensure domainData and generatedOutputs objects exist
                  const domainData = project.domainData || { tasks: {}, domainInputs: {}, generatedOutputs: {} };
                  
                  return {
                    ...project,
                    domainData: {
                      ...domainData,
                      generatedOutputs: {
                        ...domainData.generatedOutputs,
                        [domainId]: domainOutput
                      }
                    }
                  };
                }
                return project;
              });
              
              return {
                userData: {
                  ...state.userData,
                  projects: updatedProjects
                },
                isAnalyzing: false // Reset analyzing state
              };
            });
            
            // Save to Supabase if user is authenticated
            if (session) {
              try {
                await saveDomainOutput({
                  project_id: activeProject.id,
                  domain_id: domainId,
                  content,
                  created_by: session.user.id
                }, templates);
              } catch (error) {
                console.error('Error saving to Supabase:', error);
                // If there's an error with Supabase, just continue with the local data
                set({ connectionError: true });
              }
            }
          } else {
            // Fall back to updating in userData directly
            set(state => ({
              userData: {
                ...state.userData,
                generatedOutputs: {
                  ...state.userData.generatedOutputs,
                  [domainId]: domainOutput
                }
              },
              isAnalyzing: false // Reset analyzing state
            }));
          }
        } catch (error) {
          console.error('Error analyzing domain input:', error);
          // Reset analyzing state
          set({ 
            isAnalyzing: false,
            connectionError: true
          });
          throw error;
        }
      },

      getDomainOutput: (domainId) => {
        const state = get();
        const activeProject = state.getActiveProject();
        
        // First check if there's a domain output in the active project
        if (activeProject && activeProject.domainData?.generatedOutputs?.[domainId]) {
          return activeProject.domainData.generatedOutputs[domainId];
        }
        
        // Fall back to user data if not in active project
        return state.userData.generatedOutputs[domainId] || null;
      },

      exportUserData: async () => {
        // Export all user data as JSON
        const state = get();
        const exportData = {
          userData: state.userData,
          processedDocuments: state.processedDocuments,
          exportDate: new Date().toISOString(),
          version: '1.0.0'
        };
        
        return JSON.stringify(exportData, null, 2);
      },

      importUserData: async (data) => {
        if (!data || !data.userData) {
          throw new Error('Invalid import data format');
        }
        
        // Import user data
        set({
          userData: data.userData,
          processedDocuments: data.processedDocuments || []
        });
      },

      resetUserData: async () => {
        // Reset to default state
        set({
          userData: getDefaultUserData(),
          processedDocuments: []
        });
      },

      createProject: async (projectData) => {
        console.log('🆕 Store: Creating project', projectData.name);
        const today = new Date();
        
        // Default date values if not provided
        const startDate = projectData.startDate || today.toISOString();
        const sixMonthsLater = new Date(today);
        sixMonthsLater.setMonth(today.getMonth() + 6);
        const endDate = projectData.endDate || sixMonthsLater.toISOString();
        
        // Create project structure that will be used for both API and local creation
        const projectStructure = {
          id: uuidv4(), // Generate ID upfront for consistency
          name: projectData.name || "New PMO Project",
          description: projectData.description || "",
          createdAt: today.toISOString(),
          updatedAt: today.toISOString(),
          startDate,
          endDate,
          owner_id: projectData.owner_id || "",
          user_id: projectData.user_id || "",
          budget: projectData.budget || 0,
          budgetSpent: 0,
          keyObjectives: projectData.keyObjectives || [],
          stakeholders: projectData.stakeholders || [],
          risks: projectData.risks || [],
          domainData: {
            tasks: initializeTaskData(),
            domainInputs: {},
            generatedOutputs: {}
          }
        };
        
        try {
          // First check if we have a user - if not, we'll be in offline mode
          const user = await getCurrentUser().catch(() => null);
          
          if (!user) {
            console.log('💡 No user found, creating project in offline mode');
            // Add local project to state
            set(state => ({
              userData: {
                ...state.userData,
                projects: [...state.userData.projects, projectStructure],
                activeProjectId: projectStructure.id
              }
            }));
            
            console.log('✅ Created offline project:', projectStructure.id);
            return projectStructure.id;
          }
          
          console.log('🔌 User authenticated, creating project via API', user.email);
          
          // Set a maximum timeout for API request
          const timeoutPromise = new Promise((_, reject) => {
            setTimeout(() => reject(new Error('API request timed out')), 10000);
          });
          
          try {
            // Try API creation with timeout
            const apiResult = await Promise.race([
              (async () => {
                const response = await apiClient.post('/projects', {
                  name: projectData.name,
                  description: projectData.description || "",
                  owner_id: user.id,
                  email: user.email,
                  budget: projectData.budget || 0,
                  is_active: true
                });
                
                return response;
              })(),
              timeoutPromise
            ]);
            
            const projectId = apiResult.data?.data?.id;
            
            if (!projectId) {
              throw new Error("No project ID returned from API");
            }
            
            console.log('✅ Project created in database:', projectId);
            
            // Fetch fresh project data from API
            await get().fetchProjectsFromDb();
            
            // Set as active project
            get().setActiveProject(projectId);
            
            return projectId;
          } catch (error) {
            console.error('❌ Error creating project via API:', error);
            
            // Fall back to creating local project if API fails
            console.log('⚠️ Falling back to offline mode with pre-generated project');
            
            // Add local project to state immediately instead of creating a new one
            set(state => ({
              userData: {
                ...state.userData,
                projects: [...state.userData.projects, projectStructure],
                activeProjectId: projectStructure.id
              },
              connectionError: true
            }));
            
            console.log('✅ Created fallback offline project:', projectStructure.id);
            return projectStructure.id;
          }
        } catch (error) {
          console.error('❌ Error in createProject function:', error);
          
          // Final fallback if everything else fails
          try {
            // Add local project to state
            set(state => ({
              userData: {
                ...state.userData,
                projects: [...state.userData.projects, projectStructure],
                activeProjectId: projectStructure.id
              },
              connectionError: true
            }));
            
            console.log('✅ Created emergency fallback project:', projectStructure.id);
            return projectStructure.id;
          } catch (finalError) {
            console.error('💥 Critical error in project creation:', finalError);
            throw error; // Re-throw original error if even the fallback fails
          }
        }
      },

      updateProject: async (projectId, projectData) => {
        // Update project in state
        set(state => ({
          userData: {
            ...state.userData,
            projects: state.userData.projects.map(project => 
              project.id === projectId 
                ? { ...project, ...projectData, updatedAt: new Date().toISOString() } 
                : project
            )
          }
        }));
        
        // Sync with Supabase if user is authenticated
        try {
          const session = await getCurrentSession();
          if (session) {
            // Format data for Supabase
            const supabaseProjectData = {
              name: projectData.name,
              description: projectData.description,
              start_date: projectData.startDate,
              end_date: projectData.endDate,
              budget: projectData.budget,
              budget_spent: projectData.budgetSpent,
              key_objectives: projectData.keyObjectives,
              stakeholders: projectData.stakeholders,
              risks: projectData.risks,
              updated_at: new Date().toISOString()
            };
            
            try {
              // Update in Supabase
              await updateProjectInDb(projectId, supabaseProjectData);
            } catch (error) {
              console.error('Error updating project in Supabase:', error);
              set({ connectionError: true });
            }
          }
        } catch (error) {
          console.error('Error updating project in Supabase:', error);
          set({ connectionError: true });
        }
      },

      deleteProject: async (projectId) => {
        const state = get();
        const projects = state.userData.projects;
        
        // Ensure we keep at least one project
        if (projects.length <= 1) {
          throw new Error('Cannot delete the last project');
        }
        
        // Remove project from state
        set(state => {
          const updatedProjects = state.userData.projects.filter(p => p.id !== projectId);
          const activeProjectId = 
            state.userData.activeProjectId === projectId 
              ? updatedProjects[0]?.id // Set first project as active
              : state.userData.activeProjectId;
          
          return {
            userData: {
              ...state.userData,
              projects: updatedProjects,
              activeProjectId
            }
          };
        });
        
        // Sync with Supabase if user is authenticated
        try {
          const session = await getCurrentSession();
          if (session) {
            try {
              await deleteProjectInDb(projectId);
            } catch (error) {
              console.error('Error deleting project in Supabase:', error);
              set({ connectionError: true });
            }
          }
        } catch (error) {
          console.error('Error deleting project in Supabase:', error);
          set({ connectionError: true });
        }
      },

      getProjects: () => {
        return get().userData.projects || [];
      },

      getProject: (projectId) => {
        return get().userData.projects.find(project => project.id === projectId);
      },

      getActiveProject: () => {
        const state = get();
        const activeProjectId = state.userData.activeProjectId;
        
        if (!activeProjectId || activeProjectId === '') {
          // If no active project is set, but we have projects, set the first one as active
          if (state.userData.projects.length > 0) {
            const firstProject = state.userData.projects[0];
            set(state => ({
              userData: {
                ...state.userData,
                activeProjectId: firstProject.id
              }
            }));
            return firstProject;
          }
          
          // Create a default project structure if no projects exist
          const defaultProject: Project = {
            id: 'default',
            name: 'Default Project',
            description: 'Auto-created default project',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            startDate: new Date().toISOString(),
            endDate: new Date(new Date().setMonth(new Date().getMonth() + 6)).toISOString(),
            owner_id: '',
            user_id: '',
            budget: 0,
            budgetSpent: 0,
            keyObjectives: [],
            stakeholders: [],
            risks: [],
            domainData: {
              tasks: {},
              domainInputs: {},
              generatedOutputs: {}
            }
          };
          
          // Add to state
          set(state => ({
            userData: {
              ...state.userData,
              projects: [defaultProject],
              activeProjectId: defaultProject.id
            }
          }));
          
          // Attempt to create a real project in the background
          createDefaultProject().catch(err => console.error('Failed to create default project:', err));
          
          return defaultProject;
        }
        
        // Find the active project
        const activeProject = state.userData.projects.find(p => p.id === activeProjectId);
        
        // If active project ID is set but project not found, revert to fallback
        if (!activeProject) {
          if (state.userData.projects.length > 0) {
            const firstProject = state.userData.projects[0];
            set(state => ({
              userData: {
                ...state.userData,
                activeProjectId: firstProject.id
              }
            }));
            return firstProject;
          } else {
            console.warn('Active project not found and no projects exist, will create one');
            // Return a temporary project while we create a real one
            const tempProject: Project = {
              id: 'temp',
              name: 'Temporary Project',
              description: 'Auto-created temporary project',
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
              startDate: new Date().toISOString(),
              endDate: new Date(new Date().setMonth(new Date().getMonth() + 6)).toISOString(),
              owner_id: '',
              user_id: '',
              budget: 0,
              budgetSpent: 0,
              keyObjectives: [],
              stakeholders: [],
              risks: [],
              domainData: {
                tasks: {},
                domainInputs: {},
                generatedOutputs: {}
              }
            };
            
            // Create a real project in the background
            createDefaultProject().catch(err => console.error('Failed to create default project:', err));
            
            return tempProject;
          }
        }
        
        return activeProject;
      },

      getActiveProjectId: () => {
        return get().userData.activeProjectId;
      },

      setActiveProject: (projectId) => {
        set(state => ({
          userData: {
            ...state.userData,
            activeProjectId: projectId
          }
        }));
      },

      fetchProjectsFromDb: async () => {
        try {
          const user = await getCurrentUser();
          if (!user) return;
          
          // Fetch projects from Supabase
          try {
            const projects = await fetchProjects(user.id);
            
            if (projects && projects.length > 0) {
              // Convert to app format
              const appProjects = projects.map(project => ({
                id: project.id,
                name: project.name,
                description: project.description || '',
                createdAt: project.created_at,
                updatedAt: project.updated_at,
                startDate: project.start_date,
                endDate: project.end_date,
                budget: project.budget || 0,
                budgetSpent: project.budget_spent || 0,
                keyObjectives: project.key_objectives || [],
                stakeholders: project.stakeholders || [],
                risks: project.risks || [],
                ownerId: project.owner_id,
                domainData: {
                  tasks: initializeTaskData(),
                  domainInputs: {},
                  generatedOutputs: {}
                }
              }));
              
              // Update state
              set(state => ({
                userData: {
                  ...state.userData,
                  projects: appProjects as Project[],
                  activeProjectId: appProjects[0].id
                },
                connectionError: false
              }));
              
              // Fetch domain inputs and outputs for the active project
              await get().syncWithSupabase();
            }
          } catch (error) {
            console.error('Error fetching projects from Supabase:', error);
            set({ connectionError: true });
          }
        } catch (error) {
          console.error('Error fetching projects from Supabase:', error);
          set({ connectionError: true });
        }
      },

      syncWithSupabase: async (shouldReload = false) => {
        console.log('🔄 Starting syncWithSupabase operation, shouldReload:', shouldReload);
        let stateModified = false;
        
        try {
          const user = await getCurrentUser();
          if (!user) {
            console.warn('⚠️ No user found, aborting sync');
            return false;
          }
          
          console.log('👤 Current user:', user.email);
          
          // Get the active project
          const state = get();
          const activeProject = state.getActiveProject();
          
          if (!activeProject) {
            console.warn('⚠️ No active project found during sync');
            return false;
          }
          
          console.log('📊 Syncing project:', activeProject.name, activeProject.id);
          
          // Fetch tasks from server
          console.log('🔍 Fetching tasks from server for project:', activeProject.id);
          const tasks = await fetchTasks(activeProject.id);
          console.log('📥 Tasks received:', tasks?.length || 0);
          
          if (tasks && tasks.length > 0) {
            // Convert task data from API format to local format
            const taskMap: Record<string, TaskData> = {};
            tasks.forEach(task => {
              taskMap[task.task_id] = {
                    completed: task.completed || false,
                    notes: task.notes || '',
                    attachments: task.attachments || [],
                    customFields: task.custom_fields || {}
                  };
            });
            
            console.log('🔃 Processing tasks for state update');
            
            // Now update the state with the fetched tasks
            if (Object.keys(taskMap).length > 0) {
              // Check if any task differs from current state
              let tasksChanged = false;
              
              Object.entries(taskMap).forEach(([taskId, taskData]) => {
                const currentTaskData = activeProject.domainData?.tasks?.[taskId];
                
                // Simple comparison to detect changes - could be more sophisticated
                if (!currentTaskData || 
                    currentTaskData.completed !== taskData.completed || 
                    currentTaskData.notes !== taskData.notes) {
                  tasksChanged = true;
                }
              });
              
              if (tasksChanged) {
                console.log('🔄 Tasks changed, updating state');
            set(state => {
              const updatedProjects = state.userData.projects.map(project => {
                    if (project.id === activeProject.id) {
                  return {
                    ...project,
                    domainData: {
                          ...project.domainData,
                          tasks: {
                            ...project.domainData?.tasks,
                            ...taskMap
                      }
                    }
                  };
                }
                return project;
              });
              
              return {
                userData: {
                  ...state.userData,
                      projects: updatedProjects
                }
              };
            });
                
                stateModified = true;
              } else {
                console.log('📊 No task changes detected');
              }
            }
          }
          
          // Reload page if state was modified and shouldReload is true
          if (shouldReload && stateModified) {
            console.log('🔄 State modified and shouldReload is true, reloading page');
            setTimeout(() => {
              window.location.reload();
            }, 100);
          } else {
            console.log('✅ Sync completed, stateModified:', stateModified, 'shouldReload:', shouldReload);
          }
          
          // Always reset connection error when sync is successful
          set({ connectionError: false });
          return stateModified;
        } catch (error) {
          console.error('❌ Error during syncWithSupabase:', error);
          set({ connectionError: true });
          return false;
        }
      },

      addProcessedDocument: (document: ProcessedDocument) => {
        set(state => ({
          processedDocuments: [...state.processedDocuments, document]
        }));
      },

      getDocumentsForDomain: (domainId: number) => {
        return get().processedDocuments.filter(doc => doc.domainId === domainId);
      }
    }),
    {
      name: 'pmo-domains-storage',
      // Make storage more reliable and better handle projects
      partialize: (state) => {
        // Ensure we always have the projects array
        const userData = {
          ...state.userData,
          // Only remove the large generated outputs from storage
          generatedOutputs: {}
        };
        
        return {
          userData,
          currentDomain: state.currentDomain,
          connectionError: state.connectionError
          // Don't include processedDocuments in local storage
        };
      },
      // Add storage event handling to debug storage issues
      onRehydrateStorage: () => (state) => {
        console.log('🔄 Store rehydrated from local storage');
        if (state?.userData?.projects) {
          console.log(`📊 Loaded ${state.userData.projects.length} projects from storage`);
        } else {
          console.warn('⚠️ No projects found in rehydrated storage');
        }
      }
    }
  )
);

// Initialize by fetching data from Supabase
export const initializeStore = async () => {
  try {
    const session = await getCurrentSession();
    if (session) {
      await useAppStore.getState().fetchProjectsFromDb().catch(err => {
        console.error('Error initializing store:', err);
        useAppStore.getState().setConnectionError(true);
      });
      
      // Check if projects exist after fetching, if not create default
      const projects = useAppStore.getState().getProjects();
      if (!projects || projects.length === 0) {
        console.log('No projects found, creating default project');
        const projectId = await createDefaultProject();
        if (projectId) {
          // Set this as active project
          useAppStore.getState().setActiveProject(projectId);
        }
      }
    } else {
      // No session, but still create a default project
      console.log('No user session, creating default offline project');
      const projectId = await createDefaultProject();
      if (projectId) {
        // Set this as active project
        useAppStore.getState().setActiveProject(projectId);
      }
    }
  } catch (error) {
    console.error('Error initializing store:', error);
    useAppStore.getState().setConnectionError(true);
  }
};

// Initialize the store when this module is loaded
initializeStore();

// Initialize user subscription on application start
const initializeUserSubscription = async (userId: string) => {
  try {
    // Skip Supabase subscription checks since they're handled by the backend
    console.log("Skipping frontend subscription initialization - handled by backend");
    return true;
  } catch (error) {
    console.error("Error initializing user subscription:", error);
    return false;
  }
};