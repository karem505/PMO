import { 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  updateDoc, 
  arrayUnion, 
  arrayRemove, 
  query, 
  where, 
  getDocs 
} from 'firebase/firestore';
import { db } from './config';
import { v4 as uuidv4 } from 'uuid';
import { UserData, TeamCollaboration, TeamInvitation } from '../types';

// User data operations
export const createUserProfile = async (userId: string, userData: Partial<UserData>) => {
  try {
    await setDoc(doc(db, 'users', userId), {
      ...userData,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });
  } catch (error) {
    console.error("Error creating user profile: ", error);
    throw error;
  }
};

export const getUserProfile = async (userId: string) => {
  try {
    const userDoc = await getDoc(doc(db, 'users', userId));
    if (userDoc.exists()) {
      return userDoc.data() as UserData;
    }
    return null;
  } catch (error) {
    console.error("Error getting user profile: ", error);
    throw error;
  }
};

export const updateUserProfile = async (userId: string, userData: Partial<UserData>) => {
  try {
    await updateDoc(doc(db, 'users', userId), {
      ...userData,
      updatedAt: new Date().toISOString()
    });
  } catch (error) {
    console.error("Error updating user profile: ", error);
    throw error;
  }
};

// Team collaboration operations
export const createTeam = async (userId: string, teamName: string, description: string) => {
  try {
    const teamId = uuidv4();
    const teamData: TeamCollaboration = {
      id: teamId,
      name: teamName,
      description,
      createdBy: userId,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      members: [userId],
      admins: [userId]
    };
    
    await setDoc(doc(db, 'teams', teamId), teamData);
    
    // Add team reference to user
    await updateDoc(doc(db, 'users', userId), {
      teams: arrayUnion(teamId)
    });
    
    return teamId;
  } catch (error) {
    console.error("Error creating team: ", error);
    throw error;
  }
};

export const getTeam = async (teamId: string) => {
  try {
    const teamDoc = await getDoc(doc(db, 'teams', teamId));
    if (teamDoc.exists()) {
      return teamDoc.data() as TeamCollaboration;
    }
    return null;
  } catch (error) {
    console.error("Error getting team: ", error);
    throw error;
  }
};

export const getUserTeams = async (userId: string) => {
  try {
    const q = query(collection(db, 'teams'), where('members', 'array-contains', userId));
    const querySnapshot = await getDocs(q);
    
    const teams: TeamCollaboration[] = [];
    querySnapshot.forEach((doc) => {
      teams.push(doc.data() as TeamCollaboration);
    });
    
    return teams;
  } catch (error) {
    console.error("Error getting user teams: ", error);
    throw error;
  }
};

export const inviteUserToTeam = async (teamId: string, invitedByUserId: string, invitedEmail: string) => {
  try {
    const invitationId = uuidv4();
    const invitationData: TeamInvitation = {
      id: invitationId,
      teamId,
      invitedBy: invitedByUserId,
      invitedEmail,
      status: 'pending',
      createdAt: new Date().toISOString()
    };
    
    await setDoc(doc(db, 'teamInvitations', invitationId), invitationData);
    return invitationId;
  } catch (error) {
    console.error("Error inviting user to team: ", error);
    throw error;
  }
};

export const getUserInvitations = async (userEmail: string) => {
  try {
    const q = query(collection(db, 'teamInvitations'), where('invitedEmail', '==', userEmail), where('status', '==', 'pending'));
    const querySnapshot = await getDocs(q);
    
    const invitations: TeamInvitation[] = [];
    querySnapshot.forEach((doc) => {
      invitations.push(doc.data() as TeamInvitation);
    });
    
    return invitations;
  } catch (error) {
    console.error("Error getting user invitations: ", error);
    throw error;
  }
};

export const acceptTeamInvitation = async (invitationId: string, userId: string) => {
  try {
    const invitationDoc = await getDoc(doc(db, 'teamInvitations', invitationId));
    
    if (invitationDoc.exists()) {
      const invitation = invitationDoc.data() as TeamInvitation;
      
      // Update invitation status
      await updateDoc(doc(db, 'teamInvitations', invitationId), {
        status: 'accepted',
        acceptedBy: userId,
        acceptedAt: new Date().toISOString()
      });
      
      // Add user to team
      await updateDoc(doc(db, 'teams', invitation.teamId), {
        members: arrayUnion(userId),
        updatedAt: new Date().toISOString()
      });
      
      // Add team to user's teams
      await updateDoc(doc(db, 'users', userId), {
        teams: arrayUnion(invitation.teamId)
      });
      
      return invitation.teamId;
    }
    
    throw new Error("Invitation not found");
  } catch (error) {
    console.error("Error accepting team invitation: ", error);
    throw error;
  }
};

export const rejectTeamInvitation = async (invitationId: string, userId: string) => {
  try {
    await updateDoc(doc(db, 'teamInvitations', invitationId), {
      status: 'rejected',
      rejectedBy: userId,
      rejectedAt: new Date().toISOString()
    });
  } catch (error) {
    console.error("Error rejecting team invitation: ", error);
    throw error;
  }
};

export const removeTeamMember = async (teamId: string, adminUserId: string, memberUserId: string) => {
  try {
    const teamDoc = await getDoc(doc(db, 'teams', teamId));
    
    if (teamDoc.exists()) {
      const team = teamDoc.data() as TeamCollaboration;
      
      // Check if admin
      if (!team.admins.includes(adminUserId)) {
        throw new Error("Not authorized to remove team members");
      }
      
      // Remove user from team
      await updateDoc(doc(db, 'teams', teamId), {
        members: arrayRemove(memberUserId),
        admins: arrayRemove(memberUserId), // Also remove from admins if they were an admin
        updatedAt: new Date().toISOString()
      });
      
      // Remove team from user's teams
      await updateDoc(doc(db, 'users', memberUserId), {
        teams: arrayRemove(teamId)
      });
    } else {
      throw new Error("Team not found");
    }
  } catch (error) {
    console.error("Error removing team member: ", error);
    throw error;
  }
};

// Shared project/domain data operations
export const shareProjectWithTeam = async (projectId: string, teamId: string, userId: string) => {
  try {
    // First check if user is a member of the team
    const teamDoc = await getDoc(doc(db, 'teams', teamId));
    
    if (teamDoc.exists()) {
      const team = teamDoc.data() as TeamCollaboration;
      
      if (!team.members.includes(userId)) {
        throw new Error("Not a member of this team");
      }
      
      // Add project to team's shared projects
      await updateDoc(doc(db, 'teams', teamId), {
        sharedProjects: arrayUnion(projectId),
        updatedAt: new Date().toISOString()
      });
      
      // Add team reference to project's shared with teams
      await updateDoc(doc(db, 'projects', projectId), {
        sharedWithTeams: arrayUnion(teamId),
        updatedAt: new Date().toISOString()
      });
    } else {
      throw new Error("Team not found");
    }
  } catch (error) {
    console.error("Error sharing project with team: ", error);
    throw error;
  }
};