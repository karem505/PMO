import { User } from '@supabase/supabase-js';
import { signInWithEmail as supabaseSignIn, signUpWithEmail as supabaseSignUp, resetPassword, getCurrentUser, getCurrentSession } from '../services/supabaseService';
import { supabase } from '../services/supabaseClient';
import { 
  getAuth, 
  GoogleAuthProvider, 
  signInWithPopup 
} from 'firebase/auth';

/**
 * Sign in with Google using popup
 * @returns Promise resolving to the user object
 */
export const signInWithGoogle = async () => {
  try {
    // Use Firebase Google sign in instead of Supabase
    const provider = new GoogleAuthProvider();
    provider.addScope('profile');
    provider.addScope('email');
    provider.setCustomParameters({
      prompt: 'select_account'
    });
    
    const auth = getAuth();
    const result = await signInWithPopup(auth, provider);
    const user = result.user;
    
    // Optional: You might want to create or link this user in Supabase as well
    // This depends on your specific integration needs
    
    return user;
  } catch (error: any) {
    console.error("Error signing in with Google: ", error);
    throw error;
  }
};

/**
 * Sign in with email and password
 * @param email User email
 * @param password User password
 * @returns Promise resolving to the user object
 */
export const signInWithEmail = async (email: string, password: string) => {
  try {
    const { user } = await supabaseSignIn(email, password);
    return user;
  } catch (error: any) {
    console.error("Error signing in with email: ", error);
    
    // Enhanced error handling for better user feedback
    switch (error.message) {
      case 'Invalid login credentials':
        throw new Error("Incorrect email or password. Please try again.");
      default:
        throw error;
    }
  }
};

/**
 * Create a new account with email and password
 * @param email User email
 * @param password User password
 * @param displayName User display name
 * @param teamCode Optional team code for automatic group assignment
 * @returns Promise resolving to the user object
 */
export const createAccountWithEmail = async (email: string, password: string, displayName: string, teamCode?: string) => {
  try {
    const { user } = await supabaseSignUp(email, password, displayName);
    return user;
  } catch (error: any) {
    console.error("Error creating account: ", error);
    
    // Enhanced error handling
    switch (true) {
      case error.message.includes('already registered'):
        throw new Error("An account with this email already exists. Please sign in or reset your password.");
      case error.message.includes('valid email'):
        throw new Error("Please enter a valid email address.");
      case error.message.includes('password'):
        throw new Error("Password is too weak. Please choose a stronger password (at least 6 characters).");
      default:
        throw error;
    }
  }
};

/**
 * Send password reset email
 * @param email User email
 */
export const sendPasswordReset = async (email: string) => {
  try {
    await resetPassword(email);
  } catch (error: any) {
    console.error("Error sending password reset email: ", error);
    throw error;
  }
};

/**
 * Sign out the current user
 */
export const signOut = async () => {
  try {
    // Clear auth token from session storage
    sessionStorage.removeItem('authToken');
    
    const { error } = await supabase.auth.signOut();
    
    if (error) throw error;
  } catch (error) {
    console.error("Error signing out: ", error);
    throw error;
  }
};

/**
 * Get the current auth token for API calls
 * @returns Promise resolving to the ID token
 */
export const getAuthToken = async (): Promise<string | null> => {
  try {
    const session = await getCurrentSession();
    return session?.access_token || null;
  } catch (error) {
    console.error("Error getting auth token:", error);
    return null;
  }
};

/**
 * Subscribe to authentication state changes
 * @param callback Callback function called with the user object when auth state changes
 * @returns Unsubscribe function
 */
export const subscribeToAuthChanges = (callback: (user: User | null) => void) => {
  // Use Supabase auth state changes
  const { data: authListener } = supabase.auth.onAuthStateChange(async (event, session) => {
    callback(session?.user || null);
  });
  
  // Return unsubscribe function
  return () => {
    authListener.subscription.unsubscribe();
  };
};

/**
 * Check if a user belongs to a team by team code
 * @param teamCode Team code to check
 * @returns Promise resolving to boolean indicating if user is in team
 */
export const checkTeamMembership = async (teamCode: string): Promise<boolean> => {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return false;
    }
    
    // Query team membership
    const { data, error } = await supabase
      .from('team_members')
      .select('id')
      .eq('user_id', currentUser.id)
      .eq('team_id', teamCode)
      .maybeSingle();
    
    if (error) {
      console.error("Error checking team membership:", error);
      return false;
    }
    
    return !!data;
  } catch (error) {
    console.error("Error checking team membership:", error);
    return false;
  }
};