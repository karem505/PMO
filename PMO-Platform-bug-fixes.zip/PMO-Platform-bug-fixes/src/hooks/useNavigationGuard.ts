import { useNavigationGuard as useNavGuard } from '../components/NavigationGuardProvider';

/**
 * A hook that provides safe navigation functionality
 * This is a wrapper around the NavigationGuardProvider's useNavigationGuard
 */
export const useNavigationGuard = () => {
  // Simply return the context from NavigationGuardProvider
  return useNavGuard();
};

// Add default export
export default useNavigationGuard; 