import { useRef, useCallback, useEffect, RefObject } from 'react';

/**
 * Interface for the return value of useSafeRef
 */
export interface SafeRefResult<T> {
  /** The React ref object */
  ref: RefObject<T>;
  /** Whether the ref is currently attached to a mounted element */
  isMounted: boolean;
  /** Safely access the current value of the ref */
  current: T | null;
  /** Safely perform an action with the ref if it exists */
  withRef: <R>(fn: (element: T) => R, fallback?: R) => R | undefined;
}

/**
 * A hook that provides safe access to a React ref with lifecycle awareness.
 * Helps prevent "Cannot read properties of null" errors by tracking mount state
 * and providing safe access methods.
 * 
 * @param initialValue Optional initial value for the ref
 * @returns An object with the ref, isMounted flag, and safe access methods
 */
export function useSafeRef<T>(initialValue: T | null = null): SafeRefResult<T> {
  // Create the ref
  const ref = useRef<T | null>(initialValue);
  
  // Track whether the ref is mounted (has a non-null value)
  const isMountedRef = useRef<boolean>(false);
  
  // Update the mounted state when the ref changes
  useEffect(() => {
    isMountedRef.current = ref.current !== null;
    
    return () => {
      isMountedRef.current = false;
    };
  }, [ref.current]);
  
  /**
   * Safely perform an action with the ref if it exists
   * @param fn Function to execute with the ref value
   * @param fallback Value to return if ref is null
   * @returns Result of fn or fallback
   */
  const withRef = useCallback(<R>(fn: (element: T) => R, fallback?: R): R | undefined => {
    if (ref.current !== null) {
      try {
        return fn(ref.current);
      } catch (error) {
        console.error('Error in withRef callback:', error);
        return fallback;
      }
    }
    return fallback;
  }, []);
  
  return {
    ref,
    get isMounted() {
      return isMountedRef.current;
    },
    get current() {
      return ref.current;
    },
    withRef
  };
}

export default useSafeRef; 