import React from 'react';
import toast from 'react-hot-toast';

export const useToast = () => {
  return {
    success: (message: string) => {
      console.log('✅ Success:', message);
      toast.success(message, {
        duration: 4000,
        position: 'top-right',
        style: {
          background: '#f0fdf4',
          color: '#166534',
          border: '1px solid #bbf7d0',
        },
      });
    },
    
    error: (message: string) => {
      console.error('❌ Error:', message);
      toast.error(message, {
        duration: 5000,
        position: 'top-right',
        style: {
          background: '#fef2f2',
          color: '#b91c1c',
          border: '1px solid #fecaca',
        },
      });
    },
    
    info: (message: string) => {
      console.log('ℹ️ Info:', message);
      toast(message, {
        duration: 3000,
        position: 'top-right',
        style: {
          background: '#eff6ff', 
          color: '#1e40af',
          border: '1px solid #dbeafe',
        },
      });
    },
    
    warning: (message: string) => {
      console.warn('⚠️ Warning:', message);
      toast(message, {
        duration: 4000,
        position: 'top-right',
        icon: '⚠️',
        style: {
          background: '#fffbeb',
          color: '#92400e',
          border: '1px solid #fef3c7',
        },
      });
    },
    
    loading: (message: string) => {
      return toast.loading(message, {
        position: 'top-right',
        style: {
          background: '#f5f5f5',
          color: '#0f172a',
        },
      });
    },
    
    dismiss: (toastId?: string) => {
      if (toastId) {
        toast.dismiss(toastId);
      } else {
        toast.dismiss();
      }
    },
    
    custom: (message: string, options: any) => {
      return toast(message, options);
    }
  };
}; 