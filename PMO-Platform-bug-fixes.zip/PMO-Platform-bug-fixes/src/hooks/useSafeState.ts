import { useState, useEffect, useCallback, SetStateAction, Dispatch } from 'react';

/**
 * A hook that wraps useState to prevent state updates on unmounted components.
 * This helps avoid the "Can't perform a React state update on an unmounted component" warning.
 * 
 * @param initialState The initial state value
 * @returns A tuple with the current state value and a safe setState function
 */
export function useSafeState<T>(initialState: T | (() => T)): [T, Dispatch<SetStateAction<T>>] {
  const [state, setState] = useState<T>(initialState);
  
  // Track whether the component is mounted
  const mountedRef = { current: true };
  
  // Create a safe setState function that only updates if the component is mounted
  const setSafeState = useCallback((value: SetStateAction<T>) => {
    if (mountedRef.current) {
      setState(value);
    }
  }, []);
  
  // Set mounted to false when the component unmounts
  useEffect(() => {
    return () => {
      mountedRef.current = false;
    };
  }, []);
  
  return [state, setSafeState];
}

export default useSafeState; 