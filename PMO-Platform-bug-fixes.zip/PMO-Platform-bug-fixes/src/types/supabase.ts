export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          email: string
          display_name: string | null
          photo_url: string | null
          organization_name: string | null
          industry: string | null
          pmo_maturity_level: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          email: string
          display_name?: string | null
          photo_url?: string | null
          organization_name?: string | null
          industry?: string | null
          pmo_maturity_level?: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          email?: string
          display_name?: string | null
          photo_url?: string | null
          organization_name?: string | null
          industry?: string | null
          pmo_maturity_level?: string
          created_at?: string
          updated_at?: string
        }
      }
      projects: {
        Row: {
          id: string
          name: string
          description: string | null
          owner_id: string
          created_at: string
          updated_at: string
          start_date: string | null
          end_date: string | null
          budget: number | null
          budget_spent: number | null
          key_objectives: Json | null
          stakeholders: Json | null
          risks: Json | null
          is_active: boolean
        }
        Insert: {
          id?: string
          name: string
          description?: string | null
          owner_id: string
          created_at?: string
          updated_at?: string
          start_date?: string | null
          end_date?: string | null
          budget?: number | null
          budget_spent?: number | null
          key_objectives?: Json | null
          stakeholders?: Json | null
          risks?: Json | null
          is_active?: boolean
        }
        Update: {
          id?: string
          name?: string
          description?: string | null
          owner_id?: string
          created_at?: string
          updated_at?: string
          start_date?: string | null
          end_date?: string | null
          budget?: number | null
          budget_spent?: number | null
          key_objectives?: Json | null
          stakeholders?: Json | null
          risks?: Json | null
          is_active?: boolean
        }
      }
      domain_inputs: {
        Row: {
          id: string
          project_id: string
          domain_id: number
          content: string | null
          last_updated: string
          created_by: string | null
        }
        Insert: {
          id?: string
          project_id: string
          domain_id: number
          content?: string | null
          last_updated?: string
          created_by?: string | null
        }
        Update: {
          id?: string
          project_id?: string
          domain_id?: number
          content?: string | null
          last_updated?: string
          created_by?: string | null
        }
      }
      domain_outputs: {
        Row: {
          id: string
          project_id: string
          domain_id: number
          content: string | null
          generated_date: string
          created_by: string | null
        }
        Insert: {
          id?: string
          project_id: string
          domain_id: number
          content?: string | null
          generated_date?: string
          created_by?: string | null
        }
        Update: {
          id?: string
          project_id?: string
          domain_id?: number
          content?: string | null
          generated_date?: string
          created_by?: string | null
        }
      }
      tasks: {
        Row: {
          id: string
          project_id: string
          task_id: string
          completed: boolean
          notes: string | null
          attachments: Json | null
          custom_fields: Json | null
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          id?: string
          project_id: string
          task_id: string
          completed?: boolean
          notes?: string | null
          attachments?: Json | null
          custom_fields?: Json | null
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          id?: string
          project_id?: string
          task_id?: string
          completed?: boolean
          notes?: string | null
          attachments?: Json | null
          custom_fields?: Json | null
          updated_at?: string
          updated_by?: string | null
        }
      }
      templates: {
        Row: {
          id: string
          domain_output_id: string | null
          name: string
          content: string | null
          created_at: string
        }
        Insert: {
          id?: string
          domain_output_id?: string | null
          name: string
          content?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          domain_output_id?: string | null
          name?: string
          content?: string | null
          created_at?: string
        }
      }
      teams: {
        Row: {
          id: string
          name: string
          description: string | null
          created_by: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          description?: string | null
          created_by?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          description?: string | null
          created_by?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      team_members: {
        Row: {
          id: string
          team_id: string
          user_id: string
          role: string
          created_at: string
        }
        Insert: {
          id?: string
          team_id: string
          user_id: string
          role?: string
          created_at?: string
        }
        Update: {
          id?: string
          team_id?: string
          user_id?: string
          role?: string
          created_at?: string
        }
      }
      team_projects: {
        Row: {
          id: string
          team_id: string
          project_id: string
          created_at: string
          created_by: string | null
        }
        Insert: {
          id?: string
          team_id: string
          project_id: string
          created_at?: string
          created_by?: string | null
        }
        Update: {
          id?: string
          team_id?: string
          project_id?: string
          created_at?: string
          created_by?: string | null
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
  }
}