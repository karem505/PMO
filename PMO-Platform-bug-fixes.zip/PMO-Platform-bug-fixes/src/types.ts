export interface TaskData {
  id: string;
  notes: string;
  attachments: string[];
  completed: boolean;
  acceptanceStatus?: 'idle' | 'accepted' | 'needs-refinement' | 'rejected';
  task_hash?: string;
} 